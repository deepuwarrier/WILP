<?php
namespace App\Be\Admin;

use App\Models\TW\TwUsrData;
use App\Helpers\TW\InsurerData;
use App\Models\Base\InstaPolicyM;

class AdminHomeBe {

	
} // end of class
