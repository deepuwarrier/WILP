<?php
namespace App\Be\Admin;

use App\Models\Base\InstaPolicyM;

class AdminOprBe {

	public function premium_summary_report ($from_date, $to_date, $filter_param) {
		$insta_policy_db = new InstaPolicyM();
		$data =  $insta_policy_db->between_dates( $from_date, $to_date, $filter_param);
		return $data;
	}	
	
	public function get_filter_map(){
		$insta_policy_db = new InstaPolicyM();
		$branch_list = $insta_policy_db->get_filter_list("branch_code");
		$module_list = $insta_policy_db->get_filter_list("module_name");
		$insurer_list = $insta_policy_db->get_filter_list("insurer_code");
		$agent_list = $insta_policy_db->get_filter_list("agent_name");
		return array(
				"branch" => $branch_list,
				"product" => $module_list,
				"insurer" => $insurer_list,
				"agent" => $agent_list
		);
	}
	
	private function policy_by_branch ($from_date, $to_date) {
		
	}
	
	private function filter_product () {
		
	}
	
	private function filter_insurer() {
		
	}
	
	private function filter_agent () {
		
	}


		

} // end of class
