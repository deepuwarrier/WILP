<?php
namespace App\Be\Admin;

use App\Models\Base\InstaPolicyM;
use App\Models\TW\TwUsrData;
use App\Models\Car\CarTData;
use App\Models\Health\HealthUserData;
use App\Models as M;
use App\Models\Travel\TravelUsrData;
use App\Models\InstaInsurers;
use App\Models\InstaUser;
use App\Helpers\TW\InsurerData;
use App\Helpers\Car\CarHelper;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Travel\TravelHelper;

class AdminReportsBe {

	public function premium_summary_report ($from_date, $to_date, $filter_param) {
		$insta_policy_db = new InstaPolicyM();
		$data =  $insta_policy_db->between_dates( $from_date, $to_date, $filter_param);
		return $data;
	}	
	
	public function get_filter_map(){
		$insta_policy_db = new InstaPolicyM();
		
		$branch_list = $insta_policy_db->get_filter_list("branch_code");
		$module_list = $insta_policy_db->get_filter_list("module_name");
		$insurer_list = $insta_policy_db->get_filter_list("insurer_code");
		$agent_list = $insta_policy_db->get_filter_list(["agent_name","agent_code"]);
		return array(
				"branch" => $branch_list,
				"product" => $module_list,
				"insurer" => $insurer_list,
				"agent" => $agent_list
		);
	}

	public function get_filter_map_users(){
		$insta_users = new InstaUser;
		$insta_policy_db = new InstaPolicyM();
		$branch_list = $insta_policy_db->get_filter_list("branch_code");
		$module_list = $insta_policy_db->get_filter_list("module_name");
		$insurer_list = $insta_policy_db->get_filter_list("insurer_code");
		$agent_list = $insta_users->get_filter_list(["name as agent_name","user_code as agent_code"],['user_type' => 3]);
		return array(
				"branch" => $branch_list,
				"product" => $module_list,
				"insurer" => $insurer_list,
				"agent" => $agent_list
		);
	}


	public function get_policy_count($from_date, $to_date, $filter_param,$coloum_name=null) {
		$insta_policy_db = new InstaPolicyM();
		$data =  $insta_policy_db->policy_count( $from_date, $to_date, $filter_param,$coloum_name);
		$_data = [];
		foreach ($data as $key => $value) {
			$_data['labels'][] = $this->getModuleFullName($value->$coloum_name,$coloum_name);
			$_data['value'][] = $value->policy_count;
		}
		return $_data;
	}

	private function getModuleFullName($module_shortcode,$coloum_name){

		switch ($module_shortcode) {
			case 'HL':
				return 'Health';
				break;
			case 'TW':
				return 'Two Wheeler';
				break;
			case 'PC':
				return 'Private Car';
				break;
			case 'TV':
				return 'Travel';
				break;
			default:
				return $module_shortcode;
				break;
		}
	}


	public function trans_summary_report( $param_arr ){ 
		if($param_arr["agent_code"] == 'direct'){
            $param_arr["agent_code"] = null;
            $param_arr["agent_name"] = null;
        }

		switch ($param_arr["product_code"]) {
			case "PC":
				return $this->pc_trans_list( $param_arr["from_date"], $param_arr["to_date"], $param_arr["agent_code"]);
				break;
			case "HL":
				return $this->hl_trans_list( $param_arr["from_date"], $param_arr["to_date"], $param_arr["agent_code"]);
				break;
			case "TV":
				return $this->tv_trans_list( $param_arr["from_date"], $param_arr["to_date"], $param_arr["agent_code"]);
				break;
			case "TW":
				return $this->tw_trans_list( $param_arr["from_date"], $param_arr["to_date"], $param_arr["agent_code"]);
		}
	return array();		
	}
	
	private function tw_trans_list ( $from_date, $to_date, $agent_code) {
		$ret_arr = array();
		$tw_usr_db = new TwUsrData();
		$master_data = new InsurerData();
		$insta_trans = new M\Base\InstaTransStatus();
		$raw_usr_data =   $tw_usr_db->get_trans_list($from_date, $to_date, $agent_code);
		foreach ($raw_usr_data as $data){
			$ret_arr[$data->trans_code] = array(
					"product_name"=> "TW",
					"insurer_name"=> isset( $data->insurer_code)?$master_data->insurer_data("isu_name", $data->insurer_code, true):'-',
					"trans_code"=> $data->trans_code,
					"quote_date"=> $data->quote_create_date != null ? $data->quote_create_date : " - ",
					"customer_name"=> isset($data->proposer_name)?$data->proposer_name:'-',
					"customer_phone"=> $data->proposer_mobile,
					"trans_details"=> $master_data->insr_variant("vechicle_name_desc", $data->variant_code, true),
					"trans_status"=> $insta_trans->getStatusName($data->trans_status), 
					"policy_number"=> $data->policy_number,
					"url" => $this->getUrlTransStatus($data->trans_status,$data->trans_code,$master_data->insurer_data("isu_url", $data->insurer_code, true))
			);
		}
		return $ret_arr;
	}
	
	private function pc_trans_list ( $from_date, $to_date, $agent_code) {
		$ret_arr = array();
		$tw_usr_db = new CarTData();
		$insta_insurer = new InstaInsurers();
		$master_data = new CarHelper();
		$insta_trans = new M\Base\InstaTransStatus();
		$raw_usr_data =   $tw_usr_db->get_trans_list($from_date, $to_date, $agent_code);

		foreach ($raw_usr_data as $data){
			if(in_array($data['insurer_id'], ['tata_gold','tata_pearl','tata_pearl_p','tata_sapphire','tata_sapphire_p','tata_sapphire_pp'])){
				$insurer_id = 'TATA';
			} else {
				$insurer_id = $data['insurer_id'];
			}

			$ret_arr[$data->trans_code] = array(
					"product_name"=> "PC",
					"insurer_name"=> isset($insurer_id)?$insta_insurer->insurer_column($insurer_id, "insurer_code"):'-',
					"trans_code"=> $data->trans_code,
					"quote_date"=> $data->quote_create_date != null ? $data->quote_create_date : " - ",
					"customer_name"=> (isset($data->usr_firstname) || ($data->usr_lastname) ) ?$data->usr_firstname." ".$data->usr_lastname:'-',
					"customer_phone"=> $data["usr_mobile"],
					"trans_details"=> $master_data->insr_variant("variant_name", $data->car_variant, true),
					"trans_status"=> $insta_trans->getStatusName($data->t_status),
					"policy_number"=>$data->policy_nu,
					"url" => $this->getUrlTransStatus($data['t_status'],$data['trans_code'],strtolower($data['insurer_id']))
			);
		}
		
		return $ret_arr;
	}
	private function hl_trans_list ( $from_date, $to_date, $agent_code) {
		$ret_arr = array();
		$hl_usr_db = new HealthUserData();
		$health_helper = new HealthHelper();
		$insta_insurer = new InstaInsurers();
		$insta_trans = new M\Base\InstaTransStatus();
		$raw_usr_data =   $hl_usr_db->get_trans_list($from_date, $to_date, $agent_code);
		foreach ($raw_usr_data as $data){

			$ret_arr[$data->trans_code] = array(
					"product_name"=> "HL",
					"insurer_name"=> isset($data->insurerId)?$insta_insurer->insurer_column($data->insurerId, "insurer_code"):'-',
					"trans_code"=> $data->trans_code,
					"quote_date"=> $data->quote_create_date != null ? $data->quote_create_date : " - ",
					"customer_name"=> $health_helper->get_proposer_name($data),
                                        "customer_phone"=>$data->mobile, 
					"trans_details"=> isset($data->productName)?$data->productName.' - '.$data->sum_insured.' (SI)':$data->sum_insured.' (SI)',
					"trans_status"=> $insta_trans->getStatusName($data->trans_status),
					"policy_number"=> $data->policy_num,
					"url" => $this->getUrlTransStatus($data->trans_status,$data->session_id,strtolower($data->insurerName))
			);
		}
		
		return $ret_arr;
	}
	private function tv_trans_list ( $from_date, $to_date, $agent_code) {
		$ret_arr = array();
		$tw_usr_db = new TravelUsrData();
		$travel_helper = new TravelHelper();
		$insta_insurer = new InstaInsurers();
		$insta_trans = new M\Base\InstaTransStatus();
		$raw_usr_data =   $tw_usr_db->get_trans_list($from_date, $to_date, $agent_code);
		foreach ($raw_usr_data as $data){
			$ret_arr[$data->trans_code] = array(
					"product_name"=> "TV",
					"insurer_name"=> isset($data->company_id)?$insta_insurer->insurer_column($data->company_id, "insurer_code"):' - ',
					"trans_code"=> $data->trans_code,
					"quote_date"=> $data->quote_create_date != null ? $data->quote_create_date : " - ",
					"customer_name"=> $travel_helper->get_proposer_name($data),$data->name,
                                        "customer_phone"=>$data->mobile, 
					"trans_details"=> isset($data->plan_code)?$data->plan_code.' - '.$data->sum_insured.' (SI)' : $data->sum_insured.' (SI)',
					"trans_status"=>$insta_trans->getStatusName($data->transaction_status),
					"policy_number"=>  $data->policy_num,
					"url" => $this->getUrlTransStatus($data->transaction_status,$data->trans_code,strtolower($data->company_id))
			);
		}
		
		return $ret_arr;
	}

	private function getUrlTransStatus($trans_status,$trans_code,$insurer_id){
		$url = '#';
		$module = substr($trans_code,0,2);
		$default_url = [
							'PC' => 'car-insurance',
							'HL' => 'health-insurance',
							'TV' => 'travel-insurance',
							'TW' => 'two-wheeler-insurance'
						];

		$base_url = $default_url[$module];
		if(in_array($trans_status,['TS10','TS11'])){
			if($module == 'TV'){
				$url = '/'.$base_url.'/quotes/'.$trans_code;
			} else {
				$url = '/'.$base_url.'/quote/'.$trans_code;
			}
		} else if(in_array($trans_status,['TS12','TS13','TS14','TS15','TS01','TS02','TS03'])){
			if($module == 'PC'){
				$url = '/'.$base_url.'/policy/'.$insurer_id.'/'.$trans_code;
			} else {
				$url = '/'.$base_url.'/'.$insurer_id.'/'.$trans_code;
			}
		}
		return $url;
	}
	

} // end of class
