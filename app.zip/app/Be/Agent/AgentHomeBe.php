<?php
namespace App\Be\Agent;

use App\Models\TW\TwUsrData;
use App\Helpers\TW\InsurerData;

class AgentHomeBe {

	public function get_active_leads($agent_code){ return array();
	return array_merge(
			$this->get_tw_proposals ($agent_code),
			$this->get_pc_proposals ($agent_code),
			$this->get_health_proposals ($agent_code),
			$this->get_travel_proposals ($agent_code)
	);
}	

private function get_tw_leads($agent_code) { 
		$ret_arr = array();
		$tw_usr_db = new TwUsrData();
		$master_data = new InsurerData();
		$raw_usr_data =   $tw_usr_db->get_by_agent_code($agent_code);
		foreach ($raw_usr_data as $data){
			
			$ref_url = "#";
			if( $data->insurer_code == null) {
				$ref_url = url('/') ."/two-wheeler-insurance/quote/" . $data->trans_code;
			} else{
				$ref_url = url('/') 
						."/two-wheeler-insurance/". 
						$master_data->insurer_data("isu_url", $data->insurer_code)
						."/" . $data->trans_code;
			}
			
			$ret_arr[$data->trans_code] = array(
					"trans_code"=> $data->trans_code,
					"lead_date"=> $data->quote_create_date != null ? $data->quote_create_date : " - ",
					"module_name"=> "TW",
					"insurer_name"=> $master_data->insurer_data("isu_name", $data->insurer_code, true),
					"lead_name"=> $data->proposer_name,
					"lead_details"=> $master_data->insr_variant("vechicle_name_desc", $data->variant_code),
					"lead_status"=> $data->trans_status,
					"lead_ref_url"=> $ref_url
			);
		}
		
		return $ret_arr;
	}
	private function get_pc_leads($agent_code) {
		return array();
	}
	private function get_health_leads($agent_code) {
		return array();
	}
	private function get_travel_leads($agent_code) {
		return array();
	}



} // end of class
