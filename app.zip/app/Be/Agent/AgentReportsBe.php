<?php
namespace App\Be\Agent;

use App\Models\Base\InstaPolicyM;

class AgentReportsBe {

	public function premium_summary_report ($from_date, $to_date, $filter_param) {
		$insta_policy_db = new InstaPolicyM();
		$data =  $insta_policy_db->between_dates( $from_date, $to_date, $filter_param);
		return $data;
	}	
	
	public function get_filter_map(){
		$insta_policy_db = new InstaPolicyM();
		$branch_list = $insta_policy_db->get_filter_list("branch_code");
		$module_list = $insta_policy_db->get_filter_list("module_name");
		$insurer_list = $insta_policy_db->get_filter_list("insurer_code");
		$agent_list = $insta_policy_db->get_filter_list("agent_name");
		return array(
				"branch" => $branch_list,
				"product" => $module_list,
				"insurer" => $insurer_list,
				"agent" => $agent_list
		);
	}

	public function get_policy_count($from_date, $to_date, $filter_param,$coloum_name=null) {
		$insta_policy_db = new InstaPolicyM();
		$data =  $insta_policy_db->policy_count( $from_date, $to_date, $filter_param,$coloum_name);
		$_data = [];
		foreach ($data as $key => $value) {
			$_data['labels'][] = $this->getModuleFullName($value->$coloum_name,$coloum_name);
			$_data['value'][] = $value->policy_count;
		}
		return $_data;
	}

	private function getModuleFullName($module_shortcode,$coloum_name){

		switch ($module_shortcode) {
			case 'HL':
				return 'Health';
				break;
			case 'TW':
				return 'Two Wheeler';
				break;
			case 'PC':
				return 'Private Car';
				break;
			case 'TV':
				return 'Travel';
				break;
			default:
				return $module_shortcode;
				break;
		}
	}
	
		

} // end of class
