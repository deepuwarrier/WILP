<?php
namespace App\Be\Car;

use App\Helpers\Car\CarHelper;
use Carbon\Carbon;
use App\Models\Car\CarMake;
use App\Models\Car\CarModels;
use App\Models\Car\CarVariant;
use App\Models\Car\CarState;
use App\Models\Car\CarRto;
use App\Models\Car\CarTData;
use App\Models\Car\CarConfig;
use App\Models\Car\MasterState;
use Illuminate\Support\Facades\Session;
use App\Constants\Car_Constants;

class CarDetailBe{
	private $car_details;
	private $defualt_make_code;

	public function __construct(){
		$this->defualt_make_code = 31;
	}

	public function getDefaultMakeCode(){
		return $this->defualt_make_code;
	}

	public function getCarMaxYear(){
		return date("Y");
	}

	public function getCarMinYear(){
		return 1999;
	}

    // return registration year list
	public function getYorList(){
	 	$carcfgobj = new CarConfig();
		$yorstart = $carcfgobj->getValue(Car_Constants::YOR_SEL_ST);
		$yordur = $carcfgobj->getValue(Car_Constants::YOR_SEL_DUR);
		$yorList = array();
		if(!$yorstart->isEmpty() and  !$yordur->isEmpty()){
			for($idx=0;$idx< $yordur[0]->config_value;$idx++){
		   		$yorList[$idx] = $yorstart[0]->config_value - $idx;
			}	
			return $yorList;
		}else{
			return null;
		}
	}
    
    // set car details 
	public function setCarDetails($details){
		$car_helper = new CarHelper;
		if(isset($details['rto'])){
			$details['rto_num'] = substr($details['rto'],2,strlen($details['rto']));
			$details['state_code'] = substr($details['rto'],0,2);	
		}
		$this->car_details =  $details;
	}
    
    public function getCarEmptyDetails(){
    	return ["make_code" => '',
			  "model_code" => '',
			  "variant" => '',
			  "state" => '',
			  "rto" => '',
			  "year" => '',
			  "fuel" => ''];
    }
    // return make from model
	public function getMakes(){
		$car_make = new CarMake;
		return $car_make->getCarMakes();
	} 

	// return model fro make
	public function getModel($make_code){
		$car_models = new CarModels;
		return $car_models->getCarModels($make_code);
	}
   
    // return variant of model
	public function getVariant($model_code){
		$car_variant = new CarVariant;
		return $car_variant->get_variant($model_code);
	}

    //  return rto of state
	public function getRto($state_id){
		$car_rto = new CarRto;
		return $car_rto->get_rto($state_id);
	}

    // return state
	public function getState(){
		$marster_state = new MasterState;
		return $marster_state->getCarState();	
	}
   
    // filter variant according to selected Fuel
	public function filter_variant($variants,$variant_type)
	{
	    $cng_variant = array('C',"L","E");
		$avialble_variant = array();
	    $filter_variant = array();
	    foreach($variants as $variant_key => $variant){
			/*
			$attr = explode("-",$variant->variant_attr);
			$ttt  = str_replace("(","",trim($attr[0]));
			$ttt  = str_replace(")","",$ttt);
			*/
			$ttt = $variant->fuel_type;
            if(!in_array($ttt,$avialble_variant)){
            		$avialble_variant[$ttt] = $ttt;
            }

			if($ttt == $variant_type && $variant_type != "CNG"){
				$filter_variant[] = $variant;
			}
			
			if($variant_type == "CNG" && in_array($ttt,$cng_variant)){
				$filter_variant[] = $variant;
			}
		} 
		return array('variant_category'=>$avialble_variant,
					  'variants'=>$filter_variant);
	}

	public function setPartnerId($trans_code){
		$parner_value = session('partner');
		$table = ['trans_code' => $trans_code,
			'partner_code' => $parner_value,
		];
		CarTData::updateOrCreate(array('trans_code' => $table['trans_code']), $table);
	}

	public function get_storable_details($data) {
		
		$vechicle_code = $data["vechicle_code"];
		$car_rto = $data["car_rto"];
		$car_yor = $data["car_year"];
		
		$rto_db = new CarRto();
		$rto_state = $rto_db->getRTOData($car_rto,'state')->state;
		$vehicle_arr = explode("^",$vechicle_code);  
		$make_code = $vehicle_arr[0];
		$model_code = $vehicle_arr[1];
		$variant_code = $vehicle_arr[2];
		$variant_db = new CarVariant();
		$variant_data = $variant_db->get_car_details($variant_code);
		$ret_arr = array (
				"car_make" => $make_code,
				"car_model" =>$model_code,
				"car_variant" => $variant_code,
				"make_name" => $variant_data['make_name'],
				"model_name" => $variant_data['model_name'],
				"variant_name" => $variant_data['variant_name'],
				"car_state" => $rto_state,
				"car_fuel" => $variant_data['fuel'],
				"car_rto" => $car_rto,
				"car_year"=>$car_yor,
		);
		return $ret_arr;
	}
}

?>
