<?php

namespace App\Be\Car;

use App\Constants\Car_Constants;
use App\Constants\Common_Constants;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use Carbon\Carbon;

class CarPolicyBe {

	public function getYears($trans_code = null) {
		$car_details = new M\CarTData;
		//$car_helper = new CarHelper;
		/*if ($session_id === null) {
			$session_id = session()->getId();
		}*/
		$car_details = $car_details->getSessionRowData($trans_code);
		$this->carcfgobj = (isset($this->carcfgobj)) ? $this->carcfgobj : new CarConfig();
		$yom_dropdown_value = $this->carcfgobj->getValue(Car_Constants::CAR_YOM_DROPDOWN_VALUE)[0]['config_value'];
		$yom = (is_null($car_details['car_year']))?(Carbon::now()->year):$car_details['car_year'];
		for ($i = 0; $i < $yom_dropdown_value; $i++) {
			$year_select[] = $yom - $i;
		}

		return $year_select;
	}

	public function getMinYear() {
		$this->carcfgobj = (isset($this->carcfgobj)) ? $this->carcfgobj : new CarConfig();
		$dob_min_age = $this->carcfgobj->getValue(Car_Constants::DOB_AGE_RESTRICTION)[0]['config_value'];
		return Carbon::now()->addYear(-$dob_min_age)->format('d/m/Y');
	}

	public function getTypeOfBusiness($date) {
		$carquotemodel = new M\CarQuoteModel;
		$yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		return (date('Y', strtotime($date)) == $yor_select_start) ? 'new_bussiness' : 'rollover';
	}

	public function getDbFormatDate($date) {
		return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
	}

	// make house length 5
	public function getHouseNu($house_no) {
		$length = strlen($house_no);
		if ($length < 5) {
			for ($i = 0; $i < (5 - $length); $i++) {
				$house_no = " " . $house_no;
			}
		}
		return $house_no;
	}

	// $required is a price actually they want
	// $passed what exactly we passed
	// this method check wether we need to confirmation from user,to pass a new price($required one)
	public function needConfirmation($required, $passed) {
		logger("Required Total Prcie is " . $required . " and we are passing " . $passed);
		$required_confirmation = 1;
		$allowed = Car_Constants::PREMIUM_MISSMATCHALLOWED_UP_TO;
		$add = 0;
		if ($passed < $required) {
			$check = $required - $passed;
			$add = 1;
		} else {
			$check = $passed - $required;
		}
		logger("Toatal Diff Is " . $check);

		if ($check <= $allowed) {
			$required_confirmation = 0;
		}
		return $required_confirmation;
	}

	public function getMasterDataFromField($data){
		$trace = debug_backtrace();
		$level = 1;
		$master = $this->masterFieldMapper($trace[$level]['class']);
		if ($data['redirected']) {
			foreach ($master as $master_field_name) {
				(!isset($data[$master_field_name]) || $data[$master_field_name] == '') && isset($data['master_' . $master_field_name]) && $data[$master_field_name] = $data['master_' . $master_field_name];
			}
		}
		return $data;
	}

	public function masterFieldMapper($masterFor = null){
		$masterFor = (isset($masterFor))? explode("\\",$masterFor) : null;
		$master = ['IffcoTokio' => Car_Constants::IT_MASTER_FORM_FIELD];		
		return (isset($masterFor))? $master[end($masterFor)] : $master;
	}		
}
