<?php
namespace App\Be\Car;
/**
* 
*/
use App\Models\Car\CarVariant;
use App\Http\Controllers as C;
use App\Models\Car\CarRto;
use App\Helpers\Car\CarHelper;
use App\Libraries\CarLib;
use App\Models\Car\CarConfig;
use App\Models\Car\CarQuoteModel;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use App\Constants\Car_Constants;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session\Store;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class CarQuoteBe
{
	
	function __construct()
	{
		$this->carcfgobj = new CarConfig();
	}


	private function genrateRegDate($registartion_year,$yor_select_start,$carregistration_diff){
		$registartion_date = Carbon::now();
		$registartion_date->year = $registartion_year;

		if($registartion_year == ($yor_select_start-1)){
			return	$regDate = $registartion_date->format('Y-m-d');
		}

		$calculated_date = $registartion_date->addDays($carregistration_diff)->format('Y-m-d');
		
		if($registartion_date->year <= $registartion_year){
			return $calculated_date;
		}

		
		$current_date = Carbon::now();
		$current_date->year = $registartion_year;
		return $current_date->endOfYear()->format('Y-m-d');
	}
	
	public function getCarDetails($user_data){
		$car_details = [];
		$car_helper = new CarHelper;
		$stateDb = new M\MasterState();
		$car_details['cust_gst_code'] = $stateDb->getGSTCode($user_data->car_state);

		$car_rto = new M\CarRto;
		$car_details['rto_zone'] = $car_rto->getRtoZone($user_data->car_rto);

		$carvariant = new CarVariant;
		$carvariant = $carvariant->get_car_details($user_data->car_variant);
		$car_details['vehicle_cc'] = $carvariant['vehicle_cc'];
		$car_details['seating_capacity'] = $carvariant['seating_capacity'];

	
		$idv_values = $this->getIDV($user_data);	
	
		if($idv_values['idv'] != $user_data->idv_calculated){
			$new_idv_values = $this->getUpdatedPrice($idv_values['idv'],
												$idv_values['idv'],
												$idv_values['price'],
												$user_data->car_registration_date,
												$user_data);
			$car_details['idv_min'] = $new_idv_values['idv_values']['idv_min'];
			$car_details['idv_max'] = $new_idv_values['idv_values']['idv_max'];
		}
		else{
			$car_details['idv_min'] = $idv_values['idv_min'];
			$car_details['idv_max'] = $idv_values['idv_max'];
		}

		$car_details['car_regis_min'] = Carbon::create($user_data->car_year, 1, 1)->format('d/m/Y');
		$car_details['car_regis_max'] = Carbon::create($user_data->car_year, 12, 31)->format('d/m/Y');
		
		if($user_data->type_of_business != 'Rollover'){
			$car_regis_max = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_MAX_DAYS)[0]['config_value'];
			$car_regis_min = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_MIN_DAYS)[0]['config_value'];
			$car_details['car_regis_min'] = Carbon::now()->addDays($car_regis_min)->format('d/m/Y');
			$car_details['car_regis_max'] = Carbon::now()->addDays($car_regis_max)->format('d/m/Y');
		}
		
		

		$map = array_flip($this->getFieldMap());
		$data = $car_helper->grabDetails($map,$user_data);
		return array_merge($data,$car_details);
	}
	
	public function setQuoteDetailInDb($user_data){
		$carcfgobj = new CarConfig;
		$car_helper_obj = new CarHelper;
		$carquotemodel_obj = new CarQuoteModel;
		$carvariant_obj = new CarVariant;
		$car_rto_obj = new M \ CarRto;

		$yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];

		if(!$user_data->type_of_business)
			$user_data->type_of_business = $user_data->car_year < $yor_select_start? 'Rollover' :  'New Business';

		// set reg date
		if(!$user_data->car_registration_date){	
			$carregistration_diff = $this->carcfgobj->getValue(Car_Constants::
	    	CAR_REGIS_DATE_DIFF)[0]['config_value'];
			$user_data->car_registration_date = $this->genrateRegDate($user_data->car_year,$yor_select_start,$carregistration_diff);
		}

		// set policy end date
		if(!$user_data->policy_expiry_date){
			 $policyenddate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_E_DATE_DIFF)[0]['config_value'];
			$policyExpiryDate = Carbon::now();
			$user_data->policy_expiry_date = $policyExpiryDate->addDays($policyenddate_diff)->format('Y-m-d');

		}

		// set policy start date
		if(!$user_data->policy_start_date){
			$policystartdate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_S_DATE_DIFF)[0]['config_value'];
			$newdate = Carbon::parse($user_data->policy_expiry_date);
			
			if($user_data->type_of_business == 'Rollover'){
				$user_data->policy_start_date = $newdate->addDays($policystartdate_diff)->format('Y-m-d');
			}else{
				$policyStartDate = Carbon::now();
				$policyStartDate->year = $user_data->car_year;
				$user_data->policy_start_date = $policyStartDate->addDays($policystartdate_diff)->format('Y-m-d');
				// chnage reg date
				$user_data->car_registration_date = $newdate->addDays(-1)->format('Y-m-d');
			}
		}

		//dd($user_data->policy_start_date);
		$od_start_date = 0;
	    $od_end_date = 0;
	    $tp_start_date = 0;
	    $tp_end_date = 0;
		
		if($user_data->policy_type_selection == '3'){
			$od_start_date = date('d-m-Y');
			$od_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));

			$tp_start_date = date('d-m-Y');
			$tp_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));
	    }

	    if($user_data->policy_type_selection == '1'){
			$od_start_date = date('d-m-Y');
			$od_end_date   = date('d-m-Y', strtotime('-1 Day +1 Year', strtotime(date('Y-m-d'))));

			$tp_start_date = date('d-m-Y');
			$tp_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));
	    }
	
	    $user_data->od_start_date = $od_start_date;
	    $user_data->od_end_date = $od_end_date;
	    $user_data->tp_start_date = $tp_start_date;
	    $user_data->tp_end_date = $tp_end_date;
	    
		if(!$user_data->idv_calculated){
			$this->setCarRegistrationDate('registartiondate',$user_data->car_registration_date);
			$this->setpolicyStartDate('policyStartDate',$user_data->policy_start_date);

			$idv_values = $this->getIDV($user_data);
			
			// set calculated idv
			$user_data->idv_calculated = $idv_values['idv']; 
			
			// set calculated price
			$user_data->calculated_price = $idv_values['price'];
			
			// set ncb
			$user_data->ncb = $idv_values['ncb'];
			$user_data->new_ncb = $this->checkNcb($user_data->type_of_business,$user_data->ncb);
			
			// age 
			$user_data->vehicle_age = $idv_values['age'];
			
			// idv min-max
			$idv_min = $idv_values['idv_min'];
			$idv_max = $idv_values['idv_max'];
			
			//claim staatus
			$user_data->claim = 'N';
		}

		if(!$user_data->covers_selected)
			$user_data->covers_selected = Car_Constants::DEFAULT_COVER_SELECTED;

		if(!$user_data->ex_showroom_price_id)
			$user_data->ex_showroom_price_id = $this->getExShowroomPrice('ex_showroom_car_price');
		$user_data->save();
		return $user_data;
	}
	
	public function getQuotes($request){
		$car_helper = new CarHelper;
		$car_lib = new CarLib;
		$trans_code = $request->trans_code;
		$user_data = CarTData::find($request->trans_code);
		$car_details = $this->getCarDetails($user_data);
		$return_data = [];
		$value_response =  $this->get_quote_new($car_details);
		if (!isset($value_response['error'])) {
			foreach ($value_response as $key=>$value) {
				$zerodep_addon_price = null;
				$zerodep_basic_price = null;
				$loseuse_basic_price = null;
				$era_addon_price = null;
				$ep_addon_price = null;
				$ncb_addon_price = null;
				$rti_addon_price = null;
				$pa_addon_price = null;
				$ll_addon_price = null;
				$insurer_id			  =	$value['insurerId'];
				$product_id	=	$key;
				$this->idv = $value['idv'];
				// $OD_price = $car_details['car_details']['actual_OD_price'];
				$OD_price = $car_lib->calculateOD($car_details['car_details']['vehicle_cc'],$car_details['car_details']['rto_zone'],$car_details['car_details']['vehicleAge'],$this->idv);

				// Namings for route
				$insurerroute = $this->routename($insurer_id);
				$insurerName 			=	$value['insurerName'];
				$netpremium 			=	$value['netPremium'];
				$totalpremium 			=	$value['totalPremium'];
				$netPremium				= 	$value['netPremium'];
				$serviceTax				= 	$value['serviceTax'];
				$idv_received			=	$value['idv'];
				$covers = array();
				$premiumBreakupdata = array('insurerName' => $insurerName);
				$premiumBreakupdata['basic'] = array();
				$premiumBreakupdata['addon'] = array();
				$premiumBreakupdata['discounts']= array();
				$basic_total_premium = 0;
				foreach ($value['premiumBreakup'] as $key2 => $premiumBreakup) {
					if (strtolower($key2) === 'basic') {
						foreach ($premiumBreakup as $key3 => $basic) {
							/*
							if ($key3 === 'OD') {
								$od_basic_price = $basic['premium'];
								$od_basic_displayname = $basic['displayName'];
								$od_basic_covers = $value['covers']['OD'];
								$covers['OD'] = $this->pharse_covers($od_basic_covers);
								$premiumBreakupdata['basic']['od_basic_price'] = array('displayName'=>'Own Damage','basic_premium'=>$od_basic_price);
							}
							*/
							if ($key3 === 'OD' && array_key_exists($key3,$value['covers'])) {
								${strtolower($key3).'_basic_price'} = $OD_price; // $basic['premium'];
								${strtolower($key3).'_discounted_amount'} = $basic['premium'];
								${strtolower($key3).'_discount'} = $OD_price - $basic['premium'];
								${strtolower($key3).'_basic_displayname'} = $basic['displayName'];
								${strtolower($key3).'_basic_covers'} = $value['covers'][$key3];
								$return_data[$product_id][strtolower($key3).'_basic_displayname'] = ${strtolower($key3).'_basic_displayname'};
								$return_data[$product_id][strtolower($key3).'_basic_price'] = $OD_price;
								$return_data[$product_id][strtolower($key3).'_basic_covers'] = $value['covers'][$key3];
								$covers[$key3] = $this->pharse_covers(${strtolower($key3).'_basic_covers'});
								$premiumBreakupdata['basic'][strtolower($key3).'_basic_price'] = array('displayName'=>'Own Damage','basic_premium'=>${strtolower($key3).'_basic_price'});
							}

							if ($key3 != 'OD' &&array_key_exists($key3,$value['covers'])) {
								${strtolower($key3).'_basic_price'} = $basic['premium'];
								${strtolower($key3).'_basic_displayname'} = $basic['displayName'];
								${strtolower($key3).'_basic_covers'} = $value['covers'][$key3];
								$basic_total_premium += ${strtolower($key3).'_basic_price'};
								$return_data[$product_id][strtolower($key3).'_basic_displayname'] = ${strtolower($key3).'_basic_displayname'};
								$return_data[$product_id][strtolower($key3).'_basic_price'] = $basic['premium'];
								$return_data[$product_id][strtolower($key3).'_basic_covers'] = $value['covers'][$key3];
								$covers[$key3] = $this->pharse_covers(${strtolower($key3).'_basic_covers'});
								$premiumBreakupdata['basic'][strtolower($key3).'_basic_price'] = array('displayName'=>${strtolower($key3).'_basic_displayname'},'basic_premium'=>${strtolower($key3).'_basic_price'});
							}
						}

						$od_discount_price = $od_discount;
						$od_discount_displayname = 'OD discount';
						$premiumBreakupdata['discounts']['od_discount_price']['displayName'] = $od_discount_displayname;
						$premiumBreakupdata['discounts']['od_discount_price']['basic_premium']=$od_discount_price;
						$new_netpremium	=	$od_basic_price 
											+ $basic_total_premium
											- $od_discount_price;

						$basic_premium = $new_netpremium;
						//array_push($premiumBreakupdata['basic'],array('displayName'=>'Basic Total Premium','basic_premium'=>$basic_premium));
					} else if(strtolower($key2) === 'addon') {
						$default_addon_added = Car_Constants::DEFAULT_ADDON_ADDED;
						foreach ($premiumBreakup as $key4 => $addon) {
							if ((($key4 != 'PA') && ($key4 != 'LL')) &&  array_key_exists($key4,$value['covers'])) {
								${strtolower($key4).'_addon_price'} = $addon['premium'];
								${strtolower($key4).'_addon_displayname'} = $addon['displayName'];
								${strtolower($key4).'_addon_covers'} = $value['covers'][$key4];
								// $premiumBreakupdata['addon'][strtolower($key4).'_addon_price'] = array('displayName'=>${strtolower($key4).'_addon_displayname'},'basic_premium'=>$addon['premium']);
								$return_data[$product_id][strtolower($key4).'_addon_displayname'] = ${strtolower($key4).'_addon_displayname'};
								$return_data[$product_id][strtolower($key4).'_addon_price'] = $addon['premium'];
								$return_data[$product_id][strtolower($key4).'_addon_covers'] = $value['covers'][$key4];
							} 

							foreach ($default_addon_added as $key_addon => $addon_value) {
								if ((($key4 === $addon_value)) && (array_key_exists($key4,$value['covers']))) {
									${strtolower($addon_value).'_addon_price'} = $addon['premium'];
									${strtolower($key4).'_addon_displayname'} = $addon['displayName'];
									${strtolower($key4).'_addon_covers'} = $value['covers'][$key4];
									$covers[$key4] = $this->pharse_covers(${strtolower($key4).'_addon_covers'});
									// $premiumBreakupdata['addon'][strtolower($key4).'_addon_price'] = array('displayName'=>${strtolower($key4).'_addon_displayname'},'basic_premium'=>$addon['premium']);
									$return_data[$product_id][strtolower($key4).'_addon_displayname'] = ${strtolower($key4).'_addon_displayname'};
									$return_data[$product_id][strtolower($key4).'_addon_price'] = $addon['premium'];
									$return_data[$product_id][strtolower($key4).'_addon_covers'] = $value['covers'][$key4];
									$premiumBreakupdata['addon'][strtolower($addon_value).'_addon_price'] = array('displayName'=>${strtolower($key4).'_addon_displayname'},'basic_premium'=>${strtolower($addon_value).'_addon_price'});
									$new_netpremium = 	$new_netpremium	+ ${strtolower($addon_value).'_addon_price'};
								} 
							}
						}
					}  else {
						if(($key2 != 'addon') && ($key2 != 'Basic')){
							foreach ($premiumBreakup as $key5 => $addon) {
								if ($key5 === 'NCB') {
									$ncbbenefit_addon_price = $addon['premium'];
									$ncbbenefit_addon_displayname = $addon['displayName'];
									$premiumBreakupdata['discounts']['ncbbenefit_addon_price']['displayName'] = 'No Claim Bonus';
									$premiumBreakupdata['discounts']['ncbbenefit_addon_price']['basic_premium']=$ncbbenefit_addon_price;
									// array_push($premiumBreakupdata['discounts'],array('displayName'=>'No Claim Bonus','basic_premium'=>$ncbbenefit_addon_price));
								}
							}	
							// If NCB benefit is present in the quote then it is subtract from the total premium
							$new_netpremium	=	$new_netpremium - $ncbbenefit_addon_price; 
						}
					}	
				}
				
				$netpremium = $new_netpremium;
				$serviceTax = round(($netpremium*Car_Constants::GST)/100);
				$totalpremium	=	round($netpremium + $serviceTax);

				$premiumBreakupdata['netPremium'] = array('displayName'=>'Net Premium','basic_premium'=>$netpremium);
				$premiumBreakupdata['serviceTax'] = array('displayName'=>'Goods & Service Tax','basic_premium'=>$serviceTax);
				$premiumBreakupdata['totalpremium'] = array('displayName'=>'Total Premium','basic_premium'=>$totalpremium);
				$value_to_stored = ['insurerName','netPremium','serviceTax','totalpremium','covers','product_id','insurerroute','insurer_img','insurer_id','idv_received','premiumBreakup','basic_premium'];
				foreach ($value_to_stored as $key => $value) {
					if ($value === 'insurer_img') {
						$return_data[$product_id]['insurer_img'] = $insurer_id;
					} elseif($value === 'netPremium'){
						$return_data[$product_id]['netPremium'] = $netpremium;
					} elseif($value === 'premiumBreakup'){
						$return_data[$product_id]['premiumBreakup'] = $premiumBreakupdata;
					}else {
						$return_data[$product_id][$value] = ${$value};
					}
				}
			$covers_selected[$product_id] = $covers;
			}
		// If session exists for the return data of Quotation then unset it.
		$forget_session = ['return_data','covers_selected','filter_data_back','filter_data'];
		foreach ($forget_session as $key => $value) {
			if (session($value)) {  //Helper function of session which works sames
				session()->forget($value);
			}
		}

		// Sorting of result as per the lowest to highest dependent in totalpremium
		$sortedarray = array();
		foreach ($return_data as $key => $row)
		{
		    $sortedarray[$key] = $row['totalpremium'];
		}

		array_multisort($sortedarray, SORT_ASC, $return_data);
		
		$array = array(
			'return_data' => $return_data,
			'filter_data_back' => $return_data,
			'error' => false,
			'message' => ''
		);
		session()->put('covers_selected',$covers_selected);
		} else {
			/*
			 * Below values will be passed if the response from api
			 * is null or an empty array
		 	*/
		 	$covers_selected = '#,#,#,';
			$array = array( 'return_data' => [],
							'error' => true,
							'message' => '');
		}
		return $array;	
	}

	private function get_quote_new($data){
		$car_details_value = $data['car_details'];
		$carvariant = new CarVariant;
		$carrto = new CarRto;
		$regDate = $car_details_value['car_registration_date'];		
		$policyStartDate = $car_details_value['policyStartDate'];
		$rto = $car_details_value['rto'];
		$typeOfBusiness = $car_details_value['typeOfBusiness'];
		$variant_code = $car_details_value['variant_code'];
		$idv  = $car_details_value['idv'];
		$vehicleAge = $car_details_value['vehicleAge'];
		$claim = $car_details_value['claim'];
		$prevncb = $car_details_value['ncb'];
		// Log::info('NCB value passed by user.', array($car_details_value['ncb']));
		// Log::info('PrevNCB passed to quote call.', array($prevncb));
		$url = 'http://api.brokeredge.in/rest/quote/allquotes/Motor/PC';
		$auth = array('accesskey'=>'TTIBI',
				'secretkey'=>'TTIBI');
		/** added fields for new **/
		$policyStartDate = date('Y-m-d',strtotime(str_replace("/", "-", $policyStartDate)));
	//	$policyEndDate = date('Y-m-d',strtotime(str_replace("/", "-", $policyExpDate)));

		$stateid=substr($rto,0,2);
		$rto_master= $carrto->get_rto_from_code($rto);
		//$rto_code=$rto_master[0]->rto_code;
		$rto_code = $rto;
		$cityid=$rto_master[0]->city;
		$vehicle_det=$carvariant->get_variant_filter(0,0,'',$variant_code);
		if(!empty($vehicle_det)){
			// $vehicleId=$vehicle_det[0]->v_id;
			$vehicleId=$vehicle_det[0]->lstdec_code; // For last decimal
            $variant_session = array($variant_code=>array('vehicleId'=>$vehicleId));
			session('variant',$variant_session);
			$price=$vehicle_det[0]->variant_price;
		}
		if(array_key_exists('price', $car_details_value)){
			$price = $car_details_value['price'];
		}
		$vehicleRegistrationDate = $regDate;
		$month_reg_date = date("m",strtotime($regDate));		
		if ($month_reg_date <4) {
			$yom=date("Y",strtotime($regDate)) - 1;
		}
		else
		{
			$yom=date("Y",strtotime($regDate));
		}	
		$postFields = array('authentication'=>$auth,
						'stateid'=>$stateid,
						'cityid'=>$cityid,
						'vehicleId'=> $vehicleId,
						'vehicleRegistrationDate'=>$vehicleRegistrationDate,
						'idv'=>$idv,
						'vehicleAge'=>$vehicleAge,
						'price'=>$price,
						'policyStartDate'=>$policyStartDate,
						'claim'=>$claim,
						'prevncb'=>$prevncb,
						'rto'=>$rto_code,
						'yom'=>$yom,
						'typeOfBusiness'=>$typeOfBusiness,
				//	'policyEndDate'=>$policyEndDate,
						);
		$irdo = callApi($url,$postFields);	 // call api and get the result
		if ( count($irdo) < 1 ) {
			$this->get_quote_new();
		} else if(!isset($irdo['error']) && is_array($irdo) && isset($irdo['data'])){
			$products = reArrangeProduct($irdo['data']);
			return $products;
		}else{
			return ['error'=>true];
		}
	}

	public function setExShowroomPrice($property,$value){
		$this->$property = $value;
	}

	public function getExShowroomPrice($property){
		return $this->$property;
	}

	public function setPolicyStartDate($property,$policyStartDate){
		session([$property =>$policyStartDate]);
	}
	public function setPolicyEndDate($property,$policyExpiryDate){
		session([$property =>$policyExpiryDate]);
	}

	public function setCarRegistrationDate($property,$registartiondate){
		session([$property =>$registartiondate]);
	}

	public function  setSessionValue($property,$sessionvalue){
		session([$property =>$sessionvalue]);
	}
	
	public function getpolicyStartDate($property){
		return session($property);
	}
	
	public function getPolicyEndDate($property){
		return session($property);
	}
	
	public function getCarRegistrationDate($property){
		return session($property);
	}

	public function getSessionValue($property){
		return session($property);
	}

	private function pharse_covers($covers){
		$repharse_coveres = array();
		foreach ($covers as $key => $value) {
			switch ($key) {
				case 'coverId':
					$repharse_coveres['name'] = $value;
					break;
				// case 'coverType':
				// 	$repharse_coveres['coverType'] = $value;
				// 	break;
				case 'seperateSi':			
						$repharse_coveres['si'] = $value;
						if ($repharse_coveres['name'] === 'PAPASS') {
							$repharse_coveres['si'] = '100000';
						}
					break;
				case 'num':
					$repharse_coveres['num'] = $value;
					break;
				// case 'coverLimits':
				// 	$repharse_coveres['coverLimits'] = $value;
				// 	break;
				default:
					# code...
					break;
			}
		}
		if ($repharse_coveres['name'] === 'LL') {
			$repharse_coveres['num'] = 1;
			$repharse_coveres = array_except($repharse_coveres,['si']);
		}
		
		return $repharse_coveres;
	}

	public function setFilterAddon($product_id,$addon_key,$addon_value){
		$quote_new = session('filter_data');
		$quote_new[$product_id]['premiumBreakup']['addon'][$addon_key] = $addon_value;
		session()->put('filter_data', $quote_new);
	}

	/*public function getFileName(){
		// $session_id = session()->getId();
		$trans_code = CarHelper::getsuid();
		$this->field = $this->getFieldMap();
		$user_data = CarTData::find($trans_code);
		$this->user_data = (!$user_data) ?
			[] : CarHelper::getFieldData($user_data,$this->field);
	}
*/

	public function getReturnSessionValue(){
		return json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH.'/'.Car_Constants::getQuoteFileName($this->getSessionValue('session_id'))),true);
	}

	private function routename($insurer_id){
		switch ($insurer_id) {
			case '139':
				$insurerroute =	'bhartiaxa';
				break;
			case '125':
				$insurerroute =	'hdfc';
				break;
			case '545':
				$insurerroute =	'unitedindia';
				break;
			case '106':
				$insurerroute =	'iffcotokio';
				break;
			case '132':
				$insurerroute =	'futuregenerali';
				break;
			case '134':
				$insurerroute =	'unisompo';
				break;
			case '113':
				$insurerroute =	'bajajallianz';
				break;
			default:
				$insurerroute =	'hdfc';
				break;
		}
		return $insurerroute;
	}

	public function setCarDetails($data){
		$car_helper = new CarHelper;
		$carquotemodel = new CarQuoteModel;
		$carvariant = new CarVariant;
		$car_rto = new M \ CarRto;
		$trans_code = $data['trans_code'];
       
	    $carregistration_diff = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_DATE_DIFF)[0]['config_value'];
	    $policyenddate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_E_DATE_DIFF)[0]['config_value'];
	    $policystartdate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_S_DATE_DIFF)[0]['config_value'];
	    $yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$carvariant = new CarVariant;
		$cardetails = $carvariant->get_car_details($data['variant_code']);
		$make = $data['make_code'];
		$model = $data['model_code'];
		$state = $data['state'];
		$this->vehicle_cc = $cardetails['vehicle_cc'];
		$variant_code = $cardetails['variant_code'];
		// $vehicleId = $cardetails['vehicleId'];
		$make_name = $cardetails['make_name'];
		$model_name = $cardetails['model_name'];
		$fuel = $cardetails['fuel'];
		$variant_name = $cardetails['variant_name'];
		$date = Carbon::now();

		$policy_type_selection = 0;
		if(isset($data['policy_type_selection'])){
			$policy_type_selection = $data['policy_type_selection'];
		}
		
		if(isset($data['car_registration_date'])){
			$registartiondate = Carbon::parse(str_replace('/','-',$data['car_registration_date']));
			$regDate = $registartiondate->format('Y-m-d');
			$registartionyear = $registartiondate->year;
		} else {
			$registartiondate = Carbon::now();
			$registartiondate->year = $data['year'];
			$registartionyear	= $data['year'];
			if($data['year'] == ($yor_select_start-1)){
				$regDate = $registartiondate->format('Y-m-d');
			}
			else {
				$calculated_date = $registartiondate->addDays($carregistration_diff)->format('Y-m-d');
				if($registartiondate->year > $registartionyear){
					$current_date = Carbon::now();
					$current_date->year = $data['year'];
					$regDate = $current_date->endOfYear()->format('Y-m-d');
					$registartiondate = $regDate;
				} else {
					$regDate = $calculated_date;
				}
			}
		}

		if(!empty($data['policy_start_date'])){
			$policyDate = Carbon::parse(str_replace('/','-',$data['policy_start_date']));
			$policyStartDate = $policyDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyStartDate)));
		} else {
			$policyStartDate = Carbon::now();
			$policyStartDate->year =$data['year'];
			$policyStartDate = $policyStartDate->addDays($policystartdate_diff)->format('Y-m-d');
		}

		if(!empty($data['policy_expiry_date'])){
			$policyEDate = Carbon::parse(str_replace('/','-',$data['policy_expiry_date']));
			$policyExpiryDate = $policyEDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyExpiryDate)));
		} else {
			$policyExpiryDate = Carbon::now();
			$policyExpiryDate = $policyExpiryDate->addDays($policyenddate_diff)->format('Y-m-d');
		}


		// $typeOfBusiness = $registartionyear < date('Y')? 'Rollover' :  'New Business';

		$typeOfBusiness = $registartionyear < $yor_select_start? 'Rollover' :  'New Business';

		$newdate = Carbon::parse($policyExpiryDate);
		if($typeOfBusiness == 'Rollover')
			$policyStartDate = $newdate->addDays($policystartdate_diff)->format('Y-m-d');
	 	else
	 		// if(!isset($regDate)) 
				$regDate = $newdate->addDays(-1)->format('Y-m-d');

		$this->setPolicyStartDate('policyStartDate',$policyStartDate);
		$this->setPolicyEndDate('policyExpiryDate',$policyExpiryDate);
		$this->setCarRegistrationDate('registartiondate',$registartiondate);
		$variant_code = $data['variant_code'];
		$rto = $data['rto'];
		$this->rto_zone = $car_rto->getRtoZone($rto); 
		$cov = Car_Constants::DEFAULT_COVER_SELECTED; //'#,#';
		if($cov = "#,#,#,"){
			$covers_default_array = ['covers_selected_name'=>'Own Damage, Third Party Liability, Covers for Owner Driver and Paid Driver','covers_selected_id'=>$cov];
		}
		/* IDV calculation part*/
		$data['policy_start_date'] = date('d/m/Y',strtotime($policyStartDate));
		$idv_values = $this->getIDV($data);
		$ex_showroom_car_price = $this->getExShowroomPrice('ex_showroom_car_price');
		$this->vehicleAge = $idv_values['age'];
		if(!empty($data['quantity']))
		{
			//$idv= $data['quantity'];
			$new_idv_values = $this->getUpdatedPrice($data['quantity'],$idv_values['idv'],$idv_values['price'],$regDate,$data);
			$idv = $new_idv_values['idv'];
			$price = $new_idv_values['price'];
			$ncb_idv_value = $data['ncb'];
			$idv_min = $new_idv_values['idv_values']['idv_min'];
			$idv_max = $new_idv_values['idv_values']['idv_max'];
		} else {

			/* Below are the default values as per the selected car and year */
			$idv = $idv_values['idv'];   
			$price = $idv_values['price'];
			$ncb_idv_value = $idv_values['ncb'];
			$idv_min = $idv_values['idv_min'];
			$idv_max = $idv_values['idv_max'];
		}
		/* IDV calculation part ends here */

		if (!empty($data['claim_status']) && $data['claim_status'] === 'Y') {
			$claim = 'Y';
			$ncb= 0;
			$new_ncb = 0;
		} elseif(!empty($data['claim']) && $data['claim'] === 'Y') {
			$claim = 'Y';
			$ncb= 0;
			$new_ncb = 0;
		} else {
			$claim = 'N';
			$ncb = isset($data['ncb'])?$data['ncb']:$ncb_idv_value;
			$new_ncb = $this->checkNcb($typeOfBusiness,$ncb);
		}
		if(!empty($data['expiry_status']) && $data['expiry_status'] == 2){
			$ncb= 0;
			$new_ncb = 0;
		}
		/* Below values are calculated for calendar details and its validation */
		$car_regis_max = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_MAX_DAYS)[0]['config_value'];
		$car_regis_min = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_MIN_DAYS)[0]['config_value'];

		$registartionyear = $registartionyear;
		if($typeOfBusiness === 'Rollover'){
			$minDate = Carbon::create($registartionyear, 1, 1)->format('d/m/Y');
			$maxDate = Carbon::create($registartionyear, 12, 31)->format('d/m/Y');
		} else {
			$minDate = Carbon::now()->addDays($car_regis_min)->format('d/m/Y');
			$maxDate = Carbon::now()->addDays($car_regis_max)->format('d/m/Y');
		}
		$stateDb = new M\MasterState();
		$cust_gst_code = $stateDb->getGSTCode($state);
		/* Calendar values ends here */
		$cov = (isset($data['chks'])) ? $data['chks'] : $cov;
		$car_details_array = array(
								'cust_gst_code'=>$cust_gst_code,
								'make_code'=> $make,
								'model_code'=>$model,
								'variant_code' => $variant_code,
								'state'=>$state,
								'make_name' => $make_name,
								'model_name' =>$model_name,
								'fuel'=>$fuel,
								'variant_name' =>$variant_name,
								'ncb'=>$ncb,
								'rto' => $rto,
								'rto_zone' => $this->rto_zone,
								'claim'=>$claim,
								'vehicle_cc' =>$this->vehicle_cc,
								// 'vehicleId'=>$vehicleId,
								'typeOfBusiness'=>$typeOfBusiness,
								'policyStartDate'=>$policyStartDate,
								'policyExpiryDate'=>$policyExpiryDate,
								'car_registration_date'=>$regDate,
								'vehicleAge' => $this->vehicleAge,
								'ex_showroom_car_price'=>$ex_showroom_car_price,
								'price'=>$price,
								'cov' => $cov,
								'idv'=>$idv,
								'new_ncb' =>$new_ncb,
								'year'=>$registartionyear,
								'idv_min' => $idv_min,
								'idv_max' => $idv_max,
								'car_regis_min' => $minDate,
								'car_regis_max' => $maxDate,
								'seating_capacity' => $cardetails['seating_capacity'],
								'policy_type_selection' =>$policy_type_selection
							 );
		
		if(isset($data['expiry_day'])) 
		   $car_details_array['expiry_status']  = $data['expiry_day'];
		else
		 	$car_details_array['expiry_status']  = 0;


		if(!empty($data['quantity'])){
			$car_details_array['updated_idv']  = $idv;
		}
		$car_details_array['trans_code'] = $trans_code;
		$car_t_data = $this->setQuoteData($car_details_array);
		if (session('car_details')) {  //Helper function of session which works sames
			session()->forget('car_details');
		}
		return $car_t_data;
	}

	private function getUpdatedPrice($selected_idv,$actualIDV,$actual_price,$reg_year,$user_data){
		$idv_variant = $this->carcfgobj->getValue(Car_Constants::IDV_VARIANT_PERCENTAGE)[0]['config_value'];
		$diff_idv_percentage = round(((($selected_idv - $actualIDV)/$actualIDV)*100),2);
		$unsigned_diff_idv_percentage = abs($diff_idv_percentage);
		if($unsigned_diff_idv_percentage<$idv_variant){
			if ($diff_idv_percentage<0) {
				$new_price = $actual_price - (($actual_price*$unsigned_diff_idv_percentage)/100);
			} else {
				$new_price = $actual_price + (($actual_price*$unsigned_diff_idv_percentage)/100);
			}
		} else {
			if ($diff_idv_percentage<0) {
				$new_price = $actual_price - (($actual_price*$idv_variant)/100);
			} else {
				$new_price = $actual_price + (($actual_price*$idv_variant)/100);
			}
		}
		$idv_values = $this->calculateIDV($new_price,$user_data);
		return array('idv' => $selected_idv,'price' => round($new_price),'ncb' => $idv_values['ncb'],'idv_values'=>$idv_values);
	}

	private function getIDV($user_data){
		$variant_code = isset($user_data->car_variant)?$user_data->car_variant:$user_data['variant_code'];
		$carvariant = new CarVariant;
		$price = $carvariant->getPrice($variant_code);
		$this->setExShowroomPrice('ex_showroom_car_price',$price);
		$idv_values = $this->calculateIDV($price,$user_data);
		return $idv_values;
	}

	public function calculateIDV($price,$user_data){
		$idv_variant = $this->carcfgobj->getValue(Car_Constants::IDV_VARIANT_PERCENTAGE)[0]['config_value'];
		$policyStartDate = isset($user_data->policy_start_date)?$user_data->policy_start_date:date('Y-m-d',strtotime(str_replace('/','-',$user_data['policy_start_date'])));	//$this->getpolicyStartDate('policyStartDate');
		$carRegistrationDate = isset($user_data->car_registration_date)?$user_data->car_registration_date:date('Y-m-d',strtotime(str_replace('/','-',$user_data['car_registration_date']))); //$this->getCarRegistrationDate('registartiondate');
		$d1 = date($policyStartDate);
		$d2 = date($carRegistrationDate);

		// Temp Fix. Need to restore back
		if(date('Y/m/d',strtotime($d2)) == date('Y/m/d',strtotime('02/02/2015'))){
			$age = 3;
		} else {
			$from = new \DateTime($d1);
		    $to   = new \DateTime($d2);
		    $age  = $from->diff($to)->y;
		}
		
		$percantage = "40";
		$ncbp = 50;
		switch($age){
			case 0: $percantage = "95"; $ncbp=0; break;
			case 1: $percantage = "85"; $ncbp=0; break;
			case 2: $percantage = "80"; $ncbp=20; break;
			case 3: $percantage = "70"; $ncbp=25; break;
			case 4: $percantage = "60"; $ncbp=35; break;
			case 5: $percantage = "50"; $ncbp=45; break;
			case 6: $percantage = "45"; $ncbp=50; break;
			default: $percantage = "40"; $ncbp=50;
		}
		$idv = round(($price * $percantage)/100);
		// $idv_Tenpercen = ($idv*10)/100;
		$idv_min = $idv - ($idv*$idv_variant)/100;
		$idv_max = $idv + ($idv*$idv_variant)/100;
		return array('age'=>$age,'ncb'=>$ncbp,'idv'=>$idv,'idv_min'=>$idv_min,'idv_max'=>$idv_max,'price'=>$price);
	}

	public function checkNcb($typeOfBusiness,$ncb){

		if ($typeOfBusiness === 'New Business') {
			$ncb_map = array('0'=>0,'20'=>25,'25'=>35,'35'=>45,'45'=>50,'50'=>50);
			$new_ncb = $ncb_map[$ncb];
		} else {
			$ncb_map = array('0'=>20,'20'=>25,'25'=>35,'35'=>45,'45'=>50,'50'=>50);
			$new_ncb = $ncb_map[$ncb];
		}
		return $new_ncb;
	}

	public function setQuoteData($data){
		$car_t_data = new CarTData;
		!isset($data['trans_code'])?$data['trans_code'] = session()->getId():$data['trans_code'];
		$data['user_code'] = !empty(session('user_code'))?session('user_code'):NULL;
		$agent_store = new C\Customers\Customers();
		// $agent_store->agentUserCode($data['user_code']);
		$agent_store->setModule('car');
		$agent_store->setUserCode($data['user_code']);
		$agent_store->storeAgentCode($data['trans_code']);
		$field = $this->getFieldMap();
		foreach ($field as $key => $value) if(isset($data[$value])) $table[$key] = $data[$value];
		try{
			return $car_transaction = $car_t_data->updateOrCreate(array('trans_code'=>$table['trans_code']),$table);
		}catch(\Exception $e){
			echo $e->getMessage();
			die;
		}
	}
	// map sql column with form field
    public function getFieldMap($map_for = null){
      $fields = [
                 Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
      				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_QUOTELOG['user_code']=>'user_code',
                Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] =>'ncb',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] =>'new_ncb',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] =>'claim',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] =>'typeOfBusiness',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] =>'policyStartDate',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] =>'policyExpiryDate',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] =>'car_registration_date',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] =>'vehicleAge',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] =>'ex_showroom_car_price',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] =>'price',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] =>'cov',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] =>'cov',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] =>'idv',
                Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] =>'quote_response_file',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] =>'return_quote_url',
                Car_Constants::CAR_T_QUOTELOG['EXP_STATUS']=>'expiry_status',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_TYPE']=>'policy_type_selection',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_OD_START_DATE']=>'od_start_date',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_OD_END_DATE']=>'od_end_date',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_TP_START_DATE']=>'tp_start_date',
                Car_Constants::CAR_T_QUOTELOG['QUOTE_TP_END_DATE']=>'tp_end_date'
         ];
      return ($map_for)? $fields[$map_for] :  $fields;
	}
}
