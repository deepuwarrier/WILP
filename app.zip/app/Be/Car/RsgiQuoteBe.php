<?php
namespace App\Be\Car;

use App\Be\Car as BE;
use App\Models\Car as M;
use App\Models\Car\CarVariant;
use App\Helpers\Car as H;
use Carbon\Carbon;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;
use App\Libraries\CarLib;

class RsgiQuoteBe
{
	
	function __construct()
	{
		$this->carcfgobj = new M\CarConfig();
		$this->refrel_variant_col = "rsgi_code";
		$this->enable_addons = [];
	}
	public function valueAddon($addon,$pb_data){
		$available = 0;
		switch ($addon) {
			case 'ZERODEP':
				$available = round($pb_data->getZerodepPremium());
				
				break;
			case 'EP':
				$available = round($pb_data->getEpPremium());
				
				break;
			case 'RTI':
				$available = round($pb_data->getRtiPremium());
				
				break;
			case 'PAPASS':
				$available = round($pb_data->getPapassPremium());
				
				break;
			default:
				# code...
				break;
		}
		return $available;
	}

	public function enableAddon($addon){
		$available = 0;
		switch ($addon) {
			case 'ZERODEP':
				$available = 1;
				$this->proposer_request['vehicleDetails']['hdnDepreciation']	=	'true';
				break;
			case 'EP':
				$available = 1;
				$this->proposer_request['vehicleDetails']['hdnProtector'] 		=	'true';
				break;
			case 'RTI':
				$available = 1;
				$this->proposer_request['vehicleDetails']['hdnInvoicePrice']	=	'true';
				break;
			case 'PAPASS':
				$available = 1;
				$this->proposer_request['vehicleDetails']['personalaccidentcoverforunnamedpassengers']	=	100000;
		$this->proposer_request['vehicleDetails']['personalAccidentCoverForUnnamedPassengers']	=	100000;
				break;
			default:
				# code...
				break;
		}
		return $available;
	}

	public function setAddon($cov){
		$addon_available = 1;
		$addons = explode(",", $cov);
		
		unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
   
        foreach ($addons as $key => $value) {
        	$this->enable_addons[] = $value;
        	$addon_available =  $this->enableAddon($value);
        	if(!$addon_available)
        		break;
        }
        return $addon_available;
	}

	public function setVehicleDetails($data){
		$this->proposer_request['vehicleDetails']['hdnDepreciation']	=	'false';
		$this->proposer_request['vehicleDetails']['hdnInvoicePrice']	=	'false';
		$this->proposer_request['vehicleDetails']['personalaccidentcoverforunnamedpassengers']	=	0;
		$this->proposer_request['vehicleDetails']['personalAccidentCoverForUnnamedPassengers']	=	0;
		$this->proposer_request['vehicleDetails']['hdnProtector'] 		=	'false';
		$car_helper = new H\CarHelper;
		$car_variant = new M\CarVariant;
		$car_rto = new M\CarRto;
		$car_rsgi_idv = new M\CarRsgiIDV;
		$yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$ref_col = $this->refrel_variant_col;
		$registartionyear	=	$data['year'];
		$typeOfBusiness = $registartionyear < $yor_select_start? 'Rollover' :  'New Business';
		$variant_code = $data['variant_code'];
		$vehicleId = $car_variant->getVehicleId($variant_code,$ref_col)->$ref_col;
		$carRegisteredCity	=	$car_rto->get_rsgi_city_from_rto_code($data['rto'])->rsgi_rto_city_name;
		//$carRegisteredRegion	=	M\CarState::get_rsgi_region($data['state'])->rsgi_region;
		$engineCapacityAmount	=	$car_variant->fetchCC($variant_code)->variant_cc.' CC';
		$fuelType	=	$car_variant->fetchFuelType($variant_code);

		/* IDV calculation part*/
		$idv_values = $this->getIDV($registartionyear,$variant_code);
		$ex_showroom_car_price = $this->getExShowroomPrice('ex_showroom_car_price');
		$this->vehicleAge = $idv_values['age'];



		if($idv_values['idv'] != $data['idv'])
		{
			$new_idv_values = $this->checkIDV($data['idv'],$idv_values['idv'],$registartionyear);
			$idv = $new_idv_values;
		} else {
			$idv = $idv_values['idv'];   
		}

		if (!empty($data['claim']) && $data['claim'] === 'Y') {
			$claimsMadeInPreviousPolicy = 'Yes';
			$ncbcurrent 	= 0;
			$noClaimBonusPercent = 0;
			$claimsReported = 1;
			$claimAmountReceived = round(($idv*5)/100);  // Make 5% of IDV

			$this->proposer_request['vehicleDetails']['claimsReported'] = $claimsReported;
			$this->proposer_request['vehicleDetails']['claimAmountReceived'] = $claimAmountReceived;

		} else 
		{
			$claimsMadeInPreviousPolicy = 'No';
			$prevncb 		= $data['ncb'];
			$ncbcurrentArray 	= ['0'=>'20','20'=>'25','25'=>'35','35'=>'45','45'=>'50','50'=>'50'];
			$noClaimBonusPercentArray = ['0'=>1,'20'=>2,'25'=>3,'35'=>4,'45'=>5,'50'=>6];
			$ncbcurrent 		= $ncbcurrentArray[$prevncb];
			$noClaimBonusPercent	= $noClaimBonusPercentArray[$prevncb];
			$this->proposer_request['vehicleDetails']['claimsReported'] = 0;
			$this->proposer_request['vehicleDetails']['claimAmountReceived'] = '';
		}
		$this->proposer_request['vehicleDetails']['accidentCoverForPaidDriver']	= '';
		$this->proposer_request['vehicleDetails']['addonValue']	= '';
		$this->proposer_request['vehicleDetails']['automobileAssociationMembership']	= '';
		$this->proposer_request['vehicleDetails']['averageMonthlyMileageRun'] = 3000; // Car_Constants::PROPOSAL_DEFAULT['DRIVING_EXP'];
		$this->proposer_request['vehicleDetails']['carRegisteredCity']	= $carRegisteredCity;
		$this->proposer_request['vehicleDetails']['chassisNumber'] = 'RJBESi5ZnR01IL';
		$this->proposer_request['vehicleDetails']['claimsMadeInPreviousPolicy']	= $claimsMadeInPreviousPolicy;
		$this->proposer_request['vehicleDetails']['claimsReported'] = '0';
		$this->proposer_request['vehicleDetails']['companyNameForCar'] = '';
		$this->proposer_request['vehicleDetails']['cover_dri_othr_car_ass']	= 'No';
		$this->proposer_request['vehicleDetails']['cover_elec_acc']	= 'No';
		$this->proposer_request['vehicleDetails']['cover_non_elec_acc']	= 'No';
		$this->proposer_request['vehicleDetails']['depreciationWaiver']	= 'off';
		$this->proposer_request['vehicleDetails']['drivingExperience'] = Car_Constants::PROPOSAL_DEFAULT['DRIVING_EXP'];
		$this->proposer_request['vehicleDetails']['electricalAccessories']	= '';
		$this->proposer_request['vehicleDetails']['engineCapacityAmount']	= $engineCapacityAmount;
		$this->proposer_request['vehicleDetails']['engineNumber']	= '6WUaj4ENJ2';
		$this->proposer_request['vehicleDetails']['engineprotector']	=	'on';
		$this->proposer_request['vehicleDetails']['fibreGlass']	=	'No';
		$this->proposer_request['vehicleDetails']['financierName']	=	'Bajaj';
		$this->proposer_request['vehicleDetails']['fuelType']	= $fuelType;
		$this->proposer_request['vehicleDetails']['hdnKeyReplacement']	=	'false';
		$this->proposer_request['vehicleDetails']['hdnLossOfBaggage']	=	'false';
		
		$this->proposer_request['vehicleDetails']['hdnNCBProtector']	=	'false';
		
		
		
		$this->proposer_request['vehicleDetails']['hdnRoadTax']			=	'false';
		$this->proposer_request['vehicleDetails']['hdnSpareCar']		=	'false';
		$this->proposer_request['vehicleDetails']['hdnWindShield']		=	'false';
		$this->proposer_request['vehicleDetails']['idv']	= $idv;
		$this->proposer_request['vehicleDetails']['invoicePrice']	= 'on';
		$this->proposer_request['vehicleDetails']['isBiFuelKit']	=	'No';
		$this->proposer_request['vehicleDetails']['isBiFuelKitYes']	=	'No';
		$this->proposer_request['vehicleDetails']['isCarFinanced']	=	'No';
		$this->proposer_request['vehicleDetails']['isCarOwnershipChanged']	=	'No';
		$this->proposer_request['vehicleDetails']['isPreviousPolicyHolder']	=	'true';
		$this->proposer_request['vehicleDetails']['keyreplacement']	=	'off';
		$this->proposer_request['vehicleDetails']['legalliabilityToPaidDriver']		=	'Yes';
		$this->proposer_request['vehicleDetails']['modified_idv_value']		= $idv;
		$this->proposer_request['vehicleDetails']['modify_your_idv']		= '0';  // have to ask
		$this->proposer_request['vehicleDetails']['ncbcurrent']	 				= $ncbcurrent;
		$this->proposer_request['vehicleDetails']['ncbprotector']		=	'off';
		$this->proposer_request['vehicleDetails']['noClaimBonusPercent']	 	= $noClaimBonusPercent;
		$this->proposer_request['vehicleDetails']['nonElectricalAccesories']	 	= '';
		$this->proposer_request['vehicleDetails']['original_idv'] = $idv;
		
		$this->proposer_request['vehicleDetails']['previousInsurerName']	=	'';
		if($typeOfBusiness==="Rollover"){
			$this->proposer_request['vehicleDetails']['policyED']	=	$data['policy_expiry_date'];

			$this->setPolicyEndDate('policyExpiryDate',$this->proposer_request['vehicleDetails']['policyED']);
			
			$this->proposer_request['vehicleDetails']['policySD']	=	$car_helper->manDate($this->getPolicyEndDate('policyExpiryDate'),'d/m/Y',['-1 years']);
			
			$this->proposer_request['vehicleDetails']['previousPolicyExpiryDate']	=	$this->getPolicyEndDate('policyExpiryDate');

			
		} else {
			$this->proposer_request['vehicleDetails']['ProductName'] = 'BrandNewCar';
			$this->proposer_request['vehicleDetails']['typeOfCover']	= 'Bundled';
		}
		$this->proposer_request['vehicleDetails']['previousPolicyType']	=	"Comprehensive";
		$this->proposer_request['vehicleDetails']['previousinsurersCorrectAddress']=	'ABC Company';
        $this->proposer_request['vehicleDetails']['previuosPolicyNumber']=	'D234234234234';
        
        if($typeOfBusiness==="Rollover") {
        	$this->proposer_request['vehicleDetails']['ProductName'] = 'RolloverCar';
        }
        $this->proposer_request['vehicleDetails']['region']	= '';
        $this->proposer_request['vehicleDetails']['registrationchargesRoadtax']	= 'off';
        $this->proposer_request['vehicleDetails']['spareCar']	= 'off';
        $this->proposer_request['vehicleDetails']['totalIdv']	= $idv;
        $this->proposer_request['vehicleDetails']['valueOfLossOfBaggage']	= '';
		$this->proposer_request['vehicleDetails']['valueofelectricalaccessories']	= '';
		$this->proposer_request['vehicleDetails']['valueofnonelectricalaccessories']	= '';
		$vehicleModelCode = $car_variant->getVehicleId($data['variant_code'],$ref_col)->$ref_col;
		$this->proposer_request['vehicleDetails']['vehicleManufacturerName']	=	isset($car_rsgi_idv->getIdvValue($vehicleModelCode,'make')->make)?$car_rsgi_idv->getIdvValue($vehicleModelCode,'make')->make:'';
		$this->proposer_request['vehicleDetails']['vehicleModelCode']	=	$vehicleModelCode;
		$this->proposer_request['vehicleDetails']['vehicleMostlyDrivenOn']	=	'City Roads';
		$this->proposer_request['vehicleDetails']['vehicleRegisteredInTheNameOf']	= 'Individual';
		$this->proposer_request['vehicleDetails']['vehicleSubLine']	=	'privatePassengerCar';
		$this->proposer_request['vehicleDetails']['vehicleregDate'] = date("d/m/Y",strtotime($this->getPolicyEndDate('registartiondate')));
		
		$this->proposer_request['vehicleDetails']['voluntarydeductible']	= '';
		$this->proposer_request['vehicleDetails']['vehicleId']	= $vehicleId;
		$this->proposer_request['vehicleDetails']['windShieldGlass']	= 'on';
		$month_reg_date = date("m",strtotime($this->getPolicyEndDate('registartiondate')));

		if ($month_reg_date <4) {
			$this->proposer_request['vehicleDetails']['yearOfManufacture']	=	date("Y",strtotime($this->getPolicyEndDate('registartiondate'))) - 1;
		}
		else
		{
			$this->proposer_request['vehicleDetails']['yearOfManufacture']	=	date("Y",strtotime($this->getPolicyEndDate('registartiondate')));
		}
	}

	public function setProposerDetails($data) {
		$this->proposer_request['proposerDetails']['dateOfBirth']	=	 '12/08/1980';
	}

	public function addon_provided($pb_data){
		if(empty($this->enable_addons))
			return true;

		foreach ($this->enable_addons as $key => $value) {
			$addon_value =  $this->valueAddon($value,$pb_data);
        	if(!$addon_value)
        		break;
		}

		return $addon_value;
	}

	public function getRsgiQuoteCall($data){
		$car_helper = new H\CarHelper;
		$rsgi_helper = new H\RSGI\RsgiHelper;
		$rsgi_helper->trans_code = $data['trans_code'];

		$this->proposer_request['isNewUser'] = 'Yes';
		$this->setProposerDetails($data);
		$this->setVehicleDetails($data);
		$is_true = $this->setAddon($data['cov']);
		
		if(!$is_true)
			return 0;

		if($data['policy_type_selection'] == 3)
			return 0;

		$trans_code = $data['trans_code'];
		
		$this->proposer_request['isproductcheck'] = 'true';
		$this->proposer_request['istranscheck'] = 'true';
		$this->proposer_request['premium'] = '0.0';
		$this->proposer_request['proposerDetails']['addressOne'] = 'No1';
		$this->proposer_request['proposerDetails']['addressTwo'] = 'North Street';
		$this->proposer_request['proposerDetails']['contactAddress1'] = 'No1';
		$this->proposer_request['proposerDetails']['contactAddress2'] = 'North Street';
		$this->proposer_request['proposerDetails']['contactCity'] = 'Chennai';
		$this->proposer_request['proposerDetails']['contactPincode'] = '600001';
		$this->proposer_request['proposerDetails']['dateOfBirth'] = '12/08/1990';
		$this->proposer_request['proposerDetails']['guardianAge'] =' ';
		$this->proposer_request['proposerDetails']['guardianName'] =' ';
		$this->proposer_request['proposerDetails']['nomineeAge'] = '66';
		$this->proposer_request['proposerDetails']['nomineeName'] = 'ozpvlzk';
		$this->proposer_request['proposerDetails']['occupation'] = 'Student';
		$this->proposer_request['proposerDetails']['regCity'] = 'Chennai';
		$this->proposer_request['proposerDetails']['regPinCode'] = '600001';
		$this->proposer_request['proposerDetails']['relationshipWithNominee'] = 'Cousin';
		$this->proposer_request['proposerDetails']['relationshipwithGuardian'] =' ';
		$this->proposer_request['proposerDetails']['sameAdressReg'] = 'No';
		$this->proposer_request['proposerDetails']['strPhoneNo'] = '57879797';
		$this->proposer_request['proposerDetails']['strStdCode'] = '044';
		$this->proposer_request['proposerDetails']['userName'] = 'michael@xerago.com';
		$this->proposer_request['proposerDetails']['strEmail'] = 'michael@xerago.com';
		$this->proposer_request['proposerDetails']['strFirstName'] = 'imsaxec';
		$this->proposer_request['proposerDetails']['strLastName'] =' ';
		$this->proposer_request['proposerDetails']['strMobileNo'] = '9810063054';
		$this->proposer_request['proposerDetails']['strTitle'] = 'Mr';	

		/* Temp Data ended*/
		$url = Car_Constants::RSGI_QUOTE_URL;

		$irdo = $rsgi_helper->callRsgiQuoteApi($url,$this->proposer_request,$trans_code);	 // call api and get the result
		if ( count($irdo) < 1 ) {
			Log::error('CAR - RSGI - '.$trans_code.' Count of $irdo is less then 1 i.e. it is null');
		} else if(!isset($irdo['error'])){
			if(!empty($irdo)){

				$pb_data = new PremiumBreakupData();
				$car_lib =  new CarLib;
				$OD_price = $car_lib->calculateOD($data['vehicle_cc'],
					$data['rto_zone'],
					$data['vehicleAge'],
					$data['idv']);
				
				$pb =  new PremiumBreakup();

				$pb_data = $rsgi_helper->parse_premium_breakup_data($pb_data,$irdo);

				
				// get manually od discount
				$od_discount = $OD_price - $pb_data->getOdPremium();
				$pb_data->setOdDiscount($od_discount);
				$pb_data->setOdPremium($OD_price);
				$pb->setPbDatat($pb_data);

				if(!$this->addon_provided($pb_data))
					return false;

				$PremiumBreakup = $pb->genratePremiumBreakup();
					
				//$idv_opted = $irdo['DATA']['IDV'];
				$idv_opted = $data['idv'];
				$trans_code = $data['trans_code'];
				$quote_id = $irdo['DATA']['QUOTE_ID'];

				unset($irdo);
				unset($data);
				unset($pb);
				unset($car_lib);
				unset($OD_price);
				unset($od_discount);
			
		  return ['totalpremium' => $pb_data->getTotalPremium()
		            , 'insurer_id' => 'rsgi'
		            , 'product_id' => 'rsgi'
		            ,'insurerroute' => 'rsgi'
		            ,'trans_code' => $trans_code
		            , 'idv_received' => round($idv_opted)
		            , 'netPremium' => $pb_data->getGrossPremium()
		            , 'insurerName' => 'Royal Sundaram GI'
		            , 'serviceTax' => $pb_data->getServiceTax()
		            , 'premiumBreakup' => $PremiumBreakup
		        	, 'QUOTE_ID'=>$quote_id
		        	, 'pb_data' => $pb_data];
		        	
			} else {
				return ['error'=>'true'];	
			}
		}else{
			return ['error'=>'true'];
		}
	}


	private function calculateDate($data){
		$carregistration_diff = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_DATE_DIFF)[0]['config_value'];
	    $policyenddate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_E_DATE_DIFF)[0]['config_value'];
	    $policystartdate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_S_DATE_DIFF)[0]['config_value'];
	    $yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$date = Carbon::now();
		if(!empty($data['car_registration_date'])){
			$registartiondate = Carbon::parse(str_replace('/','-',$data['car_registration_date']));
			$regDate = $registartiondate->format('Y-m-d');
			$registartionyear = $registartiondate->year;

		} else {
			$registartiondate = Carbon::now();
			$registartiondate->year = $data['year'];
			$regDate = $registartiondate->addDays($carregistration_diff)->format('Y-m-d');
			$registartionyear = $registartiondate->year;
		}

		if(!empty($data['policy_start_date'])){
			$policyDate = Carbon::parse(str_replace('/','-',$data['policy_start_date']));
			$policyStartDate = $policyDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyStartDate)));
		} else {
			$policyStartDate = Carbon::now();
			$policyStartDate->year =$data['year'];
			$policyStartDate = $policyStartDate->addDays($policystartdate_diff)->format('Y-m-d');
		}
		if(!empty($data['policy_expiry_date'])){
			$policyEDate = Carbon::parse(str_replace('/','-',$data['policy_expiry_date']));
			$policyExpiryDate = $policyEDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyExpiryDate)));
		} else {
			$policyExpiryDate = Carbon::now();
			$policyExpiryDate = $policyExpiryDate->addDays($policyenddate_diff)->format('Y-m-d');
		}

		$typeOfBusiness = $registartionyear < $yor_select_start? 'Rollover' :  'New Business';
		$newdate = Carbon::parse($policyExpiryDate);
		if($typeOfBusiness === 'Rollover')
			$policyStartDate = $newdate->addDays($policystartdate_diff)->format('Y-m-d');
	 	else 
			$regDate = $newdate->addDays(-1)->format('Y-m-d');
		$this->setPolicyStartDate('policyStartDate',$policyStartDate);
		$this->setPolicyEndDate('policyExpiryDate',$policyExpiryDate);
		$this->setCarRegistrationDate('registartiondate',$registartiondate->format('Y-m-d'));
	}

	public function setPolicyStartDate($property,$policyStartDate){
		session([$property =>$policyStartDate]);
	}
	public function setPolicyEndDate($property,$policyExpiryDate){
		session([$property =>$policyExpiryDate]);
	}

	public function setCarRegistrationDate($property,$registartiondate){
		session([$property =>$registartiondate]);
	}

	public function getpolicyStartDate($property){
		return session($property);
	}
	
	public function getPolicyEndDate($property){
		return session($property);
	}
	
	public function getCarRegistrationDate($property){
		return session($property);
	}


	private function getIDV($reg_year,$variant_code){
		$carvariant = new CarVariant;
		$price = $carvariant->getPrice($variant_code);
		$this->setExShowroomPrice('ex_showroom_car_price',$price);
		$idv_values = $this->calculateIDV($price,$reg_year);
		return $idv_values;
	}

	public function calculateIDV($price,$reg_year){
		// $cDate = Carbon::parse($reg_year);
		// $age = $cDate->diffInYears();
		$policyStartDate = $this->getpolicyStartDate('policyStartDate');
		$carRegistrationDate = $this->getCarRegistrationDate('registartiondate');
		// $policyStartDate = session('car_details')['policyStartDate'];
		// $carRegistrationDate = session('car_details')['car_registration_date'];
		
		$d1 = date($policyStartDate);
		$d2 = date($carRegistrationDate);

		$age = $d1 - $d2;
		$percantage = "40";
		$ncbp = 50;
		switch($age){
			case 0: $percantage = "95"; $ncbp=0; break;
			case 1: $percantage = "85"; $ncbp=0; break;
			case 2: $percantage = "80"; $ncbp=20; break;
			case 3: $percantage = "70"; $ncbp=25; break;
			case 4: $percantage = "60"; $ncbp=35; break;
			case 5: $percantage = "50"; $ncbp=45; break;
			case 6: $percantage = "45"; $ncbp=50; break;
			default: $percantage = "40"; $ncbp=50;
		}
		$idv = round(($price * $percantage)/100);
		$idv_Tenpercen = ($idv*10)/100;
		$idv_min = $idv - $idv_Tenpercen;
		$idv_max = $idv + $idv_Tenpercen;
		return array('age'=>$age,'ncb'=>$ncbp,'idv'=>$idv,'idv_min'=>$idv_min,'idv_max'=>$idv_max,'price'=>$price);
	}
	public function setExShowroomPrice($property,$value){
		$this->$property = $value;
	}

	public function getExShowroomPrice($property){
		return $this->$property;
	}
	public function checkIDV($selected_idv,$actualIDV,$reg_year){
		$idv_variant = $this->carcfgobj->getValue(Car_Constants::IDV_VARIANT_PERCENTAGE)[0]['config_value'];
		$diff_idv_percentage = ((($selected_idv - $actualIDV)/$actualIDV)*100);
		$unsigned_diff_idv_percentage = abs($diff_idv_percentage);
		$idv =	($unsigned_diff_idv_percentage<$idv_variant) ? $selected_idv : (($diff_idv_percentage<0) ?  ($actualIDV - (($actualIDV*$idv_variant)/100)) : ($actualIDV + (($actualIDV*$idv_variant)/100)));
		return $idv;
		/*
		$idv =	($unsigned_diff_idv_percentage<$idv_variant) ? 
							($diff_idv_percentage<0) ? ($actual_price - (($actual_price*$unsigned_diff_idv_percentage)/100)) : $actual_price + (($actual_price*$unsigned_diff_idv_percentage)/100) : 
							($diff_idv_percentage<0) ?  ($actual_price - (($actual_price*$idv_variant)/100)) : ($actual_price + (($actual_price*$idv_variant)/100));
		*/

		/*if($unsigned_diff_idv_percentage<$idv_variant){
			// $new_price = ($diff_idv_percentage<0) ? ($actual_price - (($actual_price*$unsigned_diff_idv_percentage)/100)) : $actual_price + (($actual_price*$unsigned_diff_idv_percentage)/100);
			if ($diff_idv_percentage<0) {
				$new_price = $actual_price - (($actual_price*$unsigned_diff_idv_percentage)/100);
			} else {
				$new_price = $actual_price + (($actual_price*$unsigned_diff_idv_percentage)/100);
			}
		} else {
			// $new_price = ($diff_idv_percentage<0) ?  ($actual_price - (($actual_price*$idv_variant)/100)) : ($actual_price + (($actual_price*$idv_variant)/100));
			if ($diff_idv_percentage<0) {
				$new_price = $actual_price - (($actual_price*$idv_variant)/100);
			} else {
				$new_price = $actual_price + (($actual_price*$idv_variant)/100);
			}
		}*/
	}
}

?>
