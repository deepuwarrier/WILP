<?php
namespace App\Be\Car;

use App\Be\Car as BE;
use App\Models\Car as M;
use App\Helpers\Car as H;
use App\Libraries\CarLib;
use App\Constants\Car_Constants;
use Carbon\Carbon;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;
use App\Be\Common\GstBe;
use Log;
/**
 *  
 */
class TataQuoteBe
{
	private $typeOfBusiness;
	private $policyStartDate;
	private $registartionyear;
	private $registartionDate;
	private $policyExpiryDate;
	private $idv;

	function __construct()
	{
		$this->carcfgobj = new M\CarConfig();
		$this->refrel_variant_col = "tata_code";
		$this->car_lib = new CarLib;
		$this->zerodep				=	0;
		$this->ep 					=	0;
		$this->rti 					=	0;
		$this->papass 				=	0;
		$this->pa 					=	0;
		$this->ll 					=	0;
		$this->daily_allowance		=	0;
		$this->lpb					=	0;
		$this->et_hotelexpenses		=	0;
		$this->keyreplace			=	0;
		$this->cosumable_expenses	=	0;
		$this->repair_of_glass		=	0;
		$this->ts					=	0;
		$this->ncbprotect			=	0;
		$this->rsac					=	0;
		$this->packages 			= '';
	}

	public function tataQuoteCall($idv_data){
		$this->trans_code = $idv_data['trans_code'];
		if($idv_data['idv'] > 10000000){
			Log::error('CAR - TATA AIG - '.$this->trans_code.' IDV is greater then 1 CR so can not display quote');
			return ['error'=>'true'];
		}
		$car_helper = new H\CarHelper;
        $user_data = M\CarTData::find($this->trans_code);
        
        $field = $car_helper->getQuoteFieldMap();
        $car_details = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $field);
		$this->setRequest($car_details);
		$this->trans_code = $idv_data['trans_code'];
		$this->setInputJson($idv_data);
		
		if($user_data->veh_electricle)
			$this->quote_request['cover']['C4'] = ['opted'=>'Y','SI'=>$user_data->veh_electricle];
		
		if($user_data->veh_no_electricle)
			$this->quote_request['cover']['C4'] = ['opted'=>'Y','SI'=>$user_data->veh_no_electricle];

		//C29
		if($user_data->veh_cng_external == 'Y'){
			// fuel_code 5
			// fuel_name External CNG
			$this->quote_request['vehicle']['fuel_name'] =	'External CNG'; //$car_variant->fetchFuelType($variant_code); //'Petrol';
			$this->quote_request['vehicle']['fuel_code'] = 5;
			$this->quote_request['cover']['C29'] = ['opted'=>'Y'];
			$this->quote_request['cover']['C29'] = ['opted'=>'Y'];
		}
		
		$this->setPackages($idv_data);
		return $this->packages;
	}

	public function tataQuoteCallMismatch($idv_data,$product_id){
		$this->trans_code = $idv_data['trans_code'];
		if($idv_data['idv'] > 10000000){
			Log::error('CAR - TATA AIG - '.$this->trans_code.' IDV is greater then 1 CR so can not display quote');
			return ['error'=>'true'];
		}
		$car_helper = new H\CarHelper;
        $user_data = M\CarTData::find($this->trans_code);
        
        $field = $car_helper->getQuoteFieldMap();
        $car_details = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $field);
		$this->setRequest($car_details);
		$this->trans_code = $idv_data['trans_code'];
		$this->setInputJson($idv_data);
		
		if($user_data->veh_electricle)
			$this->quote_request['cover']['C4'] = ['opted'=>'Y','SI'=>$user_data->veh_electricle];
		
		if($user_data->veh_no_electricle)
			$this->quote_request['cover']['C5'] = ['opted'=>'Y','SI'=>$user_data->veh_no_electricle];

		//C29
		if($user_data->veh_cng_external == 'Y'){
			// fuel_code 5
			// fuel_name External CNG
			$this->quote_request['vehicle']['fuel_name'] =	'External CNG'; //$car_variant->fetchFuelType($variant_code); //'Petrol';
			$this->quote_request['vehicle']['fuel_code'] = 5;
			$this->quote_request['cover']['C7'] = ['opted'=>'Y','SI'=>$user_data->veh_cng_external_value];
			$this->quote_request['cover']['C29'] = ['opted'=>'Y'];
		}

		if(!empty($user_data->veh_reg_no) && $user_data->type_of_business == 'Rollover'){
			$registartion_no_array = explode('-',$user_data->veh_reg_no);
			$this->quote_request['vehicle']['regno_1'] = $registartion_no_array[0];
			$this->quote_request['vehicle']['regno_2'] = $registartion_no_array[1];
			$this->quote_request['vehicle']["regno_3"] = $registartion_no_array[2];
			$this->quote_request['vehicle']["regno_4"] = $registartion_no_array[3];
		}
		


		$this->setPackagesM($idv_data,$product_id);
		return $this->packages;
	}

	private function setPackagesM($idv_data,$product_id){
		$car_c_poduct = new M\CarProducts;
		// $tata_packages = $this->filter_package([$product_id => [ 'product_id' => $product_id]]);
		// $pack = $this->checkAddon($tata_packages);
		$pack = [$product_id => true];
		// $pack = $tata_packages;
		// dd($pack);
		foreach ($pack as $key => $value) {
			if($value){
				// $product_id = $value['product_id'];
				$product_id = $key;
				$this->activateAddon($product_id);
				$this->setAddon();
				// $this->genrateInputXml();
				$idv_data['product_id'] = $product_id;
				$this->callTataApi($idv_data);	
			}
		}	
	}

	private function setInputJson($request) {
		$this->getQuoteRequestData();
		$car_variant = new M\CarVariant;
		$request = $this->getRequest();
		$variant_code = $request['variant_code'];
		$this->setVehicleSegment($variant_code);
		$this->calculateDate();
		$this->setIdvData();
		$this->setClaimStatus();
		// $this->setVehicleAge();	
		// $this->setNcbPercentage();
		$this->setRegisNo();
		$this->setCarDetails();
		$this->setUserQuoteData();
		// dd($this->quote_request);
	}

	private function setUserQuoteData(){
		
		$this->quote_request['vehicle']['risk_startdate'] = date('Ymd',strtotime($this->getpolicyStartDate()));
		$this->quote_request['vehicle']['risk_enddate'] = date('Ymd',strtotime('-1 Day +1 Year',strtotime($this->getpolicyStartDate())));
		$this->quote_request['vehicle']['btype_name'] = $this->getTypeOfBusiness();
		$this->quote_request['vehicle']['btype_code'] = ($this->getTypeOfBusiness() == 'Roll Over')? '2':'1';
		$this->quote_request['vehicle']['manf_year'] = $this->getRegistartionyear();
		$this->quote_request['vehicle']['purchase_date'] = date('Ymd',strtotime($this->getRegistartionDate()));
		$this->quote_request['vehicle']['pp_enddate'] = ($this->getTypeOfBusiness() == 'Roll Over')? date('Ymd',strtotime($this->getPolicyExpiryDate())):'';

		if($this->getTypeOfBusiness() != 'Roll Over'){
			$this->quote_request['vehicle']['pp_curr_ncb'] = '0';
		}
		$this->quote_request['vehicle']['idv'] = $this->getIdv();
		$this->quote_request['vehicle']['revised_idv'] = $this->getIdv();
		$this->quote_request['vehicle']['veh_age'] = $this->getVehicleAge();
	}

	private function setPackages($idv_data){
		$car_c_poduct = new M\CarProducts;
		$tata_packages = $this->filter_package($car_c_poduct->getTataProductId());
		$pack = $this->checkAddon($tata_packages);
		foreach ($pack as $key => $value) {
			if($value){
				// $product_id = $value['product_id'];
				$product_id = $key;
				$this->activateAddon($product_id);
				$this->setAddon();
				$idv_data['product_id'] = $product_id;
				$this->callTataApi($idv_data);	
			}
		}	
	}

	private function callTataApi($idv_data){
		$car_helper = new H\CarHelper;
		$tata_helper = new H\TATA\TataHelper;
		$product_id = $idv_data['product_id'];
		$trans_code	=	$this->trans_code;
		$url = Car_Constants::TATA_QUOTE_URL;
		
		if((($this->quote_request['vehicle']['make_name'] ||$this->quote_request['vehicle']['make_code']) == null) || (($this->quote_request['vehicle']['model_name'] ||$this->quote_request['vehicle']['model_code']) == null) || (($this->quote_request['vehicle']['variant_name'] ||$this->quote_request['vehicle']['variant_code']) == null)){
			return ['error'=>'true'];
		}

		
		$request_quick  = $this->getQuickQuote(json_encode($this->quote_request),$idv_data);
		if($request_quick == 'false'){
			$this->packages['error'] = 'true';
		}
		$request = [
				'QDATA'	=>	json_encode($request_quick),
				'SRC'	=>	Car_Constants::TATA_SRC,
				'productid'	=>	'3121',
				'T'	=>	Car_Constants::TATA_TOKEN
			];
		$irdo = $tata_helper->callJson("Tata Full Quote ".$product_id." :- ",$url,$request,$trans_code);	 // call api and get the result
		// Log::info('Car Tata Quote '.$product_id.' Response - '.$trans_code.' - '.print_r($irdo,true));
		
		if ( count($irdo) < 1 ) {
			Log::info('CAR - Tata Quote '.$product_id.' Response - '.$trans_code.' - count of $irdo is less then 1 i.e. it is null');
			return ['error'=>'true'];
		} else if(isset($irdo['status']) && $irdo['status'] && empty($irdo['data']['errcode'])){
			if(!empty($irdo)){
				$pb_data = new PremiumBreakupData();
				$pb_data = $tata_helper->parse_premium_breakup_data_new($pb_data,$irdo);
				// get service tax
				$stateDb = new M\MasterState();
				$cust_gst_code = $stateDb->getGSTCode($idv_data['state']);
				unset($stateDb);
				$vendor_gst_code = Car_Constants::TATA_GST_CODE;
		        $gstBe = new GstBe();
		        $gstData = $gstBe->get_gst_values($vendor_gst_code,
		        								$cust_gst_code,
		        								round($pb_data->getGrossPremium()));
		        $pb_data->setServiceTax($gstData->get_total_tax());
		        unset($gstBe);
		        unset($vendor_gst_code);
		        unset($cust_gst_code);

		        $car_lib = new CarLib;
		        $OD_price = $car_lib->calculateOD($idv_data['vehicle_cc'],
					$idv_data['rto_zone'],
					$idv_data['vehicleAge'],
					$idv_data['idv']);
		        unset($car_lib);
		        
		        $od_discount = $OD_price - $pb_data->getOdPremium();
				$pb_data->setOdDiscount($od_discount);
				$pb_data->setOdPremium($OD_price);
				unset($OD_price);
				unset($od_discount);
				// if($pb_data->getRsacPremium() == '0.0'){
				// 	$rsac_premium =  116;
				// 	$pb_data->setRsacPremium($rsac_premium);
				// 	$pb_data->setGrossPremium($pb_data->getGrossPremium()+$pb_data->getRsacPremium());
				// 	$service_tax = ($pb_data->getServiceTax() + (($pb_data->getRsacPremium()*18)/100));
				// 	$pb_data->setServiceTax($service_tax);
				// 	$pb_data->setTotalPremium($pb_data->getGrossPremium()+$pb_data->getServiceTax());
				// }
				$pb = new PremiumBreakup();				
				$pb->setPbDatat($pb_data);
				$PremiumBreakup = $pb->genratePremiumBreakup(Car_Constants::PB_FORMAT);

				$product_id = $tata_helper->getAddonProductId($irdo['data']['quotationdata']['addon_plan_code']);
				unset($tata_helper);

				$car_m_products = new M\CarProducts;
				$cmp_details = $car_m_products->getCompDetails($product_id);
				unset($car_m_products);
				
				$idv_received = $irdo['data']['quotationdata']['idv']; 
				$trans_code = $idv_data['trans_code'];
				$product_img = $cmp_details->product_img;
				$product_name = $cmp_details->product_name;
				$quote_id	= $irdo['data']['quotationdata']['quotation_no'];
				unset($cmp_details);
				unset($idv_data);
				unset($irdo);

				$data = ['totalpremium' => $pb_data->getTotalPremium()
	            , 'insurer_id' => 'TATA'
	            , 'product_id' => $product_id
	            ,'insurerroute' => 'tata'
	            ,'trans_code' => $trans_code
	            , 'idv_received' => round($idv_received)
	            , 'netPremium' => $pb_data->getGrossPremium()
	            , 'insurerName' => $product_name
	            , 'serviceTax' => $pb_data->getServiceTax()
	            , 'premiumBreakup' => $PremiumBreakup
	        	, 'logo'=>$product_img
	        	, 'pb_data'=>$pb_data
	        	,'QUOTE_ID'=>$quote_id];

	        	$page = M\CarTData::find($trans_code);
				// Make sure you've got the Page model
				if($page) {
				    $page->quote_id = $quote_id;
				    $page->save();
				}
	        	$this->packages[$product_id] = $data;
			} else {
				$this->packages[$product_id]['error'] = 'true';
			}
		}else{
			$this->packages[$product_id]['error'] = 'true';
		}
	}

	public function getQuickQuote($quote_request,$idv_data){
		$car_helper = new H\CarHelper;
		$tata_helper = new H\TATA\TataHelper;
		$product_id = $idv_data['product_id'];
		$trans_code	=	$this->trans_code;
		$url = Car_Constants::TATA_QUOTE_URL;
		$request = [
				'QDATA'	=>	$quote_request,
				'SRC'	=>	Car_Constants::TATA_SRC,
				'productid'	=>	'3121',
				'T'	=>	Car_Constants::TATA_TOKEN
			];
		$irdo = $tata_helper->callJson("Tata Quick Quote".$product_id." :- ",$url,$request,$trans_code);	 // call api and get the result
		if(isset($irdo['status']) && $irdo['status'] && empty($irdo['data']['errcode'])){
			$full_quote_data = json_decode($quote_request,true);
			$full_quote_data['quote_type'] = 'full';
			$full_quote_data['vehicle']['fleet_id'] = $irdo['data']['quotationdata']['fleet_id'];
			$full_quote_data['vehicle']['discount_perc'] = $irdo['data']['quotationdata']['discount_perc'];
			$full_quote_data['vehicle']['campaign_id'] = $irdo['data']['quotationdata']['campaign_id'];
			$quote_idv_l_limit = $irdo['data']['quotationdata']['idvlowerlimit'];
			$quote_idv_u_limit = $irdo['data']['quotationdata']['idvupperlimit'];
			// idv
			if($full_quote_data['vehicle']['idv'] < $quote_idv_l_limit ){
				$full_quote_data['vehicle']['idv'] =  $quote_idv_l_limit;
				$full_quote_data['vehicle']['revised_idv'] =  $quote_idv_l_limit;
			}

			if($full_quote_data['vehicle']['idv'] > $quote_idv_u_limit ){
				$full_quote_data['vehicle']['idv'] =  $quote_idv_u_limit;
				$full_quote_data['vehicle']['revised_idv'] =  $quote_idv_u_limit;
			}
			return $full_quote_data;
		} else {
			return 'false';
		}
	}

	public function filter_package($packages){
		$packages_filtered = [];
		$default_packages = Car_Constants::TATA_PACKAGES;
		$selected_addon = $this->getSelectedCovers();
		foreach ($packages as $key => $value) {
			foreach ($selected_addon as $key1 => $value1) {
				if((in_array(strtolower($value1), $default_packages[$key]['addon'])) && !in_array($key,$packages_filtered)){
					$packages_filtered[$key] = $key;
				} elseif((!in_array(strtolower($value1), $default_packages[$key]['addon'])) && (in_array($key,$packages_filtered)))  {
					unset($packages_filtered[$key]);
				}
			}
		}
		return !empty($packages_filtered)?$packages_filtered:((empty($selected_addon))?$default_packages:[]);
	}

	private function checkAddon($tata_packages){
		$covers_selected = $this->getSelectedCovers();
 		$ncb_claim_status 	= $this->getNcbStatus();
 		$age 				= $this->getVehicleAge();
 		$model_segment 		= $this->getVehicleSegment();
 		$package_filtered = [];
 		foreach ($tata_packages as $key => $value) {
 			$pack[$key]= $this->{'check_'.$key}($ncb_claim_status, $model_segment, $age);
 		}

 		if(empty($covers_selected)||(empty(array_diff(['PAPASS'], $covers_selected)))){
			if(isset($pack['tata_silver']) && $pack['tata_silver'])
 				$package_filtered =  ['tata_silver' => true];
 		}

 		if(empty(array_diff(['RSAC'], $covers_selected))){
			if(isset($pack['tata_gold']) && $pack['tata_gold'])
 				$package_filtered =  ['tata_gold' => true];
 		}

 		if(empty(array_diff(['ZERODEP'], $covers_selected))){
			if(isset($pack['tata_pearl']) && $pack['tata_pearl'])
 				$package_filtered =  ['tata_pearl' => true];
 		}

 		if((empty(array_diff(['EP'], $covers_selected)))||(empty(array_diff(['ZERODEP','EP'], $covers_selected)))){
			if(isset($pack['tata_pearl_p']) && $pack['tata_pearl_p'])
 				$package_filtered =  ['tata_pearl_p' => true];
 		}

 		if((empty(array_diff(['ZERODEP','RTI'], $covers_selected)))||(empty(array_diff(['RTI'], $covers_selected)))){
			if(isset($pack['tata_sapphire_pp']) && $pack['tata_sapphire_pp'])
 				$package_filtered =  ['tata_sapphire_pp' => true];
 		}

 		return $package_filtered;

	}

	private function check_tata_silver($ncb_claim_status, $model_segment, $age){
		if( $age > 10 ){
			Log::info('CAR - TATA AIG Silver - '.$this->trans_code.' - package is not aplicable as age is greater then 10 Years');
			return false;
		}

		return true;
	}

	private function check_tata_gold($ncb_claim_status, $model_segment, $age){
		if( $age > 10 ){
			Log::info('CAR - TATA AIG GOLD - '.$this->trans_code.' - package is not aplicable as age is greater then 10 Years');
			return false;
		}

		return true;
	}

	private function  check_tata_pearl($ncb_claim_status, $model_segment, $age){
		// if($ncb_claim_status == 'true'  || $age > 5 ){
		if($age > 5){
			if(($age <= 7) && ($ncb_claim_status == 'false')){
				return true;
			} else {
				Log::info('CAR - TATA AIG PEARL - '.$this->trans_code.' -  package is not aplicable as age is greater then 5 Years and less then 7 but ncb is not applicable');
				return false;
			}
		}

		/*
		if(($model_segment == 'High End') || ($model_segment == 'Ultra High End')){
			return false;
		}
		*/
		return true;
	}

	private function  check_tata_pearl_p($ncb_claim_status, $model_segment, $age){
		if($age > 5){
			if(($age <= 7) && ($ncb_claim_status == 'false')){
				return true;
			} else {
				Log::info('CAR - TATA AIG PEARL PLUS - '.$this->trans_code.' -  package is not aplicable as age is greater then 5 Years and less then 7 but ncb is not applicable');
				return false;
			}
		}

		/*
		if(($model_segment == 'High End') || ($model_segment == 'Ultra High End')){
			return false;
		}
		*/
		return true;
	}

	private function  check_tata_sapphire($ncb_claim_status, $model_segment, $age){
		if($age > 5){
			if(($age <= 7) && ($ncb_claim_status == 'false')){
				return true;
			} else {
				Log::info('CAR - TATA AIG SAPPHIRE - '.$this->trans_code.' -  package is not aplicable as age is greater then 5 Years and less then 7 but ncb is not applicable');
				return false;
			}
		}

		return true;
	}

	private function  check_tata_sapphire_p($ncb_claim_status, $model_segment, $age){
		if($age > 5){
			if(($age <= 7) && ($ncb_claim_status == 'false')){
				return true;
			} else {
				Log::info('CAR - TATA AIG SAPPHIRE PLUS - '.$this->trans_code.' -  package is not aplicable as age is greater then 5 Years and less then 7 but ncb is not applicable');
				return false;
			}
		}

		return true;
	}

	private function  check_tata_sapphire_pp($ncb_claim_status, $model_segment, $age){
		if($age > 5 ){
			Log::info('CAR - TATA AIG SAPPHIRE++ - '.$this->trans_code.' -  package is not aplicable as age is greater then 5 Years');
			return false;
		}
		return true;
	}

	private function activateAddon($product_id){
		$this->setAddonNull();
		$selected_addon  = $this->getRequest()['cov'];
		$this->setSelectedCovers($selected_addon);
		$packages = Car_Constants::TATA_PACKAGES;
		$selected_addon = $this->getSelectedCovers();
		if(array_key_exists($product_id, $packages)){
			foreach ($packages[$product_id] as $key1 => $value1) {
				if($key1 == 'package')
					$this->quote_request["vehicle"]['addon_plan_code'] = $value1; //addon_plan_code
				else
					foreach ($value1 as $addon) {
						if($addon == 'papass'){
							if(in_array(strtoupper($addon),$selected_addon)){
								$this->$addon = '1';
							} else {
								$this->$addon = '0';
							}
						} else {
							$this->$addon = '1';
						}
					}
			}
		}
	}

	private function setAddon(){
		$request = $this->getRequest();
		$car_variant = new M \ CarVariant;
		$variant_code = $request['variant_code'];
		/*
			Conditions for addon to be applicable
		*/

		// PA Eligibility
		$pa_eligibility = ($this->pa)?1:0;		

		// No- Claim Bonus Protection Eligibility
		$ncbprotect_eligibility = (($this->getVehicleAge() <= 10) && ($this->quote_request['vehicle']['pp_prev_ncb'] >= 25) && $this->ncbprotect)?1:0;

		// Return to Invoice Eligibility
		$rti_eligibility = ($this->getVehicleAge() <= 5 && $this->rti)?1:0;

		// Engine Secure Eligibility
		$ep_eligibility = ($this->getVehicleAge() <= 7 && $this->ep)?1:0;

		// Depreciation Reimbursement Eligibility
		$zerodep_eligibility = $this->zerodep && (($this->getVehicleAge() <= 5 ) || (($this->getVehicleAge() <= 7) && ($this->getNcbStatus() == 'false')));

		// Consumable Expenses Eligibility
		$cosumable_expenses_eligibility = $this->cosumable_expenses && (($this->getVehicleAge() <= 5 ) || (($this->getVehicleAge() <= 7) && ($this->getNcbStatus() == 'false')));
		
		// RSAC Eligibility
		$rsac_eligibility = ($this->getVehicleAge() <= 7 && $this->rsac)?1:0;

		// Tyre Secure Eligibility
		$ts_eligibility = $this->ts && (($this->getVehicleAge() <= 5 ) || (($this->getVehicleAge() <= 7) && ($this->getNcbStatus() == 'false')));

		// Daily Allowance Eligibility
		$daily_allowance_eligibility	= ($this->getVehicleAge() <= 7 && $this->daily_allowance)?1:0;

		/*
			Conditions for addon to be applicable ends here
		*/

		// Addon tags for TATA AIG assigned below
		// For PA
		/*
		if($pa_eligibility){
			$this->inputxml_raw["PropRisks_CompulsoryPAwithOwnerDriver"] = 'true';
		}
		*/

		//For EP (Engine Protection)
		if($ep_eligibility){
			$this->quote_request['cover']['C44']['opted'] = 'Y';
			// $this->quote_request['cover']['C44']['opted'] = ($this->getVehicleSegment()=='High End')?'Without Deductible':'With Deductible';
		} else {
			$this->quote_request['cover']['C44']['opted'] = 'N';
		}

		//For RSAC
		// add manually 137rs if rsac is selected i.e including tax
		// without tax is 116
		$this->quote_request['cover']['C47']['opted'] = ($rsac_eligibility)?'Y':'N';
				
		//For RTI (Return to invoice)
		$this->quote_request['cover']['C38']['opted'] = ($rti_eligibility)?'Y':'N';

		//For PAPASS
		//C17
		//("opted":"Y","SI":"9999","persons":"3")
		$this->quote_request['cover']['C17']['opted'] = ($this->papass)?'Y':'N';
		if($this->papass){
			$this->quote_request['cover']['C17']['persons'] = $car_variant->getVehicleId($variant_code,'seat_capacity')->seat_capacity;// 5; //seating capacity value
			$this->quote_request['cover']['C17']['SI'] = 100000;  // max 2l 
		}

		//For Zero depreciation
		//C35
		$this->quote_request['cover']['C35']['opted'] = ($zerodep_eligibility)?'Y':'N';
		

		// Loss of Personal Belongings
		//C41
		$this->quote_request['cover']['C41']['opted'] =  ($this->lpb)?'Y':'N';

		// Emergency Hotel & Transportation
		//C42
		$this->quote_request['cover']['C42']['opted'] = ($this->et_hotelexpenses)?'Y':'N';

		// Key Replacement
		// C43
		$this->quote_request['cover']['C43']['opted'] = ($this->keyreplace)?'Y':'N';

		// Daily Allowance
		// C36
		$this->quote_request['cover']['C36']['opted'] = ($daily_allowance_eligibility)?'Y':'N';

		// Tyre Secure
		// C45
		if($ts_eligibility){
			$this->quote_request['cover']['C45']['opted'] =  ($this->ts)?'Y':'N';
		} else {
			$this->quote_request['cover']['C45']['opted'] = 'N';
		}

		// Repair of glass, plastic fibre and rubber glaas
		// C40
		$this->quote_request['cover']['C40']['opted'] =  ($this->repair_of_glass)?'Y':'N';

		//Consumable Expenses
		// C37
		if($cosumable_expenses_eligibility){
			$this->quote_request['cover']['C37']['opted'] =  ($cosumable_expenses_eligibility)?'Y':'N';
		} else {
			$this->quote_request['cover']['C37']['opted'] = 'N';
		}

		// NCBPROTECT
		// 39
		$this->quote_request['cover']['C39']['opted'] = ($ncbprotect_eligibility)?'Y':'N';

		// $this->storeAddon('ncbprotect');  //Not to use now
	}

	private function genrateInputXml(){
		// $car_helper = new H\CarHelper;
		// $this->inputxml 	=	$car_helper->genrateXml('<PrivateCarInsurancePolicy />',$this->inputxml_raw)->asXML();
	}

	private function setAddonNull(){
		$this->zerodep				=	0;
		$this->ep 					=	0;
		$this->rti 					=	0;
		$this->papass 				=	0;
		$this->pa 					=	0;
		$this->ll 					=	0;
		$this->daily_allowance		=	0;
		$this->lpb					=	0;
		$this->et_hotelexpenses		=	0;
		$this->keyreplace			=	0;
		$this->cosumable_expenses	=	0;
		$this->repair_of_glass		=	0;
		$this->ts					=	0;
		$this->ncbprotect			=	0;
		$this->rsac					=	0;
	}

	private function setCarDetails(){
		// dd($this->request);
		$car_make = new M \ CarMake;
		$car_models = new M \ CarModels;
		$car_variant = new M\CarVariant;
		$request = $this->request;
		$make_code = $request['make_code'];
		$model_code = $request['model_code'];
		$variant_code = $request['variant_code'];


		$this->quote_request['vehicle']['make_name'] =  $car_make->getMakeId($make_code,'tata_name');//'MARUTI';
		$this->quote_request['vehicle']['model_name'] = $car_models->getModelId($model_code,'tata_name');//'SWIFT';
		$this->quote_request['vehicle']['variant_name'] = $car_variant->getVehicleId($variant_code,'tata_name')->tata_name; //'ZXI'; 
		
		$this->quote_request['vehicle']['make_code'] = $car_make->getMakeId($make_code,'tata_code');//'96';
		$this->quote_request['vehicle']['model_code'] = $car_models->getModelId($model_code,'tata_code');//'102962';
		$this->quote_request['vehicle']['variant_code'] = $car_variant->getVehicleId($variant_code,'tata_code')->tata_code;//'1108';

		$this->quote_request['vehicle']['sc'] = $car_variant->getVehicleId($variant_code,'seat_capacity')->seat_capacity; //'5';
		$this->quote_request['vehicle']['cc'] = $car_variant->fetchCC($variant_code)->variant_cc; //'1298';
		
		$this->quote_request['vehicle']['fuel_name'] =	$car_variant->fetchFuelType($variant_code); //'Petrol';
		$this->quote_request['vehicle']['fuel_code'] =	$this->getFuelCode($car_variant->fetchFuelType($variant_code)); //'Petrol';

		$this->quote_request['vehicle']['segment_code'] = $this->getVehicleSegmentCode($this->getVehicleSegment());
		$this->quote_request['vehicle']['segment_name'] = $this->getVehicleSegment();
	}

	private function getVehicleSegmentCode($vehicle_segment){
	    try{
		$vehicle_code_matrix =	[
								'Mini' => '1',
								'Compact' => '2',
								'Mid Size' => '3',
								'High End' => '4',
								'MPV SUV' => '5'
							];
		return $vehicle_code_matrix[$vehicle_segment];
	    }catch(\Exception $e){
	        $vehicle_code_matrix['Compact'];
	    }
	}

	private function getFuelCode($fuel_type){
		$fuel_code_matrix = [
								"Petrol" => "1",
								"Diesel" => "2",
								"CNG" => "3",
								"Battery" => "4",
								"External CNG" => "5",
								"External LPG" => "6",
								"Electricity" => "7",
								"Hydrogen" => "8",
								"LPG" => "9"
							];
		return $fuel_code_matrix[$fuel_type];
	}
	private function setClaimStatus(){
		$data = $this->getRequest();
		$prevncb 	= $data['ncb'];
		if (!empty($data['claim']) && $data['claim'] == 'Y') {
			$claimsMadeInPreviousPolicy = 'true';
			$ncbcurrent 	= 0;
			$noClaimBonusPercent = 0;
			$claimsReported = 1;
			$claimAmountReceived = round(($this->idv*5)/100);  // Make 5% of IDV
			$this->setNcbStatus('true');
			// $this->setNcbPercentage();
			$this->quote_request['vehicle']['pp_claim_yn'] =  'Y';
			$this->quote_request['vehicle']['pp_prev_ncb'] =  $prevncb;
			$this->quote_request['vehicle']['pp_curr_ncb'] =  $ncbcurrent;
			// $this->inputxml_raw["PropGeneralProposalInformation_IsNCBApplicable"] = 'false';

			// $this->inputxml_raw["PropPreviousPolicyDetails_ClaimLodgedInPast"] = $claimsMadeInPreviousPolicy;
			// $this->inputxml_raw["PropRisks_NoClaimBonusApplicable"] = $noClaimBonusPercent;
			// $this->inputxml_raw["PropPreviousPolicyDetails_ClaimAmount"] = $claimAmountReceived;

		} else {
			$ncbcurrentArray 	= ['0'=>'20','20'=>'25','25'=>'35','35'=>'45','45'=>'50','50'=>'50'];
			$noClaimBonusPercentArray = ['0'=>1,'20'=>2,'25'=>3,'35'=>4,'45'=>5,'50'=>6];
			$ncbcurrent 		= $ncbcurrentArray[$prevncb];
			$noClaimBonusPercent	= $noClaimBonusPercentArray[$prevncb];
			$this->setNcbStatus('false');
			// $this->setNcbPercentage();
			$this->quote_request['vehicle']['pp_claim_yn'] =  'N';
			$this->quote_request['vehicle']['pp_prev_ncb'] =  $prevncb;
			$this->quote_request['vehicle']['pp_curr_ncb'] =  $ncbcurrent;


			// $this->inputxml_raw["PropRisks_NoClaimBonusApplicable"] = ($this->typeOfBusiness == 'Rollover')?$ncbcurrent:'0';
			// $this->inputxml_raw['PropRisks_EntitledforNCB'] =  'Yes';
			// $this->inputxml_raw["PropGeneralProposalInformation_IsNCBApplicable"] = 'true';
		// $this->inputxml_raw["PropPreviousPolicyDetails_ClaimLodgedInPast"] = 'false';
			// $this->inputxml_raw["PropPreviousPolicyDetails_ClaimAmount"] = '0';
		}

			// $this->inputxml_raw["PropPreviousPolicyDetails_NCBPercentage"] = $prevncb; // Have to ask
	}

	private function setRegisNo(){
		$car_rto = new M\CarRto;
		$rto_location 	= $this->request['rto'];
		$rto_zone		=	$car_rto->getRtoZone($rto_location);
		$rto_authority	=	$car_rto->getRTOData($rto_location,'tata_rto_location')->tata_rto_location;
		$rto_grp_code 	=	$car_rto->getRTOData($rto_location,'tata_grp_code')->tata_grp_code; 
		$rto_num_dummy_value = 'DF6565'; // as we dont have whole rto number at the time of quote calls
		$registartion_no_array = explode('-',$this->car_lib->format_regno($this->request['rto'].$rto_num_dummy_value));
		$this->quote_request['vehicle']['regno_1'] = $registartion_no_array[0];
		$this->quote_request['vehicle']['regno_2'] = $registartion_no_array[1];
		// $this->inputxml_raw["PropRisks_RegistrationNumber3"] = $registartion_no_array[2];
		// $this->inputxml_raw["PropRisks_RegistrationNumber4"] = $registartion_no_array[3];

		// $this->inputxml_raw["PropRisks_CityWherePrimarilyUsed"] = $rto_authority; //'MUMBAI';  // should be according to the rto
		$this->quote_request['vehicle']['rto_loc_code'] = $this->car_lib->format_regno($this->request['rto']);
		$this->quote_request['vehicle']['rto_loc_name'] = $rto_authority; //'Andheri (Mumbai Western Suburbs)'; // RTO location mention as 'TXT_RTO_LOCATION_DESC' in excel
		$this->quote_request['vehicle']["rtolocationgrpcd"] = $rto_grp_code;//'36';
		// $this->inputxml_raw["IsThinCustomer"] = 'false';
		$this->quote_request['vehicle']['rto_zone'] = $rto_zone;

	}

	private function getQuoteRequestData(){
		$tata_manager = new H\TATA\TataQuoteManager;
		$this->quote_request = $tata_manager->getQuoteRequest();
	}

	private function setRequest($request = null){
		$this->request = $request;
	}

	private function getRequest(){
		return $this->request;
	}

	private function setVehicleSegment($variant_code = null){
		$car_variant = new M\CarVariant;
		$this->vehicle_segment = $car_variant->getVehicleId($variant_code,'tata_vehicle_segment')->tata_vehicle_segment;
	}

	private function getVehicleSegment(){
		return $this->vehicle_segment;
	}

	private function setNcbStatus($ncb = null){
		$this->ncb_status = $ncb;
	}

	private function getNcbStatus(){
		return $this->ncb_status;
	}

	private function calculateDate(){
		$data = $this->getRequest();
		$carregistration_diff = $this->carcfgobj->getValue(Car_Constants::CAR_REGIS_DATE_DIFF)[0]['config_value'];
	    $policyenddate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_E_DATE_DIFF)[0]['config_value'];
	    $policystartdate_diff = $this->carcfgobj->getValue(Car_Constants::POLICY_S_DATE_DIFF)[0]['config_value'];
	    $yor_select_start = $this->carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$date = Carbon::now();
		$this->current_date = $date;
		if(!empty($data['car_registration_date'])){
			$registartiondate = Carbon::parse(str_replace('/','-',$data['car_registration_date']));
			$regDate = $registartiondate;
			$registartionyear = $registartiondate->year;

		} else {
			$registartiondate = Carbon::now();
			$registartiondate->year = $data['year'];
			$regDate = $registartiondate->addDays($carregistration_diff);
			$registartionyear = $registartiondate->year;
		}

		if(!empty($data['policyStartDate'])){
			$policyDate = Carbon::parse(str_replace('/','-',$data['policyStartDate']));
			$policyStartDate = $policyDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyStartDate)));
		} else {
			$policyStartDate = Carbon::now();
			$policyStartDate->year =$data['year'];
			$policyStartDate = $policyStartDate->addDays($policystartdate_diff);
		}

		if(!empty($data['policyExpiryDate'])){
			$policyEDate = Carbon::parse(str_replace('/','-',$data['policyExpiryDate']));
			$policyExpiryDate = $policyEDate->format('Y-m-d');//date('Y-m-d',strtotime(str_replace('/','-',$policyExpiryDate)));
		} else {
			$policyExpiryDate = Carbon::now();
			$policyExpiryDate = $policyExpiryDate->addDays($policyenddate_diff);
		}
		$typeOfBusiness = $registartionyear < $yor_select_start ? 'Roll Over' :  'New Business';
		$newdate = Carbon::parse($policyExpiryDate);
		if($typeOfBusiness === 'Roll Over')
			$policyStartDate = $newdate->addDays($policystartdate_diff);
	 	else 
			$regDate = $newdate->addDays(-1);
		$this->setpolicyStartDate($policyStartDate);
		$this->setTypeOfBusiness($typeOfBusiness);
		$this->setRegistartionyear($registartionyear);
		$this->setRegistartionDate($regDate);
		$this->setPolicyExpiryDate($policyExpiryDate);

		// $this->typeOfBusiness	=	$typeOfBusiness;
		// $this->registartionyear =	$registartionyear;
		// $this->registrationdate =	$regDate;
		// $this->policyExpiryDate =	$policyExpiryDate;
		// $this->policyStartDate 	=	$policyStartDate;
	}

	private function setIdvData(){
		$data = $this->request;
		$variant_code = $this->request['variant_code'];
		$registartionyear	=	$this->registartionyear;
		$carvariant = new M\CarVariant;
		$price = $carvariant->getPrice($variant_code);
		$idv_values = $this->getIDV($registartionyear,$variant_code);

		$this->calculateIDV($price,$this->registartionyear);
		if(!empty($data['idv']))
		{
			$idv_values = $this->getIdv();
			$new_idv_values = $this->checkIDV($data['idv'],$idv_values,$registartionyear);
			// $this->inputxml_raw["PropRisks_IDVofthevehicle"] = $new_idv_values;
			$this->setIdv($new_idv_values);
		} else {
			/* Below are the default values as per the selected car and year */
			// $this->inputxml_raw["PropRisks_IDVofthevehicle"] = $this->idv;
			$this->setIdv($idv);
		}
	}

	private function calculateIDV($price,$reg_year){
		$policyStartDate = Carbon::parse($this->getPolicyStartDate());
		$carRegistrationDate = Carbon::parse($this->getRegistartionDate());
		
		$d1 = date($policyStartDate);
		$d2 = date($carRegistrationDate);
		$n = $carRegistrationDate->diffInMonths($policyStartDate)/12;
		$whole = floor($n);      
		$decimal = $n - $whole; 
		if($decimal < 0.75){
			$age = $whole;
		} else {
			$age = $whole + 1;
		}
		switch($age){
			case 0: $percantage = "95"; $ncbp=0; break;
			case 1: $percantage = "85"; $ncbp=0; break;
			case 2: $percantage = "80"; $ncbp=20; break;
			case 3: $percantage = "70"; $ncbp=25; break;
			case 4: $percantage = "60"; $ncbp=35; break;
			case 5: $percantage = "50"; $ncbp=45; break;
			case 6: $percantage = "45"; $ncbp=50; break;
			default: $percantage = "40"; $ncbp=50;
		}

		$idv = round(($price * $percantage)/100);
		$this->setIdv($idv);
		$this->setVehicleAge($age);
	}

	public function checkIDV($selected_idv,$actualIDV,$reg_year){
		$idv_variant = $this->carcfgobj->getValue(Car_Constants::IDV_VARIANT_PERCENTAGE)[0]['config_value'];
		$tata_least_deviation = -10;
		$diff_idv_percentage = ((($selected_idv - $actualIDV)/$actualIDV)*100);
		$unsigned_diff_idv_percentage = abs($diff_idv_percentage);

		if($diff_idv_percentage < $tata_least_deviation){
			$idv = $actualIDV - (($actualIDV*10)/100);
		} else {
			$idv =	($unsigned_diff_idv_percentage<$idv_variant) ? $selected_idv : (($diff_idv_percentage<0) ?  ($actualIDV - (($actualIDV*$idv_variant)/100)) : ($actualIDV + (($actualIDV*$idv_variant)/100)));
		}
		return $idv;
	}

	public function setSelectedCovers($covers) {
        $chks = isset($covers)? $covers : Car_Constants::DEFAULT_COVER_SELECTED;
        $addons = explode(",", $chks);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        $this->selectedAddon = $addons;
    }

    private function getSelectedCovers(){
    	return $this->selectedAddon;
    }

    private function setVehicleAge($age = null){
		$this->age = $age;
		// $this->inputxml_raw["PropRisks_VehicleAge_Mandatary"] = $this->age;
	}

	private function getVehicleAge(){
		return $this->age;
	}



    /**
     * @return mixed
     */
    public function getTypeOfBusiness()
    {
        return $this->typeOfBusiness;
    }

    /**
     * @param mixed $typeOfBusiness
     *
     * @return self
     */
    public function setTypeOfBusiness($typeOfBusiness)
    {
        $this->typeOfBusiness = $typeOfBusiness;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPolicyStartDate()
    {
        return $this->policyStartDate;
    }

    /**
     * @param mixed $policyStartDate
     *
     * @return self
     */
    public function setPolicyStartDate($policyStartDate)
    {
        $this->policyStartDate = $policyStartDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRegistartionyear()
    {
        return $this->registartionyear;
    }

    /**
     * @param mixed $registartionyear
     *
     * @return self
     */
    public function setRegistartionyear($registartionyear)
    {
        $this->registartionyear = $registartionyear;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPolicyExpiryDate()
    {
        return $this->policyExpiryDate;
    }

    /**
     * @param mixed $policyExpiryDate
     *
     * @return self
     */
    public function setPolicyExpiryDate($policyExpiryDate)
    {
        $this->policyExpiryDate = $policyExpiryDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRegistartionDate()
    {
        return $this->registartionDate;
    }

    /**
     * @param mixed $registartionDate
     *
     * @return self
     */
    public function setRegistartionDate($registartionDate)
    {
        $this->registartionDate = $registartionDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIdv()
    {
        return $this->idv;
    }

    /**
     * @param mixed $idv
     *
     * @return self
     */
    public function setIdv($idv)
    {
        $this->idv = $idv;

        return $this;
    }
}
?>
