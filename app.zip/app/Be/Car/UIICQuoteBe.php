<?php

namespace App\Be\Car;

use App\Be\Car as BE;
use App\Models\Car as M;
use App\Helpers\Car as H;
use Carbon\Carbon;
use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use Illuminate\Support\Facades\Log;
use App\Be\Common\GstBe;

class UIICQuoteBe {

    private static $vehichle_idv_rules = ['0' => 95
        , '1' => 85
        , '2' => 80
        , '3' => 70
        , '4' => 60
        , '5' => 50
        , '6' => 45
        , '7' => 41
        , '8' => 36
        , '9' => 33
        , '10' => 30];
    private static $invoice_rate = [1 => 15
        , 2 => 20
        , 3 => 25];
    private static $zero_dep_rate = [1 => 10
        , 2 => 20
        , 5 => 30];
    private static $trafic_od_rate = [1 => [1 => [1 => 3.127
                , 2 => 3.283
                , 3 => 3.362]
            , 2 => [1 => 3.283
                , 2 => 3.447
                , 3 => 3.529]
            , 3 => [1 => 3.44
                , 2 => 3.612
                , 3 => 3.698]
        ],
        2 => [1 => [1 => 3.039
                , 2 => 3.191
                , 3 => 3.267]
            , 2 => [1 => 3.191
                , 2 => 3.351
                , 3 => 3.43]
            , 3 => [1 => 3.343
                , 2 => 3.51
                , 3 => 3.594]
        ]
    ];

    private static $long_term_od_rate = [ 1 =>  [1 => 6.442
                , 2 => 6.763
                , 3 => 7.086],
        2 =>  [1 => 6.260
                , 2 => 6.573
                , 3 => 6.886]
    ];

    private static $basic_tp_premium = [1 => 5286
        , 2 => 9534
        , 3 => 24305];
    private static $PAOD_premium = 1815
            ,$PAOD_roll_premium = 750
            , $driver_cover_premium = 50
            , $bi_fuel_tp_kit_premium = 60
            , $GST = 18
            , $STrate = 18
            , $OD_RATE = 30
            ,$PA_COVER_VALUE = 100000;

    public $data = array();
    public $enable = [];

    public function __construct() {
	   $this->vendor_gst_code = Car_Constants::UIIC_GST_CODE;
       
        $this->enable['discount'] = ['od' => 1
            , 'vd' => 0
            , 'aad' => 0
            , 'atd' => 0
            , 'ncbd' => 1];

        $this->enable['premium'] = ['RTI' => 0,
            'ZERODEP' => 0,
            'EA' => 0,
            'NEA' => 0,
            'BFK_TP' => 0,
            'PA' => 1,
            'PAPASS' => 0,
            'LL' => 0];
      
    }
    
    
        public function pre_quote_check($idv_data){
        $status = true;
        $state_code = $idv_data['rto'];
        $state_code = substr($state_code,0,2);
        if($state_code != 'KA')
            $status = false;
        unset($state_code);
        return $status;
    }

    

    public function setBasicDetails($data){
        $this->rto_zone = $data['rto_zone'];
        $this->cc = $data['vehicle_cc'];
        $this->price = $data['price'];
        $this->seating_capacity = $data['seating_capacity'];
        $this->cust_gst_code = $data['cust_gst_code'];
        $this->policy_type_selection = $data['policy_type_selection'];
        $this->type_of_business = $data['type_of_business'];
        self::setpolicyStartDate('policyStartDate',$data['policy_start_date']);
        self::setCarRegistrationDate('registartiondate',$data['registartion_date']);
        $this->setNCB($data['new_ncb']);
    }

    public function enableAddon($key) {
        $this->enable['premium'][$key] = 1;
    }

    public function disableAddon($key) {
        $this->enable['premium'][$key] = 0;
    }

    public function isEnableAddon($key) {
        if (isset($this->enable['premium'][$key])) {
            if ($this->enable['premium'][$key])
                return true;
            else
                return false;
        } else {
            Log::error('CAR - UIIC - Declare Addon ' . $key);
            return false;
        }
    }

    public function __set($key, $value) {
        ////Log::info($key);
        $this->data[$key] = $value;
    }

    public function __get($key) {
    	// if(is_array($this->data[$key]))
     //    	//Log::info($key .' = '.json_encode($this->data[$key]));
     //    else 
     //    	//Log::info($key .' = '.$this->data[$key]);
        return $this->data[$key];
    }

    public function __isset($name) {
        return isset($this->data[$name]);
    }

    //Logs 
    public function __call($method, $arguments) {
        if (method_exists($this, $method)) {
            //Log::info($method);
            return call_user_func_array(array($this, $method), $arguments);
        } else {
            //Log::info($method);
        }
    }

    private function setNCB($ncb) {
        $this->new_ncb = $ncb;
    }

    public function getTotalPremium() {
        if (!isset($this->premium))
            $this->premium = $this->getPremium();

        if (!isset($this->service_tax))
            $this->service_tax = $this->getServiceTax();

        $this->total_premium = round($this->premium + $this->service_tax,0);
        return $this->total_premium;
    }

    private function getPremium() {
        if (!isset($this->totoal_od_premium))
            $this->totoal_od_premium = $this->getTotalODPremium();

        if (!isset($this->totoal_tp_premium))
            $this->totoal_tp_premium = $this->getTotalTPPremium();

        if (!isset($this->totoal_addOn_premium))
            $this->totoal_addOn_premium = $this->getTotalAddOnPremium();

        return round(($this->totoal_od_premium + $this->totoal_tp_premium + $this->totoal_addOn_premium),0);
    }

    private function getServiceTax() {
        if (!isset($this->premium))
            $this->premium = $this->getPremium();

        $gstBe = new GstBe();
        $gstData = $gstBe->get_gst_values($this->vendor_gst_code,$this->cust_gst_code,$this->premium);
        return $gstData->get_total_tax();
        //return round(($this->premium * self::$STrate) / 100,0);
    }

    // total premium
    private function getTotalODPremium() {
        // premium
        if (!isset($this->od_premium))
            $this->od_premium = $this->getODPremium();

        if (!isset($this->ea_premium))
            $this->ea_premium = $this->getEAPremium();

        if (!isset($this->nea_premium))
            $this->nea_premium = $this->getNEAPremium();

        // discount
        if (!isset($this->anti_theft_discount))
            $this->anti_theft_discount = $this->getAntiTheftDiscount();

        if (!isset($this->auto_ass_discount))
            $this->auto_ass_discount = $this->getAutomobileAssociationDiscount();

        if (!isset($this->voluntary_discount))
            $this->voluntary_discount = $this->getVoluntaryDeductibleDiscount();

        if (!isset($this->ncb_discount))
            $this->ncb_discount = $this->getNoClaimBonusDiscount();

        if (!isset($this->od_discount))
            $this->od_discount = $this->getODDiscount();

        return round((($this->od_premium + $this->ea_premium + $this->nea_premium
                ) - ($this->ncb_discount + $this->anti_theft_discount + $this->auto_ass_discount + $this->voluntary_discount + $this->od_discount)
                ),0);
    }

    private function getTotalTPPremium() {
        if (!isset($this->tp_premium))
            $this->tp_premium = $this->getTPPremium();

        if (!isset($this->bi_fuel_kit_tp_premium))
            $this->bi_fuel_kit_tp_premium = $this->getBiFuelKitTPPremium();

        if (!isset($this->PAOD_premium))
            $this->PAOD_premium = $this->getPAODPremium();

        if (!isset($this->driver_cover_premium))
            $this->driver_cover_premium = $this->getDriverCoverPremium();

        if (!isset($this->pa_cover_premium))
            $this->pa_cover_premium = $this->getPassengerCoverPremium();

        return round(($this->tp_premium + $this->bi_fuel_kit_tp_premium + $this->PAOD_premium + $this->driver_cover_premium + $this->pa_cover_premium),0);
    }

    private function getTotalAddOnPremium() {
        if (!isset($this->zerodep_premium))
            $this->zerodep_premium = $this->getZeroDepPremium();

        if (!isset($this->rti_premium))
            $this->rti_premium = $this->getReturnToInvoicePremium();

        return round($this->zerodep_premium + $this->rti_premium,0);
    }

    // Premium  
    private function getReturnToInvoicePremium() {
        if (!$this->enable['premium']['RTI'])
            return 0;

        if (!isset($this->invoice_rate))
            $this->invoice_rate = self::getReturnToInvoiceRate();

        if (!isset($this->od_premium))
            $this->od_premium = $this->getODPremium();

        if (!isset($this->eloctronic_ass_idv))
            $this->eloctronic_ass_idv = self::getEAIDV();

        if (!isset($this->non_eloctronic_ass_idv))
            $this->non_eloctronic_ass_idv = selF::getNEAIDV();

        if ($this->invoice_rate) {
            return round((($this->invoice_rate * ($this->od_premium + $this->eloctronic_ass_idv + $this->non_eloctronic_ass_idv)) / 100),0);
        }

        return 0;
    }

    private function getZeroDepPremium() {
        if (!$this->enable['premium']['ZERODEP'])
            return 0;

        if (!isset($this->zero_dep_rate))
            $this->zero_dep_rate  =  ($this->policy_type_selection == '3') ? 21 : self::getZeroDepRate(); 

        if (!isset($this->od_premium))
            $this->od_premium = $this->getODPremium();

        if (!isset($this->ea_premium))
            $this->ea_premium = $this->getEAPremium();

        if (!isset($this->nea_premium))
            $this->nea_premium = $this->getNEAPremium();

        if ($this->zero_dep_rate) {
            return round(($this->zero_dep_rate * ($this->od_premium + $this->ea_premium + $this->nea_premium)) / 100);
        }
        return 0;
    }

    private function getODPremium() {
        if (!isset($this->age))
            $this->age = self::getVehicleAge();

        if (!isset($this->trafic_od))
            $this->trafic_od = $this->getTariffODRate($this->age, $this->rto_zone, $this->cc);

        if (!isset($this->vehicle_idv))
            $this->vehicle_idv = self::getVehicleIDV($this->price);

        if ($this->trafic_od && $this->vehicle_idv)
            return round(($this->trafic_od * $this->vehicle_idv) / 100,0);
        else
            return 0;
    }

    private function getEAPremium() {
        if (!$this->enable['premium']['EA'])
            return 0;

        if(isset($this->elect_ass_idv))
            return round(($this->elect_ass_idv * 4)/100,0);
        else 
            //Log::error("Electric Ass Idv Is not Set 'elect_ass_idv'");

        return 0;
    }

    private function getNEAPremium() {
        if (!$this->enable['premium']['NEA'])
            return 0;

        if (!isset($this->age))
            $this->age = self::getVehicleAge();
        
        if (!isset($this->trafic_od))
            $this->trafic_od = $this->getTariffODRate($this->age, $this->rto_zone, $this->cc);

        if(isset($this->nonelect_ass_idv))
            return round(($this->nonelect_ass_idv * $this->trafic_od)/100,0);
        else 
            //Log::error("NonElectric Ass Idv Is not Set 'nonelect_ass_idv'");

        return 0;
    }

    private function getBiFuelKitODPremium() {
        return 0;
    }

    private function getBiFuelKitTPPremium() {
        if (!$this->enable['premium']['BFK_TP'])
            return 0;
        return self::$bi_fuel_tp_kit_premium;
    }

    private function getTPPremium() {
        if ($this->cc <= 1000)
            return self::$basic_tp_premium[1];
        else if ($this->cc <= 1500)
            return self::$basic_tp_premium[2];
        else
            return self::$basic_tp_premium[3];
    }

    private function getPAODPremium() {
        if (!$this->enable['premium']['PA'])
            return 0;

        if($this->type_of_business == 'Rollover')
            return self::$PAOD_roll_premium;
        
        return self::$PAOD_premium;
    }

    private function getPassengerCoverPremium() {
        if (!$this->enable['premium']['PAPASS'])
            return 0;
        return round((self::$PA_COVER_VALUE * $this->seating_capacity * 0.0005));
    }

    private function getDriverCoverPremium() {
        if (!$this->enable['premium']['LL'])
            return 0;
        return self::$driver_cover_premium;
    }

    // dicounts
    private function getNoClaimBonusDiscount() {
        if (!$this->enable['discount']['ncbd'])
            return 0;

        if (!isset($this->ncb_premium_grp))
            $this->ncb_premium_grp = $this->getNCBPremiumGrp();
        // dd($this->ncb_premium_grp,$this->new_ncb);
        return round(($this->ncb_premium_grp * $this->new_ncb) / 100);
    }

    private function getAntiTheftDiscount() {
        if (!$this->enable['discount']['atd'])
            return 0;
        return 0;
    }

    private function getAutomobileAssociationDiscount() {
        if (!$this->enable['discount']['aad'])
            return 0;
        return 0;
    }

    private function getVoluntaryDeductibleDiscount() {
        if (!$this->enable['discount']['vd'])
            return 0;

        return 0;
    }

    private function getODDiscount() {
        if (!$this->enable['discount']['od'])
            return 0;

        if (!isset($this->od_premium))
            $this->od_premium = $this->getODPremium();

        if (!isset($this->nea_premium))
            $this->nea_premium = $this->getNEAPremium();

        return round((($this->od_premium + $this->nea_premium) * self::$OD_RATE) / 100);
    }

    private function getNCBPremiumGrp() {
        // all premium
        if (!isset($this->od_premium))
            $this->od_premium = $this->getODPremium();

        if (!isset($this->ea_premium))
            $this->ea_premium = $this->getEAPremium();

        if (!isset($this->nea_premium))
            $this->nea_premium = $this->getNEAPremium();

        if (!isset($this->bi_fuel_kit_od_premium))
            $this->bi_fuel_kit_od_premium = $this->getBiFuelKitODPremium();

        if (!isset($this->zerodep_premium))
            $this->zerodep_premium = $this->getZeroDepPremium();

        if (!isset($this->rti_premium))
            $this->rti_premium = $this->getReturnToInvoicePremium();

        // all disount
        if (!isset($this->od_discount))
            $this->od_discount = $this->getODDiscount();

        if (!isset($this->anti_theft_discount))
            $this->anti_theft_discount = $this->getAntiTheftDiscount();

        if (!isset($this->auto_ass_discount))
            $this->auto_ass_discount = $this->getAutomobileAssociationDiscount();

        if (!isset($this->voluntary_discount))
            $this->voluntary_discount = $this->getVoluntaryDeductibleDiscount();

        return (($this->od_premium + $this->ea_premium + $this->nea_premium + $this->bi_fuel_kit_od_premium + $this->zerodep_premium + $this->rti_premium) - ($this->od_discount + $this->anti_theft_discount + $this->auto_ass_discount + $this->voluntary_discount));
    }

    private function getTariffODRate($age, $rto_zone, $cc) {
        $rto_zone_index = 0;
        $cc_index = 0;
        $age_index = 0;

        // set rto zone index 
        if (strtolower($rto_zone) == 'a')
            $rto_zone_index = 1;
        else if (strtolower($rto_zone) == 'b')
            $rto_zone_index = 2;

        // set cc index 
        if ($cc <= 1000)
            $cc_index = 1;
        else if ($cc <= 1500)
            $cc_index = 2;
        else
            $cc_index = 3;

        // set age 
        if ($age <= 5)
            $age_index = 1;
        else if ($age <= 10)
            $age_index = 2;
        else
            $age_index = 3;

        if($this->policy_type_selection == '3')
            return self::$long_term_od_rate[$rto_zone_index][$cc_index];

        if (isset(self::$trafic_od_rate[$rto_zone_index]))
            return self::$trafic_od_rate[$rto_zone_index][$cc_index][$age_index];
        else
            //Log::error('RTO zone not match for calculate TrafficODRate');

        return 0;
    }

    private static function getZeroDepRate() {
        $age = self::getVehicleAge();
        foreach (self::$zero_dep_rate as $key => $value) {
            if ($age < $key)
                return self::$zero_dep_rate[$key];
        }
        return 0;
    }

    private static function getVehicleIDV($price) {
        //Log::info('vehicle_idv');

        $age = self::getVehicleAge();
        // return $age <= 6
        $age_list = explode('.', $age);
        if (isset($age_list[1]))
            if ($age_list[0] == 0 && $age_list[1] <= 6)
                return self::getPercantage($price, self::$vehichle_idv_rules[0]);

        // return if $age >= 6 or <=10
        foreach (self::$vehichle_idv_rules as $key => $value) {
            if ($age <= $key)
                return self::getPercantage($price, self::$vehichle_idv_rules[$key]);
        }
        // return if $age > 10
        if ($age >= 10)
            return self::getPercantage($price, self::$vehichle_idv_rules[10]);
    }

    private static function getEAIDV() {
        return 0;
    }

    private static function getNEAIDV() {
        return 0;
    }

    private static function getPercantage($a, $b) {
        return round(($a * $b) / 100);
    }

    private static function getReturnToInvoiceRate() {
        $age = self::getVehicleAge();
        foreach (self::$invoice_rate as $key => $value) {
            if ($age <= $key)
                return $value;
        }
        return 0;
    }

    private static function getVehicleAge() {
        $policyStartDate = self::getpolicyStartDate('policyStartDate');
        $carRegistrationDate = self::getCarRegistrationDate('registartiondate');
        $d1 = new \DateTime($policyStartDate);
        $d2 = new \DateTime($carRegistrationDate);
        $interval  = $d2->diff($d1)->y;
        // return round(($interval->m + 12 * $interval->y) / 12, 1);
        return $interval;
    }

    private static function getpolicyStartDate($property) {
        return session($property);
    }

    private static function getCarRegistrationDate($property) {
        return session($property);
    }

    private static function setpolicyStartDate($property, $val) {
        session([$property => $val]);
    }

    private static function setCarRegistrationDate($property, $val) {
        session([$property => $val]);
    }

}

?>
