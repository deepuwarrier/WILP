<?php
namespace App\Be\Common;

use App\Models\Base\UserMasterM;
use Hash;

class AuthBe {
	
	public function validate_login($auth_params) {
		$auth_return = "NA";
		$user_db = new UserMasterM();
		
		try{
		$user_data = $user_db->user_by_phone ($auth_params["usr_phone"]);
		
		if ($user_data) { 
			$hashedPassword = $user_data->password; 
			if (Hash::check($auth_params["usr_pwd"], $hashedPassword)) {
				if ($user_data->user_type == "1") {
					session([
							"user_code" =>$user_data->user_code,
							"user_email" =>$user_data->email,
							"user_name" =>$user_data->name,
							"user_role" => "_ADMIN"
					]);
					$auth_return = "ADMIN";
				} else if ( $user_data->user_type= "3") {
					session([
							"user_code" =>$user_data->user_code,
							"user_email" =>$user_data->email,
							"user_name" =>$user_data->name,
							"user_role" => "_AGENT"
					]);
					$auth_return = "AGENT";
				} 
			} 
		}
		}catch (\Exception $ex){}	
		return $auth_return;
	}
	
	public function execute_logout() {
// 		session([
// 				"user_code" =>null,
// 				"user_email" =>null,
// 				"user_name" =>null,
// 				"user_role" => null
// 		]);
 		\Auth::logout();
		\Session::flush();
	}

	public static function changePassword($value){
		$user_db = new UserMasterM();
        $user_id = session('user_code');
        // dd($user_id);
        $old_password = $value->old_password;
        $new_password = $value->new_password;
        $confirm_password = $value->confirm_password;
        $user_password_details = $user_db->where('user_code', $user_id)->first();
            
        if($user_password_details){
            $hashedPassword = $user_password_details->password;
            if (Hash::check($old_password, $hashedPassword)) {
                if($new_password === $confirm_password){
                    $user_db->where('user_code', $user_id)->update(['password' => Hash::make($new_password)]);
                    return '1';
                } else {
                    return '2'; // New password and old password doesnot match
                }
                
            } else
            {
                return '0'; // Old password doesnot match
            }
        } else {
        	return '5';
        }
    }
	

}
	
