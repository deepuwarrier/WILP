<?php
namespace App\Be\Common;

 class BrokerageBe {
 	
	public function calc_brokerage($policy_type, $od_value =0, $tp_value = 0){  
		$brokerage =array("brokerage_rate" => 0, "brokerage_value" => 0);
		switch ($policy_type){
			case "C":
				$brokerage["brokerage_rate"]= 15;
				$brokerage["brokerage_value"]= round($od_value * 0.15);
				break;
			case "TP":
				$brokerage["brokerage_rate"]= 5;
				$brokerage["brokerage_value"]= round($tp_value * 0.05);
				break;
		}
		return $brokerage;
	}//
	


 } // end of class
 
 
