<?php

namespace App\Be\Common;

class GstBe {
	
	public function get_gst_values( $vendor_state_code, $customer_state_code, $principal_value, $round_off_flag = true ) {
    $resp_ob = new GstData();
    if($vendor_state_code == $customer_state_code) {
      $resp_ob->set_active_tax("SGSTCGST");
      $resp_ob->set_sgst_rate(9);
      if($round_off_flag){
        $resp_ob->set_sgst_value(round(($principal_value * 9)/100 ));
      }else{
        $resp_ob->set_sgst_value(($principal_value * 9)/100 );
      }
      $resp_ob->set_cgst_rate(9);
      if($round_off_flag){
      $resp_ob->set_cgst_value(round(($principal_value * 9)/100 ));
      }else{
        $resp_ob->set_cgst_value(($principal_value * 9)/100 );
      }
      $resp_ob->set_total_tax($resp_ob->get_sgst_value() + $resp_ob->get_cgst_value());
      
    } else{
      $resp_ob->set_active_tax("IGST");
      $resp_ob->set_igst_rate(18);
      if($round_off_flag){
      $resp_ob->set_igst_value(round(($principal_value * 18)/100 ));
      }else{
        $resp_ob->set_igst_value(($principal_value * 18)/100 );
      }
      $resp_ob->set_total_tax($resp_ob->get_igst_value());
    }     
    return $resp_ob;
  } // end fo method
    
} // end of class

class GstData {
	private $_sgst_rate = 0;
	private $_cgst_rate = 0;
	private $_sgst_value = 0;
	private $_cgst_value = 0;
	private $_ugst_rate = 0;
	private $_ugst_value = 0;
	private $_igst_rate = 0;
	private $_igst_value = 0;
	private $_active_tax = null;
	private $_total_tax = 0;

  public function get_sgst_rate(){
    return $this->_sgst_rate;
  }

  public function set_sgst_rate($_sgst_rate){
    $this->_sgst_rate = $_sgst_rate;
  }

  public function get_cgst_rate(){
    return $this->_cgst_rate;
  }

  public function set_cgst_rate($_cgst_rate){
    $this->_cgst_rate = $_cgst_rate;
  }

  public function get_sgst_value(){
    return $this->_sgst_value;
  }

  public function set_sgst_value($_sgst_value){
    $this->_sgst_value = $_sgst_value;
  }

  public function get_cgst_value(){
    return $this->_cgst_value;
  }

  public function set_cgst_value($_cgst_value){
    $this->_cgst_value = $_cgst_value;
  }

  public function get_ugst_rate(){
    return $this->_ugst_rate;
  }

  public function set_ugst_rate($_ugst_rate){
    $this->_ugst_rate = $_ugst_rate;
  }

  public function get_ugst_value(){
    return $this->_ugst_value;
  }

  public function set_ugst_value($_ugst_value){
    $this->_ugst_value = $_ugst_value;
  }

  public function get_igst_rate(){
    return $this->_igst_rate;
  }

  public function set_igst_rate($_igst_rate){
    $this->_igst_rate = $_igst_rate;
  }

  public function get_igst_value(){
    return $this->_igst_value;
  }

  public function set_igst_value($_igst_value){
    $this->_igst_value = $_igst_value;
  }

  public function get_active_tax(){
    return $this->_active_tax;
  }

  public function set_active_tax($_active_tax){
    $this->_active_tax = $_active_tax;
  }


  public function get_total_tax(){
    return $this->_total_tax;
  }

  public function set_total_tax($_total_tax){
    $this->_total_tax = $_total_tax;
  }

}
	
