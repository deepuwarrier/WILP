<?php
namespace App\Be\Common;

use App\Models\Base\UserMasterM;
use App\Models\Car\CarTData;
use Hash;

class PaymentParseBE {
	public function setPaymentIdentifier($trans_code,$unique_value = null){
        if(is_null($unique_value)){
            session([$trans_code => $trans_code]);
        } else {
            session([$trans_code => $unique_value]);
        }
    }


    public function getPaymentIdentifier($unique_value){
        $session = session()->all();
        return array_search($unique_value, $session);
    }
}