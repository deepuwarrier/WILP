<?php
namespace App\Be\Emails;

Class CommonEmails{

	public function email_quote_data_internal($data){
		return $data;
	}

	public function email_quote_data_external($data){
		// dd($data);
		return $data;
	}
	
}