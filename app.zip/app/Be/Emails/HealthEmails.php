<?php
namespace App\Be\Emails;

use App\Helpers\Health\InsurerData;

class HealthEmails {

	public function proposal_submit_data_internal($trans_data){ 
		$master_db = new InsurerData();  
		$mail_data =  array(
			"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"", "final_premium"=>""
		);
			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("insurer_url", $trans_data['insurerId']) . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Proposal Submit";
			$mail_data["proposer_name"] = $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		return $mail_data;
	}	
	
	public function proposal_submit_data_external($trans_data) {
		
		$mail_data =  array(
			"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"", "final_premium"=>"",
		);
		return $mail_data;
	}
	
	public function proposal_error_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"", "final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("insurer_url", $trans_data['insurerId']) . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Proposal Error";
			$mail_data["proposer_name"] = $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		}catch (\Exception $ex){}
		return $mail_data;
	}	
	
	public function proposal_error_data_external($trans_data) {
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"", "final_premium"=>"",
		);
		return $mail_data;
	}
	
	public function payment_success_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] =  $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["trans_status"] = "Payment Success";
			$mail_data["proposer_name"] =  $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		}catch (\Exception $ex){}
		return $mail_data;
	}
	
	public function payment_success_data_external($trans_data){
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>"",
		);
		return $mail_data;
	}
	
	public function payment_failed_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("insurer_url", $trans_data['insurerId']) . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Payment Failed";
			$mail_data["proposer_name"] = $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		}catch (\Exception $ex){}
		return $mail_data;
	}

	public function payment_failed_data_external($trans_data){
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>"",
		);
		return $mail_data;
	}



	public function policy_success_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] =  $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["trans_status"] = "Policy Purchased.";
			$mail_data["proposer_name"] =  $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		}catch (\Exception $ex){}
		return $mail_data;
	}
	
	public function policy_success_data_external($trans_data){
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>"",
		);
		return $mail_data;
	}
	
	public function policy_failed_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("insurer_url", $trans_data['insurerId']) . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Policy Failed";
			$mail_data["proposer_name"] = $this->get_proposer_name($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["comm_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("insurer_name", $trans_data['insurerId']);
			$mail_data["product_name"] = $trans_data['productName'];
			$mail_data["policy_exp_date"] = $trans_data['policy_exp_date'];
			$mail_data["policy_start_date"] = $trans_data['policy_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $trans_data['totalPremium'];
			if($trans_data['product_type'] == "S"){
				$mail_data["deductables"] = $trans_data['deductables'];
			}
		}catch (\Exception $ex){}
		return $mail_data;
	}

	public function policy_failed_data_external($trans_data){
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","comm_address"=>"","insurer_name"=>"","product_name"=>"","policy_exp_date"=>"","policy_start_date"=>"","sum_insured"=>"", "deductables" =>"","final_premium"=>"",
		);
		return $mail_data;
	}

	public function email_quote_data_internal($trans_data){
		
	}
	
	public function email_quote_data_external($trans_data){
		
	}
	
	private function get_proposer_name ($trans_data) {
		$first_name = explode('|', $trans_data['firstname']); 
		$last_name = explode('|', $trans_data['lastname']); 
		$proposer_name = $first_name[0].' '.$last_name[0];
		return $proposer_name; 
	}

	private function get_comm_addr ($trans_data) {
	$ret_txt = "";
	$master_data = new InsurerData();
	try{
		$ret_txt =  	$trans_data['house_num']
					.", ".	$trans_data['street']
					.", ".	$trans_data['locality']
					.", ".	 $master_data->insr_city("city_name", $trans_data['city'], true) 
					.", ".	$master_data->insr_state("state_name", $trans_data['state'], true)
					.", ".	$trans_data['cust_pincode'];
	}catch (\Exception $ex){}
	return $ret_txt;
	}
	
	private function site_url(){  
		return url('/') . "/health-insurance/";
	}
	
} // end of class
