<?php
namespace App\Be\Emails;

use App\Models\Car\Data\MasterData;

class PcEmails {

	private $_trans_status = ["TS14"=>"Proposal Submit",
		"TS20"=>"Proposal Submit",
		"TS01"=>"Proposal Error",
		"TS17"=>"Payment Success",
		"TS02"=>"Payment Failed",
		"TS19"=>"Policy Success",
		"TS03"=>"Policy Failure"];

	public function proposal_submit_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	} //end

	public function proposal_submit_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function proposal_error_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	} //end

	public function proposal_error_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function payment_success_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	}

	public function payment_success_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}
	
	public function payment_failed_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	}

	public function payment_failed_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function policy_success_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	}

	public function policy_success_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function policy_failed_data_internal($trans_data) {
		$master_db = new MasterData();
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data->policy_nu;
			$mail_data["transaction_id"] = $trans_data->transaction_id;
			$mail_data["proposal_number"] = $trans_data->proposal_nu;

			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data->insurer_id . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = $this->_trans_status[$trans_data->t_status];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data->usr_email;
			$mail_data["proposer_phone"] = $trans_data->usr_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->veh_reg_no;
			$varinat_db = $master_db->getVariantData($trans_data->car_variant);
			if($varinat_db){
				$mail_data["vehicle_name"] = $varinat_db->variant_name;
				$mail_data["vehicle_cc"] = $varinat_db->variant_cc;	
			}
			$mail_data["vehicle_reg_date"] = $trans_data->car_registration_date;
			$mail_data["insurer_name"] = $master_db->getCommonInsurerName($trans_data->insurer_id);
			$mail_data["policy_exp_date"] = $trans_data->policy_expiry_date;
			$mail_data["term_start_date"] = $trans_data->policy_start_date;
			$mail_data["opt_idv"] = $trans_data->idv_opted;
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($varinat_db);
		unset($trans_data);
		return $mail_data;
	}

	public function policy_failed_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"vehicle_reg_no" => "",
			"vehicle_name" => "",
			"vehicle_cc" => "",
			"vehicle_reg_date" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"opt_idv" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}
	
	public function email_quote_data_internal($trans_data) {

	}

	public function email_quote_data_external($trans_data) {

	}

	private function get_reg_addr($trans_data) {
		$ret_txt = "";
		$master_data = new MasterData();
		try {
			$city_name = $master_data->getCityName($trans_data->usr_city_code);
			$state_name = $master_data->getStateName($trans_data->usr_state_code);

			$ret_txt = $trans_data->usr_houseno
			. ", " . $trans_data->usr_street
			. ", " . $trans_data->usr_locality
			. ", " . $city_name
			. ", " . $state_name
			. ", " . $trans_data->usr_pincode;
		} catch (\Exception $ex) {}
		unset($master_data);
		return $ret_txt;
	}

	private function get_comm_addr($trans_data) {
		$ret_txt = "";
		$master_data = new MasterData();
		try {
			$ret_txt = $trans_data->prem_usr_houseno
			. ", " . $trans_data->prem_usr_street
			. ", " . $trans_data->prem_usr_locality
			. ", " . $master_data->insr_city("city_name", $trans_data->prem_usr_city_code, true)
			. ", " . $master_data->insr_state("state_name", $trans_data->prem_usr_state_code, true)
			. ", " . $trans_data->prem_usr_pincode;
		} catch (\Exception $ex) {}
		return $ret_txt;
	}

	private function site_url() {
		return url('/') . "/car-insurance/";
	}

	private function proposal_url() {
		return $this->site_url() . "policy/";
	}

	private function getClientName($trans_data) {
		if ($trans_data->usr_type == 'I') {
			return trim($trans_data->usr_firstname . ' ' . $trans_data->usr_lastname);
		}

		return $trans_data->usr_contactperson;
	}

	private function getFinalPremium($trans_data) {
		return ($trans_data->final_premium) ? $trans_data->final_premium : $trans_data->totalpremium;
	}

} // end of class
