<?php
namespace App\Be\Emails;

use App\Helpers\Travel\InsurerData;

class TravelEmails {

	private $_trans_status = ["TS14"=>"Proposal Submit",
		"TS20"=>"Proposal Submit",
		"TS01"=>"Proposal Error",
		"TS17"=>"Payment Success",
		"TS02"=>"Payment Failed",
		"TS19"=>"Policy Success",
		"TS03"=>"Policy Failure"];

	public function proposal_submit_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Proposal Submit";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	} //end

	public function proposal_submit_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"policy_exp_date" => "",
			"term_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function proposal_error_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Proposal Error";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	} //end

	public function proposal_error_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function payment_success_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Payment Success";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	}

	public function payment_success_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}
	
	public function payment_failed_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Payment Failed";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	}

	public function payment_failed_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function policy_success_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Policy Purchased";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	}

	public function policy_success_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}

	public function policy_failed_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"proposal_number"=>"",
			"transaction_id"=>"",
			"policy_number"=>"",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		try {
			$mail_data["policy_number"] = $trans_data['policy_num'];
			$mail_data["transaction_id"] = $trans_data['transaction_num'];
			$mail_data["proposal_number"] = $trans_data['proposal_ref_number'];

			$mail_data["trans_code"] = $trans_data['trans_code'];
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data['agent_code'], true);
			$mail_data["trans_ref_url"] = $this->proposal_url() . "" . $trans_data['company_id'] . "/" . $trans_data['trans_code'];
			$mail_data["trans_status"] = "Policy Failed";
			$mail_data["passport"] = $trans_data['passport'];
			$mail_data["proposer_name"] = $this->getClientName($trans_data);
			$mail_data["proposer_email"] = $trans_data['email'];
			$mail_data["proposer_phone"] = $trans_data['mobile'];
			$mail_data["regn_address"] = $this->get_comm_addr($trans_data);
			$mail_data["insurer_name"] = $master_db->insurer_data("name", $trans_data['company_id']);
			$mail_data["trip_exp_date"] = $trans_data['trip_end_date'];
			$mail_data["trip_start_date"] = $trans_data['trip_start_date'];
			$mail_data["sum_insured"] = $trans_data['sum_insured'];
			$mail_data["final_premium"] = $this->getFinalPremium($trans_data);

			
		} catch (\Exception $ex) {}
		unset($trans_data);
		return $mail_data;
	}

	public function policy_failed_data_external($trans_data) {
		$mail_data = array(
			"trans_code" => "",
			"agent_name" => "",
			"trans_ref_url" => "",
			"passport" => "",
			"trans_status" => "",
			"proposer_name" => "",
			"proposer_email" => "",
			"proposer_phone" => "",
			"regn_address" => "",
			"insurer_name" => "",
			"trip_exp_date" => "",
			"trip_start_date" => "",
			"sum_insured" => "",
			"final_premium" => "",
		);
		return $mail_data;
	}
	
	public function email_quote_data_internal($trans_data) {

	}

	public function email_quote_data_external($trans_data) {

	}

	private function get_comm_addr($trans_data) {
		$ret_txt = "";
		$master_data = new InsurerData();
		$city_name = "";

		if($trans_data['city']){
			$city_name = $master_data->insr_city("city_name", $trans_data['city'], true);
			$city_name = ($city_name) ? $city_name : $trans_data['city'];
		}


		try {
			$ret_txt = $trans_data['house_name']
			. ", " . $trans_data['street']
			. ", " . $city_name
			. ", " . $master_data->insr_state("state_name", $trans_data['state'], true)
			. ", " . $trans_data->prem_usr_pincode;
		} catch (\Exception $ex) {}
		return $ret_txt;
	}

	private function site_url() {
		return url('/') . "/travel-insurance/";
	}

	private function proposal_url() {
		return $this->site_url();
	}

	private function getClientName($trans_data) {
		$client_name = explode(',', $trans_data['name']); 
		$Clientname = $client_name[0];
		return $Clientname; 
	}
	

	private function getFinalPremium($trans_data) {
		return ($trans_data['finalPremium']) ? $trans_data['finalPremium'] : $trans_data['premium'];
	}

} // end of class
