<?php
namespace App\Be\Emails;

use App\Helpers\TW\InsurerData;

class TwEmails {

	public function proposal_submit_data_internal($trans_data){ 
		$master_db = new InsurerData();  
		$mail_data =  array(
			"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("isu_url", $trans_data->insurer_code) . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = "Proposal Submit";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}   
		return $mail_data;
	}	//end
	
	public function proposal_submit_data_external($trans_data) {
		// Yet to developed.
	}
	
	public function proposal_error_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("isu_url", $trans_data->insurer_code) . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = "Proposal Error";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}
		return $mail_data;
	}	//end
	
	public function proposal_error_data_external($trans_data) {
		// Yet to developed.
	}

	public function payment_success_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data =  array(
			"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("isu_url", $trans_data->insurer_code) . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = "Payment Success";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}   
		return $mail_data;
	}

	public function payment_success_data_external($trans_data) {

	}

	public function payment_failed_data_internal($trans_data) {
		$master_db = new InsurerData();  
		$mail_data =  array(
			"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("isu_url", $trans_data->insurer_code) . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = "Payment Failed";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}   
		return $mail_data;
	}

	public function payment_failed_data_external($trans_data) {

	}
	
	public function policy_success_data_internal($trans_data){
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","policy_number"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] =  $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["policy_number"] = $trans_data->policy_number;
			$mail_data["trans_status"] = "Policy Purchased.";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}
		return $mail_data;
	}
	
	public function policy_success_data_external($trans_data){
		
	}
	
	public function policy_failed_data_internal($trans_data){
		
		$master_db = new InsurerData();
		$mail_data =  array(
				"trans_code"=>"","agent_name"=>"","trans_ref_url"=>"","trans_status"=>"","proposer_name"=>"","proposer_email"=>"","proposer_phone"=>"","regn_address"=>"","vehicle_reg_no"=>"","vehicle_name"=>"","vehicle_cc"=>"","vehicle_reg_date"=>"","insurer_name"=>"","policy_exp_date"=>"","term_start_date"=>"","opt_idv"=>"","final_premium"=>""
		);
		try {
			$mail_data["trans_code"] = $trans_data->trans_code;
			$mail_data["agent_name"] = $master_db->user_data("name", $trans_data->agent_code, true);
			$mail_data["trans_ref_url"] = $this->site_url() ."". $master_db->insurer_data("isu_url", $trans_data->insurer_code) . "/" . $trans_data->trans_code;
			$mail_data["trans_status"] = "Policy Failed";
			$mail_data["proposer_name"] = $trans_data->proposer_name;
			$mail_data["proposer_email"] = $trans_data->proposer_email;
			$mail_data["proposer_phone"] = $trans_data->proposer_mobile;
			$mail_data["regn_address"] = $this->get_reg_addr($trans_data);
			$mail_data["vehicle_reg_no"] = $trans_data->tw_reg_no;
			$mail_data["vehicle_name"] = $master_db->insr_variant("vechicle_name_desc", $trans_data->variant_code);
			$mail_data["vehicle_cc"] = $trans_data->variant_cc;
			$mail_data["vehicle_reg_date"] = $trans_data->tw_reg_date;
			$mail_data["insurer_name"] = $master_db->insurer_data("isu_name", $trans_data->insurer_code);
			$mail_data["policy_exp_date"] = $trans_data->policy_exp_date;
			$mail_data["term_start_date"] = $trans_data->term_start_date;
			$mail_data["opt_idv"] = $trans_data->opt_idv;
			$mail_data["final_premium"] = $trans_data->total_premium;
		}catch (\Exception $ex){}
		return $mail_data;
	}
	public function policy_failed_data_external($trans_data){
		
	}

	public function email_quote_data_internal($trans_data){
		
	}
	
	public function email_quote_data_external($trans_data){
		
	}
	
	
	private function get_reg_addr ($trans_data) {
	$ret_txt = "";
	$master_data = new InsurerData();
	try{
		$ret_txt =  	$trans_data->regn_addr1
					.", ".	$trans_data->regn_addr2
					.", ".	$trans_data->regn_addr3
					.", ".	 $master_data->insr_city("city_name", $trans_data->regn_city_code, true) 
					.", ".	$master_data->insr_state("state_name", $trans_data->regn_state_code, true)
					.", ".	$trans_data->regn_pincode;
	}catch (\Exception $ex){}
	return $ret_txt;
	}
	
	private function get_comm_addr ($trans_data) { 
		$ret_txt = "";
		$master_data = new InsurerData();
		try{
			$ret_txt =  	$trans_data->proposer_addr1
			.", ".	 $trans_data->proposer_addr2
			.", ".	 $trans_data->proposer_addr3
			.", ".	 $master_data->insr_city("city_name", $trans_data->proposer_city_code, true)
			.", ".	 $master_data->insr_state("state_name", $trans_data->proposer_state_code, true)
			.", ".	 $trans_data->proposer_pincode;  
		}catch (\Exception $ex){}  
		return $ret_txt;
	}
	
	private function site_url(){  
		return url('/') . "/two-wheeler-insurance/";
	}
	
	
} // end of class
