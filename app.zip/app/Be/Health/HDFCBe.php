<?php
namespace App\Be\Health;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Models\Health\data\QuoteRespData;
use App\Models\Health\data\PolicyPageData;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthRates;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthPlans;
use App\Be\Health\HealthQuoteBe;
use App\Be\Health\HealthPolicyBe;
use GuzzleHttp\Client;
use App\Be\Common\PaymentParseBE;
use App\Helpers\Email\EmailEngine;
use DateTime;
use Log;

class HDFCBe
{
    public function __construct(){ 
    }

    public function set_quote_request($user_data){
        $quote_be = new HealthQuoteBe();
        $quote_req_data = new QuoteReqData();
        $quote_req_data->set_trans_code($user_data['trans_code']);
        $quote_req_data->set_pincode($user_data['pincode']);
        $quote_req_data->set_members_list(explode('|',$user_data['members_list']));
        $quote_req_data->set_dob_list(explode('|',$user_data['dob_list']));
        $quote_req_data->set_age_list(explode('|',$user_data['age_list']));
        $quote_req_data->set_adult($user_data['adult']);
        $quote_req_data->set_children($user_data['children']);
        $quote_req_data->set_tenure($user_data['tenure']);
        $quote_req_data->set_sum_insured($user_data['sum_insured']);
        $quote_req_data->set_plan_type($user_data['plan_type']);
        $quote_req_data->set_product_type($user_data['product_type']);
        if($user_data['product_type'] == 'S'){
            //$suminsured = $quote_be->get_deductables($user_data['deductables'], $user_data['sum_insured'],'hdfc_code');
            $quote_req_data->set_sum_insured($user_data['sum_insured']);
            $quote_req_data->set_super_topup_opted('On');
            $quote_req_data->set_deductible_amount($user_data['deductables']);
        }else { 
            $quote_req_data->set_super_topup_opted('off');
            $quote_req_data->set_deductible_amount('0');
        }
        return $quote_req_data;
    }

    public function check_policy($trans_code){
        $data  = $this->check_hdfc_policy_type($trans_code);

        if(isset($data)){
            $data['insurer_id'] = 'hdfc';
            if(isset($request['ped_check']) && $request['ped_check'] != null){
                $data['ped_check']  = true;
                $data['ped_msg']    = 'Pre-existing disease is disclosed';
            }


            if(!empty($data['bmi'])){ 
                Log::info('sree');
                $data['bmi_check']  = true;
                $data['member']     = $data['bmi'];
                $data['bmi_msg']    = Health_Constants::BMI_MSG;
            }

            return view('health/campaign/status/age_status', compact('data'))->render();
            
        }
        return response()->json(['status' => false]);
    }

    public function get_plan_list($data){
        $productcode = ($data->get_deductible_amount() == '0') ? 'HSP' : 'HSTOP';
        $hdfc_plan = new HealthPlans();
        $members = $this->calculate_age($data->get_age_list(),$data->get_members_list(), $data->get_product_type());
        $insured_pattern = $this->get_insured_pattern($members,$data->get_members_list(), $data->get_product_type());
        $check_si_response = $this->check_si($insured_pattern, $data->get_sum_insured());
        if(!$check_si_response)
            return false;
        $plan_check = $this->validate_plan($data,$insured_pattern);
        if($plan_check == true ){
            $pattern = ($data->get_plan_type() == "INDV") ? '1000' : $insured_pattern;
            $column  = array('plan_id','product_code','product_name','plan_code','plan_name','plan_min_age','plan_max_age','plan_insured_pattern','plan_si','plan_tenure','is_display');
            if($data->get_product_type() === 'S'){ 
               // $data['topup'] = 'On';
                $check_values  = array('plan_deductables'=> $data->get_deductible_amount(),'product_code' => $productcode,'plan_insured_pattern' => $pattern, 'plan_si' => $data->get_sum_insured(), 'plan_tenure' => $data->get_tenure());
            }else{
                $check_values  = array('product_code' => $productcode,'plan_insured_pattern' => $pattern, 'plan_si' => $data->get_sum_insured(), 'plan_tenure' => $data->get_tenure());
            }
            return $hdfc_plan->get_plans($column,$check_values);
        }
        return false;
    }
    
    private function check_si($pattern, $si){
        if($si == '400000' && $pattern == 1000)
            return false;

        if($si == '300000'){
            switch ($pattern) {
                case 1000:
                    return false;
                    break;

                case 1010:
                    return false;
                    break;

                case 1020:
                    return false;
                    break;

                case 1030:
                    return false;
                    break;            
                
                default:
                    return true;
                    break;
            }
        }

        return true;
    }



    private function validate_plan($data,$insured_pattern){
        if(empty($insured_pattern)  || (($data->get_product_type() == 'S' && $data->get_plan_type() == 'INDV') && ($insured_pattern == 1010 || $insured_pattern == 1020 || $insured_pattern ==  1030))) {
            return false;
        }
        return true;
    }

    public function parse_quote_response($quote_response,$quote_req_data){
        if(!empty($quote_response) && $quote_response != false){
            $quote_resp_data = new QuoteRespData();
            $quote_resp_data->set_trans_code($quote_req_data->get_trans_code());
            $quote_resp_data->set_sum_insured($quote_req_data->get_sum_insured());
            $quote_resp_data->set_super_topup_opted($quote_req_data->get_super_topup_opted());
            $quote_resp_data->set_deductible_amount($quote_req_data->get_deductible_amount());
            $quote_resp_data->set_product_type($quote_req_data->get_product_type());
            $quote_resp_data->set_plan_type(($quote_req_data->get_plan_type() == 'INDV')?'NF':'WF');
            $quote_resp_data->set_premium($quote_response['base_premium']);
            $serviceTax = (($quote_response['base_premium'] * 18)/ 100);
            $quote_resp_data->set_serviceTax($serviceTax);
            $quote_resp_data->set_cgst($serviceTax/2);
            $quote_resp_data->set_sgst($serviceTax/2);
            $quote_resp_data->set_totalPremium($quote_response['base_premium'] + $serviceTax);
            $quote_resp_data->set_product_id($quote_response['plan_code']);
            $quote_resp_data->set_product_plan($quote_response['plan_name']);
            $quote_resp_data->set_product_name($quote_response['product_name'].' '.$quote_response['plan_name']);
            $quote_resp_data->set_insurer_name('hdfc');
            $quote_resp_data->set_insurer_code('HDFC');
            return $quote_resp_data;
        }
        return null;
    }

     public function cover_list($pro_Id){
        //  Silver Plans
        if(substr($pro_Id,0,3)  == 'HSS' || substr($pro_Id,0,3)  == 'HS1'){
            $hdfc_covers = [
                ["coverId" => "AMBUL","coverName"=>"Ambulance Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId" =>"DON","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverName"=>"Private room","coverLimits"=>[]]
                
            ];
            return json_encode($hdfc_covers);
        }
        // Silver Regain plans
        if(substr($pro_Id,0,3)  == 'SRE'){
            $hdfc_covers = [
                ["coverId" => "AMBUL","coverName"=>"Ambulance Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId" =>"DON","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId" =>"RESSI","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverName"=>"Private room","coverLimits"=>[]]
            ];
            return json_encode($hdfc_covers);
        }

        // Gold plans
        if(substr($pro_Id,0,3) == 'HSG' || substr($pro_Id,0,3) == 'HG1'){
            $hdfc_covers = [
                ["coverId" => "AMBUL","coverName"=>"Ambulance Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId" =>"DON","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"NB","coverName"=>"New Born Baby","coverLimits"=>[]],
                ["coverId"=>"MA","coverName"=>"Maternity","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverName"=>"Private room","coverLimits"=>[]]
            ];
            return json_encode($hdfc_covers);
        }
        // Gold Regain plans 
        if(substr($pro_Id,0,3) == 'GRE'){
            $hdfc_covers = [
                ["coverId" => "AMBUL","coverName"=>"Ambulance Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId" =>"DON","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"NB","coverName"=>"New Born Baby","coverLimits"=>[]],
                ["coverId"=>"MA","coverName"=>"Maternity","coverLimits"=>[]],
                ["coverId" =>"RESSI","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverName"=>"Private room","coverLimits"=>[]]
            ];
            return json_encode($hdfc_covers);
        }
        
    }

    private function calculate_age($agelist, $memlist, $product_type){
        $child_age_limit = ($product_type === 'S') ? '23' : '25';
        $adult = $children = 0;
        for($i=0; $i<count($memlist);$i++){
            if($memlist[$i] == 'WIFE' || $memlist[$i] == 'MOTH' || $memlist[$i] == 'FATH' || $memlist[$i] == 'HUS'){ $adult++; }
            elseif($memlist[$i] == 'SELF' && $agelist[$i] >=18 ){ $adult++; }
            elseif($memlist[$i] == 'SONM' || $memlist[$i] == 'UDTR'){
                if($agelist[$i] === '3m'){ $children++;}
                elseif($agelist[$i] > (int)$child_age_limit){ $adult++;
                }else { $children++; }
            }
        }
        $res['adult'] = $adult;
        $res['children'] = $children;
        return $res;
    }

    private function get_insured_pattern($member_type, $members, $type){ 
        if( $type ===  'S')
            $rel_flag = 1;
        else
        $rel_flag = (in_array("FATH", $members) || in_array("MOTH", $members)) ? 0 : 1 ; 

        $ins_pattern = null;
        if($rel_flag == 1){
            if(($member_type['adult'] == 2) && ($member_type['children'] == 2)) {
                $ins_pattern = 1120; }
            elseif(($member_type['adult'] == 2) && ($member_type['children'] == 1)) {
                $ins_pattern = 1110; }
            elseif(($member_type['adult'] == 1) && ($member_type['children'] == 2)) {
                $ins_pattern = 1020; }
            elseif(($member_type['adult'] == 1) && ($member_type['children'] == 3)) {
                $ins_pattern = 1030; }
            elseif(($member_type['adult'] == 1) && ($member_type['children'] == 1)) {
                $ins_pattern = 1010; }
            elseif(($member_type['adult'] == 2) &&($member_type['children'] == 0)){
                $ins_pattern = 1100; }
            elseif(($member_type['adult'] == 1) &&($member_type['children'] == 0)){
                $ins_pattern = 1000; }
            return $ins_pattern;
        }
            return null;
    }

    public function get_basic_indv($mem_age, $plan_list){
        $rate_mod = new HealthRates();
        foreach($mem_age as $age){
            foreach( $plan_list as $index => $plan){
                if(($plan['plan_min_age']<= $age)&&($plan['plan_max_age'] >= $age)){
                    $pl[] = $plan; } }
        }
        $arr = array();
        if(isset($pl) && !empty($pl)){ 
            foreach($pl as $index1 => $value1){
                foreach($pl as $index2 => $value2){
                    if(($value1['product_name'] == $value2['product_name']) && ($value1['plan_name'] == $value2['plan_name'])) {
                        $plancode = $value1['plan_code'];
                        $arr[$value1['product_name']][$index1] = $value1;
                    }
                }
            }
        }else { return 'Error'; }
        $plan_carry = array();
        $final_plan = array();
        $premium = 0;
        foreach($arr as $product){
            foreach($product as $in1 => $plan1){
                $premium = 0;
                foreach($product as $in2 => $plan2){
                  if($plan1['plan_name'] === $plan2['plan_name']){
                    $productname = $plan2['product_name'];
                    $plancode = $plan2['plan_code'];
                    $planname = $plan2['plan_name'];
                    $plansi   = (isset($plan2['plan_si']))? $plan2['plan_si'] : '';
                    $hdfc_rates = $rate_mod->getpremium($plancode,$planname,$plansi);
                    $plan_carry[$productname][$planname][$in2] = $hdfc_rates[0];
                  }
                }
            }
        }
        $temp_plan = array();
        $premium   = 0;
        foreach($plan_carry as $product){
          foreach($product as $plan){
            $premium = 0;   
            foreach($plan as $plan2){
                $premium += $plan2['base_premium'];
            }
            // Applying 10% discount if eligible
            $plan2['base_premium'] = (count($mem_age) >= 2) ? $premium - ($premium * Health_Constants::HDFC_BASIC_INDV_DISCOUNT) : $premium ;
            $temp_plan[$plan2['product_name']][$plan2['plan_name']] = $plan2;
          }
        } 
        $arr1 = array(); 
        $i = 0;
        foreach ($temp_plan as $key1 => $value1) {
            foreach ($value1 as $key2 => $value2) {
                $arr1[] = $value2; }
        }
        $i = 0;
        $final_plan = array();
        foreach($arr1 as $plan){
            $final_plan[$i][0] = $plan;
            $i++; }
        return $final_plan;
    }

    public function get_super_topup_indv($mem_age, $plan_list){
        $rate_mod = new HealthRates();
        foreach($mem_age as $age){
            if($age === '3m') $age = '3';   
            foreach( $plan_list as $index => $plan){
                if(($plan['plan_min_age']<= $age)&&($plan['plan_max_age'] >= $age)){
                    $pl[] = $plan; }  }
        }
        $arr = array();
        if(isset($pl) && !empty($pl)){ 
            foreach($pl as $index1 => $value1){
                foreach($pl as $index2 => $value2){
                    if($value1['plan_si'] == $value2['plan_si']){
                        $plancode = $value1['plan_code'];
                        $arr[$value1['plan_si']][$index1] = $value1;
                    }
                }
            }
        }else { return 'Error'; }
        $plan_carry = '';
        $final_plan = array();
        $premium = 0;
        foreach($arr as $si){
            $premium = 0;
            foreach($si as $plan){
                $plancode = $plan['plan_code'];
                $planname = $plan['plan_name'];
                $plansi   = (isset($plan['plan_si']))? $plan['plan_si'] : '';
                $hdfc_rates = $rate_mod->getpremium($plancode,$planname,$plansi);   
                $premium += round($hdfc_rates[0]['base_premium']); 
                $plan_carry =  $hdfc_rates[0];
            }
            // Applying 10% discount if eligible
            $plan_carry['base_premium'] = (count($mem_age) > 2) ? $premium - ($premium * Health_Constants::HDFC_S_TOPUP_INDV_DISCOUNT) : $premium ;
            $final_plan[][0] = $plan_carry;
        }
        return $final_plan;
    }

    

    public function set_proposal_details($usr_data){
        if(!empty($usr_data['firstname'])){
            $mem_doblist = explode('|', $usr_data['dob_list']);
            foreach($mem_doblist as $doblist){
                $dob_list[] = date('d-m-Y', strtotime($doblist));
            }
            $data = [ 
                'dob_list' => $dob_list,
                'age_list' => explode('|', $usr_data['age_list']),
                'firstname' => explode('|', $usr_data['firstname']),
                'lastname' => explode('|', $usr_data['lastname']),
                'height_feet' => explode('|', $usr_data['height_feet']),
                'height_inches' => explode('|', $usr_data['height_inches']),
                'weight' => explode('|', $usr_data['weight']),
                'occupation' => explode('|', $usr_data['occupation']),
                'business' => explode('|', $usr_data['business']),
                'designation' => explode('|', $usr_data['designation']),
                'gender' => explode('|', $usr_data['gender']),
                'agree_med_chkup' => 0,
                'usr_data' => $usr_data
            ];
            return $data;
        }
        return null;
    }


    // Proposal Section data 
    public function set_proposal_data($user_data, $type=null){
        $state_db = new HealthState();
        $city_db = new HealthCity();

        if($type == 'campaign'){
            $statelist = $state_db->get_state_campaign_list($user_data['state'], 'hdfc_code');
            $citylist = $city_db->get_city_campaign_list($user_data['city'], 'hdfc_code');
        }else{
            $statelist = $state_db->get_state_list($user_data['state'], 'hdfc_code');
            $citylist = $city_db->get_city_list($user_data['city'], 'hdfc_code');
        }

        $proposal_req_data = new PolicyPageData();
        $user_db = new HealthUserData();
        $data = $user_db->get_by_usrdata($user_data['hl_trans_code']);
        $proposal_req_data->set_hl_trans_code($user_data['hl_trans_code']);
        $proposal_req_data->set_tenure($user_data['tenure']);
        $proposal_req_data->set_plan_type(($user_data['plan_type'] == 'INDV') ? 'NF' : 'WF');
        $proposal_req_data->set_policy_start($user_data['policy_start']);
        $proposal_req_data->set_policy_end($user_data['policy_end']);
        $proposal_req_data->set_product_id($user_data['product_id']);
        $proposal_req_data->set_product_plan($user_data['product_plan']);
        $proposal_req_data->set_product_type($user_data['product_type']);
        $proposal_req_data->set_insurer_name($user_data['insurer_name']);
        $proposal_req_data->set_sum_insured($user_data['sum_insured']);

        if (is_array($user_data['dob_list'])){
                $user_data['dob_list'] = $user_data['dob_list'];
        }else{
            $user_data['dob_list'] = explode('|', $user_data['dob_list']);
        }
        foreach($user_data['dob_list'] as $dob){
            $date = DateTime::createFromFormat("d-m-Y" , $dob);
            if(!$date)
                $date = DateTime::createFromFormat("Y-m-d" , $dob);
            $mem_dob[] = $date->format('d/m/Y');
        }
        $proposal_req_data->set_dob_list($mem_dob);
        $proposal_req_data->set_age_list(explode('|',$user_data['age_list']));
        $proposal_req_data->set_members_list(explode('|', $user_data['members_list']));

        if($type == 'campaign'){
            $gender_list = explode('|', $data['gender']);
            $proposal_req_data->set_gender($gender_list);
        }else{
            $gender_list = explode('|', $data['gender']);
            $replacements = array(0 => $user_data['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            $proposal_req_data->set_gender($gender);
        }
        
        $proposal_req_data->set_firstname($user_data['firstname']);
        $proposal_req_data->set_lastname($user_data['lastname']);
        $proposal_req_data->set_aadhaar($user_data['aadhaar_num']);
        $proposal_req_data->set_feet($user_data['height_feet']);
        $proposal_req_data->set_inches($user_data['height_inches']);
        $proposal_req_data->set_weight($user_data['weight']);
        $proposal_req_data->set_email($user_data['email']);
        $proposal_req_data->set_mobile($user_data['mobile']);
        $proposal_req_data->set_houseno($user_data['house_num']);
        $proposal_req_data->set_street($user_data['street']);
        $proposal_req_data->set_locality($user_data['locality']);
        $proposal_req_data->set_cust_pincode($user_data['cust_pincode']);
        $proposal_req_data->set_state((!empty($statelist['hdfc_code']))?$statelist['hdfc_code'] : '0');
        $proposal_req_data->set_city((!empty($citylist['hdfc_code'])) ? $citylist['hdfc_code'] : '0');
        $proposal_req_data->set_ped_details($user_data['pedname']);
        $proposal_req_data->set_nominee_name($user_data['nominee_name']);
        $proposal_req_data->set_nominee_age($user_data['nominee_age']);
        $proposal_req_data->set_nominee_relation($user_data['nominee_relation']);
        $proposal_req_data->set_agree_medical_checkup((isset($user_data['agree_med_chkup']) && ($user_data['agree_med_chkup'] == 1)) ? 1 : 0 );

        $deductible = isset($user_data["deductable"]) ? $user_data["deductable"] : isset($user_data["deductables"]) ? $user_data["deductables"] : $user_data["deductibles"];

        $proposal_req_data->set_top_up(($deductible != 0) ? 'On' : 'off');
        $proposal_req_data->set_deductible_amount(!empty(($deductible) && $deductible !== null) ? $deductible : '0');
        if($type == 'campaign'){
            $proposal_req_data->set_final_premium($user_data['basePremium']);
            $proposal_req_data->set_final_serviceTax($user_data['serviceTax']);
            $proposal_req_data->set_final_totalPremium($user_data['totalPremium']);
        }else{
            $proposal_req_data->set_final_premium($data['basePremium']);
            $proposal_req_data->set_final_serviceTax($data['serviceTax']);
            $proposal_req_data->set_final_totalPremium($data['totalPremium']);
        }
  
        return $proposal_req_data;
    }

    // Basic Plan proposal request 
    public function populate_proposal_request_basic_plan($req_data){
        $cust_details = $this->calculate_custdetails($req_data);
        $plan_details = $this->calculate_plandetails($req_data);
        $payment_details = $this->calculate_paymentdetails($req_data);
        $insurer_details = $this->calculate_insureddetails($req_data);
        $hdfc_xml = '<InsuranceDetails>
                         <CustDetails>'.$cust_details.'</CustDetails>
                         <PlanDetails>'.$plan_details.'</PlanDetails>
                         <PaymentDetails>'.$payment_details.'</PaymentDetails>
                         <Member>'.implode("",$insurer_details).'</Member>
                     </InsuranceDetails>';
        return $hdfc_xml;
    }

    private function calculate_custdetails($data){
        $policy_be = new HealthPolicyBe();
        $uid_no = $policy_be->get_uid($data->get_mobile()); 
        $accepted_ppcped  = ($data->get_agree_medical_checkup() == 1) ? 1 : 0 ;
        $gender_list = $data->get_gender();
        $mem_title = ($gender_list[0] == 'M')? 'Mr': 'Ms';
        $custdetails ='<ApplFirstName>'.$data->get_firstname()[0].'</ApplFirstName>
                        <ApplLastName>'.$data->get_lastname()[0].'</ApplLastName>
                        <ApplDOB>'.$data->get_dob_list()[0].'</ApplDOB>
                        <ApplGender>'.$gender_list[0].'</ApplGender>
                        <Address1>'.$data->get_houseno().' ' .$data->get_street().'</Address1>
                        <Address2>'.$data->get_locality().'</Address2>
                        <Address3>/</Address3>
                        <State>'.$data->get_state().'</State>
                        <City>'.$data->get_city().'</City>
                        <Pincode>'.$data->get_cust_pincode().'</Pincode>
                        <EmailId>'.strtolower($data->get_email()).'</EmailId>
                        <MobileNo>'.$data->get_mobile().'</MobileNo>
                        <Title>'.$mem_title.'</Title>
                        <IsCustomerAcceptedPPCPED>'.$accepted_ppcped.'</IsCustomerAcceptedPPCPED>
                        <IsProposerSameAsInsured>Y</IsProposerSameAsInsured>
                        <IsCustomerAuthenticationDone>1</IsCustomerAuthenticationDone>
                        <AuthenticationType>OTP</AuthenticationType>
                        <UIDNo>'.$uid_no.'</UIDNo>';
        return $custdetails;   
    }

    private function calculate_plandetails($data){
        $user_db = new HealthUserData();
        $plandetails ='<ProducerCd>'.Health_Constants::HDFC_BASIC_PRODUCER_CODE.'</ProducerCd>
                        <ProductCd>'.Health_Constants::HDFC_PRODUCT_CODE.'</ProductCd>
                        <PlanCd>'.$data->get_product_id().'</PlanCd>
                        <coverType>'.$data->get_product_plan().'</coverType>
                        <BasePremium>'.round($data->get_final_premium()).'</BasePremium>
                        <ServiceTax>'.round($data->get_final_serviceTax()).'</ServiceTax>
                        <TotalPremiumAmt>'.round($data->get_final_totalPremium()).'</TotalPremiumAmt>
                        <SumInsured>'.$data->get_sum_insured().'</SumInsured>
                        <TypeOfPlan>'.$data->get_plan_type().'</TypeOfPlan>
                        <PolicyPeriod>'.$data->get_tenure().'</PolicyPeriod>';
        return $plandetails;
    }


    private function calculate_paymentdetails($data){
        $paymentdetails ='<PaymentMode>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentMode>
        <PaymentReferance>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentReferance>
        <CoInsurance>N</CoInsurance>';
        return $paymentdetails;
    }

    private function calculate_insureddetails($data){
        $insured_data = [];
        $relationship = $data->get_members_list();
        $ped_lifestyle = $this->set_ped_list($data);
        foreach ($relationship as $i => $relationship_id){
            if($relationship_id == 'SELF'){ $rel_id = 'I'; }
            if($relationship_id == 'WIFE'){ $rel_id = 'W'; } 
            if($relationship_id == 'HUSBAND'){ $rel_id = 'H'; } 
            if($relationship_id == 'SON'){ $rel_id = 'S'; } 
            if($relationship_id == 'DAUGHTER'){ $rel_id = 'D'; } 
            $gender = $data->get_gender();
            $mem_gender = ($gender[$i] == 'M') ? 'M' : 'F' ;
            $srl_no = $i+1;
            $insured_data[] = '<InsuredDetails SrNo="'.$srl_no.'" FirstName="'.$data->get_firstname()[$i].'" LastName="'.$data->get_lastname()[$i].'" DOB="'.$data->get_dob_list()[$i].'" RelationShip="'.$rel_id.'" InsuredId="'.$srl_no.'" Gender="'.$mem_gender.'" NomineeName="'.$data->get_nominee_name().'" NomineeRelationship="'.$data->get_nominee_relation().'" PreExistingDisease="'.$ped_lifestyle[$i].'" />';
        }
        return $insured_data;
    }

    private function set_ped_list($data){
        $ped = $data->get_ped_details();
        $usertdata = new HealthUserData();
        $ped_lifestyle = [
            '0'=> isset($ped['disease_member_1']) ? $ped['disease_member_1']: '',
            '1' => isset($ped['disease_member_2']) ? $ped['disease_member_2'] : '',
            '2' => isset($ped['disease_member_3']) ? $ped['disease_member_3'] : '',
            '3' => isset($ped['disease_member_4']) ? $ped['disease_member_4'] : '', 
        ];
        $input['ped_lifestyle'] = json_encode($ped_lifestyle);
        $check_values = array('trans_code' => $data->get_hl_trans_code());
        $usertdata->update_data($input, $check_values);
        return $ped_lifestyle;
    }


    public function parse_hdfc_basic_response($prop_response, $prop_request){
        $firstname = $prop_request->get_firstname(); 
        $lastname = $prop_request->get_lastname(); 
        if(strpos($prop_response, 'WsStatus') !== false){
            $xml = new \SimpleXMLElement($prop_response);
            $dom = new \DOMDocument;
            $dom->loadXML($xml);
            $status  = $dom->getElementsByTagName("WsStatus")->item(0)->nodeValue;
            if($status == 0){
                $txnnumber = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;
                $response['status']          = true;
                $response['CustomerId']      = $txnnumber;
                $response['TxnAmount']       = round($prop_request->get_final_totalPremium());
                $response['AdditionalInfo1'] = 'NB';
                $response['AdditionalInfo2'] = Health_Constants::HDFC_PRODUCT_CODE;
                $response['AdditionalInfo3'] = '1';
                $response['hdnPayMode']      = Health_Constants::HDFC_PAYMENT_MODE;
                $response['UserName']        = $firstname[0].' '.$lastname[0];
                $response['UserMailId']      = $prop_request->get_email();
                $response['ProductCd']       = Health_Constants::HDFC_PRODUCT_CODE;
                $response['ProducerCd']      = Health_Constants::HDFC_BASIC_PRODUCER_CODE;
                $response['payUrl']          = Health_Constants::HDFC_BASIC_PG_URL;
                 Log::info('Health HDFC Basic Plan PG Request - '.$prop_request->get_hl_trans_code(). ' '.print_r($response,true));
                return json_encode($response);
            }else{
                $message = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;
                if(strpos($message, 'Err - Invalid planCd') !== false){
                    return json_encode(['status' => 'false', 'mismatch' => 0, 'error' => 0,'message' => Health_Constants::INVALID_PLAN_MSG]);
                }elseif(strpos($message, 'short') !== false){ 
                    Log::info('Premium Mismatch');
                    $premium_payable = trim($this->get_string_between($message, 'Calculated premium :', ','));
                    $premium_passed  = $prop_request->get_final_totalPremium();
                    $response['error']          = 'premium mismatch';
                    $response['premiumPayable'] = $premium_payable;
                    $response['premiumPassed']  = $premium_passed;
                    return json_encode($response);
                }elseif(strpos($message, 'excess') !== false){ 
                    Log::info('Premium Mismatch');
                    $premium_payable = trim($this->get_string_between($message, 'Calculated premium :', ','));
                    $premium_passed  = $prop_request->get_final_totalPremium();
                    $response['error']          = 'premium mismatch';
                    $response['premiumPayable'] = $premium_payable;
                    $response['premiumPassed']  = $premium_passed;
                    return json_encode($response);
                }elseif(strpos($message, 'Err-Customer acceptance is not received') !== false){
                        return json_encode(['status' => 'false', 'mismatch' => 0, 'error' => 0,'message' => 'Customer-aceptance' ]);
                    }else{ 
                    $head_msg = 'Opps !. Please Correct the following errors <br>';
                    $message = str_replace('\n','<br>',$message);
                    $message  = $head_msg.$message; 
                    return json_encode(['status' => 'false', 'mismatch' => 0, 'error' => 1, 'message' => $message]); 
                }
            }
        }
    }

    // TopUp proposal Request
    public function populate_proposal_request_topup_plan($req_data){
        $topup_cust_details = $this->topup_custdetails($req_data);
        $topup_plan_details = $this->topup_plandetails($req_data);
        $topup_payment_details = $this->topup_paymentdetails($req_data);
        $topup_insurer_details = $this->topup_insureddetails($req_data);
        $hdfc_topup_xml = '<InsuranceDetails>
                         <CustDetails>'.$topup_cust_details.'</CustDetails>
                         <PlanDetails>'.$topup_plan_details.'</PlanDetails>
                         <PaymentDetails>'.$topup_payment_details.'</PaymentDetails>
                         <Member>'.implode("", $topup_insurer_details).'</Member>
                     </InsuranceDetails>';
        return $hdfc_topup_xml;
    }


    private function topup_custdetails($data){
        $policy_be = new HealthPolicyBe();
        $uid_no = $policy_be->get_uid($data->get_mobile()); 
        $accepted_ppcped  = ($data->get_agree_medical_checkup() == 1) ? 1 : 0 ;
        $gender_list = $data->get_gender();
        $custdetails = '<ApplFirstName>'.$data->get_firstname()[0].'</ApplFirstName>
                        <ApplMiddleName></ApplMiddleName>
                        <ApplLastName>'.$data->get_lastname()[0].'</ApplLastName>
                        <ApplDOB>'.$data->get_dob_list()[0].'</ApplDOB>
                        <ApplGender>'.$gender_list[0].'</ApplGender>
                        <Address1>'.$data->get_houseno().' ' .$data->get_street().'</Address1>
                        <Address2>'.$data->get_locality().'</Address2>
                        <Address3></Address3>
                        <State>'.$data->get_state().'</State>
                        <City>'.$data->get_city().'</City>
                        <Pincode>'.$data->get_cust_pincode().'</Pincode>
                        <IsProposerSameAsInsured>Y</IsProposerSameAsInsured>
                        <IsCustomerAcceptedPPCPED>'.$accepted_ppcped.'</IsCustomerAcceptedPPCPED>
                        <EmailId>'.strtolower($data->get_email()).'</EmailId>
                        <PhoneNo></PhoneNo>
                        <MobileNo>'.$data->get_mobile().'</MobileNo>
                        <IsCustomerAuthenticationDone>1</IsCustomerAuthenticationDone> 
                        <AuthenticationType>OTP</AuthenticationType> 
                        <UIDNo>'.$uid_no.'</UIDNo> ';
        return $custdetails;
    }

    private function topup_plandetails($data){
        $plandetails ='<ProducerCd>'.Health_Constants::HDFC_SUPER_TOPUP_PRODUCER_CODE.'</ProducerCd>
                        <ProductCd>'.Health_Constants::HDFC_S_TOPUP_P_CODE.'</ProductCd>
                        <PlanCd>'.$data->get_product_id().'</PlanCd>
                        <coverType>PLUS</coverType>
                        <BasePremium>'.round($data->get_final_premium()).'</BasePremium>
                        <ServiceTax>'.round($data->get_final_serviceTax()).'</ServiceTax>
                        <TotalPremiumAmt>'.round($data->get_final_totalPremium()).'</TotalPremiumAmt>
                        <SumInsured>'.$data->get_sum_insured().'</SumInsured>
                        <TypeOfPlan>'.$data->get_plan_type().'</TypeOfPlan>
                        <PolicyPeriod>'.$data->get_tenure().'</PolicyPeriod>
                        <Deductible>'.$data->get_deductible_amount().'</Deductible>';
        return $plandetails;

    }

    private function topup_paymentdetails($data){
        $paymentdetails = '<PaymentMode>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentMode>
                            <PaymentReferance>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentReferance>
                            <CoInsurance>N</CoInsurance>';
        return $paymentdetails;
    }

    private function topup_insureddetails($data){
        $insureddetails = [];
        $relationship = $data->get_members_list();
        $ped_lifestyle = $this->set_ped_list($data);
        foreach ($relationship as $i => $relationship_id){
            if($relationship_id == 'SELF'){ $rel_id = 'I'; }
            if($relationship_id == 'WIFE'){ $rel_id = 'W'; } 
            if($relationship_id == 'HUSBAND' || $relationship_id == 'HUS'){ $rel_id = 'H'; } 
            if($relationship_id == 'SON' || $relationship_id == 'SONM'){ $rel_id = 'S'; } 
            if($relationship_id == 'DAUGHTER' || $relationship_id == 'UDTR'){ $rel_id = 'D'; }
            if($relationship_id == 'MOTHER' || $relationship_id == 'MOTH'){ $rel_id = 'M'; } 
            if($relationship_id == 'FATHER' || $relationship_id == 'FATH'){ $rel_id = 'F'; } 
            $gender = $data->get_gender();
            $mem_gender = ($gender[$i] == 'M') ? 'M' : 'F' ;
            $srl_no = $i+1;
            $IsPED = (!empty($ped_lifestyle[$i])) ? 'true' : 'false' ;
            $height = $this->convert_feet_to_cm($data->get_feet()[$i], $data->get_inches()[$i]);
            $insureddetails[] = '<InsuredDetails FullName="'.$data->get_firstname()[$i].' '.$data->get_lastname()[$i].'" FirstName="'.$data->get_firstname()[$i].'" MiddleName="" LastName="'.$data->get_lastname()[$i].'" DOB="'.$data->get_dob_list()[$i].'" RelationShip="'.$rel_id.'" InsuredId="'.$srl_no.'" Gender="'.$mem_gender.'" NomineeName="'.$data->get_nominee_name().'" NomineeRelationship="'.$data->get_nominee_relation().'" PreExistingDisease="'.$ped_lifestyle[$i].'" IsPED="'.$IsPED.'" DocumentNumber="" DocumentType="" Height="'.round($height).'" Weight="'.$data->get_weight()[$i].'" />';
        }
         return $insureddetails;
    }

    public function parse_hdfc_topup_response($prop_response, $prop_request){
        $firstname = $prop_request->get_firstname(); 
        $lastname = $prop_request->get_lastname(); 
        $user_tbl = new HealthUserData();
        if(strpos($prop_response, 'WsStatus') !== false){
            $xml = new \SimpleXMLElement($prop_response);
            $dom = new \DOMDocument;
            $dom->loadXML($xml);
            $status  = $dom->getElementsByTagName("WsStatus")->item(0)->nodeValue;
            if($status == 0){
                $txnnumber = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;

                //Saving txnnumber to user table
                $trans_code = $prop_request->get_hl_trans_code();
                $column = array('campaign_txn_number' => $txnnumber);
                $user_tbl->set_by_usrdata($trans_code, $column);
                //Saving txnnumber to user table ends 

                $response['status']          = true;
                $response['CustomerId']      = $txnnumber;
                $response['TxnAmount']       = round($prop_request->get_final_totalPremium());
                $response['AdditionalInfo1'] = 'NB';
                $response['AdditionalInfo2'] = Health_Constants::HDFC_S_TOPUP_P_CODE;
                $response['AdditionalInfo3'] = '1';
                $response['hdnPayMode']      = Health_Constants::HDFC_PAYMENT_MODE;
                $response['UserName']        = $firstname[0].' '.$lastname[0];
                $response['UserMailId']      = $prop_request->get_email();
                $response['ProductCd']       = Health_Constants::HDFC_S_TOPUP_P_CODE;
                $response['ProducerCd']      = Health_Constants::HDFC_SUPER_TOPUP_PRODUCER_CODE;
                $response['payUrl']          = Health_Constants::HDFC_PG_URL;
                Log::info('Health HDFC Super Top-Up PG Request - '.$prop_request->get_hl_trans_code(). ' '.print_r($response,true));
                return json_encode($response);
            }else{
                $message = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;
                if(strpos($message, 'Invalid planCd') !== false){
                    return json_encode(['status' => 'false', 'message' => Health_Constants::INVALID_PLAN_MSG]);
                }elseif(strpos($message, 'excess') !== false){ 
                    $premium_payable = trim($this->get_string_between($message, 'Calculated premium :', ','));
                    $premium_passed  = $user_data['totalPremium'];
                    $response['error']          = 'premium mismatch';
                    $response['premiumPayable'] = $premium_payable;
                    $response['premiumPassed']  = $premium_passed;
                    return json_encode($response);
                }elseif(strpos($message, 'short') !== false){ 
                    $premium_payable = trim($this->get_string_between($message, 'Calculated premium :', ','));
                    $premium_passed  = $user_data['totalPremium'];
                    $response['error']          = 'premium mismatch';
                    $response['premiumPayable'] = $premium_payable;
                    $response['premiumPassed']  = $premium_passed;
                    return json_encode($response);
                }elseif(strpos($message, 'Customer acceptance') !== false){
                        return json_encode(['status' => 'false', 'mismatch' => 0, 'error' => 0,'message' => 'Customer-aceptance' ]);
                }else{ 

                $head_msg = 'Opps !. Please Correct the following errors <br>';
                $message  = str_replace('\n','<br>',$message);
                $message  = $head_msg.$message; 
                return json_encode(['status' => 'false', 'mismatch' => 0, 'error' => 1, 'message' => $message]); 
                }
            }
        }
    }


    private function get_string_between($string, $start, $end){
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    } 

    public function check_hdfc_policy_type($trans_code){
        $usertdata = new HealthUserData();
        $columns =array('insurerId','product_type','age_list','sum_insured','rsgi_refr_status');
        $data = $usertdata->getUserTData($trans_code,$columns);
        $insurerId      = $data['insurerId'];
        $product_type   = $data['product_type'];
        $suminsured    = $data['sum_insured'];
        $age           = explode('|',$data['age_list']);
        foreach($age as $mem_age){
            if($product_type === 'S'){
                $age['bmi']  = $this->hdfc_check_bmi($trans_code); }
         // Super Top Up Age check
            if($product_type === 'S' && $mem_age > 56){
                $age['memage']= $mem_age;
                $age['value'] = 'true'; }
         // Basic plan Age check
            if($product_type === 'B' && ($mem_age >= 51 && ($suminsured != 300000 || $suminsured != 400000)) || ($mem_age >= 45 && ($suminsured == 300000 || $suminsured == 400000))) {
                $age['memage']= $mem_age;
                $age['value'] = 'true'; 
            } 
            return $age;
        }
        return false;
    }

    private function hdfc_check_bmi($trans_code){
        $usertdata = new HealthUserData();
        $columns = array('insurerName', 'height_feet', 'height_inches', 'weight', 'age_list','members_list','firstname','lastname');
        $data = $usertdata->getUserTData($trans_code,$columns);
        $age_checklist = array();
        $bmi_member    = array();
        $insurerId      = $data['insurerName'];
        $height_feet   = explode('|',$data['height_feet']);
        $height_inches = explode('|',$data['height_inches']);
        $weight        = explode('|',$data['weight']);
        $relationship  = explode('|',$data['members_list']);
        $age           = explode('|',$data['age_list']);
        $firstname     = explode('|',$data['firstname']);
        $lastname      = explode('|',$data['lastname']);
        //Loop for checking the child age
        foreach ($relationship as $key => $data) {
            if(strcmp($data, 'UDTR') == 0 || strcmp($data, 'SONM') == 0){
                //If child age > 17  adding him to bmi checklist
                if($age[$key] > 17){ $age_checklist[] = $key; }
            }else {
                $age_checklist[] = $key;
            }
        }   
        if(!empty($age_checklist)){
            $i = 0;
            foreach ($age_checklist as $key => $index) {
                $height= $this->convert_feet_to_cm($height_feet[$index],$height_inches[$index]);
                $bmi = $this->BMI_calculation($height,$weight[$index]);
                if($bmi < Health_Constants::BMI_LOWER_LIMIT || $bmi > Health_Constants::BMI_UPPER_LIMIT){
                    $bmi_member[$i]['insurerId'] = $insurerId;
                    $bmi_member[$i]['name'] = ucfirst($firstname[$index].' '.$lastname[$index]);
                    $bmi_member[$i]['height'] = $height_feet[$index].'&#39;'.$height_inches[$index];
                    $bmi_member[$i]['weight'] = $weight[$index].'Kg';
                    $bmi_member[$i]['bmi']    = $bmi;
                    $i++;
                }
            }
            return $bmi_member;
        }else { return null; }
    }

    private function convert_feet_to_cm($feet, $inches = 0){
        $ft     = $feet.'.'.$inches;
        $height = $ft * 30.48;
        return $height;
    }

    private function BMI_calculation($height, $weight){
        $bmi = ($weight/$height/$height) * 10000;
        return number_format((float)$bmi, 1, '.', '');
    }

    public function update_paymode($data){
        $usr_tbl  = new HealthUserData;
        $columns['pay_mode']  = $data['pay_mode'];
        $usr_tbl->set_by_usrdata($data['trans_code'],$columns);
        return json_encode(['status' => true]);
    }
    
    public function check_geo_restrictions($trans_code){
        try{
        $usertdata = new HealthUserData();
        $delhi_ncr = array('1296','1232','1496','1494','1495','386','1497','1498','1499','1500','1501','1502','1503','1504','271','382','1296');
        $pattern_array = array('20','21','22','23');
        $response['status'] = true;
        $columns = array('adult', 'children','city','sum_insured');
        $data = $usertdata->getUserTData($trans_code,$columns);
        $pattern = $data['adult'].$data['children'];
        if($data['sum_insured'] == '300000' || $data['sum_insured'] == '400000'){
            if(in_array($pattern, $pattern_array)){
                $response['status'] = (in_array($data['city'], $delhi_ncr)) ? false : true;
                $response['msg'] = '<p  id="msg_cancel" style="cursor:pointer;text-align: right;padding-right: 50px; color: white;">Close</p><br><h2 style="color: white!important;">Sorry!.</h2> This plan is not available for the city you selected with Sum Insured '.$data['sum_insured'].'<br> We recommend you to try 5 Lacs & above Sum Insured for purchasing.';
            }
        }    
        return $response;
        }catch(\Exception $e){
            Log::info('Health HdfcBe: check_geo_restrictions() '. print_r($e->getMessage(),true));
            $response['status'] = false;
            $response['msg'] = 'Server is not responding to geo-restriction check! <br>Try again after sometime';
            return $response;
        }
    }

    public function parse_campaign_pg_response($pg_response,$trans_code){
        $user_tbl = new HealthUserData();
        $status = (isset($pg_response['PolicyNo']) && $pg_response['PolicyNo'] == 0) ? false : true; 
        if( ($status != null) || ($pg_response['Msg'] == 'Successfull')){
          try{
          
            //Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);

            $table['policy_status'] = 'TS19';
            $table['payment_ref_number'] = '';
            $health_transaction = $user_tbl->update_or_create(array('trans_code' => $trans_code), $table);
            
            $user_data  = $user_tbl->get_by_tc($trans_code)->toArray();
            $result = HealthTPolicy::insert($user_data); 
            $columns = array();
            $columns = array('trans_code' => $trans_code.'_DONE');
            $check_values = array('trans_code' => $trans_code);
            $usr_tbl->update_data($column, $check_values);

          }catch (\Exception $e) {
            Log::info('HEALTH_HDFC_PG_RESPONSE - '.$trans_code.' - '. print_r($e->getMessage(), true));
          }
        } 

        return json_encode(['status'=> $status,   
               'pg_response' => $pg_response]); 
    }

}
