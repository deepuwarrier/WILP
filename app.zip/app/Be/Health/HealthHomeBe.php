<?php
namespace App\Be\Health;
use App\Http\Controllers\Health\HealthPolicy;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use App\Models\Health\HealthDeductables;
use App\Models\Health\data\QuoteRespData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use App\Models\Health\HealthUserData;
use Log;

class HealthHomeBe {	
	 
	public function __construct(){
	}

	public function get_campagin_detail_data($trans_code = null){
		$response = array();
		$usr_tbl = new HealthUserData;
		$response['initial_inputs'] = null;

		if($trans_code){
			$column = array('campaign_initial_inputs');
			$check_values = array('trans_code' => $trans_code);
			$user_data_resp = $usr_tbl->get_data($column, $check_values);

			if($user_data_resp)
				$response['initial_inputs'] = json_decode($user_data_resp[0]['campaign_initial_inputs'], true);
		}
		
		//Adult age
		for($i=18;$i<=55;$i++){
			$response['adult']['title'][] = $i.' Years';
			$response['adult']['value'][] = $i;
		}

		//Child
		for($i=3;$i<=11;$i++){
			$response['child']['title'][] = $i.' Months';
			$response['child']['value'][] = $i.'m';
		}
		for($i=1;$i<=23;$i++){
			$response['child']['title'][] = ( $i==1 )? $i.' Year' : $i.' Years';
			$response['child']['value'][] = $i;
		}

		//Parent
		for($i=36;$i<=55;$i++){
			$response['parent']['title'][] = $i.' Years';
			$response['parent']['value'][] = $i;
		}

		return $response;
	}

}	
