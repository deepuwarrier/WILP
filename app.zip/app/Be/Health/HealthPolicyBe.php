<?php
namespace App\Be\Health;

use App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use App\Models\Health\HealthUserData;
use Illuminate\Support\Facades\Session\Store;
use App\Constants\Health_Constants;
use App\Models\Travel\OtpTData;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\Health\HealthPED;
use App\Libraries\HealthLib;
use App\Http\Controllers\Health\HealthPolicy;
use App\Be\Health\HealthQuoteBe;
use App\Models\Health\data\QuoteRespData;
use App\Models\Health\HealthQuoteResponse;
use App\Helpers\Health\HDFC\HDFCPolicyHelper;
use App\Libraries\TravelLib;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Log;
use DateTime;

class HealthPolicyBe {
    public function __construct(){
    }
    
    public function get_campagin_customer_records($date){
        try{
        $usr_tbl           = new HealthUserData;
        $column            = array('id','mobile','email','firstname','lastname','campaign_customer_pointer','created_at','members_list');

        $search_from   = date('Y-m-d 00:00:00', strtotime($date['from_date']));
        $search_to     = date('Y-m-d 23:59:59', strtotime($date['to_date']));

        $tbl_response  = HealthUserData::whereBetween('created_at', [$search_from, $search_to])->whereNotNull('campaign_initial_inputs')->orderBy('id', 'DESC')->get($column)->toArray();

        $response = array();

            if($tbl_response){
                foreach ($tbl_response as $key => $value) {
                    $response[$key] = $value;
                    $response[$key]['firstname'] = explode('|', $value['firstname']);
                    $response[$key]['lastname'] = explode('|', $value['lastname']);
                    $response[$key]['created_at'] = date('d M Y, H:i:s', strtotime($value['created_at']));
                }
                return  array('status' => true, 'data' => $response, 'count' => count($tbl_response), 'date' => $date);   
            }
         return  array('status' => false, 'data' =>false, 'count' => 0, 'date' =>$date);      
        }catch(\Exception $e){
            return  array('status' => false, 'data' =>false, 'count' => 0, 'date' =>$date);  
        }
    }

    public function connect_campaign_pg($trans_code, $customer_acceptance){
        try{
        $usr_tbl = new HealthUserData;
        $hdfc_be = new HDFCBe();
        $quote_rsp_tbl = new HealthQuoteResponse;
        $hdfc_helper = new HDFCPolicyHelper();
        $usr_tbl_res = $usr_tbl->getUserTData($trans_code);

        // All these are adjustments made to the request due to un-structured and confusing existing code: added by sreehari Feb 01 2019
        $quote_data = $quote_rsp_tbl->getresponse($trans_code);
        $quote_data = $quote_data[0];
        $policy_date = $this->get_policy_date($usr_tbl_res['tenure']);
        $usr_tbl_res['hl_trans_code'] = $usr_tbl_res['trans_code']; 
        $usr_tbl_res['insurer_name'] =  $quote_data['insurerName'];
        $usr_tbl_res['product_id'] =  $quote_data['productId'];
        $usr_tbl_res['product_plan'] = $quote_data['plan_code'];
        $usr_tbl_res['membercount'] = count(explode('|', $usr_tbl_res['members_list']));
        $usr_tbl_res['policy_start'] = $policy_date['p_start'];
        $usr_tbl_res['policy_end'] = $policy_date['p_ends'];
        $usr_tbl_res['firstname'] = explode('|', $usr_tbl_res['firstname']);
        $usr_tbl_res['lastname'] = explode('|', $usr_tbl_res['lastname']);
        $usr_tbl_res['aadhaar_num'] = explode('|', $usr_tbl_res['aadhaar_num']);
        $usr_tbl_res['height_inches'] = explode('|', $usr_tbl_res['height_inches']);
        $usr_tbl_res['height_feet'] = explode('|', $usr_tbl_res['height_feet']);
        $usr_tbl_res['weight'] = explode('|', $usr_tbl_res['weight']);
        $usr_tbl_res['serviceTax'] = $quote_data['serviceTax'];
        $usr_tbl_res['basePremium'] = $quote_data['netPremium'];
        $usr_tbl_res['totalPremium'] = $quote_data['totalPremium'];
        $usr_tbl_res['cust_pincode'] = $usr_tbl_res['pincode'];
        $ped_list = json_decode($usr_tbl_res['ped_list'] , true);
        if($ped_list)
          $usr_tbl_res['pedname'] = isset($ped_list['pedname']) ? $ped_list['pedname'] : '';
        else
          $usr_tbl_res['pedname'] = '';
        // Medical checkup acceptance
        $usr_tbl_res['agree_med_chkup'] = $customer_acceptance;
        $proposal_req_data = $hdfc_be->set_proposal_data($usr_tbl_res, 'campaign');
        // All these are adjustments made to the request due to un-structured existing code

        $proposal_response = $hdfc_helper->get_proposal_response($proposal_req_data);
        $parsed_response = json_decode($proposal_response, true);
        $bmi_message = 0;

        if(is_bool ($parsed_response['status']) && $parsed_response['status'] == true){
            $parsed_response['hdnPayMode'] = $usr_tbl_res['pay_mode'];
        }else{
            if(($parsed_response['status'] == "false") && ($parsed_response['message'] == 'Customer-aceptance') ){
                $bmi_message = $hdfc_be->check_policy($trans_code);
                $parsed_response['message'] = 'bmi_error';
                $parsed_response['bmi_message'] = $bmi_message;
            }
        }
        
        //Returning to campaign ajax call - response is json
        return json_encode($parsed_response);

        }catch(\Exception $e){
            Log::info('HealthPolicyBe: connect_campaign_pg()'. print_r($e->getMessage(), true));
            return json_encode(['status' => false, 'error' => 'code-exception']);
        }
    }

    public function get_campaign_saved_customer_data($trans_code){
        try{
        $usr_tbl = new HealthUserData;
        $city_tbl = new HealthCity;
        $column = array('dob_list', 'firstname', 'lastname', 'height_feet', 'height_inches', 'weight', 'mobile','email', 'nominee_name', 'nominee_relation', 'aadhaar_num', 'state', 'city', 'pincode', 'locality', 'street', 'pay_mode', 'ped_list');
        $check_values = array('trans_code' => $trans_code);
        $u_response = $usr_tbl->get_data($column, $check_values);
        $response = array();
        if($u_response){
            $response = $u_response[0];
            $doblist  = array();
            $response['dob_list']  = explode('|', $response['dob_list']);
            foreach ($response['dob_list'] as $dob) {
                        $doblist[] = date('d-m-Y', strtotime($dob));
            }
            $response['dob_list']  = $doblist;
            $response['firstname'] = explode('|', $response['firstname']);
            $response['lastname']  = explode('|', $response['lastname']);
            $response['height_feet']  = explode('|', $response['height_feet']);
            $response['height_inches']  = explode('|', $response['height_inches']);
            $response['weight']  = explode('|', $response['weight']);
            $response['aadhaar_num']  = explode('|', $response['aadhaar_num']); 
            $response['state']  = $response['state'];
            $response['city']  =  $response['city'];
            $response['pincode']  = $response['pincode'];
            $response['locality'] = $response['locality'];
            $response['street']   =  $response['street'];
            $response['pay_mode'] =  $response['pay_mode'];
            $response['ped_list'] =  ($response['ped_list'] != null ) ? json_decode($response['ped_list'], true) : null;

            // Fetching city list for selected state
            if(!empty($response['state'])){
                $response['city_list'] = $city_tbl->get_city($response['state'], 'hdfc')->toArray();
            }

            return $response ;      
        }
        else
            return null;    
        }catch(\Exception $e){
            Log::info('HealthPolicyBe: get_campaign_saved_customer_data()', print_r($e->getMessage(), true));
            return null;
        }
    }
    
    public function get_campaign_proposal_cust_data($usr_data, $trans_code){
        try{
        $quote_be = new HealthQuoteBe;
        $members  = $quote_be->get_campaign_member_list($usr_data);
        $age_list = $quote_be->formatted_age_list($trans_code, 'proposal');
        $dob_list = $this->campaign_set_dob($age_list);

        $usr_tbl = new HealthUserData;
        $column  = array('campaign_initial_inputs'); 
        $check_values = array('trans_code' => $trans_code);
        $tbl_response = $usr_tbl->get_data($column, $check_values);
        if($tbl_response){
            $inputs = $tbl_response[0]['campaign_initial_inputs'];
            $inputs = json_decode($inputs, true);
            $gender_response = $quote_be->format_campaign_inputs($inputs, $trans_code);
            $genderlist  = implode('|', $gender_response['genderlist']);
            $title_list  = implode('|', $gender_response['title_list']);
            $column = array('gender' => $genderlist ,'title'=> $title_list);
            $check_values = array('trans_code' => $trans_code);
            $usr_tbl->update_data($column, $check_values);
        }

        // State List
        $state_db = new HealthState();
        $state_list = $state_db->get_state('hdfc_code');

        return array('member_list' => $members ,
                     'age_list' => $age_list,
                     'state_list' => $state_list,
                     'dob_list' =>$dob_list);
        }catch(\Exception $e){
            Log::info('HealthPolicyBe: get_campaign_proposal_cust_data()', print_r($e->getMessage(), true));
            return null;
        }
    }

    private function campaign_set_dob($age_list){
      $data['dob'] = array();
      foreach($age_list as $index => $age){
          $data['dob'][] = $this->campaign_dob_generator(rtrim($age,"Yrs"));
      }
      return $data['dob'];
    }
  
    public function campaign_dob_generator($age){
      $child_flag = false;
      $lib = new TravelLib;

      for($i=1; $i<12 ; $i++){
          if($age == $i.' Month'){ 
            $child_flag = true;
            $effectiveDate = strtotime("-".$i." months", strtotime(date("Y-m-d")));
            $birthdate = date("Y-m-d", $effectiveDate);
            $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
          }
      }

      if(!$child_flag){
        $birthdate = date("Y-m-d", strtotime($age. 'years ago'));
        $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
      } 
     
      $min_date = $lib->minus_year_from_date($data['selected_date'], '1');
      $data['min_date']  = $lib->add_days_with_date($min_date, '1');
      $data['max_date']  = $data['selected_date'];

      return $data;
    }

    public function save_campaign_data($data){
        try{
            $user_tbl  = new HealthUserData;
            $user_data = $user_tbl->get_by_usrdata($data['trans_code']);
            $section   = $data['tab_id'];

            if($section == 'INSURED_MEMBERS_'){
                $doblist = array();
                // Re-formating d-m-Y to Y-m-d
                if (isset($data['dob_list'])) { 
                    foreach ($data['dob_list'] as $dob) {
                        $doblist[] = date('Y-m-d', strtotime($dob));
                    }
                }
                $request_data['dob_list']  = implode('|', $doblist);
                #$request_data['age_list']  = $user_data['age_list'];
                $request_data['firstname'] = implode('|', $data['firstname']);
                $request_data['lastname']  = implode('|', $data['lastname']);
                $request_data['height_feet']  = implode('|', $data['height_feet']);
                $request_data['height_inches']  = implode('|', $data['height_inches']);
                $request_data['weight']  = implode('|', $data['weight']);
                $request_data['aadhaar_num']  = implode('|', $data['aadhaar_num']);
                $request_data['mobile']  = $data['mobile'];
                $request_data['email']  = $data['email'];
                $request_data['nominee_name']  = $data['nominee_name'];
                $request_data['nominee_relation']  = $data['nominee_relation'];
            }
            if($section == 'ADDRESS_'){
                $request_data['pincode'] = $data['pincode'];
                $request_data['street'] = $data['street'];
                $request_data['locality'] = $data['locality'];
                $request_data['state'] = $data['state'];
                $request_data['city'] = $data['city'];
            }

            if($section == 'MEDICAL_HISTORY_'){
                if($data['ped_qn'] == 'n'){
                    $pedlist = json_encode(
                                    array('ped' => array('illness' => '0')
                                    )
                                );
                    $request_data['ped_list'] = $pedlist;
                }else{
                    $ped['ped'] = array('illness' => '1');
                    $ped['pedname'] = $data['pedname'];
                    $request_data['ped_list'] = json_encode($ped);
                    //$ped_lifestyle = array('asdsada','','','');
                    //$request_data['ped_lifestyle'] = json_encode($ped_lifestyle);
                }
            }

            if($section == 'PAYMENT_'){
               $request_data['pay_mode'] = $data['payment_option'];
            }
            
            $response = $user_tbl->set_by_usrdata($data['trans_code'] ,$request_data);
            return json_encode(['status' => true]);
        }catch(\Exception $e){
            Log::info('HealthPolicyBe: save_campaign_data()', print_r($e->getMessage(), true));
            return json_encode(['status' => false]);
        }
    }

    public static function store_proposal_data(Request $request){
        $h_lib = new HealthLib();
        $user_db = new HealthUserData();
        $data = $request->all();
        $user_data = $user_db->get_by_usrdata($data['trans_code']);
        $hl_trans_code = $data['trans_code'];
        // Identifies the data from which TAB, Eg: Insured, Communication
        $section = $data['id'];
        // Unsetting the extra values
        unset($data['id']);
        unset($data['_token']);
        // Insured section
        if($section == 'insured'){
            $dob = array();
            // Re-formating d-m-Y to Y-m-d
            if (isset($data['dob_list'])) { 
                foreach ($data['dob_list'] as $dob) {
                    $doblist[] = date('Y-m-d', strtotime($dob));
                }
            }
        $gender_list = explode('|', $user_data['gender']);
        $replacements = array( 0 => $data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        $data['dob_list']  = implode('|', $doblist);
        $data['age_list']  = $user_data['age_list'];
        $data['gender'] = implode("|",$gender);
        $data['firstname'] = implode('|', $data['firstname']);
        $data['lastname']  = implode('|', $data['lastname']);
        $data['height_feet']  = implode('|', $data['height_feet']);
        $data['height_inches']  = implode('|', $data['height_inches']);
        $data['weight']  = implode('|', $data['weight']);

        }
        // Health History Section 
        if($section == 'healthhistory'){
            unset($data['trans_code']);
            $pedlist = json_encode($data);
            unset($data);
            $data['ped_list'] = $pedlist;
        }
        try {
            $health_transaction = $user_db->set_by_usrdata(array('trans_code' => $hl_trans_code),$data);
        } catch (Exception $e) {
            Log::info('HEALTH_HDFC_SAVE_PROPOSAL'. print_r($e->getMessage(), true));
        return 0;
        } 
    }



    public function parse_proposal_data($usr_data){
        $policy_date = $this->get_policy_date($usr_data['tenure']);
        $quote_resp = new QuoteRespData();
        $quote_resp->set_tenure($usr_data['tenure']);
        $quote_resp->set_policy_start($policy_date['p_start']);
        $quote_resp->set_policy_end($policy_date['p_ends']);
        $quote_resp->set_trans_code($usr_data['trans_code']);
        $quote_resp->set_product_id($usr_data['productId']);
        $quote_resp->set_product_plan($usr_data['plan_code']);
        $quote_resp->set_insurer_name($usr_data['insurerName']);
        $quote_resp->set_product_name($usr_data['productName']);
        $quote_resp->set_totalPremium($usr_data['totalPremium']);
        $quote_resp->set_cgst($usr_data['cgst']);
        $quote_resp->set_sgst($usr_data['sgst']);
        $quote_resp->set_premium($usr_data['basePremium']);
        $quote_resp->set_serviceTax($usr_data['serviceTax']);
        $quote_resp->set_plan_type($usr_data['plan_type']);
        $quote_resp->set_product_type($usr_data['product_type']);
        $quote_resp->set_deductible_amount($usr_data['deductables']);
        $quote_resp->set_sum_insured($usr_data['sum_insured']);
        $quote_resp->set_sumInsuredId($usr_data['sum_insuredid']);
        $quote_resp->set_schemeId($usr_data['scheme_id']);
        $quote_resp->set_planId($usr_data['plan_id']);
        $quote_resp->set_age_list(explode('|', $usr_data['age_list']));
        $quote_resp->set_gender(explode('|', $usr_data['gender']));
        $quote_resp->set_title(explode('|', $usr_data['title']));
        $members = explode('|', $usr_data['members_list']);
        foreach($members as $mem){
            if($mem == 'SELF'){$member_list[] = 'SELF'; }
            if($mem == 'WIFE'){$member_list[] = 'WIFE'; }
            if($mem == 'HUS'){$member_list[] = 'HUSBAND'; }
            if($mem == 'UDTR'){$member_list[] = 'DAUGHTER'; }
            if($mem == 'SONM'){ $member_list[] = 'SON'; }
            if($mem == 'FATH'){ $member_list[] = 'FATHER'; }
            if($mem == 'MOTH'){ $member_list[] = 'MOTHER'; }
        }
        $quote_resp->set_dob_list(explode('|',$usr_data['dob_list']));
        $quote_resp->set_members_list($member_list);
        $quote_resp->set_adult($usr_data['adult']);
        $quote_resp->set_children($usr_data['children']);
        $quote_resp->set_member_count(count(explode('|', $usr_data['members_list'])));
        $insurer_age = explode("|", $usr_data['age_list']) ;  
        $adult_age =''; $child_age ='';
        foreach($insurer_age as $memage){
            if($memage == '3m'){  $child_age .= '1-3 Months,'; }
            elseif($memage == '10m'){ $child_age .= '3-12 Months,'; }
            else{  if($memage <= 21){ $child_age .=  $memage.'Years,'; }
                    else{ $adult_age .=  $memage.'Years,'; } }
       }
       $quote_resp->set_insurer_age_list(trim($adult_age.''.$child_age, ','));
       $quote_resp->set_rsgi_QuoteId($usr_data['rsgi_quote_id']);
       $quote_resp->set_rsgi_hosp_cash($usr_data['rsgi_hosp_cash']);
        return $quote_resp;
    }

    public function get_policy_date($tenure){
        $tenure = $tenure.' year';
        $policy_date['p_start'] = date("d-m-Y", strtotime("+1 day"));
        $policy_date['p_ends']  = date("d-m-Y",strtotime("+".$tenure, strtotime($policy_date['p_start']." -1 day")));
        return $policy_date;
    }

    public function convert_feet_to_cm($feet, $inches = 0){
        $ft     = $feet.'.'.$inches;
        $height =  $ft * 30.48;
        return $height;
    }

    // Claculate Body Mass Index height in cm & weight in Kg
    public function BMI_calculation($height, $weight){
        $bmi = ($weight/$height/$height) * 10000;
        return number_format((float)$bmi, 1, '.', '');
    }

    public function needConfirmation($required, $passed) {
        logger("Required Total Prcie is " . $required . " and we are passing " . $passed);
        $required_confirmation = 1;
        $allowed = Health_Constants::PREMIUM_MISSMATCHALLOWED_UP_TO;
        $add = 0;
        if ($passed < $required) {
            $check = $required - $passed;
            $add = 1;
        }else{
            $check = $passed - $required;
        }
        logger("Toatal Diff Is " . $check);
        if ($check <= $allowed) {
            $required_confirmation = 0;
        }
        return $required_confirmation;
    }

    public function get_uid($mobile){
        $result =  OtpTData::select('otp_id')->where('mobile', $mobile)->get(); 
        if ($result->isEmpty()) {
            return '0124';
        }else {
            return $result[0]['otp_id'];
        }
    }

    private function get_policy_details($insurerId, $age, $SI, $product_type = null) {
        foreach($age as $mem_age){
            if($insurerId == 'religare'){ 
                if($mem_age >= 55 || $SI >= 2500000){ 
                    return true;  }  
            }
        }
        return false;
    }

    public function get_proposal_inputs($trans_code, $company){
        $usertdata = new HealthUserData();
        $state_list = new HealthState();
        $city_list = new HealthCity();
        $h_quote_be = new HealthQuoteBe();
        $data['userdata']  = $usertdata->getUserTData($trans_code);
        if($data['userdata']['insurerName'] == 'Religare Health'){
            $data['religare_prd'] = true;
        }
        // Setting lists
        $data['userdata']['dob_list']     = explode('|' , $data['userdata']['dob_list']);
        $data['userdata']['age_list']     = explode('|' , $data['userdata']['age_list']);
        $data['userdata']['members_list'] = explode('|' , $data['userdata']['members_list']);
        $data['userdata']['gender']       = explode('|' , $data['userdata']['gender']);
        $data['userdata']['title']        = explode('|' , $data['userdata']['title']);
        $data['userdata']['firstname']    = explode('|' , $data['userdata']['firstname']);
        $data['userdata']['lastname']     = explode('|' , $data['userdata']['lastname']);
        try{
            $statecompany = ($company == 'usgi_code') ? 'bagi_code': $company;
            $data['state_list']= $state_list->get_state($statecompany)->toArray();
        }catch(\Exception $e){
            $data['state_list'] = null;
        }
        try{
            $citycompany = ($company == 'usgi_code') ? 'bagi': $company;
            $data['city_list'] = (!empty($data['userdata']['state'])) ? $city_list->get_city($data['userdata']['state'],$citycompany)->toArray() : null;
        }catch(\Exception $e){
            $data['city_list'] = null;
        }
        try{
        $data['userdata']['insurer_name'] = $data['userdata']['insurerId'];
        }catch(\Exception $e){
            $data['userdata']['insurer_name'] = null;
        }
        if($company == "star_code") {
            $company_rel = $this->get_nominee_relations($data['userdata']['productId']);
            $nominee =  $company_rel;
        }
        $nominee_code = isset($nominee) ? $nominee : $company ;

        $h_relation = new HealthRelationship();
        $h_nominee = new NomiRelationship();
        $data['relation_members']      = $h_relation->getRelationship($nominee_code);
        $data['nominee_rel']           = $h_nominee->getNomRelationship($nominee_code);
        $data['policy_dates']          = $this->get_policy_date($data['userdata']['tenure']);

        $h_occupation = new HealthOccupation();
        try{
            $data['members_occupation'] = $h_occupation->getOccupations($company);
        }catch(\Exception $e){
            $data['members_occupation'] = null;
        }
        $data['policy_details'] = $this->get_policy_details($data['userdata']['insurerId'],$data['userdata']['age_list'], $data['userdata']['sum_insured'], $data['userdata']['product_type']);

        $h_ped = new HealthPED();
        try{
            $data['pedlist'] = $h_ped->get_ped_list($company,'ped');
        }catch(\Exception $e){
            $data['pedlist'] = null;
        }

        try{
            $data['ped_lifestyle'] =  $h_ped->get_ped_list($company,'lifestyle');
        }catch(\Exception $e){
            $data['ped_lifestyle'] = null;
        }

        $h_policy = new HealthPolicy();
        try{
            $data['covers'] = $h_policy->getCovers($data['userdata'],$data['userdata']['productId']);
        }catch(\Exception $e){
            $data['covers'] = null;
        }

        return $data;
    }


    public function set_dob_list($data){
        $age_list = $data->get_age_list();
        $dob_list = array();
        foreach($age_list as $index => $age){
            $dob_list[] = $this->dob_generator(rtrim($age,"Y"));
            }
        return $dob_list;
    }

    public function dob_generator($age){
        $child_flag = false;
        $lib = new HealthLib;
        for($i=1; $i<12 ; $i++){
            if($age == $i.'m'){
                $i = ($i == 10) ? 12: $i;
                $child_flag = true;
                $current_date = new DateTime();
                $effectiveDate = strtotime("-".$i." months", strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['min_date']  = $data['selected_date'];
                $data['max_date']  = $current_date->format('d-m-Y');
            }
        }
        if(!$child_flag){
            $birthdate = date("Y-m-d", strtotime($age. 'years ago'));
            $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
            $min_date = $lib->minus_year_from_date($data['selected_date'], '1');
            $data['min_date']  = $lib->add_days_with_date($min_date, '1');
            $data['max_date']  = $data['selected_date'];
        } 
        return $data;
    }


}
