<?php
namespace App\Be\Health;
use App\Http\Controllers\Health\HealthPolicy;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use App\Models\Health\HealthDeductables;
use App\Models\Health\data\QuoteRespData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use App\Libraries\InstaLib;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthQuoteResponse;
use App\Models\Health\HealthCovers;
use App\Models\Health\HealthBenifit;
use App\Models\Health\HealthSumInsured;
use App\Helpers\Health\QuoteHelper;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\Star\StarQuoteHelper;
use App\Helpers\Health\RSGI\RSGIQuoteHelper;
use App\Helpers\Health\HDFC\HDFCQuoteHelper;
use App\Helpers\Health\Reliance\RelianceQuoteHelper;
use App\Helpers\Health\Religare\ReligareQuotes;
use App\Be\Health\HealthQuoteBe;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\HDFCBe;
use Log;

class HealthQuoteBe {	
	 
	public function __construct(){
	}

	public function format_campagin_quote_response($response, $trans_code){
		$image_array = $this->get_campaign_member_images($trans_code);
		$lib = new HealthLib;
		return array('sum_insured' =>  $lib->format_number( $response->get_sum_insured() ),
				     'deductible' => $lib->format_number( $response->get_deductible_amount() ), 
				     'premium' => $lib->format_number( round($response->get_totalPremium()) ),
				     'member_image_array' =>  $image_array,
				     'formatted_agelist' => $this->formatted_age_list($trans_code, 'quote')
					);
	}

	public function formatted_age_list($trans_code, $type){
		$user_tbl = new HealthUserData();
		$column   = array('age_list');
		$check_values   = array('trans_code' => $trans_code);
		$tbl_response = $user_tbl->get_data($column, $check_values);
		$age_list = $tbl_response[0]['age_list'];
		$age_list = explode('|', $age_list);
		$response = array();
		foreach ($age_list as $key => $age) {
			$response[$key] = $age.' Yrs';
			for($i=1; $i<=11; $i++){
				if($age == $i.'m')
					$response[$key] = ($type == 'quote') ? $i.' M' : $i.' Months';
			}
		}

		return $response;
	}

	public function get_campaign_member_images($trans_code){
		$user_tbl = new HealthUserData();
		$column   = array('campaign_initial_inputs');
		$check_values   = array('trans_code' => $trans_code);
		$response = $user_tbl->get_data($column, $check_values);
		$response = json_decode($response[0]['campaign_initial_inputs'], true);
		$image_array = array();
		if(isset($response['male_age']))
			$image_array[] = 'campaign_assets/images/people/round/male.png';
		if(isset($response['female_age']))
			$image_array[] = 'campaign_assets/images/people/round/female.png';
		if(isset($response['son_age']))
			$image_array[] = 'campaign_assets/images/people/round/son.png';
		if(isset($response['daughter_age']))
			$image_array[] = 'campaign_assets/images/people/round/daughter.png';
		if(isset($response['father_age']))
			$image_array[] = 'campaign_assets/images/people/round/father.png';
		if(isset($response['mother_age']))
			$image_array[] = 'campaign_assets/images/people/round/mother.png';

		return $image_array;
	}

	public function format_campaign_inputs($data, $trans_code){
		$memberslist =  array(); $agelist = array(); $genderlist = array();
		$title_list  = array();

		if(sizeof($data) == 3){
			$memberslist[] = 'SELF';
			$agelist[] = ($data['self'] == 'male') ? $data['male_age'] : $data['female_age'];
			$genderlist[] = ($data['self'] == 'male') ? 'M' : 'F';
			$title_list[] = ($data['self'] == 'male') ? 'Mr' : 'Ms'; 
		}

		if(sizeof($data) > 3){
			$memberslist = array('SELF');
			if(isset($data['male_age']) && isset($data['female_age'])){
				if($data['self'] == 'male'){
					$memberslist[] = 'WIFE';
					$agelist[] = $data['male_age'];
					$agelist[] = $data['female_age'];
					$genderlist[] = 'M';
					$genderlist[] = 'F';
			        $title_list[] = 'Mr';
			        $title_list[] = 'Ms';
				}
				if($data['self'] == 'female'){
					$memberslist[] = 'HUS';
					$agelist[] = $data['female_age'];
					$agelist[] = $data['male_age'];
					$genderlist[] = 'F';
					$genderlist[] = 'M';
			        $title_list[] = 'Ms';
			        $title_list[] = 'Mr';
				}
		    }else{
		    	if($data['self'] == 'male'){
		    		$agelist[] = $data['male_age'];
		    		$genderlist[] = 'M';
			        $title_list[] = 'Mr';
		    	}

		    	if($data['self'] == 'female'){
		    		$agelist[] = $data['female_age'];
		    		$genderlist[] = 'F';
			        $title_list[] = 'Mrs';
		    	}
		    }


		    if(isset($data['son_age'])){
		    	    $memberslist[] = 'SONM';
		    	    $agelist[] = $data['son_age'];
		    	    $genderlist[] = 'M';
			        $title_list[] = 'Mr';
		    }
		    if(isset($data['daughter_age'])){
		    	    $memberslist[] = 'UDTR';
		    	    $agelist[] = $data['daughter_age'];
		    	    $genderlist[] = 'F';
			        $title_list[] = 'Ms';
		    }
		    if(isset($data['father_age'])){
		    	    $memberslist[] = 'FATH';
		    	    $agelist[] = $data['father_age'];
		    	    $genderlist[] = 'M';
			        $title_list[] = 'Mr';
			        
		    }
		    if(isset($data['mother_age'])){
		    	    $memberslist[] = 'MOTH';
		    	    $agelist[] = $data['mother_age'];
		    	    $genderlist[] = 'F';
			        $title_list[] = 'Mrs';
		    }

		}

		return array('sum_insured' => '2000000',
			         'deductables' => '500000',
				     'pincode' => '560001',
				     'trans_code' => $trans_code,
				     'memberslist' => $memberslist,
				     'genderlist' => $genderlist,
				     'title_list' => $title_list,
				     'product_type' => 'S', 
				     'plan_type' => (sizeof($data) > 3) ? 'FF' : 'INDV',
				     'tenure' => '1',
					 'agelist' => $agelist);	
		
	}

	public function get_campaign_member_list($data){
		$memberslist =  array();
		if(sizeof($data) == 3){
			$memberslist[] = 'Self';
		}
		if(sizeof($data) > 3){
			$memberslist = array('Self');
			if(isset($data['male_age']) && isset($data['female_age'])){
				if($data['self'] == 'male')
					$memberslist[] = 'Wife';

				if($data['self'] == 'female')
					$memberslist[] = 'Husband';
		    }

		    if(isset($data['son_age'])){
		    	    $memberslist[] = 'Son';
		    }
		    if(isset($data['daughter_age'])){
		    	    $memberslist[] = 'Daughter';
		    }
		    if(isset($data['father_age'])){
		    	    $memberslist[] = 'Father';
		    }
		    if(isset($data['mother_age'])){
		    	    $memberslist[] = 'Mother';
		    }

		}

      return $memberslist;		
	}

	public function get_campaign_age_list($data){
		$agelist = array();

		if(sizeof($data) == 3){
			$agelist[] = ($data['self'] == 'male') ? $data['male_age'] : $data['female_age'];
		}

		if(sizeof($data) > 3){
			if(isset($data['male_age']) && isset($data['female_age'])){
				if($data['self'] == 'male'){
					$agelist[] = $data['male_age'];
					$agelist[] = $data['female_age'];
				}
				if($data['self'] == 'female'){
					$agelist[] = $data['female_age'];
					$agelist[] = $data['male_age'];
				}
		    }else{
		    	if($data['self'] == 'male')
		    		$agelist[] = $data['male_age'];

		    	if($data['self'] == 'female')
		    		$agelist[] = $data['female_age'];
		    }

		    if(isset($data['son_age'])){
		    	    $agelist[] = $data['son_age'];
		    }
		    if(isset($data['daughter_age'])){
		    	    $agelist[] = $data['daughter_age'];
		    }
		    if(isset($data['father_age'])){
		    	    $agelist[] = $data['father_age'];
		    }
		    if(isset($data['mother_age'])){
		    	    $agelist[] = $data['mother_age'];
		    }

		}

      return $agelist;		
	}


    /* For the campaign*/

	public function get_quotes($data, $trans_code){
        $usertdata = new HealthUserData();
        $h_helper = new HealthHelper();
        $h_lib = new HealthLib();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        if(isset($data['update_cust_choice']) && $data['update_cust_choice'] == '1'){
            
            $this->updateQuotesChoices($data, $trans_code);
            $userdata = $usertdata->getUserTData($trans_code);
            $usrcovers = explode('|', $userdata['cover_id']);
            $a = in_array('AMBUL', $usrcovers);
            foreach($usrcovers as $key => $val){
                if($a === true && $val != "AMBUL"){
                    unset($usrcovers[$key]);
                }
            } 
            if(isset($data['deductibles'])){ $deductible = $data['deductibles'];}
            if(isset($data['deductables'])){ $deductible = $data['deductables'];}
            $input['deductables'] = ($data['product_type'] == 'S') ? $deductible : null ;
            $input['sum_insured'] = isset($data['sum_insured']) ? $data['sum_insured'] : $data['suminsured'];
            $input['rsgi_hosp_cash'] = 'off';
            $input['cover_id'] = implode('|', $usrcovers);
            $input['quote_update_date'] = $curr_date;
            $input['quote_status'] = 'TS11';
            $input['trans_status'] = 'TS11';
            $check_values = array('trans_code'=>$userdata['trans_code']);
            $usertdata->update_data($input, $check_values);
            $attributes = $usertdata->getUserTData($trans_code);
            HealthQuoteResponse::truncate();
        } else{ 
            $userdetails = $h_lib->getUserdata($data);
            $userdetails['quote_create_date'] = $curr_date;
            $userdata = $this->storeUserData($userdetails);
            $attributes = $userdata['attributes']; 
 
        }
            $si_list = new HealthSumInsured();
            $attributes['sum_insured_list'] = $si_list->get_suminsured_amount();
            $deductible_list = new HealthDeductables();
            $attributes['deductible_list'] = $deductible_list->get_deductible_list();
            return $attributes;
	}

	private function updateQuotesChoices($data, $trans_code) {
        $usertdata = new HealthUserData();
        $policy_be = new HealthPolicyBe();
        $policy_date = $policy_be->get_policy_date($data['tenure']);
        $input['plan_type']  = $data['plan_type'];
        $input['deductables'] = isset($data['deductables'])? $data['deductables'] : null;
        $input['sum_insured'] = isset($data['suminsured']) ? $data['suminsured'] : '';
        $input['product_type'] = isset($data['product_type'])?$data['product_type'] :'B';
        $input['tenure'] = $data['tenure'];
        $input['policy_start_date'] = date("j-M-Y", strtotime($policy_date['p_start']));
        $input['policy_exp_date'] = date("j-M-Y", strtotime($policy_date['p_ends']));
        $check_values = array('trans_code'=> $trans_code);
        $usertdata->update_data($input, $check_values);
        return $input;
    }

	public function storeUserData($data) {
        $h_helper = new HealthHelper();
        $usertdata = new HealthUserData();
        $policy_be = new HealthPolicyBe();
        $policy_date = $policy_be->get_policy_date($data['tenure']);
        $input['quote_create_date'] = $data['quote_create_date'];
        $input['quote_status'] = 'TS10';
        $input['trans_status'] = 'TS10';
        $input['plan_type'] = $data['productType'];
        $input['product_type'] = (isset($data['selected_product'])) ? $data['selected_product'] : 'B';
        $input['age_list'] = $data['agelist'];
        $input['dob_list'] = $data['doblist']['doblist'];
        $input['members_list'] = $data['memberslist'];
        $input['gender'] = $data['genderlist']['genders'];
        $input['title'] = $data['genderlist']['title'];
        $input['adult'] = $data['doblist']['adult'];
        $input['children'] = $data['doblist']['children'];
        $input['tenure'] = $data['tenure'];
        $input['policy_start_date'] = date("j-M-Y", strtotime($policy_date['p_start']));
        $input['policy_exp_date'] = date("j-M-Y", strtotime($policy_date['p_ends']));
        $input['sum_insured'] = $data['suminsured'];
        $input['pincode'] = $data['pincode'];
        $input['cover_id'] = 'AMBUL';
        $input['rsgi_hosp_cash'] = 'off';
        $input['session_id'] = $data['trans_code'];
        $input['trans_code'] = $data['trans_code'];
        $input['user_code'] = session("user_agent") != true ? session("user_code") : null;
        $input['agent_code'] = session("user_agent") == true ? session("user_code") : null;
        return $usertdata->update_or_create(['trans_code'=>$data['trans_code']],$input);
    }

	public function get_deductables($deductables, $si, $insurer_code){
		$h_deduct_mod = new HealthDeductables();
		$plans = $h_deduct_mod->get_deductable_plans($deductables, $insurer_code);
		$company_si = explode('|', $plans[$insurer_code]);
		$result     = '';
	    foreach($company_si as $value){
			//does an exact match exist?
			if(!empty($value)){
		    if($si == $value){
				return $value; 
			} else {
				//get absolute value of difference
				$diff = abs($si-$value); 
        		if (!isset($closeness) || (isset($closeness) && $closeness>$diff)) {
            		$closeness = $diff;
            		$result    = $value;
        		}
			} }
		}
		return $result; 
	}

	public function get_benifit_plans($pro_Id, $SI){
		// Reliance Plans
		if($pro_Id == 'HealthGain') {return 'reliance';}

	    // Religare Super Top Up
		if($pro_Id == 'INRELSTP'){ return 'religare_enhance'; }	

        // Hdfc Super Top Up
		if(substr( $pro_Id, 0, 3 ) === 'HST'){ return 'hdfc_s_topup'; }

		// Royal Sundaram Plans
		if($pro_Id == 'Classic'){  return 'rsgi_classic'; }
		if($pro_Id == 'Supreme'){ return 'rsgi_supreme'; }
		if($pro_Id == 'Elite'){  return 'rsgi_elite'; }

		//Star Medi classic Plans
		if($pro_Id == 'MCINEW') {
			if($SI == '150000' || $SI == '200000'){ $benifit_plan = 'star_mci_1'; }
			if($SI == '300000' || $SI == '400000' || $SI == '500000'){ $benifit_plan = 'star_mci_2'; }
			if($SI == '1000000' || $SI == '1500000'){ $benifit_plan = 'star_mci_3'; }
			return $benifit_plan; 
		}
		//Star FHO Plans
		if($pro_Id == 'FHONEW'){
			if($SI == '200000' || $SI == '300000' || $SI == '400000' || $SI == '500000'){ $benifit_plan = 'star_fho_1'; }
			if($SI == '1000000' || $SI == '1500000' || $SI == '2000000' || $SI == '2500000'){ $benifit_plan = 'star_fho_2'; } 
			return $benifit_plan;
		}
		// Star Comprensive Plans
		if($pro_Id == 'COMPREHENSIVEIND' || $pro_Id == 'COMPREHENSIVE'){
			if($SI == '500000') { $benifit_plan = 'star_comp_1'; }
			if($SI == '750000') { $benifit_plan = 'star_comp_2'; }
			if($SI == '1000000'){ $benifit_plan = 'star_comp_3'; } 
			if($SI == '1500000'){ $benifit_plan = 'star_comp_4'; }
			if($SI == '2000000'){ $benifit_plan = 'star_comp_5'; }
			if($SI == '2500000'){ $benifit_plan = 'star_comp_6'; } 
			return $benifit_plan;
		}

		// Star Senior citizan Plans
		if($pro_Id == 'REDCARPET'){
			$benifit_plan = 'star_red_1';  
			return $benifit_plan;
		}

		// Star Diabetes Plans
		if($pro_Id == 'DIABETESIND' || $pro_Id == 'DIABETESFMLY'){
			$benifit_plan = 'star_diabetes_1';
			return $benifit_plan;
		}

		//  HDFC Helath Suraksha Silver Plans
     	if(substr( $pro_Id, 0, 3 )  == 'HSS' || substr( $pro_Id, 0, 3 )  == 'HS1'){
     		if($SI =='100000' || $SI == '200000' || $SI == '300000'){ $benifit_plan = 'hdfc_silver_1'; }
		   if($SI == '400000' || $SI == '500000'){ $benifit_plan = 'hdfc_silver_2'; }
		   if($SI == '750000' || $SI == '1000000' || $SI == '1500000' || $SI == '2000000'){ $benifit_plan = 'hdfc_silver_3'; }
		   return $benifit_plan;
		}
		// HDFC Health Suraksha Silver Regain plans
		if(substr( $pro_Id, 0, 3 )   == 'SRE'){
		   if($SI =='100000' || $SI == '200000' || $SI == '300000'){ $benifit_plan = 'hdfc_silver_regain_1'; }
		   if($SI == '400000' || $SI == '500000'){ $benifit_plan = 'hdfc_silver_regain_2'; }
		   if($SI == '750000' || $SI == '1000000' || $SI == '1500000' || $SI == '2000000'){ $benifit_plan = 'hdfc_silver_regain_3'; }
		   return $benifit_plan;
		}
		// HDFC Health Suraksha Gold Regain  plans
		if(substr( $pro_Id, 0, 3 )  == 'GRE'){
			if($SI == '100000' || $SI == '200000' || $SI == '300000'){ $benifit_plan = 'hdfc_gold_regain_1'; }
			if($SI == '400000' || $SI == '500000'){ $benifit_plan = 'hdfc_gold_regain_2'; }
			if($SI == '750000' || $SI == '1000000' || $SI =='1500000'){$benifit_plan = 'hdfc_gold_regain_3'; }
			return $benifit_plan;
		}
		// HDFC Health Suraksha Gold plans
		if(substr( $pro_Id, 0, 3 ) == 'HSG' || substr( $pro_Id, 0, 3 ) == 'HG1'){
			if($SI == '100000' || $SI == '200000' || $SI == '300000'){ $benifit_plan = 'hdfc_gold_1'; }
			if($SI == '400000' || $SI == '500000'){ $benifit_plan = 'hdfc_gold_2'; }
			if($SI == '750000' || $SI == '1000000' || $SI =='1500000'){$benifit_plan = 'hdfc_gold_3'; }
			return $benifit_plan;
		}
	 	// Unisompo Plans
		if($pro_Id == '134HL03F01' || $pro_Id == '134HL04I01'){
			if($SI == '100000' || $SI == '200000'){ $benifit_plan = 'sompo_1'; }
			if($SI == '300000' || $SI == '400000' || $SI == '500000'){ $benifit_plan = 'sompo_2'; }
			if($SI == '600000' || $SI == '700000' || $SI == '800000' || $SI == '900000' || $SI == '1000000') { $benifit_plan = 'sompo_3'; }
			return $benifit_plan;
		}
		// Bharti AXA Plans
		if($pro_Id == '139HL01F01' || $pro_Id == '139HL01F02' || $pro_Id == '139HL01F03'){
		    $benifit_plan = 'bhartiaxa_1'; 
			return $benifit_plan;
		}
		//Religare Basic Plan - pro_id & table column name are same
		return $pro_Id;
	}

	public function set_filter_quote_resp($resp){
		$quote_resp_data = new QuoteRespData();
		$quote_resp_data->set_trans_code($resp['trans_code']);
		$quote_resp_data->set_product_id($resp['productId']);
		$quote_resp_data->set_product_name($resp['productName']);
		$quote_resp_data->set_insurer_name($resp['insurerId']);
		$quote_resp_data->set_sum_insured($resp['planSI']);
		$quote_resp_data->set_sumInsuredId($resp['star_suminsured_id']);
		$quote_resp_data->set_schemeId($resp['star_scheme_id']);
		$quote_resp_data->set_premium($resp['netPremium']);
		$quote_resp_data->set_serviceTax($resp['serviceTax']);
		$quote_resp_data->set_totalPremium($resp['totalPremium']);
		$quote_resp_data->set_product_type($resp['productType']);
		$quote_resp_data->set_insurer_code(strtoupper($resp['insurerId']));
		return $quote_resp_data;
	}

	public function get_grp_product($product_type,$group_name = NULL,$product_id = NULL){
		if($product_type != 'S')
			$products =["hdfc"=>["SRE"=>["name"=>"Health Suraksha Plus Regain Silver","logo"=>"hdfc_logo.png"]
							,"GRE"=>["name"=>"Health Suraksha Plus Regain Gold","logo"=>"hdfc_logo.png"]
							,"HSG"=>["name"=>"Health Suraksha Plus Gold","logo"=>"hdfc_logo.png"]
							,"HG1"=>["name"=>"Health Suraksha Plus Gold","logo"=>"hdfc_logo.png"]
							,"HSS"=>["name"=>"Health Suraksha Plus Silver","logo"=>"hdfc_logo.png"]
							,"HS1"=>["name"=>"Health Suraksha Plus Silver","logo"=>"hdfc_logo.png"]
					]
					,'rsgi'=>['Classic' => ['name'=>'LifeLine Classic','logo'=>'rsgi_logo.png']
		  					,'Supreme' => ['name'=>'LifeLine Supreme','logo'=>'rsgi_logo.png']
		  					,'Elite'  =>  ['name'=>'LifeLine Elite','logo'=>'rsgi_logo.png']
					]
					,'star'=>['MCINEW' => ['name'=>'Medi classic','logo'=>'star_logo.png']
							,'COMPREHENSIVEIND' => ['name'=>'Comprehensive Individual','logo'=>'star_logo.png']
							,'COMPREHENSIVE' => ['name'=>'Comprehensive Floater','logo'=>'star_logo.png']
							,'FHONEW' => ['name'=>'Family Health Optima','logo'=>'star_logo.png']
							,'REDCARPET' => ['name'=>'Senior Citizens Redcarpet','logo'=>'star_logo.png']
							,'DIABETESIND' => ['name'=>'Diabetes Safe Individual' ,'logo'=>'star_logo.png']
							,'DIABETESFMLY' => ['name'=>'Diabetes Safe Floater','logo'=>'star_logo.png']
					]
					,'religare'=> ['religare_elite' => ['name'=> 'Elite','logo'=>'religare_logo.png']
			  					,'religare_care' => ['name'=> 'Care','logo'=>'religare_logo.png']			
			  		]
		];
		else
			$products = ['hdfc'=>['HST'=>['name'=>'Health Medisure Super Top Up','logo'=>'hdfc_logo.png']]
						,'religare'=>['INRELSTP' => ['name'=> 'Enhance 1','logo'=>'religare_logo.png']]
						,'rsgi'=>['Classic' => ['name'=>'LifeLine Classic','logo'=>'rsgi_logo.png']
		  					,'Supreme' => ['name'=>'LifeLine Supreme','logo'=>'rsgi_logo.png']
							]
						];		
					
		if(isset($group_name) && isset($product_id))
			return (array_key_exists($group_name,$products) && array_key_exists($product_id,$products[$group_name]))
				? $products[$group_name][$product_id] : [];

		if(isset($group_name))
			return (array_key_exists($group_name,$products))
			? $products[$group_name] : [];

		return $products;
	}

	public function get_products($product_type){
		$products = [];
		$grp_products = $this->get_grp_product($product_type);
		foreach ($grp_products as $key => $product)
			$products = array_merge($products,$product);
		unset($grp_products);
		return $products;
	}
}
