<?php
namespace App\Be\Health;
use App\Models\Health\data\QuoteReqData;
use App\Models\Health\data\QuoteRespData;
use App\Models\Health\data\PolicyPageData;
use App\Constants\Health_Constants;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthRelationship;
use App\Libraries\HealthLib;
use GuzzleHttp\Client;
use DateTime;
use Log;

class RSGIBe {

    public function __construct(){
    }

    public function set_quote_request($user_data){
        $quote_be = new HealthQuoteBe();
        $quote_req_data = new QuoteReqData();
        $quote_req_data->set_trans_code($user_data['trans_code']);
        $quote_req_data->set_pincode($user_data['pincode']);
        $quote_req_data->set_members_list(explode('|',$user_data['members_list']));
        $quote_req_data->set_dob_list(explode('|',$user_data['dob_list']));
        $quote_req_data->set_age_list(explode('|',$user_data['age_list']));
        $quote_req_data->set_adult($user_data['adult']);
        $quote_req_data->set_children($user_data['children']);
        $quote_req_data->set_tenure($user_data['tenure']);
        $quote_req_data->set_sum_insured($user_data['sum_insured']);
        $quote_req_data->set_plan_type($user_data['plan_type']);
        $quote_req_data->set_product_type($user_data['product_type']);
        $quote_req_data->set_city($user_data['city']);
        $quote_req_data->set_firstname($user_data['firstname']);
        $quote_req_data->set_email($user_data['email']);
        $quote_req_data->set_mobile($user_data['mobile']);
        $quote_req_data->set_rsgi_hosp_cash($user_data['rsgi_hosp_cash']);
        if($user_data['product_type'] == 'S'){
            $suminsured = $quote_be->get_deductables($user_data['deductables'],$user_data['sum_insured'],'rsgi_code');
            $quote_req_data->set_sum_insured($suminsured);
            $quote_req_data->set_super_topup_opted('On');
            $quote_req_data->set_deductible_amount($user_data['deductables']);
        } else { 
            $quote_req_data->set_super_topup_opted('off');
            $quote_req_data->set_deductible_amount('0');
        }
        $quote_req_data->set_rsgi_international_treatment_opted($user_data['rsgi_international_treatment']);
        return $quote_req_data;
    }

    public function product_map($data_obj){
        $return_arr = [
            "Classic" => $this->classic_plan($data_obj),
            "Supreme" => $this->supreme_plan($data_obj),
            "Elite" => $this->elite_plan($data_obj),
        ];
        return $return_arr;
    }

    private function classic_plan($data){
        $rsgi_plans = $this->get_rsgi_plans($data->get_sum_insured());
        if(isset($rsgi_plans['Classic']) && $data->get_adult() <= 2) {
            return true;
        }
        return false;
    }

    private function supreme_plan($data){
        $rsgi_plans = $this->get_rsgi_plans($data->get_sum_insured());
        if(isset($rsgi_plans['Supreme']) && $data->get_adult() <= 2) {
            return true;
        }
        return false;
    }

    private function elite_plan($data){
        $rsgi_plans = $this->get_rsgi_plans($data->get_sum_insured());
        if(isset($rsgi_plans['Elite']) && $data->get_adult() <= 2) {
            return true;
        }
        return false;
    }

    private function get_rsgi_plans($si){
        $plan_sum_insured = [
            'Classic' => [200000, 300000, 400000],
            'Supreme' => [500000, 1000000, 1500000, 2000000, 5000000],
            'Elite'   => [2500000, 3000000, 5000000, 10000000, 15000000],
        ];
        $plan_type = array();
        foreach($plan_sum_insured as $key => $sum_insured){
            foreach($sum_insured as $id => $amount){
                if($si == $amount){
                    $plan_type[$key] = $amount; 
                } 
            }
        }
        return $plan_type;
    }

    public function populate_quote_request($quote_req_data){  
        $members = $this->calculate_adults_childs_age($quote_req_data->get_age_list(),$quote_req_data->get_members_list());
        $user_data = $this->set_default_proposer_details($quote_req_data);
        $city_db = new HealthCity();
        $city = $city_db->get_city_name($user_data['city'], 'rsgi_code');
        // Calculate elder member dob from age list
        foreach($quote_req_data->get_age_list() as $agelist){
            $age[] = rtrim($agelist,'m');
        }
        $elder_age = max($age);
        $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
        $hospitalcash = (!empty($quote_req_data->get_rsgi_hosp_cash())) ? $quote_req_data->get_rsgi_hosp_cash(): 'off' ; 
        $opttopupOpted = (!empty($quote_req_data->get_super_topup_opted())) ? $quote_req_data->get_super_topup_opted(): 'off' ;
        $deductibleAmount = (!empty($quote_req_data->get_deductible_amount())) ? $quote_req_data->get_deductible_amount(): '0' ;
        $internationalTreatmentOpted = 'off';
        $rsgi_req['trans_code'] = $quote_req_data->get_trans_code(); 
        $rsgi_req['coverageType'] = $user_data['coverageType']; 
        $rsgi_req['noOfPersons'] = count($quote_req_data->get_members_list());
        $rsgi_req['members'] = $quote_req_data->get_members_list();
        $rsgi_req['noOfAdults'] = $quote_req_data->get_adult(); 
        $rsgi_req['noOfChilds'] = $quote_req_data->get_children(); 
        $rsgi_req['elderMemberDob'] = $elderMemberDob; 
        $rsgi_req['planType'] = $quote_req_data->get_rsgi_plans(); 
        $rsgi_req['sumInsured'] = $quote_req_data->get_sum_insured(); 
        $rsgi_req['city'] = $city['rsgi_code'];
        $rsgi_req['periodOfInsurance'] = $quote_req_data->get_tenure();  
        $rsgi_req['hospitalCashbenefitOpted'] = $hospitalcash; 
        $rsgi_req['opttopupOpted']= $opttopupOpted; 
        $rsgi_req['deductibleAmount']= $deductibleAmount; 
        $rsgi_req['internationalTreatmentOpted'] = $internationalTreatmentOpted; 
        $rsgi_req['firstName'] = $user_data['firstname']; 
        $rsgi_req['mobileNumber']= $user_data['mobile'];
        $rsgi_req['emailId']=$user_data['email']; 
        $rsgi_req['apikey'] =  Health_Constants::RSGI_APIKEY;
        $rsgi_req['agentId'] = Health_Constants::RSGI_AgentID;
        // Converting array to XML
        $rsgi_req['xml'] = $this->set_quote_xml_request($rsgi_req);
        return $rsgi_req;
    }

    private function set_quote_xml_request($rsgi_req){
        $xml_req = '<?xml version="1.0" encoding="UTF-8"?><CalculatePremiumRequest><calculatePremiumData><coverageType>'.$rsgi_req['coverageType'].'</coverageType><noOfPersons>'.$rsgi_req['noOfPersons'].'</noOfPersons><noOfAdults>'.$rsgi_req['noOfAdults'].'</noOfAdults><noOfChilds>'.$rsgi_req['noOfChilds'].'</noOfChilds><elderMemberDob>'.$rsgi_req['elderMemberDob'].'</elderMemberDob><planType>'.$rsgi_req['planType'].'</planType><sumInsured>'.$rsgi_req['sumInsured'].'</sumInsured><city>'.$rsgi_req['city'].'</city><periodOfInsurance>'.$rsgi_req['periodOfInsurance'].'</periodOfInsurance><hospitalCashbenefitOpted>'.$rsgi_req['hospitalCashbenefitOpted'].'</hospitalCashbenefitOpted><opttopupOpted>'.$rsgi_req['opttopupOpted'].'</opttopupOpted><deductibleAmount>'.$rsgi_req['deductibleAmount'].'</deductibleAmount><internationalTreatmentOpted>'.$rsgi_req['internationalTreatmentOpted'].'</internationalTreatmentOpted></calculatePremiumData><proposerDetailsData><firstName>'.$rsgi_req['firstName'].'</firstName><mobileNumber>'.$rsgi_req['mobileNumber'].'</mobileNumber><emailId>'.$rsgi_req['emailId'].'</emailId></proposerDetailsData><authenticationData><apikey>'.$rsgi_req['apikey'].'</apikey><agentId>'.$rsgi_req['agentId'].'</agentId></authenticationData><process>calculatePremium</process></CalculatePremiumRequest>';
        return $xml_req;
    }

    private function set_default_proposer_details($quote_req_data) {
        $prop['city'] = (!empty($quote_req_data->get_city())) ? $quote_req_data->get_city() : '546' ; 
        if(!empty($quote_req_data->get_firstname())){ 
            $first_name = explode('|',$quote_req_data->get_firstname());
            $prop['firstname'] = $first_name['0']; } else{ $prop['firstname'] = 'Rashmi'; 
        }
        $prop['mobile'] = (!empty($quote_req_data->get_mobile())) ? $quote_req_data->get_mobile() : '7899000333' ; 
        $prop['email'] = (!empty($quote_req_data->get_email())) ? $quote_req_data->get_email() : 'rashmi@instainsure.com' ; 
        $prop['coverageType'] = ($quote_req_data->get_plan_type() == 'INDV') ? 'individual' : 'familyfloater' ; 
        return $prop;
    }

    public function parse_quote_response($quote_response,$populated_request,$quote_req_data){
        if(!empty($quote_response) && $quote_response != 'Error'){
            $quote_resp_data = new QuoteRespData();
            $quote_resp_data->set_trans_code($quote_req_data->get_trans_code());
            $quote_resp_data->set_sum_insured($quote_req_data->get_sum_insured());
            $quote_resp_data->set_super_topup_opted($quote_req_data->get_super_topup_opted());
            $quote_resp_data->set_deductible_amount($quote_req_data->get_deductible_amount());
            $quote_resp_data->set_product_type($quote_req_data->get_product_type());
            $quote_resp_data->set_plan_type($quote_req_data->get_plan_type());
            $basePremium = ($quote_response['QuoteDetails']['IGST'] != 0) ? $quote_response['QuoteDetails']['finalPremium'] - $quote_response['QuoteDetails']['IGST'] : $quote_response['QuoteDetails']['finalPremium'] - ($quote_response['QuoteDetails']['CGST'] + $quote_response['QuoteDetails']['SGST']) ;
            $quote_resp_data->set_premium($basePremium);
            $quote_resp_data->set_serviceTax($quote_response['QuoteDetails']['IGST']);
            $quote_resp_data->set_cgst(($quote_response['QuoteDetails']['CGST']!=0) ? $quote_response['QuoteDetails']['CGST']: $quote_response['QuoteDetails']['IGST']/2);
            $quote_resp_data->set_sgst(($quote_response['QuoteDetails']['SGST'] != 0) ? $quote_response['QuoteDetails']['SGST'] : $quote_response['QuoteDetails']['IGST']/2);
            $quote_resp_data->set_totalPremium($quote_response['QuoteDetails']['finalPremium']);
            $quote_resp_data->set_rsgi_QuoteId($quote_response['QuoteId']);
            $quote_resp_data->set_product_id($populated_request['planType']);
            $quote_resp_data->set_product_name('LifeLine '.$populated_request['planType']);
            $quote_resp_data->set_insurer_name('rsgi');
            $quote_resp_data->set_insurer_code('RSGI');
            return $quote_resp_data;
        }
        return null;
    }

    private function calculate_adults_childs_age($agelist, $memlist){
        $adult = $children = 0;
        for($i=0; $i<sizeof($memlist);$i++){
            if($memlist[$i] == 'WIFE' || $memlist[$i] == 'HUS' || $memlist[$i] == 'MOTH' || $memlist[$i] == 'FATH'){
                $member[] = 'adult';
                $adult++;
            }elseif($memlist[$i] == 'SELF' && $agelist[$i] >=18 ){
                $member[] = 'adult';
                $adult++;
            }elseif(($memlist[$i] == 'SONM' || $memlist[$i] == 'UDTR') && $agelist[$i] > 21){
                $member[] = 'adult';
                $adult++;
            }else{
                $member[] = 'child';
                $children++;
            }
        }
        $res['member'] = $member;
        $res['adult'] = $adult;
        $res['children'] = $children;
        return $res;
    }


    public function cover_list($productId){
        if($productId == 'Classic'){
            $rsgi_covers = [
                ["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
                ["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverType"=>"S","seperateSi"=>"N","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
                ["coverId"=>"HOC","coverType"=>"A","seperateSi"=>"N","coverName"=>"Hospital Cash","coverLimits"=>[]]
            ];
            return json_encode($rsgi_covers);
        }
        if($productId == 'Supreme'){
            $rsgi_covers = [
                ["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
                ["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverType"=>"S","seperateSi"=>"N","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
                ["coverId"=>"SOP","coverType"=>"S","seperateSi"=>"N","coverName"=>"Second opinion","coverLimits"=>[]],
                ["coverId"=>"HOC","coverType"=>"A","seperateSi"=>"N","coverName"=>"Hospital Cash","coverLimits"=>[]]
            ];
            return json_encode($rsgi_covers);
        }
        if($productId == 'Elite'){
            $rsgi_covers = [
                ["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
                ["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
                ["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverType"=>"S","seperateSi"=>"N","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]],
                ["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
                ["coverId"=>"HOC","coverType"=>"A","seperateSi"=>"N","coverName"=>"Hospital Cash","coverLimits"=>[]],
                ["coverId"=>"NB","coverType"=>"A","seperateSi"=>"N","coverName"=>"New Born Baby","coverLimits"=>[]],
                ["coverId"=>"MA","coverType"=>"A","seperateSi"=>"N","coverName"=>"Maternity ","coverLimits"=>[]],
                ["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
                ["coverId"=>"SOP","coverType"=>"S","seperateSi"=>"N","coverName"=>"Second opinion","coverLimits"=>[]],
                ["coverId"=>"OPD","coverType"=>"A","seperateSi"=>"N","coverName"=>"Out Patient Services","coverLimits"=>[]]
            ];
            return json_encode($rsgi_covers);
        }

    }

    public function set_proposal_details($usr_data){
        if(!empty($usr_data['firstname'])){
            $mem_doblist = explode('|', $usr_data['dob_list']);
            foreach($mem_doblist as $doblist){
                $dob_list[] = date('d-m-Y', strtotime($doblist));
            }
            $data = [ 
                'dob_list' => $dob_list,
                'age_list' => explode('|', $usr_data['age_list']),
                'firstname' => explode('|', $usr_data['firstname']),
                'lastname' => explode('|', $usr_data['lastname']),
                'height_feet' => explode('|', $usr_data['height_feet']),
                'height_inches' => explode('|', $usr_data['height_inches']),
                'weight' => explode('|', $usr_data['weight']),
                'occupation' => explode('|', $usr_data['occupation']),
                'business' => explode('|', $usr_data['business']),
                'designation' => explode('|', $usr_data['designation']),
                'gender' => explode('|', $usr_data['gender']),
                'agree_med_chkup' => 0,
                'usr_data' => $usr_data
            ];
            return $data;
        }
        return null;
    }

    public function get_member_occupation_details($data){
        for($i=1; $i<=6; $i++){
            $occ[$i] = [
                '0' => isset($data['occupation'.$i])? $data['occupation'.$i] :'NULL',
                '1' => isset($data['designation'.$i])? $data['designation'.$i]:'NULL',
                '2' => isset($data['business'.$i]) ? $data['business'.$i]:'NULL', 
            ];
        }
        return $occ;
    }

    public function set_proposal_data($user_data){
        $state_db = new HealthState();
        $statelist = $state_db->get_state_list($user_data['state'], 'rsgi_code');
        $city_db = new HealthCity();
        $citylist = $city_db->get_city_list($user_data['city'], 'rsgi_code');
        $proposal_req_data = new PolicyPageData();
        $proposal_req_data->set_hl_trans_code($user_data['hl_trans_code']);
        $proposal_req_data->set_rsgi_quote_id($user_data['rsgi_quote_id']);
        $proposal_req_data->set_tenure($user_data['tenure']);
        $proposal_req_data->set_plan_type($user_data['plan_type']);
        $proposal_req_data->set_policy_start($user_data['policy_start']);
        $proposal_req_data->set_policy_end($user_data['policy_end']);
        $proposal_req_data->set_product_id($user_data['product_id']);
        $proposal_req_data->set_insurer_name($user_data['insurer_name']);
        $proposal_req_data->set_sum_insured($user_data['sum_insured']);
        foreach($user_data['dob_list'] as $dob){
            $date = DateTime::createFromFormat("d-m-Y" , $dob);
            $mem_dob[] = $date->format('d/m/Y');
        }
        $proposal_req_data->set_dob_list($mem_dob);
        $proposal_req_data->set_age_list(explode('|',$user_data['age_list']));
        $proposal_req_data->set_members_list(explode('|', $user_data['members_list']));
        $proposal_req_data->set_gender(explode('|',$user_data['gender_list']));
        $proposal_req_data->set_firstname($user_data['firstname']);
        $proposal_req_data->set_lastname($user_data['lastname']);
        $proposal_req_data->set_pancard(isset($user_data['pan_number']) ? $user_data['pan_number']: '');
        $proposal_req_data->set_aadhaar($user_data['aadhaar_num']);
        $proposal_req_data->set_feet($user_data['height_feet']);
        $proposal_req_data->set_inches($user_data['height_inches']);
        $proposal_req_data->set_weight($user_data['weight']);
        $proposal_req_data->set_merital_status($user_data['marital_status']);
        $proposal_req_data->set_education($user_data['education']);
        $proposal_req_data->set_member_occupation(isset($user_data['occupation']) ? $user_data['occupation'] : '');
        $occupation_details = $this->get_member_occupation_details($user_data); 
        $proposal_req_data->set_occupation_details($occupation_details);
        $proposal_req_data->set_email($user_data['email']);
        $proposal_req_data->set_mobile($user_data['mobile']);
        $proposal_req_data->set_houseno($user_data['house_num']);
        $proposal_req_data->set_street($user_data['street']);
        $proposal_req_data->set_locality($user_data['locality']);
        $proposal_req_data->set_cust_pincode($user_data['cust_pincode']);
        $proposal_req_data->set_state((!empty($statelist['rsgi_code']))?$statelist['rsgi_code'] : '0');
        $proposal_req_data->set_city((!empty($citylist['rsgi_code'])) ? $citylist['rsgi_code'] : '0');
        $ped_list = $this->set_ped_list($user_data);
        $proposal_req_data->set_ped_details($ped_list);
        $proposal_req_data->set_nominee_name($user_data['nominee_name']);
        $proposal_req_data->set_nominee_dob($user_data['nominee_dob']);
        $proposal_req_data->set_nominee_relation($user_data['nominee_relation']);
        $proposal_req_data->set_agree_medical_checkup((isset($user_data['agree_med_chkup']) && ($user_data['agree_med_chkup'] == 1)) ? 1 : 0 );
        $proposal_req_data->set_rsgi_hosp_cash($user_data['rsgi_hosp_cash']);
        $proposal_req_data->set_international_treatment(isset($user_data['rsgi_international_treatment']) ? $user_data['rsgi_international_treatment'] : 'off') ;
        $deductible = isset($user_data["deductable"])? $user_data["deductable"] : $user_data["deductibles"];
        $proposal_req_data->set_rsgi_top_up(($deductible != 0) ? 'On' : 'off');
        $proposal_req_data->set_deductible_amount(!empty(($deductible) && $deductible !== null) ? $deductible : '0');
        return $proposal_req_data;
    }


    private function set_ped_list($user_data){
        for($i=1; $i<=6; $i++){
            $ped_lifestyle[$i] = ['Alcohol' => $user_data['Alcohol'],
            'alcohol_member'.$i => isset($user_data['alcohol_member'.$i])?$user_data['alcohol_member'.$i]: '0',
            'alcohol_quantity_'.$i => isset($user_data['alcohol_quantity_'.$i]) ? $user_data['alcohol_quantity_'.$i]: '0',
            'alcohol_no_of_years_'.$i=> isset($user_data['alcohol_no-of-years_'.$i]) ? $user_data['alcohol_no_of_years_'.$i]: '0',
            'Smoke' => $user_data['Smoke'],
            'smoke_member'.$i => isset($user_data['smoke_member'.$i]) ? $user_data['smoke_member'.$i]: '0',
            'smoke_quantity_'.$i => isset($user_data['smoke_quantity_'.$i]) ? $user_data['smoke_quantity_'.$i]: '0',
            'smoke_no_of_years_'.$i => isset($user_data['smoke_no_of_years_'.$i]) ? $user_data['smoke_no_of_years_'.$i] : '0',
            'Tobacco' => $user_data['Tobacco'],
            'tobacco_member'.$i=>isset($user_data['tobacco_member'.$i])?$user_data['tobacco_member'.$i]: '0',
            'tobacco_quantity_'.$i => isset($user_data['tobacco_quantity_'.$i]) ?$user_data['tobacco_quantity_'.$i] : '0',
            'tobacco_no_of_years_'.$i => isset($user_data['tobacco_no_of_years_'.$i]) ? $user_data['tobacco_no_of_years_'.$i]: '0',
             'Narcotics' => $user_data['Narcotics'],
            'narcotics_member'.$i => isset($user_data['narcotics_member'.$i]) ? $user_data['narcotics_member'.$i]: '0',

            'narcotics_quantity_'.$i => isset($user_data['narcotics_quantity_'.$i]) ? $user_data['narcotics_quantity_'.$i]:'0',
            'narcotics_no_of_years_'.$i => isset($user_data['narcotics_no_of_years_'.$i]) ? $user_data['narcotics_no_of_years_'.$i]: '0',
             ];
      
      
             $pdata[$i] = [
                'consulted_doctor' => (isset($user_data['consulted_doctor_member'.$i]) && $user_data['consulted_doctor_member'.$i] !== null) ? $user_data['consulted_doctor_member'.$i] : 'No',
                'undergone_investigation' => (isset($user_data['undergone_investigation_member'.$i]) && $user_data['undergone_investigation_member'.$i] !== null) ? $user_data['undergone_investigation_member'.$i] : 'No',
                'taken_medical_treatment' => (isset($user_data['taken_medical_treatment_member'.$i]) && $user_data['taken_medical_treatment_member'.$i] !== null) ? $user_data['taken_medical_treatment_member'.$i] : 'No',
                'consuming_tablets' => (isset($user_data['consuming_tablets_member'.$i]) && $user_data['consuming_tablets_member'.$i] !== null) ? $user_data['consuming_tablets_member'.$i] : 'No',
                'medical_conditions' => (isset($user_data['medical_conditions_member'.$i]) && $user_data['medical_conditions_member'.$i] !== null) ? $user_data['medical_conditions_member'.$i] : 'No',
                'undergone_a_surgery' => (isset($user_data['undergone_a_surgery_member'.$i]) && $user_data['undergone_a_surgery_member'.$i] !== null) ? $user_data['undergone_a_surgery_member'.$i] : 'No',
            ];

        }
        if(isset($user_data['question_info']) && !empty($user_data['question_info'])){
            foreach ($user_data['question_info'] as $key => $kvalue) {
            $pedList[$key] = $kvalue; }
        }
        $data['ped_lifestyle'] = json_encode($ped_lifestyle);
        $data['ped_list'] = json_encode($pdata);
        $data['ped_question_info'] = json_encode($pedList);
        return json_encode($data);
    }


    public function populate_proposal_request($req_data){
        $premium_data = $this->calculatePremiumData($req_data);
        $proposer_data = $this->proposerDetailsData($req_data);
        $insured_details = $this->insuredDetailsData($req_data);
        $authentication_data = $this->getAuth();
        $req_xml = '<?xml version="1.0" encoding="UTF-8"?>
                <CalculatePremiumRequest>
                    <quoteId>'.$req_data->get_rsgi_quote_id().'</quoteId>
                    <calculatePremiumData>'.$premium_data.'</calculatePremiumData>
                    <proposerDetailsData>'.$proposer_data.'</proposerDetailsData>
                    <insuredDetailsData>'.implode("", $insured_details).'</insuredDetailsData>
                    <authenticationData>'.$authentication_data.'</authenticationData>
                </CalculatePremiumRequest>';

        return $req_xml;
    }


    public function parse_proposal_response($proposal_response,$proposal_req_data){
        $proposal_resp_data = new PolicyPageData();
        $proposal_resp_data->set_hl_trans_code($proposal_req_data->get_hl_trans_code());
        $proposal_resp_data->set_product_id($proposal_req_data->get_product_id());
        $proposal_resp_data->set_insurer_name($proposal_req_data->get_insurer_name());
        if(isset($proposal_response['QuoteDetails'])){
            $proposal_resp_data->set_referenceId($proposal_response['ReferralStatus']);
            $basePremium = ($proposal_response['QuoteDetails']['IGST'] != 0) ? $proposal_response['QuoteDetails']['finalPremium'] - $proposal_response['QuoteDetails']['IGST'] : $proposal_response['QuoteDetails']['finalPremium'] - ($proposal_response['QuoteDetails']['CGST'] + $proposal_response['QuoteDetails']['SGST']) ;
            $proposal_resp_data->set_final_premium($basePremium);
            $proposal_resp_data->set_final_totalPremium(round($proposal_response['QuoteDetails']['finalPremium']));
            $proposal_resp_data->set_final_serviceTax(round($proposal_response['QuoteDetails']['IGST']));
        }else{
            $proposal_resp_data->set_error_message($proposal_response);
        }
        return $proposal_resp_data;
    }

    private function calculatePremiumData($req_data){
        $usertdata = new HealthUserData();
        $coverageType = ($req_data->get_plan_type() == 'INDV') ? 'individual' : 'familyFloater';
        foreach ($req_data->get_dob_list() as $value) {
            $dt   = DateTime::createFromFormat('d/m/Y', $value);
            $dob[]  = $dt->format('Y/m/d');
        }
        $new_date = min($dob);
        $new_dt   = DateTime::createFromFormat('Y/m/d', $new_date);
        $elderMemberDob  = $new_dt->format('d/m/Y');
        $member_cal = $this->calculate_adults_childs_age($req_data->get_age_list(),$req_data->get_members_list());
        $PremiumData = '<coverageType>'.$coverageType.'</coverageType>
                        <noOfPersons>'.count($req_data->get_members_list()).'</noOfPersons>
                        <noOfAdults>'.$member_cal['adult'].'</noOfAdults>
                        <noOfChilds>'.$member_cal["children"].'</noOfChilds>
                        <elderMemberDob>'.$elderMemberDob.'</elderMemberDob>
                        <planType>'.$req_data->get_product_id().'</planType>
                        <sumInsured>'.$req_data->get_sum_insured().'</sumInsured>
                        <city>'.$req_data->get_city().'</city>
                        <periodOfInsurance>'.$req_data->get_tenure().'</periodOfInsurance>
                        <hospitalCashbenefitOpted>'.$req_data->get_rsgi_hosp_cash().'</hospitalCashbenefitOpted>
                        <opttopupOpted>'.$req_data->get_rsgi_top_up().'</opttopupOpted>
                        <deductibleAmount>'.$req_data->get_deductible_amount().'</deductibleAmount>
                        <internationalTreatmentOpted>'.$req_data->get_international_treatment().'</internationalTreatmentOpted>';
        return $PremiumData;
    }

    private function proposerDetailsData($req_data){
        $gender = $req_data->get_gender();
        if($gender[0] == 'M'){$mem_gender = 'Male'; }else{ $mem_gender = 'Female';}
        $proposer_data = '<firstName>'.$req_data->get_firstname()['0'].'</firstName>
                            <lastName>'.$req_data->get_lastname()['0'].'</lastName>
                            <gender>'.$mem_gender.'</gender>
                            <nationality>Indian</nationality>
                            <educationQualification>'.$req_data->get_education().'</educationQualification>
                            <maritalStatus>'.$req_data->get_merital_status().'</maritalStatus>
                            <mobileNumber>'.$req_data->get_mobile().'</mobileNumber>
                            <occupation>'.$req_data->get_member_occupation()['0'].'</occupation>
                            <designation>'.$req_data->get_occupation_details()['1']['1'].'</designation>
                            <panNumber>'.$req_data->get_pancard().'</panNumber>
                            <dateOfBirth>'.$req_data->get_dob_list()['0'].'</dateOfBirth>
                            <businessOccupation>'.$req_data->get_occupation_details()['1']['2'].'</businessOccupation>
                            <emailId>'.$req_data->get_email().'</emailId>
                            <pinCode>'.$req_data->get_cust_pincode().'</pinCode>
                            <address1>'.$req_data->get_houseno().' </address1>
                            <address2>' .$req_data->get_street().'</address2>
                            <address3>'.$req_data->get_locality().'</address3>
                            <city>'.$req_data->get_city().'</city>
                            <state>'.$req_data->get_state().'</state>
                            <nomineeRelationWithProposer>'.$req_data->get_nominee_relation().'</nomineeRelationWithProposer>
                            <nomineeFirstName>'.$req_data->get_nominee_name().'</nomineeFirstName>
                            <nomineeDateOfBirth>'.$req_data->get_nominee_dob().'</nomineeDateOfBirth>';
        return $proposer_data;
    }

    private function insuredDetailsData($req_data){
        $insured_data = [];
        $member_count = count($req_data->get_members_list());
        $occupation_details = $req_data->get_occupation_details(); 
        
        foreach($occupation_details as $details){
            $designation[] = $details['1'];
            $business[] = $details['2']; 
        }
        $relationship = $req_data->get_members_list();
         foreach ($relationship as $i => $relationship_id){
            $member_cal = $this->calculate_adults_childs_age($req_data->get_age_list(),$req_data->get_members_list());
            foreach($member_cal['member'] as $dataval){
                $insuredType[] = $dataval;
            }
             // Updating Gender and Title for Self
            $gender = $req_data->get_gender();
            $mem_gender = ($gender[$i] == 'M') ? 'Male' : 'Female' ;

            $height = $this->convert_feet_to_cm($req_data->get_feet()[$i],$req_data->get_inches()[$i]);
            $bmi    = $this->BMI_calculation($height,$req_data->get_weight()[$i]);

            // Medical questions 
            $medicalquestion = $this->get_medicalquestion_data($req_data);
            foreach($medicalquestion as $ped_question){
                $medical_question[] = $ped_question; 
            }
            // Additional medical question information
            $addition_medical_details = $this->get_question_details($req_data);
            foreach($addition_medical_details as $key => $question_info){
                if(substr($question_info,29, 31) === '<nameOfIllness></nameOfIllness>'){ 
                    $question_info ='';  }
                $qun_info[]  = $question_info;
            }
            // Life style question details                                  
            $lifestyle_data = $this->get_lifestyle_data($req_data);
            foreach($lifestyle_data as $life_ped){
                $life_style[] = $life_ped; 
            }
            $insured_data[] ='<insuredDetails>
                <insuredType>'.$insuredType[$i].'</insuredType>
                <relationshipWithProposer>'.$relationship_id.'</relationshipWithProposer>
                <firstName>'.$req_data->get_firstname()[$i].'</firstName>
                <lastName>'.$req_data->get_lastname()[$i].'</lastName>
                <gender>'.$mem_gender.'</gender>
                <dateOfBirth>'.$req_data->get_dob_list()[$i].'</dateOfBirth>
                <height>'.round($height).'</height>
                <weight>'.$req_data->get_weight()[$i].'</weight>
                <bmi>'.round($bmi).'</bmi>
                <occupation>'.$req_data->get_member_occupation()[$i].'</occupation>
                <designation>'.$designation[$i].'</designation>
                <businessOccupation>'.$business[$i].'</businessOccupation>
                <medicalDetails>'.$medical_question[$i].'</medicalDetails>
                <lifestyleDetails>'.$life_style[$i].'</lifestyleDetails>
                <additionMedicalDetails>'.$qun_info[$i].'</additionMedicalDetails>
                </insuredDetails>';
            }
        return $insured_data; 
    }


    private function getAuth(){
         $auth = '<apikey>'.Health_Constants::RSGI_APIKEY.'</apikey>
                <agentId>'.Health_Constants::RSGI_AgentID.'</agentId>';
        return $auth;
    }


    private function get_medicalquestion_data($req_data){
        $medical_questions = json_decode($req_data->get_ped_details());
        $ped_que = json_decode($medical_questions->ped_list);

        $val = array();
        for($r=1; $r<=6; $r++)
        {
            $a = ($ped_que->$r->consulted_doctor != null) ? $ped_que->$r->consulted_doctor : '';
            $val[$r] ='<medicalQuestionOne>'.$a.'</medicalQuestionOne>';
            $a = ($ped_que->$r->undergone_investigation != null) ? $ped_que->$r->undergone_investigation : '';
            $val[$r] .= '<medicalQuestionTwo>'.$a.'</medicalQuestionTwo>';
            $a = ($ped_que->$r->taken_medical_treatment != null) ? $ped_que->$r->taken_medical_treatment : '';
            $val[$r] .= '<medicalQuestionThree>'.$a.'</medicalQuestionThree>';
            $a = ($ped_que->$r->consuming_tablets != null) ? $ped_que->$r->consuming_tablets : '';
            $val[$r] .= '<medicalQuestionFour>'.$a.'</medicalQuestionFour>';
            $a = ($ped_que->$r->medical_conditions != null) ? $ped_que->$r->medical_conditions : '';
            $val[$r] .= '<medicalQuestionFive>'.$a.'</medicalQuestionFive>';
            $a = ($ped_que->$r->undergone_a_surgery != null) ? $ped_que->$r->undergone_a_surgery : '';
            $val[$r] .= '<medicalQuestionSix>'.$a.'</medicalQuestionSix>';
        }
        return $val;
    }

    private function get_question_details($data){
        $medical_details = json_decode($data->get_ped_details());
        $question_info = json_decode($medical_details->ped_question_info);
        $val = array();
        for($r=1; $r <= 6; $r++){
            $a = (isset($question_info->{'nameOfIllness_'.$r}) && $question_info->{'nameOfIllness_'.$r} !== null) ? $question_info->{'nameOfIllness_'.$r} : '';
            $val[$r] ='<additionMedicalQuestionInfo><nameOfIllness>'.$a.'</nameOfIllness>';
            $a = (isset($question_info->{'monthOfDiagnosis_'.$r}) && $question_info->{'monthOfDiagnosis_'.$r} != null) ? $question_info->{'monthOfDiagnosis_'.$r} :'';
            $val[$r] .= '<monthOfDiagnosis>'.$a.'</monthOfDiagnosis>';
            $a = (isset($question_info->{'yearOfDiagnosis_'.$r}) && $question_info->{'yearOfDiagnosis_'.$r} != null) ? $question_info->{'yearOfDiagnosis_'.$r} : '';
            $val[$r] .= '<yearOfDiagnosis>'.$a.'</yearOfDiagnosis>';
            $a = (isset($question_info->{'medicationDetail_'.$r}) && $question_info->{'medicationDetail_'.$r} != null) ? $question_info->{'medicationDetail_'.$r} :'';
            $val[$r] .= '<medicationDetail>'.$a.'</medicationDetail>';
            $a = (isset($question_info->{'treatmentOutCome_'.$r}) && $question_info->{'treatmentOutCome_'.$r} != null) ? $question_info->{'treatmentOutCome_'.$r} :'';
            $val[$r] .= '<treatmentOutCome>'.$a.'</treatmentOutCome></additionMedicalQuestionInfo>';

        if($val[$r] == '<additionMedicalQuestionInfo><nameOfIllness></nameOfIllness><monthOfDiagnosis></monthOfDiagnosis><yearOfDiagnosis></yearOfDiagnosis><medicationDetail></medicationDetail><treatmentOutCome></treatmentOutCome></additionMedicalQuestionInfo>'){
            set($val[$r] = ""); }
       }

       return $val;
    }


    private function get_lifestyle_data($user_data){
        $medical_details = json_decode($user_data->get_ped_details());
        $lifestyle = json_decode($medical_details->ped_lifestyle);
        for($i = 1; $i <= 6; $i++){
            $alcohol[$i] = ($lifestyle->$i->{'alcohol_member'.$i} == '1') ? 'Yes' : 'No';
            $smoke[$i] =   ($lifestyle->$i->{'smoke_member'.$i} == '1') ? 'Yes' : 'No' ; 
            $tobacco[$i] = ($lifestyle->$i->{'tobacco_member'.$i} == '1') ? 'Yes' : 'No'; 
            $narcotics[$i] = ($lifestyle->$i->{'narcotics_member'.$i} == '1') ? 'Yes' : 'No'; 
            $ldata[$i] =[
                'alcohol' => $alcohol[$i],
                'alcohol_quantity'=>isset($ped_lifestyle->{'alcohol_quantity_'.$i}) ? $ped_lifestyle->{'alcohol_quantity_'.$i} :'0',
                'alcohol_years'=>isset($ped_lifestyle->{'alcohol_no_of_years_'.$i}) ? $ped_lifestyle->{'alcohol_no_of_years_'.$i} :'0',
                'smoke' => $smoke[$i],
                'smoke_quantity' =>isset($ped_lifestyle->{'smoke_quantity_'.$i}) ? $ped_lifestyle->{'smoke_quantity_'.$i} : '0',
                'smoke_years'=>isset($ped_lifestyle->{'smoke_no_of_years_'.$i}) ? $ped_lifestyle->{'smoke_no_of_years_'.$i} : '0',
                'tobacco' => $tobacco[$i],
                'tobacco_quantity'=>isset($ped_lifestyle->{'tobacco_quantity_'.$i}) ? $ped_lifestyle->{'tobacco_quantity_'.$i} :'0',
                'tobacco_years' => isset($ped_lifestyle->{'tobacco_no_of_years_'.$i}) ? $ped_lifestyle->{'tobacco_no_of_years_'.$i} : '0',
                'narcotics' => $narcotics[$i],
                'narcotics_quantity' =>isset($ped_lifestyle->{'narcotics_quantity_'.$i}) ? $ped_lifestyle->{'narcotics_quantity_'.$i} : '0',
                'narcotics_years' => isset($ped_lifestyle->{'narcotics_no_of_years_'.$i}) ? $ped_lifestyle->{'narcotics_no_of_years_'.$i} : '0',
            ];
        }

        $temp = array();
              for($j=1; $j<=sizeof($ldata); $j++){
                // Alcohol
                $a = ($ldata[$j]['alcohol'] != null) ? $ldata[$j]['alcohol'] : '';
                $temp[$j] = '<alcohol>'.$a.'</alcohol>';
                $a = ($ldata[$j]['alcohol_quantity'] != null) ? $ldata[$j]['alcohol_quantity'] :'';
                $temp[$j] .= '<alcoholQuantity>'.$a.'</alcoholQuantity>';
                $a = ($ldata[$j]['alcohol_years'] != null) ? $ldata[$j]['alcohol_years'] : '';
                $temp[$j] .= '<alcoholNumberOfYears>'.$a.'</alcoholNumberOfYears>';
                // Smoke
                $a = ($ldata[$j]['smoke'] != null) ? $ldata[$j]['smoke'] : '';
                $temp[$j] .= ' <smoking>'.$a.'</smoking>';
                $a = ($ldata[$j]['smoke_quantity'] != null) ? $ldata[$j]['smoke_quantity'] : '';
                $temp[$j] .= '<smokingQuantity>'.$a.'</smokingQuantity>';
                $a = ($ldata[$j]['smoke_years'] != null) ? $ldata[$j]['smoke_years'] : '';
                $temp[$j] .= '<smokingNumberOfYears>'.$a.'</smokingNumberOfYears>';
                // tobacco
                $a = ($ldata[$j]['tobacco'] != null) ? $ldata[$j]['tobacco'] : '';
                $temp[$j] .= '<anyOtherSubstance>'.$a.'</anyOtherSubstance>';
                $a = ($ldata[$j]['tobacco_quantity'] != null) ? $ldata[$j]['tobacco_quantity'] :'';
                $temp[$j] .= '<anyOtherSubstanceQuantity>'.$a.'</anyOtherSubstanceQuantity>';
                $a = ($ldata[$j]['tobacco_years'] != null) ? $ldata[$j]['tobacco_years'] : '';
                $temp[$j] .= '<anyOtherSubstanceNumberOfYears>'.$a.'</anyOtherSubstanceNumberOfYears>';
                // narcotics
                $a = ($ldata[$j]['narcotics'] != null) ? $ldata[$j]['narcotics'] : '';
                $temp[$j] .= '<narcotics>'.$a.'</narcotics>';
                $a = ($ldata[$j]['narcotics_quantity'] != null) ? $ldata[$j]['narcotics_quantity'] : '';
                $temp[$j] .= '<narcoticsQuantity>'.$a.'</narcoticsQuantity>';
                $a = ($ldata[$j]['narcotics_years'] != null) ? $ldata[$j]['narcotics_years'] : '';
                $temp[$j] .= '<narcoticsNumberOfYears>'.$a.'</narcoticsNumberOfYears>';
                $temp[$j] .= '<otherHabits>No</otherHabits>';
                $temp[$j] .= '<otherHabitsPastYear> </otherHabitsPastYear>';
              }
        return $temp;
    }

    private function convert_feet_to_cm($feet, $inches = 0) {
        $inches = ($feet * 12) + $inches; // converts feet to inches
        $height = ($inches * 2.54);  // converts inches to cm
        return $height;
    }
    
    private function BMI_calculation($height, $weight){
        $bmi = ($weight/$height/$height) * 10000;
        return number_format((float)$bmi, 1, '.', '');
    }

    public function check_rsgi_policy_type($trans_code){
        $usertdata = new HealthUserData();
        $columns = array('insurerId', 'age_list','sum_insured','rsgi_refr_status');
        $data = $usertdata->getUserTData($trans_code,$columns);
        $insurerId      = $data['insurerId'];
        $suminsured    = $data['sum_insured'];
        $age           = explode('|',$data['age_list']);
        foreach($age as $mem_age){
            $age['bmi']  = $this->rsgi_check_bmi($trans_code);
            // RSGI  Age check above 45 years
            if($mem_age > 45) {
                $age['memage']= $mem_age;
                $age['insurer_id']= $insurerId;
            }
            //SumInsured above/equal to 10 Lk 
            if($suminsured >= 1000000) {
                $age['si']= $suminsured;
                $age['insurer_id']= $insurerId;
            }
            return $age;
        }
        return false;
    }

    private function rsgi_check_bmi($trans_code){
        $usertdata = new HealthUserData();
        $columns = array('insurerName', 'height_feet', 'height_inches', 'weight', 'age_list','members_list','firstname','lastname');
        $data = $usertdata->getUserTData($trans_code,$columns);
        $age_checklist = array();
        $bmi_member    = array();
        $insurerId      = $data['insurerName'];
        $height_feet   = explode('|',$data['height_feet']);
        $height_inches = explode('|',$data['height_inches']);
        $weight        = explode('|',$data['weight']);
        $relationship  = explode('|',$data['members_list']);
        $age           = explode('|',$data['age_list']);
        $firstname     = explode('|',$data['firstname']);
        $lastname      = explode('|',$data['lastname']);
        foreach ($relationship as $key => $data) {
            $age_checklist[] = $key;
        }
        if(!empty($age_checklist)){
            $i = 0;
        foreach ($age_checklist as $key => $index) {
            $height = $this->convert_feet_to_cm($height_feet[$index], $height_inches[$index]);
            $bmi    = $this->BMI_calculation($height,$weight[$index]);
            if($bmi < Health_Constants::RSGI_BMI_LOWER_LIMIT || $bmi >= Health_Constants::RSGI_BMI_UPPER_LIMIT){
                $bmi_member[$i]['insurerId'] = $insurerId;
                $bmi_member[$i]['name']   = ucfirst($firstname[$index].' '.$lastname[$index]);
                $bmi_member[$i]['height'] = $height_feet[$index].'&#39;'.$height_inches[$index];
                $bmi_member[$i]['weight'] = $weight[$index].'Kg';
                $bmi_member[$i]['bmi']    = $bmi;
                $i++;
            }
        }
        return $bmi_member;
        }else { return null; }
    }

}
