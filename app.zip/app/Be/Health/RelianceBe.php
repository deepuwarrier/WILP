<?php
namespace App\Be\Health;
use App\Constants\Health_Constants;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthPincode;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\data\QuoteReqData;
use App\Models\Health\data\QuoteRespData;
use App\Models\Health\data\PolicyPageData;
use App\Be\Health\HealthPolicyBe;
use DateTime;

class RelianceBe{

    public function __construct(){
    }

    public function set_quote_request($user_data){
        $quote_req_data = new QuoteReqData();
        $quote_req_data->set_trans_code($user_data['trans_code']);
        $quote_req_data->set_pincode($user_data['pincode']);
        $quote_req_data->set_members_list(explode('|',$user_data['members_list']));
        $quote_req_data->set_dob_list(explode('|',$user_data['dob_list']));
        $quote_req_data->set_age_list(explode('|',$user_data['age_list']));
        $quote_req_data->set_adult($user_data['adult']);
        $quote_req_data->set_children($user_data['children']);
        $quote_req_data->set_tenure($user_data['tenure']);
        $sum_insured = ($user_data['sum_insured'] == '500000') ? 600000 : $user_data['sum_insured'];
        $quote_req_data->set_sum_insured($sum_insured);
        $quote_req_data->set_plan_type($user_data['plan_type']);
        $quote_req_data->set_product_type($user_data['product_type']);
        return $quote_req_data;
    }

    public function product_map($data_obj){
        // Plan A = 1 
        $return_arr = [
          "1" => $this->health_gain_plan($data_obj),
        ];
        return $return_arr;
    }

    private function health_gain_plan($data){ 
      $reliance_plans = $this->get_reliance_plans($data->get_sum_insured());
      $plan_type = (($data->get_plan_type() == 'INDV' && count($data->get_members_list()) == 1) || ($data->get_plan_type() == 'FF' && count($data->get_members_list()) >= 2) ) ? 1: 0; 
      $rel_flag = 0;
        if(in_array("FATH", $data->get_members_list()) || in_array("MOTH", $data->get_members_list())){
            $rel_flag = 1; 
        }
        if(isset($reliance_plans['PlanA']) && $data->get_adult() <= 2 && count($data->get_members_list()) <= 5 && max($data->get_age_list()) <= 65 && $plan_type == 1 && $data->get_tenure() == 1 && $rel_flag != 1) {
            return true;
        }
        return false;
    }

    private function get_reliance_plans($si){
        $plan_sum_insured = [
            'PlanA' => [300000, 600000, 900000],
        ];

        $plan_type = array();
        foreach($plan_sum_insured as $key => $sum_insured){
            foreach($sum_insured as $id => $amount){
                if($si == $amount){
                    $plan_type[$key] = $amount; 
                } 
            }
        }
        return $plan_type;
    }

    public function populate_quote_request($quote_req_data){  
        $client_details = $this->calculate_client_details($quote_req_data);
        $insured_details = $this->calculate_insured_details($quote_req_data);
        $policy_details = $this->calculate_policy_details($quote_req_data);
        $risk_details = $this->calculate_risk_details($quote_req_data);
        $nominee_details = $this->calculate_nominee_details($quote_req_data);
        $premium_details = $this->calculate_premium_details($quote_req_data);
        $previous_insurance_details = $this->calculate_previous_insurance_details($quote_req_data);

        $reliance_xml_req = '<HealthDetails><ClientDetails>'.$client_details.'</ClientDetails><InsuredDetailsList>'.$insured_details.'</InsuredDetailsList><Policy>'.$policy_details.'</Policy><UploadDetails> <DocumentType /> </UploadDetails><RiskDetails>'.$risk_details.'</RiskDetails><NomineeDetails>'.$nominee_details.'</NomineeDetails><Premium>'.$premium_details.'</Premium><LstDiscount /> <ErrorMessages> <ErrMessages /> </ErrorMessages> <LstHealthCoverDetails /><PreviousInsuranceDetails>'.$previous_insurance_details.'</PreviousInsuranceDetails><UserID>'.Health_Constants::RELIANCE_USER_ID.'</UserID><SourceSystemID>'.Health_Constants::RELIANCE_SOURCE_SYSTEM_ID.'</SourceSystemID><AuthToken>'.Health_Constants::RELIANCE_AUTH_TOKEN.'</AuthToken><CoverDetails /><IsQuickquote>true</IsQuickquote><CIServicePEDList /><CIServicePreviousInsuraceDetailsList /></HealthDetails>';
        return $reliance_xml_req;
    }


    private function calculate_client_details($quote_req_data){
      // Calculate elder member dob from age list
        foreach($quote_req_data->get_age_list() as $agelist){
            $age[] = rtrim($agelist,'m');
        }
        $elder_age = max($age);
        $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
        $client_details = '<ClientTypeID>'.Health_Constants::RELIANCE_CLIENT_TYPE_ID.'</ClientTypeID><DOB>'.$elderMemberDob.'</DOB><Email></Email><ForeName /><Gender /><LastName /><MaritalStatusID /><MidName /><MobileNo></MobileNo><Nationality /><OccupationID></OccupationID><PhoneNo /><Salutation /><ClientAddress><CommunicationAddress><Address1 /><Address2 /><Address3 /><CityID /><Country /><DistrictID /><Email /><Fax /><MobileNo /><NearestLandmark /><PanNo /><PhoneNo /><Pincode /><AreaID /><StateID /></CommunicationAddress><PermanentAddress><Address><Address1 /><Address2 /><Address3 /><CityID /><Country /><DistrictID /><NearestLandmark /><Pincode /><AreaID /><StateID /></Address></PermanentAddress></ClientAddress>';
        return $client_details;
    }

    private function calculate_insured_details($quote_req_data){
        $relationship_id = ($quote_req_data->get_plan_type() == 'INDV') ? 345 :'';
        $memdob = ($quote_req_data->get_plan_type() == 'INDV') ? date("d/m/Y", strtotime($quote_req_data->get_dob_list()[0])) : '';
        $merital_status = ($quote_req_data->get_plan_type() == 'INDV') ? 1952 : '';
        $insured_details = '<InsuredDetail><RelationshipWithProposerID>'.$relationship_id.'</RelationshipWithProposerID><Salutation /><FirstName /><LastName /><MiddleName /><Gender>M</Gender><Age /><DOB>'.$memdob.'</DOB><MaritalStatusID>'.$merital_status.'</MaritalStatusID><OccupationID /><Height /><Weight /><SpecialConditions /><PreExistingDisease><IsExistingIllness>false</IsExistingIllness><DiseaseList><DiseaseDetail><DiseaseID /><SufferingSince /><OtherDisease /></DiseaseDetail></DiseaseList><IsInsuredConsumetobacco /><HasAnyPreClaimOnInsured /><DetailsOfPreClaimOnInsured /><HasAnyPreHealthInsuranceCancelled /><DetailsOfPrevInsuranceCancelled /></PreExistingDisease><OtherInsuranceList><OtherInsuranceDetail><PreviousInsuraceCompName /><PreviousPolNo /><PreviousPolStartDate /><PreviousPolEndDate /><CoverTypeID /><SumInsured /><AccumulatedCumulativeBonus /></OtherInsuranceDetail></OtherInsuranceList><NewlyAddedMember>false</NewlyAddedMember></InsuredDetail>';
        return $insured_details;
    }

    private function calculate_policy_details($quote_req_data){
      $policy_be = new HealthPolicyBe(); 
      $policy_date = $policy_be->get_policy_date($quote_req_data->get_tenure());
      $policy_details = '<Tenure>'.$quote_req_data->get_tenure().'</Tenure>
                        <PolicyStartDate>'.$policy_date['p_start'].'</PolicyStartDate>
                        <PolicyEndDate>'.$policy_date['p_ends'].'</PolicyEndDate>
                        <AgentID>'.Health_Constants::RELIANCE_AGENT_ID.'</AgentID>
                        <AgentName>'.Health_Constants::RELIANCE_AGENT_NAME.'</AgentName>
                        <Branch_Code>'.Health_Constants::RELIANCE_BRANCH_CODE.'</Branch_Code>
                        <BusinessType>'.Health_Constants::RELIANCE_BUSINESS_TYPE.'</BusinessType>
                        <ProductCode>'.Health_Constants::RELIANCE_PRODUCT_CODE.'</ProductCode>
                        <ExternalSystemID>'.Health_Constants::RELIANCE_EXTERNAL_SYSTEM_ID.'</ExternalSystemID>
                        <BranchName>'.Health_Constants::RELIANCE_BRANCH_NAME.'</BranchName>';
      return $policy_details;
    }

    private function calculate_risk_details($quote_req_data){
      // Calculate elder member dob from age list
      foreach($quote_req_data->get_age_list() as $agelist){
            $age[] = rtrim($agelist,'m');
        }
        $elder_age = max($age);
      $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
      $cover_type_id = ($quote_req_data->get_plan_type() == 'FF') ? 0 : 1;
      $risk_details = '<PlanID>'.$quote_req_data->get_reliance_plans().'</PlanID>
                      <DOBofSeniorMost>'.$elderMemberDob.'</DOBofSeniorMost>
                      <MemberCount>'.count($quote_req_data->get_members_list()).'</MemberCount>
                      <MaxAge>'.$elder_age.'</MaxAge>
                      <CoverTypeID>'.$cover_type_id.'</CoverTypeID>
                      <SumInsured>'.$quote_req_data->get_sum_insured().'</SumInsured>
                      <IsServiceTaxExemptionApplicable>false</IsServiceTaxExemptionApplicable>
                      <ServiceTaxExemptionID /> <IsAnyEmployeeOfRelianceADAGroup /> <CompanyNameID /> <EmployeeCode /> <EmailID /> <Iscrosssell /> <CrossSellPolicyNo />
                      <NoofMembersAbove21>'.$quote_req_data->get_adult().'</NoofMembersAbove21>
                      <NoofMembersBelow21>'.$quote_req_data->get_children().'</NoofMembersBelow21>
                      <PreviousCumulativeBonus /><PreviousCumulativeBonusrate /><CumulativeBonus /><CumulativeBonusrate /><ChangeinCoverageType>false</ChangeinCoverageType>
                     <AdditionofMemberatRenewal>false</AdditionofMemberatRenewal>
                    <DeletionofMemberatRenewal>false</DeletionofMemberatRenewal>';
      return $risk_details;
    }

    private function calculate_nominee_details($quote_req_data){
      $nominee_details = '<FirstName /><Salutation /><MiddleName /><LastName></LastName><DOB /><NomineeRelationshipID /><NomineeRelationshipOther /><NomineeAddress><Address1 /><Address2 /><Address3 /><CityID /><Country /><DistrictID /><NearestLandmark /><Pincode /><AreaID /><StateID /></NomineeAddress>';
      return $nominee_details;
    }

    private function calculate_premium_details($quote_req_data){
        $premium_details = '<BasicPremium /><TotalPremium /><EducationalCess /><EducationalCessPercentage /><FinalPremium /><NetPremium /><SalesTax /><SalesTaxPercentage /><SecondaryAndHigherEducationalCess /><SecondaryAndHigherEducationalCessPercentage /><ServiceTax /><ServiceTaxPercentage /><Surcharge /><SurchargePercentage />';
        return $premium_details;
    }
    private function calculate_previous_insurance_details($quote_req_data){
      $previous_insurance_details = '<PrevInsuranceID /><PrevYearPolicyNo /><PrevYearPolicyStartDate /><PrevYearPolicyEndDate />';
      return $previous_insurance_details;
    }


    public function parse_quote_response($quote_response,$populated_request,$quote_req_data){
      if(!empty($quote_response) && empty($quote_response['ErrorMessages']['ErrMessages']) && $quote_response != false){
            $quote_resp_data = new QuoteRespData();
            $quote_resp_data->set_trans_code($quote_req_data->get_trans_code());
            $quote_resp_data->set_product_type($quote_req_data->get_product_type());
            $quote_resp_data->set_plan_type(($quote_req_data->get_plan_type() == 'INDV')?'1':'0');
            foreach ($quote_response['LstPortability'] as $premium) {
              foreach($premium as $value){
                if($quote_req_data->get_sum_insured() == $value['SumInsured']){
                    $quote_resp_data->set_sum_insured($value['SumInsured']);
                    $quote_resp_data->set_premium($value['NetPremium']);
                    $quote_resp_data->set_totalPremium($value['FinalPremium']);
                    foreach($value['LstTaxComponentDetails'] as $serviceTax){
                        $quote_resp_data->set_serviceTax($serviceTax[0]['Amount'] + $serviceTax[1]['Amount']);
                        $quote_resp_data->set_cgst($serviceTax[0]['Amount']);
                        $quote_resp_data->set_sgst($serviceTax[1]['Amount']);
                    }
                }
              }
            }
            $quote_resp_data->set_product_name('Health Gain');
            $quote_resp_data->set_product_id('HealthGain');
            $quote_resp_data->set_insurer_name('reliance');
            $quote_resp_data->set_insurer_code('RELIANCE');
            return $quote_resp_data;
        }
        return null;
  }
  
  public function cover_list($productId){
    $reliance_covers = [
      ["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
      ["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
      ["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
      ["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]]
    ];
    return json_encode($reliance_covers);

  }

    public function set_proposal_details($usr_data){
        if(!empty($usr_data['firstname'])){
            $mem_doblist = explode('|', $usr_data['dob_list']);
            foreach($mem_doblist as $doblist){
                $dob_list[] = date('d-m-Y', strtotime($doblist));
            }
            $data = [ 
                'dob_list' => $dob_list,
                'age_list' => explode('|', $usr_data['age_list']),
                'firstname' => explode('|', $usr_data['firstname']),
                'lastname' => explode('|', $usr_data['lastname']),
                // 'height_feet' => explode('|', $usr_data['height_feet']),
                // 'height_inches' => explode('|', $usr_data['height_inches']),
                // 'weight' => explode('|', $usr_data['weight']),
                'occupation' => explode('|', $usr_data['occupation']),
                'business' => explode('|', $usr_data['business']),
                'designation' => explode('|', $usr_data['designation']),
                'gender' => explode('|', $usr_data['gender']),
                'agree_med_chkup' => 0,
                'usr_data' => $usr_data
            ];
            return $data;
        }
        return null;
    }

    public function set_proposal_data($user_data){
        $state_db = new HealthState();
        $statelist = $state_db->get_state_list($user_data['state'], 'reliance_code');

        $city_db = new HealthCity();
        $citylist = $city_db->get_city_list($user_data['city'], 'reliance_code');

        // Get district id from pincode
        $pincode_db = new HealthPincode();
        $city_dist_list = $pincode_db->get_address_list($user_data['cust_pincode']);

        $proposal_req_data = new PolicyPageData();
        $proposal_req_data->set_hl_trans_code($user_data['hl_trans_code']);
        $proposal_req_data->set_tenure($user_data['tenure']);
        $proposal_req_data->set_plan_type($user_data['plan_type']);
        $proposal_req_data->set_policy_start($user_data['policy_start']);
        $proposal_req_data->set_policy_end($user_data['policy_end']);
        $proposal_req_data->set_product_id($user_data['product_id']);
        $proposal_req_data->set_insurer_name($user_data['insurer_name']);
        $proposal_req_data->set_sum_insured($user_data['sum_insured']);
        $proposal_req_data->set_final_totalPremium($user_data['totalPremium']);
        foreach($user_data['dob_list'] as $dob){
            $date = DateTime::createFromFormat("d-m-Y" , $dob);
            $mem_dob[] = $date->format('d/m/Y'); }
        $proposal_req_data->set_dob_list($mem_dob);
        $proposal_req_data->set_age_list(explode('|',$user_data['age_list']));
        $proposal_req_data->set_adult($user_data['adult']);
        $proposal_req_data->set_children($user_data['children']);
        $proposal_req_data->set_members_list(explode('|', $user_data['members_list']));
        $gender_list = explode('|', $user_data['gender_list']);
        $replacements = array(0 => $user_data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        foreach($gender as $gen){
            $title[] = ($gen == 'F') ? 'Ms': 'Mr';
            $member_gender[] = ($gen == 'F') ?'Female' : 'Male'; 
        }
        $proposal_req_data->set_gender($member_gender);
        $proposal_req_data->set_title($title);
        $proposal_req_data->set_firstname($user_data['firstname']);
        $proposal_req_data->set_lastname($user_data['lastname']);
        $proposal_req_data->set_pancard(isset($user_data['pan_number']) ? $user_data['pan_number']: '');
        $proposal_req_data->set_aadhaar($user_data['aadhaar_num']);
        $proposal_req_data->set_merital_status($user_data['marital_status']);
        $proposal_req_data->set_member_occupation(isset($user_data['occupation'])?$user_data['occupation']:'');
        $proposal_req_data->set_email($user_data['email']);
        $proposal_req_data->set_mobile($user_data['mobile']);
        $proposal_req_data->set_houseno($user_data['house_num']);
        $proposal_req_data->set_street($user_data['street']);
        $proposal_req_data->set_locality($user_data['locality']);
        $proposal_req_data->set_cust_pincode($user_data['cust_pincode']);
        $proposal_req_data->set_state((!empty($statelist['reliance_code'])) ? $statelist['reliance_code'] : '0');
        $proposal_req_data->set_city((!empty($citylist['reliance_code'])) ? $citylist['reliance_code'] : '0');
        $proposal_req_data->set_district((!empty($city_dist_list)) ? $city_dist_list['district_id'] : '0');
        $proposal_req_data->set_ped_details($user_data['ped']);
        $proposal_req_data->set_nominee_name($user_data['nominee_name']);
        $proposal_req_data->set_nominee_dob($user_data['nominee_dob']);
        $proposal_req_data->set_nominee_relation($user_data['nominee_relation']);
        $proposal_req_data->set_agree_medical_checkup((isset($user_data['agree_med_chkup']) && ($user_data['agree_med_chkup'] == 1)) ? 1 : 0 );
        $proposal_req_data->set_nationality($user_data['nationality']);
        return $proposal_req_data;
    }

    public function check_reliance_policy_status($proposal_data){
        $proposal_req_data = new PolicyPageData();
        $ped_details = in_array('Yes', $proposal_data->get_ped_details());
        if($ped_details == 1 || $ped_details == true){
            $proposal_req_data->set_ped_status(Health_Constants::RELIANCE_PED_MSG);
        }
        return $proposal_req_data; 
    }

    public function check_ppc_case($proposal_data){
        $age_list = $proposal_data->get_age_list();
        $status = false;
        foreach($age_list as $mem_age){
            if($mem_age >= 45) {
                $status = true;
            }
        }
        return $status;
    }

    public function check_reliance_policy_type($trans_code){
        $usertdata = new HealthUserData();
        $data = $usertdata->get_by_usrdata($trans_code);
        $product_id = $data['productId'];
        $insurerId      = $data['insurer_name'];
        $product_type   = $data['product_type'];
        $suminsured    = $data['sum_insured'];
        $age_list           = explode('|',$data['age_list']);
        $ped_case = json_decode($data['ped_list'], True);
        $ped_details = in_array('Yes', $ped_case);
        $age = false;
        foreach($age_list as $mem_age){
            if(!empty($ped_details) && $ped_details == 1){
                $age['illness'] = 'true';
                $age['value'] = 'true'; 
            }if($mem_age >= 45){
                $age['memage'][]= $mem_age;
                $age['value'] = 'true'; 
            }
        }
        return $age;
    }


  public function populate_proposal_request($req_data){
        $client_details = $this->client_details($req_data);
        $insured_details = $this->insured_details($req_data);
        $policy_details = $this->policy_details($req_data);
        $risk_details = $this->risk_details($req_data);
        $nominee_details = $this->nominee_details($req_data);
        $premium_details = $this->premium_details($req_data);
        $previous_insurance_details = $this->previous_insurance_details($req_data);

        $req_xml = '<HealthDetails><ClientDetails>'.$client_details.'</ClientDetails><InsuredDetailsList>'.implode('',$insured_details).'</InsuredDetailsList><Policy>'.$policy_details.'</Policy><UploadDetails><DocumentType /></UploadDetails><RiskDetails>'.$risk_details.'</RiskDetails><NomineeDetails>'.$nominee_details.'</NomineeDetails><Premium>'.$premium_details.'</Premium><LstDiscount /><ErrorMessages><ErrMessages/></ErrorMessages><LstHealthCoverDetails /><PreviousInsuranceDetails>'.$previous_insurance_details.'</PreviousInsuranceDetails><UserID>'.Health_Constants::RELIANCE_USER_ID.'</UserID><SourceSystemID>'.Health_Constants::RELIANCE_SOURCE_SYSTEM_ID.'</SourceSystemID><AuthToken>'.Health_Constants::RELIANCE_AUTH_TOKEN.'</AuthToken><CoverDetails /><IsQuickquote>false</IsQuickquote><CIServicePEDList /><CIServicePreviousInsuraceDetailsList /></HealthDetails>';
        return $req_xml;
    }

    private function client_details($req_data){
        // Calculate elder member dob from age list
        foreach($req_data->get_age_list() as $agelist){
            $age[] = rtrim($agelist,'m');
        }
        $elder_age = max($age);
        $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
        $elder_key = array_search(max($age), $age);
        $client_details = '<ClientTypeID>'.Health_Constants::RELIANCE_CLIENT_TYPE_ID.'</ClientTypeID>
                            <DOB>'.$elderMemberDob.'</DOB>
                            <Email>'.$req_data->get_email().'</Email>
                            <ForeName>'.$req_data->get_firstname()[$elder_key].'</ForeName>
                            <Gender>'.$req_data->get_gender()[$elder_key].'</Gender>
                            <LastName>'.$req_data->get_lastname()[$elder_key].'</LastName>
                            <MaritalStatusID>'.$req_data->get_merital_status()[$elder_key].'</MaritalStatusID>
                            <MidName />
                            <MobileNo>'.$req_data->get_mobile().'</MobileNo>
                            <Nationality>'.$req_data->get_nationality().'</Nationality>
                            <OccupationID>'.$req_data->get_member_occupation()[$elder_key].'</OccupationID>
                            <PhoneNo />
                            <Salutation>'.$req_data->get_title()[$elder_key].'</Salutation>
                            <ClientAddress>
                                <CommunicationAddress>
                                    <Address1>'.$req_data->get_houseno().'</Address1>
                                    <Address2>'.$req_data->get_street().'</Address2>
                                    <Address3>'.$req_data->get_locality().'</Address3>
                                    <CityID>'.$req_data->get_city().'</CityID>
                                    <Country>India</Country>
                                    <DistrictID>'.$req_data->get_district().'</DistrictID>
                                    <Email>'.$req_data->get_email().'</Email>
                                    <Fax />
                                    <MobileNo>'.$req_data->get_mobile().'</MobileNo>
                                    <NearestLandmark />
                                    <PanNo>'.$req_data->get_pancard().'</PanNo>
                                    <PhoneNo />
                                    <Pincode>'.$req_data->get_cust_pincode().'</Pincode>
                                    <AreaID></AreaID>
                                    <StateID>'.$req_data->get_state().'</StateID>
                                </CommunicationAddress>
                                <PermanentAddress>
                                    <Address>
                                        <Address1>'.$req_data->get_houseno().'</Address1>
                                        <Address2>'.$req_data->get_street().'</Address2>
                                        <Address3>'.$req_data->get_locality().'</Address3>
                                        <CityID>'.$req_data->get_city().'</CityID>
                                        <Country>India</Country>
                                        <DistrictID>'.$req_data->get_district().'</DistrictID>
                                        <NearestLandmark />
                                        <Pincode>'.$req_data->get_cust_pincode().'</Pincode>
                                        <AreaID></AreaID>
                                        <StateID>'.$req_data->get_state().'</StateID>
                                    </Address>
                                </PermanentAddress>
                            </ClientAddress>';
        return $client_details;
    }

    private function insured_details($req_data){
        $insured_details = [];
        foreach($req_data->get_members_list() as $i => $relationship){
            if($relationship == 'SELF'){ $rel_id = '345'; }
            if($relationship == 'WIFE'){ $rel_id = '320'; } 
            if($relationship == 'HUSBAND'){ $rel_id = '320'; } 
            if($relationship == 'SON'){ $rel_id = '321'; } 
            if($relationship == 'DAUGHTER'){ $rel_id = '322'; } 
            if($relationship == 'FATHER'){ $rel_id = '319'; } 
            if($relationship == 'MOTHER'){ $rel_id = '1255'; } 
            $insured_details[] = '<InsuredDetail>
                                <RelationshipWithProposerID>'.$rel_id.'</RelationshipWithProposerID>
                                <Salutation>'.$req_data->get_title()[$i].'</Salutation>
                                <FirstName>'.$req_data->get_firstname()[$i].'</FirstName>
                                <LastName>'.$req_data->get_lastname()[$i].'</LastName>
                                <Gender>'.$req_data->get_gender()[$i].'</Gender>
                                <Age>'.trim($req_data->get_age_list()[$i],'m').'</Age>
                                <DOB>'.$req_data->get_dob_list()[$i].'</DOB>
                                <MaritalStatusID>'.$req_data->get_merital_status()[$i].'</MaritalStatusID>
                                <OccupationID>'.$req_data->get_member_occupation()[$i].'</OccupationID>
                                <PreExistingDisease>
                                    <IsExistingIllness>false</IsExistingIllness>
                                    <DiseaseList />
                                    <IsInsuredConsumetobacco />
                                    <HasAnyPreClaimOnInsured />
                                    <DetailsOfPreClaimOnInsured />
                                    <HasAnyPreHealthInsuranceCancelled />
                                </PreExistingDisease>
                                <OtherInsuranceList />
                            </InsuredDetail>';
        }
        return $insured_details;
    }

    private function policy_details($req_data){
        $policy_details = '<Tenure>'.$req_data->get_tenure().'</Tenure>
                            <PolicyStartDate>'.$req_data->get_policy_start().'</PolicyStartDate>
                            <PolicyEndDate>'.$req_data->get_policy_end().'</PolicyEndDate>
                            <AgentID>'.Health_Constants::RELIANCE_AGENT_ID.'</AgentID>
                            <AgentName>'.Health_Constants::RELIANCE_AGENT_NAME.'</AgentName>
                            <Branch_Code>'.Health_Constants::RELIANCE_BRANCH_CODE.'</Branch_Code>
                            <BusinessType>'.Health_Constants::RELIANCE_BUSINESS_TYPE.'</BusinessType>
                            <ProductCode>'.Health_Constants::RELIANCE_PRODUCT_CODE.'</ProductCode>
                            <ExternalSystemID>'.Health_Constants::RELIANCE_EXTERNAL_SYSTEM_ID.'</ExternalSystemID>
                            <BranchName>'.Health_Constants::RELIANCE_BRANCH_NAME.'</BranchName>';
        return $policy_details;
    }

    private function risk_details($req_data){
        // Calculate elder member dob from age list
        foreach($req_data->get_age_list() as $agelist){
            $age[] = rtrim($agelist,'m');
        }
        $elder_age = max($age);
        $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
        $cover_type_id = ($req_data->get_plan_type() == 'FF') ? 0 : 1;

        $risk_details = '<PlanID>'.Health_Constants::RELIANCE_PLAN.'</PlanID>
                        <DOBofSeniorMost>'.$elderMemberDob.'</DOBofSeniorMost>
                        <MemberCount>'.count($req_data->get_members_list()).'</MemberCount>
                        <MaxAge>'.$elder_age.'</MaxAge>
                        <CoverTypeID>'.$cover_type_id.'</CoverTypeID>
                        <SumInsured>'.$req_data->get_sum_insured().'</SumInsured>
                        <IsServiceTaxExemptionApplicable>false</IsServiceTaxExemptionApplicable>
                        <ServiceTaxExemptionID />
                        <IsAnyEmployeeOfRelianceADAGroup />
                        <CompanyNameID />
                        <EmployeeCode />
                        <EmailID />
                        <Iscrosssell />
                        <CrossSellPolicyNo />
                        <NoofMembersAbove21>'.$req_data->get_adult().'</NoofMembersAbove21>
                        <NoofMembersBelow21>'.$req_data->get_children().'</NoofMembersBelow21>
                        <PreviousCumulativeBonus />
                        <PreviousCumulativeBonusrate />
                        <CumulativeBonus />
                        <CumulativeBonusrate />
                        <ChangeinCoverageType>false</ChangeinCoverageType>
                        <AdditionofMemberatRenewal>false</AdditionofMemberatRenewal>
                        <DeletionofMemberatRenewal>false</DeletionofMemberatRenewal>';
        return $risk_details;
    }

    private function nominee_details($req_data){
        $nominee_details = '<FirstName>'.$req_data->get_nominee_name().'</FirstName>
                            <Salutation></Salutation>
                            <MiddleName />
                            <LastName>.</LastName>
                            <DOB>'.$req_data->get_nominee_dob().'</DOB>
                            <NomineeRelationshipID>'.$req_data->get_nominee_relation().'</NomineeRelationshipID>
                            <NomineeRelationshipOther />
                            <NomineeAddress>
                                <Address1>'.$req_data->get_houseno().'</Address1>
                                <Address2>'.$req_data->get_street().'</Address2>
                                <Address3>'.$req_data->get_locality().'</Address3>
                                <CityID>'.$req_data->get_city().'</CityID>
                                <Country>India</Country>
                                <DistrictID>'.$req_data->get_district().'</DistrictID>
                                <NearestLandmark />
                                <Pincode>'.$req_data->get_cust_pincode().'</Pincode>
                                <AreaID></AreaID>
                                <StateID>'.$req_data->get_state().'</StateID>
                            </NomineeAddress>';
        return $nominee_details;
    }
    
    private function premium_details($req_data){
        $premium_details = '<BasicPremium /><TotalPremium /><EducationalCess /><EducationalCessPercentage /><FinalPremium /><NetPremium /><SalesTax /><SalesTaxPercentage /><SecondaryAndHigherEducationalCess /><SecondaryAndHigherEducationalCessPercentage /><ServiceTax /><ServiceTaxPercentage /><Surcharge /><SurchargePercentage />';
        return $premium_details;
    }

    private function previous_insurance_details($req_data){
        $previous_insurance_details = '<PrevInsuranceID /><PrevYearPolicyNo /><PrevYearPolicyStartDate /><PrevYearPolicyEndDate />';
        return $previous_insurance_details;
    }


   public function parse_proposal_response($proposal_response,$proposal_req_data){
        $proposal_resp_data = new PolicyPageData();
        $proposal_resp_data->set_hl_trans_code($proposal_req_data->get_hl_trans_code());
        $proposal_resp_data->set_product_id($proposal_req_data->get_product_id());
        $proposal_resp_data->set_insurer_name($proposal_req_data->get_insurer_name());
        if(!empty($proposal_response) && empty($proposal_response['ErrorMessages']['ErrMessages'])) {
        $proposal_resp_data->set_referenceId($proposal_response['Policy']['ProposalNo']);
        foreach ($proposal_response['LstPortability'] as $premium) {
              foreach($premium as $value){
                if($proposal_req_data->get_sum_insured() == $value['SumInsured']){
                    $proposal_resp_data->set_sum_insured($value['SumInsured']);
                    $proposal_resp_data->set_final_premium($value['NetPremium']);
                    $proposal_resp_data->set_final_totalPremium($value['FinalPremium']);
                    if($value['LstTaxComponentDetails']['TaxComponentHealth']['TaxName'] == 'IGST') {
                        $proposal_resp_data->set_final_serviceTax($value['LstTaxComponentDetails']['TaxComponentHealth']['Amount']);
                    }else{
                        foreach($value['LstTaxComponentDetails'] as $serviceTax){
                            $proposal_resp_data->set_final_serviceTax($serviceTax[0]['Amount'] + $serviceTax[1]['Amount']);
                        }
                    }
                }
              }
            }
        }else{
            $proposal_resp_data->set_error_message($proposal_response['ErrorMessages']['ErrMessages']);
        }
        return $proposal_resp_data;
    }
}