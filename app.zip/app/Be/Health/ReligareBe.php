<?php
namespace App\Be\Health;
use App\Constants\Health_Constants;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthPlans;
use App\Models\Health\HealthQuoteResponse;
use App\Models\Health\HealthRates;
use Illuminate\Support\Facades\File;
use App\Be\Health\HealthQuoteBe;
use App\Models\Health\HealthState;
use App\Be\Health\HealthPolicyBe;
use App\Helpers\Health\Religare\ReligareProposal;
use DateTime;
use Log;
use App\Models\Health\data\QuoteRespData;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;

class ReligareBe{

  private function get_file($path){
    return File::get($path);
  }
  
  /* Quote Section */
  // This function will be removed, once these values are shifted to a table;
  private function coverage_values($product, $plan){
    if($product == 'religare_elite'){
      $covers = '[{"coverId":"Single Private Room","coverLimits":[]},{"coverId":"AYUR","coverLimits":[]},{"coverId":"DCP","coverLimits":[]},{"coverId":"AMBUL","coverLimits":[]},{"coverId":"DCP","coverLimits":[]},{"coverId":"DOM","coverLimits":[]},{"coverId":"DON","coverLimits":[]},{"coverId":"HC","coverLimits":[]},{"coverId":"HOSP","coverLimits":[]},{"coverId":"POST","coverLimits":[]},{"coverId":"PRE","coverLimits":[]},{"coverId":"RESSI","coverLimits":[]}]';
      return $covers;
    }
    if($product == 'religare_elite_plus'){
      $covers = '[{"coverId":"Single Private Room","coverLimits":[]},{"coverId":"AYUR","coverLimits":[]},{"coverId":"AMBUL","coverLimits":[]},{"coverId":"DCP","coverLimits":[]},{"coverId":"DOM","coverLimits":[]},{"coverId":"DON","coverLimits":[]},{"coverId":"HC","coverLimits":[]},{"coverId":"HOSP","coverLimits":[]},{"coverId":"POST","coverLimits":[]},{"coverId":"PRE","coverLimits":[]},{"coverId":"RESSI","coverLimits":[]}]';
      return $covers;
    }
    if($product == 'religare_global'){
      $covers = '[{"coverId":"Single Private Room","coverLimits":[]},{"coverId":"AYUR","coverLimits":[]},{"coverId":"AMBUL","coverLimits":[]},{"coverId":"DCP","coverLimits":[]},{"coverId":"DOM","coverLimits":[]},{"coverId":"DON","coverLimits":[]},{"coverId":"HC","coverLimits":[]},{"coverId":"HOSP","coverLimits":[]},{"coverId":"MA","coverLimits":[]},{"coverId":"POST","coverLimits":[]},{"coverId":"PRE","coverLimits":[]},{"coverId":"RESSI","coverLimits":[]}]';
      return $covers;
    }
    if($product == 'religare_super_saver'){
      $covers = '[{"coverId":"Single Private Room","coverLimits":[]},{"coverId":"AYUR","coverLimits":[]},{"coverId":"AMBUL","coverLimits":[]},{"coverId":"DCP","coverLimits":[]},{"coverId":"DOM","coverLimits":[]},{"coverId":"DON","coverLimits":[]},{"coverId":"HC","coverLimits":[]},{"coverId":"HOC","coverLimits":[]}]';
      return $covers;
    }
    
  }

  public function age_range($age_list, $mem_list){
    $flag    = true;
    foreach($age_list as $index => $age){
      if($mem_list[$index] == 'SONM' || $mem_list[$index] == 'UDTR'){
      }else{  
        if($age >=18 && $age < 100){
         
        } else {
          $flag = false;
        }
      }  

    }
    return $flag;
  }

  public function get_pattern($age_list,$mem_list,$rel){
    $pattern = '';
    // Checking for children in the relationship list
    if(in_array('SONM', $rel) || in_array('UDTR', $rel)){
      $child = $this->check_children($age_list,$mem_list);
      if($child == 0 || $child > 4){
        return null;
      }
      
      if(in_array('WIFE', $rel) || in_array('HUS', $rel)){
        switch ($child) {
          case '1' :
            $pattern = Health_Constants::PATT_2A_1C;
            break;
          case '2' :
            $pattern = Health_Constants::PATT_2A_2C;
            break;
          case '3' :
            $pattern = Health_Constants::PATT_2A_3C;
            break;
          case '4' :
            $pattern = Health_Constants::PATT_2A_4C;
            break;    
        }
      }else{
        switch ($child) {
          case '1' :
            $pattern = Health_Constants::PATT_1A_1C;
            break;
          case '2' :
            $pattern = Health_Constants::PATT_1A_2C;
            break;
          case '3' :
            $pattern = Health_Constants::PATT_1A_3C;
            break;
          case '4' :
            $pattern = Health_Constants::PATT_1A_4C;
            break;    
        }
      }

    }else{
      if(in_array('WIFE', $rel) || in_array('HUS', $rel)){
        $pattern = Health_Constants::PATT_2A;
      }else {
        $pattern = Health_Constants::PATT_1A;
      }
    }
    return $pattern;
  }

  public function check_children($age_list,$mem_list){
    $count    = 0;
    foreach($age_list as $index => $age){
      if($mem_list[$index] == 'SONM' || $mem_list[$index] == 'UDTR'){
        if($age >=1 && $age < 25){
          $count++;
        } 
      }
    }

    return $count;
  }

  public function calculate_quote($data){
    $agelist  = explode('|',$data['age_list']);
    $rel      = explode('|',$data['members_list']);
    $mem_list = explode('|', $data['members_list']);
    $plan     = array();
    $pattern       = $this->get_pattern($agelist,$mem_list,$rel);
    $plan_code     = '';
    $elder_member  = max($agelist);
    $member_count  = sizeof($agelist);
    $usr_tbl = new HealthUserData;
    //Religare doesn’t provide individualized Sum insured option for floater cases
    if($data['plan_type'] == 'INDV' && $member_count > 1){
      return null;
    }
    
    $column        = array('product_code','product_name','plan_code','plan_min_age','plan_max_age');
        
    if($data['product_type'] == 'S'){
      $bl = new HealthQuoteBe;
      $check_values  = array('plan_deductables' => $data['deductables'],'product_code' => 'INRELSTP','plan_insured_pattern' => $pattern, 'plan_si' => $data['sum_insured'], 'plan_tenure' => '1');
    }else{
      $check_values  = array('product_code' => 'INREL','plan_insured_pattern' => $pattern, 'plan_si' => $data['sum_insured'], 'plan_tenure' => '1');
    }
   
    // Getting Plan details
    $plan_tbl = new HealthPlans;
    $result   = $plan_tbl->get_data($column,$check_values);
    if($result){
 

      foreach($result as $item) { 
        if($elder_member  >= $item['plan_min_age'] && $elder_member <= $item['plan_max_age']){
          $plan      = $item; 
           
          unset($plan['plan_min_age']);
          unset($plan['plan_max_age']);
        } // End Duration check 
      }// End foreach
    }else{
      return null;
    }
    if(!empty($plan)){
    
      $columnn        = array('base_premium');
      $check_valuess  = array('plan_code' => $plan['plan_code']);
      $rates_tbl      = new HealthRates;
      $result         = $rates_tbl->get_data($columnn,$check_valuess);
      if($result){
        $base_premium = (int)$result['base_premium'];

        if($data['product_type'] == 'B'){
          // Applying discount for age > 60
          if($elder_member > 60){
            $base_premium = $base_premium - ($base_premium * Health_Constants::RELIGARE_SENIOR_DISCOUNT);
          }
        }

        $plan['base_premium'] = $base_premium;
        $plan['gst'] = round($plan['base_premium'] * Health_Constants::GST); 
        $plan['total_premium'] = round($plan['base_premium'] + $plan['gst']);
        if($data['product_type'] == 'B' && ($data['sum_insured'] == '300000' || $data['sum_insured'] == '400000')){
          // UPDATING ADD-ON IN TABLE
          $add_on_choice = json_decode($data['add_on'], true);
          $add_on_choice['ncb'] = 'Y';
          $add_on_choice  = json_encode($add_on_choice);
          $column  = array('add_on' => $add_on_choice);
          $check_values = array('session_id' => $data['session_id']);
          $usr_tbl->update_data($column,$check_values);
          $ncb_rate = ($elder_member<=45) ? '.2' : '.3';
          $plan['product_name'] = 'Care with NCB Super';
          $plan['base_premium'] = $plan['base_premium'] + ($plan['base_premium'] * $ncb_rate);
          $plan['gst']          = round($plan['base_premium'] * Health_Constants::GST);
          $plan['total_premium'] = round($plan['base_premium'] + $plan['gst']); 
        }else{
          // UPDATING ADD-ON IN TABLE
          $add_on_choice['ncb'] = 'N'; $add_on_choice['ur'] = 'N';
          $add_on_choice  = json_encode($add_on_choice);
          $column  = array('add_on' => $add_on_choice);
          $check_values = array('session_id' => $data['session_id']);
          $usr_tbl->update_data($column,$check_values);
        }
        if($data['product_type'] == 'B'){
          $plan['product_code'] = $this->map_plan_name($data['sum_insured']);
        }
     
        return $this->save_quote($plan, $data); 
      }else{
        return null;
      }   
    }else{
      return null;
    }
  }

  public function save_quote($plan, $data){
      $quote_resp = new HealthQuoteResponse();
      $arr['session_id']       = $data['session_id'];
      $arr['trans_code']       = $data['session_id'];
      $arr['productId']        = $plan['product_code'];
      $arr['plan_code']        = $plan['plan_code'];
      $arr['insurerId']        = Health_Constants::RELIGARE_ID;
      $arr['health_user_id']   = $data['id'];
      $arr['productName']      = '&nbsp;';
      $arr['product_planname'] = $plan['product_name'];
      $arr['insurerName']      = Health_Constants::RELIGARE_NAME;
      $arr['netPremium']       = $plan['base_premium'];
      $arr['serviceTax']       = $plan['gst'];
      $arr['totalPremium']     = $plan['total_premium'];
      $arr['planSI']           = $data['sum_insured'];
      $arr['cgst']             = (int) $plan['gst'] / 2;
      $arr['sgst']             = (int) $plan['gst'] / 2;
      $arr['covers']           = $this->coverage_values($plan['product_code'], $plan['plan_code']);
      $check_values = array('productId' =>$plan['product_code']);
      $quote_response[]  =  $quote_resp->update_or_create($check_values,$arr);
      return $quote_response;
  } 



  private function map_plan_name($si){
    if($si == 200000 || $si == 300000 || $si == 400000){
      return 'religare_super_saver';
    }elseif($si == 500000 || $si == 700000 || $si == 1000000){
      return 'religare_elite';
    }elseif($si == 1500000 || $si == 2000000 || $si == 2500000 || $si == 3000000 || $si == 4000000){
      return 'religare_elite_plus';
    }elseif($si == 5000000 || $si == 6000000){
      return 'religare_global';
    }

  }

  /* Quote Section Ends */

  public function is_religare_type($data){
      $relationship = explode('|',$data['members_list']);
      $rel_flag = true;
      if(in_array("FATH", $relationship) || in_array("MOTH", $relationship)){
          $rel_flag = false;
      }
      return $rel_flag;
  }

  public function parse_proposal_response($xml){
      $proposal_num = '';
      $user_table   = new HealthUserData;
      $lib          = new HealthLib;
      $trans_code =  session('hel_suid');

      $insta_lib = new InstaLib();
          $curr_date = $insta_lib->today_date_dMY();
      if(strpos($xml, 'err-description') == false){ 
        $dom = new \DOMDocument;
        try{
          $dom->loadXML($xml);
        }catch (\Exception $e){
          Log::info('HEALTH_RELIGARE_PROPOSAL_RESPONSE_PARSING'. print_r($e->getMessage(),true));
          return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        }
        $proposal_num = $dom->getElementsByTagName("proposal-num")->item(0)->nodeValue; 
        if(!empty($proposal_num)){
          $passed_premium   = (int)session('health_religare_premium');
          try{
          $response_premium = (int)$dom->getElementsByTagName("premium")->item(0)->nodeValue;
          }catch(\Exception $e){
            $response_premium = $passed_premium;
          }
          $difference       = abs($response_premium - $passed_premium);

            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS20';
            $input['trans_status'] = 'TS20';
            $user_table->set_by_usrdata($trans_code, $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
          // Updating usertable with premium & tax
          $column = array('finalPremium' => $response_premium, 'totalPremium' => $response_premium ,'finalTax' => $lib->get_tax_premium($response_premium));
          $check_values = array('session_id' => session('hel_suid'));
          $user_table->update_data($column ,$check_values);

          $ppc = $this->check_ppc($trans_code);
          

          if($difference >=1){
            $arr['proposalno'] = $proposal_num;
            $arr['PG URL']       = Health_Constants::RELIGARE_PG_URL;
            $arr['RETURN URL']   = url('/').Health_Constants::RELIGARE_RETURN_URL;
            Log::info('HEALTH_RELIGARE_PG_REQUEST '. print_r($arr,true));

            //code for mismatch
            $input['proposal_date'] = $curr_date; 
            $input['proposal_status'] = 'TS21';
            $input['trans_status'] = 'TS21';
            $input['proposal_ref_number'] = $proposal_num;
            $user_table->set_by_usrdata($trans_code, $input);

            return array('status' => 0, 'ppc_data'=>$ppc, 'mismatch' => 1, 'error' => 0, 'actual_premium' =>$response_premium , 'passed_premium' => $passed_premium, 'proposalno' => $arr['proposalno'], 'returnurl' => $arr['RETURN URL'], 'pgurl' => $arr['PG URL']);

          }else {
            $arr['proposalno'] = $proposal_num;
            $arr['Premium']    = $passed_premium;
            $arr['PG URL'] = Health_Constants::RELIGARE_PG_URL;
            $arr['RETURN URL'] = url('/').Health_Constants::RELIGARE_RETURN_URL;

            Log::info('HEALTH_RELIGARE_PG_REQUEST '. print_r($arr,true));
            //// proposal accepted
                $input['proposal_date'] = $curr_date;
                $input['proposal_status'] = 'TS15';
                $input['trans_status'] = 'TS15';
                $input['proposal_ref_number'] = $proposal_num;
                $user_table->set_by_usrdata($trans_code, $input);  
            return array('status' => 1, 'ppc_data'=>$ppc, 'proposalno' => $arr['proposalno'], 'returnurl' => $arr['RETURN URL'], 'pgurl' => $arr['PG URL'], 'premium' => $passed_premium);

          } 
          
        }else {
          //proposal error
              $input['proposal_date'] = $curr_date;
                $input['proposal_status'] = 'TS01';
                 $input['trans_status'] = 'TS01';
                $input['proposal_ref_number'] = '';
                $user_table->set_by_usrdata($trans_code, $input); 
                // Mail config
              $email_engine =  new EmailEngine; 
              $email_engine->send_email($trans_code); 
          return array('status' => 0, 'ppc_data'=> false, 'mismatch' => 0, 'error' => 0);
        }
      }
      else {
        $message ='';
        $dom = new \DOMDocument;
        $dom->loadXML($xml);
        $error = $dom->getElementsByTagName("err-description")->item(0)->nodeValue;
        if(strpos($error, 'System encountered') !== false || strpos($error, 'time out has occurred') !== false){
          Log::info('HEALTH_RELIGARE_PROPOSAL_RESPONSE '. print_r($error,true));
          return array('status' => 0, 'ppc_data'=> false, 'mismatch' => 0, 'error' => 0);
        } 
        $head_msg = 'Opps !. Please Correct the following errors <br>';
        $message  = $error;
        $message  = $head_msg.$message; 

        //proposal error
                $input['proposal_date'] = $curr_date;
                $input['proposal_status'] = 'TS01';
                 $input['trans_status'] = 'TS01';
                $input['proposal_ref_number'] = '';
                 $input['proposal_desc'] = $message;
                $user_table->set_by_usrdata($trans_code, $input); 
                // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($trans_code);
                return array('status' => 0, 'ppc_data'=> false, 'mismatch' => 0, 'error' => 1, 'message' => $message);
      }

    }
  
  public function check_ppc($trans_code){
      $u_tbl      = new HealthUserData;
      $user_data  = $u_tbl->getUserTData($trans_code);
      $age_list   = explode('|', $user_data['age_list']);
      $elder      = max($age_list);
      $ppc        = array('status' => false,'ped_flag' => false, 'age_flag' => false, 'sum_insured_flag' => false, 'product_type' => $user_data['product_type']);
      $ppc['url'] = url('/').Health_Constants::RELIGARE_PPC_URL;

      if($user_data['product_type'] == 'B'){
        if($elder > 50){
          $ppc['status'] = true;
          $ppc['age_flag'] = true;
          $ppc['age'] = $elder;
        }
      }
      if($user_data['product_type'] == 'S'){
        if($elder >= 60){
          $ppc['status'] = true;
          $ppc['age_flag'] = true;
          $ppc['age'] = $elder;
        }
      }
      if($user_data['product_type'] == 'B'){
        if($user_data['sum_insured']  > 5000000){
          $ppc['status'] = true;
          $ppc['sum_insured_flag'] = true;
          $ppc['sum_insured'] = $user_data['sum_insured'];
        }
      } 
      if($user_data['product_type'] == 'S'){
        if( ( (int)$user_data['sum_insured'] + (int)$user_data['deductables'] ) >= 4000000){ 
          $ppc['status'] = true;
          $ppc['sum_insured_flag'] = true;
          $ppc['sum_insured'] = $user_data['sum_insured'];
        }
      }  
      if($user_data['ped_list']){
        $ppc['status'] = true;
        $ppc['ped_flag']    = true;
      }
      return $ppc;
  }

  public function parse_ppc_case($request){
    
    $ppc      = $request['data']['ppc_data'];
    $response = array();
    $response['insurer_id'] = 'religare';
    if($ppc['ped_flag'] == 'true'){
      $response['ped_check']  = true;
      $response['ped_msg']    = 'Pre-existing disease is disclosed';
    }
    if($ppc['age_flag'] == 'true' ){
      $response['age_check']  = true;
      $response['age_msg']    = 'Insured member age is '.$ppc['age'].' years.';
    }
    if($ppc['sum_insured_flag'] == 'true'){
      $response['si_check']  = true;
      $response['si_msg']    = 'Sum Insured is '.$ppc['sum_insured'].' INR.';
    }
    return $response;
  }

  private function get_add_on($data){
    $add_on   = json_decode($data, true);
    $response = 'CARE';
    if($add_on['ncb'] == 'Y'){
      $response = 'CAREWITHNCB';
    }
    if($add_on['ur'] == 'Y'){
      $response = 'UAR';
    }
    if($add_on['ur'] == 'Y' && $add_on['ncb'] == 'Y'){
      $response = 'CAREWITHNCB,UAR';
    }
    return $response;
  }

  private function format_ped_date($since){
      return DateTime::createFromFormat('m/Y', $since);
  }

  public function set_policy($session_key){
      $u_tbl     = new HealthUserData;
      $user_data = $u_tbl->getUserTData($session_key);
      $xml       = $this->get_file(app_path(
                                      ($user_data['product_type'] == 'S' ) ? 
                                        Health_Constants::RELIGARE_PRP_FILE_STOPUP : 
                                        Health_Constants::RELIGARE_PRP_FILE)
                                  );
      $additional_insured_template = $this->get_file(app_path(Health_Constants::RELIGARE_ADDI_FILE));
      $dob       = explode('|', $user_data['dob_list']);
      $firstname = explode('|', $user_data['firstname']);
      $lastname  = explode('|', $user_data['lastname']);
      $gender    = explode('|', $user_data['gender']);
      $title     = explode('|', $user_data['title']);
      $members   = explode('|', $user_data['members_list']);
      $bl        = new ReligareBe;
      $state_obj = new HealthState;
      $column    = array('religare_code');
      $check_values = array('state_code' => $user_data['state']);
      $state     = $state_obj->get_data($column, $check_values)[0]['religare_code'];

      $member_count = sizeof($dob);
      $product      = 'STOPUP';
      $type         = ($member_count < 2) ? 'INDIVIDUAL' : 'FAMILYFLOATER';

      $tokens          = explode(',',Health_Constants::RELIGARE_PR_TOKEN);
      $token_values    = array();
      if($user_data['product_type'] == 'B' ){
        $token_values[]  = $this->get_add_on($user_data['add_on']);
        $product = 'BASIC';
      }else { unset($tokens[0]); }
      $token_values[]  = 'NEWBUSINESS'; 
      $token_values[]  = ($user_data['product_type'] == 'S' ) ? Health_Constants::RELIGARE_S_PRODUCT_ID : Health_Constants::RELIGARE_PRODUCT_ID;
      $token_values[]  = Health_Constants::RELIGARE_AGENT_ID;
      $token_values[]  = $type;
      $token_values[]  = date('d/m/Y', strtotime($dob[0]));
      $token_values[]  = $firstname[0];
      $token_values[]  = strtoupper(($gender[0] === 'M') ? 'Male' : 'Female');
      $token_values[]  = strtoupper(uniqid()); 
      $token_values[]  = $lastname[0];
      $token_values[]  = $user_data['house_num'].','.$user_data['street'];
      $token_values[]  = $user_data['locality'];
      $token_values[]  = $user_data['city'];
      $token_values[]  = $user_data['city'];
      $token_values[]  = $user_data['pincode'];
      $token_values[]  = $state;
      $token_values[]  = $user_data['mobile'];
      $token_values[]  = $user_data['email'];
      $token_values[]  = ($user_data['totalPremium'] >= Health_Constants::RELIGARE_PAN_PR_LIMIT) ? strtoupper($user_data['pan_number']) : '';
      $token_values[]  = strtoupper($title[0]);
      $token_values[]  = $user_data['nominee_name'];
      $token_values[]  = $user_data['nominee_relation'];
      $token_values[]  = $this->map_suminsured($user_data, $type, $product);
      
      $xml     = str_replace($tokens, $token_values , $xml);

      // PED QUESTIONS FOR PRIMARY INSURED
      $ped_carrier     = $this->get_file(app_path(Health_Constants::RELIGARE_PED_CHOICE));
      $ped             = json_decode($user_data['ped_list'],true);  
      $ped_flag        = false;
      if(empty($ped)){
         //No PED CASE
         $ped_flag     = true;
         $ped_carrier  = str_replace('{PED_CHOICE}', 'NO' , $ped_carrier);
      }else{
          foreach($ped['ped_list'] as $key => $data){
            if($data){
               $file_loc     = str_replace('{FILE_NAME}', $key , app_path(Health_Constants::RELIGARE_PED_ROUTE));
               $temp_file    = $this->get_file($file_loc);
               if(isset($ped['ped_since_year'][$key][0])){
                  $ped_flag     = true;
                  $ped_carrier  = str_replace('{PED_CHOICE}', 'YES' , $ped_carrier);
                  $since        = $ped['ped_since_month'][$key][0].'/'.$ped['ped_since_year'][$key][0];
                  $since        = $this->format_ped_date($since);
                  try{
                    $ped_carrier .= str_replace('{SINCE}', $since->format('m/Y') , $temp_file);
                  }catch(\Exception $e){}

                  try{
                    $ped_carrier  = str_replace('{CONDITION}', $ped['ped_details'][$key][0] , $ped_carrier);
                  }catch(\Exception $e){}
               }
            }
         }
      }
      if(!$ped_flag){
        $ped_carrier  = str_replace('{PED_CHOICE}', 'NO' , $ped_carrier);
      }

      $xml = str_replace('{PED_PRIMARY}',$ped_carrier, $xml);
      
      $tokens  = explode(',',Health_Constants::RELIGARE_ADDI_TOKEN);
      $insured = '';
      unset($token_values); $token_values = array();

      for($i=1; $i<$member_count; $i++){ 
         $insured .= $additional_insured_template;
         
         $token_values[] = date('d/m/Y', strtotime($dob[$i]));
         $token_values[] = $firstname[$i];
         $token_values[] = strtoupper(($gender[$i] === 'M') ? 'Male' : 'Female');
         $token_values[] = strtoupper(uniqid());
         $token_values[] = $lastname[$i];
         $token_values[] = $user_data['house_num'].','.$user_data['street'];
         $token_values[] = $user_data['locality'];
         $token_values[] = $user_data['city'];
         $token_values[] = $user_data['city'];
         $token_values[] = $user_data['pincode'];
         $token_values[] = $state;
         $token_values[] = $user_data['mobile'];
         $token_values[] = $user_data['email'];
         $token_values[] = $this->get_relationship_code($members[$i]);
         $token_values[] = strtoupper($title[$i]);
         $insured        = str_replace($tokens, $token_values, $insured);

         // PED QUESTIONS FOR OTHER MEMBERS
         $ped_carrier     = $this->get_file(app_path(Health_Constants::RELIGARE_PED_CHOICE));
         $ped             = json_decode($user_data['ped_list'],true);  
         $ped_flag        = false;
         if(empty($ped)){
          //No PED CASE
          $ped_flag     = true;
          $ped_carrier  = str_replace('{PED_CHOICE}', 'NO' , $ped_carrier);
         }else{
          foreach($ped['ped_list'] as $key => $data){
            if($data){
               $file_loc     = str_replace('{FILE_NAME}', $key , app_path(Health_Constants::RELIGARE_PED_ROUTE));
               $temp_file    = $this->get_file($file_loc);
               if(isset($ped['ped_since_year'][$key][$i])){
                  $ped_flag     = true;
                  $ped_carrier  = str_replace('{PED_CHOICE}', 'YES' , $ped_carrier);
                  $since        = $ped['ped_since_month'][$key][$i].'/'.$ped['ped_since_year'][$key][$i];
                  $since        = $this->format_ped_date($since);
                  try{
                    $ped_carrier .= str_replace('{SINCE}', $since->format('m/Y') , $temp_file);
                  }catch(\Exception $e){}

                  try{
                    $ped_carrier  = str_replace('{CONDITION}', $ped['ped_details'][$key][$i] , $ped_carrier);
                  }catch(\Exception $e){}
               }
            }
          }
        }  

        if(!$ped_flag){
          $ped_carrier  = str_replace('{PED_CHOICE}', 'NO' , $ped_carrier);
        }

        $insured = str_replace('{PED}',$ped_carrier, $insured);  
        unset($token_values);
      }  

      $xml = str_replace('{PARTY_DO_LIST}',$insured, $xml);
      session(['health_religare_premium' => $user_data['totalPremium']]);

    return $xml;
  }

  private function get_relationship_code($name){
      switch(strtolower($name)){
        case 'mother'   : return 'MOTH';
                          break;
        case 'father'   : return 'FATH';
                          break;
        case 'wife'     : return 'SPSE';
                          break;
        case 'husband'  : return 'SPSE';
                          break;
        case 'son'      : return 'SONM';
                          break;
        case 'daughter' : return 'UDTR';
                          break; 
                default : return $name;              
      }
    }

  private function map_suminsured($user_data, $type, $product){
    if($product == 'BASIC'){
         switch ($user_data['sum_insured']) {
            case '300000':
               $si = ($type == 'FAMILYFLOATER') ? '060' : '059';
               return $si;
               break;
            case '400000':
               $si = ($type == 'FAMILYFLOATER') ? '064' : '063';
               return $si;
               break;
            case '500000':
               $si = ($type == 'FAMILYFLOATER') ? '068' : '067';
               return $si;
               break; 
            case '700000':
               $si = ($type == 'FAMILYFLOATER') ? '076' : '075';
               return $si;
               break;
            case '1000000':
               $si = ($type == 'FAMILYFLOATER') ? '088' : '087';
               return $si;
               break;
            case '1500000':
               $si = ($type == 'FAMILYFLOATER') ? '090' : '089';
               return $si;
               break;
            case '2000000':
               $si = ($type == 'FAMILYFLOATER') ? '092' : '091';
               return $si;
               break;
            case '2500000':
               $si = ($type == 'FAMILYFLOATER') ? '094' : '093';
               return $si;
               break;
            case '3000000':
               $si = ($type == 'FAMILYFLOATER') ? '096' : '095';
               return $si;
               break;
            case '4000000':
               $si = ($type == 'FAMILYFLOATER') ? '098' : '097';
               return $si;
               break;
            case '5000000':
               $si = ($type == 'FAMILYFLOATER') ? '100' : '099';
               return $si;
               break;
            case '6000000':
               $si = ($type == 'FAMILYFLOATER') ? '102' : '101';
               return $si;
               break;                               
            default:
               return '0';
               break;
         }
    } 
    if($product == 'STOPUP'){
      $columns      = array('plan_si_code');
      $check_values = array('plan_code' => $user_data['plan_code']);
      $plan = new HealthPlans;
      $si   = $plan->get_data($columns,$check_values);
      if($si){
        return '0'.$si[0]['plan_si_code'];
      }
      return null;
    } 

  }

  public static function set_proposal_data($data){
    $session_key = $data['session_id'];
    $user_table   = new HealthUserData;
    $lib         = new HealthLib;
    // Identifies the data from which TAB, Eg: Insured, Communication
    $section     = $data['id'];
    
    // Unsetting the extra values
    unset($data['session_id']);
    unset($data['id']);
    unset($data['_token']);

    // Insured section
      if($section == 'insured'){
      $dob               = array();
      $age_list          = $lib->get_membersage($data['dob_list']);
      $data['age_list']  = $age_list['agelist'];
      // Re-formating d/m/y to Y-m-d
      foreach ($data['dob_list'] as $value) {
        $dt    = DateTime::createFromFormat('d-m-Y', $value);
        $dob[] = $dt->format('Y-m-d');
      }
      $member_count      = sizeof($dob);
      $data['dob_list']  = implode('|', $dob);
      $data['firstname'] = implode('|', $data['firstname']);
      $data['lastname']  = implode('|', $data['lastname']);
      if($member_count < 2){
        if($data['gender'] == 'M'){
          $data['title'] = 'Mr';
        }else{
          $data['title'] = 'Ms';
        }
      }

      $column = array('members_list', 'gender', 'title');
      $check_values = array('session_id' => $session_key);
      $response = $user_table->get_data($column, $check_values);
      $gender   = $response[0]['gender'];
      $gender   = explode('|' , $gender);
      $title    = $response[0]['title'];
      $title   = explode('|' , $title);
      $relationship = $response[0]['members_list'];
      $relationship = explode('|' , $relationship);
      if((!in_array('Wife', $relationship) || !in_array('Hus', $relationship) ) && $member_count < 2){
          $gender[0] = $data['gender'];
          if($data['gender'] == 'M'){
            $title[0] = 'Mr';
          }else{
            $title[0] = 'Ms';
          }
        $data['title'] = implode('|' , $title);
        $data['gender'] = implode('|' , $gender); 
      }  
      }
    // Insured section ends

    // Nominee Details
      if($section == 'nominee_details'){
        if(isset($data['add_on'])){
          $data['add_on'] = json_encode($data['add_on']);
        }
      }
    // Nominee Details ends  

    // Health History Section 
      if($section == 'healthhistory'){
        if(isset($data['ped_since_year']) && isset($data['ped_details'])){
          $data['ped_list'] = json_encode(array('ped_list' => $data['ped_list'], 'ped_since_year' => $data['ped_since_year'],'ped_since_month' => $data['ped_since_month'], 'ped_details' => $data['ped_details']));
        }elseif(isset($data['ped_since_year'])) {
          $data['ped_list'] = json_encode(array('ped_list' => $data['ped_list'], 'ped_since_year' => $data['ped_since_year'],'ped_since_month' => $data['ped_since_month']));
        }else{
          $data['ped_list'] = null;
        } 
      }
    // Health History Section 
    try {

      $health_transaction = $user_table->update_or_create(array('session_id' => $session_key), $data);
      return $health_transaction->id;
    } catch (Exception $e) {
      Log::info('HEALTH_RELIGARE_SAVE_PROPOSAL'. print_r($e->getMessage(), true));
      return 0;
    }  

  }

  public function parse_pg_response($pg_response){
    $healthtpolicy = new HealthTPolicy();
    $u_tbl       = new HealthUserData;

    if(!session()->has('hel_suid')){
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }
    $session_key = session('hel_suid');
    $trans_code = $session_key;
    $user_data   = $u_tbl->getUserTData($session_key);
    if(!$user_data){ 
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }    
    $status = (isset($pg_response['uwDecision']) && $pg_response['uwDecision'] == "INFORCE") ? true : false;

       // payment code 
      $insta_lib = new InstaLib();
      $curr_date = $insta_lib->today_date_dMY();
      $input['payment_date'] = $curr_date;
      $input['payment_ref_number'] = $pg_response['transactionRefNum'];
      if($status){
        $input['policy_num'] = $pg_response['policyNumber'];
        $input['payment_status'] = 'TS17';
        $input['trans_status'] = 'TS17';
        $health_transaction = $u_tbl->update_or_create(array('trans_code' => $trans_code), $input);
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($trans_code);
        $input['policy_status'] = 'TS19';
        $health_transaction = $u_tbl->update_or_create(array('trans_code' => $trans_code), $input);
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($trans_code);
      } else{
        $input['reference_num'] = $pg_response['transactionRefNum'];
        $input['payment_status'] = 'TS02';
        $health_transaction = $u_tbl->update_or_create(array('trans_code' => $trans_code), $input);
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($trans_code);
        $input['trans_status'] = 'TS03';
        $input['policy_status'] = 'TS03';
        $health_transaction = $u_tbl->update_or_create(array('trans_code' => $trans_code), $input);
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($trans_code);
      }
      $input['policy_date'] = $curr_date;
      $u_tbl->set_by_usrdata($session_key, $input); 

      if($status){
        $input['trans_code'] = $session_key.'_DONE';
        $u_tbl->set_by_usrdata(array($session_key), $input);
        $usr_data = $u_tbl->getUserTData($session_key.'_DONE');
       // Policy Counter Service
            $policy_service = new PolicyCounterService();
            $req_arr = array(
                        "module_name"=> "HL",
                        "insurer_code"=> "RELIGARE",
                        "agent_code"=> (empty($usr_data['agent_code'])) ? null : $usr_data['agent_code'],
                        "policy_date"=> $curr_date,
                        "policy_type"=> ($usr_data['product_type'] == 'B') ? 'C' : 'STP',
                        "policy_nature"=> "New",
                        "policy_number"=> $pg_response['policyNumber'],
                        "od_premium"=> $usr_data['basePremium'],
                        "tp_premium"=> 0,
                        "total_premium"=> $usr_data['basePremium'],
                        "tax"=> round($usr_data['serviceTax']),
                        "final_premium"=> $usr_data['totalPremium']
            );
            $response_status = $policy_service->service_handler($req_arr);
            Log::info('Policy Counter Status '.$usr_data['trans_code'].':', array($response_status));
            // Ends Policy Counter Service
            $policy_transaction = $healthtpolicy->set_policy_details($usr_data);
      }


    $policy_link = ($status) ? url('/').Health_Constants::RELIGARE_PDF_INTERNAL_URL.$pg_response['policyNumber'] : false;
    return json_encode(['status'=> $status,   
           'logo' => 'religare', 
           'pg_response' => $pg_response, 
           'policy_link' => $policy_link,
           'user_data' => $user_data]);
  }

  public function parse_pdf_response($result){
    $dom = new \DOMDocument;
    try{
      $dom->loadXML($result);
    }catch (\Exception $e){
      Log::info('HEALTH_RELIGARE_PDF_RESPONSE_PARSING'. print_r($e->getMessage(),true));
    }
    try{

      $response = $dom->getElementsByTagName("return")->item(0)->nodeValue;
    }catch(\Exception $e){
      return false;
    } 
      $response = simplexml_load_string('<?xml version="1.0" encoding="ISO-8859-1"?>    
                                           <documents>'.$response.'</documents>'); 
    $data = $response->StreamData;
    if($response->Status == 'SUCCESS'){
      return $data;
    }
    return false;
  }

  public function get_proposal_inputs($trans_code){
    $bl = new HealthPolicyBe;
    $data = $bl->get_proposal_inputs($trans_code, 'religare_code');
    $data['userdata']['dob_list'] = $this->set_dob_list($data);
    $data['userdata']['ped_year'] = array();
    foreach ($data['userdata']['dob_list'] as $key => $date) {
      $data['userdata']['ped_year']['min'][]  = date('Y', strtotime($date['min_date']));
      $data['userdata']['ped_year']['max'][]  = date('Y');
    }
    $data['userdata']['add_on']   = json_decode($data['userdata']['add_on'],true);
    if($data['userdata']['totalPremium'] >= Health_Constants::RELIGARE_PAN_PR_LIMIT){
      $data['en_rel_pan_id'] = true;
    }
    if($data['userdata']['product_type'] == 'B'){
      $data['en_add_on'] = true;
    }
    if(sizeof($data['userdata']['members_list']) < 2){
      $data['en_gender'] = true;
      if(in_array('WIFE',$data['userdata']['members_list']) || in_array('HUS',$data['userdata']['members_list'])){
        $data['en_gender'] = false;
      }
      
    }
    if($data['userdata']['product_planname'] == 'Care with NCB Super'){
      $data['dis_add_on_ncb'] = true;
      $data['add_on_ncb_label'] = '(Included by Default)';
    }
    return $data;
  }
  public function set_dob_list($data){
    $bl = new HealthPolicyBe;
    $data['userdata']['dob_list'] = array();
    foreach($data['userdata']['age_list'] as $index => $age){
            $data['userdata']['dob_list'][] = $bl->dob_generator($age);
    }
    return $data['userdata']['dob_list'];
  }


  public function parse_quote_response($quote_response, $quote_req_data){
    if(!empty($quote_response)){ 
      foreach($quote_response as $response){
        $quote_resp_data = new QuoteRespData();
        $quote_resp_data->set_trans_code($quote_req_data['trans_code']);
        $quote_resp_data->set_sum_insured($quote_req_data['sum_insured']);
        $super_topup = ($quote_req_data['product_type'] == 'S') ? 'yes':'no' ;
        $quote_resp_data->set_super_topup_opted($super_topup);
        $quote_resp_data->set_deductible_amount($quote_req_data['deductables']);
        $quote_resp_data->set_product_type($quote_req_data['product_type']);
        $quote_resp_data->set_plan_type($quote_req_data['plan_type']);
        $quote_resp_data->set_premium($response['attributes']['netPremium']);
        $quote_resp_data->set_serviceTax($response['attributes']['serviceTax']);
        $quote_resp_data->set_cgst($response['attributes']['cgst']);
        $quote_resp_data->set_sgst($response['attributes']['sgst']);
        $quote_resp_data->set_totalPremium($response['attributes']['totalPremium']);
        $quote_resp_data->set_product_id($response['attributes']['productId']);
        $quote_resp_data->set_planCode($response['attributes']['plan_code']);
        $quote_resp_data->set_product_name($response['attributes']['product_planname']);
        $quote_resp_data->set_insurer_name('religare');
        $quote_resp_data->set_insurer_code('RELIGARE');
        $resp_data[] = $quote_resp_data;
      } 
      return $resp_data;
    }
    return null;
  }


}