<?php
namespace App\Be\Health;
use App\Models\Health\data\QuoteReqData;
use App\Models\Health\data\QuoteRespData;
use App\Models\Health\data\PolicyPageData;
use App\Constants\Health_Constants;
use App\Models\Health\HealthUserData;
use GuzzleHttp\Client;
use DateTime;
use Log;

class StarBe {
 
	public function __construct(){
    }

	public function set_quote_request($user_data){
		$quote_req_data = new QuoteReqData();
		$quote_req_data->set_trans_code($user_data['trans_code']);
		$quote_req_data->set_pincode($user_data['pincode']);
		$quote_req_data->set_members_list(explode('|',$user_data['members_list']));
		$quote_req_data->set_dob_list(explode('|',$user_data['dob_list']));
		$quote_req_data->set_age_list(explode('|',$user_data['age_list']));
		$quote_req_data->set_adult($user_data['adult']);
		$quote_req_data->set_children($user_data['children']);
		$quote_req_data->set_tenure($user_data['tenure']);
		$quote_req_data->set_sum_insured($user_data['sum_insured']);
		$quote_req_data->set_plan_type($user_data['plan_type']);
		$quote_req_data->set_product_type($user_data['product_type']);
		return $quote_req_data;
	}

	public function product_map($data_obj) {
		$return_arr = [
			"MCINEW" => $this->mci_plan($data_obj),
			"COMPREHENSIVEIND" => $this->comprehensive_indv_plan($data_obj),
			"COMPREHENSIVE" => $this->comprehensive_floater_plan($data_obj),
			"FHONEW" => $this->fho_plan($data_obj),
			"REDCARPET" => $this->red_carpet_plan($data_obj),
			"DIABETESIND" => $this->diabete_indv_plan($data_obj),
			"DIABETESFMLY" => $this->diabete_floater_plan($data_obj),
		];
		return $return_arr;
	}

	public function populate_quote_request($quote_req_data){  
		$members_list = $quote_req_data->get_members_list();
		$age_list = $quote_req_data->get_age_list();
		$sum_insured = $quote_req_data->get_sum_insured();
		$member_count = count($members_list);
		$mem_dob = $this->get_dob_format($quote_req_data->get_dob_list());
		$policy_type = $quote_req_data->get_star_plans();
		// Get Sum insured Id
		$suminsuredId = $this->get_suminsured_id($sum_insured);
		// Get Adult Child scheme insured Id
		if($policy_type == 'COMPREHENSIVE' || $policy_type == 'FHONEW' || $policy_type == 'DIABETESFMLY'){
        	$scheme_ids = $this->get_adultchild_scheme_id($members_list, $age_list);
        	foreach($scheme_ids as $key => $scheme){
        		$schemeId[$key] = $scheme;
        	}
       	} 
        // Set Quote api request in json formate
        $poulated_request['APIKEY'] = Health_Constants::STAR_APIKEY;
        $poulated_request['SECRETKEY'] =  Health_Constants::STAR_SECRETKEY;
        $poulated_request['policyTypeName'] = $policy_type;
        $poulated_request['postalCode'] = $quote_req_data->get_pincode();
        $poulated_request['period'] = $quote_req_data->get_tenure();
        $poulated_request['sumInsuredId'] = $suminsuredId[''.$policy_type.''];
        $poulated_request['schemeId'] = ($policy_type == 'COMPREHENSIVE' || $policy_type == 'FHONEW' || $policy_type ==  'DIABETESFMLY') ? $schemeId[$key] : "";
        $poulated_request['planId'] = ($policy_type == 'DIABETESIND' || $policy_type == 'DIABETESFMLY') ? 1 : "";
       	for($i=0; $i <= $member_count-1; $i++){
        	$poulated_request['insureds['.$i.']'] = [
        		'dob' => $mem_dob[$i],
        		'sumInsuredId' => $suminsuredId[''.$policy_type.''] 
        	];
        }
        return json_encode($poulated_request);
	}

	public function parse_quote_response($quote_response,$populated_request,$quote_req_data) {
		if(!empty($quote_response)){
			$quote_resp_data = new QuoteRespData();
			$requested_data = json_decode($populated_request);
			$plan_name = $this->get_star_plans($requested_data->policyTypeName);
			$quote_resp_data->set_trans_code($quote_req_data->get_trans_code());
			$quote_resp_data->set_product_id($requested_data->policyTypeName);
			$quote_resp_data->set_product_name($plan_name);
			$quote_resp_data->set_sum_insured($quote_req_data->get_sum_insured());
			$quote_resp_data->set_sumInsuredId($requested_data->sumInsuredId);
			$quote_resp_data->set_schemeId($requested_data->schemeId);
			$planId = ($requested_data->policyTypeName == 'DIABETESFMLY' || $requested_data->policyTypeName == 'DIABETESIND') ? 1 : ''; 
			$quote_resp_data->set_planId($planId);
			$quote_resp_data->set_premium($quote_response->premium);
			$quote_resp_data->set_serviceTax($quote_response->serviceTax);
			$quote_resp_data->set_cgst($quote_response->serviceTax/2);
			$quote_resp_data->set_sgst($quote_response->serviceTax/2);
			$quote_resp_data->set_totalPremium($quote_response->totalPremium);
			$quote_resp_data->set_product_type($quote_req_data->get_product_type());
			$quote_resp_data->set_plan_type($quote_req_data->get_plan_type());
			$quote_resp_data->set_insurer_name('star');
			$quote_resp_data->set_insurer_code('STAR');
			return $quote_resp_data;
		}
		return null;
	}

	private function mci_plan($data){
		foreach($data->get_age_list() as $age){
			if($age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsured_id = $this->get_suminsured_id($data->get_sum_insured());
		 if(!empty($suminsured_id['MCINEW']) && (($data->get_tenure() == 1) || ($data->get_tenure() == 2)) && count($data->get_age_list()) == 1 && $mem_age == 0) {
		 	return true;
		 }
		return false;
	}

	private function comprehensive_indv_plan($data) {
		foreach($data->get_age_list() as $age){
			if($age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsured_id = $this->get_suminsured_id($data->get_sum_insured());
		if(!empty($suminsured_id['COMPREHENSIVEIND']) &&  ($data->get_tenure() == 1) && count($data->get_age_list()) == 1 && $mem_age == 0){
			return true;
		}
		return false;
	}

	private function comprehensive_floater_plan($data) {
		$rel_flag = 0;
		if(in_array("FATH", $data->get_members_list()) || in_array("MOTH", $data->get_members_list())){
            $rel_flag = 1; 
        }
		foreach($data->get_age_list() as $age){
			if($age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsuredId = $this->get_suminsured_id($data->get_sum_insured());
		$schemeId = $this->get_adultchild_scheme_id($data->get_members_list(),$data->get_age_list());
		if((!empty($suminsuredId['COMPREHENSIVE'])) && (!empty($schemeId['COMPREHENSIVE'])) && ($data->get_tenure() == 1)  && count($data->get_age_list()) > 1 && $mem_age == 0 && $data->get_plan_type() == 'FF' && $rel_flag != 1) { 
			return true; 
		}
		return false;
	}

	private function fho_plan($data) {
		$rel_flag = 0;
		if(in_array("FATH", $data->get_members_list()) || in_array("MOTH", $data->get_members_list())){
            $rel_flag = 1; 
        }
		foreach($data->get_age_list() as $age){
			if($age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsuredId = $this->get_suminsured_id($data->get_sum_insured());
		$schemeId = $this->get_adultchild_scheme_id($data->get_members_list(),$data->get_age_list());
		if(!empty($suminsuredId['FHONEW']) && !empty($schemeId['FHONEW']) && $data->get_tenure() == 1 && count($data->get_age_list()) > 1 && $mem_age == 0 && $data->get_plan_type() == 'FF' && $rel_flag != 1){
			return true;
		}
		return false;
	}

	private function red_carpet_plan($data) {
		$count = 0;
		foreach($data->get_age_list() as $age){
			if(($age >= 60) && ($age <= 75)){
				$count++;
			}
		}
		$suminsuredId = $this->get_suminsured_id($data->get_sum_insured());
		if(($count == sizeof($data->get_age_list())) && (!empty($suminsuredId['REDCARPET'])) && $data->get_tenure() == 1 && count($data->get_age_list()) == 1){
			return true;
		}
		return false;
	}

	private function diabete_indv_plan($data) {
		foreach($data->get_age_list() as $age){
			if($age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsuredId = $this->get_suminsured_id($data->get_sum_insured());
		if(!empty($suminsuredId['DIABETESIND']) && ($data->get_tenure() == 1) && count($data->get_age_list()) == 1 && $mem_age == 0 ){
			return true;
		}
		return false;
	}

	private function diabete_floater_plan($data) {
		$rel_flag = 0;
		if(in_array("FATH", $data->get_members_list()) || in_array("MOTH", $data->get_members_list())){
            $rel_flag = 1; 
        }
		foreach($data->get_age_list() as $age){
			if($age <= 17 || $age > 65){ $mem_age = 1; } else {$mem_age = 0; }
		}
		$suminsuredId = $this->get_suminsured_id($data->get_sum_insured());
		$schemeId = $this->get_adultchild_scheme_id($data->get_members_list(),$data->get_age_list());
		if(!empty($suminsuredId['DIABETESFMLY']) && !empty($schemeId['DIABETESFMLY'])  && $data->get_tenure() == 1 && ((count($data->get_age_list()) > 1) && count($data->get_age_list()) == 2 )  && $mem_age == 0 && $data->get_plan_type() == 'FF' && $rel_flag != 1){
			return true;
		}
		return false;
	}


   	private function get_suminsured_id($si){
   		$plan_sum_insured = [
   			'MCINEW' => [1 => 150000, 2 => 200000, 3 => 300000, 4 => 400000, 5 => 500000, 6 => 1000000, 7 => 1500000],
   			'COMPREHENSIVEIND' => [1 => 500000, 2 => 750000, 3 => 1000000, 4 => 1500000, 5 => 2000000, 6 => 2500000],
   			'COMPREHENSIVE' => [1 => 500000, 2 => 750000, 3 => 1000000, 4 => 1500000, 5 => 2000000, 6 => 2500000],
   			'FHONEW' => [2 => 300000, 3 => 400000, 4 => 500000, 5 => 1000000, 6 => 1500000, 7 => 2000000, 8 => 2500000],
   			'REDCARPET' => [1 => 100000, 2 => 200000,3 => 300000, 4 => 400000, 5 => 500000], 
   			'DIABETESIND' => [1 =>	300000, 2 => 400000, 3 => 500000],
   			'DIABETESFMLY' => [1	=> 300000, 2 => 400000, 3 => 500000],
   		];
   		$suminsuredId = array();
   		foreach($plan_sum_insured as $key => $sum_insured){
   			foreach($sum_insured as $id => $amount){
   				if($si == $amount){
   					$suminsuredId[$key] = $id; 
   				} 
   			}
   		}
   		return $suminsuredId;
   	}

   	private function get_adultchild_scheme_id($mem_list, $age_list){
   		$members_type = $this->calculate_member_type($mem_list, $age_list); 
   		$plan_scheme_id = [
   			'COMPREHENSIVE' => [1 => '2A+0C', 2 => '1A+1C', 3 => '1A+2C', 4 =>	'1A+3C', 5 => '2A+1C', 6 =>	'2A+2C', 7 => '2A+3C'],
   			'FHONEW' => [1 => '2A+0C', 2 => '1A+1C', 3 => '1A+2C', 4 => '1A+3C', 5 => '2A+1C', 6 => '2A+2C', 7 => '2A+3C'],
   			'DIABETESFMLY' => [1 => '2A+0C'],
   		];
   		$schemeId = array();
		foreach($plan_scheme_id as $key => $members){
			foreach($members as $id => $scheme){
				if($members_type == $scheme){
					$schemeId[$key] = $id; 
				} 
			}
		}
   		return $schemeId;
   	}

   	private function calculate_member_type($memlist, $agelist){
        $adult = $children = 0;
        for($i=0; $i<sizeof($memlist);$i++){
            if($memlist[$i] == 'WIFE' || $memlist[$i] == 'HUS' || $memlist[$i] == 'MOTH' || $memlist[$i] == 'FATH'){
                $member[] = 'adult';
                $adult++;
            }elseif($memlist[$i] == 'SELF' && $agelist[$i] >=18 ){
                $member[] = 'adult';
                $adult++;
            }elseif(($memlist[$i] == 'SONM' || $memlist[$i] == 'UDTR') && $agelist[$i] > 25){
                $member[] = 'adult';
                $adult++;
            }else{
                $member[] = 'child';
                $children++;
            }
        }
        return $adult.'A' .'+'. $children.'C';
   	}


   	private function get_star_plans($policyTypeName){
		if($policyTypeName == "MCINEW"){ return 'Mediclassic Individual';} 
        if($policyTypeName == "COMPREHENSIVEIND"){ return 'Star Comprehensive Individual';}
        if($policyTypeName == "COMPREHENSIVE"){ return 'Star Comprehensive';}
        if($policyTypeName == "FHONEW"){ return 'Family Health Optima';}
        if($policyTypeName == "DIABETESIND"){ return 'Diabetes Safe Individual';}
        if($policyTypeName == "DIABETESFMLY"){ return 'Diabetes Safe';}
        if($policyTypeName == "REDCARPET"){ return 'Senior Citizens Redcarpet'; }
	}

// Proposal Section data 
   	public function set_proposal_data($user_data){
   		$proposal_req_data = new PolicyPageData();
   		$relation_list = json_decode($user_data['relation_list']);
   		$members_list = explode('|', $user_data['members_list']);
   		foreach($relation_list as $relid){
   			if(isset($relid->star_code_diabetic)){ $star_code = $relid->star_code_diabetic; }
   			elseif(isset($relid->star_code_red)){ $star_code = $relid->star_code_red; }
   			else{ $star_code = $relid->star_code; }
   			foreach($members_list as $member){
   				if($member == $relid->rel_name){
   					$relationId[] = $star_code;
   				}
   			}
   		}
   		$proposal_req_data->set_members_list($members_list);
   		$proposal_req_data->set_hl_trans_code($user_data['hl_trans_code']);
   		$proposal_req_data->set_tenure($user_data['tenure']);
   		$proposal_req_data->set_policy_start($user_data['policy_start']);
   		$proposal_req_data->set_policy_end($user_data['policy_end']);
   		$proposal_req_data->set_product_id($user_data['product_id']);
   		$proposal_req_data->set_insurer_name($user_data['insurer_name']);
   		$proposal_req_data->set_sum_insured($user_data['sum_insured']);
   		$proposal_req_data->set_sumInsuredId(isset($user_data['sumInsuredId']) ? $user_data['sumInsuredId'] : '');
   		$proposal_req_data->set_schemeId(isset($user_data['schemeId']) ? $user_data['schemeId'] : '');
   		$proposal_req_data->set_planId(isset($user_data['planId']) ? $user_data['planId']: '');
   		foreach($user_data['dob_list'] as $dob){
			$date = DateTime::createFromFormat("d-m-Y" , $dob);
			$mem_dob[] = $date->format('Y-m-d');
   		}
   		$proposal_req_data->set_relationId($relationId);
   		$proposal_req_data->set_dob_list($mem_dob);
   		$proposal_req_data->set_age_list($user_data['age_list']);
   		$proposal_req_data->set_gender(explode('|',$user_data['gender_list']));
   		$proposal_req_data->set_firstname($user_data['firstname']);
   		$proposal_req_data->set_lastname($user_data['lastname']);
   		$proposal_req_data->set_pancard($user_data['pan_number']);
		$proposal_req_data->set_aadhaar($user_data['aadhaar_num']);
		$proposal_req_data->set_feet($user_data['height_feet']);
		$proposal_req_data->set_inches($user_data['height_inches']);
		$proposal_req_data->set_weight($user_data['weight']);
		$proposal_req_data->set_member_occupation(isset($user_data['occupation']) ? $user_data['occupation'] : '' );
		$proposal_req_data->set_email($user_data['email']);
		$proposal_req_data->set_mobile($user_data['mobile']);
		$proposal_req_data->set_houseno($user_data['houseno']);
		$proposal_req_data->set_street($user_data['street']);
		$proposal_req_data->set_locality($user_data['locality']);
		$proposal_req_data->set_cust_pincode($user_data['cust_pincode']);
		$proposal_req_data->set_state($user_data['state']);
		$proposal_req_data->set_city($user_data['city']);
		$proposal_req_data->set_cust_area($user_data['cust_area']);
		$ped_list = $this->set_ped_list($user_data);
		$proposal_req_data->set_ped_details($ped_list);
		$proposal_req_data->set_social_status($user_data['social_status']);
		$proposal_req_data->set_below_poverty(isset($user_data['below_poverty']) ? $user_data['below_poverty']: '0');
		$proposal_req_data->set_unorganized_sector(isset($user_data['unorganized_sector']) ? $user_data['unorganized_sector']: '0');
		$proposal_req_data->set_handicaped(isset($user_data['handicaped']) ? $user_data['handicaped']: '0');
		$proposal_req_data->set_informal_sector(isset($user_data['informal_sector']) ? $user_data['informal_sector']: '0');
		$proposal_req_data->set_nominee_name($user_data['nominee_name']);
		$proposal_req_data->set_nominee_age($user_data['nominee_age']);
		$proposal_req_data->set_nominee_relation($user_data['nominee_relation']);
		$proposal_req_data->set_star_hosp_cash(isset($user_data['star_add_on']) ? $user_data['star_add_on']: 0);
		// $proposal_req_data->set_personal_accident(isset($user_data['star_persaonal_accedent']) ? $user_data['star_persaonal_accedent'] : false);
		$proposal_req_data->set_agree_medical_checkup((isset($user_data['agree_med_chkup']) && ($user_data['agree_med_chkup'] == 1)) ? 1 : 0 );
		return $proposal_req_data;
   	}

   	public function populate_proposal_request($req_data){
   		$mem_dob = $this->get_dob_format($req_data->get_dob_list());
    	        $proposl_req_data["APIKEY"] = Health_Constants::STAR_APIKEY;
		$proposl_req_data["SECRETKEY"] = Health_Constants::STAR_SECRETKEY;
		$proposl_req_data["policyTypeName"] = $req_data->get_product_id();
		$proposl_req_data["startOn"] = date("M d, Y", strtotime(date($req_data->get_policy_start())));
		$proposl_req_data["endOn"] = date("M d, Y", strtotime(date($req_data->get_policy_end())));
		$proposl_req_data["sumInsuredId"] = $req_data->get_sumInsuredId();
		$proposl_req_data["schemeId"] = $req_data->get_schemeId();
		$proposl_req_data["planId"] = $req_data->get_planId();
		$proposl_req_data["policyCategory"] = "fresh";
		$proposl_req_data["proposerName"] = $req_data->get_firstname()[0].' '.$req_data->get_lastname()[0];
		$proposl_req_data["proposerEmail"] = $req_data->get_email();
		$proposl_req_data["proposerPhone"] = $req_data->get_mobile();
		$proposl_req_data["proposerAddressOne"] = $req_data->get_houseno().', '.$req_data->get_street();
		$proposl_req_data["proposerAddressTwo"] = $req_data->get_locality().' '.$req_data->get_city();
		$proposl_req_data["proposerAreaId"] = $req_data->get_cust_area();
		$proposl_req_data["proposerResidenceAddressOne"] = "";
		$proposl_req_data["proposerResidenceAddressTwo"] = "";
		$proposl_req_data["proposerResidenceAreaId"] = "";
		$proposl_req_data["proposerDob"] = date("M d, Y", strtotime(date($req_data->get_dob_list()[0])));
		$proposl_req_data["panNumber"] = (!empty($req_data->get_pancard()) ? $req_data->get_pancard() :'');
		$proposl_req_data["period"] = $req_data->get_tenure();
		$proposl_req_data["gstIdNumber"] = "";
		$proposl_req_data["aadharNumber"] = str_replace('-','',$req_data->get_aadhaar());
		$proposl_req_data["socialStatus"] = $req_data->get_social_status();
		$proposl_req_data["socialStatusBpl"] = $req_data->get_below_poverty();
		$proposl_req_data["socialStatusUnorganized"] = $req_data->get_unorganized_sector();
		$proposl_req_data["socialStatusDisabled"] = $req_data->get_handicaped();
		$proposl_req_data["socialStatusInformal"] = $req_data->get_informal_sector();
		$proposl_req_data["previousMedicalInsurance"] = "";
		$proposl_req_data["annualIncome"] = "";
		$proposl_req_data["criticalIllness"] = ($req_data->get_ped_details()['criticalIllness'] == 1) ? "true" : "false";
		// Loop insured members based on product ex: MCI, REDCARPET, Diabet
		$member_count = count($req_data->get_dob_list());
		if($req_data->get_product_id() == 'MCINEW' || $req_data->get_product_id() == 'FHONEW' || $req_data->get_product_id() == 'REDCARPET'){
			for($i = 0; $i <= $member_count-1; $i++) {
				$gender = ($req_data->get_gender()[0] == 'M') ? 'Male' : 'Female' ; 
				$height = $this->convert_feet_to_cm($req_data->get_feet()[$i],$req_data->get_inches()[$i]);
				$proposl_req_data['insureds['.$i.']'] = [
	    			"name" => $req_data->get_firstname()[$i].' '.$req_data->get_lastname()[$i],
					"dob" => $mem_dob[$i],
					"sex" => $gender,
					"illness" => $req_data->get_ped_details()['illness'][$i],
					"sumInsuredId" => $req_data->get_sumInsuredId(),
					"relationshipId" => $req_data->get_relationId()[$i],
					"occupationId" => $req_data->get_member_occupation()[$i],
					"hospitalCash" => $req_data->get_star_hosp_cash(),
					"height" => round(''.$height.''),
					"weight" => $req_data->get_weight()[$i],
	    		];
	    	}
	    }
	    if($req_data->get_product_id() == 'COMPREHENSIVEIND' || $req_data->get_product_id() == 'COMPREHENSIVE'){
			for($i=0; $i <= $member_count-1; $i++) {
				$gender = ($req_data->get_gender()[0] == 'M') ? 'Male' : 'Female' ; 
				$height = $this->convert_feet_to_cm($req_data->get_feet()[$i],$req_data->get_inches()[$i]);
				$pa = ($i == 0) ? 'true' : 'false' ;
	    		$proposl_req_data['insureds['.$i.']'] = [
	    			"name" => $req_data->get_firstname()[$i].' '.$req_data->get_lastname()[$i],
					"dob" => $mem_dob[$i],
					"sex" => $gender,
					"illness" => $req_data->get_ped_details()['illness'][$i],
					"sumInsuredId" => $req_data->get_sumInsuredId(),
					"relationshipId" => $req_data->get_relationId()[$i],
					"occupationId" => $req_data->get_member_occupation()[$i],
					"isPersonalAccidentApplicable" => $pa,
					"engageManualLabour" => $req_data->get_ped_details()['engageManualLabour'][$i],
					"engageWinterSports" => $req_data->get_ped_details()['engageWinterSports'][$i],
					"height" => round(''.$height.''),
					"weight" => $req_data->get_weight()[$i],
	    		];
	    	}
	    }
	    if($req_data->get_product_id() == 'DIABETESIND' || $req_data->get_product_id() == 'DIABETESFMLY'){
			for($i=0; $i <= $member_count-1; $i++) {
				$gender = ($req_data->get_gender()[$i] == 'M') ? 'Male' : 'Female' ; 
				$height = $this->convert_feet_to_cm($req_data->get_feet()[$i],$req_data->get_inches()[$i]);
				$pa = ($i == 0) ? 'true' : 'false' ;
	    		$proposl_req_data['insureds['.$i.']'] = [
	    			"name" => $req_data->get_firstname()[$i].' '.$req_data->get_lastname()[$i],
					"dob" => $mem_dob[$i],
					"sex" => $gender,
					"illness" => $req_data->get_ped_details()['illness'][$i],
					"sumInsuredId" => $req_data->get_sumInsuredId(),
					"relationshipId" => $req_data->get_relationId()[$i],
					"criticalCancer" => $proposl_req_data["criticalIllness"],
					"criticalRenal" => $proposl_req_data["criticalIllness"],
					"criticalHeart" => $proposl_req_data["criticalIllness"],
					"criticalPsychiatric" => $proposl_req_data["criticalIllness"],
					"criticalDrugs" => $req_data->get_ped_details()['criticalDrugs'],
					"diabetesMellitus" => $req_data->get_ped_details()['diabetesMellitus'][$i],
					"insulinProblem" => $req_data->get_ped_details()['insulinProblem'][$i],
					"insulinFrom" => $req_data->get_ped_details()['insulinFrom'][$i],
					"bloodSugar" => $req_data->get_ped_details()['bloodSugar'][$i],
					"serumCreatinine" => $req_data->get_ped_details()['serumCreatinine'][$i],
					"hba1c" => $req_data->get_ped_details()['hba1c'][$i],
					"eyeProblem" => $req_data->get_ped_details()['eyeProblem'],
					"kidneyProblem" => $req_data->get_ped_details()['eyeProblem'],
					"nonHealing" => $req_data->get_ped_details()['eyeProblem'],
					"height" => round(''.$height.''),
					"weight" => $req_data->get_weight()[$i],
					"isPersonalAccidentApplicable" => $pa
	    		];
	    	}
	    }
		$proposl_req_data["nomineeName"] = $req_data->get_nominee_name();
		$proposl_req_data["nomineeAge"] = $req_data->get_nominee_age();
		$proposl_req_data["nomineeRelationship"] = $req_data->get_nominee_relation();
		$proposl_req_data["nomineePercentClaim"] = "100";
		$proposl_req_data["appointeeName"] = "";
		$proposl_req_data["appointeeAge"] = "";
		$proposl_req_data["appointeeRelationship"] = "";
		$proposl_req_data["nomineeNameTwo"] = "";
		$proposl_req_data["nomineeAgeTwo"] = "";
		$proposl_req_data["nomineeRelationshipTwo"] = "";
		$proposl_req_data["nomineePercentClaimTwo"] = "";
		$proposl_req_data["appointeeNameTwo"] = "";
		$proposl_req_data["appointeeAgeTwo"] = "";
		$proposl_req_data["appointeeRelationshipTwo"] = "";
    	return json_encode($proposl_req_data);
   	}

   	public function parse_proposal_response($proposal_response,$proposal_req_data){
   		$proposal_resp_data = new PolicyPageData();
   		$proposal_resp_data->set_hl_trans_code($proposal_req_data->get_hl_trans_code());
   		$proposal_resp_data->set_product_id($proposal_req_data->get_product_id());
   		$proposal_resp_data->set_insurer_name($proposal_req_data->get_insurer_name());
   		$proposal_resp_data->set_referenceId($proposal_response->referenceId);
		$proposal_resp_data->set_final_premium($proposal_response->premium);
		$proposal_resp_data->set_final_serviceTax($proposal_response->serviceTax);
		$proposal_resp_data->set_final_totalPremium($proposal_response->totalPremium);
		return $proposal_resp_data;
   	}

   	public function get_dob_format($dob_list){
   		foreach($dob_list as $mem_dob){
   			$dob[] = date("M d, Y", strtotime(date($mem_dob)));
   		}
   		return $dob;
   	}

   	public function convert_feet_to_cm($feet, $inches = 0) {
    	$inches = ($feet * 12) + $inches; // converts feet to inches
    	$height = ($inches * 2.54);  // converts inches to cm
    	return $height;
  	}

  	public function bmi_calculation($height, $weight){
    	$bmi = ($weight/$height/$height) * 10000;
      	return number_format((float)$bmi, 1, '.', '');
  	}

  	public function set_ped_list($user_data){
  		foreach($user_data['illness'] as $ill){
  			$illness[] = (!empty($ill)) ? $ill : 'false';
  		}
  		$pedlist['illness']	 = $illness;
  		$pedlist['criticalIllness'] = ($user_data['criticalIllness'] == 1) ? 'true': 'false' ;

  		if($user_data['product_id'] == "COMPREHENSIVEIND" || $user_data['product_id'] == "COMPREHENSIVE") {
  			foreach($user_data['engageManualLabour'] as $labour){
  				$engageManualLabour[] = (!empty($labour)) ? $labour : 'false';
  			}
  			$pedlist['engageManualLabour'] = $engageManualLabour;
  			foreach($user_data['engageWinterSports'] as $sport){
  				$engageWinterSports[] = (!empty($sport)) ? $sport : 'false';
  			}
  			$pedlist['engageWinterSports'] = $engageWinterSports;
		}
		if($user_data['product_id'] == "DIABETESIND" || $user_data['product_id'] == "DIABETESFMLY") {
			$pedlist['eyeProblem'] = ($user_data['eyeProblem'] == 1) ? 'true' : 'false'; 
			$pedlist['criticalDrugs'] = ($user_data['criticalDrugs'] == 1) ? 'true' : 'false'; 
			foreach($user_data['insulinFrom'] as $sincefrom){
				if(!empty($sincefrom)){
					$insulin['From'][] = $sincefrom;
					$insulin['Problem'][] = 'true';
				} else{
					$insulin['From'][] = '0';
					$insulin['Problem'][] = 'false';
				}
			}
			$pedlist['insulinProblem'] = $insulin['Problem'];
			$pedlist['insulinFrom'] = $insulin['From'];
			foreach($user_data['diabetesMellitus'] as $diabet){
				$diabetesMellitus[] = (!empty($diabet)) ? $diabet : '0';
			}
			$pedlist['diabetesMellitus'] = $diabetesMellitus;
			foreach($user_data['bloodSugar'] as $blood_sugar){
				$bloodSugar[] = (!empty($blood_sugar)) ? $blood_sugar : '0';
			}
			$pedlist['bloodSugar'] = $bloodSugar;
			foreach($user_data['serumCreatinine'] as $serum){
				$serumCreatinine[] = (!empty($serum)) ? $serum : '0';
			}
			$pedlist['serumCreatinine'] = $serumCreatinine;
			foreach($user_data['hba1c'] as $hba){
				$hba1c[] = (!empty($hba)) ? $hba : '0';
			}
			$pedlist['hba1c'] = $hba1c;
		}
		return $pedlist;
  	}

  	public function getStarStateCity($input){
        $request = array(); 
        $client  = new Client();
        $url     = Health_Constants::STAR_STATECITY_URL.Health_Constants::STAR_APIKEY.'&SECRETKEY='.Health_Constants::STAR_SECRETKEY.'&pincode='.$input['pincode'];
        try{
            $res = $client->request('GET',$url,['verify'=> false ]);
        }catch(\Exception $e){
            Log::info('Health_Star_Proposal_StateCity_Request '. print_r($e->getMessage(), true)); 
            $arr['error'] = 1; 
            return json_encode($arr);     
        }
        $result = $res->getBody()->getContents();
        return $result;
    }

    public function getStarAreaCity($input){
        $request = array(); 
        $client  = new Client();
        $url     = Health_Constants::STAR_AREACITY_URL.Health_Constants::STAR_APIKEY.'&SECRETKEY='.Health_Constants::STAR_SECRETKEY.'&pincode='.$input['pincode'].'&city_id='.$input['city'];
        try{
            $res = $client->request('GET',$url,['verify'=> false]);
        }catch(\Exception $e){ 
            Log::info('Health_Star_Proposal_Area_Request'.print_r($e->getMessage(),true)); $arr['error'] = 1; 
            return json_encode($arr);     
        }
        $result = $res->getBody()->getContents();
        return $result;
    }

	public function set_proposal_details($usr_data){
		if(!empty($usr_data['firstname'])){
			$mem_doblist = explode('|', $usr_data['dob_list']);
			foreach($mem_doblist as $doblist){
				$dob_list[] = date('d-m-Y', strtotime($doblist));
			}
			if(!empty($usr_data['cust_pincode'])){
				$city = ['pincode' => $usr_data['cust_pincode']];
				$citylist = $this->getStarStateCity($city);
				$area = ['pincode' => $usr_data['cust_pincode'],'city' => $usr_data['city']];
				$arealist = $this->getStarAreaCity($area);
				$star_city = json_decode($citylist)->city ; 
				$star_area = json_decode($arealist)->area ; 
			}else{
				$star_city =  ''; 
				$star_area = ''; 
			}
			$data = [ 
				'dob_list' => $dob_list,
				'firstname' => explode('|', $usr_data['firstname']),
				'lastname' => explode('|', $usr_data['lastname']),
				'height_feet' => explode('|', $usr_data['height_feet']),
				'height_inches' => explode('|', $usr_data['height_inches']),
				'weight' => explode('|', $usr_data['weight']),
				'occupation' => explode('|', $usr_data['occupation']),
				'gender' => explode('|', $usr_data['gender']),
				'city' => $star_city,
				'area' => $star_area,
				'agree_med_chkup' => 0,
				'usr_data' => $usr_data
			];
			return $data;
		}
		return null;
	}

	public function check_star_policy_status($proposal_data){
		$proposal_req_data = new PolicyPageData();
		$critical_illness = $proposal_data->get_ped_details()['criticalIllness'];
		$critical_eye_disease = (isset($proposal_data->get_ped_details()['eyeProblem'])) ? $proposal_data->get_ped_details()['eyeProblem']: '';
		$member_count = count($proposal_data->get_dob_list());	
		$members_list = $proposal_data->get_members_list();
		$age_list = explode('|', $proposal_data->get_age_list());
		for($i = 0; $i <= $member_count-1; $i++) {
			if(($members_list[$i] == 'SON' || $members_list[$i] == 'DAUGHTER') && $age_list[$i] < 21) {   }else{
					$height = $this->convert_feet_to_cm($proposal_data->get_feet()[$i],$proposal_data->get_inches()[$i]);
					$weight = $proposal_data->get_weight()[$i];
					$bmi = $this->bmi_calculation($height, $weight);
					if($bmi < Health_Constants::STAR_BMI_LOWER_LIMIT || $bmi >= Health_Constants::STAR_BMI_UPPER_LIMIT){
            			$proposal_req_data->set_bmi_status(Health_Constants::STAR_BMI_MSG);
          			}
         		}
		} 
		if($critical_illness === 'true' || $critical_eye_disease == 'true'){
			$proposal_req_data->set_ped_status(Health_Constants::STAR_PED_MSG);
		}
		return $proposal_req_data;
	}

	public function check_ppc_case($proposal_data){
		$insurer = $proposal_data->get_insurer_name();
		$sum_insured = $proposal_data->get_sum_insured();
		$product_id = $proposal_data->get_product_id();
		$age_list = explode('|', $proposal_data->get_age_list());
		foreach($age_list as $mem_age){
			if($proposal_data->get_ped_details()['illness'][0] != 'false'){
				return true;
			}
			if($product_id =='FHONEW' && $sum_insured == 300000 && $mem_age == 50){
				 return true;
			}
			if(($product_id == 'MCINEW'  || $product_id == 'COMPREHENSIVEIND' || $product_id == 'COMPREHENSIVE') && $mem_age >= 50){
				return true;
			}
			return false;
		}
		return false;
	}

	public function cover_list($productId){
		if($productId == 'MCINEW'){
            $star_covers = [
            	["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
            	["coverId"=>"HOC","coverType"=>"A","seperateSi"=>"N","coverName"=>"Hospital Cash","coverLimits"=>[]],
            	["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
            	["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverType"=>"S","seperateSi"=>"N","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]]
            ];
            return json_encode($star_covers);
        }
        if($productId == 'FHONEW'){
            $star_covers = [
            	["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
            	["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
            	["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
            	["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
            	["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
            	["coverId"=>"SOP","coverType"=>"S","seperateSi"=>"N","coverName"=>"Second opinion","coverLimits"=>[]],
                ["coverId"=>"AYUR","coverType"=>"S","seperateSi"=>"N","coverName"=>"Ayurveda Treatment Cover","coverLimits"=>[]]
            ];
            return json_encode($star_covers);
        }
        if($productId == 'COMPREHENSIVE' || $productId == 'COMPREHENSIVEIND'){
            $star_covers = [
            	["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
            	["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
            	["coverId"=>"HOC","coverType"=>"A","seperateSi"=>"N","coverName"=>"Hospital Cash","coverLimits"=>[]],
            	["coverId"=>"HC","coverType"=>"S","seperateSi"=>"N","coverName"=>"Health Check","coverLimits"=>[]],
            	["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
            	["coverId"=>"SOP","coverType"=>"S","seperateSi"=>"N","coverName"=>"Second opinion","coverLimits"=>[]],
            	["coverId"=>"PA","coverType"=>"S","seperateSi"=>"N","coverName"=>"Personal Accident","coverLimits"=>[]],
            	["coverId"=>"MA","coverType"=>"A","seperateSi"=>"N","coverName"=>"Maternity ","coverLimits"=>[]]
            ];
            return json_encode($star_covers);
        }
        if($productId == 'REDCARPET'){
            $star_covers = [
            	["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]]
            ];
            return json_encode($star_covers);
        }
		if($productId == 'DIABETESIND' || $productId == 'DIABETESFMLY'){ 
            $star_covers = [
            	["coverId"=>"Single Private Room","coverType"=>"S","seperateSi"=>"N","coverName"=>"Private room","coverLimits"=>[]],
            	["coverId" => "AMBUL","coverType" => "S","seperateSi"=>"N","coverName"=>"Ambulance","coverLimits"=>[]],
            	["coverId" => "RESSI","coverType" => "S","seperateSi"=>"N","coverName"=>"Restore Sum Insured","coverLimits"=>[]],
            	["coverId"=>"PA","coverType"=>"S","seperateSi"=>"N","coverName"=>"Personal Accident","coverLimits"=>[]],
            	["coverId" => "DON","coverType" => "S","seperateSi"=>"N","coverName"=>"Organ Donor Expenses","coverLimits"=>[]],
            ];
             return json_encode($star_covers);
		}
	}

	public function check_star_policy_type($trans_code){
        $usertdata = new HealthUserData();
        $data = $usertdata->get_by_usrdata($trans_code);
        $product_id = $data['productId'];
        $insurerId      = $data['insurer_name'];
        $product_type   = $data['product_type'];
        $suminsured    = $data['sum_insured'];
        $age_list           = explode('|',$data['age_list']);
        $ped_case = json_decode($data['ped_list']);
        foreach($age_list as $mem_age){
        	if(!empty($ped_case->illness)){
        		$age['illness'] = 'true';
        		$age['value'] = 'true'; 
        	}
        	if($product_id =='FHONEW' && $suminsured == 300000 && $mem_age == 50){
        		$age['memage']= $mem_age;
                $age['value'] = 'true'; 
        	}
        	if(($product_id == 'MCINEW'  || $product_id == 'COMPREHENSIVEIND' || $product_id == 'COMPREHENSIVE') && $mem_age >= 50){
        		$age['memage']= $mem_age;
                $age['value'] = 'true';
        	}
        	return $age;
        }
        return false;
    }

    public function set_dob_list($quote_req){
        $age_list = $quote_req->get_age_list();
        $dob_list = array();
        foreach($age_list as $index => $age){
            $dob_list[] = $this->dob_generator($age, $quote_req->get_product_id());
        }
        return $dob_list;
    }

    private function dob_generator($age, $pro_id){
        if($age == '10m' && $pro_id == 'FHONEW'){
        		$current_date = new DateTime();
                $effectiveDate = strtotime("-10 months", strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
                $max_date = $current_date->format('d-m-Y');
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['max_date']      = date("d-m-Y", strtotime($max_date ."-17 days"));
                $data['min_date']      = $data['selected_date'];
                } 
             elseif($age == '10m' && ($pro_id == 'COMPREHENSIVE' || $pro_id == 'COMPREHENSIVEIND')){
             	$current_date = new DateTime();
             	$effectiveDate = strtotime("-10 months", strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['max_date']      = $current_date->format('d-m-Y');
                $data['min_date']      = $data['selected_date'];
             }

           elseif($age == '3m' && $pro_id == 'FHONEW'){ 
               	$current_date = new DateTime();
                $effectiveDate = strtotime("-3 months", strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
                $max_date = $current_date->format('d-m-Y');
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['max_date']      = date("d-m-Y", strtotime($max_date . "-17 days"));
                $data['min_date']      = $data['selected_date'];
           }
           elseif($age == '3m' && ($pro_id == 'COMPREHENSIVE' || $pro_id == 'COMPREHENSIVEIND')){ 
                $current_date = new DateTime();
                $effectiveDate = strtotime("-3 months", strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['max_date']      = $current_date->format('d-m-Y');
                $data['min_date']      = $data['selected_date'];
           }
           else{
                $birthdate = date("Y-m-d", strtotime($age. 'years ago'));
                $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
                $data['max_date']      = date('31-12-Y', strtotime($data['selected_date']));
                $data['min_date']      = date('01-01-Y', strtotime($data['selected_date']));
           }
        return $data;
    }
}
