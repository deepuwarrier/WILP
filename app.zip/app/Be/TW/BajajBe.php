<?php
namespace App\Be\TW;

use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use App\Models\TW\TwUsrData;
use App\Helpers\TW\Bajaj\WeoMotPlanDetailsUser;
use App\Helpers\TW\InsurerData;

class BajajBe {

	public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = true;
		if($quote_req_data->get_pre_policy_status() != "NEX") { $ret_status = false; }
		return $ret_status;
	}	
	
    public function post_quote_check($quote_resp_data){
		$ret_status = true;
		
		return $ret_status;
	}
	
   public function populate_quote_request (QuoteReqData $quote_req_data) {
// 	dd($quote_req_data);
	$column_name = "bajaj_code";
    $master_data = new InsurerData();
	$plan_detail = new WeoMotPlanDetailsUser();
    	
    	$plan_detail->setVehicleTypeCode(21);
    	$plan_detail->setElecAccTotal(0);
    	$plan_detail->setAddLoadingOn(0);
    	$plan_detail->setNonElecAccTotal(0);
    	$plan_detail->setPolType(3);
    	$plan_detail->setRegistrationNo($quote_req_data->get_rto_code() ."AB1234");
    	$plan_detail->setPartnerType("P");		// P for Person,  I - for Institution(company)
    	$plan_detail->setPrvNcb($quote_req_data->get_current_ncb());
    	$plan_detail->setNcb($quote_req_data->get_eligible_ncb());
    	$plan_detail->setPrvClaimStatus($quote_req_data->get_claim_status() == "N" ? 0 : 1);
    	$plan_detail->setRegistrationDate($quote_req_data->get_registration_date());
	$plan_detail->setEngineNo("QUOTE123456");
	$plan_detail->setChassisNo("QUOTE12345678");
	$plan_detail->setContractId(0);
	$plan_detail->setYearManf($quote_req_data->get_yom());
	$plan_detail->setSpDiscRate(0);
	$plan_detail->setCubicCapacity($quote_req_data->get_tw_cc());
	$plan_detail->setRegistrationLocation( $master_data->insr_rto("rto", $quote_req_data->get_rto_code()));
// 	$plan_detail->setRegiLocOther("Bangalore");
	$plan_detail->setZone($master_data->insr_rto("zone", $quote_req_data->get_rto_code()));
	$plan_detail->setAddLoading(0);
	$plan_detail->setPrvPolicyRef("QUOTE123456");
	
	$plan_detail->setVehicleMakeCode($master_data->insr_make($column_name, $quote_req_data->get_make_code()));
	$plan_detail->setVehicleMake($master_data->insr_make("make_name", $quote_req_data->get_make_code()));
	$plan_detail->setVehicleModelCode($master_data->model_data($column_name, $quote_req_data->get_model_code()));
	$plan_detail->setVehicleModel($master_data->model_data("model_name", $quote_req_data->get_model_code() ));
	$plan_detail->setVehicleSubtypeCode($master_data->insr_variant("bajaj_subtype", $quote_req_data->get_variant_code()));
	$plan_detail->setVehicleSubtype($master_data->insr_variant("variant_name", $quote_req_data->get_variant_code() ));
	$plan_detail->setFuel("P");
	
	$plan_detail->setMiscVehType(0);
	
	$plan_detail->setPrvExpiryDate($quote_req_data->get_prepolicy_end_date());
	$plan_detail->setTermStartDate($quote_req_data->get_policy_start_date());
	$plan_detail->setTermEndDate($quote_req_data->get_policy_end_date());
    	$plan_detail->setCarryingCapacity(2);
//     	$plan_detail->setHypo("State Bank of India");
    	$plan_detail->setBranchCode(1901);
    	$plan_detail->setPrvInsCompany(1);
    	$plan_detail->setColor("RED");
//     	$plan_detail->setTpFinType(1);
    	$plan_detail->setProduct4digitCode(1843);
    	$plan_detail->setDeptCode(18);
    	
    	$accessory = null;
    	$addonCover = null;
    	$motExtraCover = null;   
    	$pQuestList_inout = null;
    	$pDetariffObj_inout = null;
    	$premiumDetailsOut_out = null;
    	$premiumSummeryList_out = null;
    	$pError_out = null;
    	$pAdditionalField_inout = null;
    	
    	$bajaj_quote_req_arr = array(
    		"TRANS_CODE" => $quote_req_data->get_tw_trans_code(),	
    	  	"API_USER" => 	"policy@instainsure.com",
    	    	"API_PASS" => "newpas12",
    		"VARIANT_CODE" =>$master_data->insr_variant($column_name, $quote_req_data->get_variant_code()),
    		"LOCATION_NAME" => $master_data->insr_rto("rto", $quote_req_data->get_rto_code()),
		"PLAN_DETAILS"=> $plan_detail,
		 "ACCESSORY" => $accessory,
		 "ADDONCOVER" =>$addonCover,
		 "MOTEXTRACOVER" => $motExtraCover,
		 "PQUESTLIST_INOUT" => $pQuestList_inout,
		 "PDETARIFFOBJ_INOUT" => $pDetariffObj_inout,
		 "PREMIUMDETAILSOUT_OUT" => $premiumDetailsOut_out,
		 "PREMIUMSUMMERYLIST_OUT" => $premiumSummeryList_out,
		 "PERROR_OUT"=> $pError_out, "EXT1"=>null, "EXT2"=>null, "EXT3"=>null, 
    		 "EXT4" =>	null, "PADDITIONALFIELD_INOUT" => $pAdditionalField_inout
    	);

    	return $bajaj_quote_req_arr;
	}
	
	public function parse_quote_response( $quote_req_data, $raw_quote_resp) {
		
		$resp_data = new QuoteRespData();
		$tw_trans_code= $quote_req_data->get_tw_trans_code();
		$resp_data->_insurer_code("IITW001");
		$resp_data->_insurer_logo("bajaj_logo.png");
		$resp_data->_insurer_name("Bajaj Allianz GI");
		$resp_data->_proposal_url("two-wheeler-insurance/bajaj/" . $tw_trans_code);
		
		foreach ($raw_quote_resp['premiumSummeryList_out']->WeoMotPremiumSummaryUser as $covers ) {
			switch ($covers->paramRef) {
				case "OD":
					$resp_data->_od_value(round($covers->od, 2)); break;
				case "ACT":
					$resp_data->_tp_value( round($covers->act, 2));	break;
				case "PA_DFT":
					$resp_data->_pa_value(round($covers->act, 2)); break;
				case "NCB":
					$resp_data->_ncb_value(abs(round($covers->od, 2))); break;
				case "COMMDISC":
					$resp_data->_od_disc(abs(round($covers->od, 2))); 	break;
			}
		} // end of for loop.
	
		$resp_data->_idv($raw_quote_resp["premiumDetailsOut_out"]->totalIev);
		$resp_data->_service_tax($raw_quote_resp["premiumDetailsOut_out"]->serviceTax);
		
		$resp_data->_final_premium($raw_quote_resp["premiumDetailsOut_out"]->finalPremium);
		
		return $resp_data;
	}


} // end of class
