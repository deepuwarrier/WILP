<?php
namespace App\Be\TW;

use App\Helpers\TW\HDFC\Hdfc_Quote_Request;
use App\Helpers\TW\InsurerData;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use App\Constants\Tw_Constants;
use App\Helpers\TW\HDFC\Hdfc_Policy_Request;
use App\Libraries\TwLib;
use Illuminate\Support\Facades\Log;


class HdfcBe {

	public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = false;
		// if($quote_req_data->get_pre_policy_status() != "NEX") { 
		// 	$ret_status = true; 
		// } 
		return $ret_status; 
	}	
	
	public function post_quote_check($quote_resp_data){
		$ret_status = true;
		
		return $ret_status;
	}
	
	public function populate_quote_request (QuoteReqData $quote_req_data) {
	
    	$master_data = new InsurerData();
    	$hdfc_quote_req = new Hdfc_Quote_Request();

    	$req_params = array(
    		"policystartdate" => $this->format_date( $quote_req_data->get_policy_start_date()),
    		"policyenddate" => $this->format_date( $quote_req_data->get_policy_end_date()),
    		"prepolstartdate" => ($quote_req_data->get_prepolicy_start_date() != '')?$this->format_date( $quote_req_data->get_prepolicy_start_date()) : $quote_req_data->get_prepolicy_start_date(),
    		"prepolicyenddate" => ($quote_req_data->get_prepolicy_end_date() != '')?$this->format_date( $quote_req_data->get_prepolicy_end_date()) : $quote_req_data->get_prepolicy_end_date(),
    		"purchaseregndate" => $this->format_date( $quote_req_data->get_registration_date()) ,
    		"IsPreviousClaim" => ($quote_req_data->get_claim_status() != 'Y') ? 1 : 0,      // 0 = claims yes | 1 = claims no.
    		"previousdiscount" => $quote_req_data->get_current_ncb(),
    		"rtolocationcode" => $master_data->insr_rto(Tw_Constants::HDFC_COLUMN_NAME, $quote_req_data->get_rto_code()),
    		"vehiclemodelcode" => $master_data->insr_variant("hdfc_code", $quote_req_data->get_variant_code() ),
    		"manufacturer_code" => $master_data->insr_make("hdfc_code", $quote_req_data->get_make_code()),
    		"exshowroomprice" => $quote_req_data->get_tw_price(),
    		"Sum_Insured" => $quote_req_data->get_desired_idv(),
    		"manufacturingyear" => $quote_req_data->get_yom(),
    		"num_is_zero_dept" => $quote_req_data->get_add_on_zrdp() ? 1 : 0 ,
    		"num_is_emr_asst_cvr" => $quote_req_data->get_add_on_rsac()? 1 : 0
    	);
    	$quote_init_req = $hdfc_quote_req->prepare_quote_init($req_params);
    	return $quote_init_req;
	}
	
	public function populate_idv_request(QuoteReqData $quote_req_data){
		$master_data = new InsurerData();
		$hdfc_quote_req = new Hdfc_Quote_Request();
		$req_params = array(
				"policy_start_date" => $this->format_date( $quote_req_data->get_policy_start_date()),
				"rtolocationcode" => $master_data->insr_rto(Tw_Constants::HDFC_COLUMN_NAME, $quote_req_data->get_rto_code()),
				"vehiclemodelcode" => $master_data->insr_variant("hdfc_code", $quote_req_data->get_variant_code() ),
				"manufacturer_code" => $master_data->insr_make("hdfc_code", $quote_req_data->get_make_code()),
				"purchaseregndate" => $this->format_date( $quote_req_data->get_registration_date()) ,
				"manufacturingyear" => $quote_req_data->get_yom(),
		);
		return  $hdfc_quote_req->idv_request_str($req_params);
	}
	
	public function parse_quote_response( QuoteReqData $quote_req_data, $raw_quote_resp) {
		
		$tw_quote_be = new TwQuoteBe();
		$tw_trans_code = $quote_req_data->get_tw_trans_code();
		try{
			$xml_obj = simplexml_load_string($raw_quote_resp);
		}catch (\Exception $ee) {
			Log::error("Error in Tw HDFC Quote Request Data - ". $tw_trans_code. " - " . $ee->getMessage());
			return null;
		}
		$resp_data = new QuoteRespData();
		
		$tw_trans_code = $quote_req_data->get_tw_trans_code();
		$resp_data->_insurer_code("IITW003");
		$resp_data->_insurer_logo("hdfcgi_logo.png");
		$resp_data->_insurer_name("HDFC Ergo GI");
		$resp_data->_proposal_url("two-wheeler-insurance/hdfc");
		$resp_data->set_tw_trans_code($tw_trans_code);
		
		$rec_idv_value =  (float)  $xml_obj->PREMIUMOUTPUT->NUM_VEHICLE_IDV;
		
		$calc_od_value =  $tw_quote_be->calc_base_od(
				$quote_req_data->get_tw_age() , 
				$quote_req_data->get_tw_cc() , 
				$quote_req_data->get_rto_zone(), 
				$rec_idv_value
		);
		
		$od_disc_value = $calc_od_value - $xml_obj->PREMIUMOUTPUT->NUM_BASIC_OD_PREMIUM;
		
		$resp_data->_od_value( round ($calc_od_value ));
		$resp_data->_od_disc( round ($od_disc_value) );
		$resp_data->_ncb_value( $xml_obj->PREMIUMOUTPUT->NUM_NCB_PREM);
		$resp_data->_tp_value( $xml_obj->PREMIUMOUTPUT->NUM_TP_RATE );
		$resp_data->_pa_value( $xml_obj->PREMIUMOUTPUT->NUM_PA_COVER_OWNER_DRVR );
		$resp_data->_idv( $rec_idv_value);
		$resp_data->_gross_premium( $xml_obj->PREMIUMOUTPUT->NUM_NET_PREMIUM);
		$resp_data->_service_tax( $xml_obj->PREMIUMOUTPUT->NUM_SERVICE_TAX);
		$resp_data->_final_premium( $xml_obj->PREMIUMOUTPUT->NUM_TOTAL_PREMIUM );
		
		$resp_data->_addon_zrdp( $xml_obj->PREMIUMOUTPUT->NUM_ZERO_DEPT_PREM );
		
		
		return $resp_data;
	}

	public function populate_proposal_request ( $policy_usr_data ) {
		
		$insr_column_code = "hdfc_code";
		$insr_column_name = "hdfc_name";
		$policy_be = new TwPolicyBe();
		$insr_data = new InsurerData();
		$tw_lib = new TwLib();
		
		$opted_covers = $policy_be->parse_covers( $policy_usr_data->addon_covers != null ? $policy_usr_data->addon_covers : "" );
		$tot_prem = $policy_usr_data->total_premium;
		$base_prem = round( $tot_prem * 100 / 118);
		$gst_val = round ($base_prem * 0.18);
		
		$req_params = array(
		"Registration_Citycode" => $insr_data->insr_rto( $insr_column_code, $policy_usr_data->rto_code ),
		"Registration_City" =>  $insr_data->insr_rto( $insr_column_name, $policy_usr_data->rto_code ),
		"Vehicle_Modelcode" => $insr_data->insr_variant($insr_column_code, $policy_usr_data->variant_code ),
		"Manufacturer_Code" => $insr_data->insr_make($insr_column_code, $policy_usr_data->make_code ) ,
		"showroom_Price" => $policy_usr_data->variant_price ,
		
		"PrePolicy_Startdate" => ($policy_usr_data->policy_start_date != '')?$this->format_date($policy_usr_data->policy_start_date):$policy_usr_data->policy_start_date,
		"PrePolicy_Enddate" => ($policy_usr_data->policy_start_date != '')?$this->format_date($policy_usr_data->policy_exp_date):$policy_usr_data->policy_start_date,
		"Policy_Startdate" => $this->format_date($policy_usr_data->term_start_date),
		"Policy_Enddate" => $this->format_date($policy_usr_data->term_end_date),
		"Purchase_Regndate" => $this->format_date($policy_usr_data->tw_reg_date),
		"Sum_Insured" => $policy_usr_data->opt_idv ,
		"IsPrevious_Claim" => $policy_usr_data->pre_claim_status == "N" ? 1 : 0 ,   // 1 is no claims, 0 is claims
		"NCB_ExpiringPolicy" => $policy_usr_data->curr_ncb,
		"NCB_RenewalPolicy" => $policy_usr_data->eli_ncb,
		
		"IsZeroDept_Cover" => in_array("ZRDP", $opted_covers) ? 1 : 0, 
		"IsZeroDept_RollOver" => in_array("ZRDP", $opted_covers) ? 1 : 0, 
				
		"Vehicle_Ownedby" => $policy_usr_data->owner_type,
		"Gender" => $policy_usr_data->proposer_gender == "M" ? "Male" : "Female",
		"First_Name" => $tw_lib->get_fname( $policy_usr_data->proposer_name ),
		"Last_Name" => $tw_lib->get_lname( $policy_usr_data->proposer_name ),
		"Date_of_Birth" => $this->format_date($policy_usr_data->proposer_dob),
		"Email_Id" => $policy_usr_data->proposer_email,
		"Contactno_Mobile" => $policy_usr_data->proposer_mobile ,
		
		"Car_Address1" => $policy_usr_data->proposer_addr1 ,
		"Car_Address2" => $policy_usr_data->proposer_addr2 ,
		"Car_Address3" => $policy_usr_data->proposer_addr3 ,
		"Car_Citycode" =>  $insr_data->insr_city( $insr_column_code, $policy_usr_data->proposer_city_code),
		"Car_City" => $insr_data->insr_city($insr_column_name, $policy_usr_data->proposer_city_code),
		"Car_Statecode" => $insr_data->insr_state($insr_column_code, $policy_usr_data->proposer_state_code ),
		"Car_State" => $insr_data->insr_state( $insr_column_name, $policy_usr_data->proposer_state_code ),
		"Car_Pin" => $policy_usr_data->proposer_pincode,
		"LocationCode" => $insr_data->insr_city( $insr_column_code, $policy_usr_data->proposer_city_code),
		
		"Corres_Address1" => $policy_usr_data->proposer_addr1,
		"Corres_Address2" => $policy_usr_data->proposer_addr2,
		"Corres_Address3" => $policy_usr_data->proposer_addr3,
		"Corres_Citycode" => $insr_data->insr_city( $insr_column_code, $policy_usr_data->proposer_city_code),
		"Corres_City" => $insr_data->insr_city($insr_column_name, $policy_usr_data->proposer_city_code),
		"Corres_Statecode" => $insr_data->insr_state($insr_column_code, $policy_usr_data->proposer_state_code ),
		"Corres_State" => $insr_data->insr_state( $insr_column_name, $policy_usr_data->proposer_state_code ),
		"Corres_Pin" => $policy_usr_data->proposer_pincode,
		"Vehicle_Regno" => $policy_usr_data->tw_reg_no,
		"Engine_No" => $policy_usr_data->tw_engine_no ,
		"Chassis_No" => $policy_usr_data->tw_chassis_no ,
		"Electical_Acc" => $policy_usr_data->ele_acc ,
		"NonElectical_Acc" => $policy_usr_data->non_ele_acc ,
		"Year_of_Manufacture" => $tw_lib->manuf_date($policy_usr_data->yom),
		
		"PreInsurerCode" => $policy_usr_data->pre_insurer_code == null ? "" : $insr_data->insr_preinsr($insr_column_code,  $policy_usr_data->pre_insurer_code ),
		"PrePolicy_Number" => $policy_usr_data->pre_policy_number == null ? "" : $policy_usr_data->pre_policy_number,
		
		"Owner_Driver_Nominee_Name" => $policy_usr_data->nomi_name,
		"Owner_Driver_Nominee_Age" => $policy_usr_data->nomi_age,
		"Owner_Driver_Nominee_Relationship" => $insr_data->nomrel_data("nomrel_name", $policy_usr_data->nomi_rel_code),
		
		"Total_Premium" => $base_prem,
		"Service_Tax" => $gst_val,
		"Total_Amoutpayable" => $tot_prem 
		);
		
		$hdfc_proposal_req = new Hdfc_Policy_Request();
		$proposal_req_str = $hdfc_proposal_req->prepare_policy_request($req_params);
		return $proposal_req_str;
	}
	
	public function parse_proposal_response () {
		
	}	
	
	
	private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}
} // end of class
