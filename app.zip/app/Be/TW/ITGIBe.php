<?php
namespace App\Be\TW;

use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use App\Models\TW\TwUsrData;

class ItgiBe {

	public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = true;
		if($quote_req_data->get_pre_policy_status() != "NEX") { $ret_status = false; }
		return $ret_status;
	}	
	
	public function post_quote_check($quote_resp_data){
		$ret_status = true;
		
		return $ret_status;
	}
	
	public function populate_quote_data($param_arr) { 
	$quote_be = new TwQuoteBe();
	$quote_req_data = new QuoteReqData();
	$usr_db = new TwUsrData();
	
	$calc_pdates = $quote_be->calc_policy_dates( $param_arr["policy_expiry_date"], null );
	
	// set values to request parametes
	$quote_req_data->set_tw_trans_code($param_arr["tw_trans_code"]);
	$quote_req_data->set_pre_policy_status($param_arr["pre_policy_status"]);
	$quote_req_data->set_prepolicy_end_date ( $calc_pdates["PED"] );
	$quote_req_data->set_prepolicy_start_date ( $calc_pdates["PSD"] );// -364
	$quote_req_data->set_policy_start_date ( $calc_pdates["TSD"] );
	$quote_req_data->set_policy_end_date ( $calc_pdates["TED"] );// 365
	
	$quote_req_data->set_registration_date($param_arr["tw_registration_date"]);
	$quote_req_data->set_claim_status($param_arr["claim_status"] );
	$quote_req_data->set_current_ncb( $param_arr["claim_status"]== "N" ? $param_arr["current_ncb"] : 0 );
	$quote_req_data->set_eligible_ncb($param_arr["claim_status"]== "N" ? $param_arr["eli_ncb"] : 0 );
	$quote_req_data->set_plan_duration($param_arr["plan_duration"]);  
	
	$addon_selected = isset($param_arr["addon_selected"]) ? $param_arr["addon_selected"] : null;
	
	$quote_req_data->set_add_on_zrdp( $quote_be->addon_req_parse($addon_selected,"ZRDP") );
	$quote_req_data->set_add_on_cnsm( $quote_be->addon_req_parse($addon_selected,"CNSM"));
	$quote_req_data->set_add_on_ncbp( $quote_be->addon_req_parse($addon_selected,"NCBP"));
	$quote_req_data->set_add_on_rsac( $quote_be->addon_req_parse($addon_selected,"RSAC"));
	$quote_req_data->set_add_on_rtin( $quote_be->addon_req_parse($addon_selected,"RTIN"));
	
	//colllect and set tw details page values specific to bajaj
	$usr_data = $usr_db->get_by_tc($quote_req_data->get_tw_trans_code());
	
	$quote_req_data->set_make_code($usr_data->make_code);
	$quote_req_data->set_model_code($usr_data->model_code);
	$quote_req_data->set_variant_code($usr_data->variant_code );
	$quote_req_data->set_rto_code( $usr_data->rto_code );
	// $quote_req_data->set_rto_city_name( $mstr_data->insr_city("rsgi_code", $usr_data->rto_city_code ));
	$quote_req_data->set_yor($usr_data->yor);
	$quote_req_data->set_yom($usr_data->yom);
	$quote_req_data->set_desired_idv($usr_data->calc_idv);
	$quote_req_data->set_tw_cc($usr_data->variant_cc);
	$quote_req_data->set_tw_age($usr_data->tw_age);
	
	return $quote_req_data;
}

    public function populate_quote_request ($quote_req_data) {
		
	return $quote_req_data;
	}
	
	public function parse_quote_response( QuoteReqData $quote_req_data, $raw_quote_resp) {
		
		$resp_data = new QuoteRespData();
		$tw_trans_code= $quote_req_data->get_tw_trans_code();
		$resp_data->_insurer_code("IITW006");
		$resp_data->_insurer_logo("itgi_logo.png");
		$resp_data->_insurer_name("Ifco Tokio GI");
		$resp_data->_proposal_url("two-wheeler-insurance/itgi");
		
		$resp_data->_final_premium(2);
		
		return $resp_data;
	}


} // end of class
