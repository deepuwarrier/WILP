<?php
namespace App\Be\TW;

use App\Helpers\TW\InsurerData;
use App\Helpers\TW\Reliance\Reliance_Quote_Request;
use App\Helpers\TW\Reliance\Reliance_Policy_Request;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use App\Libraries\TwLib;
use Log;

class RelianceBe {

	public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = true;
		if($quote_req_data->get_pre_policy_status() != "NEX") { $ret_status = false; }
		return $ret_status;
	}	
	
	public function post_quote_check($quote_req_data,$quote_resp_data){
		$ret_status = false;
		/*if($quote_resp_data->ErrorMessages !=null && strlen($quote_resp_data->ErrorMessages) > 0) {
			Log::error("TW Reliance Quote Error : " . $quote_resp_data->ErrorMessages );
			$ret_status = false;
		}*/

		if($quote_resp_data == null || ($quote_resp_data->MotorPolicy->ErrorMessages !=null && strlen($quote_resp_data->MotorPolicy->ErrorMessages) > 0)) {
			Log::error("TW Reliance Quote Error :". $quote_req_data->trans_code . " - "  . $quote_resp_data->MotorPolicy->ErrorMessages);
			$ret_status = true;
		}
		return $ret_status;
	}
	
	public function populate_quote_request (QuoteReqData $quote_req_data) {
		$column_name = "reliance_code";
	    $master_data = new InsurerData();
		$quote_req_ob = new Reliance_Quote_Request();
		$quote_req_arr = $quote_req_ob->raw_quote_req_arr();
		
		// policy details
		$quote_req_arr["Policy"]["Cover_From"] =$this->format_date($quote_req_data->get_policy_start_date());
		$quote_req_arr["Policy"]["Cover_To"] = $this->format_date($quote_req_data->get_policy_end_date());
		
		// Risk details.
		$quote_req_arr["Risk"]["VehicleMakeID"] = $master_data->insr_make($column_name, $quote_req_data->get_make_code());
		$quote_req_arr["Risk"]["VehicleModelID"] = $master_data->insr_variant($column_name, $quote_req_data->get_variant_code());
		$quote_req_arr["Risk"]["VehicleVariant"] = $master_data->insr_variant("variant_name", $quote_req_data->get_variant_code());
		$quote_req_arr["Risk"]["CubicCapacity"] = $quote_req_data->get_tw_cc();
		$quote_req_arr["Risk"]["RTOLocationID"] = $master_data->insr_rto($column_name, $quote_req_data->get_rto_code());
		$quote_req_arr["Risk"]["ExShowroomPrice"] = $quote_req_data->get_tw_price();
		$quote_req_arr["Risk"]["IDV"] = $quote_req_data->get_desired_idv();
		$quote_req_arr["Risk"]["DateOfPurchase"] = $this->format_date($quote_req_data->get_registration_date());
		$quote_req_arr["Risk"]["ManufactureYear"] = $quote_req_data->get_yom();
		
		$quote_req_arr["Risk"]["StateOfRegistrationID"] = $master_data->insr_state($column_name, $quote_req_data->get_state_code()) ;  
		$quote_req_arr["Risk"]["Rto_State_City"] = $master_data->insr_rto("rto", $quote_req_data->get_rto_code());
		$quote_req_arr["Risk"]["Rto_RegionCode"] = $master_data->insr_state("state_name", $quote_req_data->get_state_code());
		
		// vehicle details
		$quote_req_arr["Vehicle"]["Registration_Number"] = substr_replace($quote_req_data->get_rto_code() , "-", 2, 0) . "-AB-1234";
		$quote_req_arr["Vehicle"]["RegistrationNumber_New"] = substr_replace($quote_req_data->get_rto_code() , "-", 2, 0) . "-AB-1234";
		$quote_req_arr["Vehicle"]["Registration_date"] = $this->format_date( $quote_req_data->get_registration_date());
		$quote_req_arr["Vehicle"]["SeatingCapacity"] = "2";  				 
		
		// cover details
		$quote_req_arr["Cover"]["IsPAToUnnamedPassengerCovered"] = "false";
		$zero_dept_required  = $quote_req_data->get_add_on_zrdp() ? "true" : "false";
		$quote_req_arr["Cover"]["IsNilDepreciation"] = $zero_dept_required ; 
		$quote_req_arr["Cover"]["NilDepreciationCoverage"]["NilDepreciationCoverage"]["IsChecked"] = $zero_dept_required;
		
		// previous insurer details
		$quote_req_arr["PreviousInsuranceDetails"]["PrevYearPolicyStartDate"] = $this->format_date( $quote_req_data->get_prepolicy_start_date());
		$quote_req_arr["PreviousInsuranceDetails"]["PrevYearPolicyEndDate"] = $this->format_date( $quote_req_data->get_prepolicy_end_date());
		
		// Ncb details
		$quote_req_arr["NCBEligibility"]["NCBEligibilityCriteria"] = ($quote_req_data->get_claim_status() == 'Y')?'1':'2';
		$quote_req_arr["NCBEligibility"]["PreviousNCB"] = $this->ncb_eli_criteria($quote_req_data->get_current_ncb());

		
		return $quote_req_ob->filled_quote_req_str($quote_req_arr); 
	}
	
	public function parse_quote_response( $quote_req_data, $raw_quote_resp) {
		
		$resp_data = new QuoteRespData();
		$tw_trans_code= $quote_req_data->get_tw_trans_code();
		$resp_data->_insurer_code("IITW008");
		$resp_data->_insurer_logo("reliance_logo.png");
		$resp_data->_insurer_name("Reliance GI");
		$resp_data->_proposal_url("two-wheeler-insurance/reliance/" . $tw_trans_code);
		
		$quote_resp = $raw_quote_resp->MotorPolicy;
		foreach ($quote_resp->lstPricingResponse as $covers ) {
			switch ($covers->CoverageName) {
				case "Basic OD":
					$resp_data->_od_value(round($covers->Premium, 2)); break;
				case "Basic Liability":
					$resp_data->_tp_value( round($covers->Premium, 2));	break;
				case "PA to Owner Driver":
					$resp_data->_pa_value(round($covers->Premium, 2)); break;
				case "OD Discount":
					$resp_data->_od_disc(abs(round($covers->Premium, 2))); break;
				case "NCB":
					$resp_data->_ncb_value(abs(round($covers->Premium, 2))); break;
				case "Nil Depreciation":
					$resp_data->_addon_zrdp(abs(round($covers->Premium, 2))); break;
			}
		} // end of for loop.
	
		$resp_data->_idv($quote_resp->IDV);
		$tot_tax =$quote_resp->NetPremium * 0.18;	
		$resp_data->_service_tax( $tot_tax );
		$resp_data->_final_premium($quote_resp->FinalPremium);
		
		return $resp_data;
	}

	private function ncb_eli_criteria($eli_ncb_rate ) {
		$ncb_eli_criteria = array(
				"0" => "0", "20" => "1", "25" => "2", "35" => "3", "45" => "4", "50" => "5"
		);
		return $ncb_eli_criteria[$eli_ncb_rate];
	}

	private function format_date($dt) { 	return date("Y-m-d", strtotime($dt));	}

	public function validate_proposal_submit ($usr_data) {
		
		$err_txt = "";
		if (!preg_match("/^[0-9]{10}$/", $usr_data->proposer_mobile)) { 	$err_txt .= "Valid mobile number required.\n";	}
		if (!preg_match("/^[a-zA-Z]{3,18}[ ][a-zA-Z]{3,18}$/", $usr_data->proposer_name)) { 	$err_txt .= "Valid first name, last name required.\n";	}
		if (!preg_match("/^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$/", $usr_data->proposer_dob)) { 	$err_txt .= "Valid DOB required.\n";	}
		if (!preg_match("/^[0-9]{4}[-][0-9]{4}[-][0-9]{4}$/", $usr_data->proposer_aadharno)) { 	$err_txt .= "Valid aadhar number required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{10}$/", $usr_data->proposer_panno)) { 	$err_txt .= "Valid PAN required.\n";	}
		if (!preg_match("/^[0-9a-zA-Z@.]{8,50}$/", $usr_data->proposer_email)) { 	$err_txt .= "Valid email required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/]{2,15}$/", $usr_data->regn_addr1)) { 	$err_txt .= "Valid house address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->regn_addr2)) { 	$err_txt .= "Valid street address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->regn_addr3)) { 	$err_txt .= "Valid locality address required.\n";	}
		if (!preg_match("/^[0-9]{6}$/", $usr_data->regn_pincode)) { 	$err_txt .= "Valid pincode required.\n";	}
		if (!preg_match("/^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$/", $usr_data->tw_reg_no)) { 	$err_txt .= "Reg. number format is wrong.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{8,30}$/", $usr_data->tw_engine_no)) { 	$err_txt .= "Valid engine no. required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{10,40}$/", $usr_data->tw_chassis_no)) { 	$err_txt .= "Valid chassis no. required.\n";	}
		if (!preg_match("/^[a-zA-Z ]{3,15}$/", $usr_data->color)) { 	$err_txt .= "Valid color required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/-]{8,30}$/", $usr_data->pre_policy_number)) { 	$err_txt .= "Valid pre. policy number required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/]{8,30}$/", $usr_data->pre_insurer_addr)) { 	$err_txt .= "Fill address min 8 max 30 char.\n";	}
		if($usr_data->pre_claim_status == "Y"){
			if (!preg_match("/^[1-9]{1}$/", $usr_data->pre_claim_count)) { 	$err_txt .= "Min 1 max 9 claims allowed.\n";	}
			if (!preg_match("/^[0-9]{2,7}$/", $usr_data->pre_claim_amount)) { 	$err_txt .= "Valid claim amount required.\n";	}
		}
		if (!preg_match("/^[a-zA-Z ]{4,30}$/", $usr_data->nomi_name)) { 	$err_txt .= "Valid nominee name required.\n";	}
		
		$ret_data = array("verror" => false, "verror_txt" => $err_txt );
		if(strlen( $err_txt) != 0) {
			$ret_data["verror"] = true;
		}
		return $ret_data; 
	} // end 

	public function populate_proposal_request($policy_usr_data) {
		$column_name = "reliance_code";
	    $master_data = new InsurerData();
		$policy_req_ob = new Reliance_Policy_Request();
		$tw_lib = new TwLib();
		$policy_req_arr = $policy_req_ob->raw_policy_req_arr();
		$finace_type = [	'HYPOTHECATION' => '1',
							'HIRE PURCHASE' => '2',
							'LEASE' => '3'
						];
		// policy details
		$policy_req_arr["Policy"]["Cover_From"] =$this->format_date($policy_usr_data->term_start_date);
		$policy_req_arr["Policy"]["Cover_To"] = $this->format_date($policy_usr_data->term_end_date);
		
		// Client Details

		$policy_req_arr["ClientDetails"]['ClientType'] = ($policy_usr_data->owner_type == 'I')?'0':'1';
		$policy_req_arr["ClientDetails"]['LastName'] = $tw_lib->get_lname( $policy_usr_data->proposer_name );
		$policy_req_arr["ClientDetails"]['ForeName'] = $tw_lib->get_fname( $policy_usr_data->proposer_name );
		$policy_req_arr["ClientDetails"]['DOB'] = $this->format_date( $policy_usr_data->proposer_dob);
		$policy_req_arr["ClientDetails"]['Gender'] = ($policy_usr_data->proposer_gender == 'M')?'Male': 'Female';
		$policy_req_arr["ClientDetails"]['MobileNo'] = $policy_usr_data->proposer_mobile;
		$policy_req_arr["ClientDetails"]['OccupationID'] = $master_data->proposer_occu('reliance_code',$policy_usr_data->proposer_occupation);
		$policy_req_arr["ClientDetails"]['MaritalStatus'] = $master_data->proposer_maritialstatus('reliance_code',$policy_usr_data->proposer_maritial_status);
		$policy_req_arr["ClientDetails"]['PanNo'] = $policy_usr_data->proposer_panno;
		$policy_req_arr["ClientDetails"]['AadhaarNo'] = str_replace('-','',$policy_usr_data->proposer_aadharno);

		// Reliance city code temp fix by sreehari 10 Jan 2019
	            $temp_city_code = 0;
	            $temp_pin = (String) $policy_usr_data->regn_pincode;
	        	switch ($temp_pin) {
	        	    case '560040':
	        			$temp_city_code = '540312';
	        			break;
	        		case '560027':
	        			$temp_city_code = '540313';
	        			break;
	        		case '603001':
	        			$temp_city_code = '540969';
	        			break;	
	        		default:
	        			$temp_city_code = $master_data->insr_city('reliance_code',$policy_usr_data->regn_city_code);
	        			break;
	        	}
	        
	     // Reliance city code temp fix ends

		
		if($policy_usr_data->same_comm_addr != 'Y'){
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address1'] = $policy_usr_data->regn_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address2'] = $policy_usr_data->regn_addr2;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address3'] = $policy_usr_data->regn_addr3;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Pincode'] = $policy_usr_data->regn_pincode;
			/*
			<CityID>542328</CityID>
	        <DistrictID>473</DistrictID>
	        <StateID>30</StateID>
	        */

	        

			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['CityID'] = $temp_city_code;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->regn_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->regn_state_code);

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address1'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address2'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address3'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Pincode'] = $policy_usr_data->proposer_pincode;

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['CityID'] = $temp_city_code;

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->proposer_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->proposer_state_code);

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address1'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address2'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address3'] = $policy_usr_data->proposer_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Pincode'] = $policy_usr_data->proposer_pincode;

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['CityID'] = $temp_city_code;

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->proposer_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->proposer_state_code);

			$policy_req_arr["ClientDetails"]['Risk']['IsRegAddressSameasCommAddress'] = 'false';
			$policy_req_arr["ClientDetails"]['Risk']['IsRegAddressSameasPermanentAddress'] = 'false';
		} else {
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address1'] = $policy_usr_data->regn_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address2'] = $policy_usr_data->regn_addr2;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Address3'] = $policy_usr_data->regn_addr3;
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['Pincode'] = $policy_usr_data->regn_pincode;

			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['CityID'] = $temp_city_code;

			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->regn_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['RegistrationAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->regn_state_code);

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address1'] = $policy_usr_data->regn_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address2'] = $policy_usr_data->regn_addr2;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Address3'] = $policy_usr_data->regn_addr3;
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['Pincode'] = $policy_usr_data->regn_pincode;

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['CityID'] =  $temp_city_code;

			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->regn_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['CommunicationAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->regn_state_code);

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address1'] = $policy_usr_data->regn_addr1;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address2'] = $policy_usr_data->regn_addr2;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Address3'] = $policy_usr_data->regn_addr3;
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['Pincode'] = $policy_usr_data->regn_pincode;

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['CityID'] = $temp_city_code;

			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['DistrictID'] = $master_data->insr_pincode('reliance_dist_code',$policy_usr_data->regn_pincode);
			$policy_req_arr["ClientDetails"]['ClientAddress']['PermanentAddress']['StateID'] = $master_data->insr_state('reliance_code',$policy_usr_data->regn_state_code);

			$policy_req_arr["ClientDetails"]['Risk']['IsRegAddressSameasCommAddress'] = 'true';
			$policy_req_arr["ClientDetails"]['Risk']['IsRegAddressSameasPermanentAddress'] = 'true';
		}

		$policy_req_arr["ClientDetails"]['EmailID'] = $policy_usr_data->proposer_email;
		$policy_req_arr["ClientDetails"]['Salutation'] = ($policy_usr_data->proposer_gender == 'M')?'Mr.':'Ms.';

		// Policy Details
		$policy_req_arr["Policy"]['Cover_From'] = $policy_usr_data->term_start_date;
		$policy_req_arr["Policy"]['Cover_To'] = $policy_usr_data->term_end_date;
		

		// Risk details.
		$policy_req_arr["Risk"]["VehicleMakeID"] = $master_data->insr_make($column_name, $policy_usr_data->make_code);
		$policy_req_arr["Risk"]["VehicleModelID"] = $master_data->insr_variant($column_name, $policy_usr_data->variant_code);
		$policy_req_arr["Risk"]["VehicleVariant"] = $master_data->insr_variant("variant_name", $policy_usr_data->variant_code);
		$policy_req_arr["Risk"]["CubicCapacity"] = $policy_usr_data->variant_cc;
		$policy_req_arr["Risk"]["RTOLocationID"] = $master_data->insr_rto($column_name, $policy_usr_data->rto_code);
		$policy_req_arr["Risk"]["ExShowroomPrice"] = $policy_usr_data->variant_price;
		$policy_req_arr["Risk"]["IDV"] = $policy_usr_data->opt_idv;
		$policy_req_arr["Risk"]["DateOfPurchase"] = $this->format_date($policy_usr_data->tw_reg_date);
		$policy_req_arr["Risk"]["ManufactureMonth"] = date("m", strtotime($policy_usr_data->tw_reg_date)); //date("Y-m-d", strtotime($policy_usr_data->tw_reg_date))
		$policy_req_arr["Risk"]["ManufactureYear"] = $policy_usr_data->yom;
		$policy_req_arr["Risk"]["StateOfRegistrationID"] = $master_data->insr_state($column_name, $policy_usr_data->state_code) ;  
		$policy_req_arr["Risk"]["Rto_State_City"] = $master_data->insr_rto("rto", $policy_usr_data->rto_code);
		$policy_req_arr["Risk"]["Rto_RegionCode"] = $master_data->insr_state("state_name", $policy_usr_data->state_code);
		$policy_req_arr["Risk"]["IsPermanentAddressSameasCommAddress"] = 'true';
		$policy_req_arr["Risk"]["EngineNo"] = $policy_usr_data->tw_engine_no;
		$policy_req_arr["Risk"]["Chassis"] = $policy_usr_data->tw_chassis_no;
		
		$policy_req_arr["Risk"]["IsVehicleHypothicated"] = ($policy_usr_data->is_financed == 'Y')?'true':'false';
		if($policy_usr_data->is_financed == 'Y'){
			$policy_req_arr["Risk"]["FinanceType"] = $finace_type[$policy_usr_data->type_of_finance];
			$policy_req_arr["Risk"]["FinancierName"] = $policy_usr_data->financier_name;
			$policy_req_arr["Risk"]["FinancierAddress"] = $policy_usr_data->financier_address;
		}
		
		// vehicle details
		$policy_req_arr["Vehicle"]["Registration_Number"] = $policy_usr_data->tw_reg_no;
		$policy_req_arr["Vehicle"]["Registration_date"] = $this->format_date( $policy_usr_data->tw_reg_date);
		// $policy_req_arr["Vehicle"]["SeatingCapacity"] = "2";
		
		// cover details
		$policy_req_arr["Cover"]["IsPAToUnnamedPassengerCovered"] = "false";
		$zero_dept_required  = ($policy_usr_data->addon_covers == 'ZRDP') ? "true" : "false"; //addon_covers
		$policy_req_arr["Cover"]["IsNilDepreciation"] = $zero_dept_required ; 
		$policy_req_arr["Cover"]["NilDepreciationCoverage"]["NilDepreciationCoverage"]["IsChecked"] = $zero_dept_required;
		$policy_req_arr["Cover"]["NilDepreciationCoverage"]["NilDepreciationCoverage"]["ApplicableRate"] = json_decode($policy_usr_data->misc_desc)['reliance_nildep_rate'];//'1';

		$policy_req_arr["Cover"]["PACoverToOwner"]["PACoverToOwner"]["NomineeName"] = $policy_usr_data->nomi_name;
		$policy_req_arr["Cover"]["PACoverToOwner"]["PACoverToOwner"]["NomineeDOB"] = $this->format_date($policy_usr_data->nominee_dob);
		$policy_req_arr["Cover"]["PACoverToOwner"]["PACoverToOwner"]["NomineeRelationship"] =  $master_data->nomrel_data("nomrel_name", $policy_usr_data->nomi_rel_code);
		
		// previous insurer details
		$policy_req_arr["PreviousInsuranceDetails"]["PrevYearPolicyStartDate"] = $this->format_date( $policy_usr_data->policy_start_date);
		$policy_req_arr["PreviousInsuranceDetails"]["PrevYearPolicyEndDate"] = $this->format_date( $policy_usr_data->policy_exp_date);
		$policy_req_arr["PreviousInsuranceDetails"]["PrevYearInsurer"] =  $master_data->insr_preinsr($column_name, $policy_usr_data->pre_insurer_code);
		$policy_req_arr["PreviousInsuranceDetails"]["PrevYearPolicyNo"] = $policy_usr_data->pre_policy_number;
		$policy_req_arr["PreviousInsuranceDetails"]["PrevYearInsurerAddress"] = $policy_usr_data->pre_insurer_addr;
		$policy_req_arr["PreviousInsuranceDetails"]["IsClaimedLastYear"] = ($policy_usr_data->pre_claim_status == 'Y')?'true':'false';
		$policy_req_arr["PreviousInsuranceDetails"]["NoOfClaimedLastYear"] = '2';
		
		// Ncb details
		$policy_req_arr["NCBEligibility"]["NCBEligibilityCriteria"] = ($policy_usr_data->pre_claim_status == 'Y')?'1':'2';
		$policy_req_arr["NCBEligibility"]["PreviousNCB"] = $this->ncb_eli_criteria($policy_usr_data->curr_ncb);

		
		return $policy_req_ob->filled_policy_req_str($policy_req_arr); 
	}


	public function post_proposal_check($quote_req_data,$quote_resp_data){
		$ret_status = false;
		
		if($quote_resp_data == null || ($quote_resp_data->MotorPolicy->ErrorMessages !=null && strlen($quote_resp_data->MotorPolicy->ErrorMessages) > 0)) {
			Log::error("TW Reliance Proposal Error :". $quote_req_data->trans_code . " - "  . $quote_resp_data->MotorPolicy->ErrorMessages);
			$ret_status = true;
		}
		return $ret_status;
	}

} // end of class
