<?php
namespace App\Be\TW;

use App\Models\TW\data\QuoteReqData;

class RsgiBe {

	public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = false;
		if($quote_req_data->get_pre_policy_status() != "NEX") { $ret_status = true; }
		return $ret_status;
	}	
	
    public function post_quote_check($quote_resp_data){
		$ret_status = true;
		return $ret_status;
	}
	
	public function validate_proposal_submit ($usr_data) {
		
		$err_txt = "";
		if (!preg_match("/^[0-9]{10}$/", $usr_data->proposer_mobile)) { 	$err_txt .= "Valid mobile number required.\n";	}
		if (!preg_match("/^[a-zA-Z]{3,18}[ ][a-zA-Z]{3,18}$/", $usr_data->proposer_name)) { 	$err_txt .= "Valid first name, last name required.\n";	}
		if (!preg_match("/^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$/", $usr_data->proposer_dob)) { 	$err_txt .= "Valid DOB required.\n";	}
		if (!preg_match("/^[0-9]{4}[-][0-9]{4}[-][0-9]{4}$/", $usr_data->proposer_aadharno)) { 	$err_txt .= "Valid aadhar number required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{10}$/", $usr_data->proposer_panno)) { 	$err_txt .= "Valid PAN required.\n";	}
		if (!preg_match("/^[0-9a-zA-Z@.]{8,50}$/", $usr_data->proposer_email)) { 	$err_txt .= "Valid email required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/]{2,15}$/", $usr_data->regn_addr1)) { 	$err_txt .= "Valid house address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->regn_addr2)) { 	$err_txt .= "Valid street address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->regn_addr3)) { 	$err_txt .= "Valid locality address required.\n";	}
		if (!preg_match("/^[0-9]{6}$/", $usr_data->regn_pincode)) { 	$err_txt .= "Valid pincode required.\n";	}
		if (!preg_match("/^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$/", $usr_data->tw_reg_no)) { 	$err_txt .= "Reg. number format is wrong.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{8,30}$/", $usr_data->tw_engine_no)) { 	$err_txt .= "Valid engine no. required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{10,40}$/", $usr_data->tw_chassis_no)) { 	$err_txt .= "Valid chassis no. required.\n";	}
		if (!preg_match("/^[a-zA-Z ]{3,15}$/", $usr_data->color)) { 	$err_txt .= "Valid color required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/-]{8,30}$/", $usr_data->pre_policy_number)) { 	$err_txt .= "Valid pre. policy number required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/]{8,30}$/", $usr_data->pre_insurer_addr)) { 	$err_txt .= "Fill address min 8 max 30 char.\n";	}
		if($usr_data->pre_claim_status == "Y"){
			if (!preg_match("/^[1-9]{1}$/", $usr_data->pre_claim_count)) { 	$err_txt .= "Min 1 max 9 claims allowed.\n";	}
			if (!preg_match("/^[0-9]{2,7}$/", $usr_data->pre_claim_amount)) { 	$err_txt .= "Valid claim amount required.\n";	}
		}
		if (!preg_match("/^[a-zA-Z ]{4,30}$/", $usr_data->nomi_name)) { 	$err_txt .= "Valid nominee name required.\n";	}
		
		$ret_data = array("verror" => false, "verror_txt" => $err_txt );
		if(strlen( $err_txt) != 0) {
			$ret_data["verror"] = true;
		}
		return $ret_data; 
	} // end 
	
	
} // end of class
