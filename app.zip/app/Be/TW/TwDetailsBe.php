<?php

namespace App\Be\TW;

use App\Constants\Tw_Constants;
use App\Models\TW\TwConfig;
use App\Models\TW\TwRTO;
use App\Models\TW\TwVariant;



class TwDetailsBe  {

  /**	Function returns Year list starting from Present year
  		Used at TW details page.
  	*/ 
	public function getYorList(){
		
   $cfgobj = new TwConfig();
   $yorstart = $cfgobj->getValue(Tw_Constants::YOR_SEL_ST );
   $yordur = $cfgobj->getValue(Tw_Constants::YOR_SEL_DUR);
   $yorList = array();
   for($idx=0;$idx< $yordur->config_value;$idx++){
   	$yorList[$idx] = $yorstart->config_value - $idx;
   }
	return $yorList;
	}
	
	public function calc_yom ($yor) {
		return $yor;
	}
	
	public function get_storable_details($params) {
		
		$vechicle_code = $params["vechicle_code"];
		$tw_rto = $params["tw_rto"];
		$tw_yor = $params["tw_yor"];
		
		$rto_db = new TwRTO();
		$rto_data = $rto_db->rto_details($tw_rto);
		
		$vehicle_arr = explode("^",$vechicle_code);  
		$make_code = $vehicle_arr[0];
		$model_code = $vehicle_arr[1];
		$variant_code = $vehicle_arr[2];
		
		$variant_db = new TwVariant();
		$variant_data = $variant_db->variant_details($variant_code);
		
		$ret_arr = array (
				"policy_type" => "C",
				"make_code" => $make_code,
				"model_code" =>$model_code,
				"variant_code" => $variant_code,
				"variant_price" => $variant_data->variant_price,
				"variant_base_price" => $variant_data->variant_price,
				"variant_cc" => $variant_data->variant_cc,
				"state_code" => $rto_data->state_code_ref,
				"rto_city_code" => $rto_data->city_code_ref,
				"rto_code" => $tw_rto,
				"yor"=>$tw_yor,
				"yom"=>$this->calc_yom($tw_yor)
		);
		
		return $ret_arr;
	}
	
	
	

	public function get_time_hh_mm_ss(){
		return date("H:i:s");
	}
	
}