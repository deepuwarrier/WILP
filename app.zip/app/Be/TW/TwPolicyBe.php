<?php
namespace App\Be\TW;

use App\Models\TW\data\QuoteRespData;
use App\Models\TW\TwInsurers;

class TwPolicyBe  {

public  function parse_covers ($cover_str) {
	 return explode("||", $cover_str);
}	

public function parse_proposal_pipb( $usr_data ){
	$quote_resp = new QuoteRespData();
	$ins_data_ob = new TwInsurers();
	$ins_data = $ins_data_ob->insurer_details($usr_data->insurer_code);
	$quote_resp->_insurer_code( $ins_data->isu_code);
	$quote_resp->_insurer_logo( $ins_data->isu_logo);
	$quote_resp->_insurer_name( $ins_data->isu_name );
	
	$add_ons = explode("|", $usr_data->addon_premium );
	
	$quote_resp->_od_value( $usr_data->od_premium);
	$quote_resp->_od_disc( $usr_data->od_disc_value);
	$quote_resp->_ncb_value( $usr_data->ncb_disc_value);
	$quote_resp->_tp_value( $usr_data->tp_premium);
	$quote_resp->_pa_value( $add_ons[0]);
	$quote_resp->_addon_zrdp( $add_ons[1]);
	$quote_resp->_idv( $usr_data->opt_idv );
	$quote_resp->_gross_premium( $usr_data->gross_total_premium);
	$quote_resp->_service_tax( $usr_data->total_tax);
	$quote_resp->_final_premium( $usr_data->total_premium);
	
	return $quote_resp;
}



} // end of class. 