<?php

namespace App\Be\TW;

use App\Libraries\TwLib;
use App\Models\TW\data\IdvData;
use App\Models\TW\TwConfig;
use App\Models\TW\TwIdvRate;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwODRates;
use App\Constants\Tw_Constants;


class TwQuoteBe  {

	public function idv_sec_values($trans_code){
	
	$idv_data = new IdvData();
	$tw_lib = new TwLib ();
	$usr_db = new TwUsrData();
	$usr_data = $usr_db->get_by_tc($trans_code);  
	
	$idv_data->set_trans_code($trans_code);

/**
 * Calculate and set the data to idv section.  Otherwise : fetch and set from transaction
 */ 
	if ($usr_data->term_start_date === null ) {
		
		//get Policy expiry date based on db config:
		$idv_data->set_pre_policy_status("NEX");
		
		
		$policy_exp_date = $this->policy_exp_date();
		$idv_data->_r_pexdt($policy_exp_date);
		$idv_data->_r_pexdt_max($tw_lib->date_adjust_days( $policy_exp_date, 60));
		$idv_data->_r_pexdt_min($tw_lib->date_adjust_days( $policy_exp_date, -1));
		
		//get Vechichle reg date based on db config and user entered values  as YOR
		$idv_data->_r_twrgdt($this->tw_reg_date($trans_code));
		
		// Initialize NCB values based on age calculation.
		$curr_ncb_calc = $this->tw_curr_ncb($idv_data->r_twrgdt(), $tw_lib->date_adjust_days($idv_data->r_pexdt(),1));
		$idv_data->_r_crr_ncb($curr_ncb_calc);
		
		$idv_data->_r_eli_ncb($this->tw_eli_ncb($curr_ncb_calc));
		
		// calculate IDV
		$idv_data->_calc_idv($this->tw_vechicle_idv_calc($trans_code, $idv_data->r_twrgdt(), $idv_data->r_pexdt() ));
		$idv_data->set_base_idv($idv_data->calc_idv); 
	} else {
		$policy_exp_date = $this->policy_exp_date();
		$idv_data->_r_pexdt($usr_data->policy_exp_date);
		$idv_data->_r_pexdt_max($tw_lib->date_adjust_days( $policy_exp_date, 60));
		$idv_data->_r_pexdt_min($tw_lib->date_adjust_days( $policy_exp_date, -1));
		$idv_data->set_pre_policy_status( $usr_data->pre_policy_status);
		$idv_data->_r_twrgdt( $usr_data->tw_reg_date);
		$idv_data->_r_crr_ncb($usr_data->curr_ncb);
		$idv_data->_r_eli_ncb( $usr_data->eli_ncb );
		$idv_data->_calc_idv( $usr_data->calc_idv);
		$idv_data->set_base_idv($usr_data->base_idv);
		$idv_data->set_variant_base_price($usr_data->variant_base_price);
	}
	return $this->populate_idv_range($idv_data);
}

public function idv_view_values($tw_trans_code, $pre_policy_status, $policy_exp_date, $reg_date, $claim_status, $curr_ncb, $expected_idv) {
	$idv_ob = new IdvData();
	$tw_lib = new TwLib ();
	
	$idv_ob->set_trans_code( $tw_trans_code);
	$idv_ob->_r_twrgdt($reg_date!= null ? $reg_date: $this->tw_reg_date( $tw_trans_code));
	$reg_dt_minmax = $this->regdt_minmax_dates($idv_ob->r_twrgdt()); 
	$idv_ob->_r_twrgdt_min($reg_dt_minmax["min_date"]);
	$idv_ob->_r_twrgdt_max($reg_dt_minmax["max_date"]);
	$idv_ob->set_pre_policy_status($pre_policy_status);
	
	switch ($pre_policy_status) {
		case "NEX":
			$pxdt = $this->policy_exp_date();
			$idv_ob->_r_pexdt($pxdt);
			$pexmm_arr = $this->pex_minmax_dates($pre_policy_status, $pxdt);  
			$idv_ob->_r_pexdt_min($pexmm_arr["min_date"]);
			$idv_ob->_r_pexdt_max($pexmm_arr["max_date"]);
			
			$idv_ob->_r_claims( $claim_status== "N" ? false : true);
			if($idv_ob->r_claims()){
				$idv_ob->_r_crr_ncb(0);
				$idv_ob->_r_eli_ncb(0);
			} else{
				$idv_ob->_r_crr_ncb($curr_ncb);
				$idv_ob->_r_eli_ncb($this->tw_eli_ncb( $idv_ob->r_crr_ncb()));
			}
			$idv_ob->_calc_idv($expected_idv);
			$idv_ob->set_base_idv($this->tw_vechicle_idv_calc($tw_trans_code, $idv_ob->r_twrgdt(), $idv_ob->r_pexdt()));
			$idv_ob = $this->populate_idv_range($idv_ob);
			break;
		case "E90":
			$today_date = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
			$pxdt = $tw_lib->date_adjust_days( $today_date, -1);
			$idv_ob->_r_pexdt($pxdt);
			$pexmm_arr = $this->pex_minmax_dates($pre_policy_status, $pxdt);
			$idv_ob->_r_pexdt_min($pexmm_arr["min_date"]);
			$idv_ob->_r_pexdt_max($pexmm_arr["max_date"]);
			
			$idv_ob->_r_claims( $claim_status== "N" ? false : true);
			if($idv_ob->r_claims()){
				$idv_ob->_r_crr_ncb(0);
				$idv_ob->_r_eli_ncb(0);
			} else{
				$idv_ob->_r_crr_ncb($curr_ncb);
				$idv_ob->_r_eli_ncb($this->tw_eli_ncb( $idv_ob->r_crr_ncb()));
			}
			$idv_ob->_calc_idv($expected_idv);
			$idv_ob->set_base_idv($this->tw_vechicle_idv_calc($tw_trans_code, $idv_ob->r_twrgdt(), $idv_ob->r_pexdt()));
			$idv_ob = $this->populate_idv_range($idv_ob);
			break;
		case "E90P":  
			$today_date = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
			$pxdt = $tw_lib->date_adjust_days( $today_date, -100);
			$idv_ob->_r_pexdt($pxdt);
			$idv_ob->set_isvisible_pexdt(false);
			$idv_ob->_r_crr_ncb(0);
			$idv_ob->_r_eli_ncb(0);
			$idv_ob->set_isvisible_ncb(false);
			$idv_ob->_calc_idv($expected_idv);
			$idv_ob->set_base_idv($this->tw_vechicle_idv_calc($tw_trans_code, $idv_ob->r_twrgdt(), $idv_ob->r_pexdt()));
			$idv_ob = $this->populate_idv_range($idv_ob);
			break;
	}
 	dd($idv_ob);
	return $idv_ob;
}

private function policy_exp_date() {
		$tw_lib = new TwLib ();
		$twconf = new TwConfig ();
		$ped_vari = $twconf->getValue ("POLICY_EXP_DT");
		
		return $tw_lib->date_adjust_days ( $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY) , $ped_vari->config_value);
	}

private function  pex_minmax_dates($pre_policy_status, $pex_date) {

	$policy_exp_date = $pex_date != null ? $pex_date : $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
	$min_date = ""; $max_date = "";
	$tw_lib = new TwLib();
	$today_date = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
	
	switch ($pre_policy_status) {
		case "NEX":
			$min_date= $today_date;
			$max_date= $tw_lib->date_adjust_days( $today_date, +45);
			break;
		case "E90":
			$min_date = $tw_lib->date_adjust_days( $today_date, -90);
			$max_date =$tw_lib->date_adjust_days( $today_date, -1);
			break;
	}
	return array("min_date" => $min_date, "max_date"=> $max_date );
}

private function  regdt_minmax_dates( $reg_date) {
	$reg_dt_arr = explode("-", $reg_date);
	$min_date= "1-Jan-". $reg_dt_arr[2];
	$max_date= "31-Dec-". $reg_dt_arr[2];
	return array("min_date" => $min_date, "max_date"=> $max_date );
}
	
	
	private function tw_reg_date($trans_code){
	$twconf = new TwConfig ();
	$twlib = new TwLib();
	$reg_dt_vari = $twconf->getValue("REG_DATE");
	$usrdt_db = new TwUsrData();
	$usr_yor = $usrdt_db->get_yor_by_tc($trans_code);
	
	return $twlib->date_adjust_days ( $twlib->date_today("d-M-".$usr_yor->yor) , $reg_dt_vari->config_value);
}	

public function tw_curr_ncb($tw_reg_date, $pol_st_date) {
	
	$tw_age = $this->tw_vechicle_age($tw_reg_date, $pol_st_date);
	
	switch ($tw_age) {
		case "0":	return 0;		break;
		case "1": 	return 0;	break;
		case "2":	return 20;	break;
		case "3":	return 25;	break;
		case "4":	return 35;	break;
		case "5":	return 45;	break;
		default:	return 50;
	}
}

public function tw_eli_ncb($curr_ncb) {
	switch ($curr_ncb) {
		case "0":		return 20;		break;
		case "20": 	return 25;		break;
		case "25":		return 35;		break;
		case "35":		return 45;		break;
		case "45":		return 50;		break;
		case "50":		return 50;		break;
		default:	return 0;
}
}

public function tw_vechicle_age($tw_reg_date, $pol_st_date){
	$twlib = new TwLib();
	$tw_age =  $twlib->date_difference($tw_reg_date, $pol_st_date);
	return $tw_age ;
}

// private function tw_vechicle_idv_calc($idv_data) {
public function tw_vechicle_idv_calc($trans_code, $reg_date, $polexp_date) {
	
	$usrtdb = new TwUsrData(); 
	$tw_lib = new TwLib();
	$usrdata = $usrtdb->get_by_tc( $trans_code);  
	
	$tw_age = $this->tw_vechicle_age(
			$reg_date,
			$tw_lib->date_adjust_days( $polexp_date, 1)
			);
	
	$idv_value =(( $usrdata->variant_price * $this->idv_rate($tw_age) )/ 100 ) ;
	return intval(round($idv_value));     
}

private function populate_idv_range ( $idv_data) {
 $min_rate = 30; $max_rate = 30;
 $base_idv = $idv_data->get_base_idv();  
 $idv_data->set_base_idv_min( round ( $base_idv - ($base_idv * $min_rate)/100) );
 $idv_data->set_base_idv_max( round ( $base_idv + ($base_idv * $max_rate)/100) );
 return $idv_data;  
}

private function idv_rate($age) {
	$db = new TwIdvRate();
	$idv_rate =  $db->idv_rate_std($age);  
	return $idv_rate->std_rate;
}

public function od_disc_rate($vehicle_age){
	$config_db = new TwConfig();
	$od_disc_rate = 0;
	$od_disc_rate_arr = explode("|", $config_db->getValue("UIIC_OD_DISC_RATE")->config_value);
	if($vehicle_age <= 2) { $od_disc_rate = $od_disc_rate_arr[0]; }
	if($vehicle_age > 2 && $vehicle_age <= 5) { $od_disc_rate = $od_disc_rate_arr[1];}
	if($vehicle_age > 5) { $od_disc_rate = $od_disc_rate_arr[2]; }
	return $od_disc_rate;
}

public function tw_od_rate( $tw_age, $tw_cc, $tw_rtozone ) {
	$od_rate_db = new TwODRates();
	return $od_rate_db->od_rates($tw_age, $tw_cc, $tw_rtozone);
}
	
}