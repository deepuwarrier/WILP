<?php

namespace App\Be\TW;

use App\Libraries\TwLib;
use App\Models\TW\data\IdvData;
use App\Models\TW\TwConfig;
use App\Models\TW\TwIdvRate;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwODRates;



class TwQuoteBe  {

public function idv_sec_values($session_key){
	
	$idv_data = new IdvData();
	$tw_lib = new TwLib ();
	
	$idv_data->_snn_key($session_key);
	
	
	//get Policy expiry date based on db config:
	
	
	$policy_exp_date = $this->policy_exp_date();
	$idv_data->_r_pexdt($policy_exp_date);
	$idv_data->_r_pexdt_max($tw_lib->date_adjust_days( $policy_exp_date, 45));
	$idv_data->_r_pexdt_min($tw_lib->date_adjust_days( $policy_exp_date, -1));

	
	
	//get Vechichle reg date based on db config and user entered values  as YOR
	$idv_data->_r_twrgdt($this->tw_reg_date($session_key));
	
	
	// Initialize NCB values based on age calculation.
	$curr_ncb_calc = $this->tw_curr_ncb($idv_data->r_twrgdt(), $tw_lib->date_adjust_days($idv_data->r_pexdt(),1));
	$idv_data->_r_crr_ncb($curr_ncb_calc);
	
	$idv_data->_r_eli_ncb($this->tw_eli_ncb($curr_ncb_calc));
	
	// calculate IDV
	$idv_data->_calc_idv($this->tw_vechicle_idv_calc($idv_data->snn_key(), $idv_data->r_twrgdt(), $idv_data->r_pexdt() ));
	return $idv_data;
}

private function policy_exp_date() {
		$tw_lib = new TwLib ();
		$twconf = new TwConfig ();
		$ped_vari = $twconf->getValue ("POLICY_EXP_DT");
		
		return $tw_lib->date_adjust_days ( $tw_lib->date_today("d-M-Y") , $ped_vari->config_value);
	}

private function tw_reg_date($session_key){
	$twconf = new TwConfig ();
	$twlib = new TwLib();
	$reg_dt_vari = $twconf->getValue("REG_DATE");
	$usrdt_db = new TwUsrData();
	$usr_yor = $usrdt_db->get_yor($session_key);
	
	return $twlib->date_adjust_days ( $twlib->date_today("d-M-".$usr_yor->yor) , $reg_dt_vari->config_value);
}	

public function tw_curr_ncb($tw_reg_date, $pol_st_date) {
	
	$tw_age = $this->tw_vechicle_age($tw_reg_date, $pol_st_date);
	
	switch ($tw_age) {
		case "0":	return 0;		break;
		case "1": 	return 20;	break;
		case "2":	return 25;	break;
		case "3":	return 35;	break;
		case "4":	return 45;	break;
		default:	return 50;
	}
}

public function tw_eli_ncb($curr_ncb) {
	switch ($curr_ncb) {
		case "0":		return 20;		break;
		case "20": 	return 25;		break;
		case "25":		return 35;		break;
		case "35":		return 45;		break;
		case "45":		return 50;		break;
		case "50":		return 50;		break;
		default:	return 0;
}
}

public function tw_vechicle_age($tw_reg_date, $pol_st_date){
	$twlib = new TwLib();
	$tw_age =  $twlib->date_difference($tw_reg_date, $pol_st_date);
	return $tw_age ;
}

// private function tw_vechicle_idv_calc($idv_data) {
public function tw_vechicle_idv_calc($ssnkey, $reg_date, $polexp_date) {
	
	$usrtdb = new TwUsrData(); 
	$tw_lib = new TwLib();
	$usrdata = $usrtdb->getValue( $ssnkey);  
	
	$tw_age = $this->tw_vechicle_age(
			$reg_date,
			$tw_lib->date_adjust_days( $polexp_date, 1)
			);
	
	$idv_value =(( $usrdata->variant_price * $this->idv_rate($tw_age) )/ 100 ) ;
	return intval(round($idv_value));     
}

private function idv_rate($age) {
	$db = new TwIdvRate();
	$idv_rate =  $db->idv_rate_std($age);  
	return $idv_rate->std_rate;
}

public function tw_od_rate( $tw_age, $tw_cc, $tw_rtozone ) {
	$od_rate_db = new TwODRates();
	return $od_rate_db->od_rates($tw_age, $tw_cc, $tw_rtozone);
}
	
}