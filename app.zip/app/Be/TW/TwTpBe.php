<?php

namespace App\Be\TW;

use App\Be\Common\GstBe;
use App\Constants\Tw_Constants;
use App\Libraries\TwLib;
use App\Helpers\TW\InsurerData;

class TwTpBe {
	
	public function calculate_tp_premium( $req_params ) { 
// 		dd($req_params);
		
		$cc_value = $req_params["cc_value"]; 
		$customer_state_code = array_key_exists("statecode",$req_params)  ? $req_params["statecode"] : "II0017";

		$basic_tp_premium = $this->calc_tp($cc_value) ; 
		$addon_tp_premium = ( $req_params["addon_pa_od"] =="Y" ? $this->calc_pa() : 0 ) 
		+ ($req_params["addon_pa_pass"] == "Y" ? $this->calc_pa_pass() : 0 ) ;
											
	$gross_tp_premium = $basic_tp_premium + $addon_tp_premium ; 
	
	$gst_be = new GstBe();
	
	$gst_data = $gst_be->get_gst_values(Tw_Constants::UIIC_GST_STATE_REF, $customer_state_code, $gross_tp_premium);
	
	$gst_tot = $gst_data->get_total_tax();
	$ret_data =   array(
			"BASIC_TP_PREMIUM" => $basic_tp_premium, 
			"ADDON_PREMIUM" => $addon_tp_premium, 
			"GROSS_PREMIUM" => $gross_tp_premium, 
			"TOTAL_GST" => $gst_tot , 
			"FINAL_PREMIUM" => $gross_tp_premium + $gst_tot  );
	
	
	return $ret_data;
	} // end fo method

	private function calc_tp ( $tw_cc) { 
		if ($tw_cc <= 75 && $tw_cc != 0) {  return 427;  }
        if ($tw_cc > 75 && $tw_cc <= 150) {  return 720; }
        if ($tw_cc > 150 && $tw_cc <= 350) {  return 985;  }
        if ($tw_cc > 350) {  return 2323;  }
        return 0;
    }

    private function calc_pa() {
        return 50;
    }
    
    private function calc_pa_pass() {
        return 100;
    }
    
     private function calc_ll_driver() {
        return 50;
    }
    
    public function parse_tp_proposal_data ($usr_trans_code, $proposal_params) { 
   
    	$tw_lib = new TwLib();
         $master_data = new InsurerData();
    	
    	$opted_addons = "";
    	$addon_premium = "";
    	
    	if( $proposal_params["addon_pa_od"] =="Y" ) {
    		$opted_addons = $opted_addons . "PA";
    		$addon_premium = $addon_premium . "50";
    	}
    	if( $proposal_params["addon_pa_pass"] =="Y" ) {
    		$opted_addons = $opted_addons . "|PAPASS";
    		$addon_premium = $addon_premium . "|100";
    	}
    	
    	$gross_total_premium = $proposal_params["basic_tp_premium"] + $proposal_params["addon_premium"];
    	
    	$twmkmdvr = explode("^", $proposal_params["vechicle_code"]);
    	$make_code = $twmkmdvr[0];
    	$model_code = $twmkmdvr[1];
    	$variant_code = $twmkmdvr[2];
    	
    	$reg_arr = explode("-", $proposal_params["tw_regno"]); 
    	
    	$rto_code = $reg_arr[0]."".$reg_arr[1] ;
    	$tw_reg_no = $proposal_params["tw_regno"];
    	$tw_yom = explode("-", $proposal_params["reg_date"]);
    	$retdata =  array(
    			"trans_code"=> $usr_trans_code,
    			"policy_type" => "TP",
    			"make_code" => $make_code,
    			"model_code" => $model_code,
    			"variant_code" => $variant_code,
    			"variant_cc" => $master_data->insr_variant("variant_cc",$variant_code),
    			"rto_code" => strtoupper($rto_code),
    			"yom" => $tw_yom[2],
    			"yor" => $tw_yom[2],
    			"policy_exp_date" => $proposal_params["pre_pex_date"],
    			"term_start_date" => $proposal_params["policy_start_date"],
    			"term_end_date" => $proposal_params["policy_end_date"],
    			"tw_reg_date" => $proposal_params["reg_date"],
    			"term_duration" => "1",
    			"insurer_code" => "IITW002",
    			"addon_covers" => $opted_addons,
    			"total_premium" => $proposal_params["final_premium"],
    			"owner_type" => $proposal_params["customer_type"],
    			"proposer_gender" => strtoupper($proposal_params["customer_gender"]),
    			"proposer_dob" =>  strtoupper($proposal_params["customer_dob"]),
    			"proposer_name" =>  $proposal_params["customer_type"] == "I" ? strtoupper($proposal_params["customer_name"]) :  strtoupper($proposal_params["organisation_name"]) ,
    			"proposer_email" =>  strtoupper($proposal_params["customer_email"]),
    			"proposer_mobile" =>  strtoupper($proposal_params["customer_mobile"]),
    			"proposer_aadharno" =>   $proposal_params["customer_type"] == "I" ? strtoupper($proposal_params["customer_aadharno"]) : strtoupper($proposal_params["organisation_gstnno"]) ,   
    			"regn_addr1" =>  strtoupper($proposal_params["customer_address"]),
    			"regn_addr2" => "",
    			"regn_addr3" => "",
    			"regn_state_code" => $proposal_params["statecode"],
    			"regn_city_code" => $proposal_params["citycode"],
    			"regn_pincode" => $proposal_params["customer_pincode"],
    			"tw_reg_no" => strtoupper($tw_reg_no),
    			"tw_engine_no" => strtoupper($proposal_params["engine_no"]),
    			"tw_chassis_no" => strtoupper($proposal_params["chassis_no"]),
    			"color" => strtoupper($proposal_params["tw_color"]),
    			"pre_insurer_code" => strtoupper($proposal_params["pre_insurer"]),
    			"pre_policy_number" => strtoupper($proposal_params["pre_policyno"]),
    			"od_premium" => 0,
    			"tp_premium" => $proposal_params["basic_tp_premium"],
    			"addon_premium" => $addon_premium,
    			"gross_total_premium" => $gross_total_premium,
    			"total_tax" => $proposal_params["total_gst"],
    			"final_premium" => $proposal_params["final_premium"]
    	);
    	return $retdata;
    }
    
} // end of class
