<?php
namespace App\Be\TW;

use App\Libraries\InstaLib;
use App\Models\TW\TwUsrData;
use App\Models\TW\data\QuoteReqData;


class UiicBe {
	
		public function pre_quote_check(QuoteReqData $quote_req_data){
		$ret_status = true;
		$rto_state = $quote_req_data->get_rto_code();
		$state_code = substr($rto_state,0,2);
		if($state_code != 'KA')
			$ret_status = false;
		return $ret_status;
	}

	public function post_quote_check($quote_resp_data){
		$ret_status = true;
		return $ret_status;
	}

	
	
	public function validate_proposal_submit ($usr_data) {
	
		$usr_db = new TwUsrData(); 
		$insta_lib = new InstaLib();
		$err_txt = "";
		if (!preg_match("/^[0-9]{10}$/", $usr_data->proposer_mobile)) { 	$err_txt .= "Valid mobile number required.\n";	}
	//	if (!preg_match("/^[a-zA-Z]{3,18}[ ][a-zA-Z]{1,18}$/", $usr_data->proposer_name)) { 	$err_txt .= "Valid first name, last name required.\n";	}
               if (!preg_match("/^(([a-zA-Z]{0,14}).(\\s[a-zA-Z]{3,14}){1,2})|([a-zA-Z]{2,14}).(\\s[a-zA-Z]{0,14}){1,2}$/", $usr_data->proposer_name)) { 	$err_txt .= "Valid first name, last name required.\n";	}
		if (!preg_match("/^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$/", $usr_data->proposer_dob)) { 	$err_txt .= "Valid DOB required.\n";	}
		if (!preg_match("/^[0-9]{4}[-][0-9]{4}[-][0-9]{4}$/", $usr_data->proposer_aadharno)) { 	$err_txt .= "Valid aadhar number required.\n";	}
		if (!preg_match("/^[0-9a-zA-Z@.]{8,50}$/", $usr_data->proposer_email)) { 	$err_txt .= "Valid email required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/]{2,15}$/", $usr_data->proposer_addr1)) { 	$err_txt .= "Valid house address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->proposer_addr2)) { 	$err_txt .= "Valid street address required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 ]{5,40}$/", $usr_data->proposer_addr3)) { 	$err_txt .= "Valid locality address required.\n";	}
		if (!preg_match("/^[0-9]{6}$/", $usr_data->proposer_pincode)) { 	$err_txt .= "Valid pincode required.\n";	}
		if (!preg_match("/^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$/", $usr_data->tw_reg_no)) { 	$err_txt .= "Reg. number format is wrong.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{8,30}$/", $usr_data->tw_engine_no)) { 	$err_txt .= "Valid engine no. required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9]{10,40}$/", $usr_data->tw_chassis_no)) { 	$err_txt .= "Valid chassis no. required.\n";	}
		if (!preg_match("/^[a-zA-Z ]{3,15}$/", $usr_data->color)) { 	$err_txt .= "Valid color required.\n";	}
		if (!preg_match("/^[a-zA-Z0-9 \/-]{8,30}$/", $usr_data->pre_policy_number)) { 	$err_txt .= "Valid pre. policy number required.\n";	}
		if (!preg_match("/^[a-zA-Z ]{4,30}$/", $usr_data->nomi_name)) { 	$err_txt .= "Valid nominee name required.\n";	}
		
		$ret_data = array("verror" => false, "verror_txt" => $err_txt );
		
		if(strlen( $err_txt) != 0) {
			$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
			$proposal_status['proposal_status'] = 'TS01';
			$proposal_status['trans_status'] = 'TS01';
			$usr_db->set_by_tc($usr_data->trans_code, $proposal_status);
			$ret_data["verror"] = true;
		} else {
			$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
			$proposal_status['proposal_status'] =  'TS15';
			$proposal_status['trans_status'] =  'TS15';
			$usr_db->set_by_tc($usr_data->trans_code, $proposal_status);
		}
		
		return $ret_data; 
	} // end 
	
	
} // end of class
