<?php 
namespace App\Be\Travel;
use App\Libraries\TravelLib;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelConfig;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelHdfcRate;
use App\Models\Travel\TravelReligareRate;
use App\Models\Travel\TravelCity;
use App\Models\Travel\TravelRelationship;
use App\Models\Travel\TravelState;
use App\Models\Travel\TravelPed;
use App\Models\Travel\TravelAddon;
use App\Models\Travel\TravelNomineeRelationship;
use App\Models\Travel\TravelPolicy;
use App\Constants\Travel_Constants;
use App\Be\Travel\TravelProposalBe;
use Illuminate\Support\Facades\Storage;
use App\Constants\Common_Constants;
use App\Be\Common\PaymentParseBE;
use Log;

class ReligareBe{

	private $policy_type_flag, $lib, $set;

  	public function __construct(){
    	date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE); 
    	$this->policy_type_flag = 0; // For Policy Checking
    	$this->lib = new TravelLib;
  	}

  	public function calculate_indv_policy($input){
        $trans_code = $input['trans_code'];
        $age      = $this->check_age($input, 'INDV_SING');
        $age      = ($age == 0) ? 10 : $age;
      
        $plan     = $this->get_plancode($age,$input,'INDV_SING');
        
        $response = array();
        if($plan == null){
          return null;
        } else {
          if(sizeof($plan) == 1){
            $premium = $this->get_premium($age, $plan[0], 'INDV_SING', $input);
            if($premium == null)
              return null;
            $response[] = $this->set_quotes($plan[0], $premium, $age, $input['sum-insured'],$trans_code);
            return $response;
          }else {
            for($i=0; $i<sizeof($plan); $i++){
              $premium = $this->get_premium($age, $plan[$i], 'INDV_SING', $input);
              if($premium == null)
                return null;
              $response[] = $this->set_quotes($plan[$i], $premium, $age, $input['sum-insured'],$trans_code);
            }
            return $response;
          }  
        }
    }

    public function calculate_floater_policy($request){
        $input        = $request; 
        $actual_input = $input;  
        $cum_response = array();
        $discount     = 1;
        $senior_flag  = false;
        // Setting Discounts
        switch($actual_input['travelcount']){
          case 1 : $discount = 1;
                   break;
          case 2 : $discount = 0.05;
                   break;
          case 3 : $discount = 0.1;
                   break;
          case 4 : $discount = 0.15;
                   break;
          case 5 : $discount = 0.175;
                   break;
          case 6 : $discount = 0.2;
                   break;                                    
        }

        for($i=0; $i<$actual_input['travelcount']; $i++){
          if($i == 0){
            $cum_response[$i] = $this->calculate_indv_policy($input, 'INDV_SING');
          }else {
            $input['dob'][0]  = $actual_input['dob'][$i];
            $cum_response[$i] = $this->calculate_indv_policy($input, 'FLT');
          }
        }


        for($i=0; $i<$actual_input['travelcount']; $i++){
          $age = $this->lib->calculateAge($actual_input['dob'][$i]);
         
          if($age > 62){
            $senior_flag = true;
          }
        }


          for($i=0; $i<$actual_input['travelcount']; $i++){
            for($j=0; $j<sizeof($cum_response[0]); $j++){
              $premium[$i][$j] = (int)$cum_response[$i][$j]['NetPremiumAmt'] - (int)$cum_response[$i][$j]['TotalTaxAmt'];
              if($senior_flag == TRUE && $cum_response[$i][$j]['PlanCode'] === '40001012'){
                $cum_response[$i][$j]['shortDescription'] = Travel_Constants::$RELIGARE_SQ_WITH_OUT_SUBLIMIT_TITLE;
              }elseif($cum_response[$i][$j]['PlanCode'] === '40001015')
                $cum_response[$i][$j]['shortDescription'] = '';
              elseif($senior_flag == TRUE)  
                $cum_response[$i][$j]['shortDescription'] = Travel_Constants::$RELIGARE_SQ_WITH_SUBLIMIT_TITLE;
              else 
                $cum_response[$i][$j]['shortDescription'] = '';
            }
          } 
          $net_premium   = array();
          $total_premium = 0;
          $insurer       = '';

          for($i=0; $i<sizeof($cum_response[0]); $i++){
            $carry_premium = 0;
            $total_premium = 0;
            $insurer      = '';
            for($j=0; $j<$actual_input['travelcount']; $j++){
              $total_premium += $premium[$j][$i];
            }
            // Applying Discount
            $total_premium   = round($total_premium - ($total_premium * $discount));
            $tax[$i]         = round($total_premium * Travel_Constants::$GST_CMN); 
            // Net Premium
            $net_premium[$i] = round($total_premium + $tax[$i]);
            // Setting Updated Premium & Tax in response
            $cum_response[0][$i]['NetPremiumAmt'] = $net_premium[$i];
            $cum_response[0][$i]['TotalTaxAmt']   = $tax[$i];
            // Setting Insured
            $indv_premium = $total_premium / $actual_input['travelcount'];
            for($k=0; $k<$actual_input['travelcount']; $k++){
              $insurer .= $indv_premium.',';
            }
            $insurer = rtrim($insurer,',');
            $cum_response[0][$i]['insurer'] = $insurer;
            
          }
          return $cum_response[0];
    }

    public function calculate_amt_policy($input){
        $age     = $this->check_age($input, 'AMT');
        $plan    = ($age != false)? $this->get_plancode($age,$input,'AMT') : null;
        $response = array();
        if($plan == null){
          return null;
        } else {
          if(sizeof($plan) == 1){
            $premium = $this->get_premium($age, $plan[0], 'AMT', $input);
            if($premium == null)
              return null;
            $response[] = $this->set_quotes($plan[0], $premium, $age, $input['sum-insured']);
            return $response;
          }else {
            for($i=0; $i<sizeof($plan); $i++){
              $premium = $this->get_premium($age, $plan[$i], 'AMT', $input);
              if($premium == null)
                return null;
              $response[] = $this->set_quotes($plan[$i], $premium, $age, $input['sum-insured']);
            }
            return $response;
          }  
        }

    }

    public function calculate_student_policy($input){
        $age      = $this->check_age($input, 'ST');
        $plan     = ($age != false)? $this->get_plancode($age,$input,'ST') : null;
        $response = array();
        if($plan == null){
          return null;
        } else {
          if(sizeof($plan) == 1){
            $premium = $this->get_premium($age, $plan[0], 'ST', $input); 
            if($premium == null){
              return null;
            }
            $response[] = $this->set_quotes($plan[0], $premium, $age, $input['sum-insured']);
            return $response;
          }else {
            for($i=0; $i<sizeof($plan); $i++){
              $premium = $this->get_premium($age, $plan[$i], 'ST', $input);
              if($premium != null){
                $response[] = $this->set_quotes($plan[$i], $premium, $age, $input['sum-insured']);
              }
            }
            foreach($response as $index => $data){
                $data['insurer'] = $data['NetPremiumAmt'];
                $this->save_quote($data);
            }
            return $response;
          }  
        }

    }

    private function get_premium($age, $plan, $type, $input) {
  	  $result = $this->check_rate($plan['code'], $type, $input['sum-insured']);
      $looper = false;
      if($type === 'INDV_SING'){
        if($result){
          foreach($result as $item) { 
            if($age >= $item['rate_min_age'] && $age <= $item['rate_max_age']) {
                if($input['duration'] == $item['rate_term']) {
                  $looper = true;
                  $item['rate_base_premium'] = $item['rate_base_premium'] + $item['rate_base_premium'] * 0.050;
                  return $item['rate_base_premium'];
                } // End Duration check 
            } // End Age check
          }// End foreach
        }
        return ($looper == false) ? null : '' ;
      } // End type check

      if($type === 'AMT'){
        if($result){
          foreach($result as $item) { 
            $duration = $this->map_duration($input['amt-duration']);
            if($age >= $item['rate_min_age'] && $age <= $item['rate_max_age']) {
                if($duration == $item['rate_term']) {
                  $looper = true;
                  $item['rate_base_premium'] = $item['rate_base_premium'] + $item['rate_base_premium'] * 0.050;
                  return $item['rate_base_premium'] ;
                } // End Duration check 
            } // End Age check
          }// End foreach
        }
        return ($looper == false) ? null : '' ;
      } // End type check
      if($type === 'ST'){
        $lib      = new TravelLib;
        $duration = $this->lib->map_student_duration($input['std-duration']);
        $duration = ($duration == 364) ? '365' : $duration;
        if($result){
          foreach($result as $item) { 
            if($age >= $item['rate_min_age'] && $age <= $item['rate_max_age']) {
                if(($duration) == $item['rate_term']) {
                  $looper = true;
                  return $item['rate_base_premium'] ;
                } // End Duration check 
            } // End Age check
          }// End foreach
        }
        return ($looper == false) ? null : '' ;
      } // End type check
  	}

  	private function check_rate($plan, $type, $si){
  	  $rate_tbl = new TravelReligareRate;
      if($type === 'AMT'){
      	$column  = array('rate_min_age', 
                 'rate_max_age', 
                 'rate_term',
                 'rate_base_premium');
        $check_values = array('rate_plan_id' => $plan,
    					'rate_trip_type' => 'Multi',
    					'rate_si' => $si);
        return $rate_tbl->get_data($column, $check_values);
      }else if($type === 'INDV_SING'){
      	$column  = array('rate_min_age', 
                 'rate_max_age', 
                 'rate_term',
                 'rate_base_premium');
        $check_values = array('rate_plan_id' => $plan,
    					'rate_trip_type' => 'Single',
    					'rate_si' => $si);
        return $rate_tbl->get_data($column, $check_values);
      }else if($type === 'ST'){
      	$column  = array('rate_min_age', 
                 'rate_max_age', 
                 'rate_term',
                 'rate_base_premium',
                 'rate_si');
        $check_values = array('rate_plan_id' => $plan,
    					'rate_trip_type' => 'ST', 'rate_si' => $si);
        return $rate_tbl->get_data($column, $check_values);
      } 
    }

    private function get_service_tax($premium){
    	return round($premium * Travel_Constants::$GST_CMN);
    }

    private  function set_quotes($plan, $premium, $age, $si,$trans_code){
        $TotalTaxAmt   = $this->get_service_tax($premium);
        $NetPremiumAmt = round($premium + $TotalTaxAmt);
        $un_key        = uniqid();
        $breakup_t     = array();
        $response['company_name']       = 'Religare';
        $response['url_code']           = 'religare';
        $response['ProductDescription'] = 'Religare';
        $response['session_key']        = $trans_code;
        $response['trans_code']         = $trans_code;
        $response['shortDescription']   = $this->set_description($plan, $age);
        $response['NetPremiumAmt']      = $NetPremiumAmt ;
        $response['TotalTaxAmt']        = $TotalTaxAmt;
        $response['PlanCode']           = $plan['code'];
        $response['PlanDesc']           = $plan['name'];
        $response['companyId']          = $this->lib->get_company_code('religare');
        $response['logo']               = 'image/logos/'.$response['companyId'].'_logo.png';
        $response['productCode']        = ''; 
        $response['destinationCode']    = '';
        $response['sum-insured']        = $si;
        $response['policyId']           = $un_key;
        $sv_quote                 = $response;
        $sv_quote['insurer']      = $premium;
        $sv_quote['addon_id']     = null;
        $sv_quote['addon_value']  = null;
        return $response;
    }
    
    private function set_description($plan, $age){ 
        if($plan['code'] === '40001012' && $age > 61 )
            return Travel_Constants::$RELIGARE_SQ_WITH_OUT_SUBLIMIT_TITLE;
        elseif($plan['code'] === '40001015')
            return '';
        elseif($age > 61)
            return Travel_Constants::$RELIGARE_SQ_WITH_SUBLIMIT_TITLE;
        else
            return '';
    }

    private function map_duration($duration){
      switch($duration){
        case 'SM' : return 30;
                    break;
        case 'ME' : return 45;
                    break;
        case 'LA' : return 60;
                    break;            
        default   : return 180;                        
      }
    }

    private function get_plancode($age,$input,$type){ 
	    $res  = $this->get_plan_details($input,$type);
	    $plan = array();
	    // SINGLE TRIP INDIVIDUAL
	    if($type === 'INDV_SING' || $type === 'AMT' || $type === 'ST'){
	      if($res){
	        foreach($res as $index=>$item) { 
	          $plan[$index]['name'] = $item['plan_name'];
	          $plan[$index]['code'] = $item['plan_code'];
	        }
	        return $plan;
	      } else {
	        return null;
	      }  
	    }
    } 

    private function get_plan_details($input, $type){
	    $plan_tbl = new TravelPlan;
	    $column   = array(Travel_Constants::TRAVEL_PLAN['CODE'],
	               Travel_Constants::TRAVEL_PLAN['NAME']); 
	    $check_values = array(Travel_Constants::TRAVEL_PLAN['TRIP_TYPE'] =>'S',
	                    Travel_Constants::TRAVEL_PLAN['DESTINATION'] => $input['area'],
	                    Travel_Constants::TRAVEL_PLAN['COMPANY'] => 'religare');
	    if($type == 'AMT'){
	      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'MT';
	      return $plan_tbl->get_data($column, $check_values); 
	    }elseif($type == 'INDV_SING'){
	      return $plan_tbl->get_data($column, $check_values);
	    }elseif($type == 'FLT'){
	      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'STF';
	      return $plan_tbl->get_data($column, $check_values); 
	    }elseif($type == 'ST'){
	      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'ST';
	      return $plan_tbl->get_data($column, $check_values); 
	    }
    }

    private function check_age($input, $type){
        $age = $this->lib->calculateAge($input['dob'][0]);
        if($type === 'INDV_SING'){
          if($age >=18 && $age < 100){
              return $age;  
          } else {
              return false;
          }
        }
        if($type === 'AMT'){
          if($age >= 18 && $age < 71){
              return $age;  
          } else {
              return false;
          }
        }
        if($type === 'FLT'){
          if($age >= 0 && $age < 100){
            if($age == 0)
              return 1;
            else
              return $age;  
          } else {
              return false;
          }
        }

        if($type === 'ST'){
          if($age >= 12 && $age < 41){
              return $age;
          } else {
              return false;
          }
        }
    }

  	public function check_si($type, $si){
	    if($type == 'S'){
        $si_list = array('25000', '30000','50000','100000','200000','300000','500000');
        if(in_array($si,$si_list)){
            return true;
        } else {
          return false;
        }

	    } 
	    if($type == 'M'){
        $si_list = array('50000','100000','300000','500000');
        if(in_array($si,$si_list)){
            return true;
        } else {
          return false;
        }
	    } 

	    if($type == 'ST'){
        $si_list = array('30000', '50000','100000','300000','500000','1000000');
        if(in_array($si,$si_list)){
            return true;
        } else {
          return false;
        }
	    } 
  	}

    public function get_proposal_inputs($trans_code){
        $company_column = 'religare_code';
        $bl = new TravelProposalBe;
        $data = $bl->get_proposal_inputs($trans_code, $company_column);
        
        // Setting Trip Start Date 
        $data['userdata']['trip_start_date'] = $this->get_trip_start_date($data['userdata']['trip_start_date'], $data['userdata']['triptype']);

        // Setting Trip End Date 
        $data['userdata']['trip_end_date'] = $this->get_trip_end_date($data['userdata']);

        if($data['userdata']['triptype'] == 'ST'){
          $data['en_academic_tab'] = true;
          $age = $data['userdata']['age_list'][0];
          $age = rtrim($age, 'Y');
          if($age<18){
            $data['en_guardian'] = true;
          }
          if($data['basic_info']['plan_code'] != '40001023'){
            $data['en_add_on'] = true;
          }
        }  

        // Setting Sponser DOB
        $data['sponser_dob'] = $this->get_sponser_dob();
        // Setting Guardian Relationship
        $data['sponser_relationship'] = $this->get_sponser_relationship();
        return $data;
    }

    private function get_trip_end_date($userdata){
        $lib = new TravelLib;
        if($userdata['triptype'] == 'M'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], '364');
        }

        if($userdata['triptype'] == 'S'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $userdata['duration'] - 1);
        }

        if($userdata['triptype'] == 'ST'){
          $duration = $lib->map_student_duration($userdata['std_duration']);
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $duration - 1);
        }

        
    } 

    private function get_trip_start_date($date, $trip_type){
        $lib = new TravelLib;
        $result = array();
        $duration = 179;
        $result['selected_date'] = ($date) ? $date : date("d-m-Y");
        $result['min_date']      = date("d-m-Y");
        $result['max_date']      = $lib->add_days_with_date(date("d-m-Y"), $duration);
        return $result;
    } 

    private function get_sponser_dob(){
        $lib = new TravelLib;
        $result = array();
        $result['selected_date'] = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['max_date']      = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['min_date']      = $lib->minus_year_from_date(date("d-m-Y"), '99');
        return $result;
    }

    private function get_sponser_relationship(){ 
        return array(  0 => array ('relationship_code' => 'FATH', 
                                   'relationship_name' => 'FATHER'),
                       1 => array ('relationship_code' => 'MOTH', 
                                   'relationship_name' => 'MOTHER'),
                       2 => array ('relationship_code' => 'BOTH', 
                                   'relationship_name' => 'BROTHER'),
                       3 => array ('relationship_code' => 'COUS', 
                                   'relationship_name' => 'COUSIN'),
                       4 => array ('relationship_code' => 'GFAT', 
                                   'relationship_name' => 'GRAND FATHER'),
                       5 => array ('relationship_code' => 'GMOT', 
                                   'relationship_name' => 'GRAND MOTHER'),
                       6 => array ('relationship_code' => 'MANT', 
                                   'relationship_name' => 'AUNTIE'),
                       7 => array ('relationship_code' => 'MUNC', 
                                   'relationship_name' => 'UNCLE'),
                       8 => array ('relationship_code' => 'NEPH', 
                                   'relationship_name' => 'NEPHEW'));
    } 

    public function set_proposal_data($data){
        $trans_code  = $data['trans_code'];
        $section     = $data['id'];
        $usr_tbl     = new TravelUsrData;
        $check_value = array('trans_code' => $trans_code);
        // Unsetting the extra values
        unset($data['trans_code']);
        unset($data['id']);
        unset($data['_token']);
        if($section == 'travel'){
            $data['name'] = implode(',',$data['name']);
            $data['dob']  = implode(',',$data['dob']);
            $data['passport']  = implode(',',$data['passport']);
            if(isset($data['add_on'])){
              $data['add_on'] = json_encode($data['add_on']);
            }
        }
        if($section == 'medical_his'){
            if(isset($data['ped_choice'])){
                $ped['ped_choice'] = $data['ped_choice'];
                $ped['ped_details'] = (isset($data['ped_details'])) ? $data['ped_details'] : '' ;
                $ped['sub_ped'] = (isset($data['sub_ped'])) ? $data['sub_ped'] : '' ;
                $ped['ped_member_choice'] = (isset($data['ped_member_choice'])) ? $data['ped_member_choice'] : '' ;
                $data = array();
                $data['ped'] = json_encode($ped);
            }else{
                $data['ped'] = null;
            }        
        }
        $usr_tbl->set_data($data, $check_value);
       
    }

    private function generate_xml($array, $tag = null){
        $xml = ($tag) ? '<'.$tag.'>' : '';
        foreach($array as $attribute => $value){
            $xml .=  '<'.$attribute.'>'.$value.'</'.$attribute.'>';
        }
        $xml .= ($tag) ? '</'.$tag.'>': '';
        return $xml;
    }

    private function format_date($date){
        $date = \DateTime::createFromFormat('d-m-Y', $date);
        return $date->format('d/m/Y');
    }

    private function get_name_details($name){
      $name = explode(',', $name);
      $member_list = array();
      foreach ($name as $key => $value) {
        $member_name = explode(' ', $value);
        if(sizeof($member_name) == 2){
          $member_list[$key]['fname'] =  strtoupper($member_name[0]);
          $member_list[$key]['mname'] = '';
          $member_list[$key]['lname'] =  strtoupper($member_name[1]);
        }

        if(sizeof($member_name) >= 3){
            $member_list[$key]['fname'] = strtoupper($member_name[0]);
            $member_list[$key]['mname'] = strtoupper($member_name[1]);
            $member_list[$key]['lname'] = strtoupper($member_name[2]);
        }
      }
      return $member_list;
    }

    private function get_end_date($date,$days){
      $date = strtotime("+".$days." days", strtotime($date));
      return date("d/m/Y", $date);
    }

    private function get_gender($title){
      $gender_list = array();
      foreach ($title as $key => $value) {
        if($value == 'Mrs' || $value == 'Ms'){
          $gender_list[$key] = 'FEMALE';
        }else{
          $gender_list[$key] = 'MALE';
        }
      }
      return $gender_list ;
    }

    public function set_proposal($trans_code){
      $usr_tbl      = new TravelUsrData;
      $config_tbl   = new TravelConfig;
      $state_tbl    = new TravelState;
      $city_tbl     = new TravelCity;
      $plan_tbl     = new TravelPlan;
      $addon_tbl    = new TravelAddon;
      $proposal_be  = new TravelProposalBe;
      $userdata     = $usr_tbl->get_all_data($trans_code);
      $config       = $config_tbl->get_data('config_key', 'religare');

      $start_date   = $this->format_date($userdata['trip_start_date']);

      $end_date     = ($userdata['triptype'] == 'M') ? 
                                  $this->get_end_date($userdata['trip_start_date'], '364') : 
                                  $this->format_date($userdata['trip_end_date']);

      $name       = $this->get_name_details($userdata['name']);
      $dob        = explode(',', $userdata['dob']);
      $title      = explode(',', $userdata['title']);
      $passport   = explode(',', $userdata['passport']);
      $relationship =  explode(',', $userdata['relationship']); 
      $guardian_dob = '';
      $age_list   = explode(',', $userdata['age_list']);
      $ped        = json_decode($userdata['ped'],true);
      $gender     = $this->get_gender($title);
      $student_data['sponser_name'] = $userdata['sponser_name'];
      $student_data['sponser_dob'] = $userdata['sponser_dob'];
      $student_data['sponser_relationship'] = $userdata['sponser_relationship'];
      $student_data['university_name'] = $userdata['university_name'];
      $student_data['program_name'] = $userdata['program_name'];
      $student_data['program_duration'] = $userdata['program_duration'];
      $student_data['university_address'] = $userdata['university_address'];
      $student_data['university_country'] = $userdata['university_country'];
      $student_data['university_state'] = $userdata['university_state'];
      $student_data['university_city'] = $userdata['university_city'];
      $student_data['guardian_relationship'] = $userdata['guardian_relationship'];
      $student_data['triptype']    = $userdata['triptype'];
      $student_data['en_guardian'] = false;
      $state_code = '';
      $city_code  = '';
      try{
      $check_values = array('state_code' => $userdata['state']);  
      $state = $state_tbl->get_data($userdata['company_column'], $check_values);
      $state_code = strtoupper($state[0][$userdata['company_column']]); 
      }catch(\Exception $e){

      }

      try{
      $check_values = array('city_name' => $userdata['city'], 'state_code' => $userdata['state']);  
      $city = $city_tbl->get_data($userdata['company_column'], $check_values);
      $city_code = strtoupper($city[0][$userdata['company_column']]); 
      }catch(\Exception $e){

      }
      
      //General info
      $data = array();
      if($userdata['triptype'] == 'ST'){
        $age = $age_list[0];
        $age = rtrim($age, 'Y');
        if($age<18){
          $student_data['en_guardian'] = true;
        } 
        $add_on = json_decode($userdata['add_on'], true);
        $add_on_array = array();
        if($add_on){
          foreach($add_on as $code => $status){
            if($status == 'Y'){
              try{
                $column  = array('religare_code');
                $check_values = array('add_on_code' =>$code);
                $add_on_response = $addon_tbl->get_value($column, $check_values);
                $add_on_array[] = $add_on_response[0]['religare_code'];
              }catch(\Exception $e){
              }
            }
          }
        }
      }

      if(!empty($add_on_array)){
        $data['addOns'] = implode(',',$add_on_array);
      }
      $data['businessTypeCd'] = 'NEWBUSINESS';
      $data['baseProductId'] = $userdata['plan_code'];
      $data['baseAgentId'] = Travel_Constants::$RELIGARE_AGENT_ID;
      $data['coverType'] = 'INDIVIDUAL';
      $general_info_xml = $this->generate_xml($data);
      
      //Personal info
      if($student_data['en_guardian']){
        $guardian_name = $this->get_name_details($userdata['guardian_name']);
        $data = array();
        $data['birthDt'] = $this->format_date($userdata['guardian_dob']);
        $data['firstName'] = $guardian_name[0]['fname'];
        $data['genderCd'] = $this->get_guardian_gender($userdata['guardian_relationship']);
        $data['guid'] = uniqid();
        $data['lastName'] =  $guardian_name[0]['lname'];
        $personal_info_xml = $this->generate_xml($data);
      }else{
        $data = array();
        $data['birthDt'] = $this->format_date($dob[0]);
        $data['firstName'] = $name[0]['fname'];
        $data['genderCd'] = $gender[0];
        $data['guid'] = uniqid();
        $data['lastName'] =  $name[0]['lname'];
        $personal_info_xml = $this->generate_xml($data);
      }
      

      //Address info permanent
      $data = array();
      $data['addressLine1Lang1'] = strtoupper($userdata['house_name']);
      $data['addressLine2Lang1'] = strtoupper($userdata['street']);
      $data['addressTypeCd'] = 'PERMANENT';
      $data['areaCd'] = $city_code;
      $data['cityCd'] = $city_code;
      $data['pinCode'] = $userdata['pincode'];
      $data['stateCd'] = $state_code;
      $data['countryCd'] = 'IND';
      $address_info_permanent_xml = $this->generate_xml($data,'partyAddressDOList');

      //Address info communication
      $data['addressTypeCd'] = 'COMMUNICATION';
      $address_info_communication_xml = $this->generate_xml($data,'partyAddressDOList');

      //Contact info
      $data = array();
      $data['contactNum'] = $userdata['mobile'];
      $data['contactTypeCd'] = 'MOBILE';
      $data['stdCode'] = '+91';
      $contact_info_xml = $this->generate_xml($data,'partyContactDOList');

      //Email info
      $data = array();
      $data['emailAddress'] = strtoupper($userdata['email']);
      $data['emailTypeCd'] = 'PERSONAL';
      $email_info_xml = $this->generate_xml($data,'partyEmailDOList');

      //Passport info
      $data = array();
      $data['identityNum'] = ($student_data['en_guardian']) ? strtoupper($userdata['guardian_passport']) : strtoupper($passport[0]);
      $data['identityTypeCd'] = 'PASSPORT';
      $passport_info_xml = $this->generate_xml($data,'partyIdentityDOList');

      //Client info
      $data = array();
      $data['relationCd'] = 'SELF';
      $data['roleCd'] = 'PROPOSER';
      $data['titleCd'] = strtoupper($title[0]);
      $client_info_xml = $this->generate_xml($data);

      $data = array();
      $data['partyDOList'] = $personal_info_xml.$address_info_permanent_xml.$address_info_communication_xml.$contact_info_xml.$email_info_xml.$passport_info_xml.$client_info_xml;
      $party_do_list_xml = $this->generate_xml($data);
      $party_do_list_xml .= $this->get_insured_details($name ,$gender, 
                                                  $passport, $dob, 
                                                  $title,
                                                  $relationship,
                                                  $address_info_permanent_xml,
                                                  $address_info_communication_xml,
                                                  $contact_info_xml,
                                                  $email_info_xml,
                                                  $ped,
                                                  $student_data
                                                ); 

      //Additional info
      $data = array();
      $data['fieldAgree'] = 'YES';
      if($student_data['en_guardian']){
        $data['field10'] = strtoupper($userdata['guardian_name']);
        $data['field12'] = strtoupper($userdata['guardian_relationship']);
      }else{
        $data['field10'] = strtoupper($userdata['nomineename']);
        $data['field12'] = strtoupper($userdata['nomineerel']);
      }
      $data['fieldAlerts'] = 'YES';
      $data['fieldTc'] = 'YES';
      $data['field20'] = ($userdata['triptype'] == 'S') ? $userdata['duration'] : '365';
      $data['tripStart'] = 'YES';
      if($userdata['triptype'] == 'ST'){
        $data['sponsorName'] = strtoupper($userdata['sponser_name']);
        $data['field8'] = strtoupper($userdata['university_name']);
        $data['universityAddress'] = strtoupper($userdata['university_address']).','.strtoupper($userdata['university_state']).','.strtoupper($userdata['university_city']).','.strtoupper($userdata['university_country']);
        $data['courseDetails'] = strtoupper($userdata['program_name']).','.strtoupper($userdata['program_duration']);
        $data['relationshipToStudent'] = strtoupper($userdata['sponser_relationship']);
        $data['sponsorDOB'] = $this->format_date($userdata['sponser_dob']);
        $data['guardianFirstName'] = '';
        $data['guardianLastName'] = '';

      }

      $additional_info_xml = $this->generate_xml($data,'policyAdditionalFieldsDOList');

      //Trip Info
      $data = array();
      $data['policyNum'] = '';
      $data['proposalNum'] = '';
      $data['quotationReferenceNum'] = '';
      $column = array('plan_si_code','plan_si');
      $check_values = array('plan_code' => $userdata['plan_code']);
      $response = $plan_tbl->get_data($column, $check_values);
      $plan_si_code = explode(',', $response[0]['plan_si_code']);
      $plan_si      = explode(',', $response[0]['plan_si']);
      $sum_insured_key = array_search($userdata['sum_insured'], $plan_si);
      $data['sumInsured'] = $plan_si_code[$sum_insured_key];
      $data['policyCommencementDt'] = $start_date;
      $data['policyMaturityDt'] = $end_date;
      if($userdata['triptype'] == 'M'){
         if($userdata['amt_duration'] == 'SM'){
             $data['maxTripPeriod'] = '30';
         }else if($userdata['amt_duration'] == 'ME'){
             $data['maxTripPeriod'] = '45';
         }else if($userdata['amt_duration'] == 'LA'){
             $data['maxTripPeriod'] = '60';
         }
      }elseif($userdata['triptype'] == 'ST'){
          if($userdata['std_duration'] == 'std_one'){
              $data['maxTripPeriod'] = 365;
          }else if($userdata['std_duration'] == 'std_two'){
              $data['maxTripPeriod'] = 730;
          }else{
              $data['maxTripPeriod'] = substr($userdata['std_duration'],4,strlen($userdata['std_duration']));
          }
          
      }else{
        $data['maxTripPeriod'] = '';
      }
      
      $data['term'] = ($userdata['triptype'] == 'ST' 
                       || $userdata['triptype'] == 'M') ? '' : '1';
      $data['travelGeographyCd'] = $userdata['plan_code']; 
      $data['tripTypeCd'] = ($userdata['triptype'] == 'S' 
                             || $userdata['triptype'] == 'ST') ? 'SINGLE' : 'MULTI';
      $data['uwDecisionCd'] = '';
      $data['isPremiumCalculation'] = 'YES';
      $trip_info_xml = $this->generate_xml($data);

      $data = array();
      $data['policy'] = $general_info_xml.$party_do_list_xml.$additional_info_xml.$trip_info_xml;

      $policy_info_xml = $this->generate_xml($data,'intIO');

      $request_xml = '<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:rel="http://relinterface.insurance.symbiosys.c2lbiz.com" xmlns:xsd="http://intf.insurance.symbiosys.c2lbiz.com/xsd">
   <soap:Header/>
   <soap:Body>
      <rel:createPolicyTravel>
      '.$policy_info_xml.'
      </rel:createPolicyTravel>
   </soap:Body>
</soap:Envelope>';

      return $request_xml;
    }

    private function get_insured_details($name,$gender,$passport,$dob,$title,$relationship,$address_info_permanent_xml,$address_info_communication_xml, $contact_info_xml, $email_info_xml,$ped,$student_data){

      $insured_details = '';

      foreach ($gender as $key => $value) {
       //Personal info
       $data = array();
       $data['birthDt'] = $this->format_date($dob[$key]);
       $data['firstName'] = $name[$key]['fname'];
       $data['genderCd'] = $gender[$key];
       $data['guid'] = uniqid();
       $data['lastName'] =  $name[$key]['lname'];
       $personal_info_xml = $this->generate_xml($data);

       //Passport info
       $data = array();
       $data['identityNum'] = strtoupper($passport[$key]);
       $data['identityTypeCd'] = 'PASSPORT';
       $passport_info_xml = $this->generate_xml($data,'partyIdentityDOList');
       //Client info
       $data = array();
       if($student_data['en_guardian']){
        $data['relationCd'] = $this->get_primary_relationship($student_data['guardian_relationship'], $gender[$key]);
       }else{
        $data['relationCd'] = $this->get_relationship_code($relationship[$key]);
       }
       
       $data['roleCd'] = 'PRIMARY';
       $data['titleCd'] = strtoupper($title[$key]);
       $client_info_xml = $this->generate_xml($data);

       //PED info
       if(isset($ped['ped_member_choice'][$key])){
         $data = array();
         $data['questionCd'] = 'pedYesNo';
         $data['questionSetCd'] = 'pedYesNoTravel';
         $data['response'] = 'YES';
         $ped_info_xml = $this->generate_xml($data,'partyQuestionDOList');
         if(isset($ped['sub_ped'][$key]['kidney'])){
            $data = array();
            $data['questionCd'] = '129';
            $data['questionSetCd'] = 'PEDkidneyDetailsTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['sub_ped'][$key]['cancer'])){
            $data = array();
            $data['questionCd'] = '114';
            $data['questionSetCd'] = 'PEDcancerDetailsTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['sub_ped'][$key]['coronary'])){
            $data = array();
            $data['questionCd'] = '143';
            $data['questionSetCd'] = 'PEDHealthDiseaseTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['sub_ped'][$key]['liver'])){
            $data = array();
            $data['questionCd'] = '128';
            $data['questionSetCd'] = 'PEDliverDetailsTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['sub_ped'][$key]['paralysis'])){
            $data = array();
            $data['questionCd'] = '164';
            $data['questionSetCd'] = 'PEDparalysisDetailsTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['sub_ped'][$key]['sub_ped_other'])){
            $data = array();
            $data['questionCd'] = '210';
            $data['questionSetCd'] = 'PEDotherDetailsTravel';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
            $data = array();
            $data['questionCd'] = 'otherDiseasesDescription';
            $data['questionSetCd'] = 'PEDotherDetailsTravel';
            $data['response'] = $ped['ped_details']['medical_history'][$key];
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['ped_details']['previous_diag'][$key])){
            $data = array();
            $data['questionCd'] = 'T001';
            $data['questionSetCd'] = 'HEDTravelHospitalized';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
            $data = array();
            $data['questionCd'] = 'PRVD';
            $data['questionSetCd'] = 'TRVLDET';
            $data['response'] = $ped['ped_details']['previous_diag'][$key];
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }
         if(isset($ped['ped_details']['previous_claim'][$key])){
            $data = array();
            $data['questionCd'] = 'T002';
            $data['questionSetCd'] = 'HEDTravelClaimPolicy';
            $data['response'] = 'YES';
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
            $data = array();
            $data['questionCd'] = 'PRDDET1';
            $data['questionSetCd'] = 'TRVLDET2';
            $data['response'] = $ped['ped_details']['previous_claim'][$key];
            $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
         }

       }else{
         // NO PED CASE
         $data = array();
         $data['questionCd'] = '';
         $data['questionSetCd'] = '';
         $data['response'] = '';
         $ped_info_xml = $this->generate_xml($data,'partyQuestionDOList');
       }

       if($student_data['triptype'] == 'ST'){
         $data = array();
         $data['questionCd'] = 'dateofBirth';
         $data['questionSetCd'] = 'SPDsponsorDetails';
         $data['response'] = $this->format_date($student_data['sponser_dob']);
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');

         $data = array();
         $data['questionCd'] = 'sponsorsName';
         $data['questionSetCd'] = 'SPDsponsorDetails';
         $data['response'] = strtoupper($student_data['sponser_name']);
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');

         $data = array();
         $data['questionCd'] = 'relationwithInsured';
         $data['questionSetCd'] = 'SPDsponsorDetails';
         $data['response'] = strtoupper($student_data['sponser_relationship']);
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');

         $data = array();
         $data['questionCd'] = 'InstName';
         $data['questionSetCd'] = 'STLEAFFIVE';
         $data['response'] = strtoupper($student_data['university_name']);
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');

         $data = array();
         $data['questionCd'] = 'CourseDetail';
         $data['questionSetCd'] = 'STLEAFSIX';
         $data['response'] = strtoupper($student_data['program_name']).','.strtoupper($student_data['program_duration']);
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');

         $data = array();
         $data['questionCd'] = 'InstAdd';
         $data['questionSetCd'] = 'STLEAFSEVEN';
         $data['response'] = strtoupper($student_data['university_address']).','.strtoupper($student_data['university_state']).','.strtoupper($student_data['university_city'].','.strtoupper($student_data['university_country']));
         $ped_info_xml .= $this->generate_xml($data,'partyQuestionDOList');
       }
 
       $data = array();
       $data['partyDOList'] = $personal_info_xml.$address_info_permanent_xml.$address_info_communication_xml.$contact_info_xml.$email_info_xml.$passport_info_xml.$ped_info_xml.$client_info_xml;
       $insured_details .= $this->generate_xml($data);

      }
      return $insured_details;

    }

    private function get_guardian_gender($relationship){
        switch($relationship){
            case 'FATH' : return 'MALE';
                          break;
            case 'MOTH' : return 'FEMALE';
                          break;
            case 'BOTH' : return 'MALE';
                          break;
            case 'COUS' : return 'MALE';
                          break;
            case 'FLAW' : return 'MALE';
                          break;
            case 'GFAT' : return 'MALE';
                          break;
            case 'GMOT' : return 'FEMALE';
                          break;
            case 'MANT' : return 'FEMALE';
                          break;
            case 'MDTR' : return 'MALE';
                          break;
            case 'MLAW' : return 'FEMALE';
                          break;
            case 'MMBR' : return 'FEMALE';
                          break;
            case 'MUNC' : return 'MALE';
                          break;
            case 'NEPH' : return 'MALE';
                          break;   
            default     : return 'Male';                                                                                 
        }
    }

    private function get_primary_relationship($relationship, $gender){

        if(($relationship === 'FATH' || $relationship === 'MOTH' ) && $gender === 'MALE'){
            return 'SONM';
        }

        if(($relationship === 'FATH' || $relationship === 'MOTH' ) && $gender === 'FEMALE'){
            return 'UDTR';
        }

        if($relationship === 'BOTH' && $gender === 'MALE'){
            return 'BOTH';
        }

        if($relationship === 'BOTH' && $gender === 'FEMALE'){
            return 'SIST';
        }

        if($relationship === 'COUS' && ($gender === 'MALE' || $gender === 'FEMALE')){
            return 'COUS';
        }

        if(($relationship === 'FLAW' || $relationship === 'MLAW' ) && $gender === 'MALE'){
            return 'SLAW';
        }

        if(($relationship === 'FLAW' || $relationship === 'MLAW' ) && $gender === 'FEMALE'){
            return 'DLAW';
        }

        if(($relationship === 'GFAT' || $relationship === 'GMOT' ) && $gender === 'MALE'){
            return 'GSON';
        }

        if(($relationship === 'GFAT' || $relationship === 'GMOT' ) && $gender === 'FEMALE'){
            return 'GDAU';
        }

        if(($relationship === 'MANT' || $relationship === 'MUNC' ) && ($gender === 'MALE' || $gender === 'FEMALE')){
            return 'NIEC';
        }

        if($relationship === 'MMBR' && $gender === 'MALE'){
            return 'MDTR';
        }

        if($relationship === 'MMBR' && $gender === 'FEMALE'){
            return 'MMBR';
        }

        if($relationship === 'MDTR' && $gender === 'MALE'){
            return 'MDTR';
        }

        if($relationship === 'NEPH' && ($gender === 'MALE' || $gender === 'FEMALE')){
            return 'NEPH';
        }
    }

    private function get_relationship_code($name){
      switch($name){
        case '1'     : return 'SELF';
                          break;
        case '5'     : return 'MOTH';
                          break;
        case '4'     : return 'FATH';
                          break;
        case '3'     : return 'SPSE';
                          break;
        case '2'     : return 'SPSE';
                          break;
        case '6'     : return 'SONM';
                          break;
        case '7'     : return 'UDTR';
                          break; 
                default : return 'SELF';              
      }
    }

    public function get_proposal_preview_data($response, $userdata){
      $nom_tbl = new TravelNomineeRelationship;
      if($userdata['triptype'] == 'ST'){
        $age = $userdata['age_list'][0];
        $age = rtrim($age, 'Y');
        if($age<18){
          $response['en_proposer_details'] = true;
          $response['traveller_info']['nominee_relation'] = null;
          $response['traveller_info']['nominee_name'] = null;
          try{
          $column       = array('relationship_name');
          $check_values = array($userdata['company_column'] => $userdata['guardian_relationship']);
          $tbl_response = $nom_tbl->get_value($column, $check_values);
          $response['traveller_info']['guardian_relationship'] = $tbl_response[0]['relationship_name'];
          }catch(\Exception $e){
          }
        } else {
          $response['en_proposer_details'] = false;
        }
        $response['traveller_info']['en_add_on'] = true;  
        $response['en_sponser_relation'] = true;
        $response['trip_info']['visiting_country'] = null;
      }
      return $response;
    } 

    public function parse_policy($xml,$trans_code = null){ 
      $payment_parse_be = new PaymentParseBE;
      if(strpos($xml, 'err-description') == false){
        $dom = new \DOMDocument;
        try{
          $dom->loadXML($xml);
        }catch (\Exception $e){
          return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        }
        $proposal_num = $dom->getElementsByTagName("proposal-num")->item(0)->nodeValue;
        if(!empty($proposal_num)){
          $lib          = new TravelLib;
          $usr_tbl      = new TravelUsrData;
          $columns      = array('premium','tax');
          $t_data       = TravelUsrData::get_data($columns,$trans_code);
          $passed_premium   = (int)$t_data['premium'];
          $response_premium = (int)$dom->getElementsByTagName("premium")->item(0)->nodeValue;
          $difference       = abs($response_premium - $passed_premium);

          $table['finalPremium'] = $response_premium;
          $table['finalTax']     = $lib->get_tax_premium($response_premium);
          $res =  $usr_tbl->update_data($table,$trans_code);
          $pg_request['proposalNum'] = $proposal_num;
          $pg_request['returnURL']   = url('/').Travel_Constants::$RELIGARE_RETURN_URL.'/'.$trans_code;
          $payment_parse_be->setPaymentIdentifier($trans_code,$trans_code);
          Log::info('TRAVEL_RELIGARE_PG_REQUEST '. print_r($pg_request,true));

          if($difference >=1){
            
            // Status updation
            $proposal_status['reference_number'] = $proposal_num;
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('premium_mismatch', $proposal_status); 
            // End Status updation

            LOG::INFO(Travel_Constants::$RELIGARE_PG_URL);
            return array('status' => 0, 'mismatch' => 1, 'error' => 0, 'actual_premium' =>$response_premium , 'passed_premium' => $passed_premium, 'request' => $pg_request, 'pg_url' => Travel_Constants::$RELIGARE_PG_URL);
          }else{

            // Status updation
            $proposal_status['reference_number'] = $proposal_num;
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('no_change_premium', $proposal_status); 
            // End Status updation

            return array('status' => 1, 'mismatch' => 0, 'error' => 0, 'premium' =>$response_premium , 'request' => $pg_request, 'pg_url' => Travel_Constants::$RELIGARE_PG_URL);
          }

        }else{

          // Status updation
          $proposal_status['response_msg'] = $xml;
          $proposal_be = new TravelProposalBe;
          $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
          // End Status updation

          return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        }
      }else{
        $message ='';
        $dom = new \DOMDocument;
        $dom->loadXML($xml);
        $error = $dom->getElementsByTagName("err-description")->item(0)->nodeValue;
        if(strpos($error, 'System encountered') !== false){
          Log::info('TRAVEL_RELIGARE_PROPOSAL_REQUEST parse_policy :- '.$trans_code.' - '. print_r($error,true));
          return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        } 
        $head_msg = 'Opps !. Please Correct the following errors <br>';
        $message  = $error;
        $message  = $head_msg.$message; 

        // Status updation
        $proposal_status['response_msg'] = $xml;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
        // End Status updation

        return array('status' => 0, 'mismatch' => 0, 'error' => 1, 'message' => $message);
      }
    }

    public function parse_pg_response($pg_response,$trans_code){
      $payment_parse_be = new PaymentParseBE;
      $trans_code = $payment_parse_be->getPaymentIdentifier($trans_code);
    $usr_tbl     = new TravelUsrData;
    $user_data   = $usr_tbl->get_all_data($trans_code);
    $proposal_be = new TravelProposalBe;
    if(!$user_data){ 
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }    
    $status = (isset($pg_response['uwDecision']) && $pg_response['uwDecision'] == "INFORCE") ? true : false;
    $policy_link = ($status) ? url('/').Travel_Constants::$RELIGARE_PDF_INTERNAL_URL.$pg_response['policyNumber'] : false;

    if($status){
      try{
      $columns = array('transaction_num' => $pg_response['transactionRefNum'], 
                       'policy_num' => $pg_response['policyNumber']);
      // Status updation
      $proposal_status['reference_number'] = $pg_response['transactionRefNum'];
      $proposal_status['response_msg'] = json_encode($pg_response); 
      $proposal_be->update_payment_status('payment_success',$proposal_status);
      //End Status updation

      // Status updation
      $proposal_be->update_payment_status('policy_accepted');
      //End Status updation

      $usr_tbl->update_data($columns, $trans_code);
      $user_data  = $usr_tbl->get_all_data($trans_code);
      $result = TravelPolicy::insert($user_data); 
      $this->update_log($user_data);
      
      $columns = array();
      $columns = array('trans_code' => $trans_code.'_DONE');
      $usr_tbl->update_data($columns, $trans_code);

      }catch (\Exception $e) {
        Log::info('TRAVEL_RELIGARE_PG_RESPONSE '. print_r($e->getMessage(), true));
      }
    }

    if(!$status){
      $columns = array('transaction_num' => $pg_response['transactionRefNum']);

      if($pg_response['uwDecision'] == "PENDINGREQUIREMENTS"){
        // Status updation
        $proposal_be->update_payment_status('conditional_policy');
        //End Status updation
      }else{
        //Status updation
        $proposal_status['reference_number'] = $pg_response['transactionRefNum'];
        $proposal_status['response_msg'] = json_encode($pg_response); 
        $proposal_be->update_payment_status('payment_failed',$proposal_status);
        $proposal_be->update_payment_status('policy_error',$proposal_status);
        //End Status updation
      }

      $usr_tbl->update_data($columns, $trans_code);
    }

    return json_encode(['status'=> $status,   
           'logo' => Travel_Constants::$RELIGARE_LOGO, 
           'pg_response' => $pg_response, 
           'policy_link' => $policy_link]);
    }

    public function update_log($user_data){
      $proposal_be = new TravelProposalBe;
      $insurer_code  = 'RELIGARE';
      $agent_code    = $user_data['agent_code'];
      $policy_number = $user_data['policy_num'];
      $final_premium = $user_data['finalPremium'];
      $tax           = $user_data['finalTax'];
      $base_premium  = (int)$final_premium - (int) $tax;
      $proposal_be->update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium);
    }

    public function parse_pdf_response($result){
      $dom = new \DOMDocument;
      try{
        $dom->loadXML($result);
      }catch (\Exception $e){
        Log::info('TRAVEL_RELIGARE_PDF_RESPONSE_PARSING'. print_r($e->getMessage(),true));
      }
      try{

        $response = $dom->getElementsByTagName("return")->item(0)->nodeValue;
      }catch(\Exception $e){
        return false;
      } 
        $response = simplexml_load_string('<?xml version="1.0" encoding="ISO-8859-1"?>    
                                             <documents>'.$response.'</documents>'); 
      $data = $response->StreamData;
      if($response->Status == 'SUCCESS'){
        return $data;
      }
      return false;
    }
}  	
