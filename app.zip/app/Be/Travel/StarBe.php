<?php
namespace App\Be\Travel;
use App\Libraries\TravelLib;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelConfig;
use App\Constants\Travel_Constants;
use App\Constants\Common_Constants;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelHdfcRate;
use App\Models\Travel\TravelTataPremium;
use App\Models\Travel\TravelPurpose;
use App\Models\Travel\TravelPed;
use App\Models\Travel\TravelPolicy;
use App\Helpers\Travel\Star\StarProposal;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Storage;
use Log;

class StarBe{

    private $policy_type_flag, $lib, $set;

    public function __construct(){
        date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE);
        $this->policy_type_flag = 0; // For Policy Checking
        $this->lib = new TravelLib;
    }

    public function check_si($type, $si){
        if($type == 'S'){
            $si_list = array('50000', '100000','250000');
            if(in_array($si,$si_list)){
                return true;
            } else {
                return false;
            }
        }
    }

    public function check_age($data){
        $age        = $this->lib->calculateYMD($data['dob'][0]);
        $child_flag = false;
        for($i=6; $i<12; $i++){
            if($age == $i.'M'){
                $child_flag = true;
            }
        }

        if(!$child_flag){
            if($age!= 0){
                $age   = $this->lib->calculateAge($data['dob'][0]);
                if($age >= 1 && $age <= 65){
                    return true;
                } else {
                    return false;
                }
            }else {
                return false;
            }
        }else {
            return true;
        }
    }

    public function calculate_indv_policy($input) {
        $request = $this->set_indv_values($input);
        return $this->callApi($request, $input,$input['trans_code']);
    }

    private function callApi($request,$input,$trans_code){
        $client = new Client();
        try{
            $res = $client->request('POST',
                Travel_Constants::$STAR_REQUEST_URL,
                ['json' => $request]
            );

        }catch(\Exception $e){
            Log::info('TRAVEL_STAR_QUOTE_RESPONSE in Catch call API method :- '.$trans_code.' - '.print_r($e->getMessage(), true));
            return null;
        }

        $response = json_decode($res->getBody()->getContents(), true);
        $response = $this->set_response($response,$input['sum-insured'],$input['area'],$trans_code);
        $result   = '';
        $result = array();
        if(empty($response)){
            $result = null;
        }else {
            $result[] = $response;
        }
        return $result;
    }

    private function set_indv_values($input){
        $request                   = array();
        $request['APIKEY']         = Travel_Constants::$STAR_APIKEY;
        $request['SECRETKEY']      = Travel_Constants::$STAR_SECRETKEY;
        $request['policyTypeName'] = Travel_Constants::$STAR_POLICY_TYPE;
        // Star will not accept current day as policy staring date
        $request['travelStartOn']  = date("M d, Y", strtotime('+1 day', strtotime(date("Y/m/d"))));
        $enddate = $this->get_end_date(date("Y/m/d"), ($input["duration"]));
        $request['travelEndOn']    = date("M d, Y", strtotime($enddate));
        $plan_details = $this->get_plan($input['sum-insured'],$input['area']);
        $request['planId']         = $plan_details['plancode'];
        $request['insureds[0]']    = array("dob"=> date("M d, Y", strtotime($input["dob"][0])));
        return $request;

    }

    private function get_end_date($date,$days){
        $date = strtotime("+".$days." days", strtotime($date));
        $date = date("m/d/Y", $date);
        return $date.' '.'11:59:59 PM';
    }

    private function set_response($response,$si,$area,$trans_code){
        $un_key        = uniqid();
        $breakup_t     = array();
        $plan          = $this->get_plan($si,$area);
        $response['company_name']       = 'Star Health and Allied Insurance';
        $response['url_code']           = 'star';
        $response['ProductDescription'] = 'Travel Protect';
        $response['session_key']        = $trans_code;
        $response['trans_code']         = $trans_code;
        $response['NetPremiumAmt']      = $response['totalPremium'];
        $response['TotalTaxAmt']        = $response['serviceTax'];
        $response['PlanCode']           = 'star#'.$plan['plancode'];
        $response['PlanDesc']           = $plan['plandec'];
        $response['companyId']          = $this->lib->get_company_code('star');
        $response['logo']               = 'image/logos/'.$response['companyId'].'_logo.png';
        $response['productCode']        = '';
        $response['destinationCode']    = '';
        $response['sum-insured']        = $si;
        $response['policyId']           = $un_key;

        $sv_quote                 = $response;
        $sv_quote['insurer']      = $response['premium'];
        $sv_quote['addon_id']     = null;
        $sv_quote['addon_value']  = null;
        return $response;
    }

    public function get_plan($sum_insured,$area){
        if($sum_insured == '50000'){
            if($area == '1' )
                return ['plancode'=> 5, 'plandec' => 'A1'];
            return ['plancode'=> 6, 'plandec' => 'A2'];
        }elseif($sum_insured == '100000'){
            if($area == '1' )
                return ['plancode'=> 1, 'plandec' => 'B1'];
            return ['plancode'=> 3, 'plandec' => 'B2'];
        }elseif($sum_insured == '250000'){
            if($area == '1' )
                return ['plancode'=> 2, 'plandec' => 'C1'];
            return ['plancode'=> 4, 'plandec' => 'C2'];   
        }elseif($sum_insured == '500000'){
            if($area == '1' )
                return ['plancode'=> 7, 'plandec' => 'D1'];
            return ['plancode'=> 8, 'plandec' => 'D2'];
        }
    }

    private function format_date($date){
        $date = \DateTime::createFromFormat('d-m-Y', $date);
        return $date->format("M d, Y");
    }

    public function set_proposal($trans_code){
        $request       = array();
        $personal      = array();
        $usr_tbl       = new TravelUsrData;
        $userdata      = $usr_tbl->get_all_data($trans_code);
        $insured_name  = explode(',', $userdata['name']);
        $insured_dob   = explode(',', $userdata['dob']);
        $gender        = explode(',', $userdata['gender']);
        $passport      = explode(',', $userdata['passport']);
        $ped           = json_decode($userdata['ped'], true);
        $userdata     = $usr_tbl->get_all_data($trans_code);

        $plan_id = explode('#',$userdata['plan_code']);

        $request['APIKEY']         = Travel_Constants::$STAR_APIKEY;
        $request['SECRETKEY']      = Travel_Constants::$STAR_SECRETKEY;
        $request['policyTypeName'] = Travel_Constants::$STAR_POLICY_TYPE;
        //Basic Details
        $request['travelStartOn']  = $this->format_date($userdata['trip_start_date']);
        $request['travelEndOn']    = $this->format_date($userdata['trip_end_date']);

        // Proposer Details 
        $request['proposerName']   = strtoupper($insured_name[0]);
        $request['proposerEmail']  = strtoupper($userdata['email']);
        $request['proposerPhone']  = strtoupper($userdata['mobile']);
        $request['proposerAddressOne']   = strtoupper($userdata['house_name']);
        $request['proposerAddressTwo']   = strtoupper($userdata['street']);
        $request['proposerAreaId']       = $userdata['cust_area'];
        $request['gstIdNumber']  = '';
        $request['proposerDob']  = $this->format_date($insured_dob[0]);
        $request['planId'] = $plan_id[1];
        $request['travelDeclaration']  = '1';
        $request['travelPurposeId'] = $userdata['purpose'];
        $request['physicianName']  = strtoupper($userdata['physician_name']);
        $request['physicianContactNumber']  = $userdata['physician_number'];

        // Traveller Details 
        $personal['name'] = strtoupper($insured_name[0]);
        $personal['dob'] =  $this->format_date($insured_dob[0]);

        // Setting Gender for user
        if($gender[0] === 'M'){
            $personal['sex'] = 'Male';
        } else{
            $personal['sex'] = 'Female';
        }
        $personal['relationshipId'] = '11';
        $personal['illness'] = 'NONE';
        if(!empty($ped)){
            $personal['illness'] = $this->get_medical_history($ped);
        }
        $personal['passportNumber'] = strtoupper($passport[0]);
        $personal['passportExpiry'] = $this->format_date($userdata['passport_expiry']);
        $personal['assigneeName'] = strtoupper($userdata['nomineename']);
        $personal['assigneeRelationshipId'] = $userdata['nomineerel'];
        $personal['visaType'] = $userdata['visa_type'];
        $request['insureds[0]'] = $personal;
        $request['placeOfVisit'] = $userdata['visiting_country'];
        return $request;
    }

    private function get_medical_history($ped){

        $ped_details = array();
        $ped_tbl = new TravelPed;
        $column = array('ped_title');
        try{
            foreach($ped['sub_ped'] as $ped_code => $status){
                $check_values  = array('star_code' => $ped_code);
                $response      = $ped_tbl->get_value($column, $check_values);
                if($response){
                    $ped_details[] = $response[0]['ped_title'];
                }

            }
        }catch(\Exception $e){
            return null;
        }
        return implode(',', $ped_details);
    }

    public function parse_policy($response,$trans_code){
        $usr_tbl = new TravelUsrData;
        $helper  = new StarProposal;
        $columns = array('premium');
        $t_data  = $usr_tbl->get_data($columns,$trans_code);
        //$t_data['premium'] = '650';
        $difference = abs((int)$response['totalPremium'] - (int)$t_data['premium']);
        $request['APIKEY']      = Travel_Constants::$STAR_APIKEY;
        $request['SECRETKEY']   = Travel_Constants::$STAR_SECRETKEY;
        $request['referenceId'] = $response['referenceId'];
        $token_response = $helper->token_request($request);
        $url = Travel_Constants::$STAR_PG_URL.$token_response['redirectToken'];
        if($difference == 0){
            Log::info('TRAVEL_STAR_PG_REQUEST - '.$trans_code.' - '. print_r($url, true));
            session()->put('star_tr_suid', $trans_code);
            $columns = array('premium','tax');
            $t_data  = $usr_tbl->get_data($columns, $trans_code);
            $table['finalPremium'] = $t_data['premium'];
            $table['finalTax']     = $t_data['tax'];
            $usr_tbl->update_data($table,$trans_code);
            $pg_request['actual_premium'] = $t_data['premium'];
            $pg_request['pg_url'] = $url;

            // Status updation
            $proposal_status['reference_number'] = $response['referenceId'];
            $proposal_status['response_msg'] = json_encode($response);
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('no_change_premium', $proposal_status);
            // End Status updation

            return array('status' => 1, 'mismatch' => 0, 'pg_request' => $pg_request);
        }else {
            $lib = new TravelLib;
            $table['finalPremium'] = $response['totalPremium'];
            $table['finalTax']     = $lib->get_tax_premium($response['totalPremium']);
            $usr_tbl->update_data($table,$trans_code);
            $pg_request['actual_premium'] = $t_data['premium'];
            $pg_request['passed_premium'] = $response['totalPremium'];
            $pg_request['pg_url'] = $url;

            // Status updation
            $proposal_status['reference_number'] = $response['referenceId'];
            $proposal_status['response_msg'] = json_encode($response);
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('premium_mismatch', $proposal_status);
            // End Status updation

            return array('status' => 0, 'mismatch' => 1, 'pg_request' => $pg_request);
        }
    }

    public function get_proposal_inputs($trans_code){
        $company_column = 'star_code';
        $bl = new TravelProposalBe;
        $data = $bl->get_proposal_inputs($trans_code, $company_column);

        // Setting Trip Start Date 
        $data['userdata']['trip_start_date'] = $this->get_trip_start_date($data['userdata']['trip_start_date'], $data['userdata']['triptype']);

        // Setting Trip End Date 
        $data['userdata']['trip_end_date'] = $this->get_trip_end_date($data['userdata']);

        //Setting City List
        $city_list = (!empty($data['userdata']['pincode']))? $this->get_city_list($data['userdata']['pincode'],$trans_code) : '';

        $data['userdata']['state'] =  (!empty($data['userdata']['pincode'])) ? $city_list['state_name'] : '';

        if($city_list){
            $city_list = $city_list['city'];
            $data['city_list'] = $city_list;
        }

        //Setting Area List
        $area_list = (!empty($data['userdata']['city']))? $this->get_area_list($data['userdata']['pincode'], $data['userdata']['city'],$trans_code) : null;

        if($area_list && array_key_exists('area',$area_list)){
            $area_list = $area_list['area'];
            $data['area_list'] = $area_list;
        }

        if($data['userdata']['triptype'] == 'S' || $data['userdata']['triptype'] == 'M'){
            unset($data['purpose_list'][2]);
            unset($data['purpose_list'][3]);
        }

        // Visa Type
        $data['visa_type_list'] = array( 0 => array ('visa_code' => '1',
                                                     'visa_name' => 'Business Visa'),
                                         1 => array ('visa_code' => '2',
                                                     'visa_name' => 'Student Visa'),
                                         2 => array ('visa_code' => '3',
                                                     'visa_name' => 'Tourist Visa'));

        // Setting Passport Expiry
        $data['passport_expiry_list'] = $this->get_passport_expiry($data['userdata']['trip_end_date'],$data['userdata']['trip_start_date']);
        return $data;
    }

    private function get_passport_expiry($trip_end_date,$trip_start_date){
        $lib = new TravelLib;
        $result = array();
        $result['selected_date'] = $lib->add_days_with_date($trip_start_date['min_date'], '180');//$trip_end_date;
        $result['max_date']      = $lib->add_year_to_date(date("d-m-Y"), '10');
        $result['min_date']      = $lib->add_days_with_date($trip_start_date['min_date'], '180');
        return $result;
    }

    public function get_travel_start_date($params){
        $passport_expiry = $params['passport_expiry_date'];
        $lib = new TravelLib;
        $result = array();
        $result['selected_date'] = $lib->sub_days_with_date($passport_expiry, '180');//$trip_end_date;
        $result['max_date']      = $result['selected_date'];
        $result['min_date']      = date("d-m-Y");
        return $result;
    }

    private function get_city_list($pincode,$trans_code){
        if(!$pincode){ return null; }
        $helper = new StarProposal;
        $data['pincode'] = $pincode;
        $data['trans_code'] = $trans_code;
        $response = $helper->get_state_city_list($data);
        $response = json_decode($response, true);
        return $response;
    }

    private function get_area_list($pincode, $city,$trans_code){
        if(!$pincode){ return null; }
        $helper = new StarProposal;
        $data['pincode'] = $pincode;
        $data['city'] = $city;
        $data['trans_code'] = $trans_code;
        $response = $helper->get_area_list($data);
        $response = json_decode($response, true);
        return $response;
    }

    public function set_proposal_data($data){
        $trans_code = $data['trans_code'];
        $section     = $data['id'];
        $usr_tbl     = new TravelUsrData;
        $check_value = array('trans_code' => $trans_code);
        // Unsetting the extra values
        unset($data['trans_code']);
        unset($data['id']);
        unset($data['_token']);
        if($section == 'travel'){
            $data['name'] = implode(',',$data['name']);
            $data['dob']  = implode(',',$data['dob']);
            $data['passport']  = implode(',',$data['passport']);
            $data['visa_type'] = implode(',',$data['visa_type']);
        }


        if($section == 'medical_his'){
            if(isset($data['ped_choice'])){
                $ped['ped_choice'] = $data['ped_choice'];
                $ped['ped_details'] = (isset($data['ped_details'])) ? $data['ped_details'] : '' ;
                $ped['sub_ped'] = (isset($data['sub_ped'])) ? $data['sub_ped'] : '' ;
                $data = array();
                $data['ped'] = json_encode($ped);
            }else{
                $data['ped'] = null;
            }
        }
        $usr_tbl->set_data($data, $check_value);

    }

    private function get_trip_start_date($date, $trip_type){
        $lib = new TravelLib;
        $result = array();
        $duration = 179;
        $result['selected_date'] = ($date) ? $date : $lib->add_days_with_date(date("d-m-Y"), '1');
        $result['min_date']      = $lib->add_days_with_date(date("d-m-Y"), '1');
        $result['max_date']      = $lib->add_days_with_date(date("d-m-Y"), $duration);
        return $result;
    }

    private function get_trip_end_date($userdata){
        $lib = new TravelLib;
        if($userdata['triptype'] == 'S'){
            return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $userdata['duration'] - 1);
        }
        if($userdata['triptype'] == 'ST'){
            $duration = $lib->map_student_duration($userdata['std_duration']);
            return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $duration - 1);
        }
    }

    public function get_proposal_preview_data($response, $userdata){
        try{
            $response['communication_info']['state'] = strtoupper($userdata['state']);
            $city = json_decode($userdata['city_list'], true);
            $city = $city['city'];
            foreach ($city as $id => $item) {
                if($item['city_id'] == $userdata['city']){
                    $response['communication_info']['city'] = strtoupper($item['city_name']);
                }
            }
        }catch(\Exception $e){
            $response['communication_info']['state'] = 'No Record Found';
            $response['communication_info']['city']  = 'No Record Found';
        }


        $response['trip_info']['visiting_country'] = null;
        $response['en_insta_disclaimer'] = false;
        $response['disclaimer']  =  Travel_Constants::$STAR_DISCLAIMER;
        return $response;
    }


    public function parse_pg_response($pg_response,$trans_code){
        $helper      = new StarProposal;
        $usr_tbl     = new TravelUsrData;
        $user_data   = $usr_tbl->get_all_data($trans_code);
        $proposal_be = new TravelProposalBe;
        if(!$user_data){
            return json_encode(['status'=> false, 'redirect' => true]) ;
        }

        $response['status'] = 0;
        $response['transaction_num'] = 0;
        $response['logo'] = Travel_Constants::$STAR_LOGO;

        if(isset($pg_response['purchaseToken']) && !empty($pg_response['purchaseToken'])){
            $status_url = str_replace('{TOKEN}',$pg_response['purchaseToken'],Travel_Constants::$STAR_PG_STAUS_URL);
            $status_response = $helper->get_payment_status($status_url, $pg_response['purchaseToken']);
            if(!empty($status_response)){
                $response['status']  = ($status_response['status'] == 'SUCCESS') ? '1' : '0' ;
                $response['transaction_num'] = $status_response['referenceId'];
            }
        }

        if($response['status']){
            try{
                $columns = array('transaction_num' => $response['transaction_num']);

                // Status updation
                $proposal_status['reference_number'] = $response['transaction_num'];
                $proposal_status['response_msg'] = json_encode($pg_response);
                $proposal_be->update_payment_status('payment_success',$proposal_status);
                //End Status updation

                // Status updation
                $proposal_be->update_payment_status('policy_accepted');
                //End Status updation


                $usr_tbl->update_data($columns, $trans_code);
                $user_data  = $usr_tbl->get_all_data($trans_code);
                $result = TravelPolicy::insert($user_data);
                $this->update_log($user_data);
                $columns = array();
                $columns = array('trans_code' => $trans_code.'_DONE');
                $usr_tbl->update_data($columns, $trans_code);

            }catch (\Exception $e) {
                Log::info('TRAVEL_STAR_PG_RESPONSE - '.$trans_code.' - '. print_r($e->getMessage(), true));
            }
        }

        if(!$response['status']){
            try{
                $columns = array('transaction_num' => $response['transaction_num']);

                //Status updation
                $proposal_status['reference_number'] = $response['transaction_num'];
                $proposal_status['response_msg'] = json_encode($pg_response);
                $proposal_be->update_payment_status('payment_failed',$proposal_status);
                $proposal_be->update_payment_status('policy_error',$proposal_status);
                //End Status updation

                $usr_tbl->update_data($columns, $trans_code);
                $user_data  = $usr_tbl->get_all_data($trans_code);

            }catch (\Exception $e) {
                Log::info('TRAVEL_STAR_PG_RESPONSE '. print_r($e->getMessage(), true));
            }
        }

        return $response;
    }

    public function update_log($user_data){
        $proposal_be = new TravelProposalBe;
        $insurer_code  = 'STAR';
        $agent_code    = $user_data['agent_code'];
        $policy_number = $user_data['policy_num'];
        $final_premium = $user_data['finalPremium'];
        $tax           = $user_data['finalTax'];
        $base_premium  = (int)$final_premium - (int) $tax;
        $proposal_be->update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium);
    }
}   
