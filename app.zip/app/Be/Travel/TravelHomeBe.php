<?php 

namespace App\Be\Travel;
use App\Models\Travel\TravelRelationship;
use App\Models\Travel\TravelUsrData;
use App\Constants\Travel_Constants;
use App\Libraries\TravelLib;
use Log; 

class TravelHomeBe{

    public function get_traveller_data($data){
       $rel_tbl = new TravelRelationship;
       $traveller_count = sizeof($data['relationship']);
       if($traveller_count == 6){
        return false;
       }

       $columns = array('relationship_id', 'relationship_name');
       $response = $rel_tbl->get_all_data($columns,  'common' );
       $key = array_search('1', $response);
       unset($response[$key]);
       $response_backup = $response;
       if(in_array('3', $data['relationship']) || in_array('2', $data['relationship'])){

           foreach($response_backup as $index => $item){
                if($item['relationship_id'] == '3'){
                    unset($response[$index]);
                }
                if($item['relationship_id'] == '2'){
                    unset($response[$index]);
                }
            }

        }

        if(in_array('4', $data['relationship'])){

           foreach($response_backup as $index => $item){
                if($item['relationship_id'] == '4'){
                    unset($response[$index]);
                }
            }

        }

        if(in_array('5', $data['relationship'])){

           foreach($response_backup as $index => $item){
                if($item['relationship_id'] == '5'){
                    unset($response[$index]);
                }
            }

        }
       
       return $response;
    }

    public function get_age_list($data){
        $self_age = $data['age'][0];
        $relationship_list = $data['relationship'];
        $age_list = $data['age'];
        $key = '';
        $html_list ='<option hidden="" selected="" disabled="" value="">Select Age</option>';
        $lower_limit = 0;
        $upper_limit = 0;

        foreach($relationship_list as $index => $item){
            if(!isset($age_list[$index])){
                $key = $index;
            }
        }    

        $relationship = $relationship_list[$key];

        if($relationship == '6' || $relationship == '7'){
            $lower_limit = '3M';
            if(in_array('3', $relationship_list)){
                $key = array_search('3', $relationship_list);
                $wife_age = $age_list[$key];
                if($wife_age < $self_age){
                   $upper_limit = $wife_age - 18;
                }else{
                   $upper_limit = $self_age - 21;
                }
            }elseif(in_array('2', $relationship_list)){
                $key = array_search('2', $relationship_list);
                $husband_age = $age_list[$key];
                if($husband_age < $self_age){
                   $upper_limit = $husband_age - 21;
                   $upper_limit = $self_age - 18;
                }
            }else{
                $upper_limit = $self_age - 18;
            }            
        }

        if($relationship == '4'){
            $lower_limit = $self_age + 21;
            $upper_limit = 99;
        }

        if($relationship == '5'){
            $lower_limit = $self_age + 18;
            $upper_limit = 99;
        }

        if($relationship == '3'){
            $lower_limit = 18;
            $upper_limit = 99;
        }
        if($relationship == '2'){
            $lower_limit = 21;
            $upper_limit = 99;
        }

        if($relationship == '8'){
            $lower_limit = '3M';
            $upper_limit = 99;
        }

        if($lower_limit == '3M'){
            for($i=3; $i<=11 ; $i++){
                $html_list .= '<option value='.$i.'M>'.$i.' Months</option>';
            }
            $lower_limit = 1;
            
        }

        for($i=$lower_limit; $i<=$upper_limit; $i++){
                $html_list .= '<option value='.$i.'>'.$i.' Years</option>';
        } 

        return $html_list; 
    }

    private function get_month_from_list($age){
        for($i=1;$i<12;$i++){
            if($age == $i.'M'){
                return 6;
            }
        }
    }

    public function save_user_data($data){
        try{
        $session_key = $data['trans_code'];
        $trans_code = $data['trans_code'];
        $trip_type = $data['triptype'];
        $area = $data['area'];
        $duration = $data['duration'];
        $amt_duration = $data['amt_duration'];
        $std_duration = $data['std_duration'];
        $relationship_list = $data['relationship_list'];
        $age_list = $data['age_list'];
        $dob_list = array();
        $current_date = date("d-m-Y");
        $lib = new TravelLib;
        $user_tbl = new TravelUsrData;
        $carry = array();
        $child_age = array('1M','2M','3M','4M','5M','6M','7M','8M','9M','10M','11M');
        $age_list_tmp = explode(',', $age_list);
        $travel_count = sizeof($age_list_tmp );
        $default_sum_insured = '50000';
        if($trip_type =='S'){
            $default_sum_insured = '50000';
        }elseif($trip_type =='M'){
            $default_sum_insured = '250000';
        }elseif($trip_type =='ST'){
            $default_sum_insured = '50000';
        }
        
        $relationship_list_tmp = explode(',', $relationship_list);
        foreach($age_list_tmp as $index => $age){
            if(in_array($age, $child_age)){
                $month = $this->get_month_from_list($age);
                $dob_list[] = $lib->minus_month_from_date($current_date,$month);
            }else{
                $dob_list[] = $lib->minus_year_from_date($current_date,$age);
            }
            
        }

        // For Relationship
        $relation_tbl = new TravelRelationship;
        $column       = array('relationship_name','relationship_gender');
        $temp         = array();
        foreach($relationship_list_tmp as $value){
            $check_values = array('relationship_id' => $value);
            $result = $relation_tbl->get_data($column,$check_values);
            $carry['relation'][] = $result[0]['relationship_name'];
            $temp['gender'][]    = $result[0]['relationship_gender'];
        }
        
        // For Gender & Title list
        foreach($temp['gender'] as $value ){
            if($value == 'S'){
                if(in_array('Wife',  $carry['relation'])){
                    $carry['gender'][] = 'M';
                    $carry['title'][]  = 'Mr';
                }elseif(in_array('Husband', $carry['relation'])){
                    $carry['gender'][] = 'F';
                    $carry['title'][]  = 'Mrs';
                }else{
                    $carry['gender'][] = 'M';
                    $carry['title'][]  = 'Mr';
                }
            }else{
                $carry['gender'][] = $value;
                switch($value){
                    case 'M' : $carry['title'][]  = 'Mr';
                    break;
                    case 'F' : $carry['title'][]  = 'Ms';
                    break;
                    case 'N' : $carry['title'][]  = 'Mr';
                    break;
                }
            }
        }
        
        // Save User data into Transition Table
        $table[Travel_Constants::USR_T_LOG['TRIP_TYPE']]    = $trip_type;
        $table[Travel_Constants::USR_T_LOG['AREA']]         = $area;
        $table[Travel_Constants::USR_T_LOG['DURATION']]     = $duration;
        $table[Travel_Constants::USR_T_LOG['AMT_DURATION']] = $amt_duration;
        $table[Travel_Constants::USR_T_LOG['STD_DURATION']] = $std_duration;
        $table[Travel_Constants::USR_T_LOG['TRAVEL_COUNT']] = $travel_count;
        $table[Travel_Constants::USR_T_LOG['DOB']]          = implode(",",$dob_list);
        $table[Travel_Constants::USR_T_LOG['RELATIONSHIP']] = $relationship_list;
        $table[Travel_Constants::USR_T_LOG['SI']]           = $default_sum_insured;
        $table[Travel_Constants::USR_T_LOG['SESSION_ID']]   = $session_key;
        $table[Travel_Constants::USR_T_LOG['TRANS_CODE']]   = $trans_code;
        $table[Travel_Constants::USR_T_LOG['USER_CODE']]    = session("user_agent") != true ? session("user_code") : null;
        $table[Travel_Constants::USR_T_LOG['AGENT_CODE']]   = session("user_role") == '_AGENT'  ? session("user_code") : null;
        $table['checks']   = null;
        $table['age_list'] = $age_list;
        $table['title']    = implode(",",$carry['title']);
        $table['gender']   = implode(",",$carry['gender']); 
        Log::info($table);
        try{
            $check_values = array(Travel_Constants::USR_T_LOG['TRANS_CODE'] => $trans_code);
            $user_tbl->set_data($table, $check_values);
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return false;
        }

        return true;
        
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return false;
        }
              
    }
}    
