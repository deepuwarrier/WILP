<?php 
namespace App\Be\Travel;
use App\Helpers\Travel\Tata\TataQuotes;
use App\Helpers\Travel\Hdfc\HdfcQuotes;
use App\Helpers\Travel\Religare\ReligareQuotes;
use App\Helpers\Travel\Star\StarQuotes;
use App\Libraries\TravelLib;
use App\Libraries\InstaLib;
use App\Constants\Travel_Constants;
use App\Models\Travel\TravelConfig;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelCoverageMap;
use App\Models\Travel\TravelCoverageMaster;
use App\Models\Travel\TravelReligareAddon;
use App\Models\Travel\TravelTataPremium;
use Illuminate\Support\Facades\Storage;
use App\Models\Travel\TravelRelationship;
use Log; 

class TravelQuoteBe{

  private $tata_helper, $hdfc_helper, $lib;
  public function __construct(){
        $this->tata_helper = new TataQuotes; 
        $this->hdfc_helper = new HdfcQuotes;
        $this->reli_helper = new ReligareQuotes;
        $this->star_helper = new StarQuotes; 
        $this->lib = new TravelLib;
    }
  
  public function update_quote_status($category,$trans_code, $data = null){
    $lib = new InstaLib;
    $usr_tbl = new TravelUsrData;
    $date = $lib->today_date_dMY();
    if($category == 'new_quote'){
      $column = array(Travel_Constants::USR_T_LOG['QUOTE_CREATE_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['QUOTE_STATUS'] => 'TS10',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS10'); 
      $usr_tbl->update_data($column, $trans_code);
    }

    if($category == 'update_quote'){
      $column = array(Travel_Constants::USR_T_LOG['QUOTE_UPDATE_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['QUOTE_STATUS'] => 'TS11',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS11'); 
      $usr_tbl->update_data($column,$trans_code);
    }

    if($category == 'select_policy'){
      $column = array(Travel_Constants::USR_T_LOG['QUOTE_UPDATE_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['QUOTE_STATUS'] => 'TS12',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS12'); 
      $usr_tbl->update_data($column,$trans_code);
    }

  }  

  public function get_breakup_data($quote_data,$user_data= null){
    try{


    $response     = array();
    $si_symbol = (strpos($quote_data['PlanDesc'], 'Europe') !== false || strpos($quote_data['ProductDescription'], 'Schengen')) ? '&#8364;' : '$';
    $response['sum_insured']    = $si_symbol.$quote_data['sum-insured'];
    $response['company_id']     = $quote_data['companyId'];
    $response['total_premium']  = '&#8377;'.round($quote_data['NetPremiumAmt']);
    $response['tax']            = '&#8377;'.$quote_data['TotalTaxAmt'];
    $response['basic_premium']  = '&#8377;'.round((int)$quote_data['NetPremiumAmt'] - (int)$quote_data['TotalTaxAmt']);
    $response['product']        = $quote_data['ProductDescription']; 
    $response['plan']           = (isset($quote_data['shortDescription'])) ? $quote_data['PlanDesc'].' '.$quote_data['shortDescription'] : $quote_data['PlanDesc'];
    $response['logo']           = 'image/logos/'.$quote_data['companyId'].'_logo.png';
    $response['senior_flag']    = (isset($quote_data['Seniorflag']) && $quote_data['Seniorflag'] == true) ? true : false;
    $response['policy_additinal_info_1'] = 'Premium is inclusive of applicable GST @ 18%';

    $response['split_up']['values'] = [];
   if(array_key_exists('insurer', $quote_data))
      $response['split_up']['values']  = explode(',',$quote_data['insurer']);
    
    $response['split_up']['keys']    = array();
    $response['travel_count']   = sizeof($response['split_up']['values']);
    foreach($response['split_up']['values'] as $index => $item){
      $count       = $index+1;
      $extra_title = '';
      if(!is_numeric($item)){
         if(!empty($item)){
           $value = explode('@', $item); 
           if($value[1] == 'WS#SN'){
               $extra_title = '&nbsp;(Senior Plan)*';
           }else if($value[1] == 'WTS'){
               $extra_title = '&nbsp;(Without Sublimit)';
           }else if($value[1] == 'WTS#SN'){
               $extra_title = '&nbsp;(Without Sublimit - Senior Plan)*';
           }else{
               $extra_title = '&nbsp;(With Sublimit)';
           }
         }
      }
      $response['split_up']['keys'][$index] = 'Traveller&nbsp;'.$count.$extra_title;
      $response['split_up']['values'][$index] = '&#8377;'.number_format((float)$item, 1, '.', '');
  }
  
  if($response['senior_flag'])
      $response['policy_additinal_info_2'] = '*Sum Insured for Senior Plan is limited to $50,000';
    }catch(Exceptio $e){
      Log::info('Error ' .$e->getMessage());
      return $e->getMessage();  
    }
  return $response;
  }
  
  public function genrate_benefit_data($user_data){
    $plan_code = $user_data['plan_code'];
    $misc_desc = json_decode($user_data['misc_desc'],true);
    $quote_data = $misc_desc[$plan_code];
    $quote_data['companyId'] = $user_data['company_id'];
    $quote_data['NetPremiumAmt'] = $user_data['premium'];
    $quote_data['TotalTaxAmt']= $user_data['tax'];
    $quote_data['sum-insured']= $user_data['sum_insured'];
    $quote_data['PlanCode'] = $user_data['plan_code'];
    $premium = $user_data['premium'] - $user_data['tax'];
    $premium = $premium/$user_data['travelcount'];
    $insurer = [];
    for($i = 0;$i < $user_data['travelcount']; $i++){
      $insurer[] = $premium;
    }
    $quote_data['insurer'] = implode(",",$insurer);

    $data = [];
    $data['benifit'] = $this->get_benefit_data($user_data['trans_code'],$quote_data,$user_data);
    $data['pb'] = $this->get_breakup_data($quote_data,$user_data);
    return $data;
  }

  public function get_benefit_data($trans_code,$quote_data,$usr_data = null){
     try{
      $response = [];
      if(!$usr_data){
        $u_tbl        = new TravelUsrData;  
        $column       = array('triptype', 'area');
        $usr_data     = $u_tbl->get_data($column,$trans_code);
      }
      
      
      $si_symbol = (strpos($quote_data['PlanDesc'], 'Europe') !== false || strpos($quote_data['ProductDescription'], 'Schengen')) ? '&#8364;' : '$';
          $response['sum_insured']    = $si_symbol.$quote_data['sum-insured'];
          $response['company_id']     = $quote_data['companyId'];
          $response['total_premium']  = '&#8377;'.round($quote_data['NetPremiumAmt']);
          $response['tax']            = $quote_data['TotalTaxAmt'];
          $response['product']        = $quote_data['ProductDescription'];
          $response['plan']           = (isset($quote_data['shortDescription'])) ? $quote_data['PlanDesc'].' '.$quote_data['shortDescription'] : $quote_data['PlanDesc'];
          $response['title']          = 'View Benefits';
          $response['trip_type']      = $usr_data['triptype'];
          $response['trip_area']      = $usr_data['area'];
          $response['logo']           = 'image/logos/'.$quote_data['companyId'].'_logo.png';
          $response['senior_flag']    = (isset($quote_data['Seniorflag']) && $quote_data['Seniorflag'] == true) ? true : false;
          $response['gen_wording']    = 'For exact terms and conditions of the policy, deductables, inclusions and exclusions, please refer the policy wordings. Read the policy wordings carefully before concluding the purchase.';

          //FGGI
          if($quote_data['companyId'] == 'fggi'){
            if($usr_data['area'] == '7'){
              $response['policy_wording']   = url('/').'/pdf/travel/future-generali-suraksha-schengen-policy-wordings.pdf';
              $response['product_brochure']   = url('/').'/pdf/travel/future-generali-suraksha-schengen-brochure.pdf';
            }else{
              if($quote_data['productCode'] == 'TSS'){
                $response['product_brochure']   = url('/').'/pdf/travel/future-generali-suraksha-select-brochure.pdf';
              }else{
                $response['product_brochure']   = url('/').'/pdf/travel/future-generali-suraksha-brochure.pdf';
              }
              $response['policy_wording']   = url('/').'/pdf/travel/future-generali-suraksha-policy-wordings.pdf';
            }
            
          }

          //TATA
          if($quote_data['companyId'] == 'tata'){
              if($usr_data['triptype'] == 'ST'){
                  $response['policy_terms']   = 'pdf/travel/policy_coverage_terms_tata_aig_student_guard.pdf';
                  $response['policy_wording'] = 'https://www.tataaiginsurance.in/taig/taig/tata_aig/about_us/Media_Centre/pdf/policy_wordings/Student_Guard_-Overseas_Health_Insurance_Plan_-_Policy_Wordings.pdf';
              }elseif($usr_data['triptype'] == 'S' && $usr_data['area'] == '3'){
                  $response['policy_terms']   = 'pdf/travel/policy_coverage_terms_tata_aig_asia_guard.pdf';
                  $response['policy_wording'] = 'https://www.tataaiginsurance.in/taig/taig/tata_aig/about_us/Media_Centre/pdf/policy_wordings/Asia_Travel_Guard_Policy_Wording.pdf';
              }else{
                  $response['policy_terms']   = 'pdf/travel/policy_coverage_terms_tata_aig.pd';
                  $response['policy_wording'] = 'https://www.tataaiginsurance.in/about-us/Media_Centre/pdf/policy_wordings/Travel_Guard_Policy_Wording.pdf';
              }
              
              $response['senior_terms']       = 'Sum Insured for Senior Plan is limited to $50,000 & Benefits are different';
              $response['policy_benefits']    = 'pdf/travel/tata_aig_senior_plan_coverage.pdf';
          }
          
          //HDFC
          if($quote_data['companyId'] == 'hdfc'){
              if($usr_data['triptype'] == 'ST'){
                  $response['policy_wording'] = 'https://www.hdfcergo.com/documents/downloads/policywordings/StudentSuraksha_PolicyWordings.pdf';
              }else{
                  $response['policy_wording'] = 'https://www.hdfcergo.com/documents/downloads/policywordings/TravelInsurance.pdf';
              }
          }
          //RELIGARE
          if($quote_data['companyId'] == 'religare'){
              if($usr_data['triptype'] == 'ST'){
                  $response['policy_wording'] = 'http://www.religarehealthinsurance.com/open-pdf.html?code=L3NpdGV1cGxvYWQvZG9jLzM3Mzk0U3R1ZGVudC1FeHBsb3JlLVRyYXZlbC1JbnN1cmFuY2UtUHJvZHVjdC5wZGY=';
              }else{
                  $response['policy_wording'] = 'http://www.religarehealthinsurance.com/open-pdf.html?code=L3NpdGV1cGxvYWQvZG9jLzM3Mjc4RXhwbG9yZS1UcmF2ZWwtSW5zdXJhbmNlLVByb2R1Y3QucGRm';
                  $response['policy_exclusions'] = 'pdf/travel/religare_exclusions.pdf';
              }
          }
          $response['coverage'] = $this->get_benefits($quote_data['PlanCode'],
                                                      $quote_data['companyId'],
                                                      $quote_data['sum-insured'],
                                                      $quote_data['destinationCode'],
                                                      $usr_data['triptype'] );
          return $response;
     }catch(Exception $e){

     }finally{
       return $response;
     }
  }

  private function get_benefits($code, $company_id, $si, $destination = null, $type){
      $columns = array(Travel_Constants::COV_MAP['BENEFITS'],
                       Travel_Constants::COV_MAP['VALUES']); 
      $check_values = array(Travel_Constants::COV_MAP['PLANCODE'] => $code);
      // For Religare student, need to consider SI also
      if($code == '40001024' || $code == '40001025' || $code == '40001026' || $code == '40001027' || $code == '40001028' || $code == '40001029'){
          $check_values[Travel_Constants::COV_MAP['SI']] = $si;
      }
      
      $cov_tbl      = new TravelCoverageMap;
      $data         = $cov_tbl->get_data($columns,$check_values);
       
      if ($data) {
          $result['code']  = explode(',', $data[0][Travel_Constants::COV_MAP['BENEFITS']]);
          $result['value'] = explode(',', $data[0][Travel_Constants::COV_MAP['VALUES']]);
          for($i=0;$i<sizeof($result['code']);$i++) {
           $result['title'][$i] = $this->get_benefit_title($result['code'][$i], $company_id, $destination,$type);
          }
        unset($result['code']);
        return $result;
      }
  }

  private function get_benefit_title($code, $company_id, $destination,$type){
      $check_values = array(Travel_Constants::COV_MASTER['CODE'] => $code);
      $benefit_tbl  = new TravelCoverageMaster;
      $column       = array();
      if($company_id == 1){
        if($type === 'S'){
          if($destination != 0)
              $column = array(Travel_Constants::COV_MASTER['SINGLE_TITLE']);  
          else
              $column = array(Travel_Constants::COV_MASTER['ASIA_TITLE']); 
        }elseif($type === 'M'){
            $column = array(Travel_Constants::COV_MASTER['AMT_TITLE']);
        }elseif ($type === 'ST') {
            $column = array(Travel_Constants::COV_MASTER['STUDENT_TITLE']);
        }

      }
      else {
        $column = array(Travel_Constants::COV_MASTER['TITLE']);
      } 
      
      $data         = $benefit_tbl->get_data($column,$check_values);
      if ($data) {
        if($company_id == 1){
          if($type === 'S'){
            if($destination != 0)
              return $data[0][Travel_Constants::COV_MASTER['SINGLE_TITLE']];
            else  
              return $data[0][Travel_Constants::COV_MASTER['ASIA_TITLE']];

          }elseif($type === 'M'){
              return $data[0][Travel_Constants::COV_MASTER['AMT_TITLE']];
          }elseif ($type === 'ST') {
              return $data[0][Travel_Constants::COV_MASTER['STUDENT_TITLE']];
          }

        }else {
          return $data[0][Travel_Constants::COV_MASTER['TITLE']]; 
        }
      }else {
        return 'Title Not Found';
      }
  }

  

  // feuture mapper for given plan
  private function get_cover($plancode){
    $cov_tbl = new TravelCoverageMap;
    $columns = array(Travel_Constants::COV_MAP['BENEFITS']);
    $check_values   = [Travel_Constants::COV_MAP['PLANCODE'] => $plancode];
    return $cov_tbl->get_data($columns, $check_values);
  }

  private function get_coves($plancodes){
    $cov_tbl = new TravelCoverageMap;
    $columns = array(Travel_Constants::COV_MAP['BENEFITS']);
    $cov = ['covers'=>[],
            'no-covers'=>[]];
    foreach ($plancodes as $key => $plancode) {
      $check_values   = [Travel_Constants::COV_MAP['PLANCODE'] => $plancode];
      $res = $cov_tbl->get_data($columns, $check_values);
      if($res)
        $cov['covers'][] = explode(',',$res[0]['map_benefits']);
      else
        $cov['no-covers'][] = $plancode;
    }
    unset($cov_tbl);
    return $cov;
  }
  
  private function get_cover_of_plans($plancodes){
    $cov = $this->get_coves($plancodes);    
    $covers = $cov['covers'];
    $common = $other = $club = $have_data = [];
    
    $cov_tbl = new TravelCoverageMaster;
    $columns = [Travel_Constants::COV_MASTER['CODE']];
    $check_values = [Travel_Constants::COV_MASTER['MUST'] => 'Y'];
    $m_have = $cov_tbl->get_data($columns, $check_values);
    foreach($m_have as $data)
        $have_data[] = $data['benefit_code'];
        $covers[count($covers)] = $have_data;
        try{
            $common = call_user_func_array('array_intersect',$covers);
            if(sizeof($covers) > 1){
              unset($covers[count($covers)-1]);
              $covers   = call_user_func_array("array_merge",$covers);
              $covers   = array_unique($covers); 
              $other1  = array_diff($covers,$common);
              $other  = array_intersect($have_data,$other1);
          }    
      }catch(\Exception $e){
        Log::info($e->getMessage());
        dd('Coverage not available for '.$empty_plancode.'. Please update the Coverage table & try');
      }
      return [$common, $other];
  }

  public function filter_response($response,$trans_code){
    if(!$response || !is_array($response))
      return NULL;

    $user_data = new TravelUsrData;
    // check wether feature is selectd 
    $data = $user_data->get_data(['checks'],$trans_code);
    if($data['checks']) // yes than must avail feature in plan
    foreach ($response as $key => $plan) {
        $req['plancodes'][0] = $plan['PlanCode'];
        $cov_exist = $this->check_feature_avail($plan['PlanCode'],$data['checks']);
        if(!$cov_exist)
            unset($response[$key]);
    }
    unset($user_data);
    
    if(empty($response))
      return NULL;

    return $response;
  }

  public function check_feature_avail($plan_code,$check){
    $covers = $this->get_cover($plan_code);
    if(!$covers)
      return false;
    $covers = $covers[0]['map_benefits'];
    $covers = explode(",",$covers);
    $check = explode(",",$check);
    $any_diff = array_diff($check,$covers);
    if(empty($any_diff))
      return true;
    return false;
  }

  public function get_cover_data($request){
      if(!array_key_exists('plancodes',$request))
        return NULL;

      $plancodes    = $request['plancodes'];
      return $this->get_cover_of_plans($plancodes);     
  }

  private function getDataQuteWithoutCheck(){
    $plan_arr = array();
          $quote_data = collect($quote_data)->sortBy('NetPremiumAmt');


    foreach($quote_data as $index=>$item){
      if(!in_array($item['PlanCode'], $plan_arr)){
        if(array_key_exists($item['companyId'],$cmp_quotes))
                unset($cmp_quotes[$item['companyId']]);
        $error = false;
        $view_data .= view('travel/quote/quote_box',
                               ['item'=>$item,
                                'index'=>$index,
                                'error'=>$error])->render();
        $plan_arr[] = $item['PlanCode'];
      }
    }
    $view_data .= $this->getNoQuoteBoxView($cmp_quotes);
    return $view_data;
  }
  
  public function getNoQuoteBoxView($cmp_quotes){
    $view_data = '';
    
    if(!is_array($cmp_quotes) || empty($cmp_quotes))
      return $view_data;

    foreach ($cmp_quotes as $key => $cmp)
       $view_data .= view('travel.quote.no_quote',
                                     ['product'=>$cmp])->render();
    return $view_data;
  }

  private function in_array_all($needles, $haystack) {
      return !array_diff($needles, $haystack);
  }
  
  private function super_unique($array){
      $result = array_map("unserialize", array_unique(array_map("serialize", $array)));
      return $result;
      // Alternate solution
      #$result = array_unique($result, SORT_REGULAR);
  }
  
  public function get_quote_inputs($trans_code, $input = null){
    $u_tbl = new TravelUsrData;
    if($input){
        $column = array('sum_insured' => $input['sum-insured']);
        $u_tbl->update_data($column,$trans_code);
    }
    // Collecting all inputs required for Quotation page and setting into one array
   
    $data  = $u_tbl->get_all_data($trans_code);
    try {
        $data['amt-duration'] = $data['amt_duration'];
        $data['std-duration'] = $data['std_duration'];
        $data['dob']          = explode(',', $data['dob']);
    }catch(\Exception $e){
        return null;
    }
    
    if($data['triptype'] == 'M'){   
        if($data['amt-duration'] == 'SM'){
            $data['trip_info'] = '1 - 30 Days Annual Multi Trip';
        }elseif($data['amt-duration'] == 'ME'){
            $data['trip_info'] = '1 - 45 Days Annual Multi Trip';
        }elseif($data['amt-duration'] == 'LA'){
            $data['trip_info'] = '1 - 60 Days Annual Multi Trip';
        }elseif($data['amt-duration'] == 'L90'){
            $data['trip_info'] = '1 - 90 Days Annual Multi Trip';
        }
    }elseif($data['triptype'] == 'S'){
        $data['trip_info'] = $data['duration'] > 1 ? $data['duration'].' Days Single Trip' : $data['duration'].' Day Single Trip';
    }elseif($data['triptype'] == 'ST'){
        if($data['std-duration'] == 'std_one'){
            $data['trip_info'] = '1 Year Student Trip';
        }elseif($data['std-duration'] == 'std_two'){
            $data['trip_info'] = '2 Year Student Trip';
        }else{
            $days =  substr($data['std-duration'],4,strlen($data['std-duration']));
            $data['trip_info'] = $days.' Days Student Trip';
        }
    }
    
    $data['member_info'] = $data['travelcount'] >1 ? $data['travelcount'].' Travelers' : 'Single Traveler' ;
    
    $data['age'] = $data['age_list'];
    
    $data['sum-insured']  =  trim($this->getSumInsured($data['triptype'], $data['area'], $data['sum_insured'], 'up', 'Y'));
    unset($data['amt_duration']);
    unset($data['std_duration']);
    unset($data['sum_insured']);
    $data['location']  = $this->get_area_title($data); 
    $data['session_key']  = $trans_code;
    $data['trans_code']  = $trans_code;
    return $data;
  }

  public function get_area_title($request){
    if($request['triptype'] == 'ST'){
      switch ($request['area']){
      case 1 : return Travel_Constants::$WWD;
               break;
      case 2 : return Travel_Constants::$WWD_EXCL_USA;
               break;
                           
    }
    } else {
    switch ($request['area']){
      case 1 : return Travel_Constants::$WWD;
               break;
      case 2 : return Travel_Constants::$WWD_EXCL_USA_CAN;
               break;
      case 3 : return Travel_Constants::$ASIA_EXCL_JAPAN;
               break;
      case 4 : return Travel_Constants::$EURO;
               break;
      case 5 : return Travel_Constants::$AFRICA;
               break;
      case 6 : return Travel_Constants::$WWD_EXCL_USA;
               break;
      case 7 : return Travel_Constants::$SCHENGEN;
               break;                                     
    }
    }
  }
  
  public function getDobArray($doblist){
      $dob = ($doblist['cust_dob'] != ''|| $doblist['cust_dob'] != null) ? $doblist['cust_dob'] : $doblist['dob'];
      try {
         return explode(',', $dob);
      }catch (\Exception $e) {
        //echo 'Access Denied, Stop !';
        //exit;
      }   
  }  
  
 
  public function getCoverTitle($code){
    $result = TravelCoverageMaster::select(Travel_Constants::COV_MASTER['SH_TITLE'])->where(Travel_Constants::COV_MASTER['CODE'], $code)->get();
    return $result[0][Travel_Constants::COV_MASTER['SH_TITLE']];
  }

  public function getCoverName($code){
    $result = TravelCoverageMaster::select(Travel_Constants::COV_MASTER['TITLE'])->where(Travel_Constants::COV_MASTER['CODE'], $code)->get();
    return $result[0][Travel_Constants::COV_MASTER['TITLE']];
  }

  public function getSumInsured($type, $area, $si, $ctrl, $quote){
    if($ctrl == 'up'){
      $up = array();
       //For World Wide
      $up['S']['1']['20000']   = 30000;
      $up['S']['1']['30000']   = 50000;
      $up['S']['1']['50000']   = 100000;
      $up['S']['1']['100000']  = 200000;
      $up['S']['1']['200000']  = 250000;
      $up['S']['1']['250000']  = 300000;
      $up['S']['1']['300000']  = 500000;

      // Worldwide Excl. USA & Canda
      $up['S']['1']['20000']   = 30000;
      $up['S']['2']['30000']   = 50000;
      $up['S']['2']['50000']   = 100000;
      $up['S']['2']['100000']  = 200000;
      $up['S']['2']['200000']  = 250000;
      $up['S']['2']['250000']  = 300000;
      $up['S']['2']['300000']  = 500000;

      // For Asia
      $up['S']['3']['10000']  = 15000;
      $up['S']['3']['15000']  = 30000;
      $up['S']['3']['30000']  = 50000;
      $up['S']['3']['50000']  = 100000;
      $up['S']['3']['100000'] = 200000;

      //Europe
      $up['S']['4']['15000'] = 30000;
      $up['S']['4']['30000'] = 100000;

      // For Africa & Word Wide - Excluding USA
      $up['S']['5']['25000'] = 50000;
      $up['S']['5']['50000'] = 100000;

      // Word Wide - Excluding USA
      $up['S']['6']['30000']  = 50000;
      $up['S']['6']['50000']  = 100000;

      // For Schengen
      $up['S']['7']['20000']   = 30000;
      $up['S']['7']['30000']   = 50000;
      $up['S']['7']['50000']   = 100000;
      $up['S']['7']['100000']  = 200000;
      $up['S']['7']['200000']  = 500000;

      //Student Trip
      $up['ST']['20000']  = 30000;
      $up['ST']['30000']  = 50000;
      $up['ST']['50000']  = 100000;
      $up['ST']['100000'] = 250000;
      $up['ST']['250000'] = 300000;
      $up['ST']['300000'] = 500000;
      $up['ST']['500000'] = 1000000;

      //Annual Multi Trip
      $up['M']['25000']  = 50000;
      $up['M']['50000']  = 100000;
      $up['M']['100000'] = 250000;
      $up['M']['250000'] = 300000;
      $up['M']['300000'] = 500000;

      if($type === 'ST' || $type === 'M'){
        if(isset($up[$type][$si])){
          return ($quote === 'Y') ? $si : $up[$type][$si];
        }else {
          return $this->closestSI($si, $up[$type]);
        }  
      }else {
        if(isset($up[$type][$area][$si])){
          return ($quote === 'Y') ? $si : $up[$type][$area][$si];
        }else {
          return $this->closestSI($si, $up[$type][$area]);
        }
      }
      
    }

    if($ctrl == 'down'){
      $down = array();
      //For World Wide
      $down['S']['1']['550000']   = 500000;
      $down['S']['1']['500000']   = 300000;
      $down['S']['1']['300000']   = 250000;
      $down['S']['1']['250000']   = 200000;
      $down['S']['1']['200000']   = 100000;
      $down['S']['1']['100000']   = 50000;
      $down['S']['1']['50000']    = 30000;

      // Worldwide Excl. USA & Canda
      $down['S']['2']['550000']   = 500000;
      $down['S']['2']['500000']   = 300000;
      $down['S']['2']['300000']   = 250000;
      $down['S']['2']['250000']   = 200000;
      $down['S']['2']['200000']   = 100000;
      $down['S']['2']['100000']   = 50000;
      $down['S']['2']['50000']   = 30000;
      
      // For Asia
      $down['S']['3']['250000']  = 200000;
      $down['S']['3']['200000']  = 100000; 
      $down['S']['3']['100000']  = 50000;
      $down['S']['3']['50000']   = 30000;
      $down['S']['3']['30000']   = 15000;

      //Europe
      $down['S']['4']['200000'] = 100000;
      $down['S']['4']['100000'] = 30000;

      // For Africa & Word Wide - Excluding USA
      $down['S']['5']['200000']  = 100000;
      $down['S']['5']['100000']  = 50000;

       // Word Wide - Excluding USA
      $down['S']['6']['200000']   = 100000;
      $down['S']['6']['100000']   = 50000;
      
      //For  Schengen
      $down['S']['7']['550000']  = 500000;
      $down['S']['7']['500000']  = 200000;
      $down['S']['7']['200000']  = 100000;
      $down['S']['7']['100000']  = 50000;
      $down['S']['7']['50000']   = 30000;

      //Student Trip
      $down['ST']['1050000']  = 1000000;
      $down['ST']['1000000']  = 500000;
      $down['ST']['500000']   = 300000;
      $down['ST']['300000']   = 250000;
      $down['ST']['250000']   = 100000;
      $down['ST']['100000']   = 50000;
      $down['ST']['50000']    = 30000;

      //Annual Multi Trip
      $down['M']['550000']   = 500000;
      $down['M']['500000']   = 300000;
      $down['M']['300000']   = 250000;
      $down['M']['250000']   = 100000;
      $down['M']['100000']   = 50000;

      if($type === 'ST' || $type === 'M'){
        if(isset($down[$type][$si])){
          return ($quote === 'Y') ? $si : $down[$type][$si];
        }else {
          return $this->closestSI($si, $down[$type]);
        }  
      }else {
        if(isset($down[$type][$area][$si])){
          return ($quote === 'Y') ? $si : $down[$type][$area][$si];
        }else {
          return $this->closestSI($si, $down[$type][$area]);
        }
      }
    }
    
  }

  private function closestSI($needle, $haystack) {
   $closest = null;
   foreach ($haystack as $item) {
      if ($closest === null || abs($needle - $closest) > abs($item - $needle)) {
         $closest = $item;
      }
   }
   return $closest;
  }

  public function getCmpSingleProduct($cmp = NULL){
    $list = [];
    $cmp_list = ['hdfc'=>['name'=>'Hdfc Ergo','logo'=>'hdfc_logo.png']
            ,"star"=>['name'=>'Star Health and Allied Insurance','logo'=>'star_logo.png']
            ,"fggi"=>['name'=>'Future Generali','logo'=>'fggi_logo.png']
            ,"tata"=>['name'=>'Tata Aig','logo'=>'tata_logo.png']
            ,"religare"=>['name'=>'Religare','logo'=>'religare_logo.png']
          ];

    if(!isset($cmp))
      return $cmp_list;

    if(array_key_exists($cmp,$cmp_list))
        $list[] = $cmp_list[$cmp];

    return $list;
  }
}  
