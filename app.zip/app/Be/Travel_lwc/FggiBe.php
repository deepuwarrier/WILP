<?php 
namespace App\Be\Travel;
use App\Libraries\TravelLib;
use App\Constants\Travel_Constants;
use App\Constants\Common_Constants;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelCity;
use App\Models\Travel\TravelState;
use App\Models\Travel\TravelPurpose;
use App\Models\Travel\data\Fggi\FggiRequest;
use App\Models\Travel\data\QuoteReqData;
use App\Models\Travel\TravelPolicy;
use App\Models\Travel\TravelRelationship;
use App\Models\Travel\TravelCountry;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Be\Travel\TravelProposalBe;
use Log;

class FggiBe{

    private $lib;

    public function __construct(){
        date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE); 
        $this->lib = new TravelLib;
    }

    public function pre_quote_filter($quote_req_data) {
        return $quote_req_data;
    }
    
    public function post_quote_filter($quote_resp_data) {
        return $quote_resp_data;
    }

    public function populate_quote_data($trans_code){
        $usr_tbl = new TravelUsrData;
        $user_data  = $usr_tbl->get_all_data($trans_code);
        $quote_req_data = new QuoteReqData();
        $quote_req_data->set_session_key($trans_code);
        $quote_req_data->set_trans_code($trans_code);
        $quote_req_data->set_trip_type($user_data['triptype']);
        $quote_req_data->set_area($user_data['area']);
        $quote_req_data->set_duration($user_data['duration']);
        $quote_req_data->set_member_count($user_data['travelcount']);
        $quote_req_data->set_dob_list(explode(',', $user_data['dob']));
        $quote_req_data->set_age_list(explode(',', $user_data['age_list']));
        $quote_req_data->set_relationship(explode(',', $user_data['relationship']));
        $quote_req_data->set_gender(explode(',', $user_data['gender']));
        $quote_req_data->set_amt_duration($user_data['amt_duration']);
        $quote_req_data->set_sum_insured($user_data['sum_insured']);
        $quote_req_data->set_student_duration($user_data['std_duration']);
        return $quote_req_data;
    }

    public function product_map($quote_req_data) {
        if($this->check_si($quote_req_data->get_trip_type(), 
                           $quote_req_data->get_sum_insured(),
                           $quote_req_data->get_area(),
                           $quote_req_data->get_member_count())){
            if($quote_req_data->get_trip_type() == 'S'){    
              if($this->check_age($quote_req_data->get_dob_list(),
                                  $quote_req_data->get_age_list(),
                                  $quote_req_data->get_relationship(),
                                  $quote_req_data->get_member_count(),
                                  $quote_req_data->get_duration(),
                                  'SING')){  
                return 'single_trip';
              }else {
                return null;
              }
            }

            if($quote_req_data->get_trip_type() == 'M'){
              if($this->check_age($quote_req_data->get_dob_list(),
                                  $quote_req_data->get_age_list(),
                                  $quote_req_data->get_relationship(),
                                  $quote_req_data->get_member_count(),
                                  $quote_req_data->get_amt_duration(),
                                  'AMT')){  
                return 'multi_trip';
              }else {
                return null;
              }
            } 

            return null; 
        
        } 
        return null;
    }

    public function populate_quote_request($quote_req_data){
        $start_date  = $this->get_start_date();
        $end_date    = $this->get_end_date($start_date, $quote_req_data->get_duration());
        $duration    = $this->get_duration($quote_req_data->get_duration(),
                                           $quote_req_data->get_amt_duration(),
                                           $quote_req_data->get_trip_type());

        $agent_code  = Travel_Constants::$FGGI_AGENT_CODE;
        $branch_code = Travel_Constants::$FGGI_BRANCH_CODE;
        $major_class = Travel_Constants::$FGGI_MAJOR_CLASS;

        $contract_type = $this->get_contract_type($quote_req_data->get_area(),
                                                  $quote_req_data->get_trip_type(),
                                                  $quote_req_data->get_member_count(),
                                                  $quote_req_data->get_dob_list());
        $coverage_name = $this->get_coverage_name($contract_type,
                                                  $quote_req_data->get_trip_type(),
                                                  $quote_req_data->get_member_count());
        $coverage_value = $this->get_coverage_value($contract_type,
                                                  $quote_req_data->get_trip_type(),
                                                  $quote_req_data->get_member_count());
        $method        = 'ENQ';
        $policy_issue_type = 'I';
        $product_name = $this->get_product_name($quote_req_data->get_trip_type());
        $family_type  = $this->get_family_type($quote_req_data->get_member_count(), 
                                               $quote_req_data->get_area());
        $country      = $this->get_country($quote_req_data->get_area());
        $continent    = $this->get_continent($quote_req_data->get_area());
        $visa_name    = 'Resident';
        $visa_value   = 'A';
        $purpose_name = 'Leisure';
        $purpose_value = 'L';
        $dob_list     = $this->get_dob_list($quote_req_data->get_dob_list());
        $self_dob     = $dob_list[0];


        // Policy Header
        $data = array();
        $data['PolicyStartDate'] = $start_date;
        $data['PolicyEndDate'] = $end_date;
        $data['AgentCode'] = $agent_code;
        $data['BranchCode'] = $branch_code;
        $data['MajorClass'] = $major_class;
        $data['ContractType'] = $contract_type;
        $data['METHOD'] = $method;
        $data['PolicyIssueType'] = $policy_issue_type;
        $data['PolicyNo'] = '';
        $data['ClientID'] = '';
        $data['ReceiptNo'] = '';
        $policy_header_xml = $this->generate_xml($data);
        
        // MISP
        $data = array();
        $data['Type'] = '';
        $data['PanNo'] = '';
        $misp_xml = $this->generate_xml($data);

        // Client
        $data = array();
        $data['ClientType'] = '';
        $data['CreationType'] = '';
        $data['Salutation'] = '';
        $data['FirstName'] = '';
        $data['LastName'] = '';
        $data['DOB'] = '';
        $data['Gender'] = '';
        $data['MaritalStatus'] = '';
        $data['Occupation'] = '';
        $data['PANNo'] = '';
        $data['GSTIN'] = '';
        $data['AadharNo'] = '';
        $data['CKYCNo'] = '';
        $data['EIANo'] = '';
        $address = array();
        $address['AddrLine1'] = '';
        $address['AddrLine2'] = '';
        $address['AddrLine3'] = '';
        $address['Landmark'] = '';
        $address['Pincode'] = '';
        $address['City'] = '';
        $address['State'] = '';
        $address['Country'] = '';
        $address['AddressType'] = '';
        $address['HomeTelNo'] = '';
        $address['OfficeTelNo'] = '';
        $address['FAXNO'] = '';
        $address['MobileNo'] = '';
        $address['EmailAddr'] = '';
        $address_xml = $this->generate_xml($address);
        $data['Address1'] = $address_xml;
        $data['Address2'] = $address_xml;
        $client_xml = $this->generate_xml($data);

        // Receipt
        $data = array();
        $data['UniqueTranKey'] = '';
        $data['CheckType'] = '';
        $data['BSBCode'] = '';
        $data['TransactionDate'] = '';
        $data['ReceiptType'] = '';
        $data['Amount'] = '';
        $data['TCSAmount'] = '';
        $data['TranRefNo'] = '';
        $data['TranRefNoDate'] = '';
        $receipt_xml = $this->generate_xml($data);

        // Risk
        $data = array();
        $data['SubProductName'] = $product_name;
        $data['FamilyType'] = $family_type;
        $countries = array();
        $countries['Countries'] = $country;
        $countries['Continent'] = $continent;
        $countries_xml = $this->generate_xml($countries, 'Countries');
        $data['VistingCountries'] = $countries_xml;
        $data['CoverageName'] = $coverage_name;
        $data['CoverageValue'] = $coverage_value;
        $data['PlanName'] = '';
        $data['PlanValue'] = '';
        $data['VisaName'] = $visa_name;
        $data['VisaValue'] =  $visa_value;
        $data['PurposeName'] =  $purpose_name;
        $data['PurposeValue'] =  $purpose_value;
        $data['DateOfDeparture'] = $start_date;
        $data['DateOfreturn'] = $end_date;
        $data['TripDuration'] = $duration;
        $insured_xml = $this->get_insured_details_quote($dob_list, 
                                    $quote_req_data->get_gender(),
                                    $quote_req_data->get_relationship());
      
        $sponsor = array();
        $sponsor['Name'] = '';
        $sponsor['DOB'] = '';
        $sponsor['EmailId'] = '';
        $sponsor['Phone'] = '';
        $sponsor['Address'] = '';
        $sponsor['Relation'] = '';
        $sponser_xml = $this->generate_xml($sponsor);
        $university = array();
        $university['Name'] = '';
        $university['Address'] = '';
        $university['EmailId'] = '';
        $university_xml = $this->generate_xml($university);
        $risk_xml = $this->generate_xml($data);
        $risk_xml.= $insured_xml;
        $data = array();
        $data['Sponsor'] = $sponser_xml;
        $data['University'] = $university_xml;
        $risk_xml .= $this->generate_xml($data);

        // Root
        $data = array();
        $data['Uid'] = $this->get_unique_id();
        $data['VendorCode'] = Travel_Constants::$FGGI_VENDOR_CODE;
        $data['VendorUserId'] = '';
        $data['PolicyHeader'] = $policy_header_xml;
        $data['POS_MISP'] = $misp_xml;
        $data['Client'] = $client_xml;
        $data['Receipt'] = $receipt_xml;
        $data['Risk'] =  $risk_xml;
        $root_xml = $this->generate_xml($data, 'Root');
        Log::info($root_xml);
        $quote_req = new FggiRequest;
        $quote_req->set_product('Travel');
        $quote_req->set_xml($root_xml);

        return $quote_req;
    }

    private function get_relationship($relationship_code){
      $relation_tbl = new TravelRelationship;
      $column       = array('relationship_name');
      $check_values = array('relationship_id' => $relationship_code);
      $result = $relation_tbl->get_data($column,$check_values);
      $relationship = $result[0]['relationship_name'];
      if($relationship == 'Wife' || $relationship == 'Husband'){
        return 'Spouse';
      } else {
        return ucfirst(strtolower($relationship));
      }
    }

    private function get_insured_details_quote($dob_list, $gender, $relationship_list){
        $insured_xml = '';
        foreach($relationship_list as $index => $relationship){
        $insured = array();
        $insured['Name'] = 'John Doe';
        $insured['DOB'] = $dob_list[$index];
        $insured['Gender'] = $gender[$index];
        $insured['RelationShip'] = $this->get_relationship($relationship);
        $insured['PassportNo'] = 'Q6555555';
        $insured['OccupationName'] = '';
        $insured['OccupationValue'] = 'SVCM';
        $insured['NomineeName'] = 'Ben Stephen';
        $insured['NomineeRelationShip'] = 'Spouse';
        $insured_xml .= $this->generate_xml($insured, 'Insured');
        }
        return $insured_xml;
    }

    private function get_start_date(){
        return date("d/m/Y");
    }

    private function get_end_date($date,$days){
        $date = \DateTime::createFromFormat('d/m/Y', $date);
        $date = $date->format('Y-m-d');
        $date = strtotime("+".($days-1)." days", strtotime($date));
        $date = date("d/m/Y", $date);
        return $date;
    }

    private function get_dob_list($dob_list){
        $list = array();
        foreach($dob_list as $index => $dob){
            $date = \DateTime::createFromFormat('d-m-Y', $dob);
            $list[$index] = $date->format('d/m/Y');
        }

        return $list;
    }

    private function get_duration($duration, $amt_duration, $trip_type){
        if($trip_type == 'S'){
            return $duration;
        }
        if($trip_type == 'M'){
            if($amt_duration == 'SM'){
                return 30;
            }

            if($amt_duration == 'ME'){
                return 45;
            }

            if($amt_duration == 'LA'){
                return 60;
            }

            if($amt_duration == 'L90'){
                return 90;
            }

            return false;
        }
        return false;
    }

    private function get_contract_type($area_code, $trip_type, $member_count, $dob_list){
        $primary_member_age =  $this->lib->calculateAge($dob_list[0]);
        //Future Travel Suraksha-World - Individual
        if(($area_code == 1 || $area_code == 2) 
           && $trip_type == 'S' 
           && $member_count == 1){
            if($primary_member_age > 70){
                // Prime
                return 'TSS';
            }
            return 'FTI';
        }

        //Future Travel Suraksha-Select
        if(($area_code == 1 || $area_code == 2) 
           && $trip_type == 'S' 
           && $member_count > 1){
           return 'TSS';
        }

        //Future Travel Suraksha-World - Annual Multi Trip
        if(($area_code == 1 || $area_code == 2)  
           && $trip_type == 'M' 
           && $member_count == 1){
           return 'FTM';
        }

        //Future Travel Suraksha Schengen Annual Multi Trip
        if($area_code == 7 
           && $trip_type == 'M' 
           && $member_count == 1){
           return 'FST';
        }

        //Future Travel Suraksha Schengen - Family
        if($area_code == 7 
           && $trip_type == 'S' 
           && $member_count > 1){
           return 'FST';
        }

        //Future Travel Suraksha Schengen - Individual
        if($area_code == 7 
           && $trip_type == 'S' 
           && $member_count == 1){
           return 'FST';
        }

        return false;
    }

    private function get_coverage_name($contract_type, $trip_type, $member_count){
        if($contract_type == 'FTI'){
            return 'Future Travel Suraksha-World - Individual';
        }

        if($contract_type == 'TSS'){
            return 'Future Travel Suraksha-Select';
        }

        if($contract_type == 'FTM'){
            return 'Future Travel Suraksha-World - Annual Multi Trip';
        }

        if($contract_type == 'FST' && $trip_type == 'M'){
            return 'Future Travel Suraksha Schengen Annual Multi Trip';
        }

        if($contract_type == 'FST' && $trip_type == 'S' && $member_count > 1){
            return 'Future Travel Suraksha Schengen - Family';
        }

        if($contract_type == 'FST' && $trip_type == 'S' && $member_count == 1){
            return 'Future Travel Suraksha Schengen - Individual';
        }

        return false;
    }

    private function get_coverage_value($contract_type, $trip_type, $member_count){
        if($contract_type == 'FTI'){
            return 'TIW';
        }

        if($contract_type == 'TSS'){
            return 'SSW';
        }

        if($contract_type == 'FTM'){
            return 'TMW';
        }

        if($contract_type == 'FST' && $trip_type == 'M'){
            return 'TSM';
        }

        if($contract_type == 'FST' && $trip_type == 'S' && $member_count > 1){
            return 'TSF';
        }

        if($contract_type == 'FST' && $trip_type == 'S' && $member_count == 1){
            return 'TSI';
        }

        return false;
    }

    private function get_product_name($trip_type){
        if($trip_type == 'S'){
            return 'Single Trip';
        }

        if($trip_type == 'M'){
            return 'Multi Trip';
        }

        return false;
    }

    private function get_visa_name($visa_type){
        if($visa_type == 'A'){
            return 'Resident';
        }

        if($visa_type == 'B'){
            return 'Travel';
        }

        return false;
    }

    private function get_family_type($member_count, $area){
        if($member_count == 1){
            return 'Individual';
        }

        if($member_count > 1 && $area == 7){
            return 'Family';
        }else{
            return 'Individual';
        }

        return false;
    }

    private function get_country($area_code){

        if($area_code == 1){
            return 'United States';
        }

        if($area_code == 2){
            return 'South Africa';
        }
        
        if($area_code == 7){
            return 'Poland';
        }

        return false;
    }

    private function get_continent($area_code){
        
        if($area_code == 1){
            return 'Americas';
        }

        if($area_code == 2){
            return 'Africa';
        }

        if($area_code == 7){
            return 'Europe';
        }
    }

    private function get_unique_id(){
        $date = date_create();
        return date_format($date,'U');
    }

    private function generate_xml($array, $tag = null){
        $xml = ($tag) ? '<'.$tag.'>' : '';
        foreach($array as $attribute => $value){
            $xml .=  '<'.$attribute.'>'.$value.'</'.$attribute.'>';
        }
        $xml .= ($tag) ? '</'.$tag.'>': '';
        return $xml;
    }

    private function check_children($relationship, $dob_list){
      $lib     = new TravelLib;
      $adults  = 0; 
      $children = 0;
      $id      = array();
      for($i = 0; $i < sizeof($relationship); $i++){
        if($relationship[$i] == 7){
          $id[] = $i;
        }

        if($relationship[$i] == 6){
          $id[] = $i;
        }
      }

      // Removing duplicate values from Array
      $id = (array_unique($id));
      for($i  = 0; $i < sizeof($id); $i++){
         $key = $id[$i];
         // Calculating the Age of Children
         $age = $lib->calculateYMD($dob_list[$key]);
         for($j=1; $j<26; $j++){
            if($j > 5){
                if($age == $j.'M'){
                    $children++; 

                }
            }
            if($age == $j.'Y'){
                $children++;
            }
         }
      }
      $children = (sizeof($id) == $children) ? $children : 0;
      return $children;
  }

    private function check_age($dob_list, $age_list, $relationship , $member_count, $duration ,$type){
        $age = $this->lib->calculateAge($dob_list[0]);
        if($type === 'SING'){
          if($member_count < 2){  
              if($age >=18 && $age < 81){
                  return $age;  
              } else {
                  return false;
              }
          }else{

            // Restirction for age < 6M
            $child_age = array('1M','2M','3M','4M','5M');
            foreach($age_list as $key => $age) {
                if(in_array($age, $child_age)){
                    return false;
                }
            }
            foreach($dob_list as $key => $dob) {
                $age = $this->lib->calculateAge($dob);
                if($age > 70){
                    return false;
                }
            }
           
            if(in_array('4', $relationship) || in_array('5', $relationship) || in_array('8', $relationship)){
                return false;
            }
            if(in_array('6', $relationship) || in_array('7', $relationship)){
                $child = $this->check_children($relationship, $dob_list);
                if($child == 0 || $child > 2){
                    return false;
                }
            }
            return true;
          }   
        }

        if($type === 'AMT' && 
           $member_count == 1 &&
           ($duration == 'SM'|| $duration == 'ME' || $duration == 'LA' || $duration == 'L90')){
          if($age >=18 && $age < 71){
              return $age;  
          } else {
              return false;
          }
        }

        return false;

    } 

    public function check_si($type, $si, $area_code, $member_count){
        if($type == 'S' && $member_count == 1 && ($area_code == 1 || $area_code == 2)){
            $si_list = array('50000', '100000','250000','500000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }

        if($type == 'S' && $member_count > 1 && ($area_code == 1 || $area_code == 2)){
            $si_list = array('50000', '100000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }

        if($type == 'S' && $member_count == 1 && $area_code == 7){
            $si_list = array('30000', '50000', '100000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }

        if($type == 'S' && $member_count > 1 && $area_code == 7){
            $si_list = array('30000', '50000', '100000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }

        if($type == 'M' && $area_code == 1){
            $si_list = array('250000','500000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }

        if($type == 'M' && $area_code == 7){
            $si_list = array('50000','100000');
            if(in_array($si,$si_list)){
                return true;
            } else {
              return false;
            } 
        }
        return false;
    }

    public function parse_quote_response($raw_quote_resp,$quote_req_data){
        $quote_resp_data = array();
        $quote_counter   = 0;
        $filter_risk_type = '';
        if($raw_quote_resp){
            $response = $raw_quote_resp->CreatePolicyResult;
            $quote_resp_obj = new \SimpleXMLElement($response);
            if(isset($quote_resp_obj->Status) && $quote_resp_obj->Status == 'Fail'){
                return null;
            }

            foreach ($quote_resp_obj->Policy->TravelPlan as $key => $plan) {
                $quote_resp_sum_insured = str_replace( ",", "",(string)$plan->SumInsured);
                if($quote_req_data->get_trip_type() == 'S' && $quote_req_data->get_member_count() < 2 && $quote_req_data->get_area() != 7){
                    $dob_list = $quote_req_data->get_dob_list();
                    $age = $this->lib->calculateAge($dob_list[0]);
                    if($age > 70){
                        if($quote_req_data->get_area() == 1){
                            $filter_risk_type = 'SSW';
                        }

                        if($quote_req_data->get_area() == 2){
                            $filter_risk_type = 'SSE';
                        }
                        
                    }elseif($quote_req_data->get_area() == 1){
                        $filter_risk_type = 'TIW';
                    }elseif($quote_req_data->get_area() == 2){
                        $filter_risk_type = 'TIE';
                    }
                    
                }elseif($quote_req_data->get_trip_type() == 'S' && $quote_req_data->get_member_count() >= 2 && $quote_req_data->get_area() != 7){
                    if($quote_req_data->get_area() == 1){
                        $filter_risk_type = 'SSW';
                    }
                    if($quote_req_data->get_area() == 2){
                        $filter_risk_type = 'SSE';
                    }
                }else{
                    $filter_risk_type =(string)$plan->RiskType;
                }
                if($quote_req_data->get_sum_insured() == $quote_resp_sum_insured){
                    $quote_proceed_flag = false;
                    if($quote_req_data->get_trip_type() == 'S'){
                        $quote_proceed_flag = true;
                    }
                    if($quote_req_data->get_trip_type() == 'M'){
                        if($quote_req_data->get_amt_duration() == 'SM' && 
                            ($plan->PlanCode == 'G30' || 
                             $plan->PlanCode == 'P30' ||
                             $plan->PlanCode == 'SG3' ||
                             $plan->PlanCode == 'SL3' )){
                            $quote_proceed_flag = true;
                        }
                        if($quote_req_data->get_amt_duration() == 'ME' && 
                            ($plan->PlanCode == 'G45' || 
                             $plan->PlanCode == 'P45' ||
                             $plan->PlanCode == 'SG4' ||
                             $plan->PlanCode == 'SL4' )){
                            $quote_proceed_flag = true;
                        }
                        if($quote_req_data->get_amt_duration() == 'LA' && 
                            ($plan->PlanCode == 'SG6' ||
                             $plan->PlanCode == 'SL6' )){
                            $quote_proceed_flag = true;
                        }
                        if($quote_req_data->get_amt_duration() == 'L90' && 
                            ($plan->PlanCode == 'SG9' ||
                             $plan->PlanCode == 'SL9' )){
                            $quote_proceed_flag = true;
                        }
                    } 
                    if($quote_proceed_flag && ($filter_risk_type == (string)$plan->RiskType) && ((string)$plan->ContractType != 'FTF')){
                    $quote_plan_name = explode('-', $plan->PlanName);
                    $quote_resp_data[$quote_counter]['company_name'] = 'Future Generali';
                    $quote_resp_data[$quote_counter]['url_code']     = 'fggi';

                    if((string)$plan->RiskType == 'TIE' || (string)$plan->RiskType == 'TIW'){
                        $quote_resp_data[$quote_counter]['ProductDescription'] = $quote_plan_name[0].' - '.$quote_plan_name[1];
                    }else{
                        $quote_resp_data[$quote_counter]['ProductDescription'] = trim($quote_plan_name[0]);
                    }  


                    $quote_resp_data[$quote_counter]['session_key'] = $quote_req_data->get_session_key();
                    $quote_resp_data[$quote_counter]['trans_code']  = $quote_req_data->get_trans_code();
                    $quote_resp_data[$quote_counter]['NetPremiumAmt'] = round((int)$plan->PremiumWithServiceTax);
                    $quote_resp_data[$quote_counter]['TotalTaxAmt'] = round((int)$plan->ServiceTaxAmount);
                    $quote_resp_data[$quote_counter]['CoverageValue'] = (string)$plan->RiskType;
                    $quote_resp_data[$quote_counter]['PlanCode'] = (string)$plan->PlanCode;
                    if($quote_resp_data[$quote_counter]['CoverageValue'] == 'TIE' || $quote_resp_data[$quote_counter]['CoverageValue'] == 'TIW'){
                        $quote_resp_data[$quote_counter]['PlanDesc'] = trim($quote_plan_name[2]);
                    }else{
                        $quote_resp_data[$quote_counter]['PlanDesc'] = (isset($quote_plan_name[1])) ? trim($quote_plan_name[1]) : '';
                    }

                    if((string)$plan->RiskType == 'TSM'){
                        $quote_resp_data[$quote_counter]['ProductDescription'] = $quote_resp_data[$quote_counter]['ProductDescription'].' Schengen';
                    }


                    $quote_resp_data[$quote_counter]['companyId'] = $this->lib->get_company_code('fggi');
                    $quote_resp_data[$quote_counter]['logo'] = 'image/logos/'.$quote_resp_data[$quote_counter]['companyId'].'_logo.png';
                   
                    $quote_resp_data[$quote_counter]['productCode'] = (string)$plan->ContractType;
                    $quote_resp_data[$quote_counter]['destinationCode'] = '';
                    $quote_resp_data[$quote_counter]['sum-insured'] = $quote_req_data->get_sum_insured();
                    $quote_resp_data[$quote_counter]['policyId'] = uniqid();
                    

                    $sv_quote     = $quote_resp_data[$quote_counter];
                    $sv_break_up  = array();
                    foreach ($plan->TravellerBrakup->TravelPlanBrakup as $bkp => $data) {
                        $sv_break_up[] = $data->Premium;
                    }
                    $sv_quote['insurer']     = implode(',',$sv_break_up);
                    $sv_quote['addon_id']    = null;
                    $sv_quote['addon_value'] = null;
                    $this->save_quote($sv_quote);
                    $quote_counter++;
                    }// End quote_proceed_flag
                }
            }
            return $quote_resp_data;
        }
    }

    private function save_quote($response){ 
      $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
      $exists     = Storage::disk('local')->exists(
                    Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
      if($exists){
        $data = json_decode(Storage::get(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
        $data['fggi'][$response['policyId']] = $response;
        Storage::disk('local')->put(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
      }else {
        $quote['fggi'][$response['policyId']] = $response;
        Storage::disk('local')->put(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($quote)); 
      }
    }

    public function clean_quote(){
        $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
        $exists     = Storage::disk('local')->exists(
            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
        if($exists){
            $data = json_decode(Storage::get(
                Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
            $data['fggi'] = array();
            Storage::disk('local')->put(
                Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
        }
    }

    public function get_proposal_inputs($trans_code){
        $company_column = 'fggi_code';
        $bl = new TravelProposalBe;
        $data = $bl->get_proposal_inputs($trans_code, $company_column);
        
        // Setting Trip Start Date 
        $data['userdata']['trip_start_date'] = $this->get_trip_start_date($data['userdata']['trip_start_date'], $data['userdata']);

        // Setting Trip End Date 
        $data['userdata']['trip_end_date'] = $this->get_trip_end_date($data['userdata']);

        // Purpose of visit
        $data['visa_type_list'] = array( 0 => array ('visa_code' => 'A', 
                                                     'visa_name' => 'Resident'),
                                         1 => array ('visa_code' => 'B', 
                                                     'visa_name' => 'Travel'));
        // Purpose of visit
        $data['marital_status_list'] = array( 0 => array ('status_code' => 'S', 
                                                          'status_name' => 'Single'),
                                              1 => array ('status_code' => 'M', 
                                                          'status_name' => 'Married'));
       
        // Country List
        $continent = $this->get_continent_list($data['userdata']['area']);
        $cntry_tbl  = new TravelCountry;
        $column     = array('country_name', $company_column);
        $check_values = $continent;
        try{
          $data['country_list'] = $cntry_tbl->get_data_continent($column,$check_values);
        }catch(\Exception $e){
          $data['country_list'] = null;
        }

        if($data['userdata']['travelcount'] < 2){
            $data['en_marital_status'] = true;
        }

        if($data['userdata']['area'] == 7){
            $data['visa_type_list'] = array( 0 => array ('visa_code' => 'D',  
                                                         'visa_name' => 'Schengen'),
                                             1 => array ('visa_code' => 'B', 
                                                         'visa_name' => 'Travel'));
        }

        return $data;
    }
    
    private function get_continent_list($area){
        if($area == 1){
            return array('Pacific','Africa','Antartica','Americas');
        }

        if($area == 2){
            return array('Pacific','Africa','Antartica');
        }

        if($area == 7){
            return array('Europe');
        }
        
        return false;
    }
    private function get_trip_start_date($date, $userdata){
        $lib = new TravelLib;
        $result = array();
        $duration = 179;
        $result['selected_date'] = ($date) ? $date : date("d-m-Y");
        $result['min_date']      = date("d-m-Y");
        $result['max_date']      = $lib->add_days_with_date(date("d-m-Y"), $duration);
        if($userdata['triptype'] == 'ST'){
            $result['max_duration'] = $lib->map_student_duration($userdata['std_duration']);

        }
        if($userdata['triptype'] == 'S'){
            $result['max_duration'] = $userdata['duration'];
        }
        if($userdata['triptype'] == 'M'){
            $result['max_duration'] = '365';
        }

        return $result;
    } 

    private function get_trip_end_date($userdata){
        $lib = new TravelLib;
        if($userdata['triptype'] == 'M'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], '364');
        }

        if($userdata['triptype'] == 'S'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $userdata['duration'] - 1);
        }

        if($userdata['triptype'] == 'ST'){
          $duration = $lib->map_student_duration($userdata['std_duration']);
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $duration - 1);
        }

        
    } 

    public function set_proposal_data($data){
        $trans_code  = $data['trans_code'];
        $section     = $data['id'];
        $usr_tbl     = new TravelUsrData;
        $check_value = array('trans_code' => $trans_code);
       
        // Unsetting the extra values
        unset($data['trans_code']);
        unset($data['id']);
        unset($data['_token']);
        
        if($section == 'travel'){
            $data['name'] = implode(',',$data['name']);
            $data['dob']  = implode(',',$data['dob']);
            $data['passport']  = implode(',',$data['passport']);
            $data['occupation']  = implode(',',$data['occupation']);
            $data['visa_type']  = implode(',',$data['visa_type']);
        }
        if($section == 'medical_his'){
            if(isset($data['ped_choice'])){
                $ped['ped_choice'] = $data['ped_choice'];
                $ped['ped_details'] = $data['ped_details'];
                $data = array();
                $data['ped'] = json_encode($ped);
            }else{
                $data['ped'] = null;
            }          
        }
        $usr_tbl->set_data($data, $check_value);
       
    }

    private function format_date($date){
        $date = \DateTime::createFromFormat('d-m-Y', $date);
        return $date->format('d/m/Y');
    }

    private function get_name_details($name){
      $name = explode(',', $name);
      $member_list = array();
      foreach ($name as $key => $value) {
        $member_name = explode(' ', $value);
        if(sizeof($member_name) == 2){
          $member_list[$key]['fname'] =  strtoupper($member_name[0]);
          $member_list[$key]['mname'] = '';
          $member_list[$key]['lname'] =  strtoupper($member_name[1]);
        }

        if(sizeof($member_name) >= 3){
            $member_list[$key]['fname'] = strtoupper($member_name[0]);
            $member_list[$key]['mname'] = strtoupper($member_name[1]);
            $member_list[$key]['lname'] = strtoupper($member_name[2]);
        }
      }
      return $member_list;
    }

    private function get_quote_data($company){
        $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
        $exists     = Storage::disk('local')->exists(
                      Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
        if($exists){
          $data = json_decode(Storage::get(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
          return $data[$company];
        }
    }

    public function check_policy_ped($trans_code){
        $usr_tbl    = new TravelUsrData;
        $column     = array('ped');
        $userdata   = $usr_tbl->get_data($column,$trans_code);
        $ped        = json_decode($userdata['ped'], true);
        if($ped){
            if(isset($ped['ped_choice']) && isset($ped['ped_choice']['medical_history'])){
                return true;
            }
        }
        return false;
    }

    public function populate_policy_request($trans_code){
        $usr_tbl     = new TravelUsrData;
        $userdata   = $usr_tbl->get_all_data($trans_code);
        $start_date  = $this->format_date($userdata['trip_start_date']);
        $transaction_date = $this->get_start_date();
        $end_date    = $this->format_date($userdata['trip_end_date']);
        $duration    = $this->get_duration($userdata['duration'],
                                           $userdata['amt_duration'],
                                           $userdata['triptype']);

        $agent_code  = Travel_Constants::$FGGI_AGENT_CODE;
        $branch_code = Travel_Constants::$FGGI_BRANCH_CODE;
        $major_class = Travel_Constants::$FGGI_MAJOR_CLASS;
        $dob         = explode(',', $userdata['dob']);
        $contract_type = $this->get_contract_type($userdata['area'],
                                                  $userdata['triptype'],
                                                  $userdata['travelcount'],
                                                  $dob);
        $coverage_name = $this->get_coverage_name($contract_type,
                                                  $userdata['triptype'],
                                                  $userdata['travelcount']);
        $method       = 'ENQ';
        $policy_issue_type = 'I'; 
        $product_name = $this->get_product_name($userdata['triptype']);
        $family_type  = $this->get_family_type($userdata['travelcount'], $userdata['area']);
        $visa_name    = $this->get_visa_name($userdata['visa_type']);
        $visa_value   = $userdata['visa_type'];
        session(['fggi_contract_type' => $contract_type]);

        $purpose_value = $userdata['purpose'];
        $purpose_tbl   = new TravelPurpose;
        $column = array('purpose_name');
        $check_values = array($userdata['company_column'] => $purpose_value);
        try{
        $purpose = $purpose_tbl->get_value($column, $check_values);
        $purpose_name = $purpose[0]['purpose_name'];
        }catch(\Exception $e){
            
        }
        $name       = $this->get_name_details($userdata['name']);
        $title      = explode(',', $userdata['title']);
        $passport   = explode(',', $userdata['passport']);
        $relationship =  explode(',', $userdata['relationship']); 
        $occupation = explode(',', $userdata['occupation']);
        $gender     = explode(',', $userdata['gender']);
        $dob_list     = $this->get_dob_list($dob);
        $self_dob     = $dob_list[0];

        // Policy Header
        $data = array();
        $data['PolicyStartDate'] = $start_date;
        $data['PolicyEndDate'] = $end_date;
        $data['AgentCode'] = $agent_code;
        $data['BranchCode'] = $branch_code;
        $data['MajorClass'] = $major_class;
        $data['ContractType'] = $contract_type;
        $data['METHOD'] = $method;
        $data['PolicyIssueType'] = $policy_issue_type;
        $data['PolicyNo'] = '';
        $data['ClientID'] = '';
        $data['ReceiptNo'] = '';
        $policy_header_xml = $this->generate_xml($data);
        
        // MISP
        $data = array();
        $data['Type'] = ''; 
        $data['PanNo'] = '';
        $misp_xml = $this->generate_xml($data);

        // Client
        $data = array();
        $data['ClientType'] = 'I';
        $data['CreationType'] = 'C';
        $data['Salutation'] = strtoupper($title[0]);
        $data['FirstName'] = strtoupper($name[0]['fname']);
        $data['LastName'] = strtoupper($name[0]['lname']);
        $data['DOB'] = $dob_list[0];
        $data['Gender'] = $gender[0];
        if($userdata['travelcount'] > 1){
            $data['MaritalStatus'] = 'M';
        }else{
            $data['MaritalStatus'] = $userdata['marital_status'];
        }
        $data['Occupation'] = $occupation[0];
        $data['PANNo'] = '';
        $data['GSTIN'] = '';
        $data['AadharNo'] = $userdata['aadhaar_num'];
        $data['CKYCNo'] = '';
        $data['EIANo'] = '';
        $address = array();
        $address['AddrLine1'] = strtoupper($userdata['house_name']); 
        $address['AddrLine2'] = strtoupper($userdata['street']); 
        $address['AddrLine3'] = '';
        $address['Landmark'] = '';
        $address['Pincode'] = $userdata['pincode']; 
        $address['City'] = strtoupper($userdata['city']);
        $column = array('state_name');
        $check_values = array('state_code' => $userdata['state']);
        $state_tbl = new TravelState;
        try{
        $state = $state_tbl->get_data($column, $check_values);
        $address['State'] = strtoupper($state[0]['state_name']);
        }catch(\Exception $e){

        }
        $address['Country'] = 'IND';
        $address['AddressType'] = 'R';
        $address['HomeTelNo'] = '';
        $address['OfficeTelNo'] = '';
        $address['FAXNO'] = '';
        $address['MobileNo'] = $userdata['mobile'];
        $address['EmailAddr'] = strtoupper($userdata['email']);
        $address_xml = $this->generate_xml($address);
        $data['Address1'] = $address_xml;
        $data['Address2'] = $address_xml;
        $client_xml = $this->generate_xml($data);

        // Receipt
        $data = array();
        $data['UniqueTranKey'] = $this->get_unique_id();
        $data['CheckType'] = '';
        $data['BSBCode'] = '';
        $data['TransactionDate'] = $transaction_date;
        $data['ReceiptType'] = 'IVR';
        $data['Amount'] = $userdata['premium'];
        $data['TCSAmount'] = '';
        $data['TranRefNo'] = 'INSTA'.$this->get_unique_id();
        $data['TranRefNoDate'] = $transaction_date;
        $receipt_xml = $this->generate_xml($data);

        try{
        $quote_data   = $this->get_quote_data('fggi');
        $quote_data   = $quote_data[$userdata['quote_id']];
        }catch(\Exception $e){}

        // Risk
        $data = array();
        $data['SubProductName'] = $product_name;
        $data['FamilyType'] = $family_type;
        $countries = array();
        $countries['Countries'] = $userdata['visiting_country'];
        $column = array('fggi_continent');
        $check_values = array('fggi_code' => $userdata['visiting_country']);
        $country_tbl = new TravelCountry;
        try{
        $country = $country_tbl->get_value($column, $check_values);
        $countries['Continent'] = strtoupper($country[0]['fggi_continent']);
        }catch(\Exception $e){
            $countries['Continent'] = '';
        }
        $countries_xml = $this->generate_xml($countries, 'Countries');
        $data['VistingCountries'] = $countries_xml;
        $data['CoverageName'] = $coverage_name;
        $data['CoverageValue'] = $quote_data['CoverageValue'];
        $data['PlanName'] = $quote_data['PlanDesc'];
        $data['PlanValue'] = $quote_data['PlanCode'];
        $data['VisaName'] = $visa_name;
        $data['VisaValue'] =  $visa_value;
        $data['PurposeName'] =  $purpose_name;
        $data['PurposeValue'] =  $purpose_value;
        $data['DateOfDeparture'] = $start_date;
        $data['DateOfreturn'] = $end_date;
        $data['TripDuration'] = $duration;

        $insured_xml = $this->get_insured_details_policy($name, $dob_list, $gender, $passport, $occupation, $userdata['nomineename'] , $userdata['nomineerel'] , $relationship);

        $sponsor = array();
        $sponsor['Name'] = '';
        $sponsor['DOB'] = '';
        $sponsor['EmailId'] = '';
        $sponsor['Phone'] = '';
        $sponsor['Address'] = '';
        $sponsor['Relation'] = '';
        $sponser_xml = $this->generate_xml($sponsor);
        $university = array();
        $university['Name'] = '';
        $university['Address'] = '';
        $university['EmailId'] = '';
        $university_xml = $this->generate_xml($university);
        $risk_xml = $this->generate_xml($data);
        $risk_xml.= $insured_xml;
        $data = array();
        $data['Sponsor'] = $sponser_xml;
        $data['University'] = $university_xml;
        $risk_xml .= $this->generate_xml($data);

        // Root
        $data = array();
        $data['Uid'] = $this->get_unique_id();
        $data['VendorCode'] = Travel_Constants::$FGGI_VENDOR_CODE;
        $data['VendorUserId'] = '';
        $data['PolicyHeader'] = $policy_header_xml;
        $data['POS_MISP'] = $misp_xml;
        $data['Client'] = $client_xml;
        $data['Receipt'] = $receipt_xml;
        $data['Risk'] =  $risk_xml;
        $root_xml = $this->generate_xml($data, 'Root');
        $quote_req = new FggiRequest;
        $quote_req->set_product('Travel');
        $quote_req->set_xml($root_xml);
        $table['proposal_request'] = $root_xml;
        $res = $usr_tbl->update_data($table,session('tr_suid'));
        Log::info('TRAVEL_FGGI_PROPOSAL_REQUEST '. print_r($root_xml,true));
        return $quote_req;
    }

    private function get_insured_details_policy($name, $dob_list, $gender, $passport, $occupation, $nominee_name, $nominee_relation, $relationship_list){

        $insured_xml = '';
        foreach($relationship_list as $index => $relationship){
        $insured = array();
        $self_name       = $name[0]['fname'].' '.$name[0]['lname'];
        $insured['Name'] = $name[$index]['fname'].' '.$name[$index]['lname'];
        $insured['DOB']  = $dob_list[$index];
        $insured['Gender'] = $gender[$index];
        $member_relation = $this->get_relationship($relationship);
        $insured['RelationShip'] = strtoupper($member_relation);
        $insured['PassportNo'] = strtoupper($passport[$index]);
        $insured['OccupationName'] = '';
        $insured['OccupationValue'] = $occupation[$index];
        $insured['NomineeName'] = $this->get_nominee_name($nominee_name, $self_name , $member_relation);
        $insured['NomineeRelationShip'] = $this->get_nominee_relationship($nominee_relation, $member_relation,$relationship_list);
        $insured_xml .= $this->generate_xml($insured, 'Insured');
        }

        return $insured_xml;
    }

    private function get_nominee_name($nominee_name, $self_name , $member_relation){
      if($member_relation == 'Self'){
        return strtoupper(substr($nominee_name,0,20));
      }else{
        return strtoupper(substr($self_name,0, 20));
      }
    }

    private function get_nominee_relationship($nominee_relation, $member_relation, $relationship){
      if($member_relation == 'Spouse'){
        return 'SPOU';
      }elseif($member_relation == 'Son' || $member_relation == 'Daughter'){
        return 'PARE';
      }else if($nominee_relation == 'MOTH'){
        return 'PARE';
      }else{
        return $nominee_relation;
      }

    } // Kilivayel

    private function get_check_sum_data($pg_request){
        $text = implode('|', $pg_request).'|';
        return hash('sha256', $text);
    }

    public function parse_policy_response($raw_policy_resp,$trans_code){
        $usr_tbl    = new TravelUsrData;
        $column     = array('premium','tax','name','mobile','email','sum_insured','triptype','amt_duration');
        $userdata   = $usr_tbl->get_data($column,$trans_code);
        $name       = $this->get_name_details($userdata['name']);
        $policy_proceed_flag = false;
        $response_premium    = 0;
        $response_tax        = 0;
        $contract_type       = session('fggi_contract_type');
        try{
        if($raw_policy_resp){
            $response = $raw_policy_resp->CreatePolicyResult;
            $policy_resp_obj = new \SimpleXMLElement($response);
            if(isset($policy_resp_obj->Status) && $policy_resp_obj->Status == 'Fail'){
               return array('status' => 0, 'mismatch' => 0, 'error' => 0);
            }
            foreach ($policy_resp_obj->Policy->TravelPlan as $key => $plan) {
                $policy_resp_sum_insured = str_replace( ",", "",(string)$plan->SumInsured);
                if($userdata['sum_insured'] == $policy_resp_sum_insured &&
                 $contract_type == (string)$plan->ContractType){
                    $policy_proceed_flag = false;
                    if($userdata['triptype'] == 'S'){
                        $policy_proceed_flag = true;
                    }
                    if($userdata['triptype'] == 'M'){
                        if($userdata['amt_duration'] == 'SM' && 
                                ($plan->PlanCode == 'G30' || 
                                $plan->PlanCode == 'P30' ||
                                $plan->PlanCode == 'SG3' ||
                                $plan->PlanCode == 'SL3' )){
                                $policy_proceed_flag = true;
                        }
                        if($userdata['amt_duration'] == 'ME' && 
                                ($plan->PlanCode == 'G45' || 
                                $plan->PlanCode == 'P45' ||
                                $plan->PlanCode == 'SG4' ||
                                $plan->PlanCode == 'SL4')){
                                $policy_proceed_flag = true;
                        }
                        if($userdata['amt_duration'] == 'LA' && 
                            ($plan->PlanCode == 'SG6' ||
                            $plan->PlanCode == 'SL6' )){
                            $policy_proceed_flag = true;
                        }

                        if($userdata['amt_duration'] == 'L90' && 
                            ($plan->PlanCode == 'SG9' ||
                            $plan->PlanCode == 'SL9' )){
                            $policy_proceed_flag = true;
                        }
                    } 
                    if($policy_proceed_flag){
                        $response_premium = (int)$plan->PremiumWithServiceTax;
                        $response_tax = (int)$plan->ServiceTaxAmount;
                    }
                }
            }
        }
        }catch (\Exception $e) {
           Log::info('TRAVEL_FGGI_PROPOSAL_RESPONSE '. print_r($e->getMessage(), true));
        }
        if($response_premium > 0){
                $trans_id = 'INSTA'.$this->get_unique_id();
                $pg_request['TransactionID'] = $trans_id;
                $pg_request['PaymentOption'] =  Travel_Constants::$FGGI_PAYMENT_OPTION;
                $pg_request['ResponseURL'] =  url('/').Travel_Constants::$FGGI_RETURN_URL; 
                $pg_request['ProposalNumber'] = $trans_id;
                $pg_request['PremiumAmount'] =  $response_premium; 
                $pg_request['UserIdentifier'] = '60000272'; 
                $pg_request['UserId'] =  '10134025';
                $pg_request['FirstName'] =  $name[0]['fname'];
                $pg_request['LastName'] =  $name[0]['lname'];
                $pg_request['Mobile'] = $userdata['mobile'];
                $pg_request['Email'] =  $userdata['email'];
                $pg_request['CheckSum'] =  $this->get_check_sum_data($pg_request);
                Log::info('TRAVEL_FGGI_PG_REQUEST '. print_r($pg_request,true));

            if($response_premium == $userdata['premium']){
                $table['finalPremium'] = $userdata['premium'];
                $table['finalTax']     = $userdata['tax'];

                // Status updation
                $proposal_status['reference_number'] = $trans_id;
                $proposal_status['response_msg'] = print_r($raw_policy_resp,true);
                $proposal_be = new TravelProposalBe;
                $proposal_be->update_proposal_status('no_change_premium', $proposal_status);
                // End Status updation

                $res =  $usr_tbl->update_data($table,session('tr_suid'));
                return array('status' => 1 , 'premium' => $response_premium, 'request' => $pg_request, 'pg_url' => Travel_Constants::$FGGI_PG_URL);
            }else{
                $table['finalPremium'] = $response_premium;
                $table['finalTax']     = $response_tax;
                $res =  $usr_tbl->update_data($table,session('tr_suid'));

                // Status updation
                $proposal_status['reference_number'] = $trans_id;
                $proposal_status['response_msg'] = print_r($raw_policy_resp,true);
                $proposal_be = new TravelProposalBe;
                $proposal_be->update_proposal_status('premium_mismatch', $proposal_status); 
                // End Status updation

                return array('status' => 0, 'mismatch' => 1, 'error' => 0, 'actual_premium' =>$response_premium , 'passed_premium' => $userdata['premium'], 'request' => $pg_request, 'pg_url' => Travel_Constants::$FGGI_PG_URL); 
            }
            
        }else{

             // Status updation
            $proposal_status['response_msg'] = print_r($raw_policy_resp,true);
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
            // End Status updation

            return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        }
        
    }

    public function parse_pg_response($pg_response){
        if(!session()->has('tr_suid')){
          return json_encode(['status'=> false, 'redirect' => true]) ;
        }
        $trans_code  = session('tr_suid');
        $usr_tbl     = new TravelUsrData;
        $user_data   = $usr_tbl->get_all_data($trans_code);
        $proposal_be = new TravelProposalBe;
        if(!$user_data){ 
          return json_encode(['status'=> false, 'redirect' => true]) ;
        }

        $pg_response = $this->decrypt_pg_response($pg_response['ResponseData']);

        $pg_response = $this->get_url_data($pg_response);

        if($pg_response){
            Log::info('TRAVEL_FGGI_PG_RESPONSE_DECRYPTED '. print_r($pg_response, true));
            $status = (isset($pg_response['Response']) && $pg_response['Response'] == "Success") ? true : false;
            if($status){
              try{
              $columns = array('transaction_num' => $pg_response['WS_P_ID'], 
                               'pg_refno' => $pg_response['PGID']);

               // Status updation
              $proposal_status['reference_number'] = $pg_response['PGID'];
              $proposal_status['response_msg'] = json_encode($pg_response); 
              $proposal_be->update_payment_status('payment_success',$proposal_status);
              //End Status updation

              $usr_tbl->update_data($columns, $trans_code);
              $user_data  = $usr_tbl->get_all_data($trans_code);
              $result = TravelPolicy::insert($user_data); 
              $this->update_log($user_data);
              $columns = array();
              $columns = array('trans_code' => $trans_code.'_DONE');
              $usr_tbl->update_data($columns, session('tr_suid'));

              }catch (\Exception $e) {
                Log::info('TRAVEL_FGGI_PG_RESPONSE '. print_r($e->getMessage(), true));
              }
            }  

            if(!$status){
                $columns = array('transaction_num' => $pg_response['WS_P_ID'], 
                                 'pg_refno' => '');

                //Status updation
                $proposal_status['reference_number'] = $pg_response['WS_P_ID'];
                $proposal_status['response_msg'] = json_encode($pg_response); 
                $proposal_be->update_payment_status('payment_failed',$proposal_status);
                $proposal_be->update_payment_status('policy_error',$proposal_status);
                //End Status updation

                $usr_tbl->update_data($columns, $trans_code);
            }
            return json_encode(['status'=> $status,   
                   'logo' => Travel_Constants::$FGGI_LOGO, 
                   'pg_response' => $pg_response]);
        }else{
            return json_encode(['status'=> false, 'redirect' => true]);
        }
    }

    public function update_log($user_data){
        $proposal_be = new TravelProposalBe;
        $insurer_code  = 'FGGI';
        $agent_code    = $user_data['agent_code'];
        $policy_number = $user_data['policy_num'];
        $final_premium = $user_data['finalPremium'];
        $tax           = $user_data['finalTax'];
        $base_premium  = (int)$final_premium - (int) $tax;
        $proposal_be->update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium);
    }

    public function set_schedule_policy_request($trans_code, $pg_id){
        $usr_tbl    = new TravelUsrData;
        $column     = array('proposal_request');
        $userdata   = $usr_tbl->get_data($column,$trans_code);
        $xml = simplexml_load_string($userdata['proposal_request']); 
        $u_id = $xml->xpath("Uid");
        $transaction_ref_num = $xml->xpath("Receipt");
        $call_method = $xml->xpath("PolicyHeader");
        $call_method[0]->METHOD = 'CRT';
        $transaction_ref_num['0']->TranRefNo = $pg_id;
        $u_id[0][0] = $this->get_unique_id(); 
        $root_xml   = $xml->asXML();
        $root_xml = str_replace("<?xml version=\"1.0\"?>\n", '', $root_xml);

        //Request Object
        $quote_req  = new FggiRequest;
        $quote_req->set_product('Travel');
        $quote_req->set_xml($root_xml);
        return $quote_req;

    }

    public function parse_schedule_policy_response($raw_policy_resp){
        $quote_resp_data = array();
        $quote_counter   = 0;
        $policy_num      = '';
        if($raw_policy_resp){
            $response = $raw_policy_resp->CreatePolicyResult;
            $policy_resp_obj = new \SimpleXMLElement($response);
            if($policy_resp_obj->Policy->Status == 'Successful'){
                $policy_num =  (string) $policy_resp_obj->Policy->PolicyNo;
                
            }
        } 
        return $policy_num;   
    }

    private function get_url_data($pg_response){
        $parsed_response = array();
        try{
        foreach (explode('&', $pg_response) as $pg_data) {
            $pg_parameter = explode("=", $pg_data);
            if ($pg_parameter) {
                $parsed_response[$pg_parameter[0]] = urldecode($pg_parameter[1]);
            }
        } 
        }catch(\Exception $e){
            return null;
        }

        return $parsed_response;
    }

    private function decrypt_pg_response($pg_response){
        try{
        $pg_response = str_replace("$","+",$pg_response);
        $key = Travel_Constants::$FGGI_CRYPTO_KEY;

        
        $module = mcrypt_module_open(MCRYPT_DES, '', MCRYPT_MODE_CBC, '');
        $blockSize = mcrypt_get_block_size(MCRYPT_DES, MCRYPT_MODE_CBC);

        $iv = $key;
        $rc = mcrypt_generic_init($module, $key, $iv);
        $value = base64_decode($pg_response);
        $value = mdecrypt_generic($module, $value);

        //apply pkcs7 padding removal
        $packing = ord($value[strlen($value) - 1]);

        if($packing && $packing < $blockSize){
            for($P = strlen($value) - 1; $P >= strlen($value) - $packing; $P--){
                if(ord($value{$P}) != $packing){
                    $packing = 0;
                }
            }
        }
         
        $value = substr($value, 0, strlen($value) - $packing); 
         
        mcrypt_generic_deinit($module); 
        $value = utf8_encode($value);
        $pg_response = str_replace("cD,mìÏ³ñ","WS_P_ID=",$value);
        return $pg_response; 
        }catch (\Exception $e) {
            Log::info('TRAVEL_FGGI_PG_RESPONSE_DECRYPTION '. print_r($e->getMessage(), true));
          
         return null; 
        }
    }   

}