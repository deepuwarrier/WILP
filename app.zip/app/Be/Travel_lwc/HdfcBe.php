<?php 
namespace App\Be\Travel;
use App\Libraries\TravelLib;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPolicy;
use App\Models\Travel\TravelConfig;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelHdfcRate;
use App\Models\Travel\TravelCity;
use App\Models\Travel\TravelRelationship;
use App\Models\Travel\TravelState;
use App\Models\Travel\TravelPed;
use App\Constants\Travel_Constants;
use App\Constants\Common_Constants;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Be\Travel\TravelProposalBe;
use App\Be\Common\PaymentParseBE;
use Log;
class HdfcBe{
  
  private $policy_type_flag, $lib, $cal;
  
  public function __construct(){
    date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE); 
    $this->policy_type_flag = 0; // For Policy Checking
    $this->lib = new TravelLib;
  }

  public function calculate_indv_policy($input){
    $age      = $this->check_pre_quote_conditions($input, 'INDV_SING');
    $duration = $input['duration']; 
    $plan     = ($age != false)? $this->get_plancode($age,$input,'INDV_SING') : null;
    if($plan == null){
      return null;
    } else {
      $premium = $this->calculate_premium($age, $plan, 'INDV_SING', $duration);
      if($premium == null){
        return null;
      }
      session(['type' => 'INDV_SING']);
      $response =  $this->set_quotes($plan, $premium, $input['sum-insured']);
      if(sizeof($response) > 5){
            $temp     = $response;
            $response = array();
            $response[] = $temp;
      }
      return $response;
    }
  }

  public function calculate_floater_policy($input){
    if($this->check_pre_quote_conditions($input, 'FLT')){
      if($this->confirm_floater($input)){        
        return null;
      }else {
        $plan = $this->get_plancode(0,$input,'FLT');
        if($plan == null){
          return null;
        } else {
          $premium = $this->get_floater_premium($plan, $input);
          if($premium == null){
            return null;
          }
          session(['type' => 'FLT']);
          $response     =  $this->set_quotes($plan, $premium, $input['sum-insured']);
          if(sizeof($response) > 5){
            $temp     = $response;
            $response = array();
            $response[] = $temp;
          }
          return $response;
        }

      } 
    }else {
          return null;
    }        
  }

  public function calculate_student_policy($input){
    $age      = $this->check_pre_quote_conditions($input, 'ST');
    $duration = $input['std-duration']; 
    $plan     = ($age != false)? $this->get_plancode($age,$input,'ST') : null;
    $response = array();
    if($plan == null){
      return null;
    }else {
      if(sizeof($plan) == 1){
        $duration = $this->lib->map_student_duration($duration);
        $premium  =  $this->calculate_premium($age, $plan[0], 'INDV_SING', $duration);
        if($premium == null){
          return null;
        }
        session(['type' => 'ST']);
        $response[]   = $this->set_quotes($plan[0], $premium, $input['sum-insured']);
        return $response;
      }else {
          $duration = $this->lib->map_student_duration($duration);
        for($i=0; $i<sizeof($plan); $i++){
          $premium  = $this->calculate_premium($age, $plan[$i], 'STD', $duration);
          if($premium == null){
            return null;
          }
          session(['type' => 'ST']);
          $response[] = $this->set_quotes($plan[$i], $premium, $input['sum-insured']);
        }
        if(sizeof($response) > 5){
            $temp     = $response;
            $response = array();
            $response[] = $temp;
          }
        return $response;
      }

    }
  }

  public function calculate_amt_policy($input){
    $age     = $this->check_pre_quote_conditions($input, 'AMT');
    $plan    = ($age != false)? $this->get_plancode($age,$input,'AMT') : null;
    if($plan == null){
      return null;
    } else {
      $premium = $this->calculate_premium($age, $plan, 'AMT', 0);
      if($premium == null){
        return null;
      }
      session(['type' => 'AMT']);
      $response =  $this->set_quotes($plan, $premium, $input['sum-insured']);
      if(sizeof($response) > 5){
            $temp     = $response;
            $response = array();
            $response[] = $temp;
      }
      return $response;
    }
  }

  private function set_quotes($plan, $premium, $si){
        $lib           = new TravelLib;
        $TotalTaxAmt   = $this->get_service_tax($premium);
        $NetPremiumAmt = $premium + $TotalTaxAmt;
        $un_key        = uniqid();
        $breakup_t     = array();
        $response['company_name']       = 'Hdfc Ergo';
        $response['url_code']           = 'hdfc';
        $response['ProductDescription'] = (session('type') === 'ST') ? 'Student Suraksha' : 'RTravel';
        $response['session_key']        = session('tr_suid');
        $response['trans_code']         = session('tr_suid');
        $response['NetPremiumAmt']      = round($NetPremiumAmt);
        $response['TotalTaxAmt']        = round($TotalTaxAmt);
        $response['PlanCode']           = $plan['code'];
        $response['PlanDesc']           = $plan['name'];
        $response['companyId']          = $lib->get_company_code('hdfc');
        $response['logo']               = 'image/logos/'.$response['companyId'].'_logo.png';
        $response['productCode']        = ''; 
        $response['destinationCode']    = '';
        $response['sum-insured']        = $si;
        $response['policyId']           = $un_key;

        $sv_quote                = $response;
        $sv_quote['insurer']     = session('premium_breakup');
        $sv_quote['addon_id']    = null;
        $sv_quote['addon_value'] = null;

        $this->save_quote($sv_quote);
        $this->save_policy($sv_quote);
        return $response;
  }

  private function save_quote($response){ 
    $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
    $exists     = Storage::disk('local')->exists(
                    Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
    if($exists){
      $data = json_decode(Storage::get(
                          Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
      $data['hdfc'][$response['policyId']] = $response;
      Storage::disk('local')->put(
                          Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
    }else {
      $quote['hdfc'][$response['policyId']] = $response;
      Storage::disk('local')->put(
                          Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($quote)); 
    }
  }
  
  public function clean_quote(){
      $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
      $exists     = Storage::disk('local')->exists(
          Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
      if($exists){
          $data = json_decode(Storage::get(
              Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
          $data['hdfc'] = array();
          Storage::disk('local')->put(
              Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
      }
  }

  private function save_policy($input){
    $lib   = new TravelLib;
    $additional_kids   = 0;
    $additional_adults = 0;
    $no_adults         = 1;
    $kids              = 0;
    $parents           = 'none';
    $addi_premium      = 0;
    $base_premium      = round(session('floater_premium'));
    $travelcount       = session('travelcount');
    $type              = session('type');
    $catagory          = 0;
    $planName          = '2A'; 
    if($type === 'FLT'){

      $additional_kids   = (session('extra_child') == null) ? '0' : session('extra_child');

      $additional_kids   = ($additional_kids < 0 ) ? 0 : $additional_kids; 

      $additional_adults = (session('extra_adult') == 0) ? '0' : session('extra_adult');
      $no_adults         = 2;
      $kids              = abs($travelcount - $no_adults - $additional_kids - $additional_adults);

      $base_premium      = round(session('floater_premium'));
      $addi_premium      = round(session('addi_premium'));
      $catagory          = session('catagory');

      if($catagory == 1){
        $planName = '2A2C';
      }elseif($catagory == 2){
        $planName = '2A1C';
      }elseif($catagory == 3){
        $planName = '2A';
      }elseif($catagory == 7){
        $planName = '1A1C';
      }elseif($catagory == 6){
        $planName = '1A2C';
      }
    }
    
    $data_keeper = array();
    $data_keeper['policy_key']               = $input['policyId'];
    $data_keeper['policy_base_premium']      = $base_premium;
    $data_keeper['policy_addi_base_premium'] = $addi_premium;
    $data_keeper['policy_tax']               = round($input['TotalTaxAmt']);
    $data_keeper['policy_total_premium']     = round($input['NetPremiumAmt']);
    $data_keeper['policy_no_adults']         = $no_adults;
    $data_keeper['policy_no_kids']           = $kids; 
    $data_keeper['policy_floater_plan']      = $planName;

    if($additional_adults == 0){
        $data_keeper['policy_parent'] = 'None';
    } elseif($additional_adults == 1){
        $data_keeper['policy_parent'] = session('parent');
    } elseif($additional_adults > 1) {
        $data_keeper['policy_parent'] = 'Both';
    }
    
    $data_keeper['policy_addi_kids'] = $additional_kids;
    $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
    $data       = json_decode(Storage::get(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
    $data['hdfc'][$input['policyId']]['policy_base_premium']      = $base_premium;
    $data['hdfc'][$input['policyId']]['policy_addi_base_premium'] = $addi_premium ;
    $data['hdfc'][$input['policyId']]['policy_tax']               = $input['TotalTaxAmt'];
    $data['hdfc'][$input['policyId']]['policy_total_premium']     = $data_keeper['policy_total_premium'];
    $data['hdfc'][$input['policyId']]['policy_no_adults']         = $data_keeper['policy_no_adults'];
    $data['hdfc'][$input['policyId']]['policy_no_kids']           = $data_keeper['policy_no_kids'];
    $data['hdfc'][$input['policyId']]['policy_floater_plan']      = $data_keeper['policy_floater_plan'];
    $data['hdfc'][$input['policyId']]['policy_parent']            = $data_keeper['policy_parent'];
    $data['hdfc'][$input['policyId']]['policy_addi_kids']         = $data_keeper['policy_addi_kids'];

    Storage::disk('local')->put(
          Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
    
  }

  private function confirm_floater($data){

    $rel = is_array($data['relationship']) ? $data['relationship'] : explode(',' , $data['relationship']);
    if(in_array('8', $rel)){
      return true;
    }elseif(in_array('4', $rel) || in_array('5', $rel)){
      if(!in_array('3', $rel) && !in_array('2', $rel)){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }

  }

  private function get_floater_premium($plan, $input) {
    $rel = is_array($input['relationship']) ? $input['relationship'] : explode(',' , $input['relationship']);
    $duration            = $input['duration'];
    $premium             = 0;
    $catagory            = 1;
    $additional_premium  = 0;
    $adult_carry_premium = 0;
    $child_carry_premium = 0;
    $child               = 0;
    $extra_adlt_count    = 0;
    $actual_premium      = 0;
    session()->forget('extra_adult');
    session()->forget('extra_child');
    // Checking for children in the relationship list
    if(in_array('6', $rel) || in_array('7', $rel)){
      // Checking Age of each children for Actual Calculation
      $child = $this->check_children($input);
      if($child == 0 || $child > 4){
        //HDFC don'nt have plan for more than 4 child
        return null;
      } 
    
      if(in_array('2', $rel) || in_array('3', $rel)){
        if($input['travelcount'] == 4 && $child == 1 ){
            return null;
        }
        switch($child){
          case 1 : //2A1C
                   $catagory = 2;
                   break;
          case 2 : //2A2C
                   $catagory = 1;
                   break;                                                               
        }
      }else{
        if($input['travelcount'] == 3 && $child == 1 ){
            return null;
        } 
        switch($child){
          case 1 : //1A1C
                   $catagory = 7;
                   break;
          case 2 : //1A2C
                   $catagory = 6;
                   break;                                                               
        }
      }

    }else {
      // If no children, Plan is 2A
      $catagory = 3;   
    }
    $parent_count = $this->check_parents($input);
    if($parent_count == 5){
      return null;
    }

    //Getting Ratecard from DB for Premium Calculation
    $rate_result = $this->check_rate($plan['code'],'FLT',$catagory);
    //Finding the elder member age
    $age = explode(',', $input['age']);
    $age_temp = array();
    foreach($age as $item){
        $age_temp[] = (substr($item, 0, -1));
    }

    $elder_member = max($age_temp);
    foreach($age as $data){
      foreach($rate_result as $item) { 
        if(($elder_member  >= $item['rate_minage'] && $elder_member <= $item['rate_maxage']) && ($duration == $item['rate_maxdays'])) {
              $premium = $item['rate_base_premium']; 
              $actual_base_premium = $premium;
              if($parent_count == 1){
                $additional_premium = $premium * (0.45);
                $premium = $premium + $additional_premium;             
              }
              if($parent_count == 2){
                $additional_premium = $premium * (0.90);
                $premium = $premium + $additional_premium;
                $carry_premium = $premium;
              }
              if($child == 3){
                $additional_premium = $premium * (0.20);
                $premium = $premium + $additional_premium;
                $carry_premium = $premium;
              }
              if($child == 4){
                $additional_premium = $premium * (0.40);
                $premium = $premium + $additional_premium;
                $carry_premium = $premium;
              }
        } // End Duration check 
      }// End foreach
    }

    $this->set_session($input['travelcount'], $catagory, $actual_base_premium, $additional_premium);
    return $premium; 
  }

  private function calculate_premium($age, $plan, $type, $duration){ 
    $result = $this->check_rate($plan['code'], $type);
      $looper = false;
      if($type === 'AMT'){
        foreach($result as $item) { 
          if($age >= $item['rate_minage'] && $age <= $item['rate_maxage']) {
              $looper = true;
              session(['premium' => $item['rate_base_premium']]);
              return $item['rate_base_premium'];
          } // End Age check
        }// End foreach
        return ($looper == false) ? null : '' ;
      }// End type check
      if($type === 'INDV_SING'){
        foreach($result as $item) { 
          if($age >= $item['rate_minage'] && $age <= $item['rate_maxage']) {
              if($duration == $item['rate_mindays']) {
                $looper = true;
                session(['premium' => $item['rate_base_premium']]);
                return $item['rate_base_premium'];
              } // End Duration check 
          } // End Age check
        }// End foreach
        return ($looper == false) ? null : '' ;
      } // End type check

      if($type === 'STD'){
        foreach($result as $item) { 
          if($age >= $item['rate_minage'] && $age <= $item['rate_maxage']) {
              if($duration >= $item['rate_mindays'] && $duration <= $item['rate_maxdays']) {
                $looper = true;
                session(['premium' => $item['rate_base_premium']]);
                session(['floater_premium' => $item['rate_base_premium']]);
                return $item['rate_base_premium'];
              } // End Duration check 
          } // End Age check
        }// End foreach
    } // End type check
  }

  private function set_session($count, $catagory, $actual_base_premium, $additional_premium){
    $total_premium = $actual_base_premium + $additional_premium;
    $prem   = ($total_premium / $count );
    $premium_breakup = array();
    for($i = 0; $i<$count; $i++){
      $premium_breakup[] = $prem;
    }
    session(['premium_breakup' => implode(',',$premium_breakup)]);
    session(['addi_premium' => $additional_premium]);
    session(['catagory' => $catagory]);
    session(['floater_premium' => $actual_base_premium]);
  }

  private function check_children($input){
      $lib     = new TravelLib;
      $adults  = 0; 
      $children = 0;
      $members = is_array($input['relationship']) ? $input['relationship'] : explode(',' , $input['relationship']);
      $id      = array();
      for($i = 0; $i < sizeof($members); $i++){
        if($members[$i] == 7){
          $id[] = $i;
        }

        if($members[$i] == 6){
          $id[] = $i;
        }
      }

      // Removing duplicate values from Array
      $id = (array_unique($id));
      for($i  = 0; $i < sizeof($id); $i++){
         $key = $id[$i];
         // Calculating the Age of Children
         $age = $lib->calculateAge($input['dob'][$key]);
         if($age>=0 && $age<22){
           $children++; 
         } 
      }
      session(['extra_child' => $children - 2]);
      return $children;
  }

  private function check_parents($input){
    $response = false;
    $parent_count = 0;
    $relationship = explode(',', $input['relationship']);
    $age_list     = explode(',', $input['age_list']);
    if(in_array("4",$relationship)){
      $key = array_search('4', $relationship);
      session(['parent' => 'Father']);
      $age = rtrim($age_list[$key], 'Y');
      if($age>60){
        return 5;
      }else{
        $parent_count++;
      }
    }

    if(in_array("5",$relationship)){
      $key = array_search('5', $relationship);
      session(['parent' => 'Mother']);
      $age = rtrim($age_list[$key], 'Y');
      if($age>60){
        return 5;
      }else{
        $parent_count++;
      }
    }
    session(['extra_adult' => $parent_count]);
    return $parent_count;

  }

  public function get_service_tax($premium){
      return round ($premium * Travel_Constants::$GST_CMN);
  }

  private function check_rate($plan, $type, $catagory = null){
    $rate_tbl = new TravelHdfcRate;
    if($type === 'AMT'){
      $column  = array('rate_minage', 
                 'rate_maxage', 
                 'rate_base_premium');
      $check_values = array('rate_plan_code' => $plan);
      return $rate_tbl->get_data($column, $check_values);  
    }else if($type === 'INDV_SING' || $type === 'STD'){
      $column  = array('rate_minage', 
                 'rate_maxage','rate_mindays', 
                 'rate_maxdays', 
                 'rate_base_premium');
      $check_values = array('rate_plan_code' => $plan);
      return $rate_tbl->get_data($column, $check_values);
    }elseif($type === 'FLT'){
      $column       = array('rate_minage', 
                    'rate_maxage',
                    'rate_mindays', 
                    'rate_maxdays', 
                    'rate_base_premium');
      $check_values = array('rate_plan_code' => $plan,
                    'rate_catagory' => $catagory);
      return $rate_tbl->get_data($column, $check_values);
    }
  }

  private function get_plancode($age,$input,$type){ 
    $res = $this->get_plan_details($input,$type);
    if($type === 'AMT'){
       if($res){
        if($input['amt-duration'] === 'SM'){
          foreach($res as $item) { 
            if($item['plan_name'] == '30_Gold' || $item['plan_name'] == '30_Platinum'){
              $plan['name'] = $item['plan_name'];
              $plan['code'] = $item['plan_code'];
              return $plan;
            } 
          }
        } elseif($input['amt-duration'] === 'ME'){
          foreach($res as $item) { 
            if($item['plan_name'] == '45_Gold' || $item['plan_name'] == '45_Platinum'){
              $plan['name'] = $item['plan_name'];
              $plan['code'] = $item['plan_code'];
              return $plan;
            } 
          }
        } else {
          return null;
        }
      } else {
        return null;
      }
    } // End AMT  

    // SINGLE TRIP INDIVIDUAL/FAMILY
    if($type === 'INDV_SING' || $type === 'FLT'){
      if($res){
        foreach($res as $item) {
          $plan['name'] = $item['plan_name']; 
          $plan['code'] = $item['plan_code'];
          return $plan;
        }
      } else {
        return null;
      }  
    }
    // STUDENT
    if($type === 'ST'){
      if($res){
        foreach($res as $index=>$item) { 
          $plan[$index]['name'] = $item['plan_name'];
          $plan[$index]['code'] = $item['plan_code'];
        }
        return $plan;
      } else {
        return null;
      }
    }  
  }

  private function get_plan_details($input,$type){
    $si       = $input['sum-insured'];
    $area     = $this->get_destination($input['area']);
    $plan_tbl = new TravelPlan;
    $column   = array(Travel_Constants::TRAVEL_PLAN['CODE'],
               Travel_Constants::TRAVEL_PLAN['NAME'],
               Travel_Constants::TRAVEL_PLAN['SI']); 
    $check_values = array(Travel_Constants::TRAVEL_PLAN['TRIP_TYPE'] =>'STI',
                    Travel_Constants::TRAVEL_PLAN['SI'] => $si,
                    Travel_Constants::TRAVEL_PLAN['DESTINATION'] => $area,
                    Travel_Constants::TRAVEL_PLAN['COMPANY'] => 'hdfc');
    if($type == 'AMT'){
      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'AMT';
      return $plan_tbl->get_data($column, $check_values); 
    }elseif($type == 'INDV_SING'){
      return $plan_tbl->get_data($column, $check_values);
    }elseif($type == 'FLT'){
      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'STF';
      return $plan_tbl->get_data($column, $check_values); 
    }elseif($type == 'ST'){
      $check_values[Travel_Constants::TRAVEL_PLAN['TRIP_TYPE']] = 'STD';
      return $plan_tbl->get_data($column, $check_values); 
    }
  } 

  private function get_destination($area){ 
    switch($area){
      case 1 : $dest = 1;
               return $dest; 
               break;
      case 2 : $dest = 2;
               return $dest; 
               break;
      case 3 : $dest = 3;
               return $dest; 
               break;
      case 4 : $dest = 2;
               return $dest; 
               break;
      case 7 : $dest = 6;
               return $dest; 
               break;                                             
      }
  }

  private function check_pre_quote_conditions($input, $type){
    $age = $this->lib->calculateAge($input['dob'][0]);
    if($type === 'AMT'){
      if($age >= 18 && $age < 71){
              return $age;  
      } else {
              return false;
      }
    }
    if($type === 'INDV_SING'){
      if($age >=18 && $age < 71){
              return $age;  
      } else {
        return false;
      }
    }
    if($type === 'FLT'){
      $age_flag = true;
      $age_list = explode(',', $input['age_list']);
      for($i=0;$i<$input['travelcount'];$i++){
        $age = $this->lib->calculateAge($input['dob'][$i]);
        if($age > 60){
          $age_flag = false; 
        } 
      }
      // if(in_array('3M',$age_list)|| 
      //    in_array('4M',$age_list)|| 
      //    in_array('5M',$age_list)){
      //     $age_flag = false; 
      // }
      if($input['duration'] > 60){
        $age_flag = false;
      }
      return $age_flag;
    }
    if($type === 'ST'){
      if($age >= 16 && $age < 36){
        return $age;
      } else {
        return false;
      }
    }
  }

  public function check_si($type,$si){
    if($type == 'S'){
      if($si == '15000' || $si == '30000' || $si == '50000' || $si == '100000' || $si == '200000' || $si == '500000'){
        return true;
      } else {
        return false;
      }
    }
    if($type == 'M'){
      if($si == '250000' || $si == '500000'){
        return true;
      } else {
        return false;
      }

    } 
    if($type == 'ST'){
      if($si == '100000' || $si == '250000' || $si == '500000'){
        return true;
      } else {
        return false;
      }

    } 
  } 

    public function get_proposal_inputs($trans_code){
        $company_column = 'hdfc_code';
        $bl = new TravelProposalBe;
        $data = $bl->get_proposal_inputs($trans_code, $company_column);
        
        // Setting Trip Start Date 
        $data['userdata']['trip_start_date'] = $this->get_trip_start_date($data['userdata']['trip_start_date'], $data['userdata']);

        // Setting Trip End Date 
        $data['userdata']['trip_end_date'] = $this->get_trip_end_date($data['userdata']);

        if($data['userdata']['triptype'] == 'ST'){
          $data['en_academic_tab'] = true;
          $data['ped_list'] = $this->get_student_ped_list();
        }  

        // Setting Guardian DOB
        $data['guardian_dob'] = $this->get_guardian_dob();

        // Setting Guardian Relationship
        $data['guardian_relationship'] = $this->get_guardian_relationship($data['userdata']['age_list']);

        return $data;
    }

    private function get_student_ped_list(){
        $ped_tbl = new TravelPed;
        $column  = array('ped_code', 'ped_title', 'ped_short_code', 'hdfc_code');
        $check_values = array('ped_catagory' => 'ST');
        return $ped_tbl->get_value($column, $check_values);
    }

    private function get_trip_end_date($userdata){
        $lib = new TravelLib;
        if($userdata['triptype'] == 'M'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], '364');
        }

        if($userdata['triptype'] == 'S'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $userdata['duration'] - 1);
        }

        if($userdata['triptype'] == 'ST'){
          $duration = $lib->map_student_duration($userdata['std_duration']);
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $duration - 1);
        }

        
    } 

    private function get_trip_start_date($date, $userdata){
        $lib = new TravelLib;
        $result = array();
        $duration = 179;
        $result['selected_date'] = ($date) ? $date : date("d-m-Y");
        $result['min_date']      = date("d-m-Y");
        $result['max_date']      = $lib->add_days_with_date(date("d-m-Y"), $duration);
        if($userdata['triptype'] == 'ST'){
            $result['max_duration'] = $lib->map_student_duration($userdata['std_duration']);

        }
        if($userdata['triptype'] == 'S'){
            $result['max_duration'] = $userdata['duration'];
        }
        if($userdata['triptype'] == 'M'){
            $result['max_duration'] = '365';
        }

        return $result;
    }  

    private function get_guardian_dob(){
        $lib = new TravelLib;
        $result = array();
        $result['selected_date'] = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['max_date']      = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['min_date']      = $lib->minus_year_from_date(date("d-m-Y"), '99');
        return $result;
    }

    private function get_guardian_relationship($age_list){ 
        $age = rtrim($age_list[0],'Y');
        if($age < 18){
        return array(  0 => array ('relationship_code' => 'Mother', 
                                   'relationship_name' => 'Mother'),
                       1 => array ('relationship_code' => 'Father', 
                                   'relationship_name' => 'Father'));
        } 
        return array(  0 => array ('relationship_code' => 'Self', 
                                   'relationship_name' => 'Self'),
                       1 => array ('relationship_code' => 'Spouse', 
                                   'relationship_name' => 'Spouse'),
                       2 => array ('relationship_code' => 'Mother', 
                                   'relationship_name' => 'Mother'),
                       3 => array ('relationship_code' => 'Father', 
                                   'relationship_name' => 'Father'));
    }
        
    public function set_proposal_data($data){
        $trans_code = $data['trans_code'];
        $section     = $data['id'];
        $usr_tbl     = new TravelUsrData;
        $check_value = array('trans_code' => $trans_code);
        // Unsetting the extra values
        unset($data['trans_code']);
        unset($data['id']);
        unset($data['_token']);
        if($section == 'travel'){
            $data['name'] = implode(',',$data['name']);
            $data['dob']  = implode(',',$data['dob']);
            $data['passport']  = implode(',',$data['passport']);
        }
        if($section == 'medical_his'){
            if(isset($data['ped_choice'])){
                $ped['ped_choice'] = $data['ped_choice'];
                $ped['ped_details'] = (isset($data['ped_details'])) ? $data['ped_details'] : '' ;
                $ped['sub_ped'] = (isset($data['sub_ped'])) ? $data['sub_ped'] : '' ;
                $data = array();
                $data['ped'] = json_encode($ped);
            }else{
                $data['ped'] = null;
            }        
        }
        $usr_tbl->set_data($data, $check_value);
       
    }
        
    private function get_end_date($date,$days){
        $date = strtotime("+".$days." days", strtotime($date));
        $date = date("d-m-Y", $date);
        return $date.' '.'11:59:59 PM';
    }
    
    public function set_proposal($trans_code){
        $usr_tbl      = new TravelUsrData;
        $config_tbl   = new TravelConfig;
        $state_tbl    = new TravelState;
        $city_tbl     = new TravelCity;
        $proposal_be  = new TravelProposalBe;
        $userdata     = $usr_tbl->get_all_data($trans_code);
        $config       = $config_tbl->get_data('config_key', 'hdfc');

        $end_date     = ($userdata['triptype'] == 'M') ? 
                                  $this->get_end_date($userdata['trip_start_date'], '364') : 
                                  $userdata['trip_end_date']; 

        $name       = $this->get_name_details($userdata['name']);
        $dob        = explode(',', $userdata['dob']);
        $title      = explode(',', $userdata['title']);
        $passport   = explode(',', $userdata['passport']);
        $relationship =  explode(',', $userdata['relationship']); 
        $guardian_dob = '';
        $gender     = $this->get_gender($title);
        try{
        $quote_data   = $this->get_quote_data('hdfc');
        $quote_data   = $quote_data[$userdata['quote_id']];
        }catch(\Exception $e){}                          
        
        // Plan Details
        if($userdata['triptype'] != 'ST'){
        $data = array();
        $data['ProducerCd'] = $config['hdfc_producer_cd'];
        $data['TotalSumInsured'] = $userdata['sum_insured'];
        $data['PlanCd'] =  $userdata['plan_code'];
        $data['DepartureDate'] = date("d/m/Y", strtotime($userdata['trip_start_date']));
        $data['ArrivalDate'] = date("d/m/Y", strtotime($end_date));
        $data['TravelDays'] = ($userdata['triptype'] == 'M') ? '365' : $userdata['duration'];
        $data['purposeofvisitcd'] = ($userdata['triptype'] == 'M') ? 'Business' : $userdata['purpose'];
        $data['PlacesVisitedCd'] = '';
        $data['BasePremiumAmt'] =  ''; 
        $data['TotalBasePremiumAmt'] = '';
        $data['ServiceTax'] = '';
        $data['TotalPremium'] = (session('updated_premium') == 0) ? $quote_data['policy_total_premium'] : session('updated_premium'); 
        $data['NoOfAdults'] = $quote_data['policy_no_adults'];
        $data['NoOfKids'] = $quote_data['policy_no_kids']; 
        $data['FloaterPlan'] = $quote_data['policy_floater_plan'];
        $data['DependentParent'] = $quote_data['policy_parent'];
        $data['NoOfAdditionalKids'] = $quote_data['policy_addi_kids'];
        $plan_detail_xml = $this->generate_xml($data, 'PlanDetails');

        }

        // Policy Details
        if($userdata['triptype'] == 'ST'){
        $data = array();
        $data['ProducerCode'] = $config['hdfc_producer_cd'];
        $data['ProductCode'] = 'Stravel';
        $data['PlanCode'] = $userdata['plan_code'];
        $data['PlanName'] = $this->get_plan_name($data['PlanCode']);
        $data['SumInsured'] = $userdata['sum_insured'];
        $data['AreYouCurrentlyInIndia'] = 'Yes';
        $data['IndianNation'] = 'Yes';
        $data['TravellingtoUSACANADA'] = (strpos($data['PlanCode'] , 'E') !== false) ? 'No' : 'Yes';
        $data['PolicyStartDate'] = date("d/m/Y", strtotime($userdata['trip_start_date']));
        $data['TravelDays'] = $this->lib->map_student_duration($userdata['std_duration']);
        $data['PolicyEndDate'] = date("d/m/Y", strtotime($end_date));
        $data['BasePremium'] = $quote_data['policy_base_premium']; 
        $data['ServiceTax'] = $quote_data['policy_tax'];
        $data['TotalPremium'] = round((session('updated_premium') == 0) ? $quote_data['policy_total_premium'] : session('updated_premium')); 
        $policy_detail_xml = $this->generate_xml($data, 'PolicyDetails');
        }

        // Payment Details
        $data = array();
        $data['PaymentOption'] =  'Credit Card';
        $data['PaymentReferance'] = '83';
        $payment_detail_xml = $this->generate_xml($data, 'PaymentDetails');

        // Customer Details
        $data = array();
        $data['Title'] = strtoupper($title[0]);
        $data['FirstName'] = $name[0]['fname']; 
        $data['MiddleName'] = $name[0]['mname'];
        $data['LastName'] = $name[0]['lname'];
        $data['DOB'] = date("d/m/Y", strtotime($dob[0]));
        $guardian_dob = $data['DOB'];
        $data['Gender'] = $gender[0];
        $data['Address1'] = strtoupper($userdata['house_name']);
        $data['Address2'] = strtoupper($userdata['street']);
        $data['Address3'] = '';
        try{
        $check_values = array('state_code' => $userdata['state']);  
        $state = $state_tbl->get_data($userdata['company_column'], $check_values);
        $data['StateCode'] = $state[0][$userdata['company_column']]; 
        }catch(\Exception $e){

        }
        try{
        $check_values = array('city_name' => $userdata['city'], 'state_code' => $userdata['state']);  
        $city = $city_tbl->get_data($userdata['company_column'], $check_values);
        $data['CityCode'] = $city[0][$userdata['company_column']]; 
        }catch(\Exception $e){

        }

        $data['Pincode'] = $userdata['pincode'];
        $data['STDCodeResi'] = '';
        $data['TelResi'] = '';
        $data['STDCodeOff'] = '';
        $data['TelOff'] = '';
        $data['MobileNumber'] = $userdata['mobile'];
        $data['OverseasNo'] = '';
        $data['Email'] = strtoupper($userdata['email']);
        if(!$userdata['ped']){
          // NO PED CASE
          $data['ExistingAliments'] = ''; 
          $data['DeclineInsurance'] = 'false'; 
          $data['DeclineReason']    = ''; 
          $data['RestrictionByIns'] = 'false'; 
          $data['RestrictionByInsDetails'] = ''; 
        }else{

          $ped = json_decode($userdata['ped'], true);

          if(isset($ped['ped_choice']['medical_history'])){
            $data['ExistingAliments'] = $this->get_medical_history($ped);
          }else {
            $data['ExistingAliments'] = ''; 
          }
          if(isset($ped['ped_choice']['medical_declined'])){
            $data['DeclineInsurance']  = 'true'; 
            $data['DeclineReason']     = strtoupper($ped['ped_details']['medical_declined']); 
          }else{
            $data['DeclineInsurance']  = 'false'; 
            $data['DeclineReason']     = '';
          }
          if(isset($ped['ped_choice']['special_conditions'])){
            $data['RestrictionByIns']  = 'true';
            $data['RestrictionByInsDetails']  = strtoupper($ped['ped_details']['special_conditions']);
          }else{
            $data['RestrictionByIns']  = 'false'; 
            $data['RestrictionByInsDetails']  = ''; 
          }
        }

        $data['IsCustomerAcceptedPED'] = 'true';
        $data['IsCustomerAuthenticationDone'] = '1';
        $data['AuthenticationType'] = 'OTP';
        $data['UIDNo'] = (string)$proposal_be->get_uid($userdata['mobile']);
        if($userdata['triptype'] == 'ST'){
          $data = $this->get_student_cust_details($data, $userdata);
        }  
        $customer_detail_xml = $this->generate_xml($data, 'CustDetails');

        // University Details
        if($userdata['triptype'] == 'ST'){
        $data = array();
        $data['UniversityName'] = strtoupper($userdata['university_name']);
        $data['ProgramName'] =  strtoupper($userdata['program_name']);
        $data['ProgramDuration'] = strtoupper($userdata['program_duration']);
        $university_address_length = strlen($userdata['university_address']);
        if($university_address_length > 35){
          $data['UniversityAddress1'] = strtoupper(substr($userdata['university_address'],0,35));
          $data['UniversityAddress2'] = strtoupper(substr($userdata['university_address'],35,$university_address_length));
        }else{
          $data['UniversityAddress1'] = strtoupper($userdata['university_address']);
          $data['UniversityAddress2'] = '';
        }
        $data['UniversityAddress3'] = '';
        $data['UniversityCountry'] = strtoupper($userdata['university_country']);
        $data['UniversityState'] = strtoupper($userdata['university_state']);
        $data['UniversityCity'] = strtoupper($userdata['university_city']);
        $university_detail_xml = $this->generate_xml($data, 'UniversityDetails');
        }
         

        // Sponser Details
        $member_details_xml  = '';
        if($userdata['triptype'] == 'ST'){
        $data = array();
        $data['SponsorName'] = strtoupper($userdata['sponser_name']);
        $data['SponsorDOB'] = date("d/m/Y", strtotime($userdata['sponser_dob']));
        $sponser_detail_xml = $this->generate_xml($data, 'SponsorDetails');
        $member_details_xml  = $this->get_student_member_details($name,
                                                   $passport,  
                                                   $userdata['nomineename'], 
                                                   $userdata['nomineerel'],
                                                   $userdata['guardian_relationship'],
                                                   $guardian_dob
                                                   );
        }else{
        $member_details_xml  = $this->get_member_details($name ,$gender, 
                                                   $passport, $dob, 
                                                   $userdata['nomineename'], 
                                                   $userdata['nomineerel'],
                                                   $relationship);
        }
        
        
        if($userdata['triptype'] == 'ST'){
        $request['InsuranceDetails'] = $policy_detail_xml.$customer_detail_xml.$university_detail_xml.$sponser_detail_xml.$payment_detail_xml.$member_details_xml; 
        }else{
        $request['InsuranceDetails'] = $plan_detail_xml.$payment_detail_xml.$customer_detail_xml.$member_details_xml; 
        }
        $request_xml = $this->generate_xml($request);
        return $request_xml;
    }

    private function get_student_cust_details($data, $userdata){
        $state_tbl = new TravelState;
        unset($data['TelResi']);
        unset($data['STDCodeOff']);
        unset($data['TelOff']);
        unset($data['ExistingAliments']);
        unset($data['DeclineInsurance']);
        unset($data['DeclineReason']);
        unset($data['RestrictionByIns']);
        unset($data['RestrictionByInsDetails']);
        $data['TelephoneNoResi'] = '';
        $data['STDCodeOffice'] = '';
        $data['TelephoneNoOffice'] = '';
        $data['Gender'] = ($data['Gender'] == 'Male') ? 'M' : 'F' ;
        try{
        $check_values = array('state_code' => $userdata['state']);  
        $state = $state_tbl->get_data('state_name', $check_values);
        $data['State'] = $state[0]['state_name']; 
        }catch(\Exception $e){

        }
        $data['City'] = $userdata['city'];
        if($userdata['guardian_relationship'] == 'Self'){
          $data['IsProposerSameAsInsured'] = 'Yes';
          $data['ProposerDOB'] = $data['DOB'];
          $data['ProposerFirstName']  = $data['FirstName'];
          $data['ProposerMiddleName'] = $data['MiddleName'];
          $data['ProposerLastName']   = $data['LastName'];

        }else {
          $data['IsProposerSameAsInsured'] = 'No';
          $data['ProposerDOB'] = date("d/m/Y", strtotime($userdata['guardian_dob']));
          $proposer_name = explode(' ', $userdata['guardian_name']);
          $data['ProposerFirstName']  = strtoupper($proposer_name[0]);
          $data['ProposerMiddleName'] = '';
          $data['ProposerLastName']   = strtoupper($proposer_name[1]);
        }

        $data['ProposerMobileNo'] = $data['MobileNumber'];
        $data['ProposerEmailId']  = $data['Email'];
        $data['InsuredDOB']  = $data['DOB'];
        $data['MobilNumber'] = $data['MobileNumber'];
        unset($data['DOB']);
        unset($data['MobileNumber']);

        if(!$userdata['ped']){
          $data['AnyMedicalTreatmentInLast5Yr'] = 'No';
        }else{
          $data['AnyMedicalTreatmentInLast5Yr'] = 'Yes';
        }
        
        return $data;
    }

    private function get_nominee_name($nominee_name, $self_name , $member_relation){
      if($member_relation == 'Self'){
        return strtoupper(substr($nominee_name,0,30));
      }else{
        return strtoupper(substr($self_name,0, 30));
      }
    }

    private function get_nominee_relationship($nominee_relation, $member_relation, $relationship, $self_gender){

      if($member_relation == 'Spouse'){
        return 'Spouse';
      }elseif($member_relation == 'Son' || $member_relation == 'Daughter'){
        $nom_rel = 'Mother';
        if($relationship[1] == '2'){
          $nom_rel = 'Mother';
        }else{
          $nom_rel = 'Father';
        }
        return $nom_rel;
      }elseif($member_relation == 'Father' || $member_relation == 'Mother'){
        if($self_gender == 'Male'){
          return 'Son';

        }else{
          return 'Daughter';
        }
        
      }else{
        return $nominee_relation;
      }

    }

    private function get_member_details($name,$gender,$passport,$dob,$nominee_name,$nominee_relation, $relationship){
      $member_details = '<Member>';
      foreach ($gender as $key => $value) {
        $self_name       = $name[0]['fname'].' '.$name[0]['lname'];
        $member_details .= '<InsuredDetails InsFirstName="'.$name[$key]['fname'].'" ';
        $member_details .= 'InsMiddleName="'.$name[$key]['mname'].'" ';
        $member_details .= 'InsLastName="'.$name[$key]['lname'].'" ';
        $member_details .= 'InsGender="'.$gender[$key].'" ';
        $member_relation = $this->get_relationship($relationship[$key]);
        $member_details .= 'InsuredRelation="'.$member_relation.'" ';
        $member_details .= 'InsDOB="'.date("d/m/Y", strtotime($dob[$key])).'" ';
        $member_details .= 'PassportNo="'.strtoupper($passport[$key]).'" ';
        $member_details .= 'NomineeName="'.$this->get_nominee_name($nominee_name, $self_name , $member_relation).'" ';
        $member_details .= 'NomineeRelation="'.$this->get_nominee_relationship($nominee_relation, $member_relation, $relationship, $gender[0]).'" />';
      }
      $member_details .= '</Member>';
      return $member_details;
    }

    private function get_student_member_details($name,$passport,$nominee_name,$nominee_relation, $guardian_relationship, $guardian_dob){
      $member_details = '<Member>';
        $member_details .= '<InsuredDetails InsFirstName="'.strtoupper($name[0]['fname']).'" ';
        $member_details .= 'InsMiddleName="'.$name[0]['mname'].'" ';
        $member_details .= 'InsLastName="'.strtoupper($name[0]['lname']).'" ';
        $member_details .= 'InsuredRelation="'.$guardian_relationship.'" ';
        $member_details .= 'InsDOB="'.$guardian_dob.'" ';
        $member_details .= 'PassportNo="'.strtoupper($passport[0]).'" ';
        $member_details .= 'NomineeRelation="'.$nominee_relation.'" ';
        $member_details .= 'NomineeName="'.strtoupper($nominee_name).'" />';
      $member_details .= '</Member>';
      return $member_details;
    }

    private function get_relationship($relationship){
      $relation_tbl = new TravelRelationship;
      $column       = array('relationship_name');
      $check_values = array('relationship_id' => $relationship);
      $result = $relation_tbl->get_data($column,$check_values);
      $relationship = $result[0]['relationship_name'];

      if($relationship == 'Wife' || $relationship == 'Husband'){
        return 'Spouse';
      } else {
        return ucfirst(strtolower($relationship));
      }
    }

    private function get_medical_history($ped){

      if(isset($ped['ped_details']['medical_history'])){
        return ucfirst(strtolower($ped['ped_details']['medical_history']));
      }

      $ped_details = '';
      $ped_tbl = new TravelPed;
      $column = array('ped_title');
      try{
      foreach($ped['sub_ped'] as $ped_code => $status){
        $check_values  = array('hdfc_code' => $ped_code); 
        $response      = $ped_tbl->get_value($column, $check_values);
        if($response){
          $ped_details[] = $response[0]['ped_title'];
        }
        
      }
      }catch(\Exception $e){
        return null;
      }
      return implode(',', $ped_details);
    }

    private function get_name_details($name){
      $name = explode(',', $name);
      $member_list = array();
      foreach ($name as $key => $value) {
        $member_name = explode(' ', $value);
        if(sizeof($member_name) == 2){
          $member_list[$key]['fname'] =  strtoupper($member_name[0]);
          $member_list[$key]['mname'] = '';
          $member_list[$key]['lname'] =  strtoupper($member_name[1]);
        }

        if(sizeof($member_name) >= 3){
            $member_list[$key]['fname'] = strtoupper($member_name[0]);
            $member_list[$key]['mname'] = strtoupper($member_name[1]);
            $member_list[$key]['lname'] = strtoupper($member_name[2]);
        }
      }
      return $member_list;
    }

    private function get_gender($title){
      $gender_list = array();
      foreach ($title as $key => $value) {
        if($value == 'Mrs' || $value == 'Ms'){
          $gender_list[$key] = 'Female';
        }else{
          $gender_list[$key] = 'Male';
        }
      }
      return $gender_list ;
    }

    private function get_plan_name($plan_code){
      $plan_tbl = new TravelPlan;
      $column = array('plan_name');
      $check_values = array('plan_company' => 'hdfc', 'plan_code' => $plan_code);
      $response = $plan_tbl->get_data($column, $check_values);
      if($response){
        return $response[0]['plan_name'];
      }
      return false;
    }

    private function generate_xml($array, $tag = null){
        $xml = ($tag) ? '<'.$tag.'>' : '';
        foreach($array as $attribute => $value){
            $xml .=  '<'.$attribute.'>'.$value.'</'.$attribute.'>';
        }
        $xml .= ($tag) ? '</'.$tag.'>': '';
        return $xml;
    }

    private function get_quote_data($company){
        $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
        $exists     = Storage::disk('local')->exists(
                      Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
        if($exists){
          $data = json_decode(Storage::get(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
          return $data[$company];
        }
    }
            
  public function parse_policy($xml,$trans_code=null){ 
      $payment_parse_be = new PaymentParseBE;
      Log::info('TRAVEL_HDFC_PROPOSAL_RESPONSE '. print_r($xml,true));
      if(strpos($xml, 'WsStatus') !== false){ // If 'WsStatus' is not there in XML then assuming that the response is an error message
        $xml = new \SimpleXMLElement($xml);
        $dom = new \DOMDocument;
        $dom->loadXML($xml);
        $actual_premium = '';
        $passed_premium = '';
        $usr_tbl = new TravelUsrData;
        // Retreving Message Status
        $status  = $dom->getElementsByTagName("WsStatus")->item(0)->nodeValue;
        // Cheking Status
        if($status == 0){
          $config_tbl   = new TravelConfig;
          $column       = 'config_key';
          $check_values = 'hdfc';
          $config_data  = $config_tbl->get_data($column, $check_values);

          $columns      = array('premium','tax', 'name', 'email');
          $t_data       = TravelUsrData::get_data($columns, session('tr_suid'));

          $table['finalPremium'] = (session()->has('hdfc_updated_premium')) ?  session('hdfc_updated_premium'): $t_data['premium'];

          $table['finalTax']     = (session()->has('hdfc_updated_tax')) ? session('hdfc_updated_tax') : $t_data['tax'];

          
          $res =  $usr_tbl->update_data($table,session('tr_suid'));
          $txnnumber = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;
          $name      = $this->get_name_details($t_data['name']);

          // Status updation
          if(session()->has('hdfc_updated_premium')){
            $proposal_status['reference_number'] = $txnnumber;
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('premium_mismatch', $proposal_status); 
          }else{
            $proposal_status['reference_number'] = $txnnumber;
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('no_change_premium', $proposal_status); 
          }
          // End Status updation

          session()->forget('hdfc_updated_premium');
          session()->forget('hdfc_updated_tax');

          $pg_request['CustomerId'] = $txnnumber;
          $pg_request['UserName'] = $name[0]['fname'].' '.$name[0]['lname'];
          $pg_request['hdnPayMode'] = $config_data['hdfc_pay_mode'];
          $pg_request['ProducerCd'] = $config_data['hdfc_producer_cd'];
          $pg_request['ProductCd'] =  $config_data['hdfc_product_code'];
          $pg_request['AdditionalInfo1'] = $config_data['hdfc_addi_info_1'];
          $pg_request['AdditionalInfo2'] = $config_data['hdfc_addi_info_2'];
          $pg_request['AdditionalInfo3'] = $config_data['hdfc_addi_info_3'];
          $pg_request['UserMailId'] = $t_data['email'];
          $pg_request['TxnAmount'] = $table['finalPremium'];
          $payment_parse_be->setPaymentIdentifier($trans_code,$txnnumber);
          $response =  array('status' => 1, 'request' => $pg_request, 'pg_url' => $config_data['hdfc_pg_url']);   

          Log::info('TRAVEL_HDFC_PG_REQUEST '. print_r($response,true));
          return $response;

        }else {
          $lib     = new TravelLib;   
          $message = $dom->getElementsByTagName("WsMessage")->item(0)->nodeValue;
          if(strpos($message, 'mismatch') !== false){ 
            $actual_premium = trim($lib->get_string_between($message, 'Actual Premium:', 'and'));
            $passed_premium = trim($lib->get_string_between($message, 'Premium Passed :', '.\n'));

            $table['finalPremium'] = $actual_premium;
            $table['finalTax']     = $lib->get_tax_premium($actual_premium);

            session(['hdfc_updated_premium' => $table['finalPremium']]);
            session(['hdfc_updated_tax' => $table['finalTax']]);

            // Status updation
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('premium_mismatch', $proposal_status); 
            // End Status updation

            $res =  $usr_tbl->update_data($table,session('tr_suid'));
            
            if(($actual_premium != null || $actual_premium !='') && ($passed_premium != null || $passed_premium !='')){
              return array('status' => 0, 'mismatch' => 1, 'error' => 0, 'actual_premium' =>$actual_premium , 'passed_premium' => $passed_premium); 
            }else {
              return array('status' => 0, 'mismatch' => 0, 'error' => 0);
            }
          }elseif(strpos($message, 'pre-existing disease') !== false){

            // Status updation
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('ped_case', $proposal_status); 
            // End Status updation

            return array('status' => 0, 'mismatch' => 0, 'error' => 0, 'ped' => 1);
          }elseif(strpos($message, 'Medical Treatment') !== false){

            // Status updation
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('ped_case', $proposal_status); 
            // End Status updation
            
            return array('status' => 0, 'mismatch' => 0, 'error' => 0, 'ped' => 1);
          }else {

            // Status updation
            $proposal_status['response_msg'] = $xml;
            $proposal_be = new TravelProposalBe;
            $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
            // End Status updation

            // Handling No Plan Found Error 
            if(strpos($message, 'No such Plan exists') !== false){
              return array('status' => 0, 'mismatch' => 0, 'error' => 0);
            } 

            $head_msg = 'Opps !. Please Correct the following errors <br>';
            $message .= str_replace('\n','<br>',$message);
            $message  = $head_msg.$message; 
            return array('status' => 0, 'mismatch' => 0, 'error' => 1, 'message' => $message); 
          } 

        } // END OF cheking status
        
      } else {

        // Status updation
        $proposal_status['response_msg'] = $xml;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
        // End Status updation

        return array('status' => 0, 'mismatch' => 0, 'error' => 0);
      }  
    }

  public function update_paymode($data){
    $usr_tbl  = new TravelUsrData;
    $columns  = array('pay_mode' => $data['pay_mode']);
    $response = $usr_tbl->update_data($columns,$data['trans_code']);
    return json_encode(['status' => true]);
  }

  public function get_proposal_preview_data($response){
    $response['trip_info']['visiting_country'] = null;
    return $response;
  } 

  public function parse_pg_response($pg_response){
    $payment_parse_be = new PaymentParseBE;
    $trans_code = $payment_parse_be->getPaymentIdentifier($pg_response['ProposalNo']);

    if(!session()->has('tr_suid')){
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }
    // $trans_code  = session('tr_suid');
    $usr_tbl     = new TravelUsrData;
    $user_data   = $usr_tbl->get_all_data($trans_code);
    $proposal_be = new TravelProposalBe;
    if(!$user_data){ 
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }  
    if(!isset($pg_response['Msg']) || !isset($pg_response['PolicyNo']) || !isset($pg_response['ProposalNo'])){
      return json_encode(['status'=> false, 'redirect' => true]);
    }

    $status = (isset($pg_response['Msg']) && $pg_response['Msg'] == "Successfull") ? true : false; 
    if($status){
      try{
      $columns = array('transaction_num' => $pg_response['ProposalNo'], 
                       'policy_num' => $pg_response['PolicyNo']);

      // Status updation
      $proposal_status['reference_number'] = $pg_response['ProposalNo'];
      $proposal_status['response_msg'] = json_encode($pg_response); 
      $proposal_be->update_payment_status('payment_success',$proposal_status);
      //End Status updation

      // Status updation
      $proposal_be->update_payment_status('policy_accepted');
      //End Status updation

      $usr_tbl->update_data($columns, $trans_code);
      $user_data  = $usr_tbl->get_all_data($trans_code);
      $result = TravelPolicy::insert($user_data); 
      $this->update_log($user_data);

      $columns = array();
      $columns = array('trans_code' => $trans_code.'_DONE');
      $usr_tbl->update_data($columns, session('tr_suid'));

      }catch (\Exception $e) {
        Log::info('TRAVEL_HDFC_PG_RESPONSE '. print_r($e->getMessage(), true));
      }
    } 

    if(!$status){
      $columns = array('transaction_num' => $pg_response['ProposalNo']);

      //Status updation
      $proposal_status['reference_number'] = $pg_response['ProposalNo'];
      $proposal_status['response_msg'] = json_encode($pg_response); 
      $proposal_be->update_payment_status('payment_failed',$proposal_status);
      $proposal_be->update_payment_status('policy_error',$proposal_status);
      //End Status updation

      $usr_tbl->update_data($columns, $trans_code);
    }

    return json_encode(['status'=> $status,   
           'logo' => Travel_Constants::$HDFC_LOGO, 
           'pg_response' => $pg_response]); 
  }

  public function update_log($user_data){
    $proposal_be = new TravelProposalBe;
    $insurer_code  = 'HDFC';
    $agent_code    = $user_data['agent_code'];
    $policy_number = $user_data['policy_num'];
    $final_premium = $user_data['finalPremium'];
    $tax           = $user_data['finalTax'];
    $base_premium  = (int)$final_premium - (int) $tax;
    $proposal_be->update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium);
  }

}
