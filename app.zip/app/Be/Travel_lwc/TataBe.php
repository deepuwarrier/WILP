<?php 
namespace App\Be\Travel;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelConfig;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\TravelState;
use App\Models\Travel\TravelCity;
use App\Models\Travel\TravelPed;
use App\Models\Travel\TravelPolicy;
use App\Models\Travel\TravelRelationship;
use App\Constants\Travel_Constants;
use App\Constants\Common_Constants;
use App\Libraries\TravelLib;
use App\Helpers\Travel\Tata\TataQuotes;
use App\Helpers\Travel\Tata\TataProposal;
use App\Be\Travel\TravelProposalBe;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Be\Common\PaymentParseBE;
use Log;

class TataBe{
	
	private $lib, $set;
	public $policy_type_flag;

  	public function __construct(){
    	date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE); 
    	$this->policy_type_flag = 0; // For Policy Checking
    	$this->lib = new TravelLib;
  	}
  	
  	private function set_common_values($data, $code){
  	    // Function to set Common Fields of Individual & Floater Policy
  	    $config_tbl       = new TravelConfig;
  	    $config           = $config_tbl->get_data('config_key', 'tata');
  	    $tokens           = explode(',',Travel_Constants::$TATA_C_TOKENS);
  	    $token_values[]  = $config['tata_message_type'];
  	    $token_values[]  = $config['tata_message_version'];
  	    $token_values[]  = $config['tata_source_id'];
  	    $token_values[]  = $config['tata_gds_code'];
  	    $token_values[]  = $this->get_trans_id();
  	    $token_values[]  = $config['tata_agency_pcc'];
  	    $token_values[]  = $config['tata_agency_code'];
  	    $token_values[]  = $config['tata_user_id'];
  	    $token_values[]  = $config['tata_agent'];
  	    $token_values[]  = $config['tata_ctry_code'];
  	    $token_values[]  = $code; // PRODUCT CODE
  	    $token_values[]  = $this->get_destination($data, $this->policy_type_flag); //DESTINATION
  	    $token_values[]  = date("m/d/Y H:i:s A"); // TIME STAMP
  	    $token_values[]  = date("m/d/Y H:i:s A"); // START DATE
  	    $token_values[]  = ($this->policy_type_flag == 2) ? $this->get_end_date(date("Y/m/d"), '364') : $this->get_end_date(date("Y/m/d"), ($data["duration"] - 1) ); // END DATE
  	    $token_values[]  = ($this->policy_type_flag == 2) ? Travel_Constants::$TATA_AN_BENEFIT_CD : Travel_Constants::$TATA_R_BENEFIT_CD; // BENIFIT CODE
  	    return [$tokens, $token_values];
  	}
  	
  	public function set_indv_values($data, $code){
  	    // Setting Values to The XML Template for Individual Policy Type
  	    $xml             = $this->get_file(app_path(
  	                                       Travel_Constants::$TATA_INDV_FILE));
  	    $code            = ($data['area'] == '3') ? '020212' : $code; // For Asia Guard
  	    list($tokens, $token_values) = $this->set_common_values($data, $code);
  	    // End Asia Guard
  	    $tokens[]       = '{PLAN_CODE}';
  	    $token_values[] = $this->get_plancode($this->policy_type_flag, $data['sum-insured'], $data['area'], $data['dob'][0]); 
  	    $tokens[]       = '{DOB}';
  	    $token_values[] = $this->format_date($data["dob"][0]);
  	    return str_replace($tokens, $token_values , $xml);
  	}

    private function format_date($date){
      $dt   = \DateTime::createFromFormat('d-m-Y', $date);
      return $dt->format('m/d/Y');
    }
    
  	public function set_floater_values($data, $code){
  	    // Setting Values to The XML Template for Floater Policy Type
  	    $xml     = $this->get_file(app_path(
  	                                 Travel_Constants::$TATA_FLT_FILE));
  	    $code    = ($data['area'] == '3') ? '020212' : $code; // For Asia Guard
  	    // Setting Common Values to the Array
  	    list($tokens, $token_values) = $this->set_common_values($data, $code);
  	    $result  = str_replace($tokens, $token_values, $xml); // Result is having Basic XML Request till Insured tag.
  	    $insured = '';
  	    // Fetching Additional Insured XML Template
  	    $additional_insured_template = $this->get_file(app_path(
  	                                                     Travel_Constants::$TATA_INSR_FILE));
  	    // Concantinating XML fields for Insured, depends on number of travelers.
  	    $j = 0; // For DOB Traversal, because $data["dob"] array starts from 0
  	    for($i=1; $i<=$data['travelcount']; $i++){
  	        $insured .= $additional_insured_template;
  	        $insured = str_replace('{INSURED_FLAG}', $i, $insured);
            $formatted_dob = $this->format_date($data["dob"][$j]);
  	        $insured = str_replace('{DOB}', $formatted_dob , $insured);
  	        // Find out if any of the traveler is above 71, If so his plancode will be SNPLN
  	        if($this->lib->calculateAge($data['dob'][$j]) > 70){
  	            $insured = str_replace('{PLAN_CODE}', 'SENPLN', $insured);
  	        } else {
  	            // If traveler is not Senior, then Plancde is according to SUM INSURED
  	            $temp_input = $data;
  	            $temp_input['dob'][0] = $data['dob'][$j];
  	            $insured = str_replace('{PLAN_CODE}', $this->get_plancode($this->policy_type_flag, $data['sum-insured'], $data['area'], $data['dob'][0]), $insured);
  	        }
  	        $j++;
  	    }
  	    // Concantinating all Insured details with Basic XML Request.
  	    $result = str_replace('{ADDITIONAL_INSURED}', $insured, $result);
  	    return $result;  // To view the final XML request, do Log:info($result) or print_r($result)
  	}
  	
  	public function set_student($data, $plan){
  	    $xml              = $this->get_file(app_path(
  	                                        Travel_Constants::$TATA_STUD_FILE));
  	    list($ftokens, $ftoken_values) = $this->set_common_values($data, Travel_Constants::$TATA_STD_PRODUCT);
  	    $duration          = $this->lib->map_student_duration($data['std-duration']);
  	    $ftoken_values[11] = $plan['plan_destination'];
  	    $ftoken_values[15] = Travel_Constants::$TATA_STD_BENEFIT_CD;
  	    $ftoken_values[14] = $this->get_end_date(date("Y/m/d"), $duration - 1);
  	    $tokens[16]        = '{PLAN_CODE}';
  	    $token_values[16]  = $plan['plan_code'];
  	    $tokens[17]        = '{DOB}';
  	    $token_values[17]  = $this->format_date($data["dob"][0]);
  	    return str_replace(array_merge($ftokens,$tokens), array_merge($ftoken_values,$token_values), $xml);
  	}
  	  	
  	public function set_rerequest($data){
  	    $config_tbl       = new TravelConfig;
  	    $config           = $config_tbl->get_data('config_key', 'tata');
  	    $xml              = $this->get_file(app_path(
  	                                   Travel_Constants::$TATA_REREQUEST_FILE));
  	    $tokens           = explode(',',Travel_Constants::$TATA_REREQ_TOKENS);
  	    $token_values[]   = $config['tata_message_type'];
  	    $token_values[]   = $config['tata_message_version'];
  	    $token_values[]   = $config['tata_source_id'];
  	    $trans            = $this->get_trans_id();
  	    $token_values[]   = $trans;
  	    $xml              = str_replace($tokens, $token_values, $xml);
  	    $segment          = '';
  	    
  	    // With sublimit section
  	    $code             = '020952';
  	    $segment_xml      = $this->get_file(app_path(
  	                                 Travel_Constants::$TATA_SEGMENT_FILE));
  	    $segment_title    = explode(',',Travel_Constants::$TATA_SEGMENT_TOKENS);
  	    $segment_values[] = $trans;
  	    $segment_values[] = $config['tata_gds_code'];
  	    $segment_values[] = $config['tata_agency_pcc'];
  	    $segment_values[] = $config['tata_agency_code'];
  	    $segment_values[] = $config['tata_user_id'];
  	    $segment_values[] = $config['tata_agent'];
  	    $segment_values[] = $config['tata_ctry_code'];
  	    $segment_values[] = $code;
  	    $segment_values[] = $this->get_destination($data, 1); //DESTINATION
  	    $segment_values[] = date("m/d/Y H:i:s A"); // TIME STAMP
  	    $segment_values[] = date("m/d/Y H:i:s A"); // START DATE
  	    $segment_values[] = $this->get_end_date(date("Y/m/d"), ($data["duration"] - 1));
  	    $segment_xml      = str_replace($segment_title, $segment_values, $segment_xml);
  	    
  	    // Fetching Additional Insured XML Template
  	    $insured = '';  $j = 0;
  	    $additional_insured_template = $this->get_file(app_path(
  	                                      Travel_Constants::$TATA_INSR_FILE));
  	    $k = 1;
  	    for($i=1; $i<=$data['travelcount']; $i++){
  	        if($this->lib->calculateAge($data['dob'][$j])< 56){
  	            $insured .= $additional_insured_template;
  	            $insured  = str_replace('{INSURED_FLAG}', $k, $insured);
  	            $insured  = str_replace('{DOB}', $this->format_date($data["dob"][$j]), $insured);
  	            $temp_input = $data;
  	            $temp_input['dob'][0] = $data["dob"][$j];
  	            $insured  = str_replace('{PLAN_CODE}', $this->get_plancode(1, $temp_input['sum-insured'], $temp_input['area'], $temp_input['dob'][0]), $insured);
  	            $k++;
  	        }
  	        $j++;
  	    }
  	    $segment .= str_replace('{ADDITIONAL_INSURED}', $insured, $segment_xml);
  	    
  	    // Without sublimit section
  	    $code             = '020953';
  	    $segment_title    = array();
  	    $segment_values   = array();
  	    $segment_xml      = $this->get_file(app_path(
  	                               Travel_Constants::$TATA_SEGMENT_FILE)); 
  	    $segment_title    = explode(',',Travel_Constants::$TATA_SEGMENT_TOKENS);
  	    $segment_values[] = $trans;
  	    $segment_values[] = $config['tata_gds_code'];
  	    $segment_values[] = $config['tata_agency_pcc'];
  	    $segment_values[] = $config['tata_agency_code'];
  	    $segment_values[] = $config['tata_user_id'];
  	    $segment_values[] = $config['tata_agent'];
  	    $segment_values[] = $config['tata_ctry_code'];
  	    $segment_values[] = $code;
  	    $segment_values[] = $this->get_destination($data, $this->policy_type_flag); // DESTINATION
  	    $segment_values[] = date("m/d/Y H:i:s A"); // TIME STAMP
  	    $segment_values[] = date("m/d/Y H:i:s A"); // START DATE
  	    $segment_values[] = $this->get_end_date(date("Y/m/d"), ($data["duration"] - 1));
  	    $segment_xml      = str_replace($segment_title, $segment_values, $segment_xml);
  	    
  	    // Fetching Additional Insured XML Template
  	    $insured = '';  $j = 0; $k = 1;
  	    $additional_insured_template = $this->get_file(app_path(
  	                                              Travel_Constants::$TATA_INSR_FILE));
  	    for($i=1; $i<=$data['travelcount']; $i++){
  	        if($this->lib->calculateAge($data['dob'][$j]) >= 56){
  	            $insured .= $additional_insured_template;
  	            $insured  = str_replace('{INSURED_FLAG}', $k, $insured);
                $formatted_dob = $this->format_date($data["dob"][$j]);
  	            $insured  = str_replace('{DOB}', $formatted_dob , $insured);
  	            // Find out if any of the traveler is above 71, If so his plancode will be SNPLN
  	            if($this->lib->calculateAge($data['dob'][$j]) > 70){
  	                $insured = str_replace('{PLAN_CODE}', 'SENPLN', $insured);
  	            } else {
  	                // If traveler is not Senior, then Plancde is according to SUM INSURED
  	                $temp_input = $data;
  	                $temp_input['dob'][0] =  $data["dob"][$j];
  	                $insured = str_replace('{PLAN_CODE}', $this->get_plancode(1, $temp_input['sum-insured'], $temp_input['area'], $temp_input['dob'][0]), $insured);
  	            }
  	            $k++;
  	        }
  	        $j++;
  	    }
  	    
  	    $segment .= str_replace('{ADDITIONAL_INSURED}', $insured, $segment_xml);
  	    return str_replace('{SEGMENT}', $segment, $xml);
  	}
  	
  	public function clean_response($response){
  	    Log::info('TRAVEL_TATA_QUOTE_RESPONSE '. print_r($response,true));
  	    // Function to Reformat XML response Structure to Parse it.
  	    $startsAt = strpos($response, "<TINS_XML_DATA>") + strlen("<TINS_XML_DATA>");
  	    $endsAt   = strpos($response, "<endwaats>", $startsAt);
  	    return '<?xml version="1.0" encoding="UTF-8"?><TINS_XML_DATA>'.substr($response, $startsAt, $endsAt - $startsAt);
  	}
  	
  	public function set_floater_quote_response($result1, $result2, $type){
  	    if($type == 'A'){
      	    if(!$result1){
      	        return $result2;
      	    }
      	    if(!$result2){
      	        $response[] = $result1;
      	        return  $response;
      	    }
      	    // Returning Parsed Response
      	    $result[] = $result2[0];
      	    $result[] = $result1;
      	    if($result[0]['TotalPremium'] == 0){
      	        unset($result[0]);
      	    }
      	    if($result[1]['TotalPremium'] == 0){
      	        unset($result[1]);
      	    }
      	    return $result;
  	    }else{
  	        try{
  	            $result1[] = $result2[0];
  	        }catch(\Exception $e){
  	            $result1[] = $result2;
  	        }
  	        // Returning Parsed Response
  	        return $result1;
  	    }
  	}
  	
  	public function parse_quote_response($xml){
  	    if(strpos($xml, 'PolicyOut') !== false){ // If 'PolicyOut' is not there in XML then assuming that the response is an error message
  	        $dom = new \DOMDocument;
  	        $dom->loadXML($xml);
  	        $res = array();
  	        $insured = array();
  	        $i   = 0;
  	        //DOM Travering for Policy Details
  	        while(is_object($plans = $dom->getElementsByTagName("PolicyOut")->item($i))){
  	            foreach($plans->childNodes as $nodename){
  	                $res[$nodename->nodeName] = $nodename->nodeValue;
  	                
  	            } // End of Foreach loop
  	            $i++;
  	        }// End of While loop
  	        
  	        //DOM Travering for Insured Details
  	        $i       = 0;
  	        while(is_object($plans = $dom->getElementsByTagName("Insured")->item($i))){
  	            foreach($plans->childNodes as $nodename){
  	                $insured[$i][$nodename->nodeName] = $nodename->nodeValue;
  	            } // End of Foreach loop
  	            $i++;
  	        }
  	        
  	        //Premium Breakup
  	        $k = 0;
  	        $breakup = '';
  	        $params = $dom->getElementsByTagName('Segment');
  	        foreach ($params as $param){
  	            $params2 = $params->item($k)->getElementsByTagName('Insured'); 
  	            $i=0;
  	            foreach ($params2 as $p) {
  	                $params3 = $params2->item($i)->getElementsByTagName('PremiumAmt');
  	                $params4 = $params2->item($i)->getElementsByTagName('PlanCode');
  	                if($params4->item(0)->nodeValue === 'SENPLN')
  	                    $breakup .= $params3->item(0)->nodeValue.'@WS#SN,';
  	                    else
  	                        $breakup .= $params3->item(0)->nodeValue.',';
  	                        $i++;
  	            }
  	            $k++;
  	        }
  	        
  	        $sen_flag    = false;
  	        $other_flag  = false;
  	        $destination = $dom->getElementsByTagName("Destination")->item(0)->nodeValue;
  	        if(sizeof($insured)>1){
  	            foreach($insured as $data){
  	                if($data['PlanCode'] === 'SENPLN'){
  	                    $sen_flag = true;
  	                }
  	                if(($data['PlanCode'] === 'GOLD') || ($data['PlanCode'] === 'PLATNM')|| ($data['PlanCode'] === 'SILVER') || ($data['PlanCode'] === 'SILPLS')){
  	                    $other_flag = true;
  	                }
  	            }
  	            if($sen_flag){
  	                foreach($insured as $data){
  	                    if($data['PlanCode'] != 'SENPLN'){
  	                        $plan_tbl = new TravelPlan;
  	                        $column = array('plan_name');
  	                        $check_values = array('plan_code' => $data['PlanCode']);
  	                        $pname = $plan_tbl->get_data($column,$check_values);
  	                        $res['PlanDesc'] = $pname[0]['plan_name'];
  	                        $res['PlanCode'] = $data['PlanCode'];
  	                        $res['Seniorflag'] = true;
  	                    }
  	                }
  	            }else {
  	                $res['PlanDesc']        = $insured[0]['PlanDesc'];
  	                // To identify Asia Plans
  	                if($destination == 0){
  	                    $res['PlanCode'] = 'Asia-'.$insured[0]['PlanCode'];
  	                    $res['ProductDescription'] =  Travel_Constants::$TATA_ASIA_GUARD;
  	                }else {
  	                    $res['PlanCode'] = $insured[0]['PlanCode'];
  	                }
  	            }
  	        } else {
  	            // To identify Asia Plans
  	            if($destination == 0){
  	                $res['PlanCode'] = 'Asia-'.$insured[0]['PlanCode'];
  	                $res['ProductDescription'] =  Travel_Constants::$TATA_ASIA_GUARD;
  	            }else {
  	                $res['PlanCode'] = $insured[0]['PlanCode'];
  	            }
  	            $res['PlanDesc']  = $insured[0]['PlanDesc'];
  	            
  	            // Appending Student Guard Product Name.
  	            if(strpos($res['ProductDescription'], 'Student') !== false){
  	                $res['ProductDescription'] = Travel_Constants::$TATA_STUDENT_GUARD_P_NAME;
  	            }
  	        }

  	        $res['companyId']         = $this->lib->get_company_code('tata');
  	        $res['company_name']      = 'Tata Aig';
            $res['url_code']          = 'tata';
            $res['logo']              = 'image/logos/'.$res['companyId'].'_logo.png';
  	        $res['productCode']       = $dom->getElementsByTagName("GDSProductCode")->item(0)->nodeValue;
  	        $res['destinationCode']   = $dom->getElementsByTagName("Destination")->item(0)->nodeValue;
  	        $res['session_key']       = session('tr_suid');
            $res['trans_code']        = session('tr_suid');
  	        $res['policyId']          = uniqid(); 
  	        $res['NetPremiumAmt']     = $dom->getElementsByTagName("TotalPremium")->item(0)->nodeValue;
  	        $res['TotalTaxAmt']       = $dom->getElementsByTagName("TotalTaxAmt")->item(0)->nodeValue;
  	        $res['insurer']           = rtrim($breakup,',');
  	        $res['sum-insured']       = session('tata_si');

  	        $res['addon_id']          = null;
  	        $res['addon_value']       = null;
  	          	        
  	        if($res['productCode'] === '020953'){
  	            $res['ProductDescription'] = Travel_Constants::$TATA_TRV_GUARD;
  	            $res['shortDescription']   = Travel_Constants::$TATA_SQ_WITH_OUT_SUBLIMIT_TITLE;
  	        }elseif($res['productCode'] === '020952') {
  	            $res['ProductDescription'] = Travel_Constants::$TATA_TRV_GUARD;
  	            $res['shortDescription']   = Travel_Constants::$TATA_SQ_WITH_SUBLIMIT_TITLE;
  	        }
  	        
  	        if(isset($res['PlanDesc']) && $res['PlanDesc'] === 'Annual Platinum'){
  	            $res['PlanDesc'] = Travel_Constants::$TATA_AMT_PLAT_TITLE;
  	        }elseif(isset($res['PlanDesc']) && $res['PlanDesc'] === 'Annual Gold'){
  	            $res['PlanDesc'] = Travel_Constants::$TATA_AMT_GOLD_TITLE;
  	        }

  	        $this->save_quote($res);
  	        return $res; //Resultant Array
  	        
  	    } else {
  	        $dom = new \DOMDocument;
  	        $dom->loadXML($xml);
  	        $val = '';
  	        try{
  	            $val = $dom->getElementsByTagName("ErrorCode")->item(1)->nodeValue;
  	        }catch(\Exception $e){
  	            Log::info('TRAVEL_TATA_RE-REQUEST '. $e->getMessage());
  	            return null;
  	        }
  	        // Making Re-request for Without - With Sublimit in a single policy
  	        if($val === '24'){
  	            $re_request = new TataQuotes;
  	            return $re_request->re_submit_request();
  	        }
  	        return null;
  	    }
  	}   
  	
  	public function parse_re_request_response($xml){
  	    Log::info('TRAVEL_TATA_QUOTE_RESPONSE '. print_r($xml,true));
  	    if(strpos($xml, 'PolicyOut') !== false){
  	        $dom = new \DOMDocument;
  	        $dom->loadXML($xml);
  	        $res[0] = array();
  	        $insured = array();
  	        $i   = 0;
  	        //DOM Travering for Policy Details
  	        while(is_object($plans = $dom->getElementsByTagName("PolicyOut")->item($i))){
  	            foreach($plans->childNodes as $nodename){
  	                $res[$i][$nodename->nodeName] = $nodename->nodeValue;
  	            } // End of Foreach loop
  	            $i++;
  	        }// End of While loop
  	        $premium = 0; $tax = 0;
  	        if(sizeof($res) > 1){
  	            for($i=0; $i<sizeof($res); $i++){
  	                $premium += $res[$i]['TotalPremium'];
  	                $tax     += $res[$i]['TotalTaxAmt'];
  	            }
  	        }
  	        //DOM Travering for Insured Details
  	        $i       = 0;
  	        while(is_object($plans = $dom->getElementsByTagName("Insured")->item($i))){
  	            foreach($plans->childNodes as $nodename){
  	                $insured[$i][$nodename->nodeName] = $nodename->nodeValue;
  	            } // End of Foreach loop
  	            $i++;
  	        }
  	        //Premium Breakup
  	        $k = 0;
  	        $breakup = '';
  	        $params = $dom->getElementsByTagName('Segment');
  	        foreach ($params as $param){
  	            $params2 = $params->item($k)->getElementsByTagName('Insured'); //digg categories with
  	            $i=0;
  	            foreach ($params2 as $p) {
  	                $params3 = $params2->item($i)->getElementsByTagName('PremiumAmt');
  	                $params4 = $params2->item($i)->getElementsByTagName('PlanCode');
  	                if($k == 0){
  	                    $breakup .= $params3->item(0)->nodeValue.'@WS,';
  	                }else {
  	                    if($params4->item(0)->nodeValue === 'SENPLN')
  	                        $breakup .= $params3->item(0)->nodeValue.'@WTS#SN,';
  	                        else
  	                            $breakup .= $params3->item(0)->nodeValue.'@WTS,';
  	                }
  	                
  	                $i++;
  	            }
  	            $k++;
  	        }
  	        
  	        $sen_flag    = false;
  	        $destination = $dom->getElementsByTagName("Destination")->item(0)->nodeValue;
  	        if(sizeof($insured)>1){
  	            foreach($insured as $data){
  	                if($data['PlanCode'] === 'SENPLN'){
  	                    $sen_flag = true;
  	                }
  	            }
  	            if($sen_flag){
  	                foreach($insured as $data){
  	                    if($data['PlanCode'] != 'SENPLN'){
  	                        $pname = TravelPlan::select('plan_name')->where('plan_code', $data['PlanCode'])->get();
  	                        $res[0]['PlanDesc']   = $pname[0]['plan_name'];
  	                        $res[0]['PlanCode']   = $data['PlanCode'];
  	                        $res[0]['Seniorflag'] = true;
  	                    }
  	                }
  	            }else {
  	                $res[0]['PlanDesc']    = $insured[0]['PlanDesc'];
  	                // To identify Asia Plans
  	                if($destination == 0){
  	                    $res[0]['PlanCode'] = 'Asia-'.$insured[0]['PlanCode'];
  	                    $res[0]['ProductDescription'] =  Travel_Constants::$TATA_ASIA_GUARD;
  	                }else {
  	                    $res[0]['PlanCode'] = $insured[0]['PlanCode'];
  	                }
  	            }
  	        } else {
  	            // To identify Asia Plans
  	            if($destination == 0){
  	                $res[0]['PlanCode'] = 'Asia-'.$insured[0]['PlanCode'];
  	                $res[0]['ProductDescription'] = Travel_Constants::$TATA_ASIA_GUARD;
  	            }else {
  	                $res[0]['PlanCode'] = $insured[0]['PlanCode'];
  	            }
  	            $res[0]['PlanDesc']  = $insured[0]['PlanDesc'];
  	        }
       
  	        $res[0]['companyId']         = $this->lib->get_company_code('tata');
            $res[0]['logo']                 = 'image/logos/'.$res[0]['companyId'].'_logo.png';
  	        $res[0]['company_name']      = 'Tata Aig';
            $res[0]['url_code']          = 'tata';
  	        $res[0]['productCode']       = '020953';
  	        $res[0]['destinationCode']   = $dom->getElementsByTagName("Destination")->item(0)->nodeValue;
  	        $res[0]['session_key']       = session('tr_suid');
            $res[0]['trans_code']          = session('tr_suid');
  	        $res[0]['policyId']          = uniqid();
  	        $res[0]['NetPremiumAmt']       = $premium;
  	        $res[0]['TransactionPremAmt']  = $premium;
  	        $res[0]['TotalPremium']        = $premium;
  	        $res[0]['TotalTaxAmt']       = $tax;
  	        $res[0]['insurer']           = rtrim($breakup,',');
  	        $res[0]['sum-insured']       = session('tata_si');
  	        $res[0]['addon_id']          = null;
  	        $res[0]['addon_value']       = null;
  	        
  	        $res[0]['ProductDescription'] = Travel_Constants::$TATA_TRV_GUARD;
  	        $res[0]['shortDescription']   = Travel_Constants::$TATA_SQ_WITH_OUT_SUBLIMIT_TITLE;
            
  	        
  	        if($res[0]['PlanDesc'] === 'Annual Platinum'){
  	            $res[0]['PlanDesc'] = Travel_Constants::$TATA_AMT_PLAT_TITLE;
  	        }elseif($res[0]['PlanDesc'] === 'Annual Gold'){
  	            $res[0]['PlanDesc'] = Travel_Constants::$TATA_AMT_GOLD_TITLE;
  	        }
  	        if($res[0]['TotalPremium'] == 0){
  	            return null;
  	        }
  	        
  	        $this->save_quote($res[0]);
  	        return  $res[0];
  	    }
  	}

    private function get_quote_data($company){
        $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
        $exists     = Storage::disk('local')->exists(
                      Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
        if($exists){
          $data = json_decode(Storage::get(
                            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
          return $data[$company];
        }
    }
  	
  	private function save_quote($response){
  	    $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
  	    $exists     = Storage::disk('local')->exists(
  	        Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
  	    if($exists){
  	        $data = json_decode(Storage::get(
  	            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
  	        $data['tata'][$response['policyId']] = $response;
  	        Storage::disk('local')->put(
  	            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
  	    }else {
  	        $quote['tata'][$response['policyId']] = $response;
  	        Storage::disk('local')->put(
  	            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($quote));
  	    }
  	}
  	
  	public function clean_quote(){
  	    $filename   = Travel_Constants::getQuoteFileName(session('tr_suid'));
  	    $exists     = Storage::disk('local')->exists(
  	        Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename );
  	    if($exists){
  	        $data = json_decode(Storage::get(
  	            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
  	        $data['tata'] = array();
  	        Storage::disk('local')->put(
  	            Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
  	    }
  	}
  	
  	
  	private function get_end_date($date,$days){
  	    $date = strtotime("+".$days." days", strtotime($date));
  	    $date = date("m/d/Y", $date);
  	    return $date.' '.'11:59:59 PM';
  	}
  	
  	private function get_file($path){
  	    return File::get($path);
  	}
  	
  	private function get_trans_id(){
  	    //Format [GDS Code][Country Code][Timestamp]
  	    $config_tbl       = new TravelConfig;
  	    $config           = $config_tbl->get_data('config_key', 'tata');
  	    $time = date('Y').date('m').date('d').date('m').date('H').date('i');
  	    $code = $config['tata_gds_code'].$config['tata_ctry_code'].$time;
  	    $code = (strlen($code) > 24) ? substr($code,0,23) : $code;// Should not be greater than 24 characters
  	    return $code;
  	}
  	
  	public function get_student_plan($data){
  	    $destination = $this->get_destination($data, 1);
  	    $plan_tbl    = new TravelPlan;
  	    $column = array('plan_destination', 'plan_code');
  	    $check_values = array(Travel_Constants::TRAVEL_PLAN['DESTINATION'] => $destination,
  	                          Travel_Constants::TRAVEL_PLAN['SI'] => $data['sum-insured'],
  	                          Travel_Constants::TRAVEL_PLAN['COMPANY'] => 'tata',
  	                          Travel_Constants::TRAVEL_PLAN['TRIP_TYPE'] => 'ST');
  	    return $plan_tbl->get_data($column,$check_values);  
  	}
  	
  	private function get_plancode($triptype, $si, $area, $dob){
  	    if($triptype === 2){
  	        switch($si){
  	            case 250000 : return 'ANGOLD';
  	            break;
  	            case 500000 : return 'ANPLAT';
  	            break;
  	        }
  	    } else {
  	        if($this->lib->calculateAge($dob) >= 71){
  	            return 'SENPLN';
  	        }
  	        else {
  	            if($area == '3'){
  	                switch($si){
  	                    case 50000  : return 'SILVER';
  	                    break;
  	                    case 200000 : return 'GOLD';
  	                    break;
  	                }
  	            } else {
  	                switch($si){
  	                    case 50000  : return 'SILVER';
  	                    break;
  	                    case 100000 : return 'SILPLS';
  	                    break;
  	                    case 250000 : return 'GOLD';
  	                    break;
  	                    case 500000 : return 'PLATNM';
  	                    break;
  	                }
  	            }
  	        }
  	    }
  	}
  	
  	public function get_plan($data){ 
  	    $age = '';
  	    if($this->policy_type_flag == 1){
  	        // If Policy type is Individual
  	        $age = $this->lib->calculateAge($data['dob'][0]);
  	    } else {
  	        // If Policy type is Floater
  	        for ($i=0; $i<sizeof($data['dob']); $i++){
  	            $agelist[$i] = $this->lib->calculateAge($data['dob'][$i]);
  	        }
  	        $age = min($agelist); // Find Smallest age from agelist array
  	     }
  	     if($age < 56){ 
  	         return 'A'; 
  	     }elseif($data['area'] == 3){
  	        return 'A';
  	     }else { 
  	        return 'A&B'; 
  	     }
  	}
  	
  	private function get_destination($data, $type){
  	    // Destination Mapping for TATA AIG
  	    if($type == 2){
  	        switch($data["amt-duration"]){
  	            case 'SM' : $dest = 3;
  	            return $dest;
  	            break;
  	            case 'ME' : $dest = 4;
  	            return $dest;
  	            break;
  	            case 'LA' : $dest = 5;
  	            return $dest;
  	            break;
  	        }
  	    }
  	    else {
  	        switch($data["area"]){
  	            case 1 : $dest = 2;
  	            return $dest;
  	            break;
  	            case 2 : $dest = 1;
  	            return $dest;
  	            break;
  	            case 3 : $dest = 0;
  	            return $dest;
  	            break;
  	            case 4 : $dest = 1;
  	            return $dest;
  	            break;
  	        }
  	    }
  	}
  	
  	public function check_si($type, $si){
  	    if($type == 'S' || $type == 'ST'){
  	        $si_list = array('50000', '100000','200000','250000','500000');
  	        if(in_array($si,$si_list)){
  	            return true;
  	        } else {
  	            return false;
  	        }
  	    }
  	    if($type == 'M'){
  	        $si_list = array('250000', '500000');
  	        if(in_array($si,$si_list)){
  	            return true;
  	        } else {
  	            return false;
  	        }
  	        
  	    } 
  	} 
  	
  	public function check_age($data, $type){
  	    $age = $this->lib->calculateAge($data['dob'][0]);
  	    if($type === 'STUD'){
  	        if($age>15 && $age<36){
  	            return true;
  	        } else {
  	            return false;
  	        }
  	    }
  	    if($type === 'ST'){
  	        if($age>=71 && $data['sum-insured'] != '50000'){
  	            return false;
  	        } else {
  	            return true;
  	        }
  	    }
  	    if($type === 'MT'){
  	        if($age>18 && $age<71){
  	            return true;
  	        } else {
  	            return false;
  	        }
  	    }
  	}
  	
  	    public function getFirstLastName($names){
              try{
        $first_and_last_name = [];
                if(!is_array($names))
          $names = explode(",",$names);
        
        if(!is_array($names) || empty($names))
          return $first_and_last_name;

        foreach ($names as $key => $value) {
              if($value == ''){
                $first_and_last_name['first_name'][$key] = '';
                $first_and_last_name['last_name'][$key] = '';
              }else{
                if(strpos($value,'|' )){
                  $full_name = explode('|',$value);
                  $first_and_last_name['first_name'][$key] = $full_name[0];
                  $first_and_last_name['last_name'][$key] = $full_name[1];  
                }else{
                  $full_name = explode(' ',$value);
                  $first_and_last_name['first_name'][$key] = $full_name[0];
                  unset($full_name[0]);
                  $first_and_last_name['last_name'][$key] = implode(" ",$full_name);
                }
                
              }
        }  
      }catch(Exception $e){
        Log::info('getFirstLastName error'.$e->getMessage());
      }finally{
        return $first_and_last_name;  
      }
      
    }//


    public function get_proposal_inputs($trans_code){
        $company_column = 'tata_code';
        $bl = new TravelProposalBe;
        $data = $bl->get_proposal_inputs($trans_code, $company_column);
        
        $names = ['first_name'=>[],'last_name'=>[]];
        if(array_key_exists('name',$data['userdata']) && !empty($data['userdata']['name']))
          $names = $this->getFirstLastName($data['userdata']['name']);
        $data['userdata']['first_name'] = $names['first_name'];
        $data['userdata']['last_name'] = $names['last_name'];

        
        // Setting Trip Start Date 
        $data['userdata']['trip_start_date'] = $this->get_trip_start_date($data['userdata']['trip_start_date'], $data['userdata']['triptype']);

        // Setting Trip End Date 
        $data['userdata']['trip_end_date'] = $this->get_trip_end_date($data['userdata']);

        if($data['userdata']['triptype'] == 'ST'){
          $data['en_academic_tab'] = true;
        }  

        // Setting Guardian DOB
        $data['guardian_dob'] = $this->get_guardian_dob();

        // Setting Guardian Relationship
        $data['guardian_relationship'] = $this->get_guardian_relationship($data['userdata']['age_list']);
        return $data;
    }

    private function get_trip_end_date($userdata){
        $lib = new TravelLib;
        if($userdata['triptype'] == 'M'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], '364');
        }

        if($userdata['triptype'] == 'S'){
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $userdata['duration'] - 1);
        }

        if($userdata['triptype'] == 'ST'){
          $duration = $lib->map_student_duration($userdata['std_duration']);
          return $lib->add_days_with_date($userdata['trip_start_date']['selected_date'], $duration - 1);
        }

        
    } 

    private function get_trip_start_date($date, $trip_type){
        $lib = new TravelLib;
        $result = array();
        $duration = 179;
        $result['selected_date'] = ($date) ? $date : date("d-m-Y");
        $result['min_date']      = date("d-m-Y");
        $result['max_date']      = $lib->add_days_with_date(date("d-m-Y"), $duration);
        return $result;
    } 

    private function get_guardian_dob(){
        $lib = new TravelLib;
        $result = array();
        $result['selected_date'] = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['max_date']      = $lib->minus_year_from_date(date("d-m-Y"), '18');
        $result['min_date']      = $lib->minus_year_from_date(date("d-m-Y"), '99');
        return $result;
    }

    private function get_guardian_relationship($age_list){ 
        $age = rtrim($age_list[0],'Y');
        if($age < 18){
        return array(  0 => array ('relationship_code' => 'Mother', 
                                   'relationship_name' => 'Mother'),
                       1 => array ('relationship_code' => 'Father', 
                                   'relationship_name' => 'Father'));
        } 
        return array(  0 => array ('relationship_code' => 'Self', 
                                   'relationship_name' => 'Self'),
                       1 => array ('relationship_code' => 'Spouse', 
                                   'relationship_name' => 'Spouse'),
                       2 => array ('relationship_code' => 'Mother', 
                                   'relationship_name' => 'Mother'),
                       3 => array ('relationship_code' => 'Father', 
                                   'relationship_name' => 'Father'));
    }

    public function set_proposal_data($data){
      $session_key = $data['trans_code'];
      $trans_code  = $data['trans_code'];
      $section     = $data['id'];
      $usr_tbl     = new TravelUsrData;
      $columns     = array('relationship', 'gender', 'title');
      $t_data      = $usr_tbl->get_data($columns, session('tr_suid'));
      $relationship = explode(',', $t_data['relationship']);
      $travel_count = sizeof($relationship);
      $gender = explode(',', $t_data['gender']);
      $title = explode(',', $t_data['title']);
      $check_value = array('trans_code' => $trans_code);
      // Unsetting the extra values
      unset($data['trans_code']);
      unset($data['id']);
      unset($data['_token']);
      
      if(array_key_exists('first_name',$data))
      foreach ($data['first_name'] as $key => $value) {
        $data['name'][] = $data['first_name'][$key].'|'.$data['last_name'][$key];
      }

      
      if($section == 'travel'){
          $data['name'] = implode(',',$data['name']);
          $data['dob']  = implode(',',$data['dob']);
          $data['passport']  = implode(',',$data['passport']);
          if($travel_count<2){
            $data['gender'] = implode(',',$data['gender']);
            $data['title'] = ($data['gender'][0] == 'M') ? 'Mr' : 'Ms';
          }
          if(in_array('8', $relationship)){
            foreach ($data['gender'] as $key => $value) {
              $gender[$key] = $value;
              $title[$key] = ($value == 'M') ? 'Mr' : 'Ms';
            }
            $data['gender'] = implode(',', $gender);
            $data['title'] = implode(',', $title);
          }
      }
      if($section == 'medical_his'){
          if(isset($data['ped_choice'])){
                $ped['ped_choice'] = $data['ped_choice'];
                $ped['ped_details'] = (isset($data['ped_details'])) ? $data['ped_details'] : '' ;
                $data = array();
                $data['ped'] = json_encode($ped);
          }else{
                $data['ped'] = null;
          }        
      }
      $usr_tbl->set_data($data, $check_value);

    }

  public function get_proposal_preview_data($response, $userdata){
    $response['en_proposer_details'] = false;
    $response['en_sponser_relation'] = false;
    $response['en_insta_disclaimer'] = false;
    $response['trip_info']['purpose'] = null;
    $response['disclaimer']  =  Travel_Constants::$TATA_DISCLAIMER;
    if($userdata['triptype'] == 'ST'){
      $response['tata_licence'] = Travel_Constants::$TATA_INSTA_STD_LICENCE;
      $response['tata_version'] = Travel_Constants::$TATA_INSTA_STD_VERSION;
    }else{
      $response['tata_licence'] = Travel_Constants::$TATA_INSTA_LICENCE;
      $response['tata_version'] = Travel_Constants::$TATA_INSTA_VERSION;
    }
    $response['trip_info']['purpose'] = null;
    return $response;
  } 

  private function generate_xml($array, $tag = null){
    $xml = ($tag) ? '<'.$tag.'>' : '';
    foreach($array as $attribute => $value){
      $xml .=  '<'.$attribute.'>'.$value.'</'.$attribute.'>';
    }
    $xml .= ($tag) ? '</'.$tag.'>': '';
    return $xml;
  }


  private function get_gender($title){
    $gender_list = array();
    foreach ($title as $key => $value) {
      if($value == 'Mrs' || $value == 'Ms'){
        $gender_list[$key] = '1';
      }else{
        $gender_list[$key] = '0';
      }
    }
    return $gender_list ;
  }

  private function get_area_name($area){
    switch ($area){
      case 1 : return Travel_Constants::$WWD;
               break;
      case 2 : return Travel_Constants::$WWD_EXCL_USA;
               break;      
    }
  }
  
  public function get_user_agreement_data($data){
    $trans_code = $data['trans_code'];
    $usr_tbl    = new TravelUsrData;
    $column     = array('triptype','area');
    try{
    $userdata   = $usr_tbl->get_data($column,$trans_code);
    }catch(\Exception $e){
      $userdata   = null;
    } 
    return $userdata;
  }

  public function check_policy_ped($trans_code){
    $usr_tbl    = new TravelUsrData;
    $column     = array('ped');
    $userdata   = $usr_tbl->get_data($column,$trans_code);
    $ped        = json_decode($userdata['ped'], true);
    if($ped){
      if(isset($ped['ped_choice']) && isset($ped['ped_choice']['medical_history'])){
        return true;
      }
      if(isset($ped['ped_choice']) && isset($ped['ped_choice']['domestic_cover'])){
        return true;
      }
    }
    return false;
  }

  public function check_limits($trans_code){
    $usr_tbl = new TravelUsrData;
    $columns = array('age_list');
    $userdata = $usr_tbl->get_data($columns, $trans_code);
    $age_list   =  explode(',', $userdata['age_list']);
    $with_sub_limit_flag = false;
    $with_out_sub_limit_flag = false;
    foreach ($age_list as $key => $age) {
      $age = rtrim($age_list[$key], 'Y');
      if($age < 56){
        $with_sub_limit_flag = true;
      }
      if($age >= 56){
        $with_out_sub_limit_flag = true;
      }
    }
    if($with_sub_limit_flag == true && $with_out_sub_limit_flag == true){
        return 're_submit'; 
    }
    return null;
  }

  public function set_proposal($trans_code, $request_type = null){
    $usr_tbl      = new TravelUsrData;
    $config_tbl   = new TravelConfig;
    $state_tbl    = new TravelState;
    $city_tbl     = new TravelCity;
    $proposal_be  = new TravelProposalBe;
    $quote_data   = '';
    //$validation_arr = $this->validate_data($userdata);
    $config       = $config_tbl->get_data('config_key', 'tata');
    $trans_id     = $this->get_trans_id();
    session(['tata_trans_id' => $trans_id]);
    $userdata     = $usr_tbl->get_all_data($trans_code);
    $trip_start_date  = $this->format_date($userdata['trip_start_date']).' '.date("H:i:s A");
    $trip_end_date    = $this->format_date($userdata['trip_end_date']).' '.'11:59:59 PM';
    $user_id          = uniqid();
    try{
    $quote_data   = $this->get_quote_data('tata');
    $quote_data   = $quote_data[$userdata['quote_id']];
    }catch(\Exception $e){

    } 

    
    $name       = $this->getFirstLastName($userdata['name']);

    $dob        = explode(',', $userdata['dob']);
    $title      = explode(',', $userdata['title']);
    $passport   = explode(',', $userdata['passport']);
    $relationship =  explode(',', $userdata['relationship']); 
    $age_list   =  explode(',', $userdata['age_list']); 
    $guardian_dob = '';
    $gender     = $this->get_gender($title);

    //Header
    $data = array();
    $data['MessageType'] = $config['tata_message_type'];
    $data['Version'] = $config['tata_message_version'];
    $data['SourceId'] = $config['tata_source_id'];
    $data['MessageId'] = $trans_id;
    $header_xml = $this->generate_xml($data);

    //Policy
    $data = array();
    $data['GDSCode'] = $config['tata_gds_code'];
    $data['AgencyPCC'] = $config['tata_agency_pcc'];
    $data['AgencyCode'] = $config['tata_agency_code'];
    $data['OriginatingCity'] = 'INDIA';
    $data['FurthestCity'] = strtoupper($userdata['visiting_country']);
    $data['IATACntryCd'] = $config['tata_ctry_code'];
    $data['TransactionApplDate'] = date("m/d/Y H:i:s A");
    $data['InceptionDate']  = $trip_start_date;
    $data['ExpirationDate'] = $trip_end_date;
    $data['UserId'] = $user_id; 
    $data['TransactionEffDate'] = $trip_start_date;
    $data['TransactionExpDate'] = $trip_end_date;
    $data['GDSProductCode'] = ($userdata['area'] == '3') ? '020212' : $quote_data['productCode'];
    session(['tata_product_code' => $data['GDSProductCode']]);
    $data['Destination'] = $quote_data['destinationCode'];
    if($userdata['triptype'] == 'ST'){
      $data['GeneralPurpose1'] = $this->get_area_name($quote_data['destinationCode']);
    }
    $data['UserCd'] = $config['tata_user_id'];
    $data['Agent'] = $config['tata_agent'];
    $policy_xml = $this->generate_xml($data);

    //Address
    $data = array();
    $data['StreetLn1Nm'] = strtoupper($userdata['house_name']).','.strtoupper($userdata['street']);
    
    try{
    $check_values = array('city_name' => $userdata['city'], 'state_code' => $userdata['state']);  
    $city = $city_tbl->get_data($userdata['company_column'], $check_values);
    $data['CityNm'] = strtoupper($city[0][$userdata['company_column']]); 
    }catch(\Exception $e){

    }

    try{
    $check_values = array('state_code' => $userdata['state']);  
    $state = $state_tbl->get_data($userdata['company_column'], $check_values);
    $data['StateNm'] = strtoupper($state[0][$userdata['company_column']]); 
    }catch(\Exception $e){

    }

    $data['ZipCd'] = $userdata['pincode'];
    $data['CntryNm'] = 'INDIA';
    $data['EmailAddr'] = strtoupper($userdata['email']);
    $data['CellPhoneNo'] = $userdata['mobile'];
    $data['HomePhoneNo'] = $userdata['mobile'];
    $address_xml = $this->generate_xml($data);

    //Benefit Info
    $data = array();
    $data['BenefitCd'] = ($userdata['triptype'] == 'M') ? Travel_Constants::$TATA_AN_BENEFIT_CD : Travel_Constants::$TATA_R_BENEFIT_CD;
    $benefit_xml = $this->generate_xml($data);
    
    // Proposal normal submission
    if(!$request_type){
      //Insured
          $insured_xml = $this->get_insured_details($title, $name, $address_xml, $userdata['area'], $gender, $dob, $user_id, $quote_data['PlanCode'], $benefit_xml, $relationship, $age_list, $passport);


      //Segment
      $data = array();
      $data['TransactionId'] = $trans_id;
      $data['TransactionType'] = 'NQuote';
      $data['PolicyIn'] = $policy_xml;
      $segment_xml = $this->generate_xml($data);
      $segment_xml.= $insured_xml;
      
      //Proposal request xml 
      $data = array();
      $data['Header'] = $header_xml;
      $data['Segment'] = $segment_xml;
      $request_xml = $this->generate_xml($data,'TINS_XML_DATA');
      return $request_xml;
    }

    // Proposal re-submission
    if($request_type == 're_submit'){
      $title_balck_up = $title;
      $with_sublimit_insured_xml = '';
      $with_out_sublimit_insured_xml = '';
      $with_sublimit_keys = array();
      $total_keys = array();
      foreach ($age_list as $key => $age) {
        $age = rtrim($age_list[$key], 'Y');
        $total_keys[] = $key; 
        if($age < 56){
          $with_sublimit_keys[] = $key;
        }
      }
      $with_out_sublimit_keys = array_diff($total_keys,$with_sublimit_keys); 
      foreach ($with_sublimit_keys as $index => $key) {
        unset($title[$key]);
      }

            $with_out_sublimit_insured_xml = $this->get_insured_details($title, $name, $address_xml, $userdata['area'], $gender, $dob, $user_id, $quote_data['PlanCode'], $benefit_xml, $relationship, $age_list, $passport);


      foreach ($with_out_sublimit_keys as $index => $key) {
        unset($title_balck_up[$key]);
      }

            $with_sublimit_insured_xml = $this->get_insured_details($title_balck_up, $name, $address_xml, $userdata['area'], $gender, $dob, $user_id, $quote_data['PlanCode'], $benefit_xml, $relationship, $age_list, $passport);


      //With sub-limit Segment
      $data = array();
      $data['TransactionId'] = $trans_id;
      $data['TransactionType'] = 'NQuote';
      $data['PolicyIn'] = str_replace('020953','020952', $policy_xml);
      $with_sublimit_segment_xml = $this->generate_xml($data);
      $with_sublimit_segment_xml.= $with_sublimit_insured_xml;

      //With out sub-limit Segment
      $data = array();
      $data['TransactionId'] = $trans_id;
      $data['TransactionType'] = 'NQuote';
      $data['PolicyIn'] = $policy_xml;
      $with_out_sublimit_segment_xml = $this->generate_xml($data);
      $with_out_sublimit_segment_xml.= $with_out_sublimit_insured_xml;

      //Proposal request xml 
      $request_xml  = '<Header>'.$header_xml.'</Header>';
      $request_xml .= '<Segment>'.$with_sublimit_segment_xml.'</Segment>';
      $request_xml .= '<Segment>'.$with_out_sublimit_segment_xml.'</Segment>';
      $request_xml  = '<TINS_XML_DATA>'.$request_xml.'</TINS_XML_DATA>';
      return $request_xml;
    }

  }

   private function get_insured_details($title, $name, $address_xml, $area, $gender, $dob, $user_id, $plan_code, $benefit_xml, $relationship, $age_list, $passport){

    $insured_xml = '';
    $counter = 0;
    foreach ($title as $key => $title_data) {
      $data = array();
      if($counter == 0){
        $self_relation = $relationship[$key];
      }
      $age = rtrim($age_list[$key], 'Y');
      $data['TitleNm'] = $title_data;
      $data['FirstNm'] = $name['first_name'][$key];
      $data['LastNm'] = $name['last_name'][$key];

      $data['Relation'] = ($counter == 0) ? 'SELF' : $this->get_relationship($self_relation, $relationship[$key]);
      $data['Address'] = $address_xml;
      $data['IsInsuredFlag'] = ($counter == 0) ? '1' : '2';
      $data['GenderCd'] = $gender[$key];
      $data['BirthDt'] = $this->format_date($dob[$key]);
            $data['InsuredIdNo'] = strtoupper($passport[$key]);

      $data['PlanCode'] = ($age > 70 ) ? 'SENPLN' : $plan_code;
      $data['PlanCode'] = ($area == '3') ?  str_replace('Asia-','', $data['PlanCode']) : $data['PlanCode'];
      $data['BenefitIn'] = $benefit_xml;
      $insured_xml .= $this->generate_xml($data, 'Insured');
      $counter++;
    } 
    return $insured_xml;
  }

  private function get_relationship($self, $relationship){
    if($self == 1){
    $relation_tbl = new TravelRelationship;
    $column       = array('relationship_name');
    $check_values = array('relationship_id' => $relationship);
    $result = $relation_tbl->get_data($column,$check_values);
    $relationship = $result[0]['relationship_name'];
    return strtoupper($relationship);
    }
    if($self != 1){
      $relation_tbl = new TravelRelationship;
      $column       = array('relationship_name');
      $check_values = array('relationship_id' => $self);
      $result = $relation_tbl->get_data($column,$check_values);
      $self = strtolower($result[0]['relationship_name']);
      $check_values = array('relationship_id' => $relationship);
      $result = $relation_tbl->get_data($column,$check_values);
      $insured_relation = strtolower($result[0]['relationship_name']);
      if($self == 'father' && $insured_relation == 'mother'){
        return 'WIFE';
      }
      if(($self == 'father' || $self == 'mother' )  && $insured_relation == 'husband'){
        return 'SON';
      }
      if(($self == 'father' || $self == 'mother' ) && $insured_relation == 'wife'){
        return 'DAUGHTER';
      }
      if($self == 'mother' && $insured_relation == 'father'){
        return 'HUSBAND';
      }
      if($self == 'Other'){
        return 'OTHER';
      }
      return strtoupper($insured_relation);
    }
  }

  public function parse_policy($response,$trans_code=null){
    $payment_parse_be = new PaymentParseBE;
    Log::info('TRAVEL_TATA_PROPOSAL_RESPONSE '. print_r($response,true));
    // Function to Reformat XML response Structure to Parse it.
    $startsAt = strpos($response, "<TINS_XML_DATA>") + strlen("<TINS_XML_DATA>");
    $endsAt   = strpos($response, "<endwaats>", $startsAt);
    $clean_response_xml =  '<?xml version="1.0" encoding="UTF-8"?><TINS_XML_DATA>'.substr($response, $startsAt, $endsAt - $startsAt);
    if(strpos($clean_response_xml, 'PolicyOut') !== false){
      $usr_tbl = new TravelUsrData;
      $policy_resp_obj = new \SimpleXMLElement($clean_response_xml);
      $transaction_number = (string)$policy_resp_obj->Segment->TransactionId;
      $total_premium = 0;
      foreach ($policy_resp_obj->Segment as $segment) {
          $premium = (string)$segment->PolicyOut->TotalPremium;
          $total_premium =  $total_premium + $premium;
      }
      $columns = array('premium');
      $t_data  = $usr_tbl->get_data($columns, session('tr_suid'));
      $passed_premium = round($t_data['premium']);
      $table['finalPremium'] = $total_premium;
      $table['finalTax'] = (string)$policy_resp_obj->Segment->PolicyOut->TotalTaxAmt;
      $table['transaction_num'] = $transaction_number;
      $table['proposal_request'] = $clean_response_xml;
      $usr_tbl->update_data($table,session('tr_suid'));

      $url          = Travel_Constants::$TATA_PG_URL;
      $vcode        = Travel_Constants::$TATA_VENDOR_CODE;
      $refnumber    = session('tata_trans_id');
      $actual_premium = round($table['finalPremium']);
      $productcode  = session('tata_product_code');
      $action       = 'action';
      $producercode = Travel_Constants::$TATA_PRODUCER_CD; 
      $hash_key     = Travel_Constants::$TATA_HASH_CODE;
      session()->forget('tata_trans_id');
      session()->forget('tata_product_code');
      $url_encode   = $url.'?'.'vendorcode='.$vcode.'&referencenum='.$refnumber.'&amount='.$actual_premium.'&productcode='.$productcode.'&action='.$action.'&producercode='.$producercode;

      $hash_string  = $url_encode.$hash_key;
      $hash_value   = md5($hash_string);

      $pg_request['vendorcode']    = $vcode;
      $pg_request['referencenum']  = $refnumber;
      $pg_request['amount']        = $actual_premium;
      $pg_request['productcode']   = $productcode;
      $pg_request['action']        = $action;
      $pg_request['producercode']  = $producercode;
      $pg_request['hash']          = $hash_value;

      if($passed_premium != $actual_premium){

        // Status updation
        $proposal_status['reference_number'] = $refnumber;
        $proposal_status['response_msg'] = $response;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('premium_mismatch', $proposal_status); 
        // End Status updation


        $response =  array('status' => 0, 'mismatch' => 1, 'actual_premium' => $actual_premium, 'passed_premium' => $passed_premium,  'request' => $pg_request, 'pg_url' => $url);
      }

      if($passed_premium == $actual_premium){

         // Status updation
        $proposal_status['reference_number'] = $refnumber;
        $proposal_status['response_msg'] = $response;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('no_change_premium', $proposal_status); 
        // End Status updation

        $response =  array('status' => 1, 'premium' => $actual_premium,'request' => $pg_request, 'pg_url' => $url); 
      }
      $payment_parse_be->setPaymentIdentifier($trans_code, $refnumber);
      Log::info('TRAVEL_TATA_PG_REQUEST '. print_r($response,true));
      return $response;
    }

    if(strpos($clean_response_xml, 'PolicyOut') == false){
      $usr_tbl = new TravelUsrData;
      $policy_resp_obj = new \SimpleXMLElement($clean_response_xml);
      $status_code = (string)$policy_resp_obj->Segment->ErrorCode;  
      if($status_code == '24' ){
        $re_request = new TataProposal;
        return $re_request->re_submit_proposal();
      }else{

        // Status updation
        $proposal_status['response_msg'] = $response;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('proposal_error', $proposal_status); 
        // End Status updation
      }
    }

  }

  public function parse_pg_response($pg_response){
    $status = 0;

    $usr_tbl = new TravelUsrData;
    $proposal_be = new TravelProposalBe;
    $pg_response['policy_number'] = 0;
    $pg_response['transaction_num'] = 0;

    if(!session()->has('tr_suid')){
      return json_encode(['status'=> false, 'redirect' => true]) ;
    }


    // if(!empty($pg_response['msg'])){
      $response =  explode('||', $pg_response['msg']);
      $pg_response['transaction_num'] = $response[0];
      $payment_parse_be = new PaymentParseBE;
      $trans_code = $payment_parse_be->getPaymentIdentifier($pg_response['transaction_num']);

      // $trans_code  = session('tr_suid');
      $pg_response['message'] = $response[5];
      $pg_response['premium']  = round((int)$response[4]);
      if($response[6] == '0300'){

        // Status updation
        $proposal_status['reference_number'] = $pg_response['transaction_num'];
        $proposal_status['response_msg'] = json_encode($pg_response); 
        $proposal_be->update_payment_status('payment_success',$proposal_status);
        //End Status updation

        $status = 1;
        try{
        $columns = array('transaction_num', 'proposal_request');
        $t_data  = $usr_tbl->get_data($columns, session('tr_suid'));
        $transaction_num  = $t_data['transaction_num'];
        $proposal_request = $t_data['proposal_request'];
        $proposal_request = str_replace("NQuote","NSell",$proposal_request);
        }catch(\Exception $e){
          Log::info('TRAVEL_TATA_PG_RESPONSE'. $e->getMessage());
        }
        if($transaction_num){
          $helper   = new TataProposal;
          $schedule_response = $helper->schedule_policy($proposal_request);
         
          if($schedule_response){
            // Function to Reformat XML response Structure to Parse it.
            $startsAt = strpos($schedule_response, "<TINS_XML_DATA>") + strlen("<TINS_XML_DATA>");
            $endsAt   = strpos($schedule_response, "<endwaats>", $startsAt);
            $clean_response_xml =  '<?xml version="1.0" encoding="UTF-8"?><TINS_XML_DATA>'.substr($schedule_response, $startsAt, $endsAt - $startsAt);
            if(strpos($clean_response_xml, 'PolicyIn') !== false){ 
              $schedule_resp_obj = new \SimpleXMLElement($clean_response_xml);
              try{
               $policy_number = (string)$schedule_resp_obj->Segment->PolicyOut->PolicyNumber;
               $pg_response['policy_number'] = $policy_number;
               Log::info('TRAVEL_TATA_POLICY_NUMBER '. print_r($policy_number,true));
              }catch(\Exception $e){
                Log::info('TRAVEL_TATA_PARSE_POLICY_SCHEDULE_RESPONSE '. print_r($e->getMessage(),true));
              }
            }
          }
        }// end of transaction number check
      }else{
        //Status updation
        $proposal_status['reference_number'] = $pg_response['transaction_num'];
        $proposal_status['response_msg'] = json_encode($pg_response); 
        $proposal_be->update_payment_status('payment_failed',$proposal_status);
        $proposal_be->update_payment_status('policy_error',$proposal_status);
        //End Status updation
      } // End of status check
    // }// End of msg check
    if($status){
      $columns = array('policy_num' => $pg_response['policy_number']);

      // Status updation
      $proposal_be->update_payment_status('policy_accepted');
      //End Status updation

      $usr_tbl->update_data($columns, $trans_code);
      $user_data  = $usr_tbl->get_all_data($trans_code);
      $result = TravelPolicy::insert($user_data); 
      $this->update_log($user_data);

      $columns = array();
      $columns = array('trans_code' => $trans_code.'_DONE');
      $usr_tbl->update_data($columns, session('tr_suid'));
    }
    if(!$status){
      $columns = array('transaction_num' => $pg_response['transaction_num']);

      // Status updation
      $proposal_status['response_msg'] = json_encode($pg_response); 
      $proposal_be->update_payment_status('policy_error',$proposal_status);
      //End Status updation
      

      $usr_tbl->update_data($columns, $trans_code);
    }

    return json_encode(['status'=> $status,   
           'logo' => Travel_Constants::$TATA_LOGO, 
           'pg_response' => $pg_response]); 
  }

  public function update_log($user_data){
    $proposal_be = new TravelProposalBe;
    $insurer_code  = 'TATA';
    $agent_code    = $user_data['agent_code'];
    $policy_number = $user_data['policy_num'];
    $final_premium = $user_data['finalPremium'];
    $tax           = $user_data['finalTax'];
    $base_premium  = (int)$final_premium - (int) $tax;
    $proposal_be->update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium);
  }  
}  	
