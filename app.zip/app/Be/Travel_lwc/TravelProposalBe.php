<?php 
namespace App\Be\Travel;
use App\Helpers\Travel\Tata\TataProposal;
use App\Helpers\Travel\Hdfc\HdfcProposal;
use App\Helpers\Travel\Religare\ReligareProposal;
use App\Helpers\Travel\Star\StarProposal;
use App\Models\Travel\TravelRelationship;
use App\Models\Travel\TravelNomineeRelationship;
use App\Models\Travel\TravelState;
use App\Models\Travel\TravelCity;
use App\Models\Travel\TravelPed;
use App\Models\Travel\TravelOccupation;
use App\Models\Travel\TravelPlan;
use App\Models\Travel\OtpTData;
use App\Models\Travel\TravelTataPremium;
use App\Models\Travel\TravelPaymentMode;
use App\Models\Travel\TravelConfig;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPurpose;
use App\Models\Travel\TravelAddon;
use App\Models\Travel\TravelCountry;
use App\Libraries\TravelLib;
use App\Libraries\InstaLib;
use App\Constants\Travel_Constants;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\HdfcBe;
use App\Be\Travel\TataBe;
use App\Be\Travel\FggiBe;
use App\Be\Travel\ReligareBe;
use App\Be\Travel\StarBe;
use App\Http\Controllers\EmailSender;
use Illuminate\Support\Facades\Storage;
use App\Services\Client\PolicyCounterService;
use Log;
use App\Helpers\Email\EmailEngine;

class TravelProposalBe{
  private $tata_helper, $lib;
  public function __construct(){
        $this->tata_helper = new TataProposal;
        $this->hdfc_helper = new HdfcProposal;
        $this->religare_helper = new ReligareProposal;
        $this->star_helper = new StarProposal;
        $this->lib = new TravelLib;
        $this->email = new EmailSender;
  }

  private function trigger_event($tarns_status,$trans_code){
    $events =  ["TS14"=>"PROPOSALSUBMIT",
          "TS20"=>"PROPOSALSUBMIT",
          "TS01"=>"PROPOSALERROR",
          "TS17"=>"PAYMENTSUCESS",
          "TS02"=>"PAYMENTFAIL",
          "TS19"=>"POLICYSUCCESS",
          "TS03"=>"POLICYFAIL"];
    
    if(array_key_exists($tarns_status,$events)){
      $email_engine =  new EmailEngine;
      $email_engine->send_email($trans_code);
    }         
  }

  public function update_proposal_status($category, $data = null){
    $lib = new InstaLib;
    $usr_tbl = new TravelUsrData;
    $date = $lib->today_date_dMY();

    if($category == 'load_proposal_form'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS13',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS13'); 
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'submit_proposal'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS14',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS14'); 
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'premium_mismatch'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS21',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS21'); 
      if(isset($data['reference_number']) && !empty($data['reference_number'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_REF_NO']] = $data['reference_number']; 
      }
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'no_change_premium'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS15',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS15'); 
      if(isset($data['reference_number']) && !empty($data['reference_number'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_REF_NO']] = $data['reference_number'];
      }
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'proposal_error'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS01',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS01'); 
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'ped_case'){
      $column = array(Travel_Constants::USR_T_LOG['PROPOSAL_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PROPOSAL_STATUS'] => 'TS22',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS22'); 
      if(isset($data['reference_number']) && !empty($data['reference_number'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_REF_NO']] = $data['reference_number'];
      }
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PROPOSAL_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }
    $this->trigger_event($column[Travel_Constants::USR_T_LOG['TRANSST']],session('tr_suid'));
  }

  public function update_payment_status($category, $data = null){
    $lib = new InstaLib;
    $usr_tbl = new TravelUsrData;
    $date = $lib->today_date_dMY();
    if($category == 'proceed_payment'){
      $column = array(Travel_Constants::USR_T_LOG['PAYMENT_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PAYMENT_STATUS'] => 'TS16',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS16'); 
      $usr_tbl->update_data($column, session('tr_suid'));
    }
    if($category == 'payment_success'){
      $column = array(Travel_Constants::USR_T_LOG['PAYMENT_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PAYMENT_STATUS'] => 'TS17',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS17'); 
      if(isset($data['reference_number']) && !empty($data['reference_number'])){
          $column[Travel_Constants::USR_T_LOG['PAYMENT_REF_NO']] = $data['reference_number'];
      }
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PAYMENT_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'payment_failed'){
      $column = array(Travel_Constants::USR_T_LOG['PAYMENT_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['PAYMENT_STATUS'] => 'TS02',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS02'); 
      if(isset($data['reference_number']) && !empty($data['reference_number'])){
          $column[Travel_Constants::USR_T_LOG['PAYMENT_REF_NO']] = $data['reference_number'];
      }
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['PAYMENT_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'policy_initiated'){
      $column = array(Travel_Constants::USR_T_LOG['POLICY_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['POLICY_STATUS'] => 'TS18',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS18'); 
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'policy_accepted'){
      $column = array(Travel_Constants::USR_T_LOG['POLICY_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['POLICY_STATUS'] => 'TS19',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS19'); 
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'policy_error'){
      $column = array(Travel_Constants::USR_T_LOG['POLICY_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['POLICY_STATUS'] => 'TS03',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS03'); 
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['POLICY_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }

    if($category == 'conditional_policy'){
      $column = array(Travel_Constants::USR_T_LOG['POLICY_DATE'] => $date,
                      Travel_Constants::USR_T_LOG['POLICY_STATUS'] => 'TS22',
                      Travel_Constants::USR_T_LOG['TRANSST'] => 'TS22'); 
      if(isset($data['response_msg']) && !empty($data['response_msg'])){
          $column[Travel_Constants::USR_T_LOG['POLICY_DESC']] = $data['response_msg'];
      }
      $usr_tbl->update_data($column, session('tr_suid'));
    }
    $this->trigger_event($column[Travel_Constants::USR_T_LOG['TRANSST']],session('tr_suid'));
  } 

  public function update_log_table($insurer_code, $agent_code, $policy_number, $base_premium, $tax, $final_premium){
    try{
      $lib = new InstaLib;
      $date = $lib->today_date_dMY();
      $request_array = array( "module_name"=> "TV", 
                                "insurer_code"=> $insurer_code, 
                                "agent_code"=> $agent_code, 
                                "policy_date"=> $date, 
                                "policy_type"=> "C", 
                                "policy_nature"=> "New", 
                                "policy_number"=> $policy_number, 
                                "od_premium"=> 0, 
                                "tp_premium"=> 0, 
                                "total_premium"=> $base_premium,
                                "tax"=> $tax, 
                                "final_premium"=> $final_premium);
        
      $log_service = new PolicyCounterService;
      $log_response = $log_service->service_handler($request_array); 
      Log::info(session('tr_suid').' '. $log_response);
    }catch(\Exception $e){
      Log::info('Travel Log table update '. print_r($e->getMessage(), true));
      Log::info(session('tr_suid').' false');
    }
  }    
    
  public function set_proposal_preview($data){
      $user_tbl = new TravelUsrData;
      $state_tbl = new TravelState;
      $nom_tbl = new TravelNomineeRelationship;
      $occ_tbl = new TravelOccupation;
      $purpose_tbl = new TravelPurpose;
      $addon_tbl = new TravelAddon;
      $country_tbl = new TravelCountry;
      $data     = $user_tbl->get_all_data($data['trans_code']);
      $response['traveller_info']['name']     = explode(',', $data['name']);  
      foreach ($response['traveller_info']['name'] as $key => $value)
        $response['traveller_info']['name'][$key] = str_replace("|"," ",$value); 

      $response['traveller_info']['dob']      = explode(',', $data['dob']);
      $response['traveller_info']['passport'] = explode(',', $data['passport']); 
      $response['traveller_info']['aadhaar']  = explode(',', $data['aadhaar_num']);
      $occupation = explode(',', $data['occupation']);
      $age_list   = explode(',', $data['age_list']);
      $response['traveller_info']['member_count'] = $data['travelcount'];
      $response['traveller_info']['nominee_name'] = $data['nomineename'];
      try{
      $column       = array('relationship_name');
      $check_values = array($data['company_column'] => $data['nomineerel']);
      $tbl_response = $nom_tbl->get_value($column, $check_values);
      $response['traveller_info']['nominee_relation'] = $tbl_response[0]['relationship_name'];
      }catch(\Exception $e){
          $response['traveller_info']['nominee_relation'] = '';
      }

      $column       = array('occ_name');
      foreach ($occupation as $key => $value) {
        try{
        $check_values = array($data['company_column'] => $value);
        $tbl_response = $occ_tbl->get_value($column, $check_values);
        $response['traveller_info']['occupation'][] = $tbl_response[0]['occ_name'];
        }catch(\Exception $e){
            $response['traveller_info']['occupation'] = '';
        }
      }

      $response['traveller_info']['guardian_name'] = $data['guardian_name'];
      $response['traveller_info']['guardian_dob'] = $data['guardian_dob'];
      $response['traveller_info']['guardian_relationship'] =  $data['guardian_relationship'];
      $response['traveller_info']['en_add_on'] = false;
      
      $add_on = json_decode($data['add_on'], true);
      $add_on_array = array();
      if($add_on){
        foreach($add_on as $code => $status){
          if($status == 'Y'){
            try{
              $column  = array('add_on_title');
              $check_values = array('add_on_code' =>$code);
              $add_on_response = $addon_tbl->get_value($column, $check_values);
              $add_on_array[] = $add_on_response[0]['add_on_title'];
            }catch(\Exception $e){
             $add_on_array[] = null;
            }
          }
        }
      }

      $response['traveller_info']['add_on'] = (!empty($add_on_array)) ? implode(',',$add_on_array): '';
      $response['communication_info']['email'] = $data['email'];
      $response['communication_info']['mobile'] = $data['mobile'];
      $response['communication_info']['house_no'] = $data['house_name'];
      $response['communication_info']['street'] = $data['street'];
      $column = array('state_name');
      $check_values = array('state_code' => $data['state']);
      try{
      $state = $state_tbl->get_data($column, $check_values);
      $response['communication_info']['state'] = $state[0]['state_name'];
      }catch(\Exception $e){
          $response['communication_info']['state'] = 'No Record Found';
      }
      $response['communication_info']['city'] = $data['city'];
      $response['trip_info']['start_date'] = $data['trip_start_date'];
      $response['trip_info']['end_date'] = $data['trip_end_date'];

      $column = array('purpose_name');
      $check_values = array($data['company_column'] => $data['purpose']);
      try{
      $purpose = $purpose_tbl->get_value($column, $check_values);
      $response['trip_info']['purpose'] = $purpose[0]['purpose_name'];
      }catch(\Exception $e){
          $response['trip_info']['purpose'] = '';
      }

      $response['trip_info']['visiting_country'] = $data['visiting_country'];

      $response['academic_info']['university_name'] = $data['university_name'];
      $response['academic_info']['program_name'] = $data['program_name'];
      $response['academic_info']['program_duration'] = $data['program_duration'];
      $response['academic_info']['university_address'] = $data['university_address'];
      $response['academic_info']['university_country'] = $data['university_country'];
      $response['academic_info']['university_state'] = $data['university_state'];
      $response['academic_info']['university_city'] = $data['university_city'];
      $response['academic_info']['sponser_name'] = $data['sponser_name'];
      $response['academic_info']['sponser_dob'] = $data['sponser_dob'];

      try{
      $column       = array('relationship_name');
      $check_values = array($data['company_column'] => $data['sponser_relationship']);
      $tbl_response = $nom_tbl->get_value($column, $check_values);
      $response['academic_info']['sponser_relationship'] = $tbl_response[0]['relationship_name'];

      }catch(\Exception $e){
          $response['academic_info']['sponser_relationship'] = '';
      }

      $response['en_insta_disclaimer'] = true;
      $response['disclaimer']  =  Travel_Constants::$INSTA_DISCLAIMER;

      if($data['triptype'] == 'ST'){
          $response['en_academic_details'] = true;
          $response['en_proposer_details'] = true;
          $response['en_sponser_relation'] = false;
      }

      if($data['company_id'] == 'hdfc'){
        $hdfc_be  = new HdfcBe;
        $response = $hdfc_be->get_proposal_preview_data($response);
      }

      if($data['company_id'] == 'star'){
        $star_be  = new StarBe;
        $user_data['state'] = $data['state'];
        $user_data['city_list'] = $data['city_list'];
        $user_data['city'] = $data['city'];
        $user_data['temp_col_1'] = $data['temp_col_1'];
        $response = $star_be->get_proposal_preview_data($response,$user_data);
      } 

      if($data['company_id'] == 'religare'){
        $religare_be  = new ReligareBe;
        $user_data['triptype'] = $data['triptype'];
        $user_data['company_column'] = $data['company_column'];
        $user_data['age_list'] = $age_list;
        $user_data['guardian_relationship'] = $data['guardian_relationship'];
        $response = $religare_be->get_proposal_preview_data($response,$user_data);   
      }

      if($data['company_id'] == 'tata'){
        $tata_be  = new TataBe;
        $user_data['triptype'] = $data['triptype'];
        $response = $tata_be->get_proposal_preview_data($response, $user_data);
      }

      $response['ped_info'] = ($data['ped']!= null) ? json_decode($data['ped'], true) : null;

       // Setting PED information
      if($response['ped_info']){
          $ped_tbl  = new TravelPed;
          $column   = array('ped_short_code');

          foreach($response['ped_info']['ped_choice'] as $item => $value){
              $check_values = array($data['company_column'] => $item);
              try{
              $ped_info = $ped_tbl->get_value($column, $check_values);
                $response['ped_info']['short_code'][] = $ped_info[0]['ped_short_code'];
              }catch(\Exception $e){
                $response['ped_info']['short_code'][] = 'N/A';
              }
              
          }
      }
      
      return  $response;
  }
    
  public function get_proposal_inputs($trans_code, $company){
      $user_tbl = new TravelUsrData;
      $data['userdata']  = $user_tbl->get_all_data($trans_code);
      $filename      = Travel_Constants::getQuoteFileName($trans_code);
      $quote_data    = json_decode(Storage::get(
                                  Travel_Constants::TRAVEL_QUOTE_FILE_PATH . '/' . $filename), true);
      foreach($quote_data as $key => $value) {
          foreach($value as $id => $values) {
              if($id == $data['userdata']['quote_id']){
                  $data['quote_data'] = $values;
              }
          }
      }
      $data['userdata']['dob'] = explode(',' , $data['userdata']['dob']);
      $data['userdata']['age_list'] = explode(',' , $data['userdata']['age_list']);
      $data['userdata']['title']  = explode(',' , $data['userdata']['title']);
      $data['userdata']['gender'] = explode(',' , $data['userdata']['gender']);
      $data['userdata']['name'] = explode(',' , $data['userdata']['name']);
      $data['userdata']['passport'] = explode(',' , $data['userdata']['passport']);
      $data['userdata']['dob_list'] = $this->set_dob($data);
      $data['userdata']['ped'] = json_decode($data['userdata']['ped'], true);
      $data['userdata']['occupation'] = explode(',' , $data['userdata']['occupation']);
      $data['userdata']['visa_type'] = explode(',' , $data['userdata']['visa_type']);
      $data['userdata']['add_on'] = json_decode($data['userdata']['add_on'], true);
      
      //Setting Add-on list
      $addon_tbl = new TravelAddon;
      $column  = array('add_on_code','add_on_title', 'add_on_description');
      try{
          $data['addon_list'] = $addon_tbl->get_data($column, $company);
      }catch(\Exception $e){
          $data['addon_list'] = null;
      }

      //Setting PED List
      $ped_tbl = new TravelPed;
      $column  = array('ped_code','ped_title', 'ped_short_code', $company);
      try{
          $data['ped_list'] = $ped_tbl->get_data($column, $company);
      }catch(\Exception $e){
          $data['ped_list'] = null;
      }

      //Setting Sub PED List
      if($data['ped_list']){
        $ped_tbl = new TravelPed;
        $column  = array('ped_title', 'ped_short_code', $company);

        foreach($data['ped_list'] as $index => $item){
          $check_values  = array('ped_group' => $item['ped_code']);
          try{
              $response = $ped_tbl->get_sub_ped_data($column, $check_values);
              if($response){
                $data['sub_ped_list'][$item['ped_code']] = $response;
              }
          }catch(\Exception $e){
              
          }
        }
        
      }  

      //Setting Occupation List
      $occ_tbl = new TravelOccupation;
      $column  = array('occ_name', $company);
      try{
          $data['occupation_list'] = $occ_tbl->get_data($column, $company);
      }catch(\Exception $e){
          $data['occupation_list'] = null;
      }

      //Setting Purpose of visit List
      $purpose_tbl = new TravelPurpose;
      $column  = array('purpose_name', $company);
      try{
          $data['purpose_list'] = $purpose_tbl->get_data($column, $company);
      }catch(\Exception $e){
          $data['purpose_list'] = null;
      }

      // For Relationship
      $relation_tbl = new TravelRelationship;
      $column       = array('relationship_name','relationship_gender');
      $temp         = array();
      $data['userdata']['relationship'] = explode(',', $data['userdata']['relationship']);
      foreach($data['userdata']['relationship'] as $value){
          $check_values = array('relationship_id' => $value);
          $result = $relation_tbl->get_data($column,$check_values);
          $temp['relation'][] = $result[0]['relationship_name'];
      }
      $data['userdata']['relationship'] = $temp['relation'];

      $state_tbl  = new TravelState;
      $column     = array('state_name', 'state_code');
      $check_values = $company;
      try{
      $data['state_list'] = $state_tbl->get_all_data($column,$check_values);
      }catch(\Exception $e){
        $data['state_list'] = null;
      }

      // Setting City List, If User already filled state
      $city_tbl = new TravelCity;
      if($data['state_list']){
          try{
              $check_values = array('state_code' => $data['userdata']['state']);
              $data['city_list'] = $city_tbl->get_data('city_name',$check_values);
          }catch(\Exception $e){
              $data['city_list'] = null;
          }
      }

      $cntry_tbl  = new TravelCountry;
      $column     = array('country_name', $company);
      $check_values = $company;
      try{
      $data['country_list'] = $cntry_tbl->get_data($column,$check_values);
      }catch(\Exception $e){
        $data['country_list'] = null;
      }

      $nominee_tbl  = new TravelNomineeRelationship;
      $column     = array('relationship_name', $company);
      $check_values = $company;
      try{
      $data['nominee_list'] = $nominee_tbl->get_data($column,$check_values);
      }catch(\Exception $e){
        $data['nominee_list'] = null;
      }

      if($data['userdata']['triptype'] == 'M'){
         if($data['userdata']['amt_duration'] == 'SM'){
             $data['basic_info']['trip_info'] =  '1 - 30 Days Annual Multi Trip';
         }else if($data['userdata']['amt_duration'] == 'ME'){
             $data['basic_info']['trip_info'] =  '1 - 45 Days Annual Multi Trip';
         }else if($data['userdata']['amt_duration'] == 'LA'){ 
             $data['basic_info']['trip_info'] = '1 - 60 Days Annual Multi Trip';
         }else if($data['userdata']['amt_duration'] == 'L90'){ 
             $data['basic_info']['trip_info'] = '1 - 90 Days Annual Multi Trip';
         }
      }
      
      if($data['userdata']['triptype'] == 'S'){
          $data['basic_info']['trip_info'] = $data['userdata']['duration'] > 1 ? $data['userdata']['duration'].' Days Single Trip' : $data['userdata']['duration'].' Day Single Trip';
      }
      
      if($data['userdata']['triptype'] == 'ST'){
          if($data['userdata']['std_duration'] == 'std_one'){
              $data['basic_info']['trip_info'] = '1 Year Student Trip';
              $data['basic_info']['std_days'] = 365;
          }else if($data['userdata']['std_duration'] == 'std_two'){
              $data['basic_info']['trip_info'] = '2 Year Student Trip';
              $data['basic_info']['std_days'] = 730;
          }else{
              $data['basic_info']['std_days'] = substr($data['userdata']['std_duration'],4,strlen($data['userdata']['std_duration']));
              $data['basic_info']['trip_info'] =  $data['basic_info']['std_days'].' Days Student Trip';
          }
          
      }
      $data['basic_info']['member_info'] = $data['userdata']['travelcount'] >1 ? $data['userdata']['travelcount'].' Travelers' : 'Single Traveler' ;
      $quote_bl = new TravelQuoteBe;
      $data['basic_info']['location_info'] = $quote_bl->get_area_title($data['userdata']); 
      $data['basic_info']['age_info']  = implode(',',$data['userdata']['age_list']);
      $data['basic_info']['product_title'] = $data['quote_data']['ProductDescription'];
      $data['basic_info']['plan_code'] = $data['quote_data']['PlanCode'];
      $data['basic_info']['plan_title'] = $data['quote_data']['PlanDesc'];
      $data['basic_info']['company_id'] = $data['quote_data']['companyId'];
      $data['basic_info']['company_name'] = $data['quote_data']['company_name'];
      $si_symbol = (strpos($data['quote_data']['PlanDesc'], 'Europe') !== false || strpos($data['quote_data']['ProductDescription'], 'Schengen')) ? '&#8364;' : '$';
      $data['basic_info']['sum_insured'] = $si_symbol.$data['quote_data']['sum-insured'];
      $data['basic_info']['total_premium']  = '&#8377;'.round($data['quote_data']['NetPremiumAmt']);
      $data['basic_info']['tax'] = '&#8377;'.$data['quote_data']['TotalTaxAmt'];
      $data['basic_info']['company_code'] = $company;
      
      $columns = array('company_id' => $data['basic_info']['company_id'], 
                      'company_column' => $company, 
                      'plan_code' => $data['basic_info']['plan_code']);
      
      $check_value = array('trans_code' => $trans_code);
      $user_tbl->set_data($columns, $check_value);
      $table = array();
      $table['finalPremium'] = Null;
      $table['finalTax']     = Null;
      $res =  $user_tbl->update_data($table,session('tr_suid'));
      
      return $data;
  }
  
  private function set_dob($data){
      $data['userdata']['dob'] = array();
      foreach($data['userdata']['age_list'] as $index => $age){
          $data['userdata']['dob'][] = $this->dob_generator(rtrim($age,"Y"));
      }
      return $data['userdata']['dob'];
  }
  
  public function dob_generator($age){
      $child_flag = false;
      $lib = new TravelLib;

      for($i=1; $i<12 ; $i++){
          if($age == $i.'M'){
            $child_flag = true;
            $effectiveDate = strtotime("-".$i." months", strtotime(date("Y-m-d")));
            $birthdate = date("Y-m-d", $effectiveDate);
            $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
          }
      }

      if(!$child_flag){
        $birthdate = date("Y-m-d", strtotime($age. 'years ago'));
        $data['selected_date'] = date("d-m-Y", strtotime($birthdate));
      } 
     
      $min_date = $lib->minus_year_from_date($data['selected_date'], '1');
      $data['min_date']  = $lib->add_days_with_date($min_date, '1');
      $data['max_date']  = $data['selected_date'];

      return $data;
  }
  
  public function get_trip_end_date($data){
      $lib = new TravelLib;
      return $lib->add_days_with_date($data['start_date'], $data['duration'] - 1);
  }

  public function get_city($data){
    $city_tbl = new TravelCity;
    $check_values = array('state_code' => $data['state_code']);
    return $city_tbl->get_data($data['company_column'], $check_values);
  }
  
  public function get_uid($mobile){
    $result =  OtpTData::select('otp_id')->where('mobile', $mobile)->get(); 
    if ($result->isEmpty()) {
      return '0124';
    }else {
      return $result[0]['otp_id'];
    }
  }

  public function get_paymode($data){
    $paymode_tbl = new TravelPaymentMode;
    $column      = ''; 
    if($data['companyId'] == 'hdfc'){
      $column = 'hdfc_code';
    }
    if(!empty($column)){
      return $paymode_tbl->get_data($column);
    }
    return false;
  }
}  