<?php

namespace App\Constants;

class Car_Constants {
	const NOMINEE_REL = ['Brother','Child','Daughter','Employee','Employer','Legal Executor','Grandchild','Grandparent','Guardian','Husband','Main Driver','Parent','Partner','Self','Sibling','Sister','Son','Spouse','Wife','Mother','Father','Others'];

	const Car_Reg_Current_Year = '2018';
	
	const UIIC_GST_CODE = '29';
        const UIIC_PRODUCT_CODE = 3114;
	const UIIC_SUBPRODUCT_CODE  = 18;
	const UIIC_OEM_DEALER_CODE = 'BRC0000702';

	const HDFC_PARTNER_CODE =  'TTIB0001';

	const DISPLAY_NAME = ['basic'=>['od'=> 'Own Damage'
						          ,'ll' => 'Legal Liability'
						          ,'pa' => 'Personal Accident'
						          ,'tp' => 'Third Party Liability']
						 ,'addon'=>['rti' => 'Return to Invoice'
									,'zerodep' => 'Zero Depreciation'
									,'ep' => 'Engine Protect'
									,'papass'=>'PA to Unnamed Passengers (1 Lac)'
									,'rsac'=>'Enhanced Roadside Assistance']
						 ,'discounts'=>['od' => 'OD Discount'
									,'ncbbenefit' => 'No Claim Bonus']
						 ,'totalpremium' => 'Total Premium'
						 ,'serviceTax' => 'Goods & Service Tax'
						 ,'netPremium' => 'Net Premium'			
						];
	const TATA_DISPLAY_NAME = ['basic'=>['od'=> 'Own Damage'
						        	,'ll' => 'Legal Liability'
						        	,'pa' => 'Personal Accident'
						        	,'tp' => 'Third Party Liability'
						        	,'lpb'=>'Loss of Personal Belongings'
									,'et_hotelexpenses'=>'Emergency Hotel & Transportation'
									,'keyreplace'=>'Key Replacement'
									,'cosumable_expenses'=>'Comsumable Expenses'
									,'repair_of_glass'=>'Repair of glass, plastic fibre and rubber glass'
									,'rsac' => 'Enhanced Roadside Assistance'
									,'ncbprotect' => 'NCB Protection'
									,'zerodep' => 'Zero Depreciation'
									,'rti' => 'Return to Invoice'
									,'ep' => 'Engine Protect'
									,'daily_allowance'=>'Daily Allowance '
									,'ts'=>'Tyre Secure'
						]
						 ,'addon'=>['rti' => 'Return to Invoice'
									,'zerodep' => 'Zero Depreciation'
									,'ep' => 'Engine Protect'
									,'papass'=>'PA to Unnamed Passengers (1 Lac)'
									,'rsac'=>'Enhanced Roadside Assistance']
						 ,'discounts'=>['od' => 'OD Discount'
									,'ncbbenefit' => 'No Claim Bonus']
						 ,'totalpremium' => 'Total Premium'
						 ,'serviceTax' => 'Goods & Service Tax'
						 ,'netPremium' => 'Net Premium'			
						];
	const GST = 18;
	const RSGI_QUOTE_URL = 'https://dtc.royalsundaram.in/DTCWS/Services/Product/PrivateCar/CalculatePremium';
	const CAR_MAKE_TABLE = 'car_m_make';
	const CAR_MODEL_TABLE = 'car_m_models';
	const CAR_VARIANT_TABLE = 'car_m_variant';
	const RSGI_QUOTE_UPDATE_URL = 'https://dtc.royalsundaram.in/DTCWS/Services/Product/PrivateCar/UpdateVehicleDetails';
	const RSGI_PROPOSAL_URL = 'https://dtc.royalsundaram.in/DTCWS/Services/Product/PrivateCar/GProposalService';
	const RSGI_PAYMENT_URL = 'https://www.royalsundaram.in/web/dtc/paymentgateway';
	const RSGI_AGENT_CODE = 'BA503014';
	const RSGI_API_KEY = '310ZQmv/bYJMYrWQ1iYa7s43084=';

	const REQUIRED_FG = 1;
	const MAXIUM_CALL_API = 2;
	const PREMIUM_MISSMATCHALLOWED_UP_TO = 2;
	const OTP_LENGTH = 4;
	const MAX_OTP = 3;
	const SEATING_CAPACITY = 5;
	const OCCUPATION = 1;
	const PREV_TAB_TEXT_NEWBUSINESS = 'Nominee Details';
	const PREV_TEXT_NEWBUSINESS = 'Enter the Insurance Details!';
	const PREV_TAB_TEXT_ROLLOVER = 'Previous Insurer';
	const PREV_TEXT_ROLLOVER = 'Enter the Previous Year Insurance Details!';

	const FG_STATIC = ['nationality'=>65
					,'occupationType'=>'OTHR'
					,'roadTypeCodes' => 5
					,'dailyMillage' => 2
					,'garageType' => 12
					,'currentMillage' => 9000];


	const AUTH = array('accesskey' => 'TTIBI', 'secretkey' => 'TTIBI');
	const API_BASE = "http://api.brokeredge.in";
	const YOR_SEL_ST = "YOR_SELECT_START";
	const YOR_SEL_DUR = "YOR_SELECT_UPTO";
	const POLICY_S_DATE_DIFF = "POLICY_S_DATE_DIFF";
	const POLICY_E_DATE_DIFF = "POLICY_E_DATE_DIFF";
	const YOR_SELECT_START = "YOR_SELECT_START";
	const CAR_REGIS_DATE_DIFF = "CAR_REGIS_DATE_DIFF";
	const CAR_INSURER_TABLE = "car_m_insurer";
	const CAR_YOM_DROPDOWN_VALUE = "CAR_YOM_DROPDOWN_VALUE";
	const CAR_REGIS_MAX_DAYS = "CAR_REGIS_MAX_DAYS";
	const CAR_REGIS_MIN_DAYS = "CAR_REGIS_MIN_DAYS";
	const POLICY_START_MAX_DAYS = "POLICY_START_MAX_DAYS";
	const POLICY_START_MIN_DAYS = "POLICY_START_MIN_DAYS";
	const POLICY_EXP_MAX_DAYS = "POLICY_EXP_MAX_DAYS";
	const POLICY_EXP_MIN_DAYS = "POLICY_EXP_MIN_DAYS";
	const DOB_AGE_RESTRICTION = "DOB_AGE_RESTRICTION";
	// IDV variant percentage
	const IDV_VARIANT_PERCENTAGE = "IDV_VARIANT_PERCENTAGE";
	// Default addon added
	const DEFAULT_ADDON_ADDED = ['PA','LL'];
	// Default cover selected
	const DEFAULT_COVER_SELECTED = "#,#,#,";
	const LOGOPATH = 'image/logos/';
	const LOGO = ["unitedindia" => self::LOGOPATH . '545.png',
		"lntinsurance" => self::LOGOPATH . '146.png',
		"unisompo" => self::LOGOPATH . '134.png',
		"bhartiaxa" => self::LOGOPATH . '139.png',
		"futuregenerali" => self::LOGOPATH . '132.png',
		"bajajallianz" => self::LOGOPATH . '113.png',
		"hdfcergo" => self::LOGOPATH . '125.png',
		"iffcotokio" => self::LOGOPATH . '106.png',
		"rsgi" => self::LOGOPATH . 'rsgi_logo.png',
		"tataaig" => self::LOGOPATH . 'tata_logo.png',
		"reliance"=> self::LOGOPATH . 'reliance_logo.png'
	];

	const CMP_LOGO = ["unitedindia" => self::LOGOPATH . '545.png',
		"lntinsurance" => self::LOGOPATH . '146.png',
		"unisompo" => self::LOGOPATH . '134.png',
		"bhartiaxa" => self::LOGOPATH . '139.png',
		"futuregenerali" => self::LOGOPATH . '132.png',
		"bajajallianz" => self::LOGOPATH . '113.png',
		"hdfc" => 'hdfcgi_logo.png',
		"iffcotokio" => self::LOGOPATH . '106.png',
		"rsgi" => self::LOGOPATH . 'rsgi_logo.png',
		"reliance"=> self::LOGOPATH . 'reliance_logo.png'];


	// session key
	const PROPOSAL_FORM_DATA = 'proposal_form_data';
	const PROPOSAL_FORM_RESULT = 'proposal_form_result';
	const PROPOSAL_REQUEST_URL = 'proposal_request_url';

	// table key container
	const CAR_T_USERLOG = ['SESSION_ID' => 'session_id',
		'USR_TYPE' => 'usr_type',
		'USR_GENDER' => 'usr_gender',
		'USR_DOB' => 'usr_dob',
		'TRANS_CODE' => 'trans_code',
		'USR_COMPANYNAME' => 'usr_companyname',
		'USR_CONTACTPERSON' => 'usr_contactperson',
		'USR_FIRSTNAME' => 'usr_firstname',
		'USR_LASTNAME' => 'usr_lastname',
		'USR_EMAIL' => 'usr_email',
		'USR_MOBILE' => 'usr_mobile',
		'USR_PAN' => 'usr_pan',
		'USR_AADHARNO'	=> 'usr_aadharno',
		'USR_TITLE' => "usr_title",
		'USR_STATE_CODE' => "usr_state_code",
		'USR_CITY_CODE' => "usr_city_code",
		'USR_MARITALSTATUS' => "usr_marital_status",
		'USR_CAPITAL' => 'usr_capital',
		'USR_CUSTSUBTYPE' => 'usr_custsubtype',
		'USR_NATIONALITY' => 'usr_nationality',
		'OCCUPATION' => "usr_occupation",
		'HOUSENO' => 'usr_houseno',
		'STREET' => 'usr_street',
		'LOCALITY' => 'usr_locality',
		'PINCODE' => 'usr_pincode',
		'PERM_HOUSENO'=>'prem_usr_houseno',
		'PERM_STREET'=>'prem_usr_street',
		'PERM_LOCALITY'=>'prem_usr_locality',
		'PERM_PINCODE'=>'prem_usr_pincode',
		'PERM_USR_STATE_CODE'=>'prem_usr_state_code',
		'PERM_USR_CITY_CODE'=>'prem_usr_city_code',
		'REG_ADD_IS_SAME' => 'reg_add_is_same',
		'BODYTYPE' => 'veh_bodytype',
		'CHASSISNO' => 'veh_chassisno',
		'COLOR' => 'veh_color',
		'ELECTRICAL' => 'veh_electricle',
		'ELECTRICAL_DATE' => 'veh_electricle_date',
		'ENGNO' => 'veh_eng_no',
		'NON_ELECTRICAL' => 'veh_no_electricle',
		'NON_ELECTRICAL_DATE' => 'veh_no_electricle_date',
		'REGNO' => 'veh_reg_no',
		'YOM' => 'veh_yom',
		'CURRENTMILLAGE' => 'veh_current_millage',
		'DAILYMILLAGE' => 'veh_daily_millage',
		'GARAGETYPE' => 'veh_garage_type',
		'PREFERREDREPAIR' => 'veh_preferred_repair',
		'ROADTYPECODES' => 'veh_road_type_codes',
		'EXTERNAL_CNG' => 'veh_cng_external',
		'EXTERNAL_CNG_VALUE' => 'veh_cng_external_value',
		'NOMINEENAME' => 'nominee_name',
		'NOMINEEREL' => 'nominee_rel',
		'POLICYNO' => 'prev_policyno',
		'PREVINSURANCE' => 'prev_insurance',
		'PREVCLAIM' => 'prev_claim',
        'CLAIM_AMOUNT_RECEIVED' => 'claim_amount_received',
		'NOMINEEAGE' => "nominee_age",
		'PREVIOUSPOLICYTYPE' => 'prev_policy_type',
		'DRIVER_CLAIMHISTORY' => 'driver_claim_history',
		'DRIVER_DOB' => 'driver_dob',
		'DRIVER_GENDER' => 'driver_gender',
		'DRIVER_NAME' => 'driver_name',
		'DRIVER_EXPERIENCE' => 'driver_experience',
		'DRIVER_NOOFACCIDENTS' => 'driver_nu_accidents',
		'DRIVER_QUALIFICATION' => 'driver_qualification',
		'PREV_NCBDECLARATIONTYPE' => 'prev_ncb_decl_type',
		'PREV_POLICYOWNER' => 'prev_policy_own',
		'PREVINSURANCE_ADDR' =>'previnsurance_addr',
		'PREVIOUSADDONS' => 'prev_addons',
		'PARTNER_ID' => 'partner_code',
                'CMP_PAID_UP' => 'cmp_paid_up',
		'VEH_VEHICLE_FINANCED'=>'veh_vehicle_financed',
		'VEH_VEHICLE_TYPE_OF_FINANCED'=>'veh_type_of_finance',
		'VEH_FINANCIER_NAME'=>'veh_financierName',
		'VEH_FINANCIER_ADDR'=>'veh_financier_addr',
		'IS_ZERODEP_PREV' => 'is_prev_zerodep',
		'isCarOwnershipChanged'=>'isCarOwnershipChanged',
		'veh_voluntary_deductible'=>'veh_voluntary_deductible',
		'FINAL_PREMIUM' => 'final_premium',
		'GSTIN'=>'gstin',
		'QUOTE_ID' => 'quote_id'

	];

	const CAR_T_PROPOSALLOG = ['POLICY_NU'	=> 'policy_nu',
							'TRANSACTION_ID' => 'transaction_id',
							'PROPOSAL_NU' => 'proposal_nu',
							'ORDER_NU' => 'order_nu',
							'QUOTE_ID' => 'quote_id',
							'PAYMENT_RESP_LOG' => 'payment_response_log',
							'CUSTOMER_ID'=>'customer_id',
							'PAYMENT_DATE'=>'payment_date'
							];
	
	const CAR_T_PROPOSALLOG_POLICY = ['POLICY_NU'	=> 'policy_nu',
							'TRANSACTION_ID' => 'transaction_id',
							'PROPOSAL_NU' => 'proposal_nu',
							'ORDER_NU' => 'order_nu',
							'QUOTE_ID' => 'quote_id',
							'CUSTOMER_ID'=>'customer_id',
							'PAYMENT_DATE'=>'payment_date',
							'PAYMENT_RESP_LOG' => 'payment_response_log',
							// status log and desc
							'quote_create_date'=>'quote_create_date',
							'quote_update_date'=>'quote_update_date',
							'quote_status'=>'quote_status',
							'quote_desc'=>'quote_desc',
							'proposal_date'=>'proposal_date',
							'proposal_status'=>'proposal_status',
							'proposal_ref_number'=>'proposal_ref_number',
							'proposal_desc'=>'proposal_desc',
							"payment_date"=>"payment_date",
							"payment_status"=>"payment_status",
							"payment_ref_number"=>"payment_ref_number",
							"payment_desc"=>"payment_desc",
							'policy_date'=>'policy_date',
							'policy_status'=>'policy_status',
							'policy_desc'=>'policy_desc',
							'misc_desc'=>'misc_desc'
							];

							
	// proposal default field values
	const ELECT_ASS = ['Rs.10,000' => '10000',
		'Rs.20,000' => '20000',
		'Rs.30,000' => '30000',
		'Rs.40,000' => '40000',
		'Rs.50,000' => '50000'];
	const NONELECT_ASS = ['Rs.10,000' => '10000',
		'Rs.20,000' => '20000',
		'Rs.30,000' => '30000',
		'Rs.40,000' => '40000',
		'Rs.50,000' => '50000'];
	const NU_OF_CLAIM = [0, 1, 2, 3, 4, 5];
	const NUMBER_OF_CLAIM = [1, 2, 3, 4, 5];
	const MARRITIAL = ['MARRIED' => "M", 'SINGLE' => "S"];
	const POLICY_TYPE = ['COMPREHENSIVE' => "C", 'LIABILITY' => "L"];
	const TYPE_OF_FINANCE = ['HYPOTHECATION'=>'Hypothecation','HIRE PURCHASE' => "Hire purchase", 'LEASE' => "Lease"];
	const TITLE = [["id" => "MISS", "value" => "Miss"],
		["id" => "MR", "value" => "Mr."],
		["id" => "MRS", "value" => "Mrs."],
		["id" => "MS", "value" => "Ms."]];
	// proposal field default values
	const PROPOSAL_DEFAULT = ['PREVIOUS_POLICY_TYPE' => 'C',
		'NUMBER_CLAIMS' => 0,
		'PREVIOUS_NCB' => 0,
		'CUR_NCB' => 0,
		'PREVIOUS_CLAIM' => 'N',
		'PAYMENT_MODE' => 'CC',
		'POLICY_TYPE' => 'C',
		// for bhartiaxa
		'NO_OF_DRIVERS' => 1,
		'YOUNGEST_DRIVER_AGE' => 22,
		'ANNUAL_MILLEAGE' => 9600,
		'GARAGE_TYPE' => "Covered",
		'DRIVING_EXP' => 5,
		// for itgi
		'ANTI_THEFT' => 'N',
		'SEATING_CAPACITY' => 5,
	];

	// Car Detail page
	const CAR_T_QUOTELOG = ['SESSION_ID' => 'session_id',
		'user_code' => 'user_code',
		'DETAIL_MAKE' => 'car_make',
		'DETAIL_MODEL' => 'car_model',
		'DETAIL_VARIANT' => 'car_variant',
		'DETAIL_STATE' => 'car_state',
		'DETAIL_RTO' => 'car_rto',
		'DETAIL_YEAR' => 'car_year',
		'DETAIL_FUEL' => 'car_fuel',
		'DETAIL_MAKE_NAME' => 'make_name',
		'DETAIL_MODEL_NAME' => 'model_name',
		'DETAIL_VARIANT_NAME' => 'variant_name',
		'DETAIL_VEHICLE_ID' => 'vehicle_id',
		'EXP_STATUS' => 'policy_exp_status',
		'QUOTE_NCB' => 'ncb',
		'QUOTE_NEW_NCB' => 'new_ncb',
		'QUOTE_CLAIM' => 'claim',
		'QUOTE_TYPE_OF_BUSINESS' => 'type_of_business',
		'QUOTE_POLICY_TYPE' => 'policy_type_selection',
		'QUOTE_POLICY_START_DATE' => 'policy_start_date',
		'QUOTE_POLICY_EXPIRY_DATE' => 'policy_expiry_date',
		'QUOTE_CAR_REGISTRATION_DATE' => 'car_registration_date',
		'QUOTE_VEHICLEAGE' => 'vehicle_age',
		'QUOTE_EX_SHOWROOM_CAR_PRICE' => 'ex_showroom_price_id',
		'QUOTE_PRICE' => 'calculated_price',
		'QUOTE_COV' => 'covers_selected',
		'QUOTE_IDV' => 'idv_calculated',
		'OPTED_IDV' => 'idv_opted',
		'OD_PREMIUM'	=> 'od_premium',
		'TP_PREMIUM'	=> 'tp_premium',
		'NCB_DISCOUNT' => 'ncb_discount',
		'OD_DISCOUNT' => 'od_discount',
		'ADDON_PREMIUM'	=> 'addon_premium',
		'TAX'	=> 'tax',
		'FILE_PATH' => 'quote_response_file',
		'QUOTE_RETURN_URL' => 'return_quote_url',
		'TOTAL_PREMIUM' => 'totalpremium',
		'NET_PREMIUM' => 'netPremium',
		'QUOTE_ID' => 'quote_id',
		'QUOTE_OD_START_DATE' => 'od_start_date',
		'QUOTE_OD_END_DATE' => 'od_end_date',
		'QUOTE_TP_START_DATE' => 'tp_start_date',
		'QUOTE_TP_END_DATE' => 'tp_end_date'
	];

	const CAR_QUOTE_FILE_PATH = 'Car/Quote';

	// master for policy
	const FG_MASTER = ['Color', 'VehicleBody', 'GarageType'
		, 'DailyMillage', 'RoadType', 'Repair'
		, 'Occupation', 'ClientMapType', 'Title'
		, 'Nationality', 'MaritalStatus', 'NomineeRelationship'
		, 'ClaimHistory', 'Gender', 'DriverQualification'
		, 'DriverExperience', 'Insurer'];
	const FG_MASTER_FORM_FIELD = ['state', 'city', 'color', 'bodyType', 'garageType'
		, 'dailyMillage', 'roadTypeCodes', 'preferredRepair'
		, 'occupation', 'clientMapType',
		'nationality', 'martitalStatus', 'nomineeRel'
		, 'previnsurance', 'yom_selected'
		, 'claimHistory', 'gender', 'qualification'
		, 'experience', 'custSubType', 'previousPolicyType'
		, 'statecode', 'citycode'];

	const HDFC_MASTER = ['Insurer', 'Financier', 'Title'];
	const HDFC_MASTER_FORM_FIELD = ['title', 'yom_selected', 'financier', 'statecode', 'citycode', 'previnsurance', 'state', 'city'];

	const UI_MASTER = ['Insurer', 'VehicleBody', 'NomineeRelationship'];
	const UI_MASTER_FORM_FIELD = ['bodyType', 'nomineeRel', 'previnsurance', 'title', 'yom_selected', 'statecode', 'citycode', 'state', 'city'];
	
	const TATA_MASTER = ['Insurer', 'VehicleBody', 'NomineeRelationship','MaritalStatus','Occupation'];
	const TATA_MASTER_FORM_FIELD = ['bodyType', 'nomineeRel', 'previnsurance', 'title', 'yom_selected', 'statecode', 'citycode', 'state', 'city'];
	
	//    working
	//    const IT_MASTER = ['Insurer','Occupation','Title','VehicleBody','GarageType','MaritalStatus'];

	const IT_MASTER = ['Insurer', 'Occupation', 'Title', 'VehicleBody', 'GarageType', 'MaritalStatus', 'NomineeRelationship'];
	const IT_MASTER_FORM_FIELD = ['insurer', 'occupation', 'title', 'bodyType', 'garageType', 'martitalStatus', 'nomineeRel', 'yom_selected', 'previousPolicyType', 'statecode', 'citycode', 'state', 'city', 'previnsurance'];

	const BJ_MASTER = ['Insurer'];
	const BJ_MASTER_FORM_FIELD = ['state','city','title', 'yom_selected', 'insurer', 'statecode', 'citycode','previnsurance'];

	const UNISOMPO_MASTER = ['Insurer', 'Title', 'VehicleBody', 'Occupation', 'MaritalStatus', 'NomineeRelationship'];
	const UNISOMPO_FORM_FIELD = ['insurer', 'title', 'bodyType', 'occupation', 'martitalStatus', 'nomineeRel', 'yom_selected', 'statecode', 'citycode', 'previnsurance', 'state', 'city'];

	const IDS = ['statecode'=>'State'
				,'citycode'=>'City'
				,'perm_citycode'=>'City'
				,'previnsurance'=>'Insurer'
				,'insurer'=>'Insurer'
				,'bodyType'=>'VehicleBody'
				,'nomineeRel'=>'NomineeRelationship'
				,'financier' => 'Financier'
				,'occupation' => 'Occupation'
				,'martitalStatus' => 'MaritalStatus'
				,'garageType'=>'GarageType'];


	const BA_MASTER = ['Insurer', 'GarageType', 'VehicleBody', 'Occupation'];
	const BA_MASTER_FORM_FIELD = ['marritial_status', 'bodyType', 'occupation', 'previnsurance', 'title', 'yom_selected', 'garageType', 'statecode', 'citycode', 'state', 'city'];

	const ROYAL_SUNDRAM_MASTER = ['Occupation','Insurer'];

	const RQGI_ERROR_CODES = ['E-0006'=>'Year Of Manufacture is mandatory','E-0007'=>'Car Registered City is mandatory','E-0008'=>'Vehicle Registration Date is mandatory','E-0009'=>'Vehicle Registration Date cannot be less than Current date','E-0010'=>'Vehicle Registration Date cannot be more than 30 days','E-0011'=>'Year of Registration should not be less than Year of Manufacturer','E-0012'=>'Year of Registration should not be greater than one year of Year of Manufacturer','E-0013'=>'Vehicle Registration Date is invalid','E-0014'=>'Vehicle Manufacturer Name is mandatory','E-0015'=>'Nominee age is above 18.So Guardian details are not required.','E-0016'=>'Nominee age is below 18.Guardian details is required.','E-0017'=>'Vehicle Model could not be found','E-0018'=>'Vehicle IDV is mandatory','E-0019'=>'Vehicle Model Name is mandatory','E-0020'=>'Policy Start Date is mandatory','E-0021'=>'Policy Start Date should be greater than or equal to current date','E-0022'=>'Year of Inception date should not be less than Year of Manufacture.','E-0023'=>'VehicleRegisteredInTheNameOf is mandatory.','E-0024'=>'CompanyName is mandatory.','E-0025'=>'isBiFuelKit is mandatory.','E-0026'=>'isBiFuelKitYes is mandatory.','E-0027'=>'AddonValue is mandatory.','E-0028'=>'AddonValue is invalid.','E-0029'=>'Previous Policy Expiry Date is mandatory.','E-0030'=>'Previous Policy Type is mandatory.','E-0031'=>'NoClaim Bonus Percent is mandatory.','E-0032'=>'Please specify in case of any Own Damage Claims made in Previous Policy','E-0033'=>'Number of Claims Reported is mandatory','E-0034'=>'Claim Amount Received is mandatory','E-0035'=>'Claim Amount Received cannot be Zero','E-0036'=>'Claim Amount Received cannot be more than 100000','E-0037'=>'Claim Amount Received should be numeric','E-0038'=>'Previous Policy Expiry Date is invalid','E-0039'=>'Year of Previous Policy Expiry should not be less than Year of Manufacture."','E-0040'=>'Date of First Purchase/Delivery should not be greater than Policy Start Date.','E-0041'=>'Previous Policy Expiry Date cannot be more than 60 days from current date.','E-0042'=>'Your policy has expired. The grace period available to you for renewal has also expired. Please contact our online chat representative for more details.'];
	const RQGI_SUCCESS_CODES = ['S-0002'=>'Premium Calculated and Quote Saved Successfully','S-0005'=>'Car Registered City is mandatory','S-0005'=>'Quote Approved, Proceed Buy Policy','S-0111'=>'Payment Updated Successfully'];

	public static function getQuoteFileName($session_id) {
		return 'Quote_Rearraged_' . $session_id . '.txt';
	}

	public static function getProposalFileName() {
		return 'Proposal_' . session()->getId() . '.txt';
	}


	// TATA - INSTAINSURE DETAILS

	// Production Ceredentials
	const TATA_QUOTE_URL = 'https://inode.tataaig.com/tagicinodems/ws/v1/ws/tran1/quotation';
	const TATA_PROPOSAL_URL = 'https://inode.tataaig.com/tagicinodems/ws/v1/ws/tran2/proposal';
	const TATA_POLICY_URL = 'https://inode.tataaig.com/tagicinodems/ws/v1/ws/nodws/genpolicy';
	const TATA_POLICY_PDF_URL = 'https://inode.tataaig.com/tagicinodews/motor_policy.jsp';
	const TATA_TOKEN = "EB28AEEA16D6DDF599FA9299B4F89AC74D03AC2379A2D800F1E1AAE6206B5356AD77F45673508640CF103A620F5612B55ABAD1D7A83600B07BD0EF6832BC89057536FEAE45162F7ECCF516E87F797D0F8547863B3138D88ED3E4C639A674428798544A7A4CCF5EA4AFFB254D3BF136EB63F69124993620BB500B244E8E7BAE9DB7D45F438045DE21FE6B65A3D3509609C29C26D12999EFCB0C857C75C185C896B973D55015CD8B6DA118E2634AFD8ADA";
	const TATA_SRC = "TTIB01";
	const TATA_SOL_ID = "TOYOTATSUS";

	const TATA_CAMPAIGN = 'INSTAINSURE';
	const TATA_MEDIUM = 'INSTAINSURE';
	const TATA_SOURCE = 'TATA-AIG';
	const TATA_USER_ID = '0033677004';
	const TATA_USER_ROLE = 'BROKER CORPORATE';
	const TATA_VENDOR_CODE = 'TMINSTAIN';
	const TATA_PRODUCT_CODE = '3121';
	const TATA_ACTION = 'action';
	const TATA_PRODUCER_CODE = '0033677004';
	const TATA_HASH_KEY = '67H571iF5ol7q1n8';
	const TATA_BASIC_OF_RATING = 'GLM';
	const TATA_GLMRate = 0.0;
	const TATA_IntermediaryCode = '0033677004';
	const TATA_TertiaryMOCode = 'WEBSERVICE';
	const TATA_COUNTRY_CODE = '64';
	const TATA_COUNTRY_NAME = 'INDIA';
	const TATA_GST_CODE = '27';
	
	const INTERMEDIARY_CODE = '0033677004';
	const PROPOSAL_INFORMATION_OFFICE_NAME = 'Bangalore';
	const INTERMEDIARY_NAME		=	'Toyota Tsusho Insurance Broker India Pvt Ltd';
	const BRANCH_OFFICE_CODE	=	'0500';
	const OFFICE_CODE	=	'0500';
	const IS_SELLER_INSURED	=	'false';
	const DISPLAY_OFFICE_CODE = '0500';
	const METHOD_OF_CALCULATION = '0033677004';

	const TATA_WARNING_MSG	=	['Transaction Declined'];

	const TATA_PACKAGES = [
						'tata_silver'			=>
							[
								'package' => 'P1',
								'addon' => ['pa','ll','repair_of_glass','papass']
							]
						,'tata_gold'			=>
							[
								'package' => 'P2',
								'addon' => ['pa','ll','lpb','et_hotelexpenses','keyreplace','repair_of_glass','rsac','papass']
							]
						,'tata_pearl'		=>
							[
								'package' => 'P3',
								'addon' => ['zerodep','pa','ll','lpb','et_hotelexpenses','keyreplace','repair_of_glass','rsac','papass']

							]
						,'tata_pearl_p'		=>
							[
								'package' => 'P8',
								'addon' => ['zerodep','ep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','keyreplace','repair_of_glass','rsac','papass']

							]
						,'tata_sapphire'	=>
							[
								'package' => 'P9',
								'addon' => ['zerodep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','ts','keyreplace','repair_of_glass','rsac','papass']

							]
						,'tata_sapphire_p'	=>
							[
								'package' => 'P10',
								'addon' => ['zerodep','ep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','ts','keyreplace','repair_of_glass','rsac','papass']

							]
						,'tata_sapphire_pp'	=>
							[
								'package' => 'P11',
								'addon' => ['rti','zerodep','ep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','ts','keyreplace','repair_of_glass','rsac','papass']

							]
					];
	

	const PB_FORMAT = ['basic' => ['od','tp','ll', 'pa']
				            , 'addon' => ['rti', 'zerodep','papass','ep','rsac','lpb','et_hotelexpenses','cosumable_expenses','keyreplace','repair_of_glass','ts']
				            , 'discounts' => ['ncbbenefit', 'od_discount']
				            , 'totalpremium'
				            , 'serviceTax'
				            , 'netPremium'];

	const UIIC_PB_FORMAT = ['basic' => ['od','tp','ll', 'pa']
				            , 'addon' => ['rti', 'zerodep','papass','ep','rsac']
				            , 'discounts' => ['ncbbenefit', 'od_discount']
				            , 'totalpremium'
				            , 'serviceTax'
				            , 'netPremium'];
}
?>
