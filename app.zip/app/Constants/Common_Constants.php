<?php
namespace App\Constants;

class Common_Constants {

	// Below are the events for email triggering

	const CONTACT_US_EVENT_ID = 1;
	const PROPOSAL_ERROR_EVENT_ID = 3;
	const QUOTE_EVENT_ID = 2;
	const PAYMENT_FAILED_EVENT_ID = 4;
	const PAYMENT_SUCCESS_EVENT_ID = 5;
	const REGISTRATION_EMAIL_EVENT_ID = 6;
	const PROPOSAL_POLICY_FINISH_HIT_EVENT_ID = 7;

	// Email Triggering events end here

	const INSTA_EMAIL_EVENTS_TABLE = 'insta_c_email_events';
	const INSTA_EMAIL_TRIGGER_TABLE = 'insta_c_email_trigger';
	const INSTA_USERS_TABLE	=	'insta_m_users';

	const INSTA_USER_TYPE_ADMIN = '1';
	const INSTA_USER_TYPE_CUSTOMER = '2';
	const INSTA_USER_TYPE_AGENT = '3';
	const INSTA_USER_TYPE_SUPPORT = '4';
	const INSTA_USER_TYPE_GENERIC = '5';

	// Offer mail constants
	const CAR_INSURANCE_OFFER_SOURCE = 'car-insurance-offer';
	const OFFER_SUCCESS_MESSAGE = 'Thanks for trusting InstaInsure. Your offer has been activated please visit to insurance quote page you want to purchase.';

	// Offer mail constants ends here

	// Constants for Login, Registration and Forgot password

	const REGISTRATION_SUCCESS_MESSAGE = 'Thanks for creating your account, your password is sent to your registered mail.';
	const REGISTRATION_FAILUER_MESSAGE = 'User is already registered.';
	const FORGOT_FAILUER_MESSAGE = 'Sorry there were some issues reseting your password please contact administrator';
	const FORGOT_SUCCESS_MESSAGE = 'Your passwor has been reset and have sent to your registered email id.';
	const FORGOT_USER_NOT_EXIST_MESSAGE = 'User Does not exist\'s. Please creat an account.';
	const USER_EMAIL_EXISTS_MESSAGE = 'Sorry this email is already registered with use please login with your registered number.';
	const USER_MOBILE_EXISTS_MESSAGE = 'Sorry this mobile number is already registered with use please login with your registered number or reset your password if your have forgot it.';

	// Constants for Login, Registration and Forgot password ends here
	
    // Email details
     
        const EMAIL_SEND_METHOD = "smtp";
	
	const SMTP_HOST = "smtp.office365.com";
	const SMTP_PORT = 587;
	const SMTP_USERNAME = "support@instainsure.com";
	const SMTP_PASSWORD = "Ttibi@729#";
	
        const DEFAULT_EMAIL = "support@instainsure.com";
	const DEFAULT_FROM_EMAIL = "support@instainsure.com";
	const DEFAULT_FROM_NAME = "Instainsure.com";
	const REPLY_TO_EMAIL = "support@instainsure.com";


	//trans status
	const TS_PROPOSAL_FAIL = "PRPLFAIL";
	const TS_PAYMENT_FAIL = "PAYFAIL";
	const TS_PAYMENT_SUCCESS = "PAYSUCCESS";
	const TS_COMPLETED = "COMPLETED";


	//page names
	const HOME = "HOME";
	const CARDETAILS = "CARDETAILS";
	const TWDETAILS = "TWDETAILS";
	const HOMEDETAILS = "HOMEDETAILS";
	const TRAVELDETAILS = "TRAVELDETAILS";
	const HEALTHDETAILS = "HEALTHDETAILS";
	const LIFEDETAILS = "LIFEDETAILS";
	const BLOGHOME = "BLOGHOME";
	const FAQHOME = "FAQHOME";

	// Reports file name

	const CARTISAN_FILE_NAME = 'InstaInsure Traffic Report For Cartisan';
}

?>


