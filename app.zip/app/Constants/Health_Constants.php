<?php

namespace App\Constants;

class Health_Constants {

    const OTP_LENGTH = 4;
    const MAXIUM_CALL_API = 2;
    const PREMIUM_MISSMATCHALLOWED_UP_TO = 2;
    const AUTH = array('accesskey' => 'TTIBI', 'secretkey' => 'TTIBI');
    const API_BASE = "http://api.brokeredge.in";
    const POLICY_S_DATE_DIFF = "POLICY_S_DATE_DIFF";
    const POLICY_E_DATE_DIFF = "POLICY_E_DATE_DIFF";
    const DOB_AGE_RESTRICTION = "DOB_AGE_RESTRICTION";
    const LOGOPATH = 'image/logos/';
   
    // Royal sundaram
    const RSGI_APIKEY = '310ZQmv/bYJMYrWQ1iYa7s43084=';
    const RSGI_AgentID = 'BA503014';
    const RSGI_PREMIUM_CALCULATION_URL = 'https://dtc.royalsundaram.in/DTCWS/Services/Product/Lifeline/CalculatePremium';
    const RSGI_PROPOSAL_URL = 'https://dtc.royalsundaram.in/DTCWS/Services/Product/Lifeline/SaveProposerAndInsuredDetails';
    const RSGI_PAYMENT_URL = 'https://www.royalsundaram.in/web/dtc/paymentgateway';
    const RSGI_BMI_LOWER_LIMIT = 0;
    const RSGI_BMI_UPPER_LIMIT = 32.5;
    const RSGI_PPC_S_TOPUP_MSG = 'Sum Insured is {SI} INR, the case shall be referred to underwriting. Team will contact you for further processing.';
    
    //HDFC Basic Health Suraksha
    const HDFC_PROPOSAL_URL = 'https://hewspool.hdfcergo.com/healthonlinecp/service.asmx/CalculatePremium';
    const HDFC_BASIC_PG_URL ='https://netinsure.hdfcergo.com/onlineproducts/healthonline/tim.aspx';
    const HDFC_BASIC_PRODUCER_CODE = 'HSC00010'; 
    const HDFC_PRODUCT_CODE = 'HSP';
    const HDFC_BASIC_INDV_DISCOUNT = 0.1;
    const HDFC_PAYMENT_MODE = 'CC';
    

    //HDFC Super TopUp
    const HDFC_SUPER_TOPUP_PROP = 'https://hewspool.hdfcergo.com/MedisureOnlineCP/Service.asmx/CalculatePremium';
    const HDFC_PG_URL = 'https://netinsure.hdfcergo.com/OnlineProducts/MedisureOnline/TIM.aspx';
    const HDFC_SUPER_TOPUP_PRODUCER_CODE = 'MSC00005';
    const HDFC_PROP_FILE    = '/xml-templates/proposal.xml';
    const HDFC_INSR_PROP_FILE   = '/xml-templates/additional-insured.xml';
    const HDFC_S_TOPUP_TOKENS = '{F_NAME},{L_NAME},{DOB},{GENDER},{HNO},{STREET},{LOCALITY},{STATE},{CITY},{PIN},{EMAIL},{MOBILE},{PRODUCER_CODE},{PRODUCT_CODE},{PLAN_CODE},{BASE_PREMIUM},{TAX},{TOTAL_PREMIUM},{SI},{PLAN_TYPE},{TENURE},{DEDUCTABLE},{UID},{PPCPED}';
    
    const HDFC_S_TOPUP_ADDI_TOKENS = '{FULL_NAME},{F_NAME},{L_NAME},{DOB},{RELATIONSHIP},{GENDER},{NOMINEE_NAME},{NOMINEE_RELATION},{HEIGHT},{WEIGHT},{PED_DETAILS},{IS_PED}';
    const HDFC_S_TOPUP_P_CODE = 'HSTOP';
    const HL202 = 'Your age is above 55. you need offline asisstance to get this policy.';
    const HDFC_S_TOPUP_INDV_DISCOUNT = 0.1;
    const PPC_S_TOPUP_MSG = 'Insured member age is {AGE} years, the case shall be referred to underwriting. Team will contact you for further processing.';
    const PED_MSG ='As Pre-existing disease is disclosed, the case shall be referred to underwriting.Team will contact you for further processing';
    const PPC_MSG = 'One of our consultant will contact you. Need to take medical checkup to buy this policy';
    const BMI_MSG = 'You can Proceed to payment but the policy may be issued only after the approval of the underwriter';
    const BMI_LOWER_LIMIT = 17;
    const BMI_UPPER_LIMIT = 35;
    const INVALID_PLAN_MSG = 'Invalid Member DOB, Please provide DOB according to the selected age range.';
    
    //Religare
    const GST           = 0.18;
    const RELIGARE_ID   = 'religare';
    const RELIGARE_NAME = 'Religare';
    const PATT_1A      = '1000'; 
    const PATT_2A      = '1100';
    const PATT_2A_1C   = '1110';
    const PATT_2A_2C   = '1120';
    const PATT_2A_3C   = '1130';
    const PATT_2A_4C   = '1140';
    const PATT_1A_1C   = '1010';
    const PATT_1A_2C   = '1020';
    const PATT_1A_3C   = '1030';
    const PATT_1A_4C   = '1040';
    const RELIGARE_PAN_PR_LIMIT = 50000;
    const RELIGARE_SENIOR_DISCOUNT = .20;
    const RELIGARE_PRODUCT_ID = '10001101';
    const RELIGARE_S_PRODUCT_ID = '11001001';
    const RELIGARE_AGENT_ID     = '20070500';
    const RELIGARE_PDF_USERNAME = 'SymbiosysUser';
    const RELIGARE_PDF_PASSWORD = 'Password-1';
    const RELIGARE_PRP_FILE   = 'Helpers/Health/Religare/xml-templates/proposal.xml';
    const RELIGARE_PRP_FILE_STOPUP    = 'Helpers/Health/Religare/xml-templates/super-topup.xml';
    const RELIGARE_ADDI_FILE  = 'Helpers/Health/Religare/xml-templates/additional-insured.xml';
    const RELIGARE_PED_ROUTE  = 'Helpers/Health/Religare/xml-templates/ped/{FILE_NAME}.xml';
    const RELIGARE_PED_CHOICE = 'Helpers/Health/Religare/xml-templates/ped/yesNoExist.xml';
    const RELIGARE_PDF_URL    = 'https://cordyprod.religarehealthinsurance.com/cordys/com.eibus.web.soap.IPGateway.RHIGateway.wcp?organization=o=ReligareHealth,cn=cordys,cn=defaultInst,o=religare.in';
    const RELIGARE_PROPOSAL_URL = 'https://api.religarehealthinsurance.com/relinterface/services/RelSymbiosysServices.RelSymbiosysServicesHttpSoap12Endpoint';
    const RELIGARE_PG_URL = 'https://faveo.religarehealthinsurance.com/portalui/PortalPayment.run';
    const RELIGARE_PDF_INTERNAL_URL = '/health-insurance/religare/pdf?p=';
    const RELIGARE_RETURN_URL  = '/health-insurance/religare/payment/status';
    const RELIGARE_PPC_URL     = '/health-insurance/religare/ppc';
    const RELIGARE_PR_TOKEN    = '{ADD_ON},{BUSNIESS_TYPE},{PRODUCT_ID},{AGENT_ID},{COVER_TYPE},{DOB},{FNAME},{GENDER},{GUID},{LNAME},{ADDR1},{ADDR2},{AREA},{CITY},{PINCODE},{STATE},{MOBILE},{EMAIL},{PAN},{TITLE},{NOMINEENAME},{NOMINEEREL},{SUM_INSURED}';
    const RELIGARE_ADDI_TOKEN    = '{DOB},{FNAME},{GENDER},{GUID},{LNAME},{ADDR1},{ADDR2},{AREA},{CITY},{PINCODE},{STATE},{MOBILE},{EMAIL},{RELATIONSHIP},{TITLE}';

    // Star Production Credentials
    const STAR_APIKEY = 'ede59878093a47c98bb46d87f6dd784c';
    const STAR_SECRETKEY = '4f5fd11c0f1d4f999d6055237bb8ad39';
    const STAR_STATECITY_URL = 'https://ig.starhealth.in/api/policy/city/details?APIKEY=';
    const STAR_AREACITY_URL  = 'https://ig.starhealth.in/api/policy/address/details?APIKEY=';
    const STAR_PREMIUM_CALCULATION_URL ='https://ig.starhealth.in/api/proposal/premium/calculate';
    const STAR_PROPOSAL_URL = 'https://ig.starhealth.in/api/policy/proposals';
    const STAR_TOKEN_URL = 'https://ig.starhealth.in/api/policy/proposals';
    const STAR_PG_URL = 'https://ig.starhealth.in/policy/proposals/purchase';
    const STAR_POLICY_STATUS_URL = 'https://ig.starhealth.in/api/policy/proposals';
    const STAR_POLICY_SCHEDULE_URL = 'https://ig.starhealth.in/api/policy/proposals';
    const STAR_BMI_LOWER_LIMIT = 15;
    const STAR_BMI_UPPER_LIMIT = 35;
    const STAR_BMI_MSG = 'BMI is exceeding the limit,';
    const STAR_PED_MSG = 'Pre-existing Critical illness is disclosed,';
    
    

    // Reliance Health
    const RELIANCE_AGENT_ID = 'Direct';
    const RELIANCE_AGENT_NAME = 'Direct';
    const RELIANCE_BRANCH_CODE = '9202';
    const RELIANCE_BRANCH_NAME = 'Direct';
    const RELIANCE_PRODUCT_CODE = '2828';
    const RELIANCE_BUSINESS_TYPE = '1';
    const RELIANCE_USER_ID = '14BRG281B05';
    const RELIANCE_SOURCE_SYSTEM_ID = '14BRG281B05';
    const RELIANCE_AUTH_TOKEN= 'TTIBL30052018';
    const RELIANCE_EXTERNAL_SYSTEM_ID = '1';
    const RELIANCE_CLIENT_TYPE_ID = '0';
    const RELIANCE_PLAN = '1';
    const RELIANCE_PED_MSG = 'Pre-existing disease/Critical illness is disclosed.';
      // Production Credentials
    const RELIANCE_PREMIUM_URL = 'http://rzonews.reliancegeneral.co.in/API/Service/PremiumCalulationForHealthwise';
    const RELIANCE_PROPOSAL_URL ='http://rzonews.reliancegeneral.co.in/API/Service/ProposalCreationForHealth';
    const RELIANCE_PAYMENT_URL = 'http://rzonews.reliancegeneral.co.in/PaymentIntegration/PaymentIntegration';
    const RELIANCE_POLICY_SCHEDULE_URL = 'http://rzonews.reliancegeneral.co.in/API/Service/GeneratePolicyschedule';


    


    
    const HEALTH_PROPOSAL_ERROR_MSG = 'Based on the information provided,';

    // session key 
    const PROPOSAL_FORM_DATA = 'proposal_form_data';
    const PROPOSAL_FORM_RESULT = 'proposal_form_result';
    const PROPOSAL_REQUEST_URL = 'proposal_request_url';
   
    // Health Detail page
    const HEALTH_T_QUOTELOG = ['SESSION_ID' => 'session_id',
        'QUOTE_POLICY_START_DATE' => 'policy_start_date',
        'QUOTE_POLICY_EXPIRY_DATE' => 'policy_expiry_date',
        'FILE_PATH' => 'quote_response_file',
        'QUOTE_RETURN_URL' => 'return_quote_url',
        'TOTAL_PREMIUM' => 'totalpremium',
        'NET_PREMIUM' => 'netPremium',
    ];

    const HEALTH_QUOTE_FILE_PATH = 'Health/Quote';



    public static function getQuoteFileName($session_id) {
        return 'Quote_Rearraged_' . $session_id . '.txt';
    }

    const HEALTH_T = ['ID' => 'id',
        'SESSION_ID' => 'session_id',
        'INSURERID' => 'insurerId',
        'PRODUCTID' => 'productId',
        'RSGI_QUOTE_ID' => 'rsgi_quote_id',
        'INSURERNAME'=> 'insurerName',
        'PRODUCTNAME' => 'productName',
        'TOTALPREMIUM'=> 'totalPremium',
        'SERVICETAX' => 'serviceTax',
        'BASEPREMIUM' => 'basePremium',
        'PLAN_TYPE' => 'plan_type',
        'DOB_LIST' => 'dob_list',
        'AGE_LIST' => 'age_list',
        'MEMBERS_LIST' => 'members_list',
        'GENDER' => 'gender',
        'ADULT' => 'adult',
        'CHILDREN' => 'children',
        'TENURE' => 'tenure',
        'SUM_INSURED' => 'sum_insured',
        'TITLE' => 'title',
        'FIRSTNAME' => 'firstname',
        'LASTNAME' => 'lastname',
        'OCCUPATION' => 'occupation',
        'DESIGNATION' => 'designation',
        'BUSINESS' => 'business',
        'MARITAL' => 'marital_status',
        'EDUCATION' => 'education', 
        'HEIGHT_FEET' => 'height_feet',
        'HEIGHT_INCHES' => 'height_inches',
        'WEIGHT' => 'weight',
        'NOMINEE_NAME' => 'nominee_name',
        'NOMINEE_AGE' => 'nominee_age',
        'NOMINEE_DOB' => 'nominee_dob',
        'NOMINEE_RELATION' => 'nominee_relation',
        'PAN_NUMBER' => 'pan_number',
        'AADHAAR_NUMBER' => 'aadhaar_num',
        'ADD_ON' => 'add_on',
        'HOUSE_NUM' => 'house_num',
        'STREET' => 'street',
        'LOCALITY' => 'locality',
        'STATE' => 'state',
        'CITY' => 'city',
        'PINCODE' => 'cust_pincode',
        'AREA' => 'cust_area',
        'EMAIL' => 'email',
        'MOBILE' => 'mobile',
        'PED_LIST' => 'ped_list',
        'PED_LIFESTYLE' => 'ped_lifestyle'
    ];

     
    const HEALTH_T_PROPOSALLOG = ['POLICY_NU'  => 'policy_num',
                            'TRANSACTION_ID' => 'transaction_id',
                            'PROPOSAL_NU' => 'proposal_num',
                            'ORDER_NU' => 'order_num',
                            'QUOTE_ID' => 'pay_quote_id',
                            'PAYMENT_RESP_LOG' => 'payment_response_log',
                            'CUSTOMER_ID'=>'customer_id',
                            'PAYMENT_STATUS' =>'payment_status',
                            'TRANSACTION_DATE' => 'policy_date'
                            ];         

    const PROPOSAL_POLICY = [
        'product_type' => ['N'=>'INDV','Y'=>'FF'],
        'tenure' => 1,
        'plan_name' =>  "Health insurance",
        'declaration_agree' => 'Y',
        'payment_mode' => 'CC',
        'is_primary_insured' => 'Y',
        'address_type' => 'C',
        'permanent_address_type' => 'P',
        'eSaleDiscount' => 'Y',
        'tieredHospitalDiscount' => 'Y'
    ];
}
?>





















