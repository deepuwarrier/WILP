<?php
namespace App\Constants;

class Travel_Constants{

    // GST & SERVICE TAX
    public static $SERVICETAX         = 0.15;
    public static $GST_CMN            = 0.18;
    public static $GST_JK             = 0.126;
    
    //COMMON CONSTANTS & MESSAGES
    const LOGOPATH                    = 'image/logos/';
    const OTP_LENGTH                  = 4;
    const TRAVEL_QUOTE_FILE_PATH      = 'Travel/Quote';
    public static $DEF_TIMEZONE       = 'Asia/Kolkata'; 
    public static $PED_MESSAGE        = 'Based on the information provided, you may not be able to purchase this policy online.';
    public static $BADRESPONSE        = 'We are facing a temporary issue while trying to contact the Insurance Company.';
    public static $HDFC_INVALIDAGE    = 'Since one of the traveller&#39;s age exceeds 60, you cannot buy this policy online.';
    public static $INSTA_DISCLAIMER   = 'T&C note "I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.';
    public static $SERVER_CONNECTIVITY = 'Unable to connect to the server !. Please try again';
    public static $THREE_ATTEMPLTS_MSG = 'If you are seeing this message more than 3 attempts, Call us at: +91 7899-000-333';

        
    //DETAILS PAGE
    public static $WWD                 = 'World Wide';
    public static $WWD_EXCL_USA_CAN    = 'World Wide Excluding USA & CANADA';
    public static $WWD_EXCL_USA        = 'World Wide Excluding USA';
    public static $ASIA_EXCL_JAPAN     = 'Asia';
    public static $EURO                = 'Europe';
    public static $AFRICA              = 'Africa';
    public static $SCHENGEN            = 'Schengen';
    public static $SINGLE_TRIP_MIN_AGE = 18;
    public static $SINGLE_TRIP_MAX_AGE = 100;
    public static $AMT_MIN_AGE = 18;
    public static $AMT_MAX_AGE = 70;
    public static $STUDENT_MIN_AGE = 12;
    public static $STUDENT_MAX_AGE = 40;

    // FGGI
    public static $FGGI_LOGO           = self::LOGOPATH .'fggi_logo.png'; 
    public static $FGGI_AGENT_CODE     = '60044931';
    public static $FGGI_VENDOR_CODE    = 'INSTAINS';
    public static $FGGI_BRANCH_CODE    = '10';
    public static $FGGI_MAJOR_CLASS    = 'TVL';
    public static $FGGI_CRYPTO_KEY     = '&%#@?,:*';
    public static $FGGI_PAYMENT_OPTION = '3';
    public static $FGGI_SERVICE_URL    = 'http://online.futuregenerali.in/BO/Service.svc?wsdl';
    public static $FGGI_RETURN_URL     = '/travel-insurance/fggi/payment/status';
    public static $FGGI_PG_URL         = 'https://online.futuregenerali.in/Ecom_NL/WEBAPPLN/UI/Common/WebAggPayNew.aspx';

    
    // TATA AIG 
    public static $TATA_LOGO           = self::LOGOPATH .'tata_logo.png';  
    public static $TATA_REQUEST_URL    = 'https://purchasexml.travelguard.com/servlet/WaatsEngine.WTEngine';
    public static $TATA_PROPOSAL_URL   = 'https://purchasexml.travelguard.com/servlet/WaatsEngine.WTEngine';
    public static $TATA_PG_URL         = 'https://webpos.tataaiginsurance.in/pgprd/pgrequest.jsp';
    public static $TATA_VENDOR_CODE    = 'TINSTAIN';
    public static $TATA_PRODUCER_CD    = '0010805000';
    public static $TATA_HASH_CODE      = '67H571iF5ol7q1n8';
    public static $TATA_STD_PRODUCT    = '020987';
    public static $TATA_STD_BENEFIT_CD = '01001';
    public static $TATA_GDS_WSLIMIT    = '020952';
    public static $TATA_GDS_WTSLIMIT   = '020953';
    public static $TATA_AN_BENEFIT_CD  = '01003';
    public static $TATA_R_BENEFIT_CD   = '01001'; 
    public static $TATA_INSTA_LICENCE  = 'TAGIC/WebApp/TG/Aug 17/2';
    public static $TATA_INSTA_VERSION  = 'Ver1/ Toyota Tsusho 887';
    public static $TATA_INSTA_STD_LICENCE  = 'TAGIC/WebApp/SG/Aug 17/3';
    public static $TATA_INSTA_STD_VERSION  = 'Ver1/ Toyota Tsusho 888';
    public static $TATA_INSTA_ASIA_LICENCE  = 'TAGIC/WebApp/ATG/Aug 17/4';
    public static $TATA_INSTA_ASIA_VERSION  = 'Ver1/ Toyota Tsusho 889';
    public static $TATA_STUDENT_GUARD_P_NAME  = 'Student Guard - Overseas Health Insurance'; 
    public static $TATA_DISCLAIMER  = 'I hereby confirm that I am the policyholder as well as the owner of the credit card / debit card / Internet banking account or any other online payment method, through which I am paying the policy premium. *Please note that in-case of a refund, the amount payable will automatically credited to the same account that you are using to pay the premium or can be refunded through a cheque in the name of the proposer';
    public static $TATA_TRV_GUARD                    = 'Travel Guard';
    public static $TATA_ASIA_GUARD                   = 'Asia Travel Guard Policy';
    public static $TATA_SQ_WITH_SUBLIMIT_TITLE       = '(With Sublimit)';
    public static $TATA_SQ_WITH_OUT_SUBLIMIT_TITLE   = '(Without Sublimit)';
    public static $TATA_AMT_PLAT_TITLE        = 'Annual Multitrip Platinum';
    public static $TATA_AMT_GOLD_TITLE        = 'Annual Multitrip Gold';
    public static $TATA_INDV_FILE      = 'Helpers/Travel/Tata/xml-templates/individual-request.xml';
    public static $TATA_FLT_FILE       = 'Helpers/Travel/Tata/xml-templates/floater-request.xml';
    public static $TATA_INSR_FILE      = 'Helpers/Travel/Tata/xml-templates/additional-insured.xml';
    public static $TATA_INDV_PROP_FILE = 'Helpers/Travel/Tata/xml-templates/individual-proposal.xml';
    public static $TATA_FLT_PROP_FILE  = 'Helpers/Travel/Tata/xml-templates/floater-proposal.xml';
    public static $TATA_INSR_PROP_FILE = 'Helpers/Travel/Tata/xml-templates/additional-insured-proposal.xml';
    public static $TATA_STUD_FILE      = 'Helpers/Travel/Tata/xml-templates/student-request.xml';
    public static $TATA_STUD_PROP_FILE = 'Helpers/Travel/Tata/xml-templates/student-proposal.xml';
    public static $TATA_SEGMENT_FILE   = 'Helpers/Travel/Tata/xml-templates/segment.xml';
    public static $TATA_PROP_SEGMENT_FILE   = 'Helpers/Travel/Tata/xml-templates/segment-proposal.xml';
    public static $TATA_REREQUEST_FILE = 'Helpers/Travel/Tata/xml-templates/floater-rerequest.xml';
    public static $TATA_C_TOKENS       = '{MESSAGE_TYPE},{MESSAGE_VERSION},{SOURCE_ID},{GDS_CODE},{TRANS_ID},{AGENCY_PCC},{AGENCY_CODE},{USER_ID},{AGENT},{COUNTRY_CODE},{PRODUCT_CODE},{DESTINATION},{TIME_STAMP},{START_DATE},{END_DATE},{BNF_CODE}';
    public static $TATA_P_TOKENS       = '{MESSAGE_TYPE},{MESSAGE_VERSION},{SOURCE_ID},{GDS_CODE},{TRANS_ID},{AGENCY_PCC},{AGENCY_CODE},{USER_ID},{AGENT},{COUNTRY_CODE},{PRODUCT_CODE},{DESTINATION},{DESTINATION_NAME},{TIME_STAMP},{START_DATE},{END_DATE},{DESTINATION_COUNTRY},{CARD_EXPIRY},{PAYMENT_TYPE},{CARD_NUMBER},{CARD_NAME},{HOLDER_NAME},{P_USER_ID}';
    public static $TATA_INDV_TOKENS    = '{TITLE},{FIRST_NAME},{LAST_NAME},{RELATION},{ADDRESS},{CITY},{STATE},{PINCODE},{EMAIL},{CELL_NO},{PASS_NO},{IS_INSURED},{GENDER},{DOB},{PLAN_CODE},{BNF_CODE}';
    public static $TATA_FLT_TOKENS     = '{TITLE},{FIRST_NAME},{LAST_NAME},{RELATION},{ADDRESS},{CITY},{STATE},{PINCODE},{EMAIL},{CELL_NO},{PASS_NO},{IS_INSURED},{GENDER},{DOB},{PLAN_CODE},{BNF_CODE}';
 
    public static $TATA_REREQ_TOKENS   = '{MESSAGE_TYPE},{MESSAGE_VERSION},{SOURCE_ID},{TRANS_ID}';
    public static $TATA_SEGMENT_TOKENS = '{TRANS_ID},{GDS_CODE},{AGENCY_PCC},{AGENCY_CODE},{USER_ID},{AGENT},{COUNTRY_CODE},{PRODUCT_CODE},{DESTINATION},{TIME_STAMP},{START_DATE},{END_DATE}';
    public static $TATA_PROP_SEGMENT_TOKENS = '{TRANS_ID},{GDS_CODE},{AGENCY_PCC},{AGENCY_CODE},{DESTINATION_COUNTRY},{P_USER_ID},{USER_ID},{AGENT},{COUNTRY_CODE},{PRODUCT_CODE},{DESTINATION},{TIME_STAMP},{START_DATE},{END_DATE}';


    //RELIGARE 
    public static $RELIGARE_LOGO           = self::LOGOPATH .'religare_logo.png';
    public static $RELIGARE_AGENT_ID       = '20070500';
    public static $RELIGARE_PDF_USERNAME   = 'SymbiosysUser';
    public static $RELIGARE_PDF_PASSWORD   = 'Password-1';
    public static $RELIGARE_PROPOSAL_URL   = 'https://api.religarehealthinsurance.com/relinterface/services/RelSymbiosysServices.RelSymbiosysServicesHttpSoap12Endpoint/';
    public static $RELIGARE_PG_URL         =  'https://faveo.religarehealthinsurance.com/portalui/PortalPayment.run'; 
    public static $RELIGARE_RETURN_URL     = '/travel-insurance/religare/payment/status';
    public static $RELIGARE_SQ_WITH_SUBLIMIT_TITLE       = '(With Sublimit)';
    public static $RELIGARE_SQ_WITH_OUT_SUBLIMIT_TITLE   = '(Without Sublimit)';
    public static $RELIGARE_PDF_INTERNAL_URL = '/travel-insurance/religare/pdf?p=';
    public static $RELIGARE_PDF_URL    = 'https://cordyprod.religarehealthinsurance.com/cordys/com.eibus.web.soap.IPGateway.RHIGateway.wcp?organization=o=ReligareHealth,cn=cordys,cn=defaultInst,o=religare.in';
    
    //HDFC
    public static $HDFC_LOGO           = self::LOGOPATH .'hdfc_logo.png';
    public static $HDFC_PROPOSAL_URL   = 'https://hewspool.hdfcergo.com/TravelChannelPartner/webservice.asmx/IssuePolicy';         
    public static $HDFC_AMT_SG         = 'PPMT1';
    public static $HDFC_AMT_MG         = 'PPMT3';
    public static $HDFC_AMT_SP         = 'PPMT2';
    public static $HDFC_AMT_MP         = 'PPMT4';
    
     //STAR INSURANCE
    public static $STAR_LOGO           = self::LOGOPATH .'star_logo.png';
    public static $STAR_APIKEY         = 'ede59878093a47c98bb46d87f6dd784c';
    public static $STAR_SECRETKEY      = '4f5fd11c0f1d4f999d6055237bb8ad39';
    
    public static $STAR_POLICY_TYPE    = 'OMPIND'; 
    public static $STAR_REQUEST_URL    = 'https://ig.starhealth.in/api/proposal/premium/calculate';
    public static $STAR_PROPOSAL_URL   = 'https://ig.starhealth.in/api/policy/proposals';
    public static $STAR_TOKEN_URL      = 'https://ig.starhealth.in/api/policy/proposals/';
    public static $STAR_PG_URL         = 'https://ig.starhealth.in/policy/proposals/purchase/';
    public static $STAR_PG_STAUS_URL   = 'https://ig.starhealth.in/api/policy/proposals/{TOKEN}/purchase/response';
    public static $STAR_STATE_CITY_URL  = 'https://ig.starhealth.in/api/policy/city/details?APIKEY=';
    public static $STAR_AREA_CITY_URL   = 'https://ig.starhealth.in/api/policy/address/details?APIKEY=';
    public static $STAR_DISCLAIMER  = 'I hereby Confirm that I/the person/s proposed Hold a valid Indian Passport which is non emigrant category and my travel doesnt include visit to any United Nations sanctioned Countries';

    // TABLE KEY CONTAINERS //

    // CMN RELATIONSHIP TABLE
    const CMN_RELATIONSHIP = ['REL_ID' => 'relationship_id', 
        'REL_NAME'=>'relationship_name', 
        'REL_GENDER'=>'relationship_gender',
        'CMN'=>'common',
        'RELIGARE'=>'religare'];

    // TRAVEL RELATIONSHIP
    const TRV_RELATIONSHIP = ['REL_ID' => 'relationship_id'];

    // TRAVEL TITLE TABLE
    const TRV_TITLE = ['TITLE_ID' => 'title_id'];

    // TATA HDFC TABLE
    const HDFC_TITLE = ['TITLE_ID' => 'title_id'];

    // TRAVEL STATE MASTER
    const TRV_STATE = ['STATE_NAME' => 'state_name',
        'STATE_ID' => 'state_id'];

    // TRAVEL CITY MASTER
    const TRV_CITY = ['CITY_NAME' => 'city_name',
        'CITY_ID' => 'city_id',
        'STATE_ID' => 'state_id'];

    // HDFC CITY MASTER
    const HDFC_CITY = ['CITY_NAME' => 'city_name',
        'CITY_ID' => 'city_id',
        'CITY_CODE' => 'city_code',
        'STATE_CODE' => 'city_state_code'];

    // HDFC STATE MASTER
    const HDFC_STATE = ['STATE_NAME' => 'state_name',
        'STATE_ID' => 'state_id'];

    // USER TABLE
    const USR_T_LOG = ['SESSION_ID' => 'session_id',
        'TRANS_CODE' => 'trans_code', 
        'SI' => 'sum_insured',
        'TRIP_TYPE' => 'triptype',
        'AREA' => 'area',
        'DURATION' => 'duration',
        'CHECKS' => 'checks',
        'AMT_DURATION' => 'amt_duration',
        'STD_DURATION' => 'std_duration',
        'TRAVEL_COUNT' => 'travelcount',
        'DOB' => 'dob',
        'CUST_DOB' => 'cust_dob',
        'TRANSNO' => 'transaction_num',
        'POLNO' => 'policy_num',
        'TRANSST' => 'transaction_status',
        'RELATIONSHIP' => 'relationship',
        'PROPREQ' => 'proposal_request',
        'USER_CODE' => 'user_code',
        'AGENT_CODE' => 'agent_code',
        'USER_CODE' => 'user_code',
        'AGENT_CODE' => 'agent_code',
        'QUOTE_ID' => 'quote_id',
        'QUOTE_CREATE_DATE' => 'quote_create_date',
        'QUOTE_UPDATE_DATE' => 'quote_update_date',
        'QUOTE_STATUS' => 'quote_status',
        'PROPOSAL_DATE' => 'proposal_date',
        'PROPOSAL_STATUS' => 'proposal_status',
        'PROPOSAL_REF_NO' => 'proposal_ref_number',
        'PROPOSAL_DESC' => 'proposal_desc',
        'PAYMENT_DATE' => 'payment_date',
        'PAYMENT_STATUS' => 'payment_status',
        'PAYMENT_REF_NO' => 'payment_ref_number',
        'PAYMENT_DESC' => 'payment_desc',
        'POLICY_DATE' => 'policy_date',
        'POLICY_STATUS' => 'policy_status',
        'POLICY_DESC' => 'policy_desc'];

    // TRAVEL NOMINEE RELATIONSHIP 
    const TRV_NOMINEE = ['REL_NAME' => 'relationship_name', 
        'HDFC' => 'relationship_hdfc', 
        'RELIGARE' => 'relationship_religare'];

    // CONFIG TABLE
    const TRV_CONFIG = ['CONFIG_NAME' => 'config_key',
        'CONFIG_VALUE' => 'config_value', 
        'CONFIG_COMPANY' => 'config_company'];

    // COVERAGE MAP TABLE
    const COV_MAP = ['BENEFITS' => 'map_benefits', 
        'SI' => 'map_si',
        'PLANCODE' => 'map_plan_code',
        'VALUES' => 'map_benefit_values'
        ];

    // COVERAGE MASTER
    const COV_MASTER = ['SH_TITLE' => 'benefit_short_title', 
        'TITLE' => 'benefit_title',
        'TATA_TITLE' => 'benefit_title_tata', 
        'ASIA_TITLE' => 'benefit_title_tata_asia',
        'SINGLE_TITLE' => 'benefit_title_tata_single',
        'AMT_TITLE' => 'benefit_title_tata_amt',
        'STUDENT_TITLE' => 'benefit_title_tata_student', 
        'CODE' => 'benefit_code', 
        'MUST' => 'benefit_must_have'];

    // TATA PREMIUM BREAKUP TABLE
    const TATA_PR_BRK = ['KEY' => 'breakup_key', 
        'TOTAL_PREMIUM' => 'breakup_totalpremium',
        'TAX' => 'breakup_tax',
        'INSURED' => 'breakup_insured'];

    // COMPANY MASTER
    const COMPANY_MASTER = ['NAME' => 'name', 
        'CODE' => 'value',
        'FULLNAME' => 'companyName',
        'URLNAME' => 'url_name'];

    // TRAVEL PLAN
    const TRAVEL_PLAN = ['ID' => 'plan_pid', 
        'COMPANY'  => 'plan_company',
        'CODE'  => 'plan_code',
        'NAME'  => 'plan_name',
        'DESTINATION'  => 'plan_destination',
        'DESTINATION_NAME'  => 'plan_destination_name',
        'SI_CODE' => 'plan_si_code',
        'SI' => 'plan_si',
        'TRIP_TYPE' => 'plan_trip_type'];
    

    public static function getQuoteFileName($session_id) {
        return 'Travel_quote' . $session_id . '.txt';
    }           
}