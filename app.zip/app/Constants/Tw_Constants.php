<?php

namespace App\Constants;

class Tw_Constants {
	
	const RSGI_QUOTE_URL = "https://dtc.royalsundaram.in/DTCWS/Services/Product/TwoWheeler/CalculatePremium";
	const RSGI_QUOTE_UPDATE_URL = "https://dtc.royalsundaram.in/DTCWS/Services/Product/TwoWheeler/UpdateVehicleDetails";
	const RSGI_PROPOSAL_URL = "https://dtc.royalsundaram.in/DTCWS/Services/Product/TwoWheeler/GProposalService";
	const RSGI_PAYMENT_URL = "https://www.royalsundaram.in/web/dtc/paymentgateway";


	const RELIANCE_COVERAGE_URL = "http://rzonews.reliancegeneral.co.in/API/Service/CoverageDetailsForMotor";
	const RELIANCE_QUOTE_URL = "http://rzonews.reliancegeneral.co.in/API/Service/PremiumCalulationForMotor";
	const RELIANCE_PROPOSAL_URL = "http://rzonews.reliancegeneral.co.in/API/Service/ProposalCreationForMotor";
	const RELIANCE_PAYMENT_URL = "http://rzonews.reliancegeneral.co.in/PaymentIntegration/PaymentIntegration";
	const RELIANCE_PDF_URL = "http://rzonews.reliancegeneral.co.in/API/Service/GeneratePolicyschedule";

	
	
	
	const YOR_SEL_ST = 'YOR_SELECT_START';
	const YOR_SEL_DUR = 'YOR_SELECT_UPTO';
	const DD_MMM_YY	 = 'd-M-y';
	const DD_MMM_YYYY 	= 'd-M-Y';

	const UIIC_COLUMN_NAME = 'uiic_code';
	
	const HDFC_COLUMN_NAME = 'hdfc_code';
	const HDFC_POLICY_REQ_FILE = "hdfcpolicyrequest.xml";
	
	const HDFC_PARTNER_CODE =  'TTIB0002';
	
	const SSN_KEY =  'ssn_key';
	const TRANS_CODE =  'trans_code';
	const POLICY_TYPE =  'policy_type';
	const MAKE_CODE =  'make_code';
	const MODEL_CODE =  'model_code';
	const VARIANT_CODE =  'variant_code';
	const VARIANT_PRICE =  'variant_price';
	const VARIANT_BASE_PRICE=  'variant_base_price';
	const VARIANT_CC =  'variant_cc';
	const STATE_CODE =  'state_code';
	const RTO_CODE =  'rto_code';
	const RTO_CITY_CODE =  'rto_city_code';
	const YOR =  'yor';
	const YOM =  'yom';
	const PRE_POLICY_STATUS=  'pre_policy_status';
	const POLICY_START_DATE =  'policy_start_date';
	const POLICY_EXP_DATE =  'policy_exp_date';
	const TERM_START_DATE =  'term_start_date';
	const TERM_END_DATE =  'term_end_date';
	const TW_REG_DATE =  'tw_reg_date';
	const TW_AGE =  'tw_age';
	const PRE_CLAIM_STATUS =  'pre_claim_status';
	const CURR_NCB =  'curr_ncb';
	const ELI_NCB =  'eli_ncb';
	const BASE_IDV =  'base_idv';
	const CALC_IDV =  'calc_idv';
	const OPT_IDV =  'opt_idv';
	const TERM_DURATION = 'term_duration';
	const INSURER_CODE =  'insurer_code';
	const ADDON_COVERS =  'addon_covers';
	const TOTAL_PREMIUM =  'total_premium';
	const OWNER_TYPE =  'owner_type';
	const PROPOSER_GENDER =  'proposer_gender';
	const PROPOSER_DOB =  'proposer_dob';
	const PROPOSER_NAME =  'proposer_name';
	const PROPOSER_EMAIL =  'proposer_email';
	const PROPOSER_MOBILE =  'proposer_mobile';
	const PROPOSER_AADHARNO =  'proposer_aadharno';
	const PROPOSER_PANNO =  'proposer_panno';
	const PROPOSER_OCCUPATION = 'proposer_occupation';
	const PROPOSER_MARITIALSTATUS = 'proposer_maritial_status';
	
	const REGN_ADDR1=  'regn_addr1';
	const REGN_ADDR2=  'regn_addr2';
	const REGN_ADDR3=  'regn_addr3';
	const REGN_STATE_CODE=  'regn_state_code';
	const REGN_CITY_CODE=  'regn_city_code';
	const REGN_PINCODE=  'regn_pincode';
	const SAME_COMM_ADDR=  'same_comm_addr';
	const PROPOSER_ADDR1 =  'proposer_addr1';
	const PROPOSER_ADDR2 =  'proposer_addr2';
	const PROPOSER_ADDR3 =  'proposer_addr3';
	const PROPOSER_STATE_CODE =  'proposer_state_code';
	const PROPOSER_CITY_CODE =  'proposer_city_code';
	const PROPOSER_PINCODE =  'proposer_pincode';
	const TW_REG_NO =  'tw_reg_no';
	const TW_ENGINE_NO =  'tw_engine_no';
	const TW_CHASSIS_NO =  'tw_chassis_no';
	const OWNER_CHANGED=  'owner_changed';
	const VOLUENTRY_DEDUCTABLES=  'voluentry_deductables';
	const ELE_ACC =  'ele_acc';
	const NON_ELE_ACC =  'non_ele_acc';
	const COLOR =  'color';
	const IS_FINANCED=  'is_financed';
	const TYPE_OF_FINANCE=  'type_of_finance';
	const FINANCIER_NAME=  'financier_name';
	const FINANCIER_ADDRESS=  'financier_address';
	const PRE_INSURER_CODE =  'pre_insurer_code';
	const PRE_INSURER_ADDR=  'pre_insurer_addr';
	const PRE_POLICY_NUMBER =  'pre_policy_number';
	const PRE_POLICY_TYPE=  'pre_policy_type';
	const PRE_CLAIM_COUNT =  'pre_claim_count';
	const PRE_CLAIM_AMOUNT =  'pre_claim_amount';
	const NOMI_NAME =  'nomi_name';
	const NOMI_AGE=  'nomi_age';
	const NOMI_DOB=  'nominee_dob';
	const NOMI_REL_CODE =  'nomi_rel_code';
	const PRE_ZERODEPT =  'pre_zerodept';
	
	const OD_PREMIUM=  'od_premium';
	const TP_PREMIUM=  'tp_premium';
	const ADDON_PREMIUM=  'addon_premium';
	const OD_DISC_VALUE=  'od_disc_value';
	const NCB_DISC_VALUE=  'ncb_disc_value';
	const GROSS_TOTAL_PREMIUM=  'gross_total_premium';
	const TOTAL_TAX=  'total_tax';
	const FINAL_PREMIUM=  'final_premium';
	const PR_CUSTOMERID =  'pr_customerid';
	const PR_NUMBER =  'pr_number';
	const TRANS_STATUS =  'trans_status';
	const POLICY_DATE=  'policy_date';
	const POLICY_NUMBER =  'policy_number';
	const USER_CODE =  'user_code';
	const AGENT_CODE =  'agent_code';
	const PARTNER_CODE =  'partner_code';
	const TEMP_COL_1 =  'temp_col_1';
	const TEMP_COL_2 =  'temp_col_2';
	const TEMP_COL_3 =  'temp_col_3';
	const TEMP_COL_4 =  'temp_col_4';
	const TEMP_COL_5 =  'temp_col_5';
	
	
	// TP constants
	
	const UIIC_GST_STATE_REF = "II0017";
	
}
