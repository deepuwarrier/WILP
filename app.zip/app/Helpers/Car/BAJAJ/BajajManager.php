<?php
namespace App\Helpers\Car\BAJAJ;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;
use App\Models\Car\CarTData;
use App\Models\Car\CarMake;
use App\Models\Car\CarModels;
use App\Models\Car\CarVariant;
use App\Models\Car\CarRto;
use App\Models\Car\MasterInsurer;
use App\Libraries\CarLib;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;

Class BajajManager {

    public $service_url = 'http://webservicesdev.bajajallianz.com/WebServicePolicy/WebServicePolicyPort?wsdl';
    public $premium_cals_fun = 'calculateMotorPremiumSig';
    public $proposal_cals_fun = 'issuePolicy';
    public $insurer_id = 'bajaj';
    public $product_id = 'bajaj';
    public $insurerroute = 'uat/bajaj';
    public $insurerName = 'Bajaj Allianz GI';
    public $pb_format = ['basic' => ['od', 'tp', 'll', 'pa']
            , 'addon' => ['rti', 'zerodep', 'ep', 'rsac', 'papass']
            , 'discounts' => ['ncbbenefit', 'od']
            , 'totalpremium'
            , 'serviceTax'
            , 'netPremium'];
    public $refrel_code = 'bajaj_code';
    public $bajaj_addon = ['PAPASS'];

    public function __construct(){
        $this->test = 0;
    }
    
    private function checkAddonAvailable(){
        $available = 1;
        if(isset($this->enable)){
            foreach ($this->enable['premium'] as $addon => $value) {
                if(!in_array($addon,$this->bajaj_addon)){
                    $available = 0;
                }
            }
        }
        return $available;
    }

    public function getQuote($data){
        $car_helper = new CarHelper;
        if(!$this->checkAddonAvailable()){
            $this->quote = NULL;
            return $this->quote;
        }

        if($this->test){
            $this->testObj = new TestBajaj();
            $this->car_details = $this->testObj->getCarDetails();
            return $this->quote = $this->testObj->getQuote();
        }else{
            $trans_code = $data['trans_code'];
            $this->car_details = $data;
            $user_data = CarTData::find($trans_code);
        }
        
        $quote = $this->get_quote_request($user_data);
        $quote->enableAddon($user_data->covers_selected);
        $param = (array) $quote;

        \Log::info('Car Bajaj Quote Request - '.$trans_code.' - ',$param);
        $result = self::callSoap($this->service_url, $param, $this->premium_cals_fun,$trans_code);
		\Log::info('Car Bajaj Quote Response - '.$trans_code.' - '.json_encode($result));

        if(!$quote->setResult($result)){
            return false;
        }
        
        $erorr = $quote->getErrorOut();
        
        //save transaction id 
        if(isset($result['pTransactionId_inout'])){
            $user_data->transaction_id = $result['pTransactionId_inout']; 
            $user_data->save();
        }
        
        if($erorr){
        	if(is_array($erorr))
        		\Log::info('Car Bajaj Quote Response Erorr - '.$trans_code.' - ',$erorr);
        	else
        		\Log::info('Car Bajaj Quote Response Erorr - '.$trans_code.' - ',(array)$erorr);	
        	return $this->quote = null;
        }
        
        $pb_data = new PremiumBreakupData();
        $pb_data = $this->parse_premium_breakup_data($pb_data,$quote);
        $pb = new PremiumBreakup();
        $pb->setPbDatat($pb_data);
        $premiumBreakup = $pb->genratePremiumBreakup();
        
        $this->quote = ['totalpremium' => $pb_data->getTotalPremium()
            , 'insurer_id' => $this->insurer_id
            , 'product_id' => $this->product_id
            , 'insurerroute' => $this->insurerroute
            , 'idv_received' => $quote->premiumDetailsOut_out->getTotalIev()
            , 'netPremium' => $pb_data->getGrossPremium()
            , 'insurerName' => $this->insurerName
            , 'serviceTax' => $pb_data->getServiceTax()
            , 'premiumBreakup' => $premiumBreakup
            ,  'pb_data'=>$pb_data];
       
        return $this->quote;
    }

    public function parse_premium_breakup_data($pb_data,$quote){
        $pb_data->setOdPremium($quote->premiumSummeryList_out->getOD());
        $pb_data->setTpPremium($quote->premiumSummeryList_out->getTP());
        $pb_data->setLlPremium($quote->premiumSummeryList_out->getLL());
        $pb_data->setPapassPremium($quote->premiumSummeryList_out->getPAPASS());
        $pb_data->setPaPremium($quote->premiumSummeryList_out->getPA());
        $pb_data->setServiceTax($quote->premiumDetailsOut_out->getServiceTax());
        $pb_data->setGrossPremium($quote->premiumDetailsOut_out->getNetPremium());
        $pb_data->setTotalPremium($quote->premiumDetailsOut_out->getFinalPremium());
        $pb_data->setNcbDiscount($quote->premiumDetailsOut_out->getNCBDiscount());
        $pb_data->setOdDiscount(0); 
        return $pb_data;
    }

    public function get_quote_request($user_data){
        $quote = new QuoteRequest();
        $car_helper = new CarHelper;
        if(strtolower($user_data->car_fuel) == 'diesel')
            $quote->pWeoMotPolicyIn_inout['fuel'] = 'D';

        $quote->pWeoMotPolicyIn_inout['termStartDate'] =$this->xml_date_parse($user_data->policy_start_date);
        $quote->pWeoMotPolicyIn_inout['termEndDate'] = $car_helper->manDate($quote->pWeoMotPolicyIn_inout['termStartDate'],'d-M-Y',['-1 days','+1 year']);
        $quote->pWeoMotPolicyIn_inout['tpFinType'] = NULL;
        if($user_data->veh_eng_no)
            $quote->pWeoMotPolicyIn_inout['engineNo'] = $user_data->veh_eng_no;
        if($user_data->veh_chassisno)
            $quote->pWeoMotPolicyIn_inout['chassisNo'] = $user_data->veh_chassisno;
        if($user_data->veh_reg_no)
            $quote->pWeoMotPolicyIn_inout['registrationNo'] = $user_data->car_rto.$user_data->veh_reg_no;

        $makeDb = new CarMake();
        $quote->pWeoMotPolicyIn_inout['vehicleMakeCode'] = $makeDb->getCode($user_data->car_make,$this->refrel_code);
        $quote->pWeoMotPolicyIn_inout['vehicleMake'] = $user_data->make_name;

        $modelDb = new CarModels();
        $quote->pWeoMotPolicyIn_inout['vehicleModelCode'] = $modelDb->getCode($user_data->car_model,$this->refrel_code);
        $quote->pWeoMotPolicyIn_inout['vehicleModel'] = $user_data->model_name;


        $variantDb = new CarVariant();
        $field = ['bajaj_code','bajaj_subtype','seat_capacity','variant_cc'];
        $variantDb = $variantDb->getData($user_data->car_variant,$field);
        $quote->pVehicleCode  = $variantDb->bajaj_code;
        $quote->pWeoMotPolicyIn_inout['vehicleSubtypeCode'] = $variantDb->bajaj_subtype;
        $quote->pWeoMotPolicyIn_inout['vehicleSubtype'] = $user_data->variant_name;
        $quote->pWeoMotPolicyIn_inout['carryingCapacity'] = $variantDb->seat_capacity;
        $quote->pWeoMotPolicyIn_inout['cubicCapacity'] = $variantDb->variant_cc;
        $quote->pWeoMotPolicyIn_inout['registrationDate'] = $this->xml_date_parse($user_data->car_registration_date);

        $rtoDb = new CarRto();
        $rtoDb = $rtoDb->getData($user_data->car_rto,['bajaj_code','zone']);
        $quote->pWeoMotPolicyIn_inout['zone'] = $rtoDb->zone;
        $quote->pWeoMotPolicyIn_inout['yearManf'] = date('Y',strtotime($user_data->car_registration_date));
        //$user_data->car_year;
        $quote->pWeoMotPolicyIn_inout['prvNcb'] = $user_data->ncb;
        $quote->pWeoMotPolicyIn_inout['ncb'] = $user_data->new_ncb;
        $quote->pWeoMotPolicyIn_inout['color'] = $user_data->veh_color;
        $quote->pWeoMotPolicyIn_inout['prvPolicyRef'] = $user_data->prev_policyno;
        if($user_data->usr_type && $user_data->usr_type == 'O')
            $quote->pWeoMotPolicyIn_inout['partnerType'] = 'I';
        

        if(strtolower($user_data->type_of_business) == 'rollover')
            $quote->pWeoMotPolicyIn_inout['prvExpiryDate'] = $this->xml_date_parse($user_data->policy_expiry_date);
        else{
            $quote->pWeoMotPolicyIn_inout['polType'] = 1;
        }

        if($user_data->prev_claim)
            $quote->pWeoMotPolicyIn_inout['prvClaimStatus'] = $user_data->prev_claim;
        
        if(!$user_data->prev_claim  && $user_data->claim == 'Y' )
            $quote->pWeoMotPolicyIn_inout['prvClaimStatus'] = 1;

        if($user_data->prev_insurance){
            $insurerDb = new MasterInsurer();
            $quote->pWeoMotPolicyIn_inout['prvInsCompany'] = $insurerDb->getCode($this->refrel_code,$user_data->prev_insurance);
        }
        

        $quote->pWeoMotPolicyIn_inout['registrationLocation'] = $rtoDb->bajaj_code;
        $quote->pWeoMotPolicyIn_inout['regiLocOther'] = $rtoDb->bajaj_code;
        $quote->pCity = $rtoDb->bajaj_code;
    
        // pass on some case 
        /*
            $quote->pWeoMotPolicyIn_inout['elecAccTotal'] = $user_data->veh_electricle;
            $quote->pWeoMotPolicyIn_inout['nonElecAccTotal'] = $user_data->veh_no_electricle;
            $quote->pWeoMotPolicyIn_inout['hypo'] = $user_data->policy_start_date;
        */
        // $quote->pWeoMotPolicyIn_inout['vehicleIdv'] = $user_data->policy_start_date;
        
        
        //$quote->enableElectAss(10000);
        return $quote;
    }

    public function setAddons($addons) {
        $addons = explode(",", $addons);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        foreach ($addons as $addon_key) {
            $this->enableAddon($addon_key);
        }
    }

    private function enableAddon($key){
    	$this->enable['premium'][$key] = 1;
    }

    private function disableAddon($key){
    	$this->enable['premium'][$key] = 0;
    }



    public static function callSoap($url, $request_xml, $fn = null,$trans_code = null) {
        try {
            $soapclient = new \SoapClient($url, array('trace' => 1));
            $response = $soapclient->__soapCall($fn, $request_xml);
            \Log::info('Car - BAJAJ - Xml Request - '.$trans_code.' :- ' .$soapclient->__getLastRequest());
            if (isset($response) && $response)
                return $response;
        } catch (\SoapFault $exception) {
            // echo $exception->getMessage();
            \Log::error('Car - BAJAJ - Soap excempetion error callSoap function - '.$trans_code.' :- ' . $exception->getMessage() . '<br> Line Number ' . $exception->getLine());
        } catch (\Exception $e) {
            // echo $e->getMessage();
            set_error_handler('var_dump', 0); // Never called because of empty mask.
            @trigger_error("");
            restore_error_handler();
            return false;
            \Log::error('Car - BAJAJ - try catch excempetion error callSoap function - '.$trans_code.' :- ' . $e->getMessage() . '<br> Line Number ' . $e->getLine());
            return false;
        }
    }

    public function getDbData($user_data) {
        $car_helper = new CarHelper;
        $this->field = $car_helper->getFieldMap();
        $this->db = (!$user_data) ? [] : $user_data;
        $this->user_data = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $this->field);
        $this->user_data['fullname'] = (isset($this->user_data['firstname']) && isset($this->user_data['lastname'])) ? $this->user_data['firstname'].' '.$this->user_data['lastname'] : '';

        if(isset($this->user_data['cust_dob']))
            $this->user_data['cust_dob'] = $car_helper->changeFormat($this->user_data['cust_dob'],'d/m/Y');
        return $this->user_data;
    }

    public function genProposalRequest($user_data,$request){
        $proposal = new ProposalRequest();
        $proposal->pTransactionId = $user_data->transaction_id;
        $proposal->setCustomerDetails($user_data);
        $quote_request = $this->get_quote_request($user_data);
        $quote_request->enableAddon($user_data->covers_selected);
        
        if($user_data->veh_electricle)
            $quote_request->enableElectAss($user_data->veh_electricle);

        if($user_data->veh_no_electricle)
            $quote_request->enableNonElectAss($user_data->veh_no_electricle);

        $proposal->pWeoMotPolicyIn_inout = $quote_request->pWeoMotPolicyIn_inout;
        $proposal->accessoriesList = $quote_request->accessoriesList_inout;
        $proposal->motExtraCover_inout = $quote_request->motExtraCover;
        $proposal->pQuestList = $quote_request->pWeoMotPolicyIn_inout;
        $proposal->paddoncoverList  = $quote_request->paddoncoverList_inout;

        //$proposal->pWeoMotPolicyIn_inout['elecAccTotal'] = 10000;

        $str = '{"WeoMotPremiumSummaryUser":[{"paramDesc":"LLO","paramRef":"LLO"},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":"policy@instainsure.com","paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null},{"paramDesc":null,"paramRef":null}]}';
        $str = json_decode($str,true);

        $proposal->premiumSummeryList = $str;

        $str = '{"serviceTax":"2234","collPremium":"14646","totalActPremium":"3013","netPremium":"12412","totalIev":"453129","addLoadPrem":"0","totalNetPremium":"0","imtOut":"22, 28,","totalPremium":"12412","ncbAmt":"-5060.7712365","stampDuty":"1","totalOdPremium":"9399","spDisc":"0","finalPremium":"14646"}';
        
        $str = json_decode($str,true);

        $proposal->premiumDetails = $str;

        $param = (array)$proposal;
        \Log::info('Car Bajaj Proposal Request - '.$user_data->trans_code.' - ',$param);
        $result = self::callSoap($this->service_url, $param, $this->proposal_cals_fun);
        \Log::info('Car Bajaj Proposal Response - '.$user_data->trans_code.' - '.json_encode($result));

    }


    public function xml_date_parse($date){
        $car_helper = new CarHelper;
        return $car_helper->changeFormat($date,'d-M-Y');
    }

    private function getVehicleAge($policy_start_date,$car_reg_date) {
        $d1 = new \DateTime($policy_start_date);
        $d2 = new \DateTime($car_reg_date);
        $interval = $d2->diff($d1);
        return (date('Y-m-d',strtotime($policy_start_date)) - date('Y-m-d',strtotime($car_reg_date)));
    }
}

Class TestBajaj{
    public $quote = [];
    public $service_url = 'http://webservicesdev.bajajallianz.com/WebServicePolicy/WebServicePolicyPort?WSDL';
    public $premium_cals_fun = 'calculateMotorPremiumSig';
    public $insurer_id = 'bajaj';
    public $product_id = 'bajaj';
    public $insurerroute = 'uat/bajaj';
    public $insurerName = 'Bajaj Allianz';
    public $pb_format = ['basic' => ['od', 'tp', 'll', 'pa']
            , 'addon' => ['rti', 'zerodep', 'ep', 'rsac', 'papass']
            , 'discounts' => ['ncbbenefit', 'od']
            , 'totalpremium'
            , 'serviceTax'
            , 'netPremium'];

    public function getQuote(){
        $this->quote = '{"totalpremium":"10700","insurer_id":"hdfc","product_id":"hdfc","insurerroute":"uat/hdfc","idv_received":"316223","netPremium":"9068","insurerName":"HDFC ERGO GI (UAT)","serviceTax":"1632","premiumBreakup":{"basic":{"od_basic_price":{"displayName":"Own Damage","basic_premium":10091},"tp_basic_price":{"displayName":"Third Party Liability","basic_premium":"2863"},"ll_basic_price":{"displayName":"Legal Liability","basic_premium":"50"},"pa_basic_price":{"displayName":"Personal Accident","basic_premium":"100"}},"discounts":{"ncbbenefit_discount_price":{"displayName":"No Claim Bonus","basic_premium":"2018"},"od_discount_price":{"displayName":"OD Discount","basic_premium":2018}},"totalpremium":{"displayName":"Total Premium","basic_premium":"10700"},"serviceTax":{"displayName":"Goods & Service Tax","basic_premium":"1632"},"netPremium":{"displayName":"Net Premium","basic_premium":"9068"}}}';
        $this->quote = json_decode($this->quote,true);
        $this->quote['insurer_id'] = $this->insurer_id;
        $this->quote['product_id'] = $this->product_id;
        $this->quote['insurerroute'] = $this->insurerroute;
        $this->quote['insurerName'] = $this->insurerName;
        return $this->quote;
    }

    public function getCarDetails(){
        $car_details = '{"cust_gst_code":"27","make_code":"IMK001","model_code":"IM0193","variant_code":"IV000005","state":"14","make_name":"Datsun","model_name":"Go Plus","fuel":"Petrol","variant_name":"D","ncb":20,"rto":"MH11","rto_zone":"B","claim":"N","vehicle_cc":"1198","typeOfBusiness":"Rollover","policyStartDate":"2017-12-24","policyExpiryDate":"2017-12-23","car_registration_date":"2015-12-25","vehicleAge":2,"ex_showroom_car_price":395279,"price":395279,"cov":"#,#,#","idv":316223,"new_ncb":25,"year":2015,"idv_min":252978.4,"idv_max":379467.6,"car_regis_min":"01/01/2015","car_regis_max":"31/12/2015","seating_capacity":5,"expiry_status":0,"session_id":"uaTN9MG5kt9BHj2AELsvut86SxgIV7CZ2bF0GAzH"}';
        $car_details = json_decode($car_details,true);
        return $car_details;
    }
}
