<?php
namespace App\Helpers\Car\BAJAJ;

use App\Helpers\Car\TATA\TataHelper;
use App\Helpers\Car\CarHelper;
use App\Models\Car\MasterState;
use App\Models\Car\MasterCity;
use App\Libraries\CarLib;

Class ProposalRequest {
	public $pUserId = 'policy@instainsure.com';
    public $pPassword = 'newpas12';
	Public $pTransactionId= '';
	Public $pRcptList_inout= NULL;
	Public $pCustDetails_inout = NULL;
	Public $pWeoMotPolicyIn_inout=NULL;
    Public $accessoriesList= [];
	Public $motExtraCover_inout=NULL;
    Public $pQuestList=[];
    Public $paddoncoverList=[];
	Public $premiumDetails=NULL;
	Public $premiumSummeryList=[];
	Public $ppolicyref_out=NULL;
	Public $ppolicyissuedate_out=NULL;
	Public $ppartId_out=NULL;
	Public $pError_out=NULL;
	Public $pErrorCode_out=NULL;
	Public $ppremiumpayerid= 0;
	Public $paymentmode= 'CC';
	Public $potherdetails=NULL;
	Public $pMotDetariff=NULL;

	public function __construct() {
        $quote_request = new QuoteRequest();

        $rcptList = new RcptList();
        $this->pRcptList_inout = $rcptList->getAttributes();

        $paymentOthDetails =  new PaymentOtherDetails();
        $this->potherdetails = $paymentOthDetails->getAttributes();
        
        $motorDetrif = new MotorDetrif();
        $this->pMotDetariff = $motorDetrif->getAttributes();
    }

    public function setCustomerDetails($user_data){
        $custDetails = new WeoB2cCustDetailsUser();
        $custDetails->setFirstName($user_data->usr_firstname);
        $custDetails->setMiddleName('');
        $custDetails->setSurname($user_data->usr_lastname);
        $custDetails->setAddLine1($user_data->usr_houseno);
        $custDetails->setAddLine2($user_data->usr_street.','.$user_data->usr_locality);
        
        $stateDb = new MasterState();
        $custDetails->setAddLine3($stateDb->getName($user_data->usr_state_code));
        
        $cityDb = new MasterCity();
        $custDetails->setAddLine5($cityDb->getName($user_data->usr_city_code));
        
        $custDetails->setPincode($user_data->usr_pincode);
        $custDetails->setEmail($user_data->usr_email);
        $custDetails->setMobile($user_data->usr_mobile);
        $custDetails->setMobile($user_data->usr_mobile);

        if(isset($user_data->reg_add_is_same) && $user_data->reg_add_is_same == 'Y'){
            $custDetails->setPolAddLine1($custDetails->getAddLine1());
            $custDetails->setPolAddLine2($custDetails->getAddLine2());
            $custDetails->setPolAddLine3($custDetails->getAddLine3());
            $custDetails->setPolAddLine5($custDetails->getAddLine5());
            $custDetails->setPolPincode($custDetails->getPincode());
            
        }else{
            $custDetails->setPolAddLine1($user_data->prem_usr_lastname);
            $custDetails->setPolAddLine2($user_data->prem_usr_street.','.$user_data->prem_usr_locality);
            $custDetails->setPolAddLine3($stateDb->getName($user_data->prem_usr_state_code));
            $custDetails->setPolAddLine5($cityDb->getName($user_data->prem_usr_city_code));
            $custDetails->setPolPincode($user_data->prem_usr_pincode);
        }
        $custDetails->setDateOfBirth(CarHelper::changeFormat($user_data->usr_dob,'d-M-Y'));
        $custDetails->setAvailableTime($user_data->usr_aadharno);
        $custDetails->setMobileAlerts($user_data->usr_pan);
        $custDetails->setTitle((strtolower($user_data->usr_gender) == 'm')? 'Mr' : 'Miss');
        
        if($user_data->usr_type && $user_data->usr_type == 'O')
            $custDetails->setCpType('I');
      
        $custDetails->setInstitutionName($user_data->usr_companyname);
        
        if($custDetails->getCpType() == 'I'){
            $custDetails->setFirstName(CarLib::getFirstName($user_data->usr_contactperson));
            $custDetails->setMiddleName('');
            $custDetails->setSurname(CarLib::getLastName($user_data->usr_contactperson));
        }

        $this->pCustDetails_inout = $custDetails->getAttributes();
    }

    public function getCustomerObj(){
        return $this->pCustDetails_inout;
    }
}

Class RcptList{
    Private $payAmt;
    Private $payMode;
    Private $collectionAmt;
    Private $collectionNo;
    Private $receiptNo;

    public function getAttributes(){
        return get_object_vars($this);
    }
}

Class WeoB2cCustDetailsUser 
{
    /**
     * @var string $telephone1
     */
    protected $telephone1 = null;

    /**
     * @var string $dateOfBirth
     */
    protected $dateOfBirth = null;

    /**
     * @var string $telephone2
     */
    protected $telephone2 = null;

    /**
     * @var string $status1
     */
    protected $status1 = null;

    /**
     * @var string $institutionName
     */
    protected $institutionName = null;

    /**
     * @var string $profession
     */
    protected $profession = null;

    /**
     * @var string $existingYn
     */
    protected $existingYn = null;

    /**
     * @var string $addLine3
     */
    protected $addLine3 = null;

    /**
     * @var string $surname
     */
    protected $surname = null;

    /**
     * @var string $addLine2
     */
    protected $addLine2 = null;

    /**
     * @var string $partId
     */
    protected $partId = null;

    /**
     * @var string $addLine1
     */
    protected $addLine1 = null;

    /**
     * @var string $password
     */
    protected $password = null;

    /**
     * @var string $title
     */
    protected $title = null;

    /**
     * @var string $delivaryOption
     */
    protected $delivaryOption = null;

    /**
     * @var string $firstName
     */
    protected $firstName = null;

    /**
     * @var string $middleName
     */
    protected $middleName = null;

    /**
     * @var string $mobileAlerts
     */
    protected $mobileAlerts = null;

    /**
     * @var string $loggedIn
     */
    protected $loggedIn = null;

    /**
     * @var string $partTempId
     */
    protected $partTempId = null;

    /**
     * @var string $availableTime
     */
    protected $availableTime = null;

    /**
     * @var string $pincode
     */
    protected $pincode = null;

    /**
     * @var string $polAddLine1
     */
    protected $polAddLine1 = null;

    /**
     * @var string $polAddLine3
     */
    protected $polAddLine3 = null;

    /**
     * @var string $polAddLine2
     */
    protected $polAddLine2 = null;

    /**
     * @var string $addLine5
     */
    protected $addLine5 = null;

    /**
     * @var string $polAddLine5
     */
    protected $polAddLine5 = null;

    /**
     * @var string $polPincode
     */
    protected $polPincode = null;

    /**
     * @var string $cpType
     */
    protected $cpType = 'P';

    /**
     * @var string $email
     */
    protected $email = null;

    /**
     * @var string $status3
     */
    protected $status3 = null;

    /**
     * @var string $status2
     */
    protected $status2 = null;

    /**
     * @var string $emailAlerts
     */
    protected $emailAlerts = null;

    /**
     * @var string $mobile
     */
    protected $mobile = null;

    
    public function __construct()
    {
        $tmp = ['partTempId'=>'',
                'firstName'=>'Raj',
                'middleName'=>'B',
                'surname'=>'Kumar',
                'addLine1'=>'GE Plaza, ',
                'addLine2'=>'3rd Floor,Yerawada, ',
                'addLine3'=>'Pune',
                'addLine5'=>'Maharashtra',
                'pincode'=>'411006',
                'email'=>'customer_email@rediffmail.com',
                'telephone1'=>'20653212',
                'telephone2'=>'20543215445',
                'mobile'=>'9970150000',
                'delivaryOption'=>'',
                'polAddLine1'=>'GE Plaza, ',
                'polAddLine2'=>'3rd Floor,Yerawada, ',
                'polAddLine3'=>'Pune',
                'polAddLine5'=>'Maharashtra',
                'polPincode'=>'411006',
                'password'=>'',
                'cpType'=>'I',
                'profession'=>'',
                'dateOfBirth'=>'01-JAN-1985',
                'availableTime'=>'1234 1231 1254',
                'institutionName'=>'',
                'existingYn'=>'N',
                'loggedIn'=>'',
                'mobileAlerts'=>'ABRPU121E',
                'emailAlerts'=>'',
                'title'=>'Mr',
                'partId'=>'',
                'status1'=>'',
                'status2'=>'',
                'status3'=>''];
        // foreach ($tmp as $key => $value) {
        //     $this->$key = $value;
        // }
    }

    public function getAttributes(){
        return get_object_vars($this);
    }

    /**
     * @return string
     */
    public function getTelephone1()
    {
      return $this->telephone1;
    }

    /**
     * @param string $telephone1
     * @return WeoB2cCustDetailsUser
     */
    public function setTelephone1($telephone1)
    {
      $this->telephone1 = $telephone1;
      return $this;
    }

    /**
     * @return string
     */
    public function getDateOfBirth()
    {
      return $this->dateOfBirth;
    }

    /**
     * @param string $dateOfBirth
     * @return WeoB2cCustDetailsUser
     */
    public function setDateOfBirth($dateOfBirth)
    {
      $this->dateOfBirth = $dateOfBirth;
      return $this;
    }

    /**
     * @return string
     */
    public function getTelephone2()
    {
      return $this->telephone2;
    }

    /**
     * @param string $telephone2
     * @return WeoB2cCustDetailsUser
     */
    public function setTelephone2($telephone2)
    {
      $this->telephone2 = $telephone2;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatus1()
    {
      return $this->status1;
    }

    /**
     * @param string $status1
     * @return WeoB2cCustDetailsUser
     */
    public function setStatus1($status1)
    {
      $this->status1 = $status1;
      return $this;
    }

    /**
     * @return string
     */
    public function getInstitutionName()
    {
      return $this->institutionName;
    }

    /**
     * @param string $institutionName
     * @return WeoB2cCustDetailsUser
     */
    public function setInstitutionName($institutionName)
    {
      $this->institutionName = $institutionName;
      return $this;
    }

    /**
     * @return string
     */
    public function getProfession()
    {
      return $this->profession;
    }

    /**
     * @param string $profession
     * @return WeoB2cCustDetailsUser
     */
    public function setProfession($profession)
    {
      $this->profession = $profession;
      return $this;
    }

    /**
     * @return string
     */
    public function getExistingYn()
    {
      return $this->existingYn;
    }

    /**
     * @param string $existingYn
     * @return WeoB2cCustDetailsUser
     */
    public function setExistingYn($existingYn)
    {
      $this->existingYn = $existingYn;
      return $this;
    }

    /**
     * @return string
     */
    public function getAddLine3()
    {
      return $this->addLine3;
    }

    /**
     * @param string $addLine3
     * @return WeoB2cCustDetailsUser
     */
    public function setAddLine3($addLine3)
    {
      $this->addLine3 = $addLine3;
      return $this;
    }

    /**
     * @return string
     */
    public function getSurname()
    {
      return $this->surname;
    }

    /**
     * @param string $surname
     * @return WeoB2cCustDetailsUser
     */
    public function setSurname($surname)
    {
      $this->surname = $surname;
      return $this;
    }

    /**
     * @return string
     */
    public function getAddLine2()
    {
      return $this->addLine2;
    }

    /**
     * @param string $addLine2
     * @return WeoB2cCustDetailsUser
     */
    public function setAddLine2($addLine2)
    {
      $this->addLine2 = $addLine2;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartId()
    {
      return $this->partId;
    }

    /**
     * @param string $partId
     * @return WeoB2cCustDetailsUser
     */
    public function setPartId($partId)
    {
      $this->partId = $partId;
      return $this;
    }

    /**
     * @return string
     */
    public function getAddLine1()
    {
      return $this->addLine1;
    }

    /**
     * @param string $addLine1
     * @return WeoB2cCustDetailsUser
     */
    public function setAddLine1($addLine1)
    {
      $this->addLine1 = $addLine1;
      return $this;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
      return $this->password;
    }

    /**
     * @param string $password
     * @return WeoB2cCustDetailsUser
     */
    public function setPassword($password)
    {
      $this->password = $password;
      return $this;
    }

    /**
     * @return string
     */
    public function getTitle()
    {
      return $this->title;
    }

    /**
     * @param string $title
     * @return WeoB2cCustDetailsUser
     */
    public function setTitle($title)
    {
      $this->title = $title;
      return $this;
    }

    /**
     * @return string
     */
    public function getDelivaryOption()
    {
      return $this->delivaryOption;
    }

    /**
     * @param string $delivaryOption
     * @return WeoB2cCustDetailsUser
     */
    public function setDelivaryOption($delivaryOption)
    {
      $this->delivaryOption = $delivaryOption;
      return $this;
    }

    /**
     * @return string
     */
    public function getFirstName()
    {
      return $this->firstName;
    }

    /**
     * @param string $firstName
     * @return WeoB2cCustDetailsUser
     */
    public function setFirstName($firstName)
    {
      $this->firstName = $firstName;
      return $this;
    }

    /**
     * @return string
     */
    public function getMiddleName()
    {
      return $this->middleName;
    }

    /**
     * @param string $middleName
     * @return WeoB2cCustDetailsUser
     */
    public function setMiddleName($middleName)
    {
      $this->middleName = $middleName;
      return $this;
    }

    /**
     * @return string
     */
    public function getMobileAlerts()
    {
      return $this->mobileAlerts;
    }

    /**
     * @param string $mobileAlerts
     * @return WeoB2cCustDetailsUser
     */
    public function setMobileAlerts($mobileAlerts)
    {
      $this->mobileAlerts = $mobileAlerts;
      return $this;
    }

    /**
     * @return string
     */
    public function getLoggedIn()
    {
      return $this->loggedIn;
    }

    /**
     * @param string $loggedIn
     * @return WeoB2cCustDetailsUser
     */
    public function setLoggedIn($loggedIn)
    {
      $this->loggedIn = $loggedIn;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartTempId()
    {
      return $this->partTempId;
    }

    /**
     * @param string $partTempId
     * @return WeoB2cCustDetailsUser
     */
    public function setPartTempId($partTempId)
    {
      $this->partTempId = $partTempId;
      return $this;
    }

    /**
     * @return string
     */
    public function getAvailableTime()
    {
      return $this->availableTime;
    }

    /**
     * @param string $availableTime
     * @return WeoB2cCustDetailsUser
     */
    public function setAvailableTime($availableTime)
    {
      $this->availableTime = $availableTime;
      return $this;
    }

    /**
     * @return string
     */
    public function getPincode()
    {
      return $this->pincode;
    }

    /**
     * @param string $pincode
     * @return WeoB2cCustDetailsUser
     */
    public function setPincode($pincode)
    {
      $this->pincode = $pincode;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolAddLine1()
    {
      return $this->polAddLine1;
    }

    /**
     * @param string $polAddLine1
     * @return WeoB2cCustDetailsUser
     */
    public function setPolAddLine1($polAddLine1)
    {
      $this->polAddLine1 = $polAddLine1;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolAddLine3()
    {
      return $this->polAddLine3;
    }

    /**
     * @param string $polAddLine3
     * @return WeoB2cCustDetailsUser
     */
    public function setPolAddLine3($polAddLine3)
    {
      $this->polAddLine3 = $polAddLine3;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolAddLine2()
    {
      return $this->polAddLine2;
    }

    /**
     * @param string $polAddLine2
     * @return WeoB2cCustDetailsUser
     */
    public function setPolAddLine2($polAddLine2)
    {
      $this->polAddLine2 = $polAddLine2;
      return $this;
    }

    /**
     * @return string
     */
    public function getAddLine5()
    {
      return $this->addLine5;
    }

    /**
     * @param string $addLine5
     * @return WeoB2cCustDetailsUser
     */
    public function setAddLine5($addLine5)
    {
      $this->addLine5 = $addLine5;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolAddLine5()
    {
      return $this->polAddLine5;
    }

    /**
     * @param string $polAddLine5
     * @return WeoB2cCustDetailsUser
     */
    public function setPolAddLine5($polAddLine5)
    {
      $this->polAddLine5 = $polAddLine5;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolPincode()
    {
      return $this->polPincode;
    }

    /**
     * @param string $polPincode
     * @return WeoB2cCustDetailsUser
     */
    public function setPolPincode($polPincode)
    {
      $this->polPincode = $polPincode;
      return $this;
    }

    /**
     * @return string
     */
    public function getCpType()
    {
      return $this->cpType;
    }

    /**
     * @param string $cpType
     * @return WeoB2cCustDetailsUser
     */
    public function setCpType($cpType)
    {
      $this->cpType = $cpType;
      return $this;
    }

    /**
     * @return string
     */
    public function getEmail()
    {
      return $this->email;
    }

    /**
     * @param string $email
     * @return WeoB2cCustDetailsUser
     */
    public function setEmail($email)
    {
      $this->email = $email;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatus3()
    {
      return $this->status3;
    }

    /**
     * @param string $status3
     * @return WeoB2cCustDetailsUser
     */
    public function setStatus3($status3)
    {
      $this->status3 = $status3;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatus2()
    {
      return $this->status2;
    }

    /**
     * @param string $status2
     * @return WeoB2cCustDetailsUser
     */
    public function setStatus2($status2)
    {
      $this->status2 = $status2;
      return $this;
    }

    /**
     * @return string
     */
    public function getEmailAlerts()
    {
      return $this->emailAlerts;
    }

    /**
     * @param string $emailAlerts
     * @return WeoB2cCustDetailsUser
     */
    public function setEmailAlerts($emailAlerts)
    {
      $this->emailAlerts = $emailAlerts;
      return $this;
    }

    /**
     * @return string
     */
    public function getMobile()
    {
      return $this->mobile;
    }

    /**
     * @param string $mobile
     * @return WeoB2cCustDetailsUser
     */
    public function setMobile($mobile)
    {
      $this->mobile = $mobile;
      return $this;
    }

}


Class PaymentOtherDetails{
    Private $imdcode;
    Private $covernoteNo;
    Private $leadNo;
    Private $cceCode;
    Private $runnerCode;
    Private $extra1 = 'NEWPG';
    Private $extra2;
    Private $extra3;
    Private $extra4;
    Private $extra5;

    public function getAttributes(){
        return get_object_vars($this);
    }
}

Class MotorDetrif{
    Private $vehPurchaseType;
    Private $vehPurchaseDate;
    Private $monthOfMfg;
    Private $bodyType;
    Private $goodsTransType;
    Private $natureOfGoods;
    Private $otherGoodsFrequency;
    Private $permitType;
    Private $roadType;
    Private $vehDrivenBy;
    Private $driverExperience;
    Private $clmHistCode;
    Private $incurredClmExpCode;
    Private $driverQualificationCode;
    Private $tacMakeCode;
    Private $extCol1;
    Private $extCol2;
    Private $extCol3;
    Private $extCol4;
    Private $extCol5;
    Private $extCol6;
    Private $extCol7;
    Private $extCol8;
    Private $extCol9;
    Private $extCol10;
    Private $extCol11;
    Private $extCol12;
    Private $extCol13;
    Private $extCol14;
    Private $extCol15;
    Private $extCol16;
    Private $extCol17;
    Private $extCol18;
    Private $extCol19;
    Private $extCol20 = 'http://your_domain_name/zzz/response.aspx?';
    Private $registrationAuth;
    Private $extCol21;
    Private $extCol22;
    Private $extCol23;
    Private $extCol24;
    Private $extCol25;
    Private $extCol26;
    Private $extCol27;
    Private $extCol28;
    Private $extCol29;
    Private $extCol30;
    Private $extCol31;
    Private $extCol32;
    Private $extCol33;
    Private $extCol34;
    Private $extCol35;
    Private $extCol36;
    Private $extCol37;
    Private $extCol38;
    Private $extCol39;
    Private $extCol40;

    public function getAttributes(){
        return get_object_vars($this);
    }
}