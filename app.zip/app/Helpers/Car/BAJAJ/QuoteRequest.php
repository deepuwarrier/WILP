<?php

namespace App\Helpers\Car\BAJAJ;

use App\Helpers\Car\TATA\TataHelper;
use App\Helpers\Car\CarHelper;

Class QuoteRequest {

    public $pUserId = 'policy@instainsure.com';
    public $pPassword = 'newpas12';
    public $pVehicleCode = '';
    public $pCity = 'DELHI';
    public $pWeoMotPolicyIn_inout = NULL;
    public $accessoriesList_inout = NULL;
    public $paddoncoverList_inout = [];
    public $motExtraCover = NULL;
    public $pQuestList_inout = NULL;
    public $pDetariffObj_inout = NULL;
    public $premiumDetailsOut_out = NULL;
    public $premiumSummeryList_out = NULL;
    public $pError_out = NULL;
    public $pErrorCode_out = NULL;
    public $pTransactionId_inout = 0;
    public $pTransactionType = 0;
    public $pContactNo = NULL;

    public function __construct() {
        $this->pWeoMotPolicyIn_inout = (array) new WeoMotPlanDetailsUser();
        $this->accessoriesList_inout = (array) new WeoMotAccessoriesUserArray();
        $this->motExtraCover = (array) new WeoSigMotExtraCoversUser();
        $this->pQuestList_inout = (array) new WeoBjazMotQuestionaryUserArray();
        $this->pDetariffObj_inout = (array) new WeoMotDetariffObjUser();
    }

    public function enableAddon($addon){
        $addon = explode(',',$addon);
        $assc = new Addon;
        if(in_array('PAPASS',$addon))
                $assc->enable_papass();
        // by defaulf ll enablbe
        $assc->enable_ll();
        $this->paddoncoverList_inout = $assc->addon_list;
        unset($assc);

    }

    public function enableElectAss($price){
        $assc = new Addon;
        $assc->enable_elect();
        $this->paddoncoverList_inout[] = $assc->addon_list[0];
        $this->pWeoMotPolicyIn_inout['elecAccTotal'] = $price;
        unset($assc);
    }

    public function enableNonElectAss($price){
        $assc = new Addon;
        $assc->enable_non_elect();
        $this->paddoncoverList_inout[] = $assc->addon_list[0];
        $this->pWeoMotPolicyIn_inout['nonElecAccTotal'] = $price;
        unset($assc);
    }

    public function setResult($result){
       if(!$result)
           return false;

       if (isset($result['pError_out'])) {
            $error = new Error((array) $result['pError_out']);
            $this->setErrorOut($error);
        }

        if (isset($result['premiumDetailsOut_out'])) {
            $detail = new PremiumDetails((array) $result['premiumDetailsOut_out']);
            $this->setPremiumDetails($detail);
        }

        if (isset($result['premiumSummeryList_out'])) {
            $premium_sum = new PremiumSumm((array) $result['premiumSummeryList_out']);
            $this->setPremiumSumm($premium_sum);
        }

        if (isset($result['pDetariffObj_inout'])) {
            $pDetariffObj_inout = new WeoMotDetariffObjUser((array) $result['pDetariffObj_inout']);
            $this->setDetariffObj($pDetariffObj_inout);
        }
        
        return true;
    }

    public function setDetariffObj(WeoMotDetariffObjUser $pDetariffObj_inout){
    	$this->pDetariffObj_inout = $pDetariffObj_inout;
    }
    public function setPremiumSumm(PremiumSumm $premium_sum){
    	$this->premiumSummeryList_out = $premium_sum;
    }

    public function setPremiumDetails(PremiumDetails $details) {
        $this->premiumDetailsOut_out = $details;
    }

    public function getPremiumSumm(){
    	return $this->premiumSummeryList_out;
    }

    public function setErrorOut(Error $obj) {
        $this->pError_out = $obj;
    }

    public function getPremiumDetails() {
        return $this->premiumDetailsOut_out;
    }

    public function getErrorOut() {
    	if(isset($this->pError_out->WeoTygeErrorMessageUser))
        	return $this->pError_out->WeoTygeErrorMessageUser;
        else 
        	return NULL;
    }
}

Class WeoMotPlanDetailsUser {
    public $contractId = '';
    public $polType = '3';
    public $product4digitCode = '1801';
    public $deptCode = '18';
    public $branchCode = '1901';
    public $termStartDate = '';
    public $termEndDate = '';
    public $tpFinType = '';
    public $hypo = '';
    public $vehicleTypeCode = '22';
    public $vehicleType = 'Private Car';
    public $miscVehType = '';
    public $vehicleMakeCode = '';
    public $vehicleMake = '';
    public $vehicleModelCode = '';
    public $vehicleModel = '';
    public $vehicleSubtypeCode = '';
    public $vehicleSubtype = '';
    public $fuel = '';
    public $zone = '';
    public $engineNo = 'ABCD';
    public $chassisNo = 'ABCD';
    public $registrationNo = 'MH12FR1234';
    public $registrationDate = '';
    public $registrationLocation = 'DELHI';
    public $regiLocOther = 'DELHI';
    public $carryingCapacity = '';
    public $cubicCapacity = '';
    public $yearManf = '';
    public $color = '';
    public $vehicleIdv = '';
    public $ncb = '';
    public $addLoading = '0';
    public $addLoadingOn = '0';
    public $spDiscRate = '0';
    public $elecAccTotal = '0';
    public $nonElecAccTotal = '0';
    public $prvPolicyRef = '';
    public $prvExpiryDate = '';
    public $prvInsCompany = '1';
    public $prvNcb = '';
    public $prvClaimStatus =  0;
    public $autoMembership = '';
    public $partnerType = 'P';

    public function __construct() {
        $test_param = ['contractId' => 0,
            'polType' => 3,
            'product4digitCode' => 1801,
            'deptCode' => 18,
            'branchCode' => 1901,
            'termStartDate' => '16-Dec-2017',
            'termEndDate' => '15-Dec-2018',
            'tpFinType' => 1,
            'hypo' => 'State Bank of India',
            'vehicleTypeCode' => 22,
            'vehicleType' => 'public Car',
            'miscVehType' => 0,
            'vehicleMakeCode' => 110,
            'vehicleMake' => 'MARUTI',
            'vehicleModelCode' => 29,
            'vehicleModel' => 'SWIFT',
            'vehicleSubtypeCode' => 21,
            'vehicleSubtype' => 'LXI',
            'fuel' => 'P',
            'zone' => 'A',
            'engineNo' => 'ABCD',
            'chassisNo' => 'ABCD',
            'registrationNo' => 'MH12FR1234',
            'registrationDate' => '9-Dec-2016',
            'registrationLocation' => 'DELHI',
            'regiLocOther' => 'DELHI',
            'carryingCapacity' => 5,
            'cubicCapacity' => 1298,
            'yearManf' => 2013,
            'color' => 'RED',
            'vehicleIdv' => '',
            'ncb' => 20,
            'addLoading' => 0,
            'addLoadingOn' => 0,
            'spDiscRate' => 0,
            'elecAccTotal' => 0,
            'nonElecAccTotal' => 0,
            'prvPolicyRef' => '123123123',
            'prvExpiryDate' => '15-DEC-2017',
            'prvInsCompany' => 1,
            'prvNcb' => 0,
            'prvClaimStatus' => 0,
            'autoMembership' => '',
            'partnerType' => 'P'];

        // foreach ($test_param as $key => $value) {
        //     $this->{$key} = trim($value);
        // }

  //       $this->termStartDate = CarHelper::manDate(date('d-M-Y'),'d-M-Y',['+1 days']);
  //       $this->termEndDate = CarHelper::manDate($this->termStartDate,'d-M-Y',['-1 days','-1 year']);
  //       $this->prvExpiryDate = CarHelper::manDate($this->termStartDate,'d-M-Y',['-1 days']);
  //       $this->registrationDate = date('d-M-Y', strtotime($this->registrationDate));
		// $this->yearManf = 2016;    
    }

}

Class WeoMotAccessoriesUserArray {

    public $contractId = '';
    public $accCategoryCode = '';
    public $accTypeCode = '';
    public $accMake = '';
    public $accModel = '';
    public $accIev = '';
    public $accCount = '';

}

Class Addon{
	public $addon_list = [];

	public function enable_papass(){
		$addon = new WeoMotGenParamUserArray();
		$addon->paramDesc = 'PA';
		$addon->paramRef = 'PA';
		$this->addon_list[] = (array)$addon;
		unset($addon);
	}

	public function enable_ll(){
		$addon = new WeoMotGenParamUserArray();
		$addon->paramDesc = 'LLO';
		$addon->paramRef = 'LLO';
		$this->addon_list[] = (array)$addon;
		unset($addon);
	}

    public function enable_elect(){
        $addon = new WeoMotGenParamUserArray();
        $addon->paramDesc = 'ELECACC';
        $addon->paramRef = 'ELECACC';
        $this->addon_list[] = (array)$addon;
        unset($addon);
    }

    public function enable_non_elect(){
        $addon = new WeoMotGenParamUserArray();
        $addon->paramDesc = 'NELECACC';
        $addon->paramRef = 'NELECACC';
        $this->addon_list[] = (array)$addon;
        unset($addon);
    }
}	

Class WeoMotGenParamUserArray {
    public $paramDesc = NULL;
    public $paramRef = NULL;
}

Class WeoSigMotExtraCoversUser {
    public $geogExtn = '';
    public $noOfPersonsPa = '5';
    public $sumInsuredPa = '100000';
    public $sumInsuredTotalNamedPa = '100000';
    public $cngValue = '';
    public $noOfEmployeesLle = '';
    public $noOfPersonsLlo = '1';
    public $fibreGlassValue = '';
    public $sideCarValue = '';
    public $noOfTrailers = '';
    public $totalTrailerValue = '';
    public $voluntaryExcess = '';
    public $covernoteNo = '';
    public $covernoteDate = NULL;
    public $subImdcode = '';
    public $extraField1 = '';
    public $extraField2 = '';
    public $extraField3 = '';


}

Class WeoBjazMotQuestionaryUserArray {

    public $questionRef = "";
    public $contractId = "";
    public $questionVal = "";

}

Class WeoMotDetariffObjUser {

    public $vehPurchaseType = '';
    public $vehPurchaseDate = '';
    public $monthOfMfg = '';
    public $bodyType = '';
    public $goodsTransType = '';
    public $natureOfGoods = '';
    public $otherGoodsFrequency = '';
    public $permitType = '';
    public $roadType = '';
    public $vehDrivenBy = '';
    public $driverExperience = '';
    public $clmHistCode = '';
    public $incurredClmExpCode = '';
    public $driverQualificationCode = '';
    public $tacMakeCode = '';
    public $extCol1 = '';
    public $extCol2 = '';
    public $extCol3 = '';
    public $extCol4 = '';
    public $extCol5 = '';
    public $extCol6 = '';
    public $extCol7 = '';
    public $extCol8 = '';
    public $extCol9 = '';
    public $extCol10 = '';
    public $extCol11 = '';
    public $extCol12 = '';
    public $extCol13 = '';
    public $extCol14 = '';
    public $extCol15 = '';
    public $extCol16 = '';
    public $extCol17 = '';
    public $extCol18 = '';
    public $extCol19 = '';
    public $extCol20 = '';
    public $registrationAuth = '';
    public $extCol21 = '';
    public $extCol22 = '';
    public $extCol23 = '';
    public $extCol24 = '';
    public $extCol25 = '';
    public $extCol26 = '';
    public $extCol27 = '';
    public $extCol28 = '';
    public $extCol29 = '';
    public $extCol30 = '';
    public $extCol31 = '';
    public $extCol32 = '';
    public $extCol33 = '';
    public $extCol34 = '';
    public $extCol35 = '';
    public $extCol36 = '';
    public $extCol37 = '';
    public $extCol38 = '';
    public $extCol39 = '';
    public $extCol40 = '';

    public function __construct($k = NULL) {

    	if(isset($k) && is_array($k))
	        foreach ($k as $key => $value) {
	            $this->$key = $value;
	        }
    }

}

Class PremiumDetails {
    Public $ncbAmt = NULL;
    Public $addLoadPrem = NULL;
    Public $totalOdPremium = NULL;
    Public $totalActPremium = NULL;
    Public $totalNetPremium = NULL;
    Public $totalPremium = NULL;
    Public $netPremium = NULL;
    Public $finalPremium = NULL;
    Public $spDisc = NULL;
    Public $serviceTax = NULL;
    Public $stampDuty = NULL;
    Public $collPremium = NULL;
    Public $imtOut = NULL;
    Public $totalIev = NULL;

    public function __construct($k) {
        // foreach ($k as $key => $value) {
        //     $this->$key = abs($value);
        // }
        $this->setTP($k['totalActPremium']);
        $this->setOD($k['totalOdPremium']);
        $this->setNCBDiscount($k['ncbAmt']);
        $this->setServiceTax($k['serviceTax']);
        $this->setNetPremium($k['netPremium']);
        $this->setFinalPremium($k['finalPremium']);
        $this->setTotalIev($k['totalIev']);
    }

    public function setTotalIev($totalIev){
        $this->totalIev = $totalIev;
    }

    public function getTotalIev(){
        return $this->totalIev;
    }

    public function setTP($totalActPremium){
        $this->totalActPremium=round($totalActPremium);
    }

    public function setOD($totalOdPremium){
         $this->totalOdPremium=round($totalOdPremium);
    }

    public function setNCBDiscount($ncbAmt){
         $this->ncbAmt=round(abs($ncbAmt));
    }

    public function setServiceTax($serviceTax){
         $this->serviceTax=round($serviceTax);
    }

    public function setNetPremium($netPremium){
         $this->netPremium=round($netPremium);
    }

    public function setFinalPremium($finalPremium){
         $this->finalPremium=round($finalPremium);
    }

    public function getTP(){
    	return $this->totalActPremium;
    }
    
    public function getOD(){
    	return $this->totalOdPremium;
    }

    public function getNCBDiscount(){
    	return $this->ncbAmt;
    }

    public function getServiceTax() {
        return $this->serviceTax;
    }

    public function getNetPremium() {
        return $this->netPremium;
    }

    public function getFinalPremium() {
        return $this->finalPremium;
    }
} 

Class PremiumSumm{
	public $WeoMotPremiumSummaryUser = NULL;
	public $od = NULL;
	public $pa = NULL;
	public $papass = NULL;
	public $tp = NULL;
	public $ll = NULL;
	public $ncb = NULL;

	public function __construct($k) {
        foreach ($k as $key => $value) {
            $this->$key = $value;
        }

        if(isset($this->WeoMotPremiumSummaryUser) && is_array($this->WeoMotPremiumSummaryUser))
        	$this->genrateSummaryDetails();
    }

	public function genrateSummaryDetails(){
		foreach ($this->WeoMotPremiumSummaryUser as $key => $value)
			$this->set_param($value);
	}

	public function set_param($value){
		switch ($value->paramRef) {
			case 'OD':
				$this->od = round($value->od);
				break;
			case 'ACT':
				$this->tp = round($value->act);
				break;
			case 'PA_DFT':
				$this->pa = round($value->act);
				break;
			case 'PA':
				$this->papass = round($value->act);
				break;
			case 'LLO':
				$this->ll = round($value->act);
				break;
			case 'NCB':
				$this->ncb = round($value->od);
				break;
			default:
				break;
		}
	}

	public function getOD(){
		return $this->od;
	}

	public function getTP(){
		return $this->tp;
	}

	public function getPA(){
		return $this->pa;
	}

	public function getPAPASS(){
		return $this->papass;
	}

	public function getNCB(){
		return $this->ncb;
	}

	public function getLL(){
		return $this->ll;
	}
}

Class Error {
    public function __construct($k) {
        foreach ($k as $key => $value) {
            $this->$key = $value;
        }
    }
}
