<?php
namespace App\Helpers\Car;
use App\Constants\Car_Constants;
use App\Models as M;
use App\Models\Car;
use App\Models\Car\CarTData;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers as C;
use App\Libraries\InstaLib;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;
use App\Models\Car\CarProducts;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;

class CarHelper {

	private function trigger_event($tarns_status,$trans_code){
		$events =  ["TS14"=>"PROPOSALSUBMIT",
					"TS20"=>"PROPOSALSUBMIT",
					"TS01"=>"PROPOSALERROR",
					"TS17"=>"PAYMENTSUCESS",
					"TS02"=>"PAYMENTFAIL",
					"TS19"=>"POLICYSUCCESS",
					"TS03"=>"POLICYFAIL"];
		
		if(array_key_exists($tarns_status,$events)){
			$email_engine =  new EmailEngine;
			$email_engine->send_email($trans_code);
		}					
	}

	public function getTotalODPremium($user_data) {
        $od_premium = $user_data->od_premium;
        $ea_premium = 0;
        $nea_premium = 0;
        $anti_theft_discount = 0;
        $auto_ass_discount = 0;
        $voluntary_discount = 0;
        $ncb_discount = $user_data->ncb_discount;
        $od_discount = $user_data->od_discount;
        //addons
        $zerodep = $this->addon['zerodep'];
        $rti = $this->addon['rti'];
        $rsac = $this->addon['rsac'];
        $ep = $this->addon['ep'];
        $addons = $zerodep+$rti+$ep+$rsac;

        return round((($addons+$od_premium + $ea_premium + $nea_premium
                ) - ($ncb_discount + $anti_theft_discount + $auto_ass_discount + $voluntary_discount + $od_discount)
                ),0);
    }

    public function getTotalTPPremium($user_data){
        $tp_premium = $user_data->tp_premium;
        $bi_fuel_kit_tp_premium = 0;
        $PAOD_premium = 100;
        $driver_cover_premium = 50;
        $pa_cover_premium = $this->addon['papass'];
        return round(($tp_premium + $bi_fuel_kit_tp_premium + $PAOD_premium + $driver_cover_premium + $pa_cover_premium),0);
    }

    public function setAddonsPremium($user_data){
    	$addons = explode(",",$user_data->covers_selected);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        
        $this->addon = ['zerodep'=>0,
    			'rti'=>0,
    			'rsac'=>0,
    			'papass'=>0,
    			'ep'=>0];

        $addons_premium = [];

        if(isset($user_data->addon_premium))
        	$addons_premium = json_decode($user_data->addon_premium);

        foreach ($addons_premium as $key => $value) {
        	$this->addon[$key] = $value;
        }
    }

	// policy counter
	public function hitPolicyCounter($usr_data){
		try{
			$plocy_nature = (strtolower($usr_data->type_of_business) == 'rollover') ? 'Rollover' : "New";
			// set addon premium to get addon OD and TP Premium
			$this->setAddonsPremium($usr_data);
			$od_premium = $this->getTotalODPremium($usr_data);
			$tp_premium = $this->getTotalTPPremium($usr_data);
			$netPremium = $usr_data->netPremium;
			$final_premium = (isset($usr_data->final_premium)) ? $usr_data->final_premium
								: $usr_data->totalpremium;

			$request_array = array(
					"module_name"=> "PC",
					"insurer_code"=> $usr_data->insurer_id,
					"agent_code"=> !empty($usr_data->agent_code)?$usr_data->agent_code:null,
					"policy_date"=> $usr_data->policy_date,
					"policy_type"=> $usr_data->prev_policy_type,
					"policy_nature"=> $plocy_nature,
					"policy_number"=> $usr_data->policy_nu,
					"od_premium"=> $od_premium,
					"tp_premium"=> $tp_premium,
					"total_premium"=> $netPremium,
					"tax"=> $usr_data->tax,
					"final_premium"=> $final_premium
					);
			$policy_counter = new PolicyCounterService;
			$result = $policy_counter->service_handler($request_array);
			Log::info($usr_data->trans_code.' Policy Counter Status : '.$result);
		}catch(\Exception $e){
			return 0;
		}
		return 1;
	}
	

	// status function 
	public function log_quote_status($trans_code,$status,$msg = NULL){
		$car_t_data = CarTData::find($trans_code);
		$InstaLib = new InstaLib();
		$current_date = $InstaLib->today_date_dMY();
		unset($InstaLib);
		$status_code = NULL;
		switch($status){
			case 'create_quote':
				 $car_t_data->quote_create_date = $current_date;
				 $status_code = 'TS10'; 
				 break;
			case 'update_quote':
				 $car_t_data->quote_update_date = $current_date;
				 $status_code = 'TS11'; 
				 break;
			case 'buy_quote':
				 $car_t_data->quote_update_date = $current_date;
				 $status_code = 'TS12'; 
				 break;	 	 
			default: $status_code = NULL;
		}
		$car_t_data->quote_status = $status_code;
		$car_t_data->t_status = $status_code;
		$car_t_data->save();
		return $car_t_data;
	}

	public function update_proposal_status($trans_code,$status,$response = NULL){
		$car_t_data = CarTData::find($trans_code);
		$InstaLib = new InstaLib();
		$car_t_data->proposal_date = $InstaLib->today_date_dMY();
		unset($InstaLib);
		$status_code = NULL;
		switch($status){
			case 'proposal_load': $status_code = 'TS13'; break;
			case 'proposal_submit': $status_code = 'TS14'; break;
			case 'proposal_submit_new_premium': $status_code = 'TS20'; break;
			case 'proposal_accepted':
				$status_code = 'TS15';
				if($car_t_data->proposal_status == 'TS20')
					$status_code = 'TS21';
				$car_t_data->proposal_ref_number = (isset($response['ref_no'])) ? $response['ref_no'] : NULL;
				break;
			case 'proposal_error': $status_code = 'TS01';
				$car_t_data->proposal_ref_number = (isset($response['ref_no'])) ? $response['ref_no'] : NULL;
				$car_t_data->proposal_desc = (isset($response['msg'])) ? $response['msg'] : NULL;
				 break;
			default: $status_code = NULL;
		}
		$car_t_data->proposal_status = $status_code;
		$car_t_data->t_status = $status_code;
		$car_t_data->save();
		$this->trigger_event($car_t_data->t_status,$trans_code);
		return $car_t_data;
	}

	public function log_payment_status($trans_code,$status,$response=NULL){
		$car_t_data = CarTData::find($trans_code);
		$InstaLib = new InstaLib();
		$car_t_data->payment_date = $InstaLib->today_date_dMY();
		unset($InstaLib);
		$status_code = NULL;
		switch($status){
			case 'payment_request': $status_code = 'TS16'; break;
			case 'payment_success': $status_code = 'TS17';
					$car_t_data->payment_ref_number = (isset($response['ref_no'])) ? $response['ref_no'] : NULL;
					break;
			case 'payment_error': $status_code = 'TS02'; 
					$car_t_data->payment_ref_number = (isset($response['ref_no'])) ? $response['ref_no'] : NULL;
					$car_t_data->payment_desc = (isset($response['msg'])) ? $response['msg'] : NULL;
					break;
			default: $status_code = NULL;
		}
		$car_t_data->payment_status = $status_code;
		$car_t_data->t_status = $status_code;

		$car_t_data->save();
		$this->trigger_event($car_t_data->t_status,$trans_code);
		return $car_t_data;
	}

	public function log_policy_status($trans_code,$status,$response=NULL){
		$car_t_data = CarTData::find($trans_code);
		$InstaLib = new InstaLib();
		$car_t_data->policy_date = $InstaLib->today_date_dMY();
		unset($InstaLib);
		$status_code = NULL;
		switch($status){
			case 'policy_request': $status_code = 'TS18'; break;
			case 'policy_success': $status_code = 'TS19'; 
				  $this->hitPolicyCounter($car_t_data);
				  break;
			case 'policy_error': $status_code = 'TS03'; 
					$car_t_data->policy_desc = (isset($response['msg'])) ? $response['msg'] : NULL;
					break;
			default: $status_code = NULL;
		}
		$car_t_data->policy_status = $status_code;
		$car_t_data->t_status = $status_code;
		$car_t_data->save();
		$this->trigger_event($car_t_data->t_status,$trans_code);
		return $car_t_data;
	}

	public function log_policy_result($trans_code,$status,$response=NULL){
		if(!$trans_code)
			return 0;

		if($status)
			return $this->log_policy_status($trans_code,'policy_success',$response);

		return $this->log_policy_status($trans_code,'policy_error',$response);
	}

	public function log_payment_result($trans_code,$status,$response=NULL){
		if(!$trans_code)
			return 0;

		if($status)
			return $this->log_payment_status($trans_code,'payment_success',$response);

		return $this->log_payment_status($trans_code,'payment_error',$response);
	}

	public $auth = array('accesskey' => 'TTIBI', 'secretkey' => 'TTIBI');

	public function getCarBasicDetails($user_data){
		$field = $this->getQuoteFieldMap();
        return (!$user_data) ? [] : $this->getFieldData($user_data, $field);
	}

	public function getPremiumBreakup($usar_data,$pb_data,$format = NULL){
		$car_product = new  CarProducts();
		$pb = new PremiumBreakup;
		$pb->setPbDatat($pb_data);
		  if($usar_data->insurer_id == "reliance")
		     $pb->setRsacValue(0);


		$car_product = $car_product->getCompDetails($usar_data->product_id);
		if($car_product)
			$cmp_name  =  $car_product->product_name;
		else
			$cmp_name  = "GI";
		
		if(!isset($format))
			$format = Car_Constants::PB_FORMAT;
       
        return ['totalpremium' => $pb->getTotalpremiumValue()
            , 'insurer_id' => $usar_data->insurer_id
            , 'product_id' => $usar_data->product_id
            , 'idv_received' => $usar_data->idv_opted
            , 'netPremium' => $pb->getNetPremiumValue()
            , 'insurerName' => $cmp_name
            , 'serviceTax' => $pb->getServiceTaxValue()
            , 'premiumBreakup' => $pb->genratePremiumBreakup($format)];
    }

	public function parse_curl_data($http_config,$postFields){
		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$fields = http_build_query($postFields);
		else if(isset($http_config['post-type']) && $http_config['post-type'] == 'xml')
			$fields = $postFields;
		else
			$fields = json_encode($postFields);
		return $fields;
	}

	public function get_content_type($http_config){
		if(isset($http_config['content-type']))
			$contentType = "content-type: ".$http_config['content-type'];
		else 
			$contentType = "content-type: application/json";
		return $contentType;
	}

	public function call_hdfc_curl_api($title,$url, $postFields ,$http_config = null,$trans_code = null){
		if(is_array($postFields))
			Log::info('CAR '.$title.' Request - '.$trans_code.' - ', $postFields);
		else
			Log::info('CAR '.$title.' Request - '.$trans_code.' - '.$postFields);

		$curl = curl_init();

		$contentType = $this->get_content_type($http_config);
		$fields = $this->parse_curl_data($http_config,$postFields);
		
		curl_setopt_array($curl, array(
			// CURLOPT_PORT => "91",
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $fields,
			CURLOPT_HTTPHEADER => array($contentType),
		));
		$response = array();
		$data = curl_exec($curl);
		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$response['data'] = $data;
		else 
			$response['data'] = json_decode($data, true);
		
		if(is_array($response))
			Log::info('CAR '.$title.' Response - '.$trans_code.' - ',$response);
		else 
			Log::info('CAR '.$title.' Response - '.$trans_code.' - '.$response);

		if (empty($response['data'])) {
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}

		curl_close($curl);
		return $response;
	}

	public function call_curl_api($title,$url, $postFields ,$http_config = null,$trans_code = null){
		if(is_array($postFields))
			Log::info('CAR '.$title.' Request - '.$trans_code.' - ', $postFields);
		else
			Log::info('CAR '.$title.' Request - '.$trans_code.' - '.$postFields);

		$curl = curl_init();

		$contentType = $this->get_content_type($http_config);
		$fields = $this->parse_curl_data($http_config,$postFields);
		
		curl_setopt_array($curl, array(
		//	CURLOPT_PORT => "91",
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $fields,
			CURLOPT_HTTPHEADER => array($contentType),
		));
		$response = array();
		$data = curl_exec($curl);

		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$response['data'] = $data;
		else 
			$response['data'] = json_decode($data, true);
		
		if(is_array($response))
			Log::info('CAR '.$title.' Response - '.$trans_code.' - ',$response);
		else 
			Log::info('CAR '.$title.' Response - '.$trans_code.' - '.$response);

		if (empty($response['data'])) {
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}

		curl_close($curl);
		return $response;
	}

	public function callApi($url, $postFields ,$http_config = null,$trans_code = null) {
		return $this->call_curl_api('Last Decimal Proposal',$url, $postFields ,$http_config,$trans_code);
	}

	/* it's not used any more.used when required data from master */
	public function callGenericMaster($productId, $MasterId) {
		$url = "http://api.brokeredge.in/rest/master/codes/" . $productId . "/" . $MasterId;
		$postFields = array('authentication' => $this->$auth);
		return $this->callApi($url, $postFields);
	}

	/* it's not used any more.used when required data from master */
	public function callCity($insurerId, $stateId) {
		$url = "http://api.brokeredge.in/rest/master/city/" . $insurerId . "/" . $stateId;
		$postFields = array('authentication' => $this->$auth);
		return $this->callApi($url, $postFields);
	}

	// helper function for policy

	public function getFieldData($user_data, $fields) {
		$data_mapper = $this->getMysqlMap($fields);
		$data = [];
		foreach ($data_mapper as $key => $value) {
			if (is_array($value)) {
				foreach ($value as $v_key => $v_value) {
					$data[$v_key] = $user_data[$v_value];
				}
			} else {
				$data[$key] = $user_data[$value];
			}

		}
		return $data;
	}

	public function getMysqlMap($fields) {
		$is_muliarray = 1;
		foreach ($fields as $key => $value) {
			if (is_array($value)) {
				$fields[$key] = array_flip($value);
			} else {
				$is_muliarray = 0;
				break;
			}
		}
		return (!$is_muliarray) ? array_flip($fields) : $fields;
	}
	public function getDbFormatDate($date) {
		return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
	}
	public function getFormDate($date) {
		return date('d/m/Y', strtotime(str_replace('-', '/', $date)));
	}
	

	public function checkQuoteExists($session_id) {
		$filename = Car_Constants::getQuoteFileName($session_id);
		$exists = Storage::disk('local')->exists(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename);
		if ($exists) {
			return true;
		} else {
			return false;
		}
	}

	public function getSuid() {
		return session('pc_suid');
		// $insta = new InstaLib();
		// if(session()->has('pc_suid')){
		// 	$suid = session('pc_suid');
		// } else {
		// 	$suid = $insta->get_pc_tc();//session()->getId();
		// 	self::setSuid($suid);
		// }
		// return $suid;
	}

	public function setSuid($suid) {
		session(['pc_suid' => $suid]);
		\Session::put('pc_suid', $suid);
		\Session::save();
	}

	public function suidExit(){
		return (session()->has('pc_suid')) ? true : false;
	}

	public function checkTransaction($transaction_code) {
		$car_t_data = new CarTData;
		$transaction = $car_t_data->checkTransaction($transaction_code);
		if ($transaction !== null) {
			if ($transaction->t_status && $transaction->t_status == 'TS19') {
				return 1;
			}
		}
		return 0;
	}

	public function getMasterData($for, $master) {
		$master_path = '\App\Models\Car\Master'.$master;
		$model = new  $master_path;
		return $result = $model->{'get' . $master}($for);
	}

	public function getMasterId($for, $master , $code) {
		$master_path = 'App\Models\Car\Master' . $master;
		$model = new $master_path;
		return $result = $model->{'get' . $master.'Id'}($for,$code);
	}

	public function getMasterName( $master , $code) {
		$master_path = 'App\Models\Car\Master' . $master;
		$model = new $master_path;
		return $result = $model->{'get' . $master.'Name'}($code);
	}

	public function getMasterCity($for, $master, $state_code) {
		$master_path = 'App\Models\Car\Master' . $master;
		$model = new $master_path;
		return $result = $model->{'get' . $master}($for, $state_code);
	}

	public function getMasterCityByPolicyCode($for, $policy_code) {
		$master_state = new \App\Models\Car\MasterState;
		return $master_state->getCity($for, $policy_code);
	}


	public function storeUserLoginId(){
		$suid = $this->getSuid();
		$table['user_id'] = !empty(session('user_id')) ? session('user_id') : NULL;
		try {
			$car_transaction = CarTData::updateOrCreate(array('session_id' => $suid), $table);
		} catch (Exception $e) {
			echo $e->getMessage();
			die;
		}
	}

	public function storeIp($request){
		if($request->ip() != ""){
			$table['client_ip'] = $request->ip();
			$table['trans_code'] = $request->trans_code;
			$t = CarTData::updateOrCreate(array('trans_code' => $table['trans_code']), $table);	
		}
	}

	public function storeOptedIDV($request){
		if($request->idv_opted)
	        	$table['idv_opted'] = $request->idv_opted;
		$table['trans_code'] = $request->trans_code;
        	$t = CarTData::where('trans_code',$table['trans_code'])->update($table);
	}
	
	public function grabDetails($fileds,$proposal_data){
		foreach ($fileds as $key => $value) {
			if(is_array($value)){
				foreach ($value as $value_key => $value_value) {
					$data[] = $proposal_data[$value_value];	
				}
				$proposer_request[$key] = implode(",",$data);
				unset($data);
			}else{
				if(isset($proposal_data[$value]))
					$proposer_request[$key] = $proposal_data[$value];
			}
		}
		return $proposer_request;
	}

	public function getMilitime(){
		return round(microtime(true) * 1000);
	}

	public function genrateXml($root,$fields){
		$xml = new \SimpleXMLElement($root);
		$this->addChild($xml,$fields);
		return $xml;
	}

	public function addChild($xml,$fields){
		$fn = function($value,$key) use ($xml){
			 if(is_array($value)){
			 	if($key == 'attribute'){
			 		foreach ($value as $key2 => $value2) {
			 			$xml->addAttribute($key2,$value2);
			 		}
			 	}else{
			 		$sxml = $xml->addChild($key);
			 		$this->addChild($sxml,$value);
			 	}
			 }else {
		 		$xml->addChild($key,$value);
		 	}
		};
		array_walk($fields,$fn);
		return $xml;
	}

	public function getUserCode(){
		$user_code = !empty(session('user_code')) ? session('user_code') : NULL;
		return 	$user_code;
	}

	public  function getODTPPremium($user_data){            
		$new_ncb = ($user_data->od_premium*$user_data->new_ncb)/100;            
		$od_premium = $user_data->od_premium - $new_ncb;            
		$tp_premium = $user_data->tp_premium;            
		$od_addon = ['zerodep','ep','ncbprotect','rsac','rti'];            
		$tp_addon = ['pa','ll','papass'];        
		
		if(isset($user_data->addon_premium) && $user_data->addon_premium != ''){
			$addon = json_decode($user_data->addon_premium);               
				foreach($addon as $key => $value){                    
				 	if(in_array($key,$od_addon))                        
				 		$od_premium = $od_premium+$addon->$key;             
				 	if(in_array($key,$tp_addon))                        
				 		$tp_premium = $tp_premium+$addon->$key;                
			}            
		}            
		return ['od_premium'=>round($od_premium,0),'tp_premium'=>round($tp_premium,0)];        
	}

	public function db_to_pb_data($pb_data,$user_data){
		if($user_data)
			$user_data = $user_data->toArray();
		else 
			return false;

		$pb_data->setAttributesUsingDb($user_data);
		return $pb_data;
	}

	public function pb_to_pb_data($pb_data,$data){
		$pb_data->setAttributes($data);
		return $pb_data;
	}	

	public function getQuoteValue($trans_code){
		$pb_data = new PremiumBreakupData();
		$user_data = CarTData::find($trans_code);
		$data = $this->db_to_pb_data($pb_data,$user_data);
		unset($pb_data);
		unset($user_data);
		return $data;
	}

	public function storeQuoteValue($data){
		$pb_data = new PremiumBreakupData();
		$pb_data = $this->pb_to_pb_data($pb_data,$data['pb']);

		$table = [];

		if(isset($data['product_id']))
     		$table['product_id'] = $data['product_id'];

     	if(isset($data['insurer_id']))
     		$table['insurer_id'] = $data['insurer_id'];

     	if(isset($data['idv_opted']))
	        	$table['idv_opted'] = $data['idv_opted'];

	    if(isset($data['quote_id']))
	        	$table['quote_id'] = $data['quote_id'];

     	$table['totalpremium'] = $pb_data->getTotalPremium();
        $table['od_premium'] = $pb_data->getOdPremium();
        $table['tp_premium'] = $pb_data->getTpPremium();
        $table['od_discount'] = $pb_data->getOdDiscount();
        $table['ncb_discount'] = $pb_data->getNcbDiscount();
        $table['tax'] = $pb_data->getServiceTax();
        
        $table['return_quote_url'] = $data['return_quote_url'];
        $table['netPremium'] = $data['netPremium'];

        $addon = $pb_data->getAddons();

        if(!empty($addon))
            $table['addon_premium'] = json_encode($addon);
        
		if(CarTData::updateOrCreate(array('trans_code' => $data['trans_code']), $table))
			return $pb_data;
	}

	// DATE FUNCTION
	public function manDate($date,$format=null,$man=null){
		$date = str_replace('/','-',$date);

		if(isset($man))
			$date = $this->manipulateDate($date,$man);
		
		if(isset($format))
			$date = $this->changeFormat($date,$format);


		return $date;
	}

	public function changeFormat($date,$format){
		$date = str_replace('/','-',$date);
		$date = strtotime($date);
		return date($format,$date);
	}

	public function manipulateDate($date,$man){
		if(is_array($man)){
			foreach ($man as $key => $value) {
				$man_date = strtotime($date);
				$date = date('Y-m-d',strtotime($value,$man_date));
			}
		}else{
			$date = strtotime($date);
			$date = date('Y-m-d',strtotime($man,$date));
		}
		return $date;
	}

	public function getAgeInMonth($date_x,$date_y){
		$date_x = new \DateTime($date_x);
		$date_y = new \DateTime($date_y);
		$diff = $date_y->diff($date_x);
		return $diff->y.'.'.$diff->m;
	}

	public function getAgentFromQuoteId(){
		$car_t_data = new CarTData;
		$car_helper = new CarHelper;
		$trans_code = $car_helper->getsuid();
		$agent_data = $car_t_data->getTransRowData($trans_code);

		if (empty($agent_data['agent_code'])) {
			return 'NA';
		}
		$agent_code = $agent_data['agent_code'];
		return $this->getUserNameFromCode($agent_code);
	}

	public function getAgentEmailQuoteId(){
		$car_t_data = new CarTData;
		$car_helper = new CarHelper;
		$trans_code = $car_helper->getsuid();
		$agent_data = $car_t_data->getTransRowData($trans_code);

		if (empty($agent_data['agent_code'])) {
			return 'NA';
		}
		$agent_code = $agent_data['agent_code'];
		return $this->getUserEmailFromCode($agent_code);
	}

	public function getUserNameFromCode($user_code){
		$insta_user = new M \ InstaUser;
		$agent_name = $insta_user->getUserName($user_code);
		return $agent_name;
	}

	private static function getUserEmailFromCode($user_code){
		$insta_user = new M \ InstaUser;
		$agent_name = $insta_user->getEmail($user_code);
		return $agent_name;
	}

	// get comapnay name 
	public function getInsuranceCompanyName($product_id) {
		$products =  CarProducts::where('product_id',$product_id)->first();
		if($products)
			return $products->product_name;
	}

	public function getQuoteFieldMap($map_for = null) {
		$fields = [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
			Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_TYPE'] => 'policy_type_selection',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
                        Car_Constants::CAR_T_QUOTELOG['OPTED_IDV'] => 'idv_opted',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
			Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_ID'] => 'quote_id',
			Car_Constants::CAR_T_QUOTELOG['EXP_STATUS']	 => 'expiry_status',
            Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_TYPE']=>'policy_type_selection',
            Car_Constants::CAR_T_QUOTELOG['QUOTE_OD_START_DATE']=>'od_start_date',
            Car_Constants::CAR_T_QUOTELOG['QUOTE_OD_END_DATE']=>'od_end_date',
            Car_Constants::CAR_T_QUOTELOG['QUOTE_TP_START_DATE']=>'tp_start_date',
            Car_Constants::CAR_T_QUOTELOG['QUOTE_TP_END_DATE']=>'tp_end_date'
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}


	// xml to array
	public function xmlToarray($data,$response){
		$fn = function($value) use ($response){
			if(is_object($value)){
				$resp = (array)$value;
				return $this->xmlToarray($resp,$response);
			}
			$a = @simplexml_load_string($value);
			if($a === FALSE){
				return $value;
			}else{
				$resp = (array)$a;
				return $this->xmlToarray($resp,$response);
			}
		};
		if(is_object($data)){
			$data = (array)$data;
		} else if(is_string($data)) {
			$data = str_replace('ns2:','',$data);
			$data = str_replace('ns3:','',$data);
			$data = str_replace('ns7:','',$data);
			$data = str_replace('soap:','',$data);
			$a = @simplexml_load_string($data);
			return $this->xmlToarray($a,$response);
		}
		return array_map($fn,$data);;
	}

	public function getFieldName($type, $mapper_name) {
		$field = $this->getFieldMap();
		if (isset($field) && !empty($field)) {
			return $field[$type][Car_Constants::CAR_T_USERLOG[$mapper_name]];
		}
	}

	public function getFieldMap($map_for = null) {
		$fields = ['PROPOSER' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['USR_GENDER'] => 'gender',
				Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'covers_selected',
				Car_Constants::CAR_T_USERLOG['USR_TYPE'] => 'type',
				Car_Constants::CAR_T_USERLOG['USR_DOB'] => "cust_dob",
				Car_Constants::CAR_T_USERLOG['USR_FIRSTNAME'] => "firstname",
				Car_Constants::CAR_T_USERLOG['USR_LASTNAME'] => "lastname",
				Car_Constants::CAR_T_USERLOG['USR_EMAIL'] => "email",
				Car_Constants::CAR_T_USERLOG['USR_MOBILE'] => "mobile",
				Car_Constants::CAR_T_USERLOG['USR_TITLE'] => "title",
				Car_Constants::CAR_T_USERLOG['OCCUPATION'] => "occupation",
				Car_Constants::CAR_T_USERLOG['USR_PAN'] => "pan",
				Car_Constants::CAR_T_USERLOG['USR_COMPANYNAME'] => "companyname",
				Car_Constants::CAR_T_USERLOG['USR_CONTACTPERSON'] => "contactperson",
				Car_Constants::CAR_T_USERLOG['CMP_PAID_UP'] => 'cmp_paid_up',
				Car_Constants::CAR_T_USERLOG['USR_AADHARNO'] => "aadharno",
				Car_Constants::CAR_T_USERLOG['USR_MARITALSTATUS'] => "martitalStatus",
				Car_Constants::CAR_T_USERLOG['GSTIN'] => "gstin",
				Car_Constants::CAR_T_USERLOG['QUOTE_ID'] => "quote_id"
			],
			'COMMUNICATION' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['HOUSENO'] => 'houseno',
				Car_Constants::CAR_T_USERLOG['STREET'] => "street",
				Car_Constants::CAR_T_USERLOG['LOCALITY'] => "locality",
				Car_Constants::CAR_T_USERLOG['PINCODE'] => "pincode",
				Car_Constants::CAR_T_USERLOG['USR_STATE_CODE'] => "statecode",
				Car_Constants::CAR_T_USERLOG['USR_CITY_CODE'] => "citycode",
				Car_Constants::CAR_T_USERLOG['PERM_HOUSENO'] => 'perm_houseno',
				Car_Constants::CAR_T_USERLOG['PERM_STREET'] => "perm_street",
				Car_Constants::CAR_T_USERLOG['PERM_LOCALITY'] => "perm_locality",
				Car_Constants::CAR_T_USERLOG['PERM_PINCODE'] => "perm_pincode",
				Car_Constants::CAR_T_USERLOG['PERM_USR_STATE_CODE'] => "perm_statecode",
				Car_Constants::CAR_T_USERLOG['PERM_USR_CITY_CODE'] => "perm_citycode",
				Car_Constants::CAR_T_USERLOG['REG_ADD_IS_SAME'] => 'reg_add_is_same',

			],
			'VEHICLE' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['CHASSISNO'] => 'chassisno',
				Car_Constants::CAR_T_USERLOG['ELECTRICAL'] => 'electrical',
				Car_Constants::CAR_T_USERLOG['ELECTRICAL_DATE'] => 'electrical_year',
				Car_Constants::CAR_T_USERLOG['ENGNO'] => 'engno',
				Car_Constants::CAR_T_USERLOG['NON_ELECTRICAL'] => 'non_electrical',
				Car_Constants::CAR_T_USERLOG['NON_ELECTRICAL_DATE'] => 'non_electrical_year',
				Car_Constants::CAR_T_USERLOG['REGNO'] => 'regno',
				Car_Constants::CAR_T_USERLOG['YOM'] => 'yom_selected',
				Car_Constants::CAR_T_USERLOG['COLOR'] => 'color',
				Car_Constants::CAR_T_USERLOG['BODYTYPE'] => 'bodyType',
				Car_Constants::CAR_T_USERLOG['EXTERNAL_CNG'] => 'external_cng_fitted',
				Car_Constants::CAR_T_USERLOG['EXTERNAL_CNG_VALUE'] => 'e_cng_value',
				Car_Constants::CAR_T_USERLOG['VEH_VEHICLE_FINANCED']=>'vehicle_financed',
				Car_Constants::CAR_T_USERLOG['VEH_VEHICLE_TYPE_OF_FINANCED']=>'type_of_finance',
				Car_Constants::CAR_T_USERLOG['VEH_FINANCIER_NAME']=>'financierName',
				Car_Constants::CAR_T_USERLOG['VEH_FINANCIER_ADDR']=>'financierAddress',
				Car_Constants::CAR_T_USERLOG['isCarOwnershipChanged']=>'ownership_change',
				Car_Constants::CAR_T_USERLOG['veh_voluntary_deductible']=>'vd',
				Car_Constants::CAR_T_USERLOG['GARAGETYPE'] => 'garageType',
			],
			"PREVIOUSINSURER" => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['POLICYNO'] => 'policyno',
				Car_Constants::CAR_T_USERLOG['PREVINSURANCE'] => 'previnsurance',
				Car_Constants::CAR_T_USERLOG['PREVIOUSPOLICYTYPE'] => 'previousPolicyType',
				Car_Constants::CAR_T_USERLOG['PREVIOUSADDONS'] => 'prev_addons',
				Car_Constants::CAR_T_USERLOG['NOMINEENAME'] => 'nomineeName',
				Car_Constants::CAR_T_USERLOG['NOMINEEREL'] => 'nomineeRel',
				Car_Constants::CAR_T_USERLOG['NOMINEEAGE'] => "nomineeAge",
				Car_Constants::CAR_T_USERLOG['PREVCLAIM'] => 'claim',
				Car_Constants::CAR_T_USERLOG['CLAIM_AMOUNT_RECEIVED']=>'claimAmountReceived',
				Car_Constants::CAR_T_USERLOG['PREVINSURANCE_ADDR']=>'previnsurance_addr',
				Car_Constants::CAR_T_USERLOG['IS_ZERODEP_PREV'] => 'prevzerodep'
			],
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	public static function getDbData($session_id) {
		$car_helper = new CarHelper;
		$field = $car_helper->getFieldMap();
		$user_data = CarTData::find($session_id);
		return (!$user_data) ? [] : CarHelper::getFieldData($user_data,$field);
	}

	public static function getDbDataByField($user_data) {
		$field = CarHelper::getFieldMap();
		return (!$user_data) ? [] : CarHelper::getFieldData($user_data,$field);
	}

	public function insr_variant($column_name, $variant_code, $null_check = false){
		
		$variant_db = new M\Car\CarVariant();
		$ret_value = "";
		$variant_data = $variant_db->get_car_details($variant_code);
		$ret_value =  $variant_data['make_name'].' '.$variant_data['model_name'].' '.$variant_data['variant_name'];

		return $ret_value;
	} //end

}

?>
