<?php
namespace App\Helpers\Car;
use App\Constants\Car_Constants;
use App\Models as M;
use App\Models\Car;
use App\Models\Car\CarTData;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers as C;

class CarHelper {
	public static $auth = array('accesskey' => 'TTIBI', 'secretkey' => 'TTIBI');

	public static function callApi($url, $postFields ,$http_config = null) {

		if(is_array($postFields))
			Log::info('CAR - Last Decimal - Proposal Request.', $postFields);
		else
			Log::info('CAR - Last Decimal - Proposal Request. '.$postFields);

		$curl = curl_init();
		
		if(isset($http_config['content-type']))
			$contentType = "content-type: ".$http_config['content-type'];
		else 
			$contentType = "content-type: application/json";

		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$fields = http_build_query($postFields);
		else 
			$fields = json_encode($postFields);
		
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $fields,
			CURLOPT_HTTPHEADER => array($contentType),
		));
		$response = array();
		$data = curl_exec($curl);

		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$response['data'] = $data;
		else 
			$response['data'] = json_decode($data, true);
		
		if(is_array($response))
			Log::info('CAR - Last Decimal - Proposal Response..', $response);
		else 
			Log::info('CAR - Last Decimal - Proposal Response..'.$response);

		if (empty($response['data'])) {
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}
		curl_close($curl);
		return $response;
	}

	/* it's not used any more.used when required data from master */
	public static function callGenericMaster($productId, $MasterId) {
		$url = "http://api.brokeredge.in/rest/master/codes/" . $productId . "/" . $MasterId;
		$postFields = array('authentication' => self::$auth);
		return self::callApi($url, $postFields);
	}

	/* it's not used any more.used when required data from master */
	public static function callCity($insurerId, $stateId) {
		$url = "http://api.brokeredge.in/rest/master/city/" . $insurerId . "/" . $stateId;
		$postFields = array('authentication' => self::$auth);
		return self::callApi($url, $postFields);
	}

	// helper function for policy

	public static function getFieldData($user_data, $fields) {
		$data_mapper = self::getMysqlMap($fields);
		$data = [];
		foreach ($data_mapper as $key => $value) {
			if (is_array($value)) {
				foreach ($value as $v_key => $v_value) {
					$data[$v_key] = $user_data[$v_value];
				}
			} else {
				$data[$key] = $user_data[$value];
			}

		}
		return $data;
	}

	public static function getMysqlMap($fields) {
		$is_muliarray = 1;
		foreach ($fields as $key => $value) {
			if (is_array($value)) {
				$fields[$key] = array_flip($value);
			} else {
				$is_muliarray = 0;
				break;
			}
		}
		return (!$is_muliarray) ? array_flip($fields) : $fields;
	}
	public static function getDbFormatDate($date) {
		return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
	}
	public static function getFormDate($date) {
		return date('d/m/Y', strtotime(str_replace('-', '/', $date)));
	}
	public static function addDataToFile($filename, $data) {
		$exists = Storage::disk('local')->exists(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename);
		if ($exists) {
			$data_fetch = json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename), true);
			foreach ($data as $key => $value) {
				$data_fetch[$key] = $value;
			}
			Storage::disk('local')->put(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename, json_encode($data_fetch));
		} else {

			Storage::disk('local')->put(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
		}
	}
	
	// add data into file [@parth chavda]
	public static function addFileData($array){
		$session_id = self::getSuid();
		self::addDataToFile(Car_Constants::getQuoteFileName($session_id),$array);
	}

	// retrive data into file [@parth chavda]
	public static function retFileData($key = null){
		$data = null;
		try{
			$session_id = self::getSuid();
			if(isset($key))
				$data =  CarHelper::getSessionValue($session_id)[$key];
			else 
				$data = CarHelper::getSessionValue($session_id);	
		}catch(\Exception $e){
			
		}finally{
			return $data;
		}
	}

	public static function getReturnDataSessionValue($session_id) {
		$return_value = json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true);
		return isset($return_value['return_data'])?$return_value['return_data']:[];
	}

	public static function getDetailsDelectedSessionValue($session_id) {

		$details_selected = array_key_exists('details_selected', json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true)) ? json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true)['details_selected'] : "";
		return $details_selected;
	}

	public static function getCarDetailsSessionValue($session_id) {
		return json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true)['car_details'];
	}

	public static function getSessionValue($session_id) {
		return json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true);
	}

	public static function getSelectedCoversSessionValue($session_id) {
		return json_decode(Storage::get(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . Car_Constants::getQuoteFileName($session_id)), true)['covers_selected'];
	}

	public static function checkQuoteExists($session_id) {
		$filename = Car_Constants::getQuoteFileName($session_id);
		$exists = Storage::disk('local')->exists(Car_Constants::CAR_QUOTE_FILE_PATH . '/' . $filename);
		if ($exists) {
			return true;
		} else {
			return false;
		}
	}

	public static function getSuid() {
		return (session()->has('pc_suid')) ? session('pc_suid') : session()->getId();
	}

	public static function setSuid($suid) {
		session(['pc_suid' => $suid]);
	}

	public static function suidExit(){
		return (session()->has('pc_suid')) ? true : false;
	}

	public static function checkTransaction() {
		$transaction = CarTData::checkTransaction();
		if ($transaction !== null) {
			if ($transaction->t_status && $transaction->t_status == 1) {
				return 1;
			}
		}
		return 0;
	}

	public static function getMasterData($for, $master) {
		$model = 'App\Models\Car\Master' . $master;
		return $result = $model::{'get' . $master}($for);
	}

	public static function getMasterId($for, $master , $code) {
		$model = 'App\Models\Car\Master' . $master;
		return $result = $model::{'get' . $master.'Id'}($for,$code);
	}

	public static function getMasterName( $master , $code) {
		$model = 'App\Models\Car\Master' . $master;
		return $result = $model::{'get' . $master.'Name'}($code);
	}

	public static function getMasterCity($for, $master, $state_code) {
		$model = 'App\Models\Car\Master' . $master;
		return $result = $model::{'get' . $master}($for, $state_code);
	}

	public static function getMasterCityByPolicyCode($for, $policy_code) {
		return \App\Models\Car\MasterState::getCity($for, $policy_code);
	}


	public static function storeUserLoginId(){
		$table['user_id'] = !empty(session('user_id')) ? session('user_id') : NULL;
		try {
			$car_transaction = CarTData::updateOrCreate(array('session_id' => Self::getSuid()), $table);
		} catch (Exception $e) {
			echo $e->getMessage();
			die;
		}
	}

	public static function storeIp($request){
		if($request->ip() != ""){
			$table['client_ip'] = $request->ip();
			$table['session_id'] = CarHelper::getSuid();
			$t = CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);	
		}
	}

	public static function storeOptedIDV($request){
            $idv_opted = (isset($request->idv_opted))? $request->idv_opted : null;
            $table['idv_opted'] = $idv_opted;
            $table['session_id'] = CarHelper::getSuid();
            $t = CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);	
	}
	
	public static function grabDetails($fileds,$proposal_data){
		foreach ($fileds as $key => $value) {
			if(is_array($value)){
				foreach ($value as $value_key => $value_value) {
					$data[] = $proposal_data[$value_value];	
				}
				$proposer_request[$key] = implode(",",$data);
				unset($data);
			}else{
				if(isset($proposal_data[$value]))
					$proposer_request[$key] = $proposal_data[$value];
			}
		}
		return $proposer_request;
	}

	public static function getMilitime(){
		return round(microtime(true) * 1000);
	}

	public static function genrateXml($root,$fields){
		$xml = new \SimpleXMLElement($root);
		self::addChild($xml,$fields);
		return $xml;
	}

	public static function addChild($xml,$fields){
		$fn = function($value,$key) use ($xml){
			 if(is_array($value)){
			 	if($key == 'attribute'){
			 		foreach ($value as $key2 => $value2) {
			 			$xml->addAttribute($key2,$value2);
			 		}
			 	}else{
			 		$sxml = $xml->addChild($key);
			 		self::addChild($sxml,$value);
			 	}
			 }else {
		 		$xml->addChild($key,$value);
		 	}
		};
		array_walk($fields,$fn);
		return $xml;
	}

	public static function getUserCode(){
		$user_code = !empty(session('user_code')) ? session('user_code') : NULL;
		$agent_store = new C\Customers\Customers();
		$agent_store->agentUserCode($user_code);
		return 	$user_code;
	}

	public static  function getODTPPremium($user_data){            
		$new_ncb = ($user_data->od_premium*$user_data->new_ncb)/100;            
		$od_premium = $user_data->od_premium - $new_ncb;            
		$tp_premium = $user_data->tp_premium;            
		$od_addon = ['zerodep','ep','ncbprotect','rsac','rti'];            
		$tp_addon = ['pa','ll','papass'];        
		
		if(isset($user_data->addon_premium) && $user_data->addon_premium != ''){
			$addon = json_decode($user_data->addon_premium);               
				foreach($addon as $key => $value){                    
				 	if(in_array($key,$od_addon))                        
				 		$od_premium = $od_premium+$addon->$key;             
				 	if(in_array($key,$tp_addon))                        
				 		$tp_premium = $tp_premium+$addon->$key;                
			}            
		}            
		return ['od_premium'=>round($od_premium,0),'tp_premium'=>round($tp_premium,0)];        
	}

	
	public function storePremiumDetails($product_id){
		$stored_session_data	=	CarHelper::getSessionValue(Self::getSuid());
		$return_quote_url		=	$stored_session_data['return_quote_url'];
		
		$premium_details = (array_key_exists($product_id, $stored_session_data['filter_data_back']))? $stored_session_data['filter_data_back'][$product_id] : $stored_session_data[$product_id.'_return_data'][$product_id];

		$addon_value			=	(isset($premium_details['premiumBreakup']['addon']))?$premium_details['premiumBreakup']['addon']:[];
		$basic_value			=	(isset($premium_details['premiumBreakup']['basic']))?$premium_details['premiumBreakup']['basic']:[];
		$discounts_value		=	(isset($premium_details['premiumBreakup']['discounts']))?$premium_details['premiumBreakup']['discounts']:[];
		$od_premium				=	$premium_details['od_basic_price'] - $discounts_value['od_discount_price']['basic_premium'];
		$covers_selected = $stored_session_data['covers_selected_id'];
		$covers_selected =	$covers_selected.',PA,LL';
		$valu_chc = explode(',',$covers_selected);
		$array_filer_addon = array('ZERODEP'=>'zerodep','EP'=>'ep','NCBPROTECT'=>'ncbprotect','RSAC'=>'rsac','RTI'=>'rti','PAPASS'=>'papass','PAPASS'=>'papass','PA'=>'pa','LL'=>'ll');
		$checking_value_for = [];
		$addon_premium = [];
		foreach ($valu_chc as $key => $value) {
			if(array_key_exists($value,$array_filer_addon)){
				$checking_value_for[] = $array_filer_addon[$value];
				if(array_key_exists($array_filer_addon[$value].'_addon_price', $addon_value)){
					$addon_premium[$array_filer_addon[$value]]	=	$addon_value[$array_filer_addon[$value].'_addon_price']['basic_premium'];
				} else {
					if(array_key_exists($array_filer_addon[$value].'_basic_price', $basic_value)){
						$addon_premium[$array_filer_addon[$value]]	=	$basic_value[$array_filer_addon[$value].'_basic_price']['basic_premium'];
					}
				}
			}
		}
		$table = [
			'session_id'		=>	Self::getSuid(),
			'insurer_id'		=>	$premium_details['insurer_id'],
			'product_id'		=>	$premium_details['product_id'],
			'return_quote_url'	=>	$return_quote_url,
			'totalpremium'		=>	$premium_details['totalpremium'],
			'netPremium'		=>	$premium_details['netPremium'],
			'od_premium'		=>	$od_premium,
			'tp_premium'		=>	$premium_details['tp_basic_price'],
			'addon_premium'		=>	json_encode($addon_premium),
			'tax'				=>	$premium_details['serviceTax']
		];
		CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);
		$car_helper = new CarHelper();
	}

	public static function storeQuoteValue($data){
		$addon = [];
		$table = [];

		if(isset($data['product_id']))
     		$table['product_id'] = $data['product_id'];

		if(isset($data['totalpremium']))
			$table['totalpremium'] = $data['totalpremium'];

		if(isset($data['od_basic_price']))
			$table['od_premium'] = $data['od_basic_price'];

		if(isset($data['tp_basic_price']))
			$table['tp_premium'] = $data['tp_basic_price'];
		
		// ADD ADDON
		if(isset($data['zerodep_addon_price']))
			$addon['zerodep'] = $data['zerodep_addon_price'];

		if(isset($data['ll_basic_price']))
			$addon['ll'] = $data['ll_basic_price'];

		if(isset($data['pa_basic_price']))
			$addon['pa'] = $data['pa_basic_price'];

		if(!empty($addon))
			$table['addon_premium'] = json_encode($addon);

		CarTData::updateOrCreate(array('session_id' => $data['session_id']), $table);
	}

	// DATE FUNCTION
	public static function manDate($date,$format=null,$man=null){
		if(isset($man))
			$date = self::manipulateDate($date,$man);
		
		if(isset($format))
			$date = self::changeFormat($date,$format);


		return $date;
	}

	public static function changeFormat($date,$format){
		$date = str_replace('/','-',$date);
		$date = strtotime($date);
		return date($format,$date);
	}

	public static function manipulateDate($date,$man){
		if(is_array($man)){
			foreach ($man as $key => $value) {
				$date = strtotime($date);
				$date = date('Y-m-d',strtotime($value,$date));
			}
		}else{
			$date = strtotime($date);
			$date = date('Y-m-d',strtotime($man,$date));
		}
		return $date;
	}

	public static function getAgentFromQuoteId(){
		$session_id = CarHelper::getsuid();
		$agent_data = CarTData::getSessionRowData($session_id);

		if (empty($agent_data['agent_code'])) {
			return 'NA';
		}
		$agent_code = $agent_data['agent_code'];
		return self::getUserNameFromCode($agent_code);
	}

	public static function getAgentEmailQuoteId(){
		$session_id = CarHelper::getsuid();
		$agent_data = CarTData::getSessionRowData($session_id);

		if (empty($agent_data['agent_code'])) {
			return 'NA';
		}
		$agent_code = $agent_data['agent_code'];
		return self::getUserEmailFromCode($agent_code);
	}

	public static function getUserNameFromCode($user_code){
		$agent_name = M \ InstaUser::getUserName($user_code);
		return $agent_name;
	}

	private static function getUserEmailFromCode($user_code){
		$agent_name = M \ InstaUser::getEmail($user_code);
		return $agent_name;
	}

	// get comapnay name 
	public static function getInsuranceCompanyName($product_id) {
		$return_data = CarHelper::retFileData($product_id);
		return $return_data['insurerName'];
	}

	public static function getQuoteFieldMap($map_for = null) {
		$fields = [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
                        Car_Constants::CAR_T_QUOTELOG['OPTED_IDV'] => 'idv_opted',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
			Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_ID'] => 'quote_id',
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}


	// xml to array
	public static function xmlToarray($data,$response){
		$fn = function($value) use ($response){
			if(is_object($value)){
				$resp = (array)$value;
				return self::xmlToarray($resp,$response);
			}
			$a = @simplexml_load_string($value);
			if($a === FALSE){
				return $value;
			}else{
				$resp = (array)$a;
				return self::xmlToarray($resp,$response);
			}
		};
		if(is_object($data)){
			$data = (array)$data;
		} else if(is_string($data)) {
			$data = str_replace('ns2:','',$data);
			$data = str_replace('ns3:','',$data);
			$data = str_replace('ns7:','',$data);
			$data = str_replace('soap:','',$data);
			$a = @simplexml_load_string($data);
			return self::xmlToarray($a,$response);
		}
		return array_map($fn,$data);;
	}

	public static function getFieldName($type, $mapper_name) {
		$field = self::getFieldMap();
		if (isset($field) && !empty($field)) {
			return $field[$type][Car_Constants::CAR_T_USERLOG[$mapper_name]];
		}
	}

	public static function getFieldMap($map_for = null) {
		$fields = ['PROPOSER' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['USR_GENDER'] => 'gender',
				Car_Constants::CAR_T_USERLOG['USR_TYPE'] => 'type',
				Car_Constants::CAR_T_USERLOG['USR_DOB'] => "cust_dob",
				Car_Constants::CAR_T_USERLOG['USR_FIRSTNAME'] => "firstname",
				Car_Constants::CAR_T_USERLOG['USR_LASTNAME'] => "lastname",
				Car_Constants::CAR_T_USERLOG['USR_EMAIL'] => "email",
				Car_Constants::CAR_T_USERLOG['USR_MOBILE'] => "mobile",
				Car_Constants::CAR_T_USERLOG['USR_TITLE'] => "title",
				Car_Constants::CAR_T_USERLOG['OCCUPATION'] => "occupation",
				Car_Constants::CAR_T_USERLOG['USR_PAN'] => "pan",
				Car_Constants::CAR_T_USERLOG['USR_COMPANYNAME'] => "companyname",
				Car_Constants::CAR_T_USERLOG['USR_CONTACTPERSON'] => "contactperson",
				Car_Constants::CAR_T_USERLOG['CMP_PAID_UP'] => 'cmp_paid_up',
				Car_Constants::CAR_T_USERLOG['USR_AADHARNO'] => "aadharno",
				Car_Constants::CAR_T_USERLOG['USR_MARITALSTATUS'] => "martitalStatus",
				Car_Constants::CAR_T_USERLOG['GSTIN'] => "gstin",
				Car_Constants::CAR_T_USERLOG['QUOTE_ID'] => "quote_id"
			],
			'COMMUNICATION' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['HOUSENO'] => 'houseno',
				Car_Constants::CAR_T_USERLOG['STREET'] => "street",
				Car_Constants::CAR_T_USERLOG['LOCALITY'] => "locality",
				Car_Constants::CAR_T_USERLOG['PINCODE'] => "pincode",
				Car_Constants::CAR_T_USERLOG['USR_STATE_CODE'] => "statecode",
				Car_Constants::CAR_T_USERLOG['USR_CITY_CODE'] => "citycode",
				Car_Constants::CAR_T_USERLOG['PERM_HOUSENO'] => 'perm_houseno',
				Car_Constants::CAR_T_USERLOG['PERM_STREET'] => "perm_street",
				Car_Constants::CAR_T_USERLOG['PERM_LOCALITY'] => "perm_locality",
				Car_Constants::CAR_T_USERLOG['PERM_PINCODE'] => "perm_pincode",
				Car_Constants::CAR_T_USERLOG['PERM_USR_STATE_CODE'] => "perm_statecode",
				Car_Constants::CAR_T_USERLOG['PERM_USR_CITY_CODE'] => "perm_citycode",
				Car_Constants::CAR_T_USERLOG['REG_ADD_IS_SAME'] => 'reg_add_is_same',

			],
			'VEHICLE' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['CHASSISNO'] => 'chassisno',
				Car_Constants::CAR_T_USERLOG['ELECTRICAL'] => 'electrical',
				Car_Constants::CAR_T_USERLOG['ENGNO'] => 'engno',
				Car_Constants::CAR_T_USERLOG['NON_ELECTRICAL'] => 'non_electrical',
				Car_Constants::CAR_T_USERLOG['REGNO'] => 'regno',
				Car_Constants::CAR_T_USERLOG['YOM'] => 'yom_selected',
				Car_Constants::CAR_T_USERLOG['COLOR'] => 'color',
				Car_Constants::CAR_T_USERLOG['BODYTYPE'] => 'bodyType',
				Car_Constants::CAR_T_USERLOG['VEH_VEHICLE_FINANCED']=>'vehicle_financed',
				Car_Constants::CAR_T_USERLOG['VEH_VEHICLE_TYPE_OF_FINANCED']=>'type_of_finance',
				Car_Constants::CAR_T_USERLOG['VEH_FINANCIER_NAME']=>'financierName',
				Car_Constants::CAR_T_USERLOG['isCarOwnershipChanged']=>'ownership_change',
				Car_Constants::CAR_T_USERLOG['veh_voluntary_deductible']=>'vd',
				Car_Constants::CAR_T_USERLOG['GARAGETYPE'] => 'garageType',
			],
			"PREVIOUSINSURER" => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['POLICYNO'] => 'policyno',
				Car_Constants::CAR_T_USERLOG['PREVINSURANCE'] => 'previnsurance',
				Car_Constants::CAR_T_USERLOG['PREVIOUSPOLICYTYPE'] => 'previousPolicyType',
				Car_Constants::CAR_T_USERLOG['PREVIOUSADDONS'] => 'prev_addons',
				Car_Constants::CAR_T_USERLOG['NOMINEENAME'] => 'nomineeName',
				Car_Constants::CAR_T_USERLOG['NOMINEEREL'] => 'nomineeRel',
				Car_Constants::CAR_T_USERLOG['NOMINEEAGE'] => "nomineeAge",
				Car_Constants::CAR_T_USERLOG['PREVCLAIM'] => 'claim',
				Car_Constants::CAR_T_USERLOG['CLAIM_AMOUNT_RECEIVED']=>'claimAmountReceived',
				Car_Constants::CAR_T_USERLOG['PREVINSURANCE_ADDR']=>'previnsurance_addr',
				Car_Constants::CAR_T_USERLOG['IS_ZERODEP_PREV'] => 'prevzerodep'
			],
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	public static function getDbData($session_id) {
		$field = CarHelper::getFieldMap();
		$user_data = CarTData::find($session_id);
		return (!$user_data) ? [] : CarHelper::getFieldData($user_data,$field);
	}

	public static function getDbDataByField($user_data) {
		$field = CarHelper::getFieldMap();
		return (!$user_data) ? [] : CarHelper::getFieldData($user_data,$field);
	}
}

?>
