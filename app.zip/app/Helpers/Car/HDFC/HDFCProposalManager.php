<?php
namespace App\Helpers\Car\HDFC;

use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use App\Be\Car as BE;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use Log;

class HDFCProposalManager{
	const HDFC_MASTER  = ['Insurer', 'Financier','NomineeRelationship'];
	//public $service_url = 'http://202.191.196.210/uat/onlineproducts/newmotorcp/service.asmx';
	public $service_url = 'https://hewspool.hdfcergo.com/motorcp/service.asmx'; // Production
	private $paymentUrl = "https://netinsure.hdfcergo.com/onlineproducts/motoronline/TIM.aspx";
	//private $paymentUrl = 'http://202.191.196.210/UAT/OnlineProducts/NewDesignMotorOnline/TIM.aspx';

	public function __construct(){
		$this->car_helper = new CarHelper;
		$this->http_config['content-type'] = 'application/x-www-form-urlencoded';
		$this->http_config['post-type'] = 'http';
		$this->refrel_col = "hdfc_code";
		$this->new_refrel_col = "hdfc_code";
		$this->refrel_variant_col = "lstdec_code";
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->title = Car_Constants::TITLE;
		$this->logo = Car_Constants::CMP_LOGO['hdfc'];
		$this->type_of_finance = Car_Constants::TYPE_OF_FINANCE;
		$this->cmp_paid_up = ['More than Rs. 25 Crores'=>'more than 25cr'
								,'From Rs. 10 to 25 Crores'=>'10cr-25cr'
								,'Upto Rs. 10 Crores' =>'upto 10 cr' ];
		$this->test = 0;
	}

	public function getPredefinedData($request_data){

		session(['request' => $request_data]);
		$car_t_data = new CarTData;
		$user_data = $car_t_data->find($request_data['trans_code'])->toArray();
		$covers = array_key_exists('covers_selected',$user_data) ? explode(',',$user_data['covers_selected']) : [];
		$date = Carbon::now();
		$return_data_field = ['variant_code','product_id','insurer_id','totalpremium','netPremium','session_id','trans_code','return_quote_url','policyStartDate','idv','policyExpiryDate','rto','price','claim'];
		foreach ($return_data_field as $value) {
			$return_data[$value] = $request_data[$value];	
		}
		$return_data['zero_dep_selected'] = in_array('ZERODEP',$covers);
		$return_data['idv_opted'] = $request_data['idv'];
		$return_data['ncb'] = $request_data['new_ncb'];
		$return_data['pre_ncb'] = $request_data['ncb'];
		$return_data['year'] = (isset($request_data['year']))? $request_data['year'] : null;
		$return_data['sc'] = 5;
		$return_data['occupation'] = 0;
		$return_data['regDate'] =  (isset($request_data['regDate']) && $request_data['regDate'])  ? $request_data['regDate'] : $request_data['car_registration_date'];
		$this->getDbData($return_data['trans_code']);
		$policy_exp_status = (isset($this->db->policy_exp_status)) ? $this->db->policy_exp_status : 0;
		if ($this->db->type_of_business == 'New Business') {
			$return_data['typeOfBusiness'] = 'new_bussiness';
			$return_data['policyStartDate'] = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyStartDate'])));
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_NEWBUSINESS;
			
		} else {
			$return_data['typeOfBusiness'] = 'rollover';
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyExpiryDate'])));
			$return_data['policyStartDate'] = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_ROLLOVER;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_ROLLOVER;
		}
		if($policy_exp_status == 2){
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_NEWBUSINESS;
		}
		$return_data['perm_diff'] = (($this->user_data['reg_add_is_same']) == 'N') ? '': 'checked';
   		$return_data['reg_add_is_same'] = (isset($this->user_data['reg_add_is_same']) && $this->user_data['reg_add_is_same']) ? $this->user_data['reg_add_is_same'] : 'Y';
   		$return_data['trans_code'] = $request_data['trans_code'];
		$this->genrateTransactionTable($return_data);
		$return_data['refrel_col'] = $this->refrel_col;
		return $return_data;
	}

    public function getStateCity($product_id) {
    	$car_helper = new CarHelper;
		if (!Session::has($product_id . 'apiDataState')) {
			$state = $car_helper->getMasterData($this->refrel_col, 'State');
			if (!empty($state)) {
				$field_name = $car_helper->getFieldName('COMMUNICATION', 'USR_STATE_CODE');
				$state_id = (isset($this->user_data[$field_name])) ? $this->user_data[$field_name] : $state[0]['id'];
				$city = $car_helper->getMasterCity($this->refrel_col, 'City', $state_id);

				$field_name = 'perm_statecode';
				$perm_state_id = (isset($this->user_data[$field_name])) ?
				$this->user_data[$field_name] : $state[0]['id'];
				$perm_city = $car_helper->getMasterCity($this->refrel_col, 'City', $perm_state_id);

				Session::put($product_id . 'apiDataState', ['state' => $state, 'city' => $city,'perm_city'=>$perm_city]);
				Session::save();
				return ['state' => $state, 'city' => $city,'perm_city'=>$perm_city];
			}else{
				return [];
			}
		}
		return Session::pull($product_id . 'apiDataState');
	}

	public function requiredData($product_id) {
		$car_helper = new CarHelper;
		$response_data = array();
		foreach (self::HDFC_MASTER as $value) {
			$refrel_col = $this->refrel_col;
			$result = $car_helper->getMasterData($refrel_col, $value);
			$response_data[strtolower($value)] = (!empty($result)) ? $result : array();
		}
		Session::put($product_id . 'apiData', $response_data);
		Session::save();
		return Session::pull($product_id . 'apiData');
	}

	public function genrateTransactionTable($data){
		$car_t_data = new CarTData;
    	$fields = ['trans_code'
				 ,'insurer_id'
				 ,'product_id'
				 ,'return_quote_url'
				 ,'totalpremium'
				 ,'netPremium'
				 ,'final_premium'
				 ,'tax'];
		foreach ($fields as $value) 
			if(isset($data[$value]))
				$table[$value] = $data[$value];		

		if(isset($table['trans_code']))
			return $car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
		else 
			return false;
    }

    public function submit_policy($req_param,$trans_code = null){
    	$car_helper = new CarHelper;
    	$error = 0;
		$url = $this->service_url.'/xmlstring';
		$request_param['str'] = $req_param;
		$response = $car_helper->call_hdfc_curl_api('HDFC Proposal',$url,$request_param,$this->http_config,$trans_code);
		if(isset($response['data']) && $response['data']){
			$resp = $car_helper->xmlToarray($response['data'],[]);
			if(isset($resp[0]) && is_array($resp)){
				return $resp[0]['WsResultSet'];
			}
			return $resp;
		}
		return $error;
	}

	public function checkInspectionStatus($pg_trans_no){
		$car_helper = new CarHelper;
		$url = $this->service_url.'/GetBreakinInspectionStatus';
		$request_param['AgentCode'] = $this->AgentCode;
		$request_param['PGTransNo'] = $pg_trans_no;
		$response = $car_helper->callApi($url,$request_param,$this->http_config);
	}

	public function genrateProposalResponse($result,$data,$trans_code){
		$car_t_data = new CarTData;
		$user_data = CarTData::find($trans_code);

		$return_response = [];
		$breacking_case =  0;
		if(is_array($result)){
			if($result['WsStatus']){
    			$explode_result = explode('|',$result['WsMessage']);
    			if(is_array($explode_result)){
    				if(trim($explode_result[0]) == 'Total Premium provided is incorrect.')
    					$case = 'Premium Mismatch';
    				else
    					$case = 'Error';	
    			}else
    				$case = 'Error';
    		}else
    			$case = 'Payment';
		}else
			$case = 'ApiNotWorking';

    	
    	if(isset($data['LocationCode']))
			$breacking_case =  1;


    	switch ($case) {
    		case 'Premium Mismatch':
				$result = $this->parsePremiumMissmatch($explode_result);
				$return_response['error'] = 'premium mismatch';
				$return_response['premiumPayable'] = $result['Total Amount Payable'];
				$return_response['passedPremium'] = $data['Total_Amoutpayable'];
				$this->updatePremiumeValue($result,$trans_code);
    			break;
    		case 'Payment':
				$return_response['premiumPayable'] = $data['Total_Amoutpayable'];
				$return_response['url'] = $this->paymentUrl;
				$fields['CustomerID'] = $result['WsMessage'];
				$fields['TxnAmount'] = $data['Total_Amoutpayable'];
				$fields['AdditionalInfo1'] = 'NB';
				$fields['AdditionalInfo2'] = 'MOT';
				$fields['AdditionalInfo3'] = 1;
				$fields['hdnPayMode'] = $user_data->pay_mode;
				$fields['UserName'] = $data['First_Name'].' '.$data['Last_Name'];
				$fields['UserMailId'] = $data['Email_Id'];
				$fields['ProductCd'] = 'MOT';
				$fields['ProducerCd'] = Car_Constants::HDFC_PARTNER_CODE.'-'.$result['WsMessage'];
				$return_response['fields'] = $fields;
				break;
    		case 'Error':
    			$return_response = ['error'=>$result['WsMessage']];
    			break;
    		default:
				$return_response = ['proposal_error' =>'Api Not Working'];
    			break;
    	}

    	if($breacking_case){
    		if($case == 'Payment'){
    			$return_response = ['proposal_error' =>'Congratulations!<br/>
Inspection of your vehicle has been scheduled.<br/>
The reference number is : '.$fields['CustomerID']];
    		}
    	}

		if(isset($return_response['proposal_error'])){
    		session()->put('flash_msg',$return_response['proposal_error']);
			$footer_msg = '<h5>You will be contacted by a representative of HDFC Ergo General Insurance Company shortly.</h5>
			  <h6>For any queries contact InstaInsure at: +91 7899-000-333</h6>';
			session()->put('footer_msg',$footer_msg);
			session()->save();
    	}

    	Log::info('CAR HDFC Payment Request - '.$trans_code.' - ',$return_response);
    	return $return_response;
    	
	}


	private function parsePremiumMissmatch($data){
		$premium = [];

		foreach ($data as $key => $value)
    						$data[$key] = explode(':', $data[$key]);

		foreach ($data as $key => $value) {
			if(is_array($value)){
				$len = count($value);
				if($len > 1)
					$premium[trim($value[$len-2])] = trim($value[$len-1]);
				else 
					$premium[$key] = trim($value[$len-1]);
			}
		}

		return $premium;
	}

	public function excludingZeroDept($user_data){
		$covers = explode(',',$user_data->covers_selected);
		foreach ($covers as $key => $value) {
			if(strtolower($value) == 'zerodep')
				unset($covers[$key]);
		}
		$user_data->covers_selected = implode(',',$covers);
		$addon = json_decode($user_data->addon_premium,true);
		$zerodep_value = $addon['zerodep'];
		$zerodep_tax = (($zerodep_value*Car_Constants::GST)/100);
		$user_data->totalpremium = $user_data->totalpremium-($zerodep_value+$zerodep_tax);
		$user_data->netPremium = round($user_data->totalpremium / (Car_Constants::GST+100) * 100);
		$user_data->tax = $user_data->totalpremium -$user_data->netPremium;
		unset($addon['zerodep']);
		$user_data->addon_premium =  json_encode($addon);
		$user_data->save();
		return $user_data;
	}
	
	private function updatePremiumeValue($result,$trans_code){
		$data = ['final_premium'=>$result['Total Amount Payable']
				 ,'trans_code'=>$trans_code];
		return $this->genrateTransactionTable($data);
	}

    public function getDbData($trans_code) {
    	$car_t_data = new CarTData;
		$this->field = $this->car_helper->getFieldMap();
		$user_data = $car_t_data->find($trans_code);
		$this->db = (!$user_data) ? [] : $user_data;
		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $this->field);
		$this->user_data['fullname'] = (isset($this->user_data['firstname']) && isset($this->user_data['lastname'])) ? $this->user_data['firstname'].' '.$this->user_data['lastname'] : '';

		if(!$this->user_data['regno']){
            $car_lib = new CarLib;
            $this->user_data['regno'] = $car_lib->parseRegistrationNumber($user_data['car_rto']).'-';
            unset($car_lib);
            unset($user_data);
        }
	}

	public function storeStatusAndTransaction($status,$trans_code = null){
		$car_lib = new CarLib;
		$car_t_data = new CarTData;
		$car_t_policy = new M\CarTPolicy;
		$t_status = ($status) ? 1 : 2;
		// store success or failed in databse
		$user_data = $car_lib->storeStatus($t_status,$trans_code);
		

		if ($user_data && $user_data->t_status != 'TS19') {
			return $user_data->t_status;
		}

		if ($user_data && 'TS19' == $user_data->t_status) {
			$user_data = $user_data->toArray();
			$user_data['trans_code'] = $trans_code.'_DONE';
			if($user_data['car_make'] && $user_data['car_model']){
				$car_t_policy->updateOrCreate(array('trans_code' =>
				$user_data['trans_code']),$user_data);
			}
		}
	}

	public function parsePaymentResponse($payment_resp){
		$trans_code = $this->car_helper->getSuid();
		$table = ['trans_code' => $trans_code,
				Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($payment_resp),
				Car_Constants::CAR_T_PROPOSALLOG['PROPOSAL_NU'] => 
					$payment_resp['ProposalNo']
			    ];
		$this->status = ($payment_resp['PolicyNo']) ? 1 : 0;
		if(isset($payment_resp['PolicyNo']) && $payment_resp['PolicyNo']){
			$table[Car_Constants::CAR_T_PROPOSALLOG['POLICY_NU']] = $payment_resp['PolicyNo'];
			$this->setPolicyRefNo($payment_resp['PolicyNo']);
		}
		return $table;
	}

	// set policy refreance number
	public function setPolicyRefNo($no){
		$this->policy_ref_no = $no;
	}

	// retrived policy refreance number
	public function getPolicyRefNo(){
		return (isset($this->policy_ref_no))? $this->policy_ref_no : 0;
	}

	// helper function
	public function changeDateFormate() {
		if (!empty($this->user_data)) {
			$field_name = $this->car_helper->getFieldName('PROPOSER', 'USR_DOB');
			$this->user_data[$field_name] = (isset($this->user_data[$field_name])) ?
			$this->car_helper->getFormDate($this->user_data[$field_name]) : null;
		}
	}

}

