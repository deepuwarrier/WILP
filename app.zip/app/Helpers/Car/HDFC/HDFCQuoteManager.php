<?php
namespace App\Helpers\Car\HDFC;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;
use App\Models\Car as M;
use App\Libraries\CarLib;
use Log;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;

class HDFCQuoteManager {
	//public $service_url = 'http://202.191.196.210/uat/onlineproducts/wscalculate/service.asmx'; //UAT URL
    public $service_url = 'https://hewspool.hdfcergo.com/wscalculate/service.asmx'; // Production URL
    public $agentCode = 'TTIB0001';
    public $logo = 'hdfcgi_logo.png';
    public $vehicleCode = 45;
    public $businessType;
    public $vehicleModelCode;
    public $policyStartDate;
    public $policyEndDate;
    public $firstRegistrationDate;
    public $RTOLocationCode;
    public $prevPolicyEndDate;
    public $manufacturerCode;
	public $exshowroomPrice;
    public $idv_amount;
    public $idv_amount_min;
    public $idv_amount_max;
	public $exshowroomPrice_min;
    public $exshowroomPrice_max;
    public $custType = 'I';
	public $custAge = 'Up to 35';
	public $manufacturingYear;
	public $prevPolicyStartDate;
	public $policy_type_selection = 1;
	public $isPrevClaim = 0; // 1 for no claim made 
	public $prevDiscount = 0;
	public $elecnoofemployeesticalAcc = 0;
	public $electicalAcc = 0;
	public $nonElecticalAcc = 0;
	public $lpg_cngkit = 0;
	public $paiddriversi = 0;
	public $unnamedsi = 0;
	public $noofemployees = 0;
	public $nooflldrivers = 0;
	public $occupationtype = 0;
	public $pa_cover_owner_driver = 0;
	public $num_is_rti = 0;
	public $num_is_emr_asst_cvr = 0;
	public $num_is_zero_dept = 0;
	public $txt_plan_type;
	public $num_is_emr_asst_wider_cvr = 0;
	public $is_ncb_protection = 0;
	public $is_engine_gear_box_protection = 0;
	public $is_cost_of_consumable = 0;
	public $is_loss_of_use_down_protection = 0;
	// premium value
	public $ODValue = 0;
    public $TPValue = 0;
    public $NCBValue = 0;
    public $PAValue = 0;
    public $IDV = 0;
    public $PremiumValue = 0;
    public $FinalValue = 0;
    public $ServiceTaxValue = 0;
    public $ZERODEPValue = 0;
    public $EPValue = 0;
    public $RTIValue = 0;
    public $NCBDiscount = 0;
    public $ODDiscount = 0;
    public $LLValue = 0;
    public $RSACValue = 0;
    public $PAPASSValue = 0;
    //  addon enable by company and user
    public $enable = ['premium'=>['RTI' => 0,
    		'ZERODEP' => 0,
    		'EA' => 0,
    		'NEA' => 0,
            'BFK_TP' => 0,
            'PA' => 1,
            'PAPASS' => 0,
            'LL' => 1,
            'EP'=>0,
            'RSAC'=>0]];	
	
	// covers provide by company 
    public $addon = ['PA'=>1,'LL'=>1];	
    
    // format of Premium Breakup
    private $premium_breakup_fromat = ['basic' => ['od', 'tp', 'll', 'pa']
            , 'addon' => ['rti', 'zerodep','ep','rsac','papass']
            , 'discounts' => ['ncbbenefit', 'od']
            , 'totalpremium'
            , 'serviceTax'
            , 'netPremium'];

    //map gui addon value to BE 
    private $addon_map = ['RTI' => "RTI",
    		'ZERODEP' => 'ZERODEP',
    		'EP' => 'ENGEBOX',
    		'NEA' => 0,
    		'EA' => 0,
            'BFK_TP' => 0,
            'PA' => 'PA',
            'PAPASS' => 'PAPASS',
            'LL' => 'LL',
            'RSAC'=>'EmergAssist'];

    public function __construct($data){
        
    	$this->debug_code = 0;
		$this->http_config['content-type'] = 'application/x-www-form-urlencoded';
		$this->http_config['post-type'] = 'http';
		libxml_use_internal_errors(true);
    	
        foreach ($data as $key => $value)
    		$this->$key = $value;

    	$this->setBasicDetails();
        if($this->getManufacturerCode() && $this->getVehicleModelCode()){
			$this->breakDownDay();
			$this->genrateQuote();
			$log_array = ['model'=>$this->getVehicleModelCode(),
			'make'=>$this->getManufacturerCode(),
			'manufacturingyear'=>$this->getManufacturingYear(),
			'rtolocationcode'=>$this->getRTOLocationCode(),
			'reg_date'=>$this->getFirstRegistrationDate(),
			'policystartdate'=>$this->getPolicyStartDate(),
			'policyenddate'=>$this->getPolicyEndDate(),
			'prepolstartdate'=>$this->getPrevPolicyEndDate(),
			'prepolstartdate'=>$this->getPrevPolicyStartDate(),
			'exshowroomprice'=>$this->getExshowroomPrice(),
			'Sum_Insured'=>$this->getIdvAmount()
			];
			if(!$this->getPremiumValue()){
                $this->quote = null;
            }
		}
    }
    

    private function breakDownDay(){
        $car_helper = new CarHelper;
    	$now = time(); // or your date as well
    	if($this->getPrevPolicyEndDate()){
    		$your_date = strtotime($car_helper->changeFormat($this->getPrevPolicyEndDate(),'Y-m-d'));
			$datediff = $now - $your_date;
			return floor($datediff / (60 * 60 * 24));	
    	}
		return 0;
    }

    public function getPlanTypes(){
        $car_helper = new CarHelper;
		$error = 1;
		$req_param = $this->getPlanTypesRequest();
		$url = $this->service_url.'/GetPlanTypes';
		$response = $car_helper->call_hdfc_curl_api('HDFC Plan Type',$url,$req_param,$this->http_config,$this->trans_code);
		if(isset($response['data']) && $response['data']){
			$addon_str  = (array)simplexml_load_string($response['data']);
			$addon_str = $addon_str[0];
			if($addon_str){
				$addon = explode(',',$addon_str);
				foreach($addon as $key => $value) {
					$this->addon[''.$value] = 1;
				}	
                // by default set eaddon enable 
                $this->addon['PAPASS'] = 1;
			}else
				$error = 0;	
		}else{
			$error = 0;
		}
		return $error;
	}

	// use if idv you wan to take from API
	public function getIDV(){
        $car_helper = new CarHelper;
		$error = 0;
		$url = $this->service_url.'/getIDV';
		$req_param['typeofbusiness'] = $this->getBusinessType();
		$req_param['vehiclemodelcode'] = $this->getVehicleModelCode();
		$req_param['policy_start_date'] = $this->getPolicyStartDate();
		$req_param['purchaseregndate'] = $this->getFirstRegistrationDate();
		$req_param['RTOLocationCode'] = $this->getRTOLocationCode();
		$req_param['vehicle_class_cd'] = $this->getVehicleCode();
		$req_param['manufacturer_code'] = $this->getManufacturerCode();
		$req_param['prev_policy_end_date'] =  $this->getPrevPolicyEndDate();
		$param = $car_helper->genrateXml("<IDV/>",$req_param)->asXML();
		$response = $car_helper->call_hdfc_curl_api('HDFC IDV',$url,['str'=>$param],$this->http_config,$this->trans_code);
		if(isset($response['data']) && $response['data']){
			$idv_resp = $car_helper->xmlToarray($response['data'],[]);
			$idv_resp = $idv_resp[0];
			if(isset($idv_resp['exshowroomPrice']))
				$this->setExshowroomPrice($idv_resp['exshowroomPrice']);
			if(isset($idv_resp['idv_amount']))
				$this->setIdvAmount($idv_resp['idv_amount']);
			if(isset($idv_resp['idv_amount_min']))
				$this->setIdvAmountMin($idv_resp['idv_amount_min']);
			if(isset($idv_resp['idv_amount_max']))
				$this->setIdvAmountMax($idv_resp['idv_amount_max']);
			if(isset($idv_resp['exshowroomPrice_min']))
				$this->setExshowroomPriceMin($idv_resp['exshowroomPrice_min']);
			if(isset($idv_resp['exshowroomPrice_max']))
				$this->setExshowroomPriceMax($idv_resp['exshowroomPrice_max']);
		}else{
			$error = 1;	
		}
		return $error;
	}

	public function genrateQuote(){
		if($this->getPlanTypes()){
			$this->setAddons($this->selected_chcks);
            if(!$this->checkAddonAvailable())
				return 0;
			// enable 
            if($this->isEnable('ZERODEP'))
				$this->setNumIsZeroDept(1);
			if($this->isEnable('EP'))
				$this->setIsEngineGearBoxProtection(1);
			if($this->isEnable('RTI'))
				$this->setNumIsRti(1);
			if($this->isEnable('PA'))
				$this->setPaCoverOwnerDriver(1);
            if($this->isEnable('RSAC'))
                $this->setNumIsEmrAsstCvr(1);
            if($this->isEnable('PAPASS'))
              $this->setUnnamedsi('100000');
            //$this->getIDV(); // uncomment if need idv from API
			$this->getPremium();
		}
		$this->breakDownDay();
		
		//$this->getPremiumBreakup();
        $pb_data = new PremiumBreakupData();
        $pb_data = $this->parse_premium_breakup_data($pb_data);
        $pb = new PremiumBreakup();
        $pb->setPbDatat($pb_data);
        $PremiumBreakup = $pb->genratePremiumBreakup();
		$this->quote = ['totalpremium' => $pb_data->getTotalPremium()
            , 'insurer_id' => 'hdfc'
            , 'product_id' => 'hdfc'
            ,'insurerroute' => 'hdfc'
            , 'idv_received' => $this->getIdvAmount()
            , 'netPremium' => $pb_data->getGrossPremium()
            , 'insurerName' => 'HDFC ERGO GI'
            , 'serviceTax' => $pb_data->getServiceTax()
            , 'premiumBreakup' =>$PremiumBreakup
            , 'pb_data' => $pb_data
        ];
	}

	public function getPremium(){
        $car_helper = new CarHelper;
		$error = 0;
		$url = $this->service_url.'/getPremium';
		$req_param = $this->getPremiumRequestParam();
		//unset($req_param['txt_plan_type']);
		$param = $car_helper->genrateXml("<PCVPremiumCalc/>",$req_param)->asXML();
		$request_param = ['str'=>$param,
						'VehicleClassCode'=>$this->getVehicleCode()];
		$idv_resp = '';
		$response = $car_helper->call_hdfc_curl_api('HDFC Quote',$url,$request_param,$this->http_config,$this->trans_code);
		if(isset($response['data']) && $response['data']){
			$idv_resp  = (array)simplexml_load_string($response['data']);
			if(isset($idv_resp[0]) && is_array($idv_resp)){
                $idv_resp  = (array)simplexml_load_string($idv_resp[0]);
                if($idv_resp == false)
                    $error = 1;
                else
                    $this->setPremiumResponseParam($idv_resp);
            }
            if(empty($idv_resp))
                $error = 1;
		}else
			$error = 1;
		return $error;
	}

	public function mapAddonAvailable(){
		$map_available = 1;
		foreach ($this->enable['premium'] as $key => $value)
			if($value)
				if(!$this->addon_map[$key])
				   $map_available = 0;
		return $map_available;
	}

	public function checkAddonAvailable(){
		$addon_availabel = 1;
		if(!$this->mapAddonAvailable())
			return 0;
		else
			foreach ($this->enable['premium'] as $key => $value)
				if($value)
					if(!isset($this->addon[$this->addon_map[$key]]))
						$addon_availabel = 0;

		return $addon_availabel;
	}

	public function setAddons($addons) {
        $addons = explode(",", $addons);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        foreach ($addons as $addon_key) {
            $this->enableAddon($addon_key);
        }
    }

    private function enableAddon($key){
    	$this->enable['premium'][$key] = 1;
    }

    private function disableAddon($key){
    	$this->enable['premium'][$key] = 0;
    }

    private function isEnable($key){
    	if(isset($this->enable['premium'][$key]) && $this->enable['premium'][$key])
    		return 1;
    	else 
    		return 0;
    }

    public function parse_premium_breakup_data($pb_data){
        $pb_data->setGrossPremium($this->PremiumValue);
        $pb_data->setTotalPremium($this->FinalValue);
        $pb_data->setServiceTax($this->ServiceTaxValue);
        $pb_data->setOdPremium($this->ODValue);
        $pb_data->setLlPremium($this->LLValue);
        $pb_data->setTpPremium($this->TPValue);
        $pb_data->setPaPremium($this->PAValue);
        $pb_data->setRtiPremium($this->RTIValue);
        $pb_data->setZerodepPremium($this->ZERODEPValue);
        $pb_data->setPapassPremium($this->PAPASSValue);
        $pb_data->setNcbDiscount($this->NCBValue); 
        $pb_data->setOdDiscount($this->ODDiscount); 
        $pb_data->setEpPremium($this->EPValue);
        $pb_data->setRsacPremium($this->RSACValue);
        return $pb_data;
    }

    private function setBasicDetails(){
        $car_helper = new CarHelper;
        $car_make = new M\CarMake;
    	$this->setExshowroomPrice($this->car_details['ex_showroom_car_price']);
		$this->setIdvAmount($this->car_details['idv']);
		$this->setIdvAmountMin($this->car_details['idv_min']);
		$this->setIdvAmountMax($this->car_details['idv_max']);
    	
    	if(isset($this->car_details['claim']) && $this->car_details['claim'] == 'N')
    		$this->setIsPrevClaim(1); // for no calim made
    	else 
    		$this->setIsPrevClaim(0);

    	if(isset($this->car_details['ncb']))
    		$this->setPrevDiscount($this->car_details['ncb']);

		if(isset($this->car_details['typeOfBusiness']))
        	$this->setBusinessType($this->car_details['typeOfBusiness']);

        if(isset($this->car_details['policyStartDate'])){
            if($this->car_details['expiry_status'] == 2)
                 $this->setPolicyStartDate($car_helper->manDate($this->car_details['policyStartDate'],'d/m/Y',['+2 day']));
            else 
    		  $this->setPolicyStartDate($car_helper->changeFormat($this->car_details['policyStartDate'],'d/m/Y'));
    		$this->setPolicyEndDate($car_helper->manDate($this->car_details['policyStartDate'],'d/m/Y',["+1 year","-1 day"]));
        }
  
		if(isset($this->car_details['vm_code']))
        	$this->setVehicleModelCode($this->car_details['vm_code']);

        if(isset($this->car_details['typeOfBusiness']) && $this->car_details['typeOfBusiness'] == 'Rollover'){
            $this->setPrevPolicyStartDate($car_helper->manDate($this->car_details['policyExpiryDate'],'d/m/Y',["-1 year","+1 day"]));
            $this->setPrevPolicyEndDate($car_helper->changeFormat($this->car_details['policyExpiryDate'],'d/m/Y'));
            if($this->car_details['expiry_status'] == 2){
                $this->setPrevPolicyStartDate('01/01/1900');
                $this->setPrevPolicyEndDate('01/01/1900');
            }
        }
		
		if(isset($this->car_details['car_registration_date']))
        	$this->setFirstRegistrationDate($car_helper->changeFormat($this->car_details['car_registration_date'],'d/m/Y'));

		if(isset($this->car_details['rto_location']))
			$this->setRTOLocationCode($this->car_details['rto_location']);

		$code = $car_make->getMakeId($this->car_details['make_code'],'hdfc_code');
    	$this->setManufacturerCode($code);
    }

    private function getPlanTypesRequest(){
    	$req_param['AgentCode'] = $this->getAgentCode();
		$req_param['BusinessType'] = $this->getBusinessType();
		$req_param['VehicleModelCode'] = $this->getVehicleModelCode();
		$req_param['PolicyStartDate'] = $this->getPolicyStartDate();
		$req_param['FirstRegistrationDate'] = $this->getFirstRegistrationDate();
		$req_param['RTOLocationCode'] = $this->getRTOLocationCode();
		return $req_param;
    }

    private function setPremiumResponseParam($idv_resp){
        $car_lib = new CarLib;
    	$this->premium = $idv_resp;
    	if(isset($this->premium) && $this->premium && !empty($this->premium)){
			if(isset($this->premium['PARENT']))
				$this->premium = $this->car_details['policy_type_selection'] == 1 ?  (Object)$this->premium['PARENT'][0] : (Object)$this->premium['PARENT'][1];

			$this->premium = (Object)$this->premium;
			$od_without_disc = $car_lib->calculateOD($this->car_details['vehicle_cc'],
   			$this->car_details['rto_zone'],
   			$this->premium->NUM_VEHICLE_AGE,
   			$this->premium->NUM_VEHICLE_IDV,
   			$this->car_details['policy_type_selection']
   		    );
   			$od_disc_value = $od_without_disc - $this->premium->NUM_BASIC_OD_PREMIUM;
			$this->setODValue($od_without_disc);
			$this->setODDiscount($od_disc_value);
			$this->setZERODEPValue($this->premium->NUM_ZERO_DEPT_PREM);
            		$this->setRSACValue($this->premium->NUM_EMR_ASST_PREM);
			$this->setRTIValue($this->premium->NUM_RTI_PREM);
			$this->setEPValue($this->premium->NUM_ENG_GRBX_PREM);
			$this->setFinalValue($this->premium->NUM_TOTAL_PREMIUM );
			$this->setPremiumValue($this->premium->NUM_NET_PREMIUM );
			$this->setServiceTaxValue($this->premium->NUM_SERVICE_TAX );
			$this->setPAValue($this->premium->NUM_PA_COVER_OWNER_DRVR );
			$this->setIDV($this->premium->NUM_TOTAL_PREMIUM );
			$this->setNCBValue($this->premium->NUM_NCB_PREM );
			$this->setTPValue($this->premium->NUM_TP_RATE );
			$this->setLLValue($this->premium->NUM_LL_PAID_DRIVER);
            		$this->setPAPASSValue($this->premium->NUM_UNNAMED_PA_PREM);
            		$this->setIdvAmount($this->premium->NUM_VEHICLE_IDV);
		}
	}

	private function getPremiumRequestParam(){
	       if($this->car_details['idv'] < $this->getIdvAmountMax() && 
		        $this->car_details['idv'] > $this->getIdvAmountMin())
		    $this->setIdvAmount($this->car_details['idv']);
		else if($this->car_details['idv'] >= $this->getIdvAmountMax())
		    $this->setIdvAmount($this->getIdvAmountMax());
		else
		    $this->setIdvAmount($this->getIdvAmountMin());

        
		$req_param['agentcode'] = $this->getAgentCode();
		$req_param['typeofbusiness'] = $this->getBusinessType();
		$req_param['txt_cust_type'] = $this->getCustType();
		$req_param['custage'] = $this->getCustAge();
		$req_param['manufacturingyear'] = $this->getManufacturingYear();
		$req_param['purchaseregndate'] = $this->getFirstRegistrationDate();
		$req_param['policystartdate'] = $this->getPolicyStartDate();
		$req_param['policyenddate'] = $this->getPolicyEndDate();
		$req_param['prepolstartdate'] = $this->getPrevPolicyStartDate();
		$req_param['prepolicyenddate'] = $this->getPrevPolicyEndDate();
		$req_param['basedon_IDV_ExShowRoom'] = 1;
		$req_param['exshowroomprice'] =	$this->getExshowroomPrice();
		$req_param['Sum_Insured'] = $this->getIdvAmount();
		$req_param['vehiclemodelcode'] = $this->getVehicleModelCode();
		$req_param['manufacturer_code'] = $this->getManufacturerCode();
		$req_param['rtolocationcode'] = $this->getRTOLocationCode();
		$req_param['IsPreviousClaim'] = $this->getIsPrevClaim();
		$req_param['previousdiscount'] = $this->getPrevDiscount();
		$req_param['electicalacc'] = $this->getElecticalAcc();
		$req_param['nonelecticalacc'] = $this->getNonElecticalAcc();
		$req_param['lpg_cngkit'] = $this->getLpgCngkit();
		$req_param['paiddriversi'] = $this->getPaiddriversi();
		$req_param['unnamedsi']	= $this->getUnnamedsi();
		$req_param['noofemployees'] = $this->getNoofemployees();
		$req_param['nooflldrivers'] = $this->getNooflldrivers();
		$req_param['occupationtype'] = $this->getOccupationtype();
		$req_param['is_pa_cover_owner_driver'] = $this->getPaCoverOwnerDriver();
		$req_param['num_is_rti'] = $this->getNumIsRti();
		$req_param['num_is_emr_asst_cvr'] = $this->getNumIsEmrAsstCvr();
		$req_param['num_is_zero_dept'] = $this->getNumIsZeroDept();
		$req_param['txt_plan_type'] = $this->getPlanTypes();
        $req_param['txt_plan_type'] = '';
		$req_param['num_is_emr_asst_wider_cvr'] = $this->getNumIsEmrAsstWiderCvr();
		$req_param['AddOnCovers']['Premium_Year'] = '1';
		$req_param['AddOnCovers']['is_ncb_protection'] = $this->getIsNcbProtection();
		$req_param['AddOnCovers']['is_engine_gear_box_protection'] = $this->getIsEngineGearBoxProtection();
		$req_param['AddOnCovers']['is_cost_of_consumable'] = $this->getIsCostOfConsumable();
		$req_param['AddOnCovers']['is_loss_of_use_down_protection']  = $this->getIsLossOfUseDownProtection();
		$req_param['vehicle_class_cd'] = $this->getVehicleCode();
		return $req_param;
	}


    /**
     * @return mixed
     */
    public function getServiceUrl()
    {
        return $this->service_url;
    }

    /**
     * @param mixed $service_url
     *
     * @return self
     */
    public function setServiceUrl($service_url)
    {
        $this->service_url = $service_url;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAgentCode()
    {
        return $this->agentCode;
    }

    /**
     * @param mixed $agentCode
     *
     * @return self
     */
    public function setAgentCode($agentCode)
    {
        $this->agentCode = $agentCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getBusinessType()
    {
        return $this->businessType;
    }

    /**
     * @param mixed $businessType
     *
     * @return self
     */
    public function setBusinessType($businessType)
    {
        $this->businessType = $businessType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getVehicleModelCode()
    {
        return $this->vehicleModelCode;
    }

    /**
     * @param mixed $vehicleModelCode
     *
     * @return self
     */
    public function setVehicleModelCode($vehicleModelCode)
    {
        $this->vehicleModelCode = $vehicleModelCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPolicyStartDate()
    {
        return $this->policyStartDate;
    }

    /**
     * @param mixed $policyStartDate
     *
     * @return self
     */
    public function setPolicyStartDate($policyStartDate)
    {
        $this->policyStartDate = $policyStartDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFirstRegistrationDate()
    {
        return $this->firstRegistrationDate;
    }

    /**
     * @param mixed $firstRegistrationDate
     *
     * @return self
     */
    public function setFirstRegistrationDate($firstRegistrationDate)
    {
        return $this->firstRegistrationDate = $firstRegistrationDate;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getRTOLocationCode()
    {
        return $this->RTOLocationCode;
    }

    /**
     * @param mixed $RTOLocationCode
     *
     * @return self
     */
    public function setRTOLocationCode($RTOLocationCode)
    {
        $this->RTOLocationCode = $RTOLocationCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getVehicleCode()
    {
        return $this->vehicleCode;
    }

    /**
     * @param mixed $vehicleCode
     *
     * @return self
     */
    public function setVehicleCode($vehicleCode)
    {
        $this->vehicleCode = $vehicleCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrevPolicyEndDate()
    {
        return $this->prevPolicyEndDate;
    }

    /**
     * @param mixed $prevPolicyEndDate
     *
     * @return self
     */
    public function setPrevPolicyEndDate($prevPolicyEndDate)
    {
        $this->prevPolicyEndDate = $prevPolicyEndDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getManufacturerCode()
    {
        return $this->manufacturerCode;
    }

    /**
     * @param mixed $manufacturerCode
     *
     * @return self
     */
    public function setManufacturerCode($manufacturerCode)
    {
        $this->manufacturerCode = $manufacturerCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getExshowroomPrice()
    {
        return $this->exshowroomPrice;
    }

    /**
     * @param mixed $exshowroomPrice
     *
     * @return self
     */
    public function setExshowroomPrice($exshowroomPrice)
    {
        $this->exshowroomPrice = $exshowroomPrice;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIdvAmount()
    {
        return $this->idv_amount;
    }

    /**
     * @param mixed $idv_amount
     *
     * @return self
     */
    public function setIdvAmount($idv_amount)
    {
        $this->idv_amount = $idv_amount;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIdvAmountMin()
    {
        return $this->idv_amount_min;
    }

    /**
     * @param mixed $idv_amount_min
     *
     * @return self
     */
    public function setIdvAmountMin($idv_amount_min)
    {
        $this->idv_amount_min = $idv_amount_min;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIdvAmountMax()
    {
        return $this->idv_amount_max;
    }

    /**
     * @param mixed $idv_amount_max
     *
     * @return self
     */
    public function setIdvAmountMax($idv_amount_max)
    {
        $this->idv_amount_max = $idv_amount_max;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getExshowroomPriceMin()
    {
        return $this->exshowroomPrice_min;
    }

    /**
     * @param mixed $exshowroomPrice_min
     *
     * @return self
     */
    public function setExshowroomPriceMin($exshowroomPrice_min)
    {
        $this->exshowroomPrice_min = $exshowroomPrice_min;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getExshowroomPriceMax()
    {
        return $this->exshowroomPrice_max;
    }

    /**
     * @param mixed $exshowroomPrice_max
     *
     * @return self
     */
    public function setExshowroomPriceMax($exshowroomPrice_max)
    {
        $this->exshowroomPrice_max = $exshowroomPrice_max;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCustType()
    {
        return $this->custType;
    }

    /**
     * @param mixed $custType
     *
     * @return self
     */
    public function setCustType($custType)
    {
        $this->custType = $custType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCustAge()
    {
        return $this->custAge;
    }

    /**
     * @param mixed $custAge
     *
     * @return self
     */
    public function setCustAge($custAge)
    {
        $this->custAge = $custAge;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getManufacturingYear()
    {
        return $this->manufacturingYear;
    }

    /**
     * @param mixed $manufacturingYear
     *
     * @return self
     */
    public function setManufacturingYear($manufacturingYear)
    {
        $this->manufacturingYear = $manufacturingYear;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrePolicyEndDate()
    {
        return $this->prePolicyEndDate;
    }

    /**
     * @param mixed $prePolicyEndDate
     *
     * @return self
     */
    public function setPrePolicyEndDate($prePolicyEndDate)
    {
        $this->prePolicyEndDate = $prePolicyEndDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsPrevClaim()
    {
        return $this->isPrevClaim;
    }

    /**
     * @param mixed $isPrevClaim
     *
     * @return self
     */
    public function setIsPrevClaim($isPrevClaim)
    {
        $this->isPrevClaim = $isPrevClaim;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrevDiscount()
    {
        return $this->prevDiscount;
    }

    /**
     * @param mixed $prevDiscount
     *
     * @return self
     */
    public function setPrevDiscount($prevDiscount)
    {
        $this->prevDiscount = $prevDiscount;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getElecnoofemployeesticalAcc()
    {
        return $this->elecnoofemployeesticalAcc;
    }

    /**
     * @param mixed $elecnoofemployeesticalAcc
     *
     * @return self
     */
    public function setElecnoofemployeesticalAcc($elecnoofemployeesticalAcc)
    {
        $this->elecnoofemployeesticalAcc = $elecnoofemployeesticalAcc;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNonElecticalAcc()
    {
        return $this->nonElecticalAcc;
    }

    /**
     * @param mixed $nonElecticalAcc
     *
     * @return self
     */
    public function setNonElecticalAcc($nonElecticalAcc)
    {
        $this->nonElecticalAcc = $nonElecticalAcc;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLpgCngkit()
    {
        return $this->lpg_cngkit;
    }

    /**
     * @param mixed $lpg_cngkit
     *
     * @return self
     */
    public function setLpgCngkit($lpg_cngkit)
    {
        $this->lpg_cngkit = $lpg_cngkit;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPaiddriversi()
    {
        return $this->paiddriversi;
    }

    /**
     * @param mixed $paiddriversi
     *
     * @return self
     */
    public function setPaiddriversi($paiddriversi)
    {
        $this->paiddriversi = $paiddriversi;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getUnnamedsi()
    {
        return $this->unnamedsi;
    }

    /**
     * @param mixed $unnamedsi
     *
     * @return self
     */
    public function setUnnamedsi($unnamedsi)
    {
        $this->unnamedsi = $unnamedsi;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNoofemployees()
    {
        return $this->noofemployees;
    }

    /**
     * @param mixed $noofemployees
     *
     * @return self
     */
    public function setNoofemployees($noofemployees)
    {
        $this->noofemployees = $noofemployees;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNooflldrivers()
    {
        return $this->nooflldrivers;
    }

    /**
     * @param mixed $nooflldrivers
     *
     * @return self
     */
    public function setNooflldrivers($nooflldrivers)
    {
        $this->nooflldrivers = $nooflldrivers;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getOccupationtype()
    {
        return $this->occupationtype;
    }

    /**
     * @param mixed $occupationtype
     *
     * @return self
     */
    public function setOccupationtype($occupationtype)
    {
        $this->occupationtype = $occupationtype;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPaCoverOwnerDriver()
    {
        return $this->pa_cover_owner_driver;
    }

    /**
     * @param mixed $pa_cover_owner_driver
     *
     * @return self
     */
    public function setPaCoverOwnerDriver($pa_cover_owner_driver)
    {
        $this->pa_cover_owner_driver = $pa_cover_owner_driver;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNumIsRti()
    {
        return $this->num_is_rti;
    }

    /**
     * @param mixed $num_is_rti
     *
     * @return self
     */
    public function setNumIsRti($num_is_rti)
    {
        $this->num_is_rti = $num_is_rti;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNumIsEmrAsstCvr()
    {
        return $this->num_is_emr_asst_cvr;
    }

    /**
     * @param mixed $num_is_emr_asst_cvr
     *
     * @return self
     */
    public function setNumIsEmrAsstCvr($num_is_emr_asst_cvr)
    {
        $this->num_is_emr_asst_cvr = $num_is_emr_asst_cvr;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNumIsZeroDept()
    {
        return $this->num_is_zero_dept;
    }

    /**
     * @param mixed $num_is_zero_dept
     *
     * @return self
     */
    public function setNumIsZeroDept($num_is_zero_dept)
    {
        $this->num_is_zero_dept = $num_is_zero_dept;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTxtPlanType()
    {
        return $this->txt_plan_type;
    }

    /**
     * @param mixed $txt_plan_type
     *
     * @return self
     */
    public function setTxtPlanType($txt_plan_type)
    {
        $this->txt_plan_type = $txt_plan_type;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNumIsEmrAsstWiderCvr()
    {
        return $this->num_is_emr_asst_wider_cvr;
    }

    /**
     * @param mixed $num_is_emr_asst_wider_cvr
     *
     * @return self
     */
    public function setNumIsEmrAsstWiderCvr($num_is_emr_asst_wider_cvr)
    {
        $this->num_is_emr_asst_wider_cvr = $num_is_emr_asst_wider_cvr;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsNcbProtection()
    {
        return $this->is_ncb_protection;
    }

    /**
     * @param mixed $is_ncb_protection
     *
     * @return self
     */
    public function setIsNcbProtection($is_ncb_protection)
    {
        $this->is_ncb_protection = $is_ncb_protection;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsEngineGearBoxProtection()
    {
        return $this->is_engine_gear_box_protection;
    }

    /**
     * @param mixed $is_engine_gear_box_protection
     *
     * @return self
     */
    public function setIsEngineGearBoxProtection($is_engine_gear_box_protection)
    {
        $this->is_engine_gear_box_protection = $is_engine_gear_box_protection;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsCostOfConsumable()
    {
        return $this->is_cost_of_consumable;
    }

    /**
     * @param mixed $is_cost_of_consumable
     *
     * @return self
     */
    public function setIsCostOfConsumable($is_cost_of_consumable)
    {
        $this->is_cost_of_consumable = $is_cost_of_consumable;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsLossOfUseDownProtection()
    {
        return $this->is_loss_of_use_down_protection;
    }

    /**
     * @param mixed $is_loss_of_use_down_protection
     *
     * @return self
     */
    public function setIsLossOfUseDownProtection($is_loss_of_use_down_protection)
    {
        $this->is_loss_of_use_down_protection = $is_loss_of_use_down_protection;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPrevPolicyStartDate()
    {
        return $this->prevPolicyStartDate;
    }

    /**
     * @param mixed $prevPolicyStartDate
     *
     * @return self
     */
    public function setPrevPolicyStartDate($prevPolicyStartDate)
    {
        $this->prevPolicyStartDate = $prevPolicyStartDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getElecticalAcc()
    {
        return $this->electicalAcc;
    }

    /**
     * @param mixed $electicalAcc
     *
     * @return self
     */
    public function setElecticalAcc($electicalAcc)
    {
        $this->electicalAcc = $electicalAcc;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPolicyEndDate()
    {
        return $this->policyEndDate;
    }

    /**
     * @param mixed $policyEndDate
     *
     * @return self
     */
    public function setPolicyEndDate($policyEndDate)
    {
        $this->policyEndDate = $policyEndDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getODValue()
    {
        return $this->ODValue;
    }

    /**
     * @param mixed $ODValue
     *
     * @return self
     */
    public function setODValue($ODValue)
    {
        $this->ODValue = $ODValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTPValue()
    {
        return $this->TPValue;
    }

    /**
     * @param mixed $TPValue
     *
     * @return self
     */
    public function setTPValue($TPValue)
    {
        $this->TPValue = $TPValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNCBValue()
    {
        return $this->NCBValue;
    }

    /**
     * @param mixed $NCBValue
     *
     * @return self
     */
    public function setNCBValue($NCBValue)
    {
        $this->NCBValue = $NCBValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPAValue()
    {
        return $this->PAValue;
    }

    /**
     * @param mixed $PAValue
     *
     * @return self
     */
    public function setPAValue($PAValue)
    {
        $this->PAValue = $PAValue;

        return $this;
    }

    /**
     * @param mixed $IDV
     *
     * @return self
     */
    public function setIDV($IDV)
    {
        $this->IDV = $IDV;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPremiumValue()
    {
        return $this->PremiumValue;
    }

    /**
     * @param mixed $PremiumValue
     *
     * @return self
     */
    public function setPremiumValue($PremiumValue)
    {
        $this->PremiumValue = $PremiumValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getServiceTaxValue()
    {
        return $this->ServiceTaxValue;
    }

    /**
     * @param mixed $ServiceTaxValue
     *
     * @return self
     */
    public function setServiceTaxValue($ServiceTaxValue)
    {
        $this->ServiceTaxValue = $ServiceTaxValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getZERODEPValue()
    {
        return $this->ZERODEPValue;
    }

    /**
     * @param mixed $ZERODEPValue
     *
     * @return self
     */
    public function setZERODEPValue($ZERODEPValue)
    {
        $this->ZERODEPValue = $ZERODEPValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getFinalValue()
    {
        return $this->FinalValue;
    }

    /**
     * @param mixed $FinalValue
     *
     * @return self
     */
    public function setFinalValue($FinalValue)
    {
        $this->FinalValue = $FinalValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEPValue()
    {
        return $this->EPValue;
    }

    /**
     * @param mixed $EPValue
     *
     * @return self
     */
    public function setEPValue($EPValue)
    {
        $this->EPValue = $EPValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRTIValue()
    {
        return $this->RTIValue;
    }

    /**
     * @param mixed $RTIValue
     *
     * @return self
     */
    public function setRTIValue($RTIValue)
    {
        $this->RTIValue = $RTIValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEnable()
    {
        return $this->enable;
    }

    /**
     * @param mixed $enable
     *
     * @return self
     */
    public function setEnable($enable)
    {
        $this->enable = $enable;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNCBDiscount()
    {
        return $this->NCBDiscount;
    }

    /**
     * @param mixed $NCBDiscount
     *
     * @return self
     */
    public function setNCBDiscount($NCBDiscount)
    {
        $this->NCBDiscount = $NCBDiscount;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getODDiscount()
    {
        return $this->ODDiscount;
    }

    /**
     * @param mixed $ODDiscount
     *
     * @return self
     */
    public function setODDiscount($ODDiscount)
    {
        $this->ODDiscount = $ODDiscount;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPremiumBreakupFromat()
    {
        return $this->premium_breakup_fromat;
    }

    /**
     * @param mixed $premium_breakup_fromat
     *
     * @return self
     */
    public function setPremiumBreakupFromat($premium_breakup_fromat)
    {
        $this->premium_breakup_fromat = $premium_breakup_fromat;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLLValue()
    {
        return $this->LLValue;
    }

    /**
     * @param mixed $LLValue
     *
     * @return self
     */
    public function setLLValue($LLValue)
    {
        $this->LLValue = $LLValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getAddon()
    {
        return $this->addon;
    }

    /**
     * @param mixed $addon
     *
     * @return self
     */
    public function setAddon($addon)
    {
        $this->addon = $addon;

        return $this;
    }

  /**
     * @return mixed
     */
    public function getAddonMap()
    {
        return $this->addon_map;
    }

    /**
     * @param mixed $addon_map
     *
     * @return self
     */
    public function setAddonMap($addon_map)
    {
        $this->addon_map = $addon_map;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRSACValue()
    {
        return $this->RSACValue;
    }

    /**
     * @param mixed $RSACValue
     *
     * @return self
     */
    public function setRSACValue($RSACValue)
    {
        $this->RSACValue = $RSACValue;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPAPASSValue()
    {
        return $this->PAPASSValue;
    }

    /**
     * @param mixed $PAPASSValue
     *
     * @return self
     */
    public function setPAPASSValue($PAPASSValue)
    {
        $this->PAPASSValue = $PAPASSValue;

        return $this;
    }
}
