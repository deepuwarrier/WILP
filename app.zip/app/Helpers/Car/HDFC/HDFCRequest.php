<?php
namespace App\Helpers\Car\HDFC;
use App\Helpers\Car\CarHelper;
use App\Models\Car as M;
use App\Libraries\CarLib;
use App\Constants\Car_Constants;

class HDFCRequest {

	public  $defaultVal = ['Policy_Type' => 'C'
   ,'IsAgeDisc' => 'N'
   ,'Data1' => 'CC'
   ,'IsCustomerAuthenticationDone'=>1
   ,'AuthenticationType'=>'OTP'
   ,'UIDNo' => '03685'
   ,'Occupation_Type' => "0"
   ,'No_of_LLdrivers'=>0
	   ,'Contactno_Home'=>''
	   ,'Contactno_Mobile'=>''
	   ,'Electical_Acc'=>0
	   ,'NonElectical_Acc'=>0
	   ,'LPG-CNG_Kit'=>0
      ];

	public function __construct(HDFCProposalManager $manager){
		$this->manager = $manager;
	}

	public function setData($suid,$user_data){
		$car_helper = new CarHelper;
		$car_lib = new CarLib;
		$car_rto = new M\CarRto;
		$car_make = new M\CarMake;
		$car_variant = new M\CarVariant;
		if($user_data['is_prev_zerodep'] == 'N'){
			$covers = explode(',',$user_data->covers_selected);
			if(in_array('ZERODEP',$covers))
				$user_data = $this->manager->excludingZeroDept($user_data);
		}

		$req = $car_helper->grabDetails($this->dbToProposalMap()
										,$user_data);
		// required on time of breakin
		if(isset($user_data->veh_vehicle_financed) && $user_data->veh_vehicle_financed){
			if($user_data->veh_vehicle_financed == 'Y')
				$req['Name_Financial_Institution'] = 
			$car_helper->getMasterId($this->manager->refrel_col,'Financier',$user_data['veh_financierName']);
		}
		
		if($user_data->policy_exp_status){
			$city_code = (isset($user_data->prem_usr_city_code) && $user_data->prem_usr_city_code) ?
				$user_data->prem_usr_city_code :  $req['Car_Citycode'];
			$req['LocationCode'] = $car_helper->getMasterId($this->manager->refrel_col,'BreakinLocation',$city_code);
		}

		if(strtotime($req['Policy_Startdate']) < strtotime(date('Y-m-d')))
			$req['Policy_Startdate'] = date('Y-m-d', strtotime(date('Y-m-d')));
		
		$req['Policy_Startdate'] = '26/01/2019';//date('Y-m-d', strtotime(date('Y-m-d')));
		
		
		$rtoDb = $car_rto->getRTOData($user_data->car_rto,['hdfc_code','hdfc_name']);
		$req['Registration_Citycode'] = $rtoDb->hdfc_code;
		$req['Registration_City'] = $rtoDb->hdfc_name;

		$req['Policy_Enddate'] = '25/01/2020';//$user_data->policy_type_selection == 1 ? $car_helper->manDate($req['Policy_Startdate'],'d-m-Y',['+1 year','-1 day']) : $car_helper->manDate($req['Policy_Startdate'],'d-m-Y',['+3 year','-1 day']);
		
		$req['Premium_Year'] = $user_data->policy_type_selection == 1 ? '1' : '3';

		$req['PrePolicy_Startdate'] = $car_helper->manDate($req['PrePolicy_Enddate'],'d-m-Y',['-1 year','+1 day']);
		$req['CustAge'] =  date('Y')-date('Y',strtotime($req['Date_of_Birth']));
		$req['AgentCode'] = $this->manager->agent_code;
		$req['Manufacturer_Code'] = $car_make->getMakeId($user_data->car_make,$this->manager->new_refrel_col);
		$req['Car_City'] = $car_helper->getMasterName('City',$req['Car_Citycode']);
		$req['Car_State'] = $car_helper->getMasterName('State',$req['Car_Statecode']);
	    $req['Vehicle_Modelcode'] = $car_variant->getVehicleId($user_data->car_variant,$this->manager->new_refrel_col)->hdfc_code; 
	    $req['Car_Citycode'] = $car_helper->getMasterId($this->manager->refrel_col,'City',$req['Car_Citycode']);
		$req['Car_Statecode'] = $car_helper->getMasterId($this->manager->refrel_col,'State',$req['Car_Statecode']);
		$req['Owner_Driver_Nominee_Relationship'] = $car_helper->getMasterName('NomineeRelationship',$req['Owner_Driver_Nominee_Relationship']);
		
		$req['Registration_City'] = $req['Car_City'];
		if($user_data->reg_add_is_same == 'N'){
			$req['Corres_City'] = $car_helper->getMasterName('City',$user_data->prem_usr_city_code);
			$req['Corres_State'] =  $car_helper->getMasterName('State',$user_data->prem_usr_state_code);
			$req['Corres_Statecode'] = $car_helper->getMasterId($this->manager->refrel_col,'State',$user_data->prem_usr_state_code);
			$req['Corres_Citycode']  = $car_helper->getMasterId($this->manager->refrel_col,'City',$user_data->prem_usr_city_code);
			$req['Corres_Pin'] = $user_data->prem_usr_pincode;
			$req['Corres_Address1'] =  $user_data->prem_usr_houseno;
			$req['Corres_Address2'] = $user_data->prem_usr_street;
			$req['Corres_Address3'] = $user_data->prem_usr_locality;
		}else{
			$req['Corres_Statecode'] = $req['Car_Statecode'];
			$req['Corres_Citycode'] = $req['Car_Citycode'];
			$req['Corres_State'] = $req['Car_State'];
			$req['Corres_City'] = $req['Car_City'];	

		}

		foreach ($this->defaultVal as $key => $value) {
			if(!isset($req[$key]) || !$req[$key])
				$req[$key] = $value;
		}
		$req['Gender'] = ($req['Gender'] == 'M') ? 'Male' : 'Female';
		$req['Vehicle_Regno'] = strtoupper($user_data->veh_reg_no);
		// chnage date formate
		$req['Purchase_Regndate'] = $car_helper->changeFormat($req['Purchase_Regndate'],'d/m/Y');
		$req['Date_of_Birth'] = $car_helper->changeFormat($req['Date_of_Birth'],'d/m/Y');
		$req['Policy_Startdate'] = $car_helper->changeFormat($req['Policy_Startdate'],'d/m/Y');
		$req['Policy_Enddate'] = $car_helper->changeFormat($req['Policy_Enddate'],'d/m/Y');
		
		if(strtolower($req['Type_of_Business']) == 'new business'){
			$req['NCB_ExpiringPolicy'] = 0;
			$req['NCB_RenewalPolicy'] = 0;	
			$req['Year_of_Manufacture'] = $req['Purchase_Regndate'];
			$req['PrePolicy_Startdate'] = '01/01/1900';
			$req['PrePolicy_Enddate'] = '01/01/1900';
			$req['Vehicle_Regno'] = 'NEW';
			unset($req['PreInsurerCode']);
			unset($req['PrePolicy_Number']);
			unset($req['PrePolicy_Startdate']);
			unset($req['PrePolicy_Enddate']);
		}else{
			$req['PrePolicy_Startdate'] = $car_helper->changeFormat($req['PrePolicy_Startdate'],'d/m/Y');
			$req['PrePolicy_Enddate'] =  $car_helper->changeFormat($req['PrePolicy_Enddate'],'d/m/Y');
			$req['Year_of_Manufacture'] = (strtotime($car_helper->changeFormat($req['Purchase_Regndate'],'d-m-Y')
			) < strtotime($car_helper->changeFormat($req['PrePolicy_Startdate'],'d-m-Y')))
				 ?  $req['Purchase_Regndate'] : $req['PrePolicy_Startdate'];

			if($user_data->policy_exp_status != 2){
				$req['IsPrevious_Claim'] = ($user_data->claim == 'N')? 1 : 0;
			    $req['PreInsurerCode'] = $car_helper->getMasterId($this->manager->refrel_col,'Insurer',$req['PreInsurerCode']);	
			}else{
				$req['IsPrevious_Claim'] = '';
				$req['PreInsurerCode'] = '';
				$req['PrePolicy_Number'] = '';
				$req['PrePolicy_Startdate'] = '01/01/1900';
				$req['PrePolicy_Enddate'] = '01/01/1900';
			}
		}
		
		//$req['Ex-showroom_Price'] = 566153;
		if($req['Vehicle_Ownedby'] == "O"){
			$req['First_Name'] = $user_data->usr_companyname;
			$req['Last_Name'] = $user_data->usr_contactperson;
		}
		
		$not_to_parse = ['Gender','Manufacturer_Code','Vehicle_Modelcode','Engine_No','Chassis_No','PreInsurerCode','PrePolicy_Number','AgentCode'];

		if(isset($this->req_prem)){
			$req['Service_Tax'] = round(($user_data->final_premium*Car_Constants::GST
				/(Car_Constants::GST+100)));
			$req['Total_Premium'] = round($user_data->final_premium - $req['Service_Tax']);
			$req['Total_Amoutpayable'] = $user_data->final_premium;
		}
		$req['Service_Tax'] = round((($req["Total_Premium"] * Car_Constants::GST) / 100));
		$this->req = $car_lib->parseDataInUpperCase((array)$req,$not_to_parse);
		if($user_data->covers_selected != ''){
			$covers = explode(',',$user_data->covers_selected);
			if(in_array('EP',$covers))	
				$this->req['AddOnCovers']['is_engine_gear_box_protection'] = 1;
			if(in_array('ZERODEP',$covers)){
				$this->req['IsZeroDept_Cover'] = 1;
				$this->req['IsZeroDept_RollOver'] = 1;
				$this->req['IsEmergency_Cover'] = 0;
				$this->req['num_is_emr_asst_wider_cvr'] = 0;
			}
			if(in_array('RTI',$covers))
				$this->req['IsRTICover'] = 1;
			if(in_array('RSAC',$covers))
				$this->req['IsEmergency_Cover'] = 1;
			
			if(in_array('PAPASS',$covers))
				$this->req['Unnamed_Si'] = 100000;
		}

		if($user_data->idv_opted){
			$this->req['Sum_Insured'] = $user_data->idv_opted;
		}else{
			$this->req['Sum_Insured'] = $user_data->idv_calculated;
		}

	}

	private function dbToProposalMap(){
		return ['Year_of_Manufacture' => 'veh_yom',
				'Manufacturer_Code' => 'car_make',
				'Vehicle_Modelcode' => 'car_model',
				'Purchase_Regndate' => 'car_registration_date',
				'Engine_No' => 'veh_eng_no',
				'Chassis_No' => 'veh_chassisno',
				'Manufacture_Name' => 'make_name',
				'Fuel_Type' =>  'car_fuel',
				'Electical_Acc' => 'veh_electricle',
				'NonElectical_Acc' => 'veh_no_electricle',
				'PrePolicy_Enddate' => 'policy_expiry_date',
				'PreInsurerCode' => 'prev_insurance',
				'PrePolicy_Number' => 'prev_policyno',
				'IsPrevious_Claim' => 'prev_claim',
				'First_Name' => 'usr_firstname',
				'Last_Name' => 'usr_lastname',
				'Date_of_Birth' => 'usr_dob',
				'Gender' => 'usr_gender',
				'Email_Id' => 'usr_email',
				'Contactno_Mobile' => 'usr_mobile',
				'Car_Address1' => 'usr_houseno',
				'Car_Address2' => 'usr_street',
				'Car_Address3' => 'usr_locality',
				'Corres_Address1' => 'usr_houseno',
				'Corres_Address2' => 'usr_street',
				'Corres_Address3' => 'usr_locality',
				'Car_Pin' => 'usr_pincode',
				'Corres_Pin' => 'usr_pincode',
				'Car_Citycode' => 'usr_city_code',
				'Car_Statecode' => 'usr_state_code',
				'PAN_Card' => 'usr_pan',
				'Type_of_Business' => 'type_of_business',
				'Policy_Startdate' => 'policy_start_date',
				'Occupation_Type' => 'usr_occupation',
				'Vehicle_Ownedby' => 'usr_type',
				'Total_Premium' =>  'netPremium',
				'Service_Tax' => 'tax',
				'Total_Amoutpayable' => 'totalpremium',
				'Owner_Driver_Nominee_Name' => 'nominee_name',
				'Owner_Driver_Nominee_Age' =>  'nominee_age',
				'Owner_Driver_Nominee_Relationship' => 'nominee_rel',
				'Vehicle_Model' => 'model_name',
				'Ex-showroom_Price' => 'ex_showroom_price_id',
				'Sum_Insured' => 'idv_opted',
				'NCB_ExpiringPolicy' => 'ncb',
				'NCB_RenewalPolicy' => 'new_ncb',
			];
	}
}
