<?php
namespace App\Helpers\Car;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;

Class PremiumBreakup {

    public $display_name = ['od'=> 'Own Damage'
                ,'ll' => 'Legal Liability'
                ,'pa' => 'Personal Accident'
                ,'tp' => 'Third Party Liability'
                ,'rti' => 'Return to Invoice'
                ,'zerodep' => 'Zero Depreciation'
                ,'ep' => 'Engine Protect'
                ,'papass'=>'PA to Unnamed Passengers (1 Lac)'
                ,'rsac'=>'Enhanced Roadside Assistance'
                ,'od_discount' => 'OD Discount'
                ,'ncbbenefit' => 'No Claim Bonus'
                ,'totalpremium' => 'Total Premium'
                ,'serviceTax' => 'Goods & Service Tax'
                ,'netPremium' => 'Net Premium' 
                ,'daily_allowance' =>'Daily Allowance '
                ,'et_hotelexpenses'=>'Emergency Hotel & Transportation'
                ,'keyreplace'=>'Key Replacement'
                ,'repair_of_glass'=>'Repair of glass, plastic fibre and rubber glass'
                ,'cosumable_expenses'=>'Comsumable Expenses'
                ,'lpb'=>'Loss of Personal Belongings'
                ,'ts' => 'Tyre Secure'     
            ];

    public $dafault_format  = ['basic' => ['od','tp','ll', 'pa']
                            , 'addon' => ['rti', 'zerodep','papass','ep','rsac','lpb','et_hotelexpenses','cosumable_expenses','keyreplace','repair_of_glass','ts']
                            , 'discounts' => ['ncbbenefit', 'od_discount']
                            , 'totalpremium'
                            , 'serviceTax'
                            , 'netPremium'];

    public $od_value = NULL;
    public $tp_value = NULL;
    public $ll_value = NULL;
    public $pa_value = NULL;
    public $rti_value = NULL;
    public $zerodep_value = NULL;
    public $ep_value = NULL;
    public $rsac_value = NULL;
    public $papass_value = NULL;

    public $lpb_value = NULL;
    public $et_hotelexpenses_value = NULL;
    public $cosumable_expenses_value = NULL;
    public $keyreplace_value = NULL;
    public $repair_of_glass_value = NULL;
    public $ts_value = NULL;

    public $ncbbenefit_value = NULL;
    public $odbenefit_value = NULL;
    public $totalpremium_value = NULL;
    public $serviceTax_value = NULL;
    public $netPremium_value = NULL;

    public function getDefaultFormat(){
        return $this->dafault_format;
    }

    public function getDispayName($key = null){
        if(isset($key))
            return $this->display_name[$key];

        return $this->display_name;
    }

    public function setDispayName($display_name,$key = null){
        if(!is_array($display_name))
            return false;

        if(isset($key))
            $this->display_name[$key] = $display_name;
        
        $this->display_name = $display_name;
    }

    public function setPbDatat($pb_data){

        // set basic 
        $this->setOdValue($pb_data->getOdPremium());
        $this->setTpValue($pb_data->getTpPremium());

        // set discount
        if($pb_data->getNcbDiscount())
            $this->setNcbbenefit($pb_data->getNcbDiscount());
       
        $this->setOdbenefit($pb_data->getOdDiscount());

        // set pa and ll
        if($pb_data->getPaPremium())
            $this->setPaValue($pb_data->getPaPremium());

        if($pb_data->getLlPremium())
            $this->setLlValue($pb_data->getLlPremium());

        // set addon
        if($pb_data->getEpPremium())
            $this->setEpValue($pb_data->getEpPremium());
        
        if($pb_data->getPaPassPremium())
            $this->setPapassValue($pb_data->getPaPassPremium());
        
        if($pb_data->getRsacPremium())
            $this->setRsacValue($pb_data->getRsacPremium());
        
        if($pb_data->getRtiPremium())
            $this->setRtiValue($pb_data->getRtiPremium());
        
        if($pb_data->getZerodepPremium())
            $this->setZerodepValue($pb_data->getZerodepPremium());

        if($pb_data->getKeyreplacePremium())
            $this->setKeyreplaceValue($pb_data->getKeyreplacePremium());

        if($pb_data->getLpbPremium())
            $this->setLpbValue($pb_data->getLpbPremium());

        if($pb_data->getRepairOfGlassPremium() || (is_string($pb_data->getRepairOfGlassPremium())))
            $this->setRepairOfGlassValue($pb_data->getRepairOfGlassPremium());

        if($pb_data->getEtHotelexpenses())
            $this->setEtValue($pb_data->getEtHotelexpenses());

        if($pb_data->getCosumableExpenses())
            $this->setCosumableValue($pb_data->getCosumableExpenses());

        if($pb_data->getTsPremium())
            $this->setTsValue($pb_data->getTsPremium());

        // set premium
        $this->setTotalpremiumValue($pb_data->getTotalPremium());
        $this->setNetPremiumValue($pb_data->getGrossPremium());
        $this->setServiceTaxValue($pb_data->getServiceTax());

    }

    public function addInPBFormat($property,$key_name,$pb_format){
        if (isset($this->$property))
            $pb_format[$key_name] = $this->$property;
        else
            $pb_format[$key_name] = NULL;
        return $pb_format;    
    }

    public function assignValueInPB($pb_format,$array){

        foreach ($pb_format as $key => $value) {
            if(!is_array($value)){
                $key_ = $value.'_value';
                $array = $this->addInPBFormat($key_,$value,$array);
            }else{
                $array[$key] = $this->assignValueInPB($value,[]);
            }
        }
        return $array;
    }

    public function applyDisplayName($pb_format,$array){
        foreach ($pb_format as $key => $values) {
            if(!isset($values))
                continue;

            if (!is_array($values) && isset($values)){
                $array[$key]['displayName'] = $this->getDispayName($key); 
                $array[$key]['basic_premium'] = $values;
            }
            else
                $array[$key] = $this->applyDisplayName($values,[]);
        }
        return $array;
    }

    public function genratePremiumBreakup($pb_format = null){
        // dd($this);
        if(!isset($pb_format))
            $pb_format = $this->getDefaultFormat($pb_format);
        
        $pb_format = $this->assignValueInPB($pb_format,[]);
        
        $pb_format['discounts']['od_discount'] = $this->getOdbenefit();
        
        $premium_breakup = $this->applyDisplayName($pb_format,[]);
        
        unset($pb_format);
        return $premium_breakup;
    }

    public function getOdValue() {
        return $this->od_value;
    }

    public function setOdValue($od_value) {
        $this->od_value = $od_value;

        return $this;
    }

    public function getTpValue() {
        return $this->tp_value;
    }

    public function setTpValue($tp_value) {
        $this->tp_value = $tp_value;

        return $this;
    }

    public function getLlValue() {
        return $this->ll_value;
    }

    public function setLlValue($ll_value) {
        $this->ll_value = $ll_value;

        return $this;
    }

    public function getPaValue() {
        return $this->pa_value;
    }

    public function setPaValue($pa_value) {
        $this->pa_value = $pa_value;

        return $this;
    }

    public function getRtiValue() {
        return $this->rti_value;
    }

    public function setRtiValue($rti_value) {
        $this->rti_value = $rti_value;
        return $this;
    }

    public function getZerodepValue() {
        return $this->zerodep_value;
    }

    public function setZerodepValue($zerodep_value) {
        $this->zerodep_value = $zerodep_value;
        return $this;
    }

    public function getEpValue() {
        return $this->ep_value;
    }

    public function setEpValue($ep_value) {
        $this->ep_value = $ep_value;
        return $this;
    }

    public function getRsacValue() {
        return $this->rsac_value;
    }

    public function setRsacValue($rsac_value) {
        $this->rsac_value = $rsac_value;
        return $this;
    }

    public function getPapassValue() {
        return $this->papass_value;
    }

    public function setPapassValue($papass_value) {
        $this->papass_value = $papass_value;
        return $this;
    }

    public function getNcbbenefit() {
        return $this->ncbbenefit_value;
    }

    public function setNcbbenefit($ncbbenefit) {
        $this->ncbbenefit_value = $ncbbenefit;
        return $this;
    }

    public function getOdbenefit() {
        return $this->odbenefit_value;
    }

    public function setOdbenefit($odbenefit) {
        $this->odbenefit_value = $odbenefit;
        return $this;
    }

    public function getTotalpremiumValue() {
        return $this->totalpremium_value;
    }

    public function setTotalpremiumValue($totalpremium_value) {
        $this->totalpremium_value = $totalpremium_value;
        return $this;
    }

    public function getServiceTaxValue() {
        return $this->serviceTax_value;
    }

    public function setServiceTaxValue($serviceTax_value) {
        $this->serviceTax_value = $serviceTax_value;
        return $this;
    }

    public function setNetPremiumValue($netPremium_value) {
        $this->netPremium_value = $netPremium_value;
        return $this;
    }

    public function getNetPremiumValue(){
        return $this->netPremium_value;
    }


    /**
     * @return mixed
     */
    public function getLpbValue()
    {
        return $this->lpb_value;
    }

    /**
     * @param mixed $lpb_value
     *
     * @return self
     */
    public function setLpbValue($lpb_value)
    {
        $this->lpb_value = $lpb_value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEtValue()
    {
        return $this->et_hotelexpenses_value;
    }

    /**
     * @param mixed $et_value
     *
     * @return self
     */
    public function setEtValue($et_hotelexpenses_value)
    {
        $this->et_hotelexpenses_value = $et_hotelexpenses_value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCosumableValue()
    {
        return $this->cosumable_expenses_value;
    }

    /**
     * @param mixed $cosumable_value
     *
     * @return self
     */
    public function setCosumableValue($cosumable_expenses_value)
    {
        $this->cosumable_expenses_value = $cosumable_expenses_value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getKeyreplaceValue()
    {
        return $this->keyreplace_value;
    }

    /**
     * @param mixed $keyreplace_value
     *
     * @return self
     */
    public function setKeyreplaceValue($keyreplace_value)
    {
        $this->keyreplace_value = $keyreplace_value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRepairOfGlassValue()
    {
        return $this->repair_of_glass_value;
    }

    /**
     * @param mixed $repair_of_glass_value
     *
     * @return self
     */
    public function setRepairOfGlassValue($repair_of_glass_value)
    {
        $this->repair_of_glass_value = $repair_of_glass_value;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTsValue()
    {
        return $this->ts_value;
    }

    /**
     * @param mixed $ts_value
     *
     * @return self
     */
    public function setTsValue($ts_value)
    {
        $this->ts_value = $ts_value;

        return $this;
    }
}
