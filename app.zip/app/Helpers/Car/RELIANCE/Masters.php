<?php
namespace App\Helpers\Car\RELIANCE;

Class Masters{

	private $system_name = ["Customer"=>0,
							"Agent"=>1];

	private $client_type = ["Individual"=>0,
							"Corporate"=>1];

	private $fuel_type = ["petrol"=>1,
							"diesel"=>2,
							"cng"=>3,
							"lpg"=>4,
							"bifuel"=>5,
							"battery"=>6,
							"none"=>0,
							"na"=>7];

	private $prev_policy_type = ['Package'=>1,
								'StandaloneTP'=>2,
								'Fire'=>3,
								'Fire&theft'=>4,
								];

	private $ncb_criteria = ['y'=>1,
							'n'=>2
							];

	private $ncb = [0 =>	0,
					20=>	1,
					25=>	2,
					35=>	3,
					45=>	4,
					50=>	5,
					55=>	6,
					65=>	7];

	private $salulation  = ['M'=>'Mr',
							'F'=>'Miss',
							'D'=>'Dr',
							'C'=>'M/S'];
    
    public function getFuelTypeId($fuel){
        if(!array_key_exists($fuel,$this->fuel_type))
            return 0;
        return $this->fuel_type[$fuel];
    }

    public function getPrevPolicyCriteria($key){
        if(!array_key_exists($key,$this->ncb_criteria))
            return 2;
        return $this->ncb_criteria[$key];
    }

    public function getNCBId($key){
        if(!array_key_exists($key,$this->ncb))
            return 0;
        return $this->ncb[$key];   
    }

    public function getClientType($user_type){
    	if($user_type == "I")
    		return $this->client_type['Individual'];

    	return $this->client_type['Corporate'];
    }

    public function getSalulation($gender,$client_type){
    	if($client_type == 1)
    		return $this->salulation['C'];

    	if(array_key_exists($gender,$this->salulation))
    		return $this->salulation[$gender];

    	return $this->salulation['D'];
    }


}

?>