<?php
namespace App\Helpers\Car\RELIANCE;

use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Libraries\CarLib;
use App\Constants\Car_Constants;
use App\Models\Car\CarTPolicy;

Class ProposalManager{
	
	public $refrel_code = 'reliance_code';
	
	//API Config
    private $proposal_url = 'http://rzonews.reliancegeneral.co.in/API/Service/ProposalCreationForMotor';
    private $payment_url = 'http://rzonews.reliancegeneral.co.in/PaymentIntegration/PaymentIntegration';
    private $policy_pdf_url = "http://rzonews.reliancegeneral.co.in/API/Service/GeneratePolicyschedule";

    private $curl_config = ['content-type'=>'application/xml','post-type'=>'xml'];

	public function __construct(){
		$this->car_helper = new CarHelper;
	}	

    public function getPolicyPdfUrl($policy_nu = NULL){
        return $this->policy_pdf_url."?PolicyNo=".$policy_nu."&ProductCode=2311";
    }

	public function genProposalRequest($user_data,$request){
        $request_obj = new ProposalRequest();
        $proposal_req = $request_obj->genrateRequest($user_data);
        $proposal_req = $this->car_helper->genrateXml("<PolicyDetails/>",$proposal_req)->asXml();
        return $proposal_req;
    }

    public function callApi($prop_request){
        $response = $this->car_helper->call_curl_api('RELIANCE Proposal',$this->proposal_url,$prop_request,$this->curl_config);
    	unset($prop_request);

    	return $response;
    }

    public function genProposalResponse($form_data,$response,$user_data){
        if(!is_array($response))
    		return 0;

    	$motor_policy = $response['data']['MotorPolicy'];

    	if(isset($motor_policy['ErrorMessages']) && $motor_policy['ErrorMessages'])
    		return ['error'=>$motor_policy['ErrorMessages']];

        $totalpremium = $user_data->totalpremium;
        
        // check premium allready missmatch
        if(array_key_exists('new_premium',$form_data))
            $totalpremium = $form_data['new_premium'];

        if($motor_policy['FinalPremium'] != $totalpremium){
            $user_data->final_premium = $motor_policy['FinalPremium'];
            $user_data->save();

            return ['error'=>'premium mismatch',
                    'premiumPayable'=>$motor_policy['FinalPremium'],
                    'passedPremium'=>$totalpremium];
        }

    	$user_data->quote_id = $motor_policy['QuoteNo'];
    	$user_data->proposal_nu = $motor_policy['ProposalNo'];
    	$user_data->save();

        $fields = ['ProposalNo'=>$user_data->proposal_nu,
                'UserID'=>'14BRG281B05',
                'PaymentType'=>1,
                'ProposalAmount'=>$totalpremium,
                'Responseurl'=> route('car.policy.reliance.returnPage')];

        return ['fields'=> $fields,
                'payment_url'=>$this->payment_url
            ];
    }
	public function getDbData($trans_code) {
    	$car_t_data = new CarTData;
		$this->field = $this->car_helper->getFieldMap();
		$user_data = $car_t_data->find($trans_code);
		$this->db = (!$user_data) ? [] : $user_data;
		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $this->field);
		$this->user_data['fullname'] = (isset($this->user_data['firstname']) && isset($this->user_data['lastname'])) ? $this->user_data['firstname'].' '.$this->user_data['lastname'] : '';

		if(!$this->user_data['regno']){
            $car_lib = new CarLib;
            $this->user_data['regno'] = $car_lib->parseRegistrationNumber($user_data['car_rto']).'-';
            unset($car_lib);
            unset($user_data);
        }
        unset($car_t_data);
        return $this->user_data;

	}

    public function parse_pgresp($payment_resp){
        $payment_resp = explode("|",$payment_resp['Output']);
        $payment_resp = ['Status ID' => $payment_resp[0],
            'Policy Number'=>$payment_resp[1],
            'Transaction Number'=>$payment_resp[2],
            'Optional value'=>$payment_resp[3],
            'Gateway Name'=>$payment_resp[4],
            'Proposal Number'=>$payment_resp[5],
            'Transaction Status'=>$payment_resp[6]];
        return $payment_resp;
    }

    public function store_payment_data($payment_resp){
        $trans_code = $this->car_helper->getSuid();
       
        $table = ['trans_code' => $trans_code,
                Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($payment_resp),
                Car_Constants::CAR_T_PROPOSALLOG['PROPOSAL_NU'] => 
                    $payment_resp['Proposal Number']
                ];
        
        $this->status = ($payment_resp['Status ID']) ? 1 : 0;
        
        if(isset($payment_resp['Policy Number']) && $payment_resp['Policy Number'] != ''){
            $table[Car_Constants::CAR_T_PROPOSALLOG['POLICY_NU']] = $payment_resp['Policy Number'];
            $table[Car_Constants::CAR_T_PROPOSALLOG['TRANSACTION_ID']] = $payment_resp['Transaction Number'];
            $this->setPolicyRefNo($payment_resp['Policy Number']);
        }

        return $table;
    }

	public function changeDateFormate($user_data) {
		if(!$user_data || empty($user_data))
			return 1;

		$field_name = $this->car_helper->getFieldName('PROPOSER', 'USR_DOB');
		$user_data[$field_name] = (isset($user_data[$field_name])) ?
		$this->car_helper->getFormDate($user_data[$field_name]) : null;
		unset($field_name);
		return $user_data;
	}

    // set policy refreance number
    public function setPolicyRefNo($no){
        $this->policy_ref_no = $no;
    }

    // retrived policy refreance number
    public function getPolicyRefNo(){
        return (isset($this->policy_ref_no))? $this->policy_ref_no : 0;
    }

    public function storeStatusAndTransaction($status,$trans_code = null){
        
        $car_lib = new CarLib;
        $car_t_data = new CarTData;
        $car_t_policy = new CarTPolicy;
        $t_status = ($status) ? 1 : 2;
        
        // store success or failed in databse
        $user_data = $car_lib->storeStatus($t_status,$trans_code);
        
        if ($user_data && $user_data->t_status != 'TS19') {
            return $user_data->t_status;
        }

        if ($user_data && 'TS19' == $user_data->t_status) {
            $user_data = $user_data->toArray();
            
            $user_data['trans_code'] = $trans_code.'_DONE';
            
            if($user_data['car_make'] && $user_data['car_model']){
                $car_t_policy->updateOrCreate(array('trans_code' =>
                $user_data['trans_code']),$user_data);
            }
        }
    }
}