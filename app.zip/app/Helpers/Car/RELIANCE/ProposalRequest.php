<?php
namespace App\Helpers\Car\RELIANCE;

use App\Helpers\Car\CarHelper;
use App\Helpers\Car\RELIANCE\Masters;
use App\Models\Car\CarTData;
use App\Models\Car\Data\MasterData;
use App\Libraries\CarLib;

Class ProposalRequest{
    
    public $refrel_code = 'reliance_code';
    public $branch_code = '9202';
    public $agent_name = 'Direct';
    public $product_code = "2311";
    public $other_system_name = "1";

    public function test(){
    	$user_data = CarTData::find('PC1802151018350390');
    	$this->genrateRequest($user_data);
    }

    


    public function genrateRequest($user_data){
        $this->helper =  new CarHelper();
        $this->master = new Masters();
        $this->master_db = new MasterData();
        
        // get sample request
        $this->proposal_request = file_get_contents(__DIR__.'/proposal_request.json');
        $this->proposal_request = json_decode($this->proposal_request);

        $this->variant_db = $this->master_db->getVariantData($user_data->car_variant,$this->refrel_code);
        $this->rto_db = $this->master_db->getRtoData($user_data->car_rto,['zone',$this->refrel_code]);

        // set real data
        $this->setClientDetails($user_data);
        $this->setPolicy($user_data);
        $this->setRisk($user_data);
        $this->setVehicle($user_data);
        $this->setPreviousInsuranceDetails($user_data);
        $this->setCovers($user_data);
        $this->setNCB($user_data);
    
        unset($this->helper);
        unset($this->master);
        unset($this->master_db);
        unset($this->variant_db);
        unset($this->rto_db);

        $request_json = json_encode($this->proposal_request);
        return json_decode($request_json,true);
    }    

    private function setClientDetails($user_data){
        $client = $this->proposal_request->ClientDetails;
    	$client->ClientType = $this->master->getClientType($user_data->usr_type);
        $client->LastName = $user_data->usr_lastname;
    	$client->ForeName = $user_data->usr_firstname;
    	$client->DOB = $user_data->usr_dob;
    	$client->Gender = ($user_data->usr_gender == "M") ? "Male" : "Female"; 
    	$client->MobileNo = $user_data->usr_mobile;
    	$client->EmailID = $user_data->usr_email;

        $client->Salutation = ($client->Gender == 'M') ? $this->master->getSalulation($user_data->usr_gender,$client->ClientType) : $this->master->getSalulation($user_data->usr_gender,$client->ClientType);

        if(strtolower($user_data->usr_type) == 'o'){
            $car_lib = new CarLib;
            $client->ForeName = $car_lib->getFirstName($user_data->usr_contactperson);
            $client->LastName = $car_lib->getLastName($user_data->usr_contactperson);
            $client->CorporateName = $user_data->usr_companyname;
            unset($car_lib);
        }

        unset($client->MaritalStatus);

        $reg_address = $client->ClientAddress->RegistrationAddress;
        $comm_address = $client->ClientAddress->CommunicationAddress;
        $perm_address = $client->ClientAddress->PermanentAddress;

        $reg_address->AddressType = 0;
        $reg_address->Address1 = $user_data->usr_houseno;
        $reg_address->Address2 = $user_data->usr_street;
        $reg_address->Address3 = $user_data->usr_locality;
        $reg_address->CityID = $this->master_db->getCityId($user_data->usr_city_code,$this->refrel_code);

        \Log::info('City Ref Code'.$user_data->usr_city_code);

        $pincode_ob = $this->master_db->getDataByPincode(['reliance_dist_code'],$user_data->usr_pincode);
       
        if($pincode_ob)
            $reg_address->DistrictID = $pincode_ob->reliance_dist_code;
        else 
            $reg_address->DistrictID = '';

        unset($pincode_ob);

        $reg_address->StateID = $this->master_db->getStateId($user_data->usr_state_code,$this->refrel_code);
        $reg_address->Pincode = $user_data->usr_pincode;
        $reg_address->Country = 'India';
        $reg_address->NearestLandmark = '';

        $pincode_ob = $this->master_db->getDataByPincode(['reliance_dist_code'],$user_data->prem_usr_pincode);
        $perm_address->AddressType = $comm_address->AddressType = 0;
        $perm_address->Address1 = $comm_address->Address1 = $user_data->prem_usr_houseno;
        $perm_address->Address2 = $comm_address->Address2 = $user_data->prem_usr_street;
        $perm_address->Address3 = $comm_address->Address3 = $user_data->prem_usr_locality;
        $perm_address->CityID = $comm_address->CityID = $this->master_db->getCityId($user_data->prem_usr_city_code,$this->refrel_code);
        
        if($pincode_ob)
            $perm_address->DistrictID = $comm_address->DistrictID = $pincode_ob->reliance_dist_code;
        else
            $perm_address->DistrictID = $comm_address->DistrictID = '';

        unset($pincode_ob);
        $perm_address->StateID = $comm_address->StateID = $this->master_db->getStateId($user_data->prem_usr_state_code,$this->refrel_code);
        $perm_address->Pincode = $comm_address->Pincode = $user_data->prem_usr_pincode;
        $perm_address->Country = $comm_address->Country = 'India';
        $perm_address->NearestLandmark = $comm_address->NearestLandmark = '';


        $client->ClientAddress->RegistrationAddress = $reg_address;
        $client->ClientAddress->CommunicationAddress = $comm_address;
        $client->ClientAddress->PermanentAddress = $perm_address; 

    	$this->proposal_request->ClientDetails = $client;
    	unset($client);
    }

    private function setPolicy($user_data){
    	$policy  = $this->proposal_request->Policy;
		
		$policy->branch_code = $this->branch_code;
    	$policy->AgentName = $this->agent_name; 
    	$policy->productcode = $this->product_code;

		$policy->BusinessType = 5;
    	if(strtolower($user_data->type_of_business) != 'rollover')
    			$policy->BusinessType = 1;

    	$policy->OtherSystemName = $this->other_system_name;
    	$policy->Cover_From = $this->helper->changeFormat($user_data->policy_start_date,'d/m/Y');
    	$policy->Cover_To = $this->helper->manDate($user_data->policy_start_date,'d/m/Y',['+ 1 year','-  1 days']);
    	
    	$this->proposal_request->Policy  = $policy;
    	unset($policy);
    }

    private function setRisk($user_data){
        $car_lib = new CarLib;
    	$risk = $this->proposal_request->Risk;

        $risk->VehicleMakeID = $this->master_db->getMakeId($user_data->car_make,$this->refrel_code);
        $risk->VehicleModelID = $this->variant_db->reliance_code;
    	$risk->CubicCapacity = $this->variant_db->variant_cc;
        $risk->Zone =  $this->rto_db->zone;
        $risk->RTOLocationID = $this->rto_db->{$this->refrel_code};
        $risk->ExShowroomPrice = $user_data->ex_showroom_price_id;
        $risk->IDV = $user_data->idv_opted;
        $risk->DateOfPurchase = $this->helper->changeFormat($user_data->car_registration_date,"d/m/Y");
        $risk->ManufactureMonth = $this->helper->changeFormat($risk->DateOfPurchase,"m");
        $risk->ManufactureYear = $this->helper->changeFormat($risk->DateOfPurchase,"Y");
        $risk->EngineNo = $user_data->veh_eng_no;
        $risk->Chassis = $user_data->veh_chassisno;
    

        if($user_data->veh_vehicle_financed == 'Y'){
            $risk->IsVehicleHypothicated = "true";
            // if(strtolower($user_data->veh_type_of_finance) == 'hypothecation'){
            //     $risk->IsVehicleHypothicated = "true";
                $risk->FinancierName = $user_data->veh_financierName;
                $risk->FinancierAddress = $user_data->veh_financier_addr;
            // }

            switch (strtolower($user_data->veh_type_of_finance)) {
                case 'hypothecation':
                    $risk->FinanceType  = "1";
                    break;
                case 'hire purchase':
                    $risk->FinanceType  = "2";
                    break;
                case 'lease':
                    $risk->FinanceType  = "3";
                    break;
            }
        }        
        
         $risk->IsRegAddressSameasCommAddress = "true";
        $risk->IsRegAddressSameasPermanentAddress = "true";

        $risk->IsPermanentAddressSameasCommAddress = "true";
        
        
        $risk->VehicleVariant = $this->variant_db->variant_name;
        $risk->StateOfRegistrationID = $this->master_db->getStateId($user_data->usr_state_code,$this->refrel_code);
        $risk->Rto_RegionCode= $car_lib->parseRegistrationNumber($user_data->rto_code);
        
        $this->proposal_request->Risk = $risk;
        unset($risk);
    }

    private function setVehicle($user_data){
    	$vehicle = $this->proposal_request->Vehicle;
    	
        $vehicle->Registration_Number = $user_data->veh_reg_no;
        
        $vehicle->ISNewVehicle = "false";

        if(strtolower($user_data->type_of_business) != "rollover"){
            $vehicle->ISNewVehicle = "true";
            $vehicle->Registration_Number = "NEW";
        }
        
        $vehicle->Registration_date = $this->helper->changeFormat($user_data->car_registration_date,"d/m/Y");
        $vehicle->SeatingCapacity = $this->variant_db->seat_capacity;
        $vehicle->TypeOfFuel = $this->master->getFuelTypeId(strtolower($user_data->car_fuel));
    	
    	$this->proposal_request->Vehicle = $vehicle;
    	
    }

    private function setPreviousInsuranceDetails($user_data){
    	$prev = $this->proposal_request->PreviousInsuranceDetails;
    	
        //$prev->PrevYearInsurer
        $prev->PrevYearPolicyNo = $user_data->prev_policyno;
    	$prev->PrevYearPolicyEndDate =$this->helper->changeFormat($user_data->policy_expiry_date,'d/m/Y');
    	$prev->PrevYearPolicyStartDate  = $this->helper->manDate($user_data->policy_expiry_date,"d/m/Y",["-1 year","+ 1 days"]);

    	$this->proposal_request->PreviousInsuranceDetails = $prev; 
    	unset($prev);
    }

    private function setCovers($user_data){
        $cover = $this->proposal_request->Cover;

        if($user_data->usr_type == "O")
            $cover->IsPAToOwnerDriverCoverd = false;
        
        $misc_desc =  json_decode($user_data->misc_desc,true);

        $addons = explode(",",$user_data->covers_selected);
        
        if(in_array("ZERODEP",$addons)){
            $cover->IsNilDepreciation = "true";
            $zerodep = $cover->NilDepreciationCoverage->NilDepreciationCoverage;
            $zerodep->IsChecked = "true";
            $zerodep->ApplicableRate = $misc_desc['reliance_zerodep_rate'];
            $cover->NilDepreciationCoverage->NilDepreciationCoverage = $zerodep;
        }

        if(in_array("PAPASS",$addons)){
            $si = "100000";
            $cover->IsPAToUnnamedPassengerCovered = "true";
            $cover->NoOfUnnamedPassenegersCovered = $this->variant_db->seat_capacity;
            $cover->UnnamedPassengersSI = $si;
            $field = $cover->PAToUnNamedPassenger->PAToUnNamedPassenger;
                $field->IsChecked = "true";
                $field->NoOfItems = $this->variant_db->seat_capacity;
                $field->SumInsured = $si;
            $cover->PAToUnNamedPassenger->PAToUnNamedPassenger = $field;
            unset($field);
            unset($si);
        }

        $this->proposal_request->Cover = $cover; 
        unset($cover);
    }

    private function setNCB($user_data){
       $ncb = $this->proposal_request->NCBEligibility; 
       
        $ncb->IsNCBApplicable = "true";
        if($user_data->claim == "Y")
            $ncb->IsNCBApplicable = "false";

       $ncb->NCBEligibilityCriteria = $this->master->getPrevPolicyCriteria(strtolower($user_data->claim));

       $ncb->PreviousNCB = $this->master->getNCBId($user_data->ncb); 
       $ncb->CurrentNCB = $this->master->getNCBId($user_data->new_ncb);
       unset($ncb);
    }
    
}	

