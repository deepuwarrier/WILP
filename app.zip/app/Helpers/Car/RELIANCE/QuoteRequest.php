<?php
namespace App\Helpers\Car\RELIANCE;

use App\Helpers\Car\CarHelper;
use App\Models\Car\CarMake;
use App\Models\Car\CarVariant;
use App\Models\Car\CarState;
use App\Models\Car\CarRto;
use Carbon\Carbon;
use App\Helpers\Car\RELIANCE\Masters;

Class QuoteRequest{

    public $ref_col = 'reliance_code';

    public function genrateRequest($idv_data,$user_data){
        $this->helper =  new CarHelper();
        $this->master = new Masters();
        // get sample request
    	$this->quote_request = file_get_contents(__DIR__.'/quote_request.json');
        $this->quote_request = json_decode($this->quote_request);
        // set real data
        $this->setIDV($idv_data);
        $this->setPolicy($idv_data);
        $this->setRisk($idv_data);
        $this->setVehicle($idv_data);
        $this->setPreviousInsuranceDetails($idv_data);
        $this->setCovers($idv_data,$user_data);
        $this->setNCB($idv_data);
        // unset temp variable
        unset($this->helper);
        unset($this->master);
        unset($idv_data);
        
		return $this->quote_request;
    }

    private function setPolicy($idv_data){
    	$policy  = $this->quote_request->Policy;
		$policy->BusinessType = 5;
    	
    	if(strtolower($idv_data['typeOfBusiness']) != 'rollover')
    			$policy->BusinessType = 1;

    	$policy->Cover_From = $this->helper->changeFormat($idv_data['policyStartDate'],'d/m/Y');
    	$policy->Cover_To = $this->helper->manDate($idv_data['policyStartDate'],'d/m/Y',['+ 1 year','-  1 days']);
    	$this->quote_request->Policy  = $policy;
    	unset($policy);
    }

    private function setRisk($idv_data){
        // dd($idv_data);
        $car_make = new CarMake;
        $car_variant = new CarVariant;
        $car_rto = new CarRto;
        $car_state = new CarState;
        $refrence_col = $this->ref_col;
    	$risk = $this->quote_request->Risk;
    	$risk->VehicleMakeID = $car_make->getMakeId($idv_data['make_code'],$refrence_col); //"192";
    	$risk->VehicleModelID = $car_variant->getVehicleId($idv_data['variant_code'],$refrence_col)->$refrence_col;//"19233";
    	$risk->Zone = $idv_data['rto_zone'];
    	$risk->ExShowroomPrice = $idv_data['ex_showroom_car_price'];
    	$risk->RTOLocationID = $car_rto->getRTOData($idv_data['rto'],$refrence_col)->$refrence_col; //"381";
    	$risk->IDV = $idv_data['idv']; // $this->getDefaultIDV();
        $risk->DateOfPurchase = $this->helper->changeFormat($idv_data['car_registration_date'],"d/m/Y");
    	$risk->ManufactureMonth = $this->helper->changeFormat($risk->DateOfPurchase,"m");
    	$risk->ManufactureYear = $this->helper->changeFormat($risk->DateOfPurchase,"Y");
    	$risk->VehicleVariant = $idv_data['variant_name'];
    	$risk->StateOfRegistrationID = $car_state->get_state_code($idv_data['state'],$refrence_col);//"17";
    	$risk->Rto_RegionCode= implode('-',str_split($idv_data['rto'],2));//"KA-01";
        $risk->LicensedCarryingCapacity = $idv_data['seating_capacity'];
    	$this->quote_request->Risk = $risk;
    	unset($risk);
    }

    private function setVehicle($idv_data){
    	$vehicle = $this->quote_request->Vehicle;
    	$vehicle->Registration_date = $this->helper->changeFormat($idv_data['car_registration_date'],"d/m/Y");
    	$vehicle->SeatingCapacity = $idv_data['seating_capacity'];
    	$vehicle->TypeOfFuel = $this->master->getFuelTypeId(strtolower($idv_data['fuel']));
    	$vehicle->ISNewVehicle = "false";
    	$this->quote_request->Vehicle = $vehicle;
    	unset($vehicle);
    }

    private function setPreviousInsuranceDetails($idv_data){
    	$prev = $this->quote_request->PreviousInsuranceDetails;
    	if($idv_data['claim'] == "Y")
    		$prev->IsNCBApplicable = "false";
    	
    	$prev->PrevYearPolicyEndDate =$this->helper->changeFormat($idv_data["policyExpiryDate"],'d/m/Y');
    	$prev->PrevYearPolicyStartDate  = $this->helper->manDate($idv_data["policyExpiryDate"],"d/m/Y",["-1 year","+ 1 days"]);

    	$this->quote_request->PreviousInsuranceDetails = $prev; 
    	unset($prev);
    }

    private function setCovers($idv_data,$user_data){
        $cover = $this->quote_request->Cover;
        $addons = explode(",",$idv_data['selected_chcks']);
        
        $misc_desc =  json_decode($user_data->misc_desc,true);
        
        if(in_array("ZERODEP",$addons)){
            $cover->IsNilDepreciation = "true";
            $zerodep = $cover->NilDepreciationCoverage->NilDepreciationCoverage;
            $zerodep->IsChecked = "true";
            $zerodep->ApplicableRate = $misc_desc['reliance_zerodep_rate'];
            $cover->NilDepreciationCoverage->NilDepreciationCoverage = $zerodep;
        }

        if(in_array("PAPASS",$addons)){
            $si = "100000";
            $cover->IsPAToUnnamedPassengerCovered = "true";
            $cover->NoOfUnnamedPassenegersCovered = $idv_data['seating_capacity'];
            $cover->UnnamedPassengersSI = $si;
            $field = $cover->PAToUnNamedPassenger->PAToUnNamedPassenger;
                $field->IsChecked = "true";
                $field->NoOfItems = $idv_data['seating_capacity'];
                $field->SumInsured = $si;
                $field->IsMandatory = "true";
            $cover->PAToUnNamedPassenger->PAToUnNamedPassenger = $field;
            unset($field);
            unset($si);
        }

        $this->quote_request->Cover = $cover; 
        unset($cover);
    }

    private function setNCB($idv_data){
       $ncb = $this->quote_request->NCBEligibility; 
       
       $ncb->NCBEligibilityCriteria = $this->master->getPrevPolicyCriteria(strtolower($idv_data['claim']));
       //$ncb->NCBEligibility = $this->master->getNCBId($idv_data['ncb']); 
       $ncb->PreviousNCB = $this->master->getNCBId($idv_data['ncb']); 
       unset($ncb);
    }

    private function setIDV($idv_data){
        $carvariant = new CarVariant;
        $policyStartDate = Carbon::parse($idv_data['policyStartDate']);
        $carRegistrationDate = Carbon::parse($idv_data['car_registration_date']);
        $price = $carvariant->getPrice($idv_data['variant_code']);
        
        $d1 = date($policyStartDate);
        $d2 = date($carRegistrationDate);
        $age = $d1 - $d2;
   
        switch($age){
            case 0: $percantage = "95"; $ncbp=0; break;
            case 1: $percantage = "85"; $ncbp=0; break;
            case 2: $percantage = "80"; $ncbp=20; break;
            case 3: $percantage = "70"; $ncbp=25; break;
            case 4: $percantage = "60"; $ncbp=35; break;
            case 5: $percantage = "50"; $ncbp=45; break;
            case 6: $percantage = "45"; $ncbp=50; break;
            default: $percantage = "40"; $ncbp=50;
        }

        $idv = round(($price * $percantage)/100);
        $this->setDefaultIDV($idv);
    }

    /**
     * Gets the value of defaultIDV.
     *
     * @return mixed
     */
    public function getDefaultIDV()
    {
        return $this->defaultIDV;
    }

    /**
     * Sets the value of defaultIDV.
     *
     * @param mixed $defaultIDV the default i d v
     *
     * @return self
     */
    public function setDefaultIDV($defaultIDV)
    {
        $this->defaultIDV = $defaultIDV;

        return $this;
    }
}