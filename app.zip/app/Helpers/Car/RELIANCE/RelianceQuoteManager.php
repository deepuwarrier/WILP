<?php
namespace App\Helpers\Car\RELIANCE;

use App\Models\Car\CarTData;
use App\Helpers\Car\RELIANCE\QuoteRequest;
use App\Helpers\Car\RELIANCE\CoverageRequest;
use App\Helpers\Car\CarHelper;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;

class RelianceQuoteManager{
    public $trans_code;
    public $addons = [];
    public $idv_data = [];
    public $product_id = 'reliance';
    public $insurer_id = 'reliance';

    // Config
    public $proposal_route = "reliance";
    public $insurer_name = "Reliance GI";
    
    //API Config
    private $coverage_url = 'http://rzonews.reliancegeneral.co.in/API/Service/CoverageDetailsForMotor';

    private $quote_url = 'http://rzonews.reliancegeneral.co.in/API/Service/PremiumCalulationForMotor';

    private $curl_config = ['content-type'=>'application/xml','post-type'=>'xml'];

    public $quote_request;

    private $available_addons = ['ZERODEP','PAPASS','RSAC'];


    private function callCoverage($idv_data,$car_helper,$user_data){
        // call coverage API
        $coverage_req = new CoverageRequest();
        $coverage_req = $coverage_req->genrateRequest($idv_data);
        $coverage_req = json_decode(json_encode($coverage_req),TRUE);;
        $this->coverage_request = $car_helper->genrateXml("<PolicyDetails/>",$coverage_req)->asXml();
        $response = $car_helper->call_curl_api('RELIANCE Coverage',$this->coverage_url,$this->coverage_request,$this->curl_config,$idv_data['trans_code']);
        
        if(isset($response['data']['CoverageList']['ErrorMessages']) && $response['data']['CoverageList']['ErrorMessages'] != '')
             return '';

        if(!$response or !is_array($response) or !array_key_exists('data',$response))
            return '';
        
        $addons_rate = [];

        foreach ($response['data']['LstAddonCovers'] as $value)
            $addons_rate[$value['CoverageName']] = $value['rate'];
        
        
        $data = json_decode($user_data->misc_desc,true);
        $data[$this->insurer_id.'_zerodep_rate'] = $addons_rate['Nil Depreciation'];
        $user_data['misc_desc'] = json_encode($data);
        $user_data->save();
        unset($coverage_req);
    }

    public function getQuote(){
        $car_helper = new CarHelper;
        $idv_data = $this->getIDVData();
        $user_data = $this->getUserData();

        $this->setAddons($idv_data['selected_chcks']);

        if(!$this->have_enable_addons())
            return 0;

        $addons = $this->getAddons();
        
        if(in_array('ZERODEP',$addons)){
            $age_with_month = $car_helper->getAgeInMonth(date('Y-m-d'),$idv_data['car_registration_date']);
            
            if($idv_data['vehicleAge'] <= 5)
                $this->callCoverage($idv_data,$car_helper,$user_data);
            else 
                return false;
        }

        $quote_loop = 0;
        QUOTE_CALL:

        // call api
        $quote_req = new QuoteRequest();
        $quote_req = $quote_req->genrateRequest($idv_data,$user_data);
        $quote_req = json_decode(json_encode($quote_req),TRUE);;
        $this->quote_request = $car_helper->genrateXml("<PolicyDetails/>",$quote_req)->asXml();
        $response = $car_helper->call_curl_api('RELIANCE Quote',$this->quote_url,$this->quote_request,$this->curl_config,$idv_data['trans_code']);

        // check there is a IDV issue
        if($response == null || strlen($response['data']['MotorPolicy']['ErrorMessages']) > 0 )
            $idv_issue = strpos($response['data']['MotorPolicy']['ErrorMessages'],"User IDV should be in range");

        // call quote after change of idv
        if(isset($idv_issue) && $idv_issue === 0 && $quote_loop == 0){
            $quote_loop++;
            $idv_data['idv'] =  $this->getIDV($response['data']['MotorPolicy']['ErrorMessages'],$idv_data['idv']);
            goto QUOTE_CALL;
        }

        if($response['data']['MotorPolicy']['ErrorMessages'] != ''){
            return '';
        }

        if(!$response or !is_array($response) or !array_key_exists('data',$response))
            return '';

        // genrate premium breakup
        $pb_data =  new PremiumBreakupData;
        $pb_data = $this->parse_premium_breakup_data($pb_data,$response['data']['MotorPolicy']);
        $pb = new PremiumBreakup();             
        $pb->setPbDatat($pb_data);
        $pb->setRsacValue(0);
        $PremiumBreakup = $pb->genratePremiumBreakup();
        
        $vehicle_idv = $response['data']['MotorPolicy']['IDV'];
        $trans_code = $idv_data['trans_code'];

        $quote = ['totalpremium' => $pb_data->getTotalPremium()
                    ,'pb_data'=>$pb_data
                    , 'insurer_id' => $this->insurer_id
                    , 'product_id' => $this->product_id
                    ,'insurerroute' => $this->proposal_route
                    ,'trans_code' => $trans_code
                    , 'idv_received' => $vehicle_idv
                    , 'netPremium' => $pb_data->getGrossPremium()
                    , 'insurerName' => $this->insurer_name
                    , 'serviceTax' => $pb_data->getServiceTax()
                    , 'premiumBreakup' => $PremiumBreakup];

        unset($pb);
        unset($response);
        unset($car_helper);
        unset($idv_data);
        unset($this->quote_request);

        return $quote;
    }

    public function getIDV($error,$current_idv){
        preg_match('#\((.*?)\)#',$error, $match);
        if(isset($match[1])){
            $idvs = explode(",",$match[1]);
        }
        $min = trim($idvs[0]);
        $max = trim($idvs[1]);

        if($current_idv < $min)
            return ceil($min);

        return floor($max);
    }

    private function have_enable_addons(){
        return (empty(array_diff($this->getAddons(),$this->available_addons)));
    }

    public function parse_premium_breakup_data($pb_data,$quote_response){
        $premium_details = [];
        
        foreach ($quote_response['lstPricingResponse'] as $key => $value)
             $premium_details[str_replace(" ","_",strtolower($value['CoverageName']))]  = abs($value['Premium']);

        $tp_premium = $premium_details['basic_liability'];
        
        $tp_premium = (isset($premium_details['bifuel_kit_tp'])) ? $tp_premium+$premium_details['bifuel_kit_tp'] : $tp_premium;
        $pb_data->setTpPremium($tp_premium);
        
        $od_premium = $premium_details['basic_od'];
        $od_premium = (isset($premium_details['bifuel_kit'])) ? $od_premium+$premium_details['bifuel_kit'] : $od_premium;
        $pb_data->setOdPremium($od_premium);


        $pb_data->setGrossPremium($quote_response['NetPremium']);
        $pb_data->setTotalPremium($quote_response['FinalPremium']);
        $pb_data->setServiceTax($pb_data->getTotalPremium()-$pb_data->getGrossPremium());
                   
        // discount
        if(array_key_exists('ncb',$premium_details))
            $pb_data->setNcbDiscount($premium_details['ncb']); 

        if(array_key_exists('od_discount',$premium_details))
            $pb_data->setOdDiscount($premium_details['od_discount']); 

        // basic addon
        if(array_key_exists('pa_to_owner_driver',$premium_details))
            $pb_data->setPaPremium($premium_details['pa_to_owner_driver']);

        if(array_key_exists('liability_to_paid_driver',$premium_details))
            $pb_data->setLlPremium($premium_details["liability_to_paid_driver"]);

        // extra covers
        if(array_key_exists('pa_to_unnamed_passenger',$premium_details))
            $pb_data->setPapassPremium($premium_details['pa_to_unnamed_passenger']);

        if(array_key_exists('nil_depreciation',$premium_details))
            $pb_data->setZerodepPremium($premium_details['nil_depreciation']);    
    
        $pb_data->setOdPremium($pb_data->getOdPremium()+$pb_data->getOdDiscount());
        return $pb_data;
    }

    public function setIDVData($idv_data){
        $this->idv_data = $idv_data;
        $this->setTransCode($idv_data['trans_code']);
    }

    public function getIDVData(){
        return $this->idv_data;
    }

    public function setAddons($addons){
        $this->addons = $addons;

        if(!is_array($this->addons))
            $this->addons = $this->parseAddon($this->addons);
    }

    public function getAddons(){
        return $this->addons;
    }

    public function setTransCode($trans_code){
        $this->trans_code = $trans_code;
    }

    public function getTransCode(){
        return $this->trans_code;
    }

    // helper function
    public function getUserData(){
        $user_data = CarTData::find($this->getTransCode());
        return $user_data;
    }

    public function parseAddon($addons){
        $addons = explode(",",$addons);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        return $addons;
    }
}