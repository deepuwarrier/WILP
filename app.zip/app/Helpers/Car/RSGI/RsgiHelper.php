<?php
namespace App\Helpers\Car\RSGI;
use App\Constants\Car_Constants;
use App\Models\Car;
use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;


class RsgiHelper {
	protected $productId	=	'RSGI';
	public $trans_code;
	public function callRsgiQuoteApi($url, $postFields,$trans_code = null) {
		Log::info('CAR - RSGI - Quote Request - '.$trans_code.' - ', $postFields);
		$test = 0;
		$postFields['reqType'] = 'JSON';
		$postFields['respType'] = 'XML';
		$postFields['authenticationDetails']['agentId'] = Car_Constants::RSGI_AGENT_CODE;
		$postFields['authenticationDetails']['apikey'] = Car_Constants::RSGI_API_KEY;


		if($test){
			$data_dummy = '{"PREMIUMDETAILS":{"DATA":{"GROSS_PREMIUM":"9474.0","PREMIUM_WITHOUT_COVERS":"9474","IDV":"247100.0","OD_PREMIUM":{"BASIC_PREMIUM_AND_NON_ELECTRICAL_ACCESSORIES":"4130.0","ELECTRICAL_ACCESSORIES":"0.0","BI_FUEL_KIT":"0.0","FIBER_GLASS_TANK":"0.0","AUTOMOBILE_ASSOCIATION_DISCOUNT":"0.0","VOLUNTARY_DEDUCTABLES":"0.0","VOLUNTARY_DEDUCTABLE":"0.0","NO_CLAIM_BONUS":"1445.0","DEPRECIATION_WAIVER":"2347.0","ENGINE_PROTECTOR":"0.0","NCB_PROTECTOR":"741.0","WIND_SHIELD_GLASS":"0.0","LIFE_TIME_ROAD_TAX":"0.0","SPARE_CAR":"0.0","INVOICE_PRICE_INSURANCE":"0.0","LOSS_OF_BAGGAGE":"0.0","TOTAL_OD_PREMIUM":"5873.0","KEY_REPLACEMENT":"100.0","TOWING_CHARGES_COVER_PREMIUM":"0.0"},"LIABILITY":{"BASIC_PREMIUM_INCLUDING_PREMIUM_FOR_TPPD":"2055.0","BI_FUEL_KIT_CNG":"0.0","PERSONAL_ACCIDENT_BENEFITS":"-","UNDER_SECTION_III_OWNER_DRIVER":"100.0","UNNAMED_PASSENGRS":"0.0","PA_COVER_TO_PAID_DRIVER":"0.0","TO_PAID_DRIVERS":"0.0","TO_EMPLOYESES":"0.0","TOTAL_LIABILITY_PREMIUM":"2155.0"},"PACKAGE_PREMIUM":"8028.0","PREMIUM":"9474.0","QUOTE_ID":"QVBB0055782","SERVICETAX":"0","ECESS":"0","KRISHI_CESS":"0.0","TAX_TYPE":"GST","IGST":"0.0","CGST":"723.0","SGST":"723.0","UTGST":"0.0","POLICY_START_DATE":"02/07/2017","POLICY_EXPIRY_DATE":"01/07/2018","VERSION_NO":"1.0"},"Status":{"StatusCode":"S-0002","Message":"Premium Calculated and Quote Saved Successfully"}}}';
			$response = json_decode($data_dummy,true);
		} else {
			$request_xml = $this->genrateXml('<CALCULATEPREMIUMREQUEST/>',$postFields)->asXML();
			//Log::info("CAR - RSGI - Post Fields for quote - xml form--.".$request_xml);
			$response = $this->callHttp($url,$request_xml,function($response){

				isset($response['PREMIUMDETAILS']) ? $return_data	=	$response['PREMIUMDETAILS'] : $return_data['error'] = (isset($return_data['Status']['Message'])?$return_data['Status']['Message']:'true');
				
				if(isset($return_data['Status']['StatusCode']) && !array_key_exists($return_data['Status']['StatusCode'], Car_Constants::RQGI_SUCCESS_CODES)){
					$return_data['error'] = $return_data['Status']['Message'];
				}

				if(is_array($response)){
					Log::info("CAR - RSGI - Quote Response - ".$response['trans_code'].' - ',$response['PREMIUMDETAILS']);
				} else 
					Log::info("CAR - RSGI - Quote Response - ".$response['trans_code'].' - '.$response['PREMIUMDETAILS']);

				return $return_data;
			},$trans_code);
		}
		is_array($response)?Log::info("CAR - RSGI - Quote Response - ".$trans_code.' - ',$response):Log::info("CAR - RSGI - Quote Response - ".$trans_code.' - '.$response);
		return $response;
	}

	public function genrateXml($root,$fields){
		$xml = new \SimpleXMLElement($root);
		$this->addChild($xml,$fields);
		return $xml;
	}

	public function addChild($xml,$fields){
		$fn = function($value,$key) use ($xml){
			 if(is_array($value)){
			 	$sxml = $xml->addChild($key);
			 	$this->addChild($sxml,$value);
			 }else
			 	$xml->addChild($key,$value);
		};
		array_walk($fields,$fn);
		return $xml;
	}

	public function callRsgiUpdateQuoteApi($url, $postFields,$trans_code = null) {
		unset($postFields['covers']);
		$postFields['reqType'] = 'JSON';
		$postFields['respType'] = 'XML';
		$postFields['authenticationDetails']['agentId'] = Car_Constants::RSGI_AGENT_CODE;
		$postFields['authenticationDetails']['apikey'] = Car_Constants::RSGI_API_KEY;
		// Log::info('Post Fields--.', $postFields);
        $test = 0;
        if($test){
			$data_dummy = '{"PREMIUMDETAILS":{"DATA":{"GROSS_PREMIUM":"9474.0","PREMIUM_WITHOUT_COVERS":"9474","IDV":"247100.0","OD_PREMIUM":{"BASIC_PREMIUM_AND_NON_ELECTRICAL_ACCESSORIES":"4130.0","ELECTRICAL_ACCESSORIES":"0.0","BI_FUEL_KIT":"0.0","FIBER_GLASS_TANK":"0.0","AUTOMOBILE_ASSOCIATION_DISCOUNT":"0.0","VOLUNTARY_DEDUCTABLES":"0.0","VOLUNTARY_DEDUCTABLE":"0.0","NO_CLAIM_BONUS":"1445.0","DEPRECIATION_WAIVER":"2347.0","ENGINE_PROTECTOR":"0.0","NCB_PROTECTOR":"741.0","WIND_SHIELD_GLASS":"0.0","LIFE_TIME_ROAD_TAX":"0.0","SPARE_CAR":"0.0","INVOICE_PRICE_INSURANCE":"0.0","LOSS_OF_BAGGAGE":"0.0","TOTAL_OD_PREMIUM":"5873.0","KEY_REPLACEMENT":"100.0","TOWING_CHARGES_COVER_PREMIUM":"0.0"},"LIABILITY":{"BASIC_PREMIUM_INCLUDING_PREMIUM_FOR_TPPD":"2055.0","BI_FUEL_KIT_CNG":"0.0","PERSONAL_ACCIDENT_BENEFITS":"-","UNDER_SECTION_III_OWNER_DRIVER":"100.0","UNNAMED_PASSENGRS":"0.0","PA_COVER_TO_PAID_DRIVER":"0.0","TO_PAID_DRIVERS":"0.0","TO_EMPLOYESES":"0.0","TOTAL_LIABILITY_PREMIUM":"2155.0"},"PACKAGE_PREMIUM":"8028.0","PREMIUM":"9474.0","QUOTE_ID":"QVBB0055782","SERVICETAX":"0","ECESS":"0","KRISHI_CESS":"0.0","TAX_TYPE":"GST","IGST":"0.0","CGST":"723.0","SGST":"723.0","UTGST":"0.0","POLICY_START_DATE":"02/07/2017","POLICY_EXPIRY_DATE":"01/07/2018","VERSION_NO":"1.0"},"Status":{"StatusCode":"S-0002","Message":"Premium Calculated and Quote Saved Successfully"}}}';
			$response = json_decode($data_dummy,true);
		} else {
			$request_xml = $this->genrateXml('<CALCULATEPREMIUMREQUEST/>',$postFields)->asXML();
			Log::info("CAR RSGI Quote Request - ".$trans_code.' - '.$request_xml);
			$response = $this->callHttp($url,$request_xml);
		}
		

		is_array($response)?
			Log::info("CAR RSGI Quote Response ",$response)
			:	Log::info("CAR RSGI Quote Response - ".$trans_code.' - '.$response);

		if(!is_array($response))
			$response = json_decode($response,true);
		
		$return_data = isset($response['PREMIUMDETAILS'])?$response['PREMIUMDETAILS']:[];
		
		if(!array_key_exists($return_data['Status']['StatusCode'], Car_Constants::RQGI_SUCCESS_CODES)){
	   		$return_data['error'] = $return_data['Status']['Message'];
	  	} elseif (empty($return_data)) {
	   		$return_data['error'] = 'Return Data is empty';
	  	}
		
		return $return_data;
	}

	public function testCallRsgiProposalServiceApi(){
		$fields = json_decode('{"premium":"4891.0","quoteId":"QVBB0056611","reqType":"JSON","strEmail":"PARTHMY007@GMAIL.COM"
			,"respType":"XML"}',true);
		return $this->callRsgiProposalServiceApi($fields);		
	}

	public function callRsgiProposalServiceApi($fields,$trans_code = null){
		$fields['reqType'] = 'JSON';
		$fields['respType'] = 'XML';
		$fields['isOTPVerified'] = 'Yes';
		$fields['authenticationDetails']['agentId'] = Car_Constants::RSGI_AGENT_CODE;
		$fields['authenticationDetails']['apikey'] = Car_Constants::RSGI_API_KEY;
		Log::info('CAR Rsgi Proposal Request - '.$trans_code.' - '.json_encode($fields));
		$url = Car_Constants::RSGI_PROPOSAL_URL;
		
		$xml = $this->genrateXml('<GPROPOSALREQUEST/>',$fields);
		$request_xml = $xml->asXML();
		Log::info('CAR Rsgi Proposal Request XML - '.$trans_code.' - '.$request_xml);
		$response = $this->callHttp($url,$request_xml);
		if(!is_array($response))
			$response = json_decode($response,true);

		Log::info('CAR Rsgi Proposal Response - '.$trans_code.' - ',$response);
		return $response;
	}

	public function testcallRsgiPaymentApi(){
		$request_param = '{"premium":"4891.0","quoteId":"QVBB0056611","strEmail":"PARTHMY007@GMAIL.COM","reqType":"JSON","respType":"XML"}';
		$fields = json_decode($request_param,true);
		return $this->callRsgiPaymentApi($fields);		
	}

	

	public function callRsgiPaymentApi($fields){
		
		$fields['reqType'] = 'JSON';
		$fields['respType'] = 'XML';
		Log::info('CAR - RsgiPaymentApi Request :: '.json_encode($fields));
		$url = Car_Constants::RSGI_PAYMENT_URL;
		$fields['authenticationDetails']['agentId'] = Car_Constants::RSGI_AGENT_CODE;
		$fields['authenticationDetails']['apikey'] = Car_Constants::RSGI_API_KEY;
		
		$xml = $this->genrateXml('<PAYMENTGATEWAYREQUEST/>',$fields);
		$request_xml = $xml->asXML();
		Log::info($request_xml);
		return $this->callHttp($url,$request_xml);	
	}

	public function callHttp($url,$request_xml,$fn = null,$trans_code = null){
		// dd($url,$request_xml,$fn,$trans_code);
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => (is_array($request_xml))? json_encode($request_xml,true) : $request_xml,
			CURLOPT_HTTPHEADER => array("content-type: application/xml"),
		));
	    $data = curl_exec($curl);

		$response = array();
		
		$response = json_decode($data,true);

		if (empty($response)) {
		    Log::info("PC RSGI Proposal Resp".$trans_code ." - ". print_r($data, true));
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}else{
			if(is_array($data))
				Log::info('CAR - RSGI callHttp Response.', $data);	
		} 

		curl_close($curl);

		if(isset($fn)){
			$response['trans_code'] = $trans_code;
			return call_user_func($fn,$response);
		}
		return $response;
		
	}

	public function parse_premium_breakup_data($pb_data,$irdo){	    
		$premium = $irdo['DATA'];
		if(!round($premium['IGST'])){
			$service_tax = $premium['CGST']+$premium['SGST'];
		}else{
			$service_tax = $premium['IGST'];
		}
		$pb_data->setOdPremium($premium['OD_PREMIUM']['BASIC_PREMIUM_AND_NON_ELECTRICAL_ACCESSORIES']);
		$pb_data->setTpPremium($premium['LIABILITY']['BASIC_PREMIUM_INCLUDING_PREMIUM_FOR_TPPD']);
		$pb_data->setServiceTax($service_tax);
		$pb_data->setGrossPremium($premium['PACKAGE_PREMIUM']);
		$pb_data->setTotalPremium($premium['PREMIUM']);
		$pb_data->setPaPremium($premium['LIABILITY']['UNDER_SECTION_III_OWNER_DRIVER']);
		$pb_data->setLlPremium(NULL);
		$pb_data->setRtiPremium(round($premium['OD_PREMIUM']['INVOICE_PRICE_INSURANCE']));
		$pb_data->setZerodepPremium(round($premium['OD_PREMIUM']['DEPRECIATION_WAIVER']));
		$pb_data->setPapassPremium(round($premium['LIABILITY']['UNNAMED_PASSENGRS']));
		$pb_data->setEpPremium($premium['OD_PREMIUM']['ENGINE_PROTECTOR']);
		$pb_data->setRsacPremium(NULL);
		$pb_data->setOdDiscount(0);
		$pb_data->setNcbDiscount($premium['OD_PREMIUM']['NO_CLAIM_BONUS']); 
		return $pb_data;
	}

	public function reformatIncludePackage($covers){
		$re_covers = [];
		$covers_select	=	['OD','TP','LL','PA','RTI','ZERODEP','PAPASS'];
		$covers_rsqi	=	[
								'BASIC_PREMIUM_AND_NON_ELECTRICAL_ACCESSORIES'=>'OD',
								'TOTAL_LIABILITY_PREMIUM' => 'TLP',
								'ELECTRICAL_ACCESSORIES'=>'EA',
								'BASIC_PREMIUM_INCLUDING_PREMIUM_FOR_TPPD' => 'TP',
								'BI_FUEL_KIT_CNG' => 'BFTC',
								'PERSONAL_ACCIDENT_BENEFITS' => 'PAB',
								'UNDER_SECTION_III_OWNER_DRIVER' => 'PA',
								'UNNAMED_PASSENGRS' => 'PAPASS',
								'PA_COVER_TO_PAID_DRIVER' => 'PAPD',
								'TO_PAID_DRIVERS' =>'TPD',
								'TO_EMPLOYESES'=>'TE',
								'BI_FUEL_KIT'=>'BFT',
								'FIBER_GLASS_TANK'=>'FGT',
								'AUTOMOBILE_ASSOCIATION_DISCOUNT'=>'AAD',
								'VOLUNTARY_DEDUCTABLES'=>'VDS',
								'VOLUNTARY_DEDUCTABLE'=>'VD',
								'NO_CLAIM_BONUS'=>'NCB',
								'DEPRECIATION_WAIVER'=>'ZERODEP',
								'ENGINE_PROTECTOR'=>'EP',
								'NCB_PROTECTOR'=>'NCBPROTECT',
								'WIND_SHIELD_GLASS'=>'WSG',
								'LIFE_TIME_ROAD_TAX'=>'LTT',
								'SPARE_CAR'=>'SC',
								'INVOICE_PRICE_INSURANCE'=>'RTI',
								'LOSS_OF_BAGGAGE'=>'LOBL',
								'TOTAL_OD_PREMIUM'=>'TOTAL_OD',
								'KEY_REPLACEMENT'=>'KEYREPL',
								'TOWING_CHARGES_COVER_PREMIUM'=>'TOW'
							];
		foreach($covers as $cover_product_attr => $cover_value){
			if(isset($covers_rsqi[$cover_product_attr]))
				$re_covers[$covers_rsqi[$cover_product_attr]] = $cover_value;
		//	unset($re_covers[$cover_value['coverId']]['coverId']);
		}
		return $re_covers;
	}

	function reformatAttributes($attributes){
		$re_attribute = [];
		foreach($attributes as $attribute_product_attr => $attribute_value){
			if(is_array($attribute_value) && count($attribute_value) == 1){
				foreach ($attribute_value as $attribute_value_product_attr => $attribute_value_value) {
					$re_attribute[$attribute_value_product_attr] = $attribute_value_value;
				}
			}else{
				$re_attribute[$attribute_product_attr] = $attribute_value;	
			}
		}
		return $re_attribute;
	}



	function reformatPremiumBreakup($premiumBreakups){
		$rePremiumBreakup = [];
		foreach ($premiumBreakups as $premiumBreakup_product_attr => $premiumBreakup_value) {
			if(is_array($premiumBreakup_value)){
				foreach ($premiumBreakup_value as $premiumBreakup_value_product_attr => $premiumBreakup_value_value) {
					//var_dump($premiumBreakup_value_value);
					$rePremiumBreakup[$premiumBreakup_product_attr][$premiumBreakup_value_value['coverId']] = $premiumBreakup_value_value;
					unset($rePremiumBreakup[$premiumBreakup_product_attr][$premiumBreakup_value_value['coverId']]['coverId']);
				}
			}
		}
		return $rePremiumBreakup;
	}

}

?>
