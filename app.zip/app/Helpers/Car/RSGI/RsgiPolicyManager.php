<?php
namespace App\Helpers\Car\RSGI;
use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car as M;

class RsgiPolicyManager{

	public $refrel_col = 'rsgi_code';

	public $VD = ['0','2500','5000','7500','15000'];
	public $vehicle_details = [  'addonValue' => ''
										,'automobileAssociationMembership' => ''
										,'averageMonthlyMileageRun' => 3000
										,'companyNameForCar' => ''
										,'engineprotector' => 'on'
										// ,'claimAmountReceived' => 0
										,'cover_dri_othr_car_ass' => 'No'
										,'cover_elec_acc' => 'No'
										,'cover_non_elec_acc' => 'No'
										,'depreciationWaiver' => 'off'
										,'drivingExperience' => Car_Constants::PROPOSAL_DEFAULT['DRIVING_EXP']
										,'fibreGlass' => 'No'
										,'hdnDepreciation' => 'FALSE'
										,'hdnInvoicePrice'=> 'FALSE'
										,'hdnLossOfBaggage' => 'FALSE'
										,'hdnNCBProtector' => 'FALSE'
										,'hdnProtector'	=> 'FALSE'
										,'hdnSpareCar' => 'FALSE'
										,'hdnWindShield' => 'FALSE'
										,'hdnRoadTax' => 'FALSE'
										,'invoicePrice' => 'on'
										,'isBiFuelKit' => 'No'
										,'isBiFuelKitYes' => 'No'
										,'isPreviousPolicyHolder' => 'true'
										,'keyreplacement' => 'off'
										,'legalliabilityToPaidDriver' => 'Yes'
										,'modify_your_idv' => '0'
										,'ncbprotector' => 'off'
										// ,'personalAccidentCoverForUnnamedPassengers' => 100000
										// ,'personalaccidentcoverforunnamedpassengers'=> 100000
										,'accidentcoverforpaiddriver' => ''
										,'region' => ''
										,'registrationchargesRoadtax' => 'off'
										,'spareCar' => 'off'
										,'windShieldGlass' => 'on'
										,'valueOfLossOfBaggage' => ''
										,'vehicleMostlyDrivenOn' => 'City roads'
										,'vehicleRegisteredInTheNameOf' => 'Individual'
										,'vehicleSubLine' => 'privatePassengerCar'
										// ,'voluntarydeductible' => ''
										
	];

	// public static $NCB =  ['0'=>1
	// 					,'20'=>2
	// 					,'25'=>3
	// 					,'35'=>4
	// 					,'45'=>5
	// 					,'50'=>6];
	public $ncbcurrentArray 	= ['0'=>'20','20'=>'25','25'=>'35','35'=>'45','45'=>'50','50'=>'50'];
	public $noClaimBonusPercentArray = ['0'=>1,'20'=>2,'25'=>3,'35'=>4,'45'=>5,'50'=>6];
	
	public function setData($data,$user_data) {
		$this->user_data = $user_data;
		$car_lib = new CarLib;
		$car_helper = new CarHelper;
		$data = $car_lib->parseDataInUpperCase((array) $data);
		// get id from code relevant master
		foreach (Car_Constants::IDS as $field => $field_master) {
			$refrel_col = $this->refrel_col;
			if($field == 'nomineeRel')
				goto FINISH;
			if(isset($data[$field]) && $data[$field] != '')
				$data[$field] = $car_helper->getMasterId($refrel_col,$field_master,$data[$field]);
			FINISH:
		}

		$this->proposal_data = $data;
		$this->setName();
		$this->proposer_request = []; // init 
		$this->proposer_request['proposerDetails'] 
				= $car_helper->grabDetails($this->getRequestMap('proposerDetails')
										,$this->proposal_data);
		$this->proposer_request['vehicleDetails'] 
				= $car_helper->grabDetails($this->getRequestMap('vehicleDetails')
										,$this->proposal_data);
		
		$this->proposer_request['vehicleDetails']['vehicleregDate'] = $car_helper->changeFormat($this->proposer_request['vehicleDetails']['vehicleregDate'],'d/m/Y');
		
		
		if(!isset($this->proposal_data['reg_add_is_same'])){
			$this->proposer_request['proposerDetails']['sameAdressReg'] = 'No';
			$this->proposer_request['proposerDetails']['contactAddress1'] = $this->proposal_data['perm_houseno'].' '.$this->proposal_data['perm_street'];
			$this->proposer_request['proposerDetails']['contactAddress2'] = $this->proposal_data['perm_locality'];
			$this->proposer_request['proposerDetails']['contactCity'] = $this->proposal_data['perm_citycode'];
			$this->proposer_request['proposerDetails']['contactPincode'] = $this->proposal_data['perm_pincode'];
		} else {
			$this->proposer_request['proposerDetails']['sameAdressReg'] = 'Yes';
			$this->proposer_request['proposerDetails']['contactAddress1'] = $this->proposal_data['houseno'].' '.$this->proposal_data['street'];
			$this->proposer_request['proposerDetails']['contactAddress2'] = $this->proposal_data['locality'];
			$this->proposer_request['proposerDetails']['contactCity'] = $this->proposal_data['city'];
			$this->proposer_request['proposerDetails']['contactPincode'] = $this->proposal_data['pincode'];
		}

		$this->proposer_request['quoteId'] 
				= $data['quote_id'];
		$this->setProposerDetails();
		$this->setVehicleDetails();
		return $this->proposer_request;
	}

	private function setName(){
		$car_lib = new CarLib;
		if(isset($this->proposal_data['fullname']) && $this->proposal_data['fullname'] != ""){
			// grab firstname and lastname from the fullname
			$this->proposal_data['firstname'] = $car_lib->getCorrect($car_lib->getFirstName($this->proposal_data['fullname']));
			$this->proposal_data['lastname'] = $car_lib->getCorrect($car_lib->getLastName($this->proposal_data['fullname']));	
		}
	}

	private function setProposerDetails(){
		$this->proposer_request['proposerDetails']['strTitle'] =
			 ($this->proposal_data['gender'] == 'M')? 'MR' : 'MISS';
		// strPhoneNo
		// strStdCode
	}

	private function setVehicleDetails(){
		$car_helper = new CarHelper;
		$session_id = $car_helper->getSuid();
		$vehicle_details = $this->vehicle_details;
		$financier_value = ['HYPOTHECATION'=>'Hypothecation','HIRE PURCHASE'=>'Hire purchase','LEASE'=>'Lease'];
		$this->proposer_request['vehicleDetails']['ProductName'] = 'BrandNewCar';
		$this->proposer_request['vehicleDetails']['typeOfCover']	= 'Bundled';
		$this->proposer_request['vehicleDetails']['vehicleSubLine']	=	'privatePassengerCar';
		$this->proposer_request['vehicleDetails']['vehicleRegisteredInTheNameOf'] = 'Individual';
		foreach ($vehicle_details as $key => $value) {
			$this->proposer_request['vehicleDetails'][$key]	 = $value;
		}
		
		// for rollover 
		if(strtolower($this->proposal_data['typeOfBusiness']) == 'rollover'){
			// $this->proposer_request['vehicleDetails']['previousPolicyType'] = "Comprehensive";
			if($this->proposal_data['previousPolicyType'] == 'C') {
				$this->proposer_request['vehicleDetails']['previousPolicyType'] = "Comprehensive";
			} else {
				$this->proposer_request['vehicleDetails']['previousPolicyType'] = "Liability";
			}
			$this->proposer_request['vehicleDetails']['ProductName'] = 'RolloverCar';

			/* Below code is added by vivek  */
	    	// if claimsMadeInPreviousPolicy then the condition is true 
			if (!empty($this->proposal_data['prev_claim_status']) && $this->proposal_data['prev_claim_status'] === 'Y') {
				$this->proposer_request['vehicleDetails']['claimsMadeInPreviousPolicy'] = 'Yes';
				$this->proposer_request['vehicleDetails']['ncbcurrent'] 	= 0;
				$this->proposer_request['vehicleDetails']['noClaimBonusPercent'] = 0;
				$this->proposer_request['vehicleDetails']['claimsReported'] = $this->proposal_data['claim'];
				$this->proposer_request['vehicleDetails']['claimAmountReceived'] = $this->proposal_data['claimAmountReceived'];  // Make 20% of IDV
			} else 
			{
				$this->proposer_request['vehicleDetails']['claimsMadeInPreviousPolicy'] = 'No';
				$this->proposer_request['vehicleDetails']['ncbcurrent'] =  $this->ncbcurrentArray[$this->proposal_data['pre_ncb']];
				$this->proposer_request['vehicleDetails']['noClaimBonusPercent'] = $this->noClaimBonusPercentArray[$this->proposal_data['pre_ncb']];
				$this->proposer_request['vehicleDetails']['claimsReported'] = 0;
				$this->proposer_request['vehicleDetails']['claimAmountReceived'] = '';
			}
			/* Below code is added by vivek  */
			// $this->proposer_request['vehicleDetails']['fibreGlass'] = 'No';
			$this->proposer_request['vehicleDetails']['previousPolicyExpiryDate'] = date('d/m/Y',strtotime($this->proposal_data['policyExpiryDate']));
		    $this->proposer_request['vehicleDetails']['policyED'] = date('Y/m/d',strtotime($this->proposal_data['policyExpiryDate']));
			$this->proposer_request['vehicleDetails']['policySD'] =  date('Y/m/d',strtotime('-1 year',strtotime($this->proposal_data['policyExpiryDate'])));
			if($this->proposer_request['vehicleDetails']['isCarOwnershipChanged'] === 'N'){
			$this->proposer_request['vehicleDetails']['isCarOwnershipChanged'] = 'No';
			} else {
				$this->proposer_request['vehicleDetails']['isCarOwnershipChanged'] = 'Yes';
				$this->proposer_request['vehicleDetails']['ncbcurrent'] 	= 0;
				$this->proposer_request['vehicleDetails']['noClaimBonusPercent'] = 0;
			}

		}else{
			// $this->proposer_request['vehicleDetails']['isBiFuelKitYes'] = 'No';
			// $this->proposer_request['vehicleDetails']['fibreglass'] = 'No';
			$this->proposer_request['vehicleDetails']['registrationNumber'] = '';
			$this->proposer_request['isNewUser'] = 'Yes';
			
		}

		//$this->proposer_request['vehicleDetails']['isCarOwnershipChanged'] = 'No'; // required compl
		
		// if yes than we need to pass 
		// financierName (if carfinancied)
	    // isCarFinancedValue
	    // $this->proposer_request['vehicleDetails']['isCarFinanced'] = 'No';
		// $this->proposer_request['vehicleDetails']['isBiFuelKit'] = 'No'; //tmp set no
		
		// pass electronic accessories
		if(isset($this->proposal_data['electrical']) && $this->proposal_data['electrical'] != ''){
			$this->proposer_request['vehicleDetails']['cover_elec_acc'] =  'Yes';
			$this->proposer_request['vehicleDetails']['electricalAccessories'] = 
			['electronicAccessoriesDetails'
		 		=>['makeModel'=>$this->proposal_data['vehicleManufacturerName'].' '.$this->proposal_data['model_name']
		 		,'nameOfElectronicAccessories'=>'Electronic Accessories'
		 		,'value'=>$this->proposal_data['electrical']]
		 	];
		 	$this->proposer_request['vehicleDetails']['valueofelectricalaccessories'] = $this->proposal_data['electrical'];
		}else{
			$this->proposer_request['vehicleDetails']['electricalAccessories'] = []; //tmp set no
			$this->proposer_request['vehicleDetails']['valueofelectricalaccessories'] =  0;
		}

		// pass non electronic accessories
		if(isset($this->proposal_data['non_electrical']) && $this->proposal_data['non_electrical'] != ''){
			$this->proposer_request['vehicleDetails']['cover_non_elec_acc'] =  'Yes';
			$this->proposer_request['vehicleDetails']['nonElectricalAccesories'] = 
			['nonelectronicAccessoriesDetails'
		 		=>['makeModel'=>$this->proposal_data['vehicleManufacturerName'].' '.$this->proposal_data['model_name']
		 		,'nameOfElectronicAccessories'=>'Non Electronic Accessories'
		 		,'value'=>$this->proposal_data['non_electrical']]
		 	];
		 	$this->proposer_request['vehicleDetails']['valueofnonelectricalaccessories'] = $this->proposal_data['non_electrical'];
		}else{
			$this->proposer_request['vehicleDetails']['nonElectricalAccesories'] = [];	
			$this->proposer_request['vehicleDetails']['valueofnonelectricalaccessories'] =  0;
		}

		if($this->user_data->veh_reg_no)
			$this->proposer_request['vehicleDetails']['registrationNumber'] = $this->user_data->veh_reg_no;//

		if(isset($this->proposal_data['vehicle_financed']) && ($this->proposal_data['vehicle_financed'] == 'Y')){
			$this->proposer_request['vehicleDetails']['isCarFinanced']= 'Yes';

			$this->proposer_request['vehicleDetails']["isCarFinancedValue"] =	$financier_value[$this->proposal_data['type_of_finance']];// $this->proposal_data['type_of_finance'];
			$this->proposer_request['vehicleDetails']["financierName"]= $this->proposal_data['financierName'];
		} else {
			$this->proposer_request['vehicleDetails']['isCarFinanced']= 'No';
			$this->proposer_request['vehicleDetails']["isCarFinancedValue"] = '';
			$this->proposer_request['vehicleDetails']["financierName"]= '';
		}
		
		 
	}

	// maping field with request perameter
	public function getRequestMap($map_for = null) {
		$fields = [
					'proposerDetails' => ['addressOne'=>['houseno','street']	
										,'addressTwo' => 'locality'
										,'regCity' => 'city'
										,'regPinCode' => 'pincode'
										,'nomineeName' => 'nomineeName'
										,'nomineeAge' => 'nomineeAge'
										,'relationshipWithNominee' => 'nomineeRel'
										,'dateOfBirth' => 'cust_dob'
										,'occupation' => 'occupation'
										,'userName' => 'fullname'
										,'strFirstName' => 'firstname'
										,'strLastName' => 'lastname'
										,'strMobileNo' => 'mobile'
										,'strEmail' => 'email'
					],
					'vehicleDetails' => ["carRegisteredCity"=>'city'
										,"chassisNumber"=>'chassisno'
										,"engineNumber"=>'engno'
										,"yearOfManufacture"=>'yom_selected'
										,"previuosPolicyNumber"=>'policyno'
										,"previousInsurerName"=>'previnsurance'
										,"isCarOwnershipChanged" =>'ownership_change'
										,"fuelType"=>'fuelType'
										
										,"voluntarydeductible"=>'vd'
										//,'previousPolicyExpiryDate'=>'policyExpiryDate'
										,'vehicleregDate'=>'regDate'
										,"previousinsurersCorrectAddress"=>
											['houseno','street','locality']
										,'engineCapacityAmount'=> 'engine_cc'
										,'fuelType'=> 'fuelType'
										,'idv'=> 'idv'
										,'original_idv'=> 'idv'
										,'vehicleModelCode' => 'vehicleModelCode'
										,'vehicleManufacturerName' =>	'vehicleManufacturerName'
					]
				];
		return ($map_for) ? $fields[$map_for] : $fields;
	}




	public function getDbData($session_id) {
		$car_helper = new CarHelper;
		$car_t_data = new CarTData;
		$user_data = $car_t_data->find($session_id);
		$user_map_data = (!$user_data) ? [] : $car_helper->getFieldData($user_data,$car_helper->getFieldMap());

		if(!$user_map_data['regno']){
            $car_lib = new CarLib;
            $user_map_data['regno'] = $car_lib->parseRegistrationNumber($user_data['car_rto']).'-';
            unset($car_lib);
            unset($user_data);
        }

        return $user_map_data;
	}

	public static function getDbFormatDate($date) {
		return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
	}

	public function requiredData($master) {
		$car_helper = new CarHelper;
		foreach ($master as $value) {
			$refrel_col = $this->refrel_col;
			$result = $car_helper->getMasterData($refrel_col,$value);
			$request_data[strtolower($value)] = (!empty($result)) ? $result : array();
		}
		return $request_data;
	}

	public function insertIntoTranscation($user_data,$trans_code= null){
		$car_helper = new CarHelper;
		$car_t_data = new CarTData;
		$car_t_policy = new M\CarTPolicy;
		if ($user_data && $user_data->t_status == 'TS19') {
			$user_data = $user_data->toArray();
			if($user_data['car_make'] && $user_data['car_model'])
				$car_t_policy->updateOrCreate(array('trans_code' =>
				$user_data['trans_code']),$user_data);
		}
	}
}
