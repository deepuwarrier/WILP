<?php
namespace App\Helpers\Car\TATA;

use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
class AccountingRequest{
	public $request_param = '{
    "source": "0",
    "medium": "0",
    "campaign": "0",
    "strLVTokenID": "",
    "objLVUserDataPEntryLst": {
      "UserDataPaymentEntry": {
        "AcceptanceDate": "",
        "AcceptanceVoucherNumber": "0",
        "AllocationReqd": "Y",
        "AuthorizationCode": "",
        "BGId": "0",
        "BGTag": "5",
        "BackDateAcc": "0",
        "BalanceAmount": "0",
        "BankAccountNo": "912020044796381",
        "BankCode": "1001",
        "BankName": "STATE BANK OF INDIA",
        "BatchDate": "",
        "BatchNumber": "0",
        "BckDtVal": "|",
        "BounceReason": "",
        "BranchCode": "",
        "BranchName": "",
        "BusinessLocation": "90200",
        "BusinessLocationName": "MUMBAI",
        "BusinessType": "Direct",
        "BusinessTypeCd": "1",
        "CMSSlipNumber": "",
        "CallEnv": "AP",
        "CardHolderName": "Deepak venugopal",
        "ConversionAmount": "0",
        "CounterNo": "0",
        "CurrencyAmount": "0",
        "CurrencyConcateString": "",
        "CurrencyConvertRate": "0",
        "DealerCode": "",
        "DealerName": "",
        "DecimalPaymentAmount": "13773.00",
        "DepositAdviceDate": "15/11/2017",
        "DepositOfficeCode": "90200",
        "DeptCode": "0",
        "DraweeBankLoc": "",
        "Enable_Pol_Issue_Role_Wise": "false",
        "EncodedCardNumber": "",
        "EntryDate": "",
        "ExpiryDate": "01/01/2200",
        "ForeignCurrencyAmount": "0",
        "GenPolicyNo": "1",
        "HoRefDate": "",
        "HoRefNo": "",
        "HouseBankBranchCode": "10013",
        "IFSCCode": "",
        "ILPosPaymentId": "",
        "ITSPaymentId": "0",
        "InsertedTransID": "0",
        "InstrumentTypeCd": "0",
        "InsertedTransIDDate": "",
        "IntermediaryCode": "0",
        "IntermediaryName": "",
        "InvoiceId": "",
        "InwardNumber": "0",
        "IsAcceptanceApplicable": "false",
        "IsDepositSlipNoGenerate": "false",
        "IsPortalReceipt": "false",
        "MICRNumber": "0",
        "MICRTag": "0",
        "MerchantId": "TMINSTAIN",
        "ModifiedTransID": "0",
        "ModifiedTransIDDate": "",
        "MonthEndExtension": "",
        "MultiCustomerApplicability": "true",
        "MultiCustomerConcat": "",
        "MultiCustomerFlag": "N",
        "NoteNumber": {
          "KeyValueOfstringint": [
            {
              "Key": "TotalAmount",
              "Value": "0"
            },
            {
              "Key": "Thousand",
              "Value": "0"
            },
            {
              "Key": "Fivehundred",
              "Value": "0"
            },
            {
              "Key": "Hundred",
              "Value": "0"
            },
            {
              "Key": "Fifty",
              "Value": "0"
            },
            {
              "Key": "Twenty",
              "Value": "0"
            },
            {
              "Key": "Ten",
              "Value": "0"
            },
            {
              "Key": "Five",
              "Value": "0"
            },
            {
              "Key": "Two",
              "Value": "0"
            },
            {
              "Key": "One",
              "Value": "0"
            }
          ]
        },
        "NsurPlusPaymentID": "",
        "PayerCustomerId": "1000122958",
        "PayerName": "Deepak venugopal",
        "PayerType": "Direct",
        "PayerTypeCd": "1",
        "PayinSlipDate": "",
        "PayinSlipNumber": "0",
        "PaymentAmount": "13773",
        "PaymentDate": "15/11/2017",
        "PaymentId": "",
        "PaymentMode": "DA",
        "PaymentNumber": "9999999999999999",
        "PaymentType": "-1",
        "PolicyNumber": "",
        "PostAuthCode": "JIC45813377122",
        "ProducerCode": "3051994444",
        "PropCount": "0",
        "ReceiptDate": "15/11/2017",
        "ReconcileDate": "",
        "RelationShip": "",
        "Remarks": "OK",
        "Status": "",
        "YNOthersType": "",
        "TransactionId": "100000500503403",
        "TransactionTime": "15/11/2017 01:02:02 PM",
        "TransactionType": "2",
        "UserId": "3051994444",
        "UserRole": "ADMIN",
        "VoucherNoMiscTransfer": "0",
        "TAGICAccNo": ""
      }
    },
    "objUserDataSubReceipt": {
      "CallSLEnv": "AP",
      "TransactionID": "100000500503403",
      "UserID": "3051994444"
    },
    "objUserDataPaymentTaging": {
      "AutoAcceptanceApplicable": "0",
      "BankChargeAmt": "0",
      "BusinessType": "1",
      "CallSLEnv": "AP",
      "CheckAutoProposal": "1",
      "CheckAutopayment": "1",
      "ClsProposalDetailsGrd": {
        "ClsPolicyIdGrid": {
          "BankCharge": "0",
          "IsChecked": "true",
          "ProposalDate": "15/11/2017",
          "ProposalNo": "201711140002188"
        }
      },
      "DealerId": "",
      "FinancierID": "0",
      "GenPolicy": "0",
      "InstrumentAmount": "0",
      "IntermediaryId": "0",
      "Is64vbAllowed": "false",
      "IsAutoPaymentChecked": "false",
      "IsAutoPropChecked": "false",
      "IsCreditPolicy": "false",
      "IsShortFallNonAllowedFlg": "false",
      "IsShortPremAllowedFlg": "false",
      "MaxPremium": "0",
      "ModeOfEntry": "5",
      "MonthlyExtension": "0",
      "OfficeCode": "90200",
      "OtherBankApplicability": "0",
      "PayerId": "1000122958",
      "PayerType": "",
      "ProposalAmount": "13773",
      "ProposalId": "201711140002188",
      "ProposalUnPaidAmount": "0",
      "ShortPremium": "0",
      "TagSequence": "0",
      "TotalInstrumentBalanceAmount": "0",
      "TransactionId": "100000500503403",
      "TransactionTime": "15/11/2017 01:02:02 PM",
      "UserId": "3051994444",
      "WorkflowName": ""
    },
    "lstExistPayments": ""
  }';

  public $Source = 'TATA-AIG';
  public $Medium = 'INSTAINSURE';
  public $Campaign = 'INSTAINSURE';
  public $UserRole = 'BROKER CORPORATE';
  public $UserId = '0033677004';

	//public $BankCode = 0;
	// public $BankName = 0;
  public $BankName = 'HSBC Bank'; // Bank Details
	public $BankAccountNo = '002176410002'; // Bank Account Number
  public $BankCode = '1907';  // Bank Code
  public $BusinessLocation = '90500';
  public $BusinessLocationName = 'Bangalore';
  public $DepositOfficeCode = '90500';
  public $HouseBankBranchCode = '19071037';

  public $PayerType = 1;
	public $PayerTypeCd = 1;
	public $PaymentNumber = '9999999999999999';
	public $BusinessType = 'BROKER CORPORATE';
	public $BckDtVal = '|';

  

	public  function __construct($user_data,$pgresp_arr){
    try{
      $car_helper = new CarHelper;
      $this->request = json_decode($this->request_param,true);   
      $obj = new \StdClass();
      $obj->ProposalDate = date('d/m/Y');
      $obj->PayerType = $this->PayerType;
      $obj->PayerTypeCd = $this->PayerTypeCd;
      $obj->PaymentAmount = (int)$pgresp_arr['ammount']; //pg
      $obj->DecimalPaymentAmount  = (isset($user_data->final_premium) && $user_data->final_premium)? $user_data->final_premium : $user_data->totalpremium;

      $obj->ProposalAmount = (isset($user_data->final_premium) && $user_data->final_premium)? $user_data->final_premium : $user_data->totalpremium;

      $obj->PaymentDate = date('d/m/Y');
      $obj->MICRTag = '';
      
      $obj->Source = $this->Source;
      $obj->Medium = $this->Medium;
      $obj->Campaign = $this->Campaign;
      $obj->UserRole = $this->UserRole;
      $obj->UserId = $this->UserId;

      $obj->PaymentNumber = $this->PaymentNumber;
      $obj->BankCode = $this->BankCode;
      $obj->BankName = $this->BankName;
      $obj->BankAccountNo = $this->BankAccountNo;
      $obj->BusinessLocation = $this->BusinessLocation; 
      $obj->DepositOfficeCode = $this->DepositOfficeCode;
      $obj->BusinessLocationName = $this->BusinessLocationName;
      $obj->HouseBankBranchCode = $this->HouseBankBranchCode;
      $obj->ProducerCode = Car_Constants::TATA_PRODUCER_CODE;

      $obj->CardHolderName = '';
      $obj->PayerCustomerId = isset($user_data->customer_id) ?$user_data->customer_id:0;
      $obj->ProposalNo = isset($user_data->proposal_nu) ?$user_data->proposal_nu:0;
      $obj->PayerId = isset($user_data->customer_id) ? $user_data->customer_id:0;
      $obj->TransactionId =  isset($user_data->transaction_id)? str_replace('W','',$user_data->transaction_id) : 0;
      
      $exp_date = $car_helper->manDate($user_data->policy_start_date,'d/m/Y',["-1 days","+1 year"]);
      $obj->ExpiryDate = "01/01/2200" ;  
      $obj->BckDtVal = $this->BckDtVal;
      $obj->MerchantId = $pgresp_arr['partnercode'];
      $obj->PayerName =  $user_data->usr_firstname.' '.$user_data->usr_lastname;
      // $obj->CardHolderName =  $user_data->usr_firstname.' '.$user_data->usr_lastname;
      $obj->PostAuthCode = $pgresp_arr['PostAuthCode'];
      $obj->TransactionType = '2';
      $obj->PaymentType = -1;
      $obj->BusinessTypeCd = 1;
      $obj->BusinessType = $this->BusinessType;
      // done by me
      
      $obj->ReceiptDate = date('d/m/Y');
      $obj->DepositAdviceDate = date('d/m/Y');
      $obj->TransactionTime =  date('d/m/Y h:i:s A');
      $obj->UserId = Car_Constants::INTERMEDIARY_CODE;
      $this->setData($obj);  
    }catch(\Exception $e){
        $this->request = $e->getMessage(); 
    }		
  }	

	public function setData($obj){
		$paymentTag = $this->request['objUserDataPaymentTaging'];
		$paymentTag['BusinessType'] = $obj->BusinessTypeCd;
		$paymentTag['OfficeCode'] = $obj->DepositOfficeCode;
		$paymentTag['ProposalAmount'] = $obj->ProposalAmount;
		$paymentTag['ProposalId'] = $obj->ProposalNo;
		$paymentTag['TransactionId'] = $obj->TransactionId;
		$paymentTag['UserId'] = $obj->UserId;
    $paymentTag['PayerId'] = $obj->PayerCustomerId;
    $paymentTag['TransactionTime'] = $obj->TransactionTime;
		$paymentTag['ClsProposalDetailsGrd']['ClsPolicyIdGrid']['ProposalNo'] = $obj->ProposalNo;
		$paymentTag['ClsProposalDetailsGrd']['ClsPolicyIdGrid']['ProposalDate'] = $obj->ProposalDate;
		$this->request['objUserDataPaymentTaging'] = $paymentTag;
		// 
		$subReciept = $this->request['objUserDataSubReceipt'];
		$subReciept['TransactionID'] = $obj->TransactionId;
		$subReciept['UserID'] = $obj->UserId;
		$this->request['objUserDataSubReceipt'] = $subReciept;
		//
		$payment = $this->request['objLVUserDataPEntryLst']['UserDataPaymentEntry'];
		$payment['BankAccountNo'] = $obj->BankAccountNo;
		$payment['BankCode'] = $obj->BankCode;
		$payment['BankName'] = $obj->BankName;
		$payment['BckDtVal'] = $obj->BckDtVal;
		$payment['BusinessLocation'] = $obj->BusinessLocation;
		$payment['BusinessLocationName'] = $obj->BusinessLocationName;
		$payment['BusinessType'] = $obj->BusinessType;
		$payment['BusinessTypeCd'] = $obj->BusinessTypeCd;
		$payment['DecimalPaymentAmount'] = $obj->DecimalPaymentAmount;
		$payment['DepositAdviceDate'] = $obj->DepositAdviceDate;
		$payment['DepositOfficeCode'] = $obj->DepositOfficeCode;
    $payment['HouseBankBranchCode'] = $obj->HouseBankBranchCode;
		$payment['PayerCustomerId'] = $obj->PayerCustomerId;
		$payment['PayerName'] = $obj->PayerName;
		$payment['PayerType'] = $obj->PayerType;
		$payment['PayerTypeCd'] = $obj->PayerTypeCd;
		$payment['PaymentAmount'] = $obj->PaymentAmount;
		$payment['PaymentDate'] = $obj->PaymentDate;
		$payment['PaymentNumber'] = $obj->PaymentNumber;
		$payment['PaymentType'] = $obj->PaymentType;
		$payment['PostAuthCode'] = $obj->PostAuthCode;
		$payment['ProducerCode'] = $obj->ProducerCode;
		$payment['ReceiptDate'] = $obj->ReceiptDate;
		$payment['TransactionId'] = $obj->TransactionId;
		$payment['TransactionTime'] = $obj->TransactionTime;
		$payment['TransactionType'] = $obj->TransactionType;
		$payment['UserId'] = $obj->UserId;
    $payment['MerchantId'] = $obj->MerchantId;
    $payment['CardHolderName'] = $obj->CardHolderName;
    $payment['source']  = $obj->Source;
    $payment['medium']  = $obj->Medium;
    $payment['campaign']  = $obj->Campaign;
    $payment['UserRole']  = $obj->UserRole;
		$this->request['objLVUserDataPEntryLst']['UserDataPaymentEntry'] = $payment;
	}

	public function getParam(){
		return $this->request;
	}
}
?>
