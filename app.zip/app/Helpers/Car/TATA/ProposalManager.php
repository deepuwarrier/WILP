<?php
namespace App\Helpers\Car\TATA;

use  App\Models\Car\CarTData;
use App\Helpers\Car\CarHelper;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\MasterData;
use App\Models\Car as M;
use App\Libraries\CarLib;
use App\Be\Common\PaymentParseBE;
use App\Constants\Car_Constants;

class ProposalManager{
	public $src = Car_Constants::TATA_SRC;
	public $T = Car_Constants::TATA_TOKEN;
	public $Productid = "3121";
	
	public $Sol_id = Car_Constants::TATA_SOL_ID;
	
	public $proposal_service_url = Car_Constants::TATA_PROPOSAL_URL;	//"https://pipuat.tataaiginsurance.in/tagichubms/ws/v1/ws/tran2/proposal";
	// public $payment_service_url = "https://pay.tataaig.com/PaymentGatewayAggr/_tataaig_payment";
	public $payment_service_url = "https://pay.tataaig.com/PaymentGatewayAggr/_tataaig_payment_net";

	private $ref_col = "tata_code";

	public function __construct(){
	}

	public function genPaymentResuest($user_data,$proposal_resp){
		$car_h = new CarHelper;
		$payment_parse_be = new PaymentParseBE;
		$time_now=mktime(date('h')+5,date('i')+30,date('s'));
        $time_now=date('d-m-Y H:i:s',$time_now);
		$payment_request = file_get_contents(__DIR__.'/Payment_request.json');
		$payment_request = json_decode($payment_request,true);
		$payment_request['sourceReturnUrl'] = route('car.policy.tata.returnPage');
		$payment_request['transactionID'] = $user_data->trans_code;//'PC'.round($car_h->getMilitime());
		if($user_data->type_of_business == "Rollover")
			$payment_request['businessType'] = "2";
		
		$payment_request['reqID'] = $user_data->trans_code;//"".round($car_h->getMilitime());
		$payment_request['policyNumber'] = $user_data->proposal_nu;
		$payment_request['paymentAmount'] = $proposal_resp['data']['premiun'];
		$payment_request['transTimeStamp'] = date('d-m-Y H:i:s.').$this->getMilisecond();
		$response = ['url'=>$this->payment_service_url
					,'fields'=>['pgiRequest'=>$payment_request]];
		$payment_parse_be->setPaymentIdentifier($user_data->trans_code);
		return $response;
	}

	private function getMilisecond(){
		$times = gettimeofday();
		$seconds = strval($times["sec"]);
		$milliseconds = strval(floor($times["usec"]/1000));
		$missingleadingzeros = 3-strlen($milliseconds);
		if($missingleadingzeros > 0){
			for($i = 0; $i < $missingleadingzeros; $i++){
				$milliseconds = '0'.$milliseconds;
			}
		}
		return $milliseconds;
	}

	public function storeStatusAndTransaction($status,$trans_code){
		$car_t_data = new CarTData;
		$car_lib = new CarLib;
		$car_helper = new CarHelper;
		$car_t_policy = new M\CarTPolicy;
		$t_status = ($status) ? 1 : 2;
		// store success or failed in databse
		$user_data = $car_lib->storeStatus($t_status,$trans_code);
		if ($user_data->t_status != 'TS19') {
			return $user_data->t_status;
		}

		if ($user_data && 'TS19' == $user_data->t_status) {
			$user_data = $user_data->toArray();
			$user_data = $car_t_data->find($trans_code.'_DONE')->toArray();
			if($user_data['car_make'] && $user_data['car_model']){
				$car_t_policy->updateOrCreate(['trans_code'=>$user_data['trans_code']],$user_data);
			}
		}
	}
	
	public function genProposalRequest($user_data){
		//$user_data,$reques
		$this->car_h = new CarHelper();
		$this->master = new MasterData();
		$this->proposal_request = file_get_contents(__DIR__.'/PC_Proposal_Request.json');
        $this->proposal_request = json_decode($this->proposal_request,true);
		$this->proposal_request['quotation_no'] = $user_data->quote_id;//"PHQ/3121/0000018752";
		$this->proposal_request['sol_id']  = $this->Sol_id;
		$this->proposal_request['productcod']  = $this->Productid;
		$this->proposal_request['lead_id']  = "";
		$this->proposal_request['sp_name']  = "";
		$this->proposal_request['sp_license']  = "";
		$this->proposal_request['sp_place']  = "";
		$this->proposal_request['pol_sdate'] = $this->car_h->changeFormat($user_data->policy_start_date,'Ymd');
		
		$this->setCustomerDetails($user_data);
		$this->setVehicleDetails($user_data);
		$this->setPrevPolicyDetails($user_data);
		$this->setFinancierDetails($user_data);
		$this->setNomineeDetails($user_data);
		$this->setDriverDetails($user_data);
		return $this->proposal_request; 
	}	

	private function setDriverDetails($user_data){
		return 1;
		$driver = $this->proposal_request['driver'];
		$driver["flag"] = "Y";
		$driver["gender"] = ($user_data->usr_gender == "F") ?  'Female' : 'Male';
		$driver["fname"] =  $user_data->usr_firstname;
		$driver["lname"] = $user_data->usr_lastname;
		$driver["age"] = date('Y-m-d') - $user_data->usr_dob;
		$driver["marital_status"] = $user_data->usr_marital_status;
	}

	private function setNomineeDetails($user_data){
		$nominee = $this->proposal_request['nominee'];
		$nominee['name'] = $user_data->nominee_name;
		$nominee['age'] = $user_data->nominee_age;
		$nominee["relation"] = $this->master->getNomineeCode($this->ref_col,$user_data->nominee_rel);
		$this->proposal_request['nominee'] = $nominee;
	}

	private function setFinancierDetails($user_data){
		if($user_data->veh_vehicle_financed && $user_data->veh_vehicle_financed == 'N')
			return 1;

		$financier = $this->proposal_request['financier'];
		$financier["type"] = 	$user_data->veh_type_of_finance;
		$financier["name"] =	$user_data->veh_financierName;
		$financier["address"] =	"";
		$this->proposal_request['financier'] = $financier;
	}

	private function setCustomerDetails($user_data){
		$customer = $this->proposal_request['customer'];
		if($user_data->usr_gender == "F"){
			$customer["salutation"] = 'MISS';
			$customer["gender"] = 'Female';
				
		}
		$customer["client_type"] = "individual";
		$customer["first_name"] =  $user_data->usr_firstname;
		$customer["last_name"] = $user_data->usr_lastname;
		$customer["dob"] = $this->car_h->changeFormat($user_data->usr_dob,'Ymd');
		$customer["marital_status"] = $user_data->usr_marital_status;
		$customer["address_1"] = $user_data->usr_houseno;
		$customer["address_2"] = $user_data->usr_street;
		$customer["address_3"] = $user_data->usr_locality;
		$customer["address_4"] = '';
		$customer["pincode"] = $user_data->usr_pincode;
		$customer["account_no"] = "";
		$customer["cust_aadhaar"] = $user_data->usr_aadharno;
		$customer["mobile_no"]	= $user_data->usr_mobile;
		$customer["email_id"]	= $user_data->usr_email;
		$this->proposal_request['customer'] = $customer;
	}

	private function setVehicleDetails($user_data){
		$vehicle = $this->proposal_request['vehicle'];
		$vehicle['engine_no'] = $user_data->veh_eng_no;
		$vehicle['chassis_no'] = $user_data->veh_chassisno;
		$this->proposal_request['vehicle'] = $vehicle;
	}

	private function setPrevPolicyDetails($user_data){
		if(strtolower($user_data->type_of_business) != 'rollover')
			return 1;

		$prev_pol = $this->proposal_request['prevpolicy'];
		$prev_pol['flag'] = "Y";
		$prev_pol['code'] =  $this->master->getInsurerCode($this->ref_col,$user_data->prev_insurance);
		$prev_pol['name'] =  $this->master->getInsurerName($user_data->prev_insurance);
		$prev_pol['address1'] =  $user_data->previnsurance_addr;
		$prev_pol['polno'] = $user_data->prev_policyno;
		$this->proposal_request['prevpolicy'] = $prev_pol;
	}

	public function getProposalResponse($response){
		$result = [];

		if(!$response)
			return ['error'=>"Please try again"];

		if(is_array($response) && array_key_exists('data',$response))
			$result = json_decode($response['data'],true);

		if(array_key_exists('errcode',$result['data']) && $result['data']['errcode'] != '')
			return ['error'=>$result['data']['message']];

		return $result;
	}

	public function callProposal($request,$trans_code = null){
		$car_h = new CarHelper;
		$request = json_encode($request);
		$title = "TATA Proposal";
		$url = $this->proposal_service_url;
		
		$postFields = ["PDATA"=>$request,
						"SRC"=>$this->src,
						"T"=>$this->T,
						"product_code"=>$this->Productid,
						"THANKYOU_URL"=>'ewffee'];

		$config['content-type'] = "application/x-www-form-urlencoded";
		$config['post-type'] = "http";

		return $this->call_curl_api($title,$url, $postFields,$config,$trans_code);
	}


	public function call_curl_api($title,$url, $postFields ,$http_config = null,$trans_code = null){
		if(is_array($postFields))
			Log::info('CAR '.$title.' Request Array - '.$trans_code.' - ', $postFields);
		else
			Log::info('CAR '.$title.' Recquest - '.$trans_code.' - '.$postFields);
		$curl = curl_init();

		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS =>  http_build_query($postFields),
			CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded"),
		));
		$response = array();
		$data = curl_exec($curl);

		if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
			$response['data'] = $data;
		else 
			$response['data'] = json_decode($data, true);
		
		if(is_array($response))
			Log::info('CAR '.$title.' Response - '.$trans_code.' - ',$response);
		else 
			Log::info('CAR '.$title.' Response - '.$trans_code.' - '.$response);

		if (empty($response['data'])) {
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}

		curl_close($curl);
		return $response;
	}
}


