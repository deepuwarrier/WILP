<?php
namespace App\Helpers\Car\TATA;

use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use App\Libraries\CarLib;
use App\Constants\ Car_Constants;

class ProposalRequest{
  public $gstNumber;
  public $PropRisks_Campaign = 0;
  public $PropRisks_OpenCvrNo = 'false';
  // public $PropGeneralProposalInformation_POSPANNo;
  // public $PropGeneralProposalInformation_POSAadhaarNo;
  // public $PropRisks_Age = 50;
  // public $PropRisks_Lifemember  ='false';
  // public $PropRisks_OpenCvrNo = 'false';
  // public $PropDistributionChannel_BusineeChanneltype;
  // public $PropRisks_HomeAway = 'false';
  // public $PropGeneralProposalInformation_iscovernoteused = 'false';
  // //mandatry
  // public $PropRisks_SumAssuredAOY = 10000;
  // Proposer Details

  
  public $PropRisks_ProposalType = 'New Business';
  public $PropRisks_ProposalType_Mandatary = 'New Business';
  public $PropCustomerDtls_CustomerType = 'I';
  public $CustomerType = 'I';
  public $PropRisks_PinCode;
  public $PropRisks_Gender = 'MALE';
  public $Gender = 'MALE';
  public $PropRisks_MaritalStatus = 'UNKNOWN';
    // customer details
  public $Salutation = 'MR';
  public $Occupation = 23;
  public $MiddleName = '';
  public $SourceOfFund = 'Others';
  public $PANNo;
  public $FirstName;
  public $LastName;
  public $DOB;
  public $MobileNo;
  public $LandLineNo= '';
  public $AlternateMobileNo = '';
  public $idproof = 0;
  public $IsThinCustomer = 'false';
  public $PermanentLocationSameAsMailLocation = 'false';
  // end Proposer Details

  // Communication
  public $PropRisks_Registrationaddressline1; // House No
  public $PropRisks_Registrationaddressline2; // street
  public $PropRisks_Registrationaddressline3; // area
  public $PropRisks_City;
  public $PropRisks_CityCode;
  public $PropRisks_State;
  public $PropRisks_StateCode;
  public $PropRisks_RegistrationAddressSameComm = 'true';
  // End Communication

  // Car Details
  public $RegNoNotRequired = 'true';
  public $PropRisks_CubicCapacity;
  public $PropRisks_IDVofthevehicle;
  public $PropRisks_ManufacturerCode; 
  public $PropRisks_VariantCode;
  public $PropRisks_ModelCode; 
  public $PropRisks_Manufacture;
  public $PropRisks_ModelVariant;
  public $PropRisks_Model;
  public $PropRisks_FuelType;
  public $PropRisks_ManufactureYear;
  public $PropRisks_YearLicensed;
  public $PropRisks_VehicleAge_Mandatary;
  public $PropRisks_Engineno;
  public $PropRisks_ChassisNumber;
  public $PropRisks_Typeofbody; 
  public $PropRisks_RegistrationNumber;
  public $PropRisks_RegistrationNumber2;
  public $PropRisks_RegistrationNumber3;
  public $PropRisks_RegistrationNumber4;
  // public $PropRisks_NumberOfPersonsUnnamed = 5;
  // public $PropRisks_SeatingCapacity = 5;
  // End Car Details
  
  // previus policy details
  public $PropPreviousPolicyDetails_PolicyNo;
  public $PropPreviousPolicyDetails_PreviousPolicyType;
  public $PropPreviousPolicyDetails_CorporateCustomerId_Mandatary;
  public $PropPreviousPolicyDetails_PolicyEffectiveFrom;
  public $PropPreviousPolicyDetails_PolicyEffectiveTo;
  public $PropPreviousPolicyDetails_PreviousInsPincode;
  public $PropRisks_EntitledforNCB = 'No';
  
  // claim details
  public $PropRisks_NoClaimBonusApplicable =  0;
  public $PropPreviousPolicyDetails_NoOfClaims;
  public $PropPreviousPolicyDetails_ClaimAmount;
  public $PropPreviousPolicyDetails_ClaimLodgedInPast;
  public $PropPreviousPolicyDetails_NCBPercentage;
  public $PropRisks_PrevYearNCB;
  public $PropGeneralProposalInformation_IsNCBApplicable = 'false'; // for new business
  //end claim details

  // Addon
  // public $PropRisks_EngineSecure = 'false'; // ep
  // public $PropRisks_RoadsideAssistance = 'false'; // rsac
  // public $PropRisks_DepreciationReimbursement = 'false'; // zerodep
  // public $PropRisks_ReturnToInvoice = 'false'; // rti
  // public $PropRisks_OtherChk2 = 'false'; // papass
  // public $PropRisks_WiderLegalLiabilityToPaid = 'false';
  public $PropRisks_CompulsoryPAwithOwnerDriver = 'true';
    // we don't provide
  // public $PropRisks_TyreSecure = 'false';
  // public $PropRisks_KeyReplacement = 'false';
  // end Addon

  public $PropRisks_Dateofpurchase;
  public $PropRisks_DateofRegistration;

  // financier details
  public $PropFinancierDetails_AgreementType;
  public $PropFinancierDetails_FinancierName ; //  master
  public $PropFinancierDetails_LoanAccountNo;
  public $PropFinancierDetails_BranchName;
  public $PropFinancierDetails_Country;
  public $PropFinancierDetails_FinancierStatus;
  public $PropFinancierDetails_Remarks;
  public $PropFinancierDetails_FinancierType;
  public $PropFinancierDetails_FinancierCode_Mandatary;
  public $PropFinancierDetails_CityCode;
  public $PropFinancierDetails_DistrictCode; //master
  public $PropFinancierDetails_StateCode;
  public $PropFinancierDetails_Pincode;
  public $PropFinancierDetails_State;
  public $PropFinancierDetails_City;
  public $PropFinancierDetails_District;
  public $PropFinancierDetails_Address;
  public $PropFinancierDetails_SrNo_Mandatary;
  public $PropFinancierDetails_IsDataDeleted;
  public $PropFinancierDetails_IsOldDataDeleted;
  
  // Deafult Tag and Value 
  public $PropRisks_MainDriver = 'Paid Driver';
  public $PropRisks_OtherInformation1T = 19219;
  public $PropRisks_VehicleType = 'Indigenous';
  public $PropGeneralProposalInformation_BusinessType_Mandatary  = 'New Business';
  public $PropIntermediaryDetails_IntermediaryName = 'Ram Singh'; //Producer Name
  public $PropGeneralProposalInformation_PolicySchedule_Mandatary = 'Yes'; // print option online
  public $PropRisks_VehiclePurchaseAs = 'Brand new'; // brand or used
  public $PropDistributionChannel_BusinessSource_Mandatary = 'INTERMEDIARY';
  public $PropGeneralProposalInformation_MethodOfCalculation = 'GCWINPR05';
  // 1. No Exemption 2. SEZ 3. Foregin Embassy
  public $PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary = 'SEZ';
  public $PropRisks_RiskVariant = 'PackageComprehensive'; // package or ll
  // public $PropRisks_AddOnPlanSelected =  "Optional";
  public $OtherDetailsGrid  = [];
  public $PropProductDetails_ProductCode;
  public $PropRisks_IsVehicleUsedforblindpersons = 'false';
  public $PropEndorsementDtls_IsSellerInsured = 'false';

  // Proposal Date
  public $PropPolicyEffectivedate_Fromdate_Mandatary;
  public $PropPolicyEffectivedate_Fromhour_Mandatary; //current time
  public $PropPolicyEffectivedate_Todate_Mandatary; // greater than the policy Start Date.
  public $PropPolicyEffectivedate_Tohour_Mandatary = '23:59'; 
  public $PropGeneralProposalInformation_ProposalDate_Mandatary; // current date

  // From Master
  public $PropRisks_AuthorityLocation; // RTO master
  public $PropGeneralProposalInformation_OfficeName; // Previuos Insurer Office Master
  public $PropRisks_CityWherePrimarilyUsed;  // RTO master
  public $PropRisks_Airbag ='N'; // fetched from Vehicle Model Master.
  public $PropRisks_VehicleTypeCode = 45; // Vehicle Master
  public $PropRisks_RTOCode; // RTO master
  public $PropRisks_RTOGroupCode; // RTO master

  public $PropRisks_InsuredHasDrivinglicense = 'true'; // Mandatory if owner driver is selected. Pass value true/false true/false to be entered
  public $PropGeneralNodes_ApplicationDate; // current date
  
  public $QuotationNumber; 
  public $EmailId;
  
  // dont'know
  public $PropSerIntermediaryDetails_SerIntermediaryCode = ''; 
  public $PropRisks_NumberOfPersonsNamed = 0;
  public $PropGeneralProposalInformation_DisplayOfficeCode;
  public $PropRisks_AutoTransmission = 'N';
  public $PropRisks_VehicleSegment; //  This field will be auto-populated
  public $PropRisks_PreSourceApproval = 'false';
  //public $PropCustomerDtls_CustomerName;

  // Registration authority auto
  public $PropRisks_Zone_Mandatary; 
  public $PropRisks_LoadingNewCarRplacmnt = '0';
  //  not understand
  public $PropRisks_CountryCode = 64;
  //public $PropCustomerDtls_CustomerID_Mandatary;

  //public $PropRisks_RatioofAOAinAOY = '1:2';

  public function __construct(TataProposalManager $manager){
    $this->PropRisks_BasisOfRating = Car_Constants::TATA_BASIC_OF_RATING;
    $this->PropRisks_GLMRate = Car_Constants::TATA_GLMRate;
    $this->PropIntermediaryDetails_IntermediaryCode = Car_Constants::TATA_IntermediaryCode;
    $this->PropMODetails_TertiaryMOCode = Car_Constants::TATA_TertiaryMOCode; 
    $this->manager = $manager;
    $this->setPropProductDetailsProductCode(Car_Constants::TATA_PRODUCT_CODE);
    $this->setPropGeneralProposalInformationMethodOfCalculation(Car_Constants::METHOD_OF_CALCULATION);
    $this->setPropGeneralProposalInformationDisplayOfficeCode(Car_Constants::DISPLAY_OFFICE_CODE);
    $this->PropDistributionChannel_BusineeChanneltype = '';
  }

  public function setData(CarTData $user_data){
    $car_helper = new CarHelper;
    $car_lib = new CarLib;
    $car_variant = new M\CarVariant;
    $this->OtherDetailsGrid['OwnerDriverNomineeDetails'] = ['attribute'=>['Name' => 'OwnerDriverNomineeDetails',
                   'Value'=> 'GRP292']];
    $this->setNomineeDetails($user_data);
    $this->setProposerDetails($user_data);
    $this->setElctronicsDetails($user_data);
    $this->setNonElctronicsDetails($user_data);
    $this->setCommunicationDetail($user_data);
    $this->setCarDetails($user_data);
    $this->setProposalRegistrationAddress($user_data);
    $this->setFinanceDetail($user_data);
    $curent_date = date('d/m/Y');
    $this->setPropPolicyEffectivedateFromdateMandatary($car_helper->manDate($user_data->policy_start_date,'d/m/Y'),['+1 Days']);
    $this->setPropPolicyEffectivedateTodateMandatary($car_helper->manDate($user_data->policy_start_date,'d/m/Y',['-1 Days','+1 Year']));
    $this->setPropGeneralNodesApplicationDate($curent_date);
    $this->setPropGeneralProposalInformationProposalDateMandatary($curent_date);
    //$this->setPropCustomerDtlsCustomerIDMandatary('1000083054');
    $this->setQuotationNumber($user_data->quote_id);
    if($this->getPropRisksProposalType() == 'Rollover'){
      $this->setPrevPolicyDetails($user_data); 
      $this->setClaimDetails($user_data);        
    }
    $this->setPropRisksRTOCode(strtoupper($car_lib->parseRegistrationNumber($user_data->car_rto)));
    $reg_date = $car_helper->changeFormat($user_data->car_registration_date,'d/m/Y');
    $this->setPropRisksDateOfPurchase($reg_date);
    $this->setPropRisksDateOfRegistration($reg_date);
    unset($reg_date);
    
    $this->PropGeneralProposalInformation_OfficeCode =  Car_Constants::OFFICE_CODE;
    $this->PropGeneralProposalInformation_BranchOfficeCode =  Car_Constants::BRANCH_OFFICE_CODE;
    $this->setPropGeneralProposalInformationOfficeName(Car_Constants::PROPOSAL_INFORMATION_OFFICE_NAME);
    
    $this->setPropPolicyEffectivedateTohourMandatary("23:59");

    $this->setPropIntermediaryDetailsIntermediaryName(Car_Constants::INTERMEDIARY_NAME);

    $this->setPropGeneralProposalInformationDisplayOfficeCode(Car_Constants::DISPLAY_OFFICE_CODE);

    $this->setPropRisksSeatingCapacity($car_variant->getVehicleId($user_data->car_variant,'seat_capacity')->seat_capacity);

    $this->PropRisks_ABS = ($car_variant->getVehicleId($user_data->car_variant,'abs')->abs == 'Y')?'true':'false';
    $this->setPropPolicyEffectivedateFromhourMandatary('00:00:01');
    $this->setPropRisksAirbag((($car_variant->getVehicleId($user_data->car_variant,'airbag')->airbag == 'Y')?'true':'false'));
    $this->setPropRisksAutoTransmission((($car_variant->getVehicleId($user_data->car_variant,'auto_transmission')->auto_transmission == 'Y')?'true':'false'));
    unset($this->manager);
    $this->setPropRisksVehiclePurchaseAs(($this->getPropRisksProposalType() == 'Rollover')?'':'Brand new');
    $this->setAddon($user_data);
    // $this->PropPreviousPolicyDetails_CorporateCustomerId_Mandatary = 'TATAAIG';
    // unset($this->PropPreviousPolicyDetails_CorporateCustomerId_Mandatary);
    // $this->IsThinCustomer = ['false','false'];
    unset($this->vehicle_segment);
    $this->request = get_object_vars($this);
    
    //unset($this->request['PropCustomerDtls_CustomerType']);
    return 0;  
  }
  
  private function setFinanceDetail($user_data){
    $master_pincode = new  M \ MasterPincode;
    if($user_data->veh_vehicle_financed != 'Y')
      return 0;
    switch ($user_data->veh_type_of_finance) {
      case 'Hire purchase':
        $this->setPropFinancierDetailsAgreementType('Hire Purchase');
        break;
      case 'Hypothecation':
        $this->setPropFinancierDetailsAgreementType('Hypothecation');
        break;
      case 'Lease':
        $this->setPropFinancierDetailsAgreementType('Lease agreement');
        break; 
      default:
       $this->setPropFinancierDetailsAgreementType('');
        break;
    }
    $this->setPropFinancierDetailsFinancierName($user_data->veh_financierName);
    $this->setPropFinancierDetailsCity($this->getPropRisksCity());
    $this->setPropFinancierDetailsCityCode($this->getPropRisksCityCode());
    $this->setPropFinancierDetailsState($this->getPropRisksState());
    $this->setPropFinancierDetailsStateCode($this->getPropRisksStateCode());
    $this->setPropFinancierDetailsCountry(Car_Constants::TATA_COUNTRY_NAME);
    $this->setPropFinancierDetailsPincode($user_data->usr_pincode);
    $this->setPropFinancierDetailsLoanAccountNo('');
    $this->setPropFinancierDetailsFinancierType('');
    $this->setPropFinancierDetailsFinancierCodeMandatary('');
    $pincode_data = $master_pincode->getPincode($user_data->usr_pincode);
    $this->setPropFinancierDetailsDistrictCode($pincode_data->tata_dist_code); //master
    $this->setPropFinancierDetailsDistrict($pincode_data->dist_name);
    $this->setPropFinancierDetailsAddress('');
    $this->setPropFinancierDetailsSrNoMandatary('');
    // dont'e knoe
    $this->setPropFinancierDetailsIsDataDeleted('');
    $this->setPropFinancierDetailsIsOldDataDeleted('');
    $this->setPropFinancierDetailsRemarks('');
    $this->setPropFinancierDetailsBranchName('');
    $this->setPropFinancierDetailsFinancierStatus('');
  }

  private function setElctronicsDetails($user_data){
    if(!$user_data->veh_electricle)
      return 0;
    // $car_helper = new CarHelper;
    // $car_reg_year = $car_helper->changeFormat($user_data->car_registration_date,'Y');
    $this->PropRisks_ElectricalAccessories = $user_data->veh_electricle;
    $node = &$this->addGridDetails('ElectricalAccessiories','GRP289');
    $this->addAttribute($node,'Make','N/A');
    $this->addAttribute($node,'Model','N/A');
    $this->addAttribute($node,'Year',date('Y',strtotime($user_data->veh_electricle_date))); 
    $this->addAttribute($node,'IDV',$user_data->veh_electricle,"Double");
    $this->addAttribute($node,'TypeofAccessories','Other');
    $this->addAttribute($node,'Description','N/A');
    $this->addAttribute($node,'SerialNo','');
    $this->addAttribute($node,'Remarks','');
    unset($car_reg_year);
  }

  private function setNonElctronicsDetails($user_data){
    if(!$user_data->veh_no_electricle)
      return 0;
    // $car_helper = new CarHelper;
    // $car_reg_year = $car_helper->changeFormat($user_data->car_registration_date,'Y');
    $this->PropRisks_NonElectricalAccessories = $user_data->veh_no_electricle;
    $node = &$this->addGridDetails('NonElectricalAccessiories','GRP288');
    $this->addAttribute($node,'Make','N/A');
    $this->addAttribute($node,'Model','N/A');
    $this->addAttribute($node,'Year',date('Y',strtotime($user_data->veh_no_electricle_date))); 
    $this->addAttribute($node,'IDV',$user_data->veh_no_electricle,"Double");
    $this->addAttribute($node,'TypeofAccessories','Other');
    $this->addAttribute($node,'Description','N/A');
    $this->addAttribute($node,'SerialNo','');
    $this->addAttribute($node,'Remarks','');
    unset($car_reg_year);
  }


  private function &addGridDetails($name,$value){
    $this->OtherDetailsGrid[$name] =  ['attribute'=>['Name'=>$name,
                                 'Value'=>$value]];
    $this->OtherDetailsGrid[$name][$name] = ['attribute'=> ['Type' => 'GroupData']];
    return $this->OtherDetailsGrid[$name][$name];
  }

  private function addAttribute(&$tag,$name,$value,$type = 'String'){
    $tag[$name] = ['attribute'=>['Name'=>$name,
                                 'Value'=>$value,
                                   'Type' =>$type]]; 
  }

  private function setNomineeDetails($user_data){
     $car_helper = new CarHelper;
    $nominee_name = $user_data->nominee_name;
    $nominee_rel = $car_helper->getMasterId($this->manager->refrel_col,'NomineeRelationship',$user_data->nominee_rel);

    $nominee_age = $user_data->nominee_age;
    $ownerDriverDetail = ['attribute'=> ['Type' => 'GroupData'],
      'Nominee'=>['attribute'=>['Name'=> 'Nominee',
                                'Value'=> $nominee_name,
                                'Type' => 'String']],
      'Age'=>['attribute'=>['Name'=> 'Age',
                            'Value'=> $nominee_age,
                            'Type' => 'Double']],
      'Relationship'=> ['attribute'=>['Name'=> 'Relationship',
                                      'Value'=> $nominee_rel,
                                      'Type' => 'String']
                        ]];
    $this->OtherDetailsGrid['OwnerDriverNomineeDetails']['OwnerDriverNomineeDetails'] = $ownerDriverDetail;
    $this->PropRisks_NameOfNominee  = $nominee_name;
    $this->PropRisks_AgeCoverageDetails = $nominee_age;
    $this->PropRisks_Relationship = $nominee_rel;
    unset($nominee_name);
    unset($nominee_age);
    unset($nominee_rel);
  }

  private function setAddon($user_data){
    $car_variant = new M\CarVariant;

    // Addon as per the Packages selected
    $packages = Car_Constants::TATA_PACKAGES;
    $product_id = $user_data->product_id;
    if(array_key_exists($product_id, $packages)){
      foreach ($packages[$product_id] as $key1 => $value1) {
        if($key1 == 'package'){
          $this->setPropRisksAddOnPlanSelected($value1);
        }         
        else {
          foreach ($value1 as $addon) {
            ${$addon.'_eligibility'} = 1;
          }
        }
      }
    }

    // Packages end here
    // Filters the addon selected
    $addon = explode(",",trim($user_data->covers_selected));
    foreach ($addon as $key => $value) {
      $addon[strtolower($value)] = strtolower($value);
    }

    $this->PropRisks_AddOnChoiceOpted = 'Choice 1';
    $this->PropRisks_EngineSecure = (isset($ep_eligibility))? 'true':'false';
    if(isset($ep_eligibility))
      $this->PropRisks_EngineSecureOptions = ($this->getVehicleSegment()=='High End')?'Without Deductible':'With Deductible';

    $this->PropRisks_RoadsideAssistance = (isset($rsac_eligibility))?'true':'false';

    $this->PropRisks_ReturnToInvoice = (isset($rti_eligibility))? 'true':'false';
    $this->PropRisks_OtherChk2 = ((isset($papass_eligibility)) && (isset($addon['papass'])))?'true':'false';
    if((isset($papass_eligibility)) && (isset($addon['papass']))){
      $this->PropRisks_NumberOfPersonsUnnamed = $car_variant->getVehicleId($user_data->car_variant,'seat_capacity')->seat_capacity;//seating capacity value
      $this->PropRisks_CapitalSIPerPerson = 100000;  // max 2l 
    }

    $this->PropRisks_DepreciationReimbursement = (isset($zerodep_eligibility))?'true':'false';
    $this->PropRisks_NoOfClaimsDepreciation =  (isset($zerodep_eligibility))?'2':'0';
    
    // LL for paid driver
    $this->PropRisks_OtherChk3 = 'false';  // for paid driver
    $this->PropRisks_NoOfPersonsPaidDriver = '';  // for paid driver
    $this->PropRisks_SumInsuredPaidDriver = ''; 
    // LL for paid driver ends above
    $this->PropRisks_WiderLegalLiabilityToPaid = 'true';
    $this->PropRisks_NoOfPersonWiderLegalLiability = '1'; // Less then seating capacity

    // Emergency Hotel & Transportation
    if($et_hotelexpenses_eligibility){
      $this->PropRisks_EmergTrnsprtAndHotelExpensIDV = '10000';
      $this->PropRisks_RatioofAOAinAOY = '1:1';
      $this->PropRisks_SumAssuredAOY = '10000';
      $this->PropRisks_SumAssuredAOA = '10000';
    }

    // Key Replacement
    $this->PropRisks_KeyReplacement =  (isset($keyreplace_eligibility))?'true':'false';
    $this->PropRisks_SumAssuredKeyReplacement = (isset($keyreplace_eligibility))?'25000':'0';

    // Daily Allowance
    $this->PropRisks_DailyAllowance = (isset($daily_allowance_eligibility))?'true':'false';
    if(isset($daily_allowance_eligibility)){
      $this->PropRisks_AllowanceDaystheft = '15';
      $this->PropRisks_AllowanceDaysTheftTotal = '15';
      $this->PropRisks_AllowanceDaysAccident = '10';
      $this->PropRisks_FranchiseDays = '3';
    }

    // Tyre Secure

    if(isset($ts_eligibility)){
      $this->PropRisks_TyreSecure =  ($ts_eligibility)?'true':'false';
      $this->PropRisks_TyreSecureOption =  'Replacement Basis';
    }

    // Repair of glass, plastic fibre and rubber glaas
    $this->PropRisks_RepairOfGlasPlastcFibNRubrGlas =  (isset($repair_of_glass_eligibility))?'true':'false';
    // $this->repair_of_glass

    //Consumable Expenses
    if(isset($cosumable_expenses_eligibility)){
      $this->PropRisks_ConsumablesExpenses =  (isset($cosumable_expenses_eligibility))?'true':'false';
    }

    // NCBPROTECT
    $this->PropRisks_NCBProtectionCover = (isset($ncbprotect_eligibility)  && ($this->getPropPreviousPolicyDetailsNCBPercentage() >= 25)  && (isset($addon['ncbprotect'])))?'true':'false';
    if((isset($ncbprotect_eligibility)) && (isset($addon['ncbprotect']))){
      $this->PropRisks_NoOfClaimsNCBProtection = 2;
    }

    // Loss of Personal Belongings
    $this->PropRisks_LossOfPersonalBelongings =  (isset($lpb_eligibility))?'true':'false';
    $this->PropRisks_SumAssuredLossOfPersonalBelong = (isset($lpb_eligibility))?'10000':'0';

    if($user_data->veh_cng_external == 'Y'){
      $this->PropRisks_VehcleFitWithFibrGlasFuelTank = 'true';
      $this->PropRisks_CNGLPGkitValue = $user_data->veh_cng_external_value;
      $this->setPropRisksFuelType('External CNG');
      $this->PropRisks_IsCNGLPGKitinsuredinPIP = 'true';
    }

    }

  private function setCommunicationDetail($user_data){
    $car_helper = new CarHelper;
    $master_pincode = new M \ MasterPincode;
    $this->setPropRisksRegistrationaddressline1($user_data->usr_houseno);
    $this->setPropRisksRegistrationaddressline2($user_data->usr_street);
    $this->setPropRisksRegistrationaddressline3($user_data->usr_locality);
    $city_name = $car_helper->getMasterName('City',$user_data->usr_city_code);
    $state_name = $car_helper->getMasterName('State',$user_data->usr_state_code);
    $city_code = $car_helper->getMasterId($this->manager->refrel_col,'City',$user_data->usr_city_code);
    $state_code = $car_helper->getMasterId($this->manager->refrel_col,'State',$user_data->usr_state_code);
    $this->setPropRisksCityCode($city_code);
    $this->setPropRisksStateCode($state_code);
    $this->setPropRisksCity($city_name);
    $this->setPropRisksState($state_name);
    $pincode_data = $master_pincode->getPincode($user_data->usr_pincode);
    $this->PropRisks_District = $pincode_data->dist_name;
    $this->PropRisks_DistrictCode = $pincode_data->tata_dist_code;
    if($user_data->reg_add_is_same == 'N'){
      $this->PropRisks_RegistrationAddressSameComm = 'false';
      $pincode_data = $master_pincode->getPincode($user_data->prem_usr_pincode);
      $pincode = $user_data->prem_usr_pincode;
      $pincodelocality = $pincode_data->locality_name;
      $district_code = $pincode_data->tata_dist_code;
      $distric_name = $pincode_data->dist_name;
      $prem_city_name = $car_helper->getMasterName('City',$user_data->prem_usr_city_code);
      $prem_state_name = $car_helper->getMasterName('State',$user_data->prem_usr_state_code);
      $prem_city_code = $car_helper->getMasterId($this->manager->refrel_col,'City',$user_data->prem_usr_city_code);
      $prem_state_code = $car_helper->getMasterId($this->manager->refrel_col,'State',$user_data->prem_usr_state_code);
      $this->mailLocation['AddressLine1'] = $user_data->prem_usr_houseno;
      $this->mailLocation['AddressLine2'] = $user_data->prem_usr_street;
      $this->mailLocation['AddressLine3'] = $user_data->prem_usr_locality;
      $this->mailLocation['Landmark'] = '';
      $this->mailLocation['CountryID'] = Car_Constants::TATA_COUNTRY_CODE;
      $this->mailLocation['CountryName'] = Car_Constants::TATA_COUNTRY_NAME;
      $this->mailLocation['StateCode'] = $prem_state_code;
      $this->mailLocation['StateName'] = $prem_state_name;
      $this->mailLocation['CityId'] = $prem_city_code;
      $this->mailLocation['CityName'] = $prem_city_name;
      $this->mailLocation['CityDistrictCode'] = $district_code;//"10641";
      $this->mailLocation['CityDistrictName'] = $distric_name;//"AHMEDABAD";
      $this->mailLocation['PinCodeLocality'] = $pincodelocality;//"AHMEDABAD";
      $this->mailLocation['PinCode'] = $pincode;
      $this->mailLocation['POBox'] = '';
      $this->mailLocation['AreaVillageCode'] = '';
      $this->mailLocation['AreaVillageName'] = '';
      $this->mailLocation['MailingLocationCode'] = '';
      $this->setPropRisksCityWherePrimarilyUsed($prem_city_name);
    }else{
      $this->PropRisks_RegistrationAddressSameComm = 'true';
      $pincode_data = $master_pincode->getPincode($user_data->usr_pincode);
      $pincode = $user_data->usr_pincode;
      $pincodelocality = $pincode_data->locality_name;
      $district_code = $pincode_data->tata_dist_code;
      $distric_name = $pincode_data->dist_name;
      $this->mailLocation['AddressLine1'] = $user_data->usr_houseno;
      $this->mailLocation['AddressLine2'] = $user_data->usr_street;
      $this->mailLocation['AddressLine3'] = $user_data->usr_locality;
      $this->mailLocation['Landmark'] = '';
      $this->mailLocation['CountryID'] = Car_Constants::TATA_COUNTRY_CODE;
      $this->mailLocation['CountryName'] = Car_Constants::TATA_COUNTRY_NAME;
      $this->mailLocation['StateCode'] = $state_code;
      $this->mailLocation['StateName'] = $state_name;
      $this->mailLocation['CityId'] = $city_code;
      $this->mailLocation['CityName'] = $city_name;
      $this->mailLocation['CityDistrictCode'] = $district_code;//"10641";
      $this->mailLocation['CityDistrictName'] = $distric_name;//"AHMEDABAD";
      $this->mailLocation['PinCodeLocality'] = $pincodelocality;//"AHMEDABAD";
      $this->mailLocation['PinCode'] = $pincode;
      $this->mailLocation['POBox'] = '';
      $this->mailLocation['AreaVillageCode'] = '';
      $this->mailLocation['AreaVillageName'] = '';
      $this->mailLocation['MailingLocationCode'] = '';
      $this->setPropRisksCityWherePrimarilyUsed($city_name);
    }
    foreach ($this->mailLocation as $key => $value) {
      $this->permanentLocation[$key] = $value;  
    }
    $this->PermanentLocationSameAsMailLocation = 'true';
    unset($city_code);
    unset($state_code);
    unset($city_name);
    unset($state_name);
  }

  private function setProposerDetails($user_data){
     $car_helper = new CarHelper;
    if(strtolower(trim($user_data->type_of_business)) != 'new business'){
        $this->setPropRisksProposalType('Rollover');
        $this->setPropGeneralProposalInformationBusinessTypeMandatary('Roll Over');
        $this->PropRisks_ProposalType_Mandatary = 'Rollover';
    }
    $this->PANNo= $user_data->usr_pan;
    
    $this->PropGeneralProposalInformation_POSPanNo = $user_data->usr_pan;
    $this->PropGeneralProposalInformation_POSAadhaarNo = $user_data->usr_aadharno;

    $this->FirstName = $user_data->usr_firstname;
    $this->LastName = $user_data->usr_lastname;
    $this->DOB = $car_helper->changeFormat($user_data->usr_dob,'d/m/Y');  

    $age = date('Y/m/d') - date($car_helper->changeFormat($user_data->usr_dob,'Y/m/d'));
    $this->setPropRisksAge($age);

    $this->setEmailId($user_data->usr_email);
    $this->MobileNo = $user_data->usr_mobile; 
    $this->MiddleName = '';
    $this->Name = '';
    $this->IDProofDetails = '';
    // $this->Occupation = CarHelper::getMasterId($this->manager->refrel_col,'Occupation',$user_data->usr_occupation);
    $this->setPropCustomerDtlsCustomerType($user_data->usr_type);
    $this->setCustomerType($user_data->usr_type);
    // $this->setPropCustomerDtlsCustomerName('GEMMA ARTERTON');
    $stattus = $car_helper->getMasterId($this->manager->refrel_col,'MaritalStatus',$user_data->usr_marital_status);
    $this->setPropRisksMaritalStatus($stattus);
    $this->MaritalStatus = $stattus; 
    $this->setPropRisksPinCode($user_data->usr_pincode);
    if($user_data->usr_gender == 'F'){
      $this->setPropRisksGender('FEMALE');
      $this->Gender = 'FEMALE';
      $this->Salutation = 'MISS';
    }
  }

  private function setCarDetails($user_data){
    $car_make = new M\CarMake;
    $car_models = new M\CarModels;
    $car_variant = new M\CarVariant;
    $make_code = $car_make->getMakeId($user_data->car_make,'tata_code');
    $model_code = $car_models->getModelId($user_data->car_model,'tata_code');
    $variant_code = $car_variant->getVehicleId($user_data->car_variant,'tata_code')->tata_code;
    $cc = $car_variant->fetchCC($user_data->car_variant)->variant_cc;
    $this->setPropRisksCubicCapacity($cc);
    $this->setPropRisksIDVofthevehicle($user_data->idv_opted);
    $this->setPropRisksManufacturerCode($make_code);
    $this->setPropRisksVariantCode($variant_code);
    $this->setPropRisksModelCode($model_code);
    $this->setPropRisksManufacture(strtoupper($user_data->make_name));
    $this->setPropRisksModelVariant(strtoupper($user_data->variant_name));
    $this->setPropRisksModel(strtoupper($user_data->model_name));
    $this->setPropRisksFuelType($user_data->car_fuel);
    $this->setPropRisksManufactureYear($user_data->veh_yom);
    $this->setPropRisksYearLicensed($user_data->veh_yom);
    $this->setPropRisksVehicleAge($user_data->vehicle_age);
    $this->setPropRisksEngineno($user_data->veh_eng_no);
    $this->setPropRisksChassisNumber($user_data->veh_chassisno);
    $this->setVehicleSegment($user_data->car_variant);
    $veh_body = $car_variant->getVehicleId($user_data->car_variant,'type_of_body')->type_of_body;
    if(!isset($veh_body))
        $veh_body = 'N/A';
    $this->setPropRisksTypeofbody($veh_body);
    unset($veh_body);
    $veh_segment = $car_variant->getVehicleId($user_data->car_variant,'tata_vehicle_segment')->tata_vehicle_segment;
    if(!isset($veh_segment))
      $veh_segment =  'Mini';
    $this->setPropRisksVehicleSegment($veh_segment);
    unset($veh_segment);
    unset($cc);
    unset($make_code);
    unset($model_code);
    unset($variant_code);
  }

  private function setClaimDetails($user_data){
    if($user_data->claim == 'N'){
      $this->setPropPreviousPolicyDetailsClaimLodgedInPast('false');
      $this->setPropRisksEntitledforNCB('Yes');
      $this->setPropGeneralProposalInformationIsNCBApplicable(true);
      $this->setPropPreviousPolicyDetailsNCBPercentage($user_data->ncb);
      $this->setPropRisksPrevYearNCB($user_data->ncb);
      $this->setPropRisksNoClaimBonusApplicable($user_data->new_ncb);
      $this->setPropPreviousPolicyDetailsNoOfClaims('0');
    }else{
      $this->setPropPreviousPolicyDetailsClaimLodgedInPast('true');
      $this->setPropPreviousPolicyDetailsNCBPercentage('0');
      $this->setPropPreviousPolicyDetailsClaimAmount($user_data->claim_amount_received);  //claim_amount_received
      $this->setPropPreviousPolicyDetailsNoOfClaims($user_data->prev_claim);
    }
  }
  
  private function setPrevPolicyDetails($user_data){
    $inusrerDb = new M\MasterInsurer();
    $prev_insurance = $inusrerDb->getCode($this->manager->refrel_col,$user_data->prev_insurance);
    $this->setPropPreviousPolicyDetailsPolicyNo($user_data->prev_policyno);
    $this->setPropPreviousPolicyDetailsPreviousPolicyType("PackageComprehensive");
    $this->setPropPreviousPolicyDetailsCorporateCustomerIdMandatary($prev_insurance);
    $this->setPropPreviousPolicyDetailsPolicyEffectiveFrom($this->getPrevPolicyFromDate($user_data));
    $this->setPropPreviousPolicyDetailsPolicyEffectiveTo($this->getPrevPolicyToDate($user_data));
    $this->setPropPreviousPolicyDetailsPreviousInsPincode($user_data->usr_pincode);
  }

  private function setProposalRegistrationAddress($user_data){
    $car_lib = new CarLib;
    $car_rto = new M\CarRto;
    
    $rto_location   = $user_data->car_rto;
    $rto_zone   = $car_rto->getRtoZone($rto_location);
    $rto_authority  = $car_rto->getRTOData($rto_location,'tata_rto_location')->tata_rto_location;
    $rto_grp_code   = $car_rto->getRTOData($rto_location,'tata_grp_code')->tata_grp_code; 

    if($this->getPropRisksProposalType() == 'Rollover'){
      $regno = strtoupper($user_data->veh_reg_no);
      $regno = explode('-',$regno);  
      $rto_location   = $regno[0].$regno[1];
      
      $this->setRegNoNotRequired('false');
      $this->setPropRisksRegistrationNumber($regno[0]);
      $this->setPropRisksRegistrationNumber2($regno[1]);
      $this->setPropRisksRegistrationNumber3($regno[2]);
      if(isset($regno[3]))
        $this->setPropRisksRegistrationNumber4($regno[3]);
    }
    $this->setPropRisksZoneMandatary('Zone-'.$rto_zone);
    $this->setPropRisksAuthorityLocation($rto_authority); 
    $this->setPropRisksRTOGroupCode($rto_grp_code);
    
    unset($regno);
    unset($rto_location);
    unset($rto_zone);
    unset($rto_authority);
    unset($rto_grp_code);
  }

  private function setVehicleSegment($variant_code = null){
    $car_variant = new M\CarVariant;
    $this->vehicle_segment = $car_variant->getVehicleId($variant_code,'tata_vehicle_segment')->tata_vehicle_segment;
  }

  private function getVehicleSegment(){
    return $this->vehicle_segment;
  }

  private function getPrevPolicyFromDate($user_data){
     $car_helper = new CarHelper;
    return $car_helper->manDate($user_data->policy_expiry_date,'d/m/Y',['-1 year','+1 day']);
  }

  private function getPrevPolicyToDate($user_data){
     $car_helper = new CarHelper;
    return $car_helper->manDate($user_data->policy_expiry_date,'d/m/Y',[]);    
  }

    /**
     * @return mixed
     */
    public function getPropRisksProposalType()
    {
        return $this->PropRisks_ProposalType;
    }

    /**
     * @param mixed $PropRisks_ProposalType
     *
     * @return self
     */
    public function setPropRisksProposalType($PropRisks_ProposalType)
    {
        $this->PropRisks_ProposalType = $PropRisks_ProposalType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropCustomerDtlsCustomerType()
    {
        return $this->PropCustomerDtls_CustomerType;
    }

    /**
     * @param mixed $PropCustomerDtls_CustomerType
     *
     * @return self
     */
    public function setPropCustomerDtlsCustomerType($PropCustomerDtls_CustomerType)
    {
        $this->PropCustomerDtls_CustomerType = $PropCustomerDtls_CustomerType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCustomerType()
    {
        return $this->CustomerType;
    }

    /**
     * @param mixed $CustomerType
     *
     * @return self
     */
    public function setCustomerType($CustomerType)
    {
        $this->CustomerType = $CustomerType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksMaritalStatus()
    {
        return $this->PropRisks_MaritalStatus;
    }

    /**
     * @param mixed $PropRisks_MaritalStatus
     *
     * @return self
     */
    public function setPropRisksMaritalStatus($PropRisks_MaritalStatus)
    {
        $this->PropRisks_MaritalStatus = $PropRisks_MaritalStatus;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksPinCode()
    {
        return $this->PropRisks_PinCode;
    }

    /**
     * @param mixed $PropRisks_PinCode
     *
     * @return self
     */
    public function setPropRisksPinCode($PropRisks_PinCode)
    {
        $this->PropRisks_PinCode = $PropRisks_PinCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksGender()
    {
        return $this->PropRisks_Gender;
    }

    /**
     * @param mixed $PropRisks_Gender
     *
     * @return self
     */
    public function setPropRisksGender($PropRisks_Gender)
    {
        $this->PropRisks_Gender = $PropRisks_Gender;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationaddressline1()
    {
        return $this->PropRisks_Registrationaddressline1;
    }

    /**
     * @param mixed $PropRisks_Registrationaddressline1
     *
     * @return self
     */
    public function setPropRisksRegistrationaddressline1($PropRisks_Registrationaddressline1)
    {
        $this->PropRisks_Registrationaddressline1 = $PropRisks_Registrationaddressline1;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationaddressline2()
    {
        return $this->PropRisks_Registrationaddressline2;
    }

    /**
     * @param mixed $PropRisks_Registrationaddressline2
     *
     * @return self
     */
    public function setPropRisksRegistrationaddressline2($PropRisks_Registrationaddressline2)
    {
        $this->PropRisks_Registrationaddressline2 = $PropRisks_Registrationaddressline2;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationaddressline3()
    {
        return $this->PropRisks_Registrationaddressline3;
    }

    /**
     * @param mixed $PropRisks_Registrationaddressline3
     *
     * @return self
     */
    public function setPropRisksRegistrationaddressline3($PropRisks_Registrationaddressline3)
    {
        $this->PropRisks_Registrationaddressline3 = $PropRisks_Registrationaddressline3;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCity()
    {
        return $this->PropRisks_City;
    }

    /**
     * @param mixed $PropRisks_City
     *
     * @return self
     */
    public function setPropRisksCity($PropRisks_City)
    {
        $this->PropRisks_City = $PropRisks_City;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCityCode()
    {
        return $this->PropRisks_CityCode;
    }

    /**
     * @param mixed $PropRisks_CityCode
     *
     * @return self
     */
    public function setPropRisksCityCode($PropRisks_CityCode)
    {
        $this->PropRisks_CityCode = $PropRisks_CityCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksState()
    {
        return $this->PropRisks_State;
    }

    /**
     * @param mixed $PropRisks_State
     *
     * @return self
     */
    public function setPropRisksState($PropRisks_State)
    {
        $this->PropRisks_State = $PropRisks_State;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksStateCode()
    {
        return $this->PropRisks_StateCode;
    }

    /**
     * @param mixed $PropRisks_StateCode
     *
     * @return self
     */
    public function setPropRisksStateCode($PropRisks_StateCode)
    {
        $this->PropRisks_StateCode = $PropRisks_StateCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationAddressSameComm()
    {
        return $this->PropRisks_RegistrationAddressSameComm;
    }

    /**
     * @param mixed $PropRisks_RegistrationAddressSameComm
     *
     * @return self
     */
    public function setPropRisksRegistrationAddressSameComm($PropRisks_RegistrationAddressSameComm)
    {
        $this->PropRisks_RegistrationAddressSameComm = $PropRisks_RegistrationAddressSameComm;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRegNoNotRequired()
    {
        return $this->RegNoNotRequired;
    }

    /**
     * @param mixed $RegNoNotRequired
     *
     * @return self
     */
    public function setRegNoNotRequired($RegNoNotRequired)
    {
        $this->RegNoNotRequired = $RegNoNotRequired;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCubicCapacity()
    {
        return $this->PropRisks_CubicCapacity;
    }

    /**
     * @param mixed $PropRisks_CubicCapacity
     *
     * @return self
     */
    public function setPropRisksCubicCapacity($PropRisks_CubicCapacity)
    {
        $this->PropRisks_CubicCapacity = $PropRisks_CubicCapacity;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksIDVofthevehicle()
    {
        return $this->PropRisks_IDVofthevehicle;
    }

    /**
     * @param mixed $PropRisks_IDVofthevehicle
     *
     * @return self
     */
    public function setPropRisksIDVofthevehicle($PropRisks_IDVofthevehicle)
    {
        $this->PropRisks_IDVofthevehicle = $PropRisks_IDVofthevehicle;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksManufacturerCode()
    {
        return $this->PropRisks_ManufacturerCode;
    }

    /**
     * @param mixed $PropRisks_ManufacturerCode
     *
     * @return self
     */
    public function setPropRisksManufacturerCode($PropRisks_ManufacturerCode)
    {
        $this->PropRisks_ManufacturerCode = $PropRisks_ManufacturerCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVariantCode()
    {
        return $this->PropRisks_VariantCode;
    }

    /**
     * @param mixed $PropRisks_VariantCode
     *
     * @return self
     */
    public function setPropRisksVariantCode($PropRisks_VariantCode)
    {
        $this->PropRisks_VariantCode = $PropRisks_VariantCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksModelCode()
    {
        return $this->PropRisks_ModelCode;
    }

    /**
     * @param mixed $PropRisks_ModelCode
     *
     * @return self
     */
    public function setPropRisksModelCode($PropRisks_ModelCode)
    {
        $this->PropRisks_ModelCode = $PropRisks_ModelCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksManufacture()
    {
        return $this->PropRisks_Manufacture;
    }

    /**
     * @param mixed $PropRisks_Manufacture
     *
     * @return self
     */
    public function setPropRisksManufacture($PropRisks_Manufacture)
    {
        $this->PropRisks_Manufacture = $PropRisks_Manufacture;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksModelVariant()
    {
        return $this->PropRisks_ModelVariant;
    }

    /**
     * @param mixed $PropRisks_ModelVariant
     *
     * @return self
     */
    public function setPropRisksModelVariant($PropRisks_ModelVariant)
    {
        $this->PropRisks_ModelVariant = $PropRisks_ModelVariant;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksModel()
    {
        return $this->PropRisks_Model;
    }

    /**
     * @param mixed $PropRisks_Model
     *
     * @return self
     */
    public function setPropRisksModel($PropRisks_Model)
    {
        $this->PropRisks_Model = $PropRisks_Model;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksFuelType()
    {
        return $this->PropRisks_FuelType;
    }

    /**
     * @param mixed $PropRisks_FuelType
     *
     * @return self
     */
    public function setPropRisksFuelType($PropRisks_FuelType)
    {
        $this->PropRisks_FuelType = $PropRisks_FuelType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksManufactureYear()
    {
        return $this->PropRisks_ManufactureYear;
    }

    /**
     * @param mixed $PropRisks_ManufactureYear
     *
     * @return self
     */
    public function setPropRisksManufactureYear($PropRisks_ManufactureYear)
    {
        $this->PropRisks_ManufactureYear = $PropRisks_ManufactureYear;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksYearLicensed()
    {
        return $this->PropRisks_YearLicensed;
    }

    /**
     * @param mixed $PropRisks_YearLicensed
     *
     * @return self
     */
    public function setPropRisksYearLicensed($PropRisks_YearLicensed)
    {
        $this->PropRisks_YearLicensed = $PropRisks_YearLicensed;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVehicleAge()
    {
        return $this->PropRisks_VehicleAge_Mandatary;
    }

    /**
     * @param mixed $PropRisks_VehicleAge_Mandatary
     *
     * @return self
     */
    public function setPropRisksVehicleAge($PropRisks_VehicleAge_Mandatary)
    {
        $this->PropRisks_VehicleAge_Mandatary = $PropRisks_VehicleAge_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksEngineno()
    {
        return $this->PropRisks_Engineno;
    }

    /**
     * @param mixed $PropRisks_Engineno
     *
     * @return self
     */
    public function setPropRisksEngineno($PropRisks_Engineno)
    {
        $this->PropRisks_Engineno = $PropRisks_Engineno;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksChassisNumber()
    {
        return $this->PropRisks_ChassisNumber;
    }

    /**
     * @param mixed $PropRisks_ChassisNumber
     *
     * @return self
     */
    public function setPropRisksChassisNumber($PropRisks_ChassisNumber)
    {
        $this->PropRisks_ChassisNumber = $PropRisks_ChassisNumber;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksTypeofbody()
    {
        return $this->PropRisks_Typeofbody;
    }

    /**
     * @param mixed $PropRisks_Typeofbody
     *
     * @return self
     */
    public function setPropRisksTypeofbody($PropRisks_Typeofbody)
    {
        $this->PropRisks_Typeofbody = $PropRisks_Typeofbody;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationNumber()
    {
        return $this->PropRisks_RegistrationNumber;
    }

    /**
     * @param mixed $PropRisks_RegistrationNumber
     *
     * @return self
     */
    public function setPropRisksRegistrationNumber($PropRisks_RegistrationNumber)
    {
        $this->PropRisks_RegistrationNumber = $PropRisks_RegistrationNumber;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationNumber2()
    {
        return $this->PropRisks_RegistrationNumber2;
    }

    /**
     * @param mixed $PropRisks_RegistrationNumber2
     *
     * @return self
     */
    public function setPropRisksRegistrationNumber2($PropRisks_RegistrationNumber2)
    {
        $this->PropRisks_RegistrationNumber2 = $PropRisks_RegistrationNumber2;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationNumber3()
    {
        return $this->PropRisks_RegistrationNumber3;
    }

    /**
     * @param mixed $PropRisks_RegistrationNumber3
     *
     * @return self
     */
    public function setPropRisksRegistrationNumber3($PropRisks_RegistrationNumber3)
    {
        $this->PropRisks_RegistrationNumber3 = $PropRisks_RegistrationNumber3;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRegistrationNumber4()
    {
        return $this->PropRisks_RegistrationNumber4;
    }

    /**
     * @param mixed $PropRisks_RegistrationNumber4
     *
     * @return self
     */
    public function setPropRisksRegistrationNumber4($PropRisks_RegistrationNumber4)
    {
        $this->PropRisks_RegistrationNumber4 = $PropRisks_RegistrationNumber4;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksNumberOfPersonsUnnamed()
    {
        return $this->PropRisks_NumberOfPersonsUnnamed;
    }

    /**
     * @param mixed $PropRisks_NumberOfPersonsUnnamed
     *
     * @return self
     */
    public function setPropRisksNumberOfPersonsUnnamed($PropRisks_NumberOfPersonsUnnamed)
    {
        $this->PropRisks_NumberOfPersonsUnnamed = $PropRisks_NumberOfPersonsUnnamed;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksSeatingCapacity()
    {
        return $this->PropRisks_SeatingCapacity;
    }

    /**
     * @param mixed $PropRisks_SeatingCapacity
     *
     * @return self
     */
    public function setPropRisksSeatingCapacity($PropRisks_SeatingCapacity)
    {
        $this->PropRisks_SeatingCapacity = $PropRisks_SeatingCapacity;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsPolicyNo()
    {
        return $this->PropPreviousPolicyDetails_PolicyNo;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_PolicyNo
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsPolicyNo($PropPreviousPolicyDetails_PolicyNo)
    {
        $this->PropPreviousPolicyDetails_PolicyNo = $PropPreviousPolicyDetails_PolicyNo;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsPreviousPolicyType()
    {
        return $this->PropPreviousPolicyDetails_PreviousPolicyType;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_PreviousPolicyType
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsPreviousPolicyType($PropPreviousPolicyDetails_PreviousPolicyType)
    {
        $this->PropPreviousPolicyDetails_PreviousPolicyType = $PropPreviousPolicyDetails_PreviousPolicyType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsCorporateCustomerIdMandatary()
    {
        return $this->PropPreviousPolicyDetails_CorporateCustomerId_Mandatary;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_CorporateCustomerId_Mandatary
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsCorporateCustomerIdMandatary($PropPreviousPolicyDetails_CorporateCustomerId_Mandatary)
    {
        $this->PropPreviousPolicyDetails_CorporateCustomerId_Mandatary = $PropPreviousPolicyDetails_CorporateCustomerId_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsPolicyEffectiveFrom()
    {
        return $this->PropPreviousPolicyDetails_PolicyEffectiveFrom;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_PolicyEffectiveFrom
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsPolicyEffectiveFrom($PropPreviousPolicyDetails_PolicyEffectiveFrom)
    {
        $this->PropPreviousPolicyDetails_PolicyEffectiveFrom = $PropPreviousPolicyDetails_PolicyEffectiveFrom;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsPolicyEffectiveTo()
    {
        return $this->PropPreviousPolicyDetails_PolicyEffectiveTo;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_PolicyEffectiveTo
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsPolicyEffectiveTo($PropPreviousPolicyDetails_PolicyEffectiveTo)
    {
        $this->PropPreviousPolicyDetails_PolicyEffectiveTo = $PropPreviousPolicyDetails_PolicyEffectiveTo;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsPreviousInsPincode()
    {
        return $this->PropPreviousPolicyDetails_PreviousInsPincode;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_PreviousInsPincode
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsPreviousInsPincode($PropPreviousPolicyDetails_PreviousInsPincode)
    {
        $this->PropPreviousPolicyDetails_PreviousInsPincode = $PropPreviousPolicyDetails_PreviousInsPincode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksEntitledforNCB()
    {
        return $this->PropRisks_EntitledforNCB;
    }

    /**
     * @param mixed $PropRisks_EntitledforNCB
     *
     * @return self
     */
    public function setPropRisksEntitledforNCB($PropRisks_EntitledforNCB)
    {
        $this->PropRisks_EntitledforNCB = $PropRisks_EntitledforNCB;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksNoClaimBonusApplicable()
    {
        return $this->PropRisks_NoClaimBonusApplicable;
    }

    /**
     * @param mixed $PropRisks_NoClaimBonusApplicable
     *
     * @return self
     */
    public function setPropRisksNoClaimBonusApplicable($PropRisks_NoClaimBonusApplicable)
    {
        $this->PropRisks_NoClaimBonusApplicable = $PropRisks_NoClaimBonusApplicable;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsNoOfClaims()
    {
        return $this->PropPreviousPolicyDetails_NoOfClaims;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_NoOfClaims
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsNoOfClaims($PropPreviousPolicyDetails_NoOfClaims)
    {
        $this->PropPreviousPolicyDetails_NoOfClaims = $PropPreviousPolicyDetails_NoOfClaims;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsClaimAmount()
    {
        return $this->PropPreviousPolicyDetails_ClaimAmount;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_ClaimAmount
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsClaimAmount($PropPreviousPolicyDetails_ClaimAmount)
    {
        $this->PropPreviousPolicyDetails_ClaimAmount = $PropPreviousPolicyDetails_ClaimAmount;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsClaimLodgedInPast()
    {
        return $this->PropPreviousPolicyDetails_ClaimLodgedInPast;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_ClaimLodgedInPast
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsClaimLodgedInPast($PropPreviousPolicyDetails_ClaimLodgedInPast)
    {
        $this->PropPreviousPolicyDetails_ClaimLodgedInPast = $PropPreviousPolicyDetails_ClaimLodgedInPast;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPreviousPolicyDetailsNCBPercentage()
    {
        return $this->PropPreviousPolicyDetails_NCBPercentage;
    }

    /**
     * @param mixed $PropPreviousPolicyDetails_NCBPercentage
     *
     * @return self
     */
    public function setPropPreviousPolicyDetailsNCBPercentage($PropPreviousPolicyDetails_NCBPercentage)
    {
        $this->PropPreviousPolicyDetails_NCBPercentage = $PropPreviousPolicyDetails_NCBPercentage;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksPrevYearNCB()
    {
        return $this->PropRisks_PrevYearNCB;
    }

    /**
     * @param mixed $PropRisks_PrevYearNCB
     *
     * @return self
     */
    public function setPropRisksPrevYearNCB($PropRisks_PrevYearNCB)
    {
        $this->PropRisks_PrevYearNCB = $PropRisks_PrevYearNCB;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationIsNCBApplicable()
    {
        return $this->PropGeneralProposalInformation_IsNCBApplicable;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_IsNCBApplicable
     *
     * @return self
     */
    public function setPropGeneralProposalInformationIsNCBApplicable($PropGeneralProposalInformation_IsNCBApplicable)
    {
        $this->PropGeneralProposalInformation_IsNCBApplicable = $PropGeneralProposalInformation_IsNCBApplicable;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksEngineSecure()
    {
        return $this->PropRisks_EngineSecure;
    }

    /**
     * @param mixed $PropRisks_EngineSecure
     *
     * @return self
     */
    public function setPropRisksEngineSecure($PropRisks_EngineSecure)
    {
        $this->PropRisks_EngineSecure = $PropRisks_EngineSecure;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRoadsideAssistance()
    {
        return $this->PropRisks_RoadsideAssistance;
    }

    /**
     * @param mixed $PropRisks_RoadsideAssistance
     *
     * @return self
     */
    public function setPropRisksRoadsideAssistance($PropRisks_RoadsideAssistance)
    {
        $this->PropRisks_RoadsideAssistance = $PropRisks_RoadsideAssistance;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksDepreciationReimbursement()
    {
        return $this->PropRisks_DepreciationReimbursement;
    }

    /**
     * @param mixed $PropRisks_DepreciationReimbursement
     *
     * @return self
     */
    public function setPropRisksDepreciationReimbursement($PropRisks_DepreciationReimbursement)
    {
        $this->PropRisks_DepreciationReimbursement = $PropRisks_DepreciationReimbursement;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksReturnToInvoice()
    {
        return $this->PropRisks_ReturnToInvoice;
    }

    /**
     * @param mixed $PropRisks_ReturnToInvoice
     *
     * @return self
     */
    public function setPropRisksReturnToInvoice($PropRisks_ReturnToInvoice)
    {
        $this->PropRisks_ReturnToInvoice = $PropRisks_ReturnToInvoice;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksOtherChk2()
    {
        return $this->PropRisks_OtherChk2;
    }

    /**
     * @param mixed $PropRisks_OtherChk2
     *
     * @return self
     */
    public function setPropRisksOtherChk2($PropRisks_OtherChk2)
    {
        $this->PropRisks_OtherChk2 = $PropRisks_OtherChk2;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksWiderLegalLiabilityToPaid()
    {
        return $this->PropRisks_WiderLegalLiabilityToPaid;
    }

    /**
     * @param mixed $PropRisks_WiderLegalLiabilityToPaid
     *
     * @return self
     */
    public function setPropRisksWiderLegalLiabilityToPaid($PropRisks_WiderLegalLiabilityToPaid)
    {
        $this->PropRisks_WiderLegalLiabilityToPaid = $PropRisks_WiderLegalLiabilityToPaid;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCompulsoryPAwithOwnerDriver()
    {
        return $this->PropRisks_CompulsoryPAwithOwnerDriver;
    }

    /**
     * @param mixed $PropRisks_CompulsoryPAwithOwnerDriver
     *
     * @return self
     */
    public function setPropRisksCompulsoryPAwithOwnerDriver($PropRisks_CompulsoryPAwithOwnerDriver)
    {
        $this->PropRisks_CompulsoryPAwithOwnerDriver = $PropRisks_CompulsoryPAwithOwnerDriver;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksTyreSecure()
    {
        return $this->PropRisks_TyreSecure;
    }

    /**
     * @param mixed $PropRisks_TyreSecure
     *
     * @return self
     */
    public function setPropRisksTyreSecure($PropRisks_TyreSecure)
    {
        $this->PropRisks_TyreSecure = $PropRisks_TyreSecure;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksKeyReplacement()
    {
        return $this->PropRisks_KeyReplacement;
    }

    /**
     * @param mixed $PropRisks_KeyReplacement
     *
     * @return self
     */
    public function setPropRisksKeyReplacement($PropRisks_KeyReplacement)
    {
        $this->PropRisks_KeyReplacement = $PropRisks_KeyReplacement;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksDateofpurchase()
    {
        return $this->PropRisks_Dateofpurchase;
    }

    /**
     * @param mixed $PropRisks_Dateofpurchase
     *
     * @return self
     */
    public function setPropRisksDateofpurchase($PropRisks_Dateofpurchase)
    {
        $this->PropRisks_Dateofpurchase = $PropRisks_Dateofpurchase;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksDateofRegistration()
    {
        return $this->PropRisks_DateofRegistration;
    }

    /**
     * @param mixed $PropRisks_DateofRegistration
     *
     * @return self
     */
    public function setPropRisksDateofRegistration($PropRisks_DateofRegistration)
    {
        $this->PropRisks_DateofRegistration = $PropRisks_DateofRegistration;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsAgreementType()
    {
        return $this->PropFinancierDetails_AgreementType;
    }

    /**
     * @param mixed $PropFinancierDetails_AgreementType
     *
     * @return self
     */
    public function setPropFinancierDetailsAgreementType($PropFinancierDetails_AgreementType)
    {
        $this->PropFinancierDetails_AgreementType = $PropFinancierDetails_AgreementType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsFinancierName()
    {
        return $this->PropFinancierDetails_FinancierName;
    }

    /**
     * @param mixed $PropFinancierDetails_FinancierName
     *
     * @return self
     */
    public function setPropFinancierDetailsFinancierName($PropFinancierDetails_FinancierName)
    {
        $this->PropFinancierDetails_FinancierName = $PropFinancierDetails_FinancierName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsLoanAccountNo()
    {
        return $this->PropFinancierDetails_LoanAccountNo;
    }

    /**
     * @param mixed $PropFinancierDetails_LoanAccountNo
     *
     * @return self
     */
    public function setPropFinancierDetailsLoanAccountNo($PropFinancierDetails_LoanAccountNo)
    {
        $this->PropFinancierDetails_LoanAccountNo = $PropFinancierDetails_LoanAccountNo;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsBranchName()
    {
        return $this->PropFinancierDetails_BranchName;
    }

    /**
     * @param mixed $PropFinancierDetails_BranchName
     *
     * @return self
     */
    public function setPropFinancierDetailsBranchName($PropFinancierDetails_BranchName)
    {
        $this->PropFinancierDetails_BranchName = $PropFinancierDetails_BranchName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsCountry()
    {
        return $this->PropFinancierDetails_Country;
    }

    /**
     * @param mixed $PropFinancierDetails_Country
     *
     * @return self
     */
    public function setPropFinancierDetailsCountry($PropFinancierDetails_Country)
    {
        $this->PropFinancierDetails_Country = $PropFinancierDetails_Country;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsFinancierStatus()
    {
        return $this->PropFinancierDetails_FinancierStatus;
    }

    /**
     * @param mixed $PropFinancierDetails_FinancierStatus
     *
     * @return self
     */
    public function setPropFinancierDetailsFinancierStatus($PropFinancierDetails_FinancierStatus)
    {
        $this->PropFinancierDetails_FinancierStatus = $PropFinancierDetails_FinancierStatus;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsRemarks()
    {
        return $this->PropFinancierDetails_Remarks;
    }

    /**
     * @param mixed $PropFinancierDetails_Remarks
     *
     * @return self
     */
    public function setPropFinancierDetailsRemarks($PropFinancierDetails_Remarks)
    {
        $this->PropFinancierDetails_Remarks = $PropFinancierDetails_Remarks;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsFinancierType()
    {
        return $this->PropFinancierDetails_FinancierType;
    }

    /**
     * @param mixed $PropFinancierDetails_FinancierType
     *
     * @return self
     */
    public function setPropFinancierDetailsFinancierType($PropFinancierDetails_FinancierType)
    {
        $this->PropFinancierDetails_FinancierType = $PropFinancierDetails_FinancierType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsFinancierCodeMandatary()
    {
        return $this->PropFinancierDetails_FinancierCode_Mandatary;
    }

    /**
     * @param mixed $PropFinancierDetails_FinancierCode_Mandatary
     *
     * @return self
     */
    public function setPropFinancierDetailsFinancierCodeMandatary($PropFinancierDetails_FinancierCode_Mandatary)
    {
        $this->PropFinancierDetails_FinancierCode_Mandatary = $PropFinancierDetails_FinancierCode_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsCityCode()
    {
        return $this->PropFinancierDetails_CityCode;
    }

    /**
     * @param mixed $PropFinancierDetails_CityCode
     *
     * @return self
     */
    public function setPropFinancierDetailsCityCode($PropFinancierDetails_CityCode)
    {
        $this->PropFinancierDetails_CityCode = $PropFinancierDetails_CityCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsDistrictCode()
    {
        return $this->PropFinancierDetails_DistrictCode;
    }

    /**
     * @param mixed $PropFinancierDetails_DistrictCode
     *
     * @return self
     */
    public function setPropFinancierDetailsDistrictCode($PropFinancierDetails_DistrictCode)
    {
        $this->PropFinancierDetails_DistrictCode = $PropFinancierDetails_DistrictCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsStateCode()
    {
        return $this->PropFinancierDetails_StateCode;
    }

    /**
     * @param mixed $PropFinancierDetails_StateCode
     *
     * @return self
     */
    public function setPropFinancierDetailsStateCode($PropFinancierDetails_StateCode)
    {
        $this->PropFinancierDetails_StateCode = $PropFinancierDetails_StateCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsPincode()
    {
        return $this->PropFinancierDetails_Pincode;
    }

    /**
     * @param mixed $PropFinancierDetails_Pincode
     *
     * @return self
     */
    public function setPropFinancierDetailsPincode($PropFinancierDetails_Pincode)
    {
        $this->PropFinancierDetails_Pincode = $PropFinancierDetails_Pincode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsState()
    {
        return $this->PropFinancierDetails_State;
    }

    /**
     * @param mixed $PropFinancierDetails_State
     *
     * @return self
     */
    public function setPropFinancierDetailsState($PropFinancierDetails_State)
    {
        $this->PropFinancierDetails_State = $PropFinancierDetails_State;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsCity()
    {
        return $this->PropFinancierDetails_City;
    }

    /**
     * @param mixed $PropFinancierDetails_City
     *
     * @return self
     */
    public function setPropFinancierDetailsCity($PropFinancierDetails_City)
    {
        $this->PropFinancierDetails_City = $PropFinancierDetails_City;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsDistrict()
    {
        return $this->PropFinancierDetails_District;
    }

    /**
     * @param mixed $PropFinancierDetails_District
     *
     * @return self
     */
    public function setPropFinancierDetailsDistrict($PropFinancierDetails_District)
    {
        $this->PropFinancierDetails_District = $PropFinancierDetails_District;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsAddress()
    {
        return $this->PropFinancierDetails_Address;
    }

    /**
     * @param mixed $PropFinancierDetails_Address
     *
     * @return self
     */
    public function setPropFinancierDetailsAddress($PropFinancierDetails_Address)
    {
        $this->PropFinancierDetails_Address = $PropFinancierDetails_Address;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsSrNoMandatary()
    {
        return $this->PropFinancierDetails_SrNo_Mandatary;
    }

    /**
     * @param mixed $PropFinancierDetails_SrNo_Mandatary
     *
     * @return self
     */
    public function setPropFinancierDetailsSrNoMandatary($PropFinancierDetails_SrNo_Mandatary)
    {
        $this->PropFinancierDetails_SrNo_Mandatary = $PropFinancierDetails_SrNo_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsIsDataDeleted()
    {
        return $this->PropFinancierDetails_IsDataDeleted;
    }

    /**
     * @param mixed $PropFinancierDetails_IsDataDeleted
     *
     * @return self
     */
    public function setPropFinancierDetailsIsDataDeleted($PropFinancierDetails_IsDataDeleted)
    {
        $this->PropFinancierDetails_IsDataDeleted = $PropFinancierDetails_IsDataDeleted;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropFinancierDetailsIsOldDataDeleted()
    {
        return $this->PropFinancierDetails_IsOldDataDeleted;
    }

    /**
     * @param mixed $PropFinancierDetails_IsOldDataDeleted
     *
     * @return self
     */
    public function setPropFinancierDetailsIsOldDataDeleted($PropFinancierDetails_IsOldDataDeleted)
    {
        $this->PropFinancierDetails_IsOldDataDeleted = $PropFinancierDetails_IsOldDataDeleted;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksAge()
    {
        return $this->PropRisks_Age;
    }

    /**
     * @param mixed $PropRisks_Age
     *
     * @return self
     */
    public function setPropRisksAge($PropRisks_Age)
    {
        $this->PropRisks_Age = $PropRisks_Age;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksMainDriver()
    {
        return $this->PropRisks_MainDriver;
    }

    /**
     * @param mixed $PropRisks_MainDriver
     *
     * @return self
     */
    public function setPropRisksMainDriver($PropRisks_MainDriver)
    {
        $this->PropRisks_MainDriver = $PropRisks_MainDriver;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksOtherInformation1T()
    {
        return $this->PropRisks_OtherInformation1T;
    }

    /**
     * @param mixed $PropRisks_OtherInformation1T
     *
     * @return self
     */
    public function setPropRisksOtherInformation1T($PropRisks_OtherInformation1T)
    {
        $this->PropRisks_OtherInformation1T = $PropRisks_OtherInformation1T;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVehicleType()
    {
        return $this->PropRisks_VehicleType;
    }

    /**
     * @param mixed $PropRisks_VehicleType
     *
     * @return self
     */
    public function setPropRisksVehicleType($PropRisks_VehicleType)
    {
        $this->PropRisks_VehicleType = $PropRisks_VehicleType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationBusinessTypeMandatary()
    {
        return $this->PropGeneralProposalInformation_BusinessType_Mandatary;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_BusinessType_Mandatary
     *
     * @return self
     */
    public function setPropGeneralProposalInformationBusinessTypeMandatary($PropGeneralProposalInformation_BusinessType_Mandatary)
    {
        $this->PropGeneralProposalInformation_BusinessType_Mandatary = $PropGeneralProposalInformation_BusinessType_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropIntermediaryDetailsIntermediaryName()
    {
        return $this->PropIntermediaryDetails_IntermediaryName;
    }

    /**
     * @param mixed $PropIntermediaryDetails_IntermediaryName
     *
     * @return self
     */
    public function setPropIntermediaryDetailsIntermediaryName($PropIntermediaryDetails_IntermediaryName)
    {
        $this->PropIntermediaryDetails_IntermediaryName = $PropIntermediaryDetails_IntermediaryName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationPolicyScheduleMandatary()
    {
        return $this->PropGeneralProposalInformation_PolicySchedule_Mandatary;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_PolicySchedule_Mandatary
     *
     * @return self
     */
    public function setPropGeneralProposalInformationPolicyScheduleMandatary($PropGeneralProposalInformation_PolicySchedule_Mandatary)
    {
        $this->PropGeneralProposalInformation_PolicySchedule_Mandatary = $PropGeneralProposalInformation_PolicySchedule_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVehiclePurchaseAs()
    {
        return $this->PropRisks_VehiclePurchaseAs;
    }

    /**
     * @param mixed $PropRisks_VehiclePurchaseAs
     *
     * @return self
     */
    public function setPropRisksVehiclePurchaseAs($PropRisks_VehiclePurchaseAs)
    {
        $this->PropRisks_VehiclePurchaseAs = $PropRisks_VehiclePurchaseAs;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropDistributionChannelBusinessSourceMandatary()
    {
        return $this->PropDistributionChannel_BusinessSource_Mandatary;
    }

    /**
     * @param mixed $PropDistributionChannel_BusinessSource_Mandatary
     *
     * @return self
     */
    public function setPropDistributionChannelBusinessSourceMandatary($PropDistributionChannel_BusinessSource_Mandatary)
    {
        $this->PropDistributionChannel_BusinessSource_Mandatary = $PropDistributionChannel_BusinessSource_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationMethodOfCalculation()
    {
        return $this->PropGeneralProposalInformation_MethodOfCalculation;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_MethodOfCalculation
     *
     * @return self
     */
    public function setPropGeneralProposalInformationMethodOfCalculation($PropGeneralProposalInformation_MethodOfCalculation)
    {
        $this->PropGeneralProposalInformation_MethodOfCalculation = $PropGeneralProposalInformation_MethodOfCalculation;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationServiceTaxExemptionCategoryMandatary()
    {
        return $this->PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary
     *
     * @return self
     */
    public function setPropGeneralProposalInformationServiceTaxExemptionCategoryMandatary($PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary)
    {
        $this->PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary = $PropGeneralProposalInformation_ServiceTaxExemptionCategory_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRiskVariant()
    {
        return $this->PropRisks_RiskVariant;
    }

    /**
     * @param mixed $PropRisks_RiskVariant
     *
     * @return self
     */
    public function setPropRisksRiskVariant($PropRisks_RiskVariant)
    {
        $this->PropRisks_RiskVariant = $PropRisks_RiskVariant;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksAddOnPlanSelected()
    {
        return $this->PropRisks_AddOnPlanSelected;
    }

    /**
     * @param mixed $PropRisks_AddOnPlanSelected
     *
     * @return self
     */
    public function setPropRisksAddOnPlanSelected($PropRisks_AddOnPlanSelected)
    {
        $this->PropRisks_AddOnPlanSelected = $PropRisks_AddOnPlanSelected;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getOtherDetailsGrid()
    {
        return $this->OtherDetailsGrid;
    }

    /**
     * @param mixed $OtherDetailsGrid
     *
     * @return self
     */
    public function setOtherDetailsGrid($OtherDetailsGrid)
    {
        $this->OtherDetailsGrid = $OtherDetailsGrid;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropProductDetailsProductCode()
    {
        return $this->PropProductDetails_ProductCode;
    }

    /**
     * @param mixed $PropProductDetails_ProductCode
     *
     * @return self
     */
    public function setPropProductDetailsProductCode($PropProductDetails_ProductCode)
    {
        $this->PropProductDetails_ProductCode = $PropProductDetails_ProductCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksIsVehicleUsedforblindpersons()
    {
        return $this->PropRisks_IsVehicleUsedforblindpersons;
    }

    /**
     * @param mixed $PropRisks_IsVehicleUsedforblindpersons
     *
     * @return self
     */
    public function setPropRisksIsVehicleUsedforblindpersons($PropRisks_IsVehicleUsedforblindpersons)
    {
        $this->PropRisks_IsVehicleUsedforblindpersons = $PropRisks_IsVehicleUsedforblindpersons;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropEndorsementDtlsIsSellerInsured()
    {
        return $this->PropEndorsementDtls_IsSellerInsured;
    }

    /**
     * @param mixed $PropEndorsementDtls_IsSellerInsured
     *
     * @return self
     */
    public function setPropEndorsementDtlsIsSellerInsured($PropEndorsementDtls_IsSellerInsured)
    {
        $this->PropEndorsementDtls_IsSellerInsured = $PropEndorsementDtls_IsSellerInsured;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPolicyEffectivedateFromdateMandatary()
    {
        return $this->PropPolicyEffectivedate_Fromdate_Mandatary;
    }

    /**
     * @param mixed $PropPolicyEffectivedate_Fromdate_Mandatary
     *
     * @return self
     */
    public function setPropPolicyEffectivedateFromdateMandatary($PropPolicyEffectivedate_Fromdate_Mandatary)
    {
        $this->PropPolicyEffectivedate_Fromdate_Mandatary = $PropPolicyEffectivedate_Fromdate_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPolicyEffectivedateFromhourMandatary()
    {
        return $this->PropPolicyEffectivedate_Fromhour_Mandatary;
    }

    /**
     * @param mixed $PropPolicyEffectivedate_Fromhour_Mandatary
     *
     * @return self
     */
    public function setPropPolicyEffectivedateFromhourMandatary($PropPolicyEffectivedate_Fromhour_Mandatary)
    {
        $this->PropPolicyEffectivedate_Fromhour_Mandatary = $PropPolicyEffectivedate_Fromhour_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPolicyEffectivedateTodateMandatary()
    {
        return $this->PropPolicyEffectivedate_Todate_Mandatary;
    }

    /**
     * @param mixed $PropPolicyEffectivedate_Todate_Mandatary
     *
     * @return self
     */
    public function setPropPolicyEffectivedateTodateMandatary($PropPolicyEffectivedate_Todate_Mandatary)
    {
        $this->PropPolicyEffectivedate_Todate_Mandatary = $PropPolicyEffectivedate_Todate_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropPolicyEffectivedateTohourMandatary()
    {
        return $this->PropPolicyEffectivedate_Tohour_Mandatary;
    }

    /**
     * @param mixed $PropPolicyEffectivedate_Tohour_Mandatary
     *
     * @return self
     */
    public function setPropPolicyEffectivedateTohourMandatary($PropPolicyEffectivedate_Tohour_Mandatary)
    {
        $this->PropPolicyEffectivedate_Tohour_Mandatary = $PropPolicyEffectivedate_Tohour_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationProposalDateMandatary()
    {
        return $this->PropGeneralProposalInformation_ProposalDate_Mandatary;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_ProposalDate_Mandatary
     *
     * @return self
     */
    public function setPropGeneralProposalInformationProposalDateMandatary($PropGeneralProposalInformation_ProposalDate_Mandatary)
    {
        $this->PropGeneralProposalInformation_ProposalDate_Mandatary = $PropGeneralProposalInformation_ProposalDate_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksAuthorityLocation()
    {
        return $this->PropRisks_AuthorityLocation;
    }

    /**
     * @param mixed $PropRisks_AuthorityLocation
     *
     * @return self
     */
    public function setPropRisksAuthorityLocation($PropRisks_AuthorityLocation)
    {
        $this->PropRisks_AuthorityLocation = $PropRisks_AuthorityLocation;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationOfficeName()
    {
        return $this->PropGeneralProposalInformation_OfficeName;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_OfficeName
     *
     * @return self
     */
    public function setPropGeneralProposalInformationOfficeName($PropGeneralProposalInformation_OfficeName)
    {
        $this->PropGeneralProposalInformation_OfficeName = $PropGeneralProposalInformation_OfficeName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCityWherePrimarilyUsed()
    {
        return $this->PropRisks_CityWherePrimarilyUsed;
    }

    /**
     * @param mixed $PropRisks_CityWherePrimarilyUsed
     *
     * @return self
     */
    public function setPropRisksCityWherePrimarilyUsed($PropRisks_CityWherePrimarilyUsed)
    {
        $this->PropRisks_CityWherePrimarilyUsed = $PropRisks_CityWherePrimarilyUsed;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksAirbag()
    {
        return $this->PropRisks_Airbag;
    }

    /**
     * @param mixed $PropRisks_Airbag
     *
     * @return self
     */
    public function setPropRisksAirbag($PropRisks_Airbag)
    {
        $this->PropRisks_Airbag = $PropRisks_Airbag;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVehicleTypeCode()
    {
        return $this->PropRisks_VehicleTypeCode;
    }

    /**
     * @param mixed $PropRisks_VehicleTypeCode
     *
     * @return self
     */
    public function setPropRisksVehicleTypeCode($PropRisks_VehicleTypeCode)
    {
        $this->PropRisks_VehicleTypeCode = $PropRisks_VehicleTypeCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRTOCode()
    {
        return $this->PropRisks_RTOCode;
    }

    /**
     * @param mixed $PropRisks_RTOCode
     *
     * @return self
     */
    public function setPropRisksRTOCode($PropRisks_RTOCode)
    {
        $this->PropRisks_RTOCode = $PropRisks_RTOCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksRTOGroupCode()
    {
        return $this->PropRisks_RTOGroupCode;
    }

    /**
     * @param mixed $PropRisks_RTOGroupCode
     *
     * @return self
     */
    public function setPropRisksRTOGroupCode($PropRisks_RTOGroupCode)
    {
        $this->PropRisks_RTOGroupCode = $PropRisks_RTOGroupCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksInsuredHasDrivinglicense()
    {
        return $this->PropRisks_InsuredHasDrivinglicense;
    }

    /**
     * @param mixed $PropRisks_InsuredHasDrivinglicense
     *
     * @return self
     */
    public function setPropRisksInsuredHasDrivinglicense($PropRisks_InsuredHasDrivinglicense)
    {
        $this->PropRisks_InsuredHasDrivinglicense = $PropRisks_InsuredHasDrivinglicense;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralNodesApplicationDate()
    {
        return $this->PropGeneralNodes_ApplicationDate;
    }

    /**
     * @param mixed $PropGeneralNodes_ApplicationDate
     *
     * @return self
     */
    public function setPropGeneralNodesApplicationDate($PropGeneralNodes_ApplicationDate)
    {
        $this->PropGeneralNodes_ApplicationDate = $PropGeneralNodes_ApplicationDate;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getQuotationNumber()
    {
        return $this->QuotationNumber;
    }

    /**
     * @param mixed $QuotationNumber
     *
     * @return self
     */
    public function setQuotationNumber($QuotationNumber)
    {
        $this->QuotationNumber = $QuotationNumber;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEmailId()
    {
        return $this->EmailId;
    }

    /**
     * @param mixed $EmailId
     *
     * @return self
     */
    public function setEmailId($EmailId)
    {
        $this->EmailId = $EmailId;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropSerIntermediaryDetailsSerIntermediaryCode()
    {
        return $this->PropSerIntermediaryDetails_SerIntermediaryCode;
    }

    /**
     * @param mixed $PropSerIntermediaryDetails_SerIntermediaryCode
     *
     * @return self
     */
    public function setPropSerIntermediaryDetailsSerIntermediaryCode($PropSerIntermediaryDetails_SerIntermediaryCode)
    {
        $this->PropSerIntermediaryDetails_SerIntermediaryCode = $PropSerIntermediaryDetails_SerIntermediaryCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksNumberOfPersonsNamed()
    {
        return $this->PropRisks_NumberOfPersonsNamed;
    }

    /**
     * @param mixed $PropRisks_NumberOfPersonsNamed
     *
     * @return self
     */
    public function setPropRisksNumberOfPersonsNamed($PropRisks_NumberOfPersonsNamed)
    {
        $this->PropRisks_NumberOfPersonsNamed = $PropRisks_NumberOfPersonsNamed;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropGeneralProposalInformationDisplayOfficeCode()
    {
        return $this->PropGeneralProposalInformation_DisplayOfficeCode;
    }

    /**
     * @param mixed $PropGeneralProposalInformation_DisplayOfficeCode
     *
     * @return self
     */
    public function setPropGeneralProposalInformationDisplayOfficeCode($PropGeneralProposalInformation_DisplayOfficeCode)
    {
        $this->PropGeneralProposalInformation_DisplayOfficeCode = $PropGeneralProposalInformation_DisplayOfficeCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksAutoTransmission()
    {
        return $this->PropRisks_AutoTransmission;
    }

    /**
     * @param mixed $PropRisks_AutoTransmission
     *
     * @return self
     */
    public function setPropRisksAutoTransmission($PropRisks_AutoTransmission)
    {
        $this->PropRisks_AutoTransmission = $PropRisks_AutoTransmission;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksVehicleSegment()
    {
        return $this->PropRisks_VehicleSegment;
    }

    /**
     * @param mixed $PropRisks_VehicleSegment
     *
     * @return self
     */
    public function setPropRisksVehicleSegment($PropRisks_VehicleSegment)
    {
        $this->PropRisks_VehicleSegment = $PropRisks_VehicleSegment;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getIsThinCustomer()
    {
        return $this->IsThinCustomer;
    }

    /**
     * @param mixed $IsThinCustomer
     *
     * @return self
     */
    public function setIsThinCustomer($IsThinCustomer)
    {
        $this->IsThinCustomer = $IsThinCustomer;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksPreSourceApproval()
    {
        return $this->PropRisks_PreSourceApproval;
    }

    /**
     * @param mixed $PropRisks_PreSourceApproval
     *
     * @return self
     */
    public function setPropRisksPreSourceApproval($PropRisks_PreSourceApproval)
    {
        $this->PropRisks_PreSourceApproval = $PropRisks_PreSourceApproval;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksZoneMandatary()
    {
        return $this->PropRisks_Zone_Mandatary;
    }

    /**
     * @param mixed $PropRisks_Zone_Mandatary
     *
     * @return self
     */
    public function setPropRisksZoneMandatary($PropRisks_Zone_Mandatary)
    {
        $this->PropRisks_Zone_Mandatary = $PropRisks_Zone_Mandatary;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksLoadingNewCarRplacmnt()
    {
        return $this->PropRisks_LoadingNewCarRplacmnt;
    }

    /**
     * @param mixed $PropRisks_LoadingNewCarRplacmnt
     *
     * @return self
     */
    public function setPropRisksLoadingNewCarRplacmnt($PropRisks_LoadingNewCarRplacmnt)
    {
        $this->PropRisks_LoadingNewCarRplacmnt = $PropRisks_LoadingNewCarRplacmnt;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropCustomerDtlsCustomerName()
    {
        return $this->PropCustomerDtls_CustomerName;
    }

    /**
     * @param mixed $PropCustomerDtls_CustomerName
     *
     * @return self
     */
    public function setPropCustomerDtlsCustomerName($PropCustomerDtls_CustomerName)
    {
        $this->PropCustomerDtls_CustomerName = $PropCustomerDtls_CustomerName;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropRisksCountryCode()
    {
        return $this->PropRisks_CountryCode;
    }

    /**
     * @param mixed $PropRisks_CountryCode
     *
     * @return self
     */
    public function setPropRisksCountryCode($PropRisks_CountryCode)
    {
        $this->PropRisks_CountryCode = $PropRisks_CountryCode;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPropCustomerDtlsCustomerIDMandatary()
    {
        return $this->PropCustomerDtls_CustomerID_Mandatary;
    }

    /**
     * @param mixed $PropCustomerDtls_CustomerID_Mandatary
     *
     * @return self
     */
    public function setPropCustomerDtlsCustomerIDMandatary($PropCustomerDtls_CustomerID_Mandatary)
    {
        $this->PropCustomerDtls_CustomerID_Mandatary = $PropCustomerDtls_CustomerID_Mandatary;

        return $this;
    }
}

 
