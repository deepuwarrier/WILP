<?php
namespace App\Helpers\Car\TATA;
use App\Constants\Car_Constants;
use App\Models\Car;
use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use App\Be\Common\GstBe;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class TataHelper {
	protected $productId	=	'TATA';
	public $formated = [];

	public function __construct(){
		if(!empty($this->formated)){
			$this->formated = [];
		}
	}

	public function callSoap($url,$request_xml,$fn = null,$trans_code = null,$log_msg = null){
		try {
			//Log::info("CAR - TATA - Quote Request",$request_xml);
			$atservices_wsdl = $url;
			$soapclient = new \SoapClient($atservices_wsdl);

    		$soapclient->__setLocation($atservices_wsdl);
    		if(!isset($fn))
		       $response = $soapclient->createQuote($request_xml);
		      else{
		       $response = $soapclient->$fn($request_xml);
		      }
		     \Log::info('Car - TATA - '.$log_msg.' - Xml Request - '.$trans_code.' :- ' .$soapclient->__getLastRequest());
			\Log::info('Car - TATA - '.$log_msg.' - Xml Response - '.$trans_code.' :- ' .$soapclient->__getLastResponse());
    		// is_array($response)?Log::info("CAR - TATA - Quote Response",$response):Log::info("CAR - TATA - Quote Response".json_encode($response));
    		if(isset($response) && $response)
    			return $this->responseXmlToArray($response);
    		else
    			return 'null';
		} catch (\SoapFault $exception) {
		//	echo SoapClient::__getLastResponse();
			Log::error('Car - TATA - '.$trans_code.' Soap excempetion error callSoap function  :- '.$exception->getMessage().'<br> Line Number '.$exception->getLine());
		 } catch (\Exception $e) {
			Log::error('Car - TATA - '.$trans_code.' try catch excempetion error callSoap function  :- '.$e->getMessage().'<br> Line Number '.$e->getLine());
			return false;
		}
	}

	public function callJson($title,$url,$postFields,$trans_code = null,$log_msg = null){
		try {
			if(is_array($postFields))
					Log::info('CAR '.$title.' Request - '.$trans_code.' - ', $postFields);
			else
				Log::info('CAR '.$title.' Recquest - '.$trans_code.' - '.$postFields);
			
			$curl = curl_init();
			
			curl_setopt_array($curl, array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 120,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS =>  http_build_query($postFields),
				CURLOPT_HTTPHEADER => array("Content-Type: application/x-www-form-urlencoded"),
			));
			$response = array();
			$data = curl_exec($curl);
			Log::info('CAR '.$title.' Response JSON - '.$trans_code.' - '.$data);
			if(isset($http_config['post-type']) && $http_config['post-type'] == 'http')
				$response = $data;
			else 
				$response = json_decode($data, true);
			
			if(is_array($response))
				Log::info('CAR '.$title.' Response - '.$trans_code.' - ',$response);
			else 
				Log::info('CAR '.$title.' Response - '.$trans_code.' - '.$response);
			
			if (empty($response)) {
				$response['error'] = curl_error($curl);
				$response['status'] = "0";
			}
			
			curl_close($curl);
			return $response;
		} catch (\SoapFault $exception) {
		//	echo SoapClient::__getLastResponse();
			Log::error('Car - TATA - '.$trans_code.' JSON excempetion error callSoap function  :- '.$exception->getMessage().'<br> Line Number '.$exception->getLine());
		 } catch (\Exception $e) {
			Log::error('Car - TATA - '.$trans_code.' try catch excempetion error callSoap function  :- '.$e->getMessage().'<br> Line Number '.$e->getLine());
			return false;
		}
	}

	public function callSoapPdf($url,$request_xml,$fn = null,$trans_code = null,$log_msg = null){
		try {
			//Log::info("CAR - TATA - Quote Request",$request_xml);
			$atservices_wsdl = $url;

			// SOAP 1.2 client
			$params = array ('Content-Type'=>' application/.pdf');

			$soapclient = new \SoapClient($atservices_wsdl,$params);
    		$soapclient->__setLocation($atservices_wsdl);
    		if(!isset($fn))
		       $response = $soapclient->createQuote($request_xml);
		      else{
		       $response = $soapclient->$fn($request_xml);
		      }
		     \Log::info('Car - TATA - '.$log_msg.' - Xml Request - '.$trans_code.' :- ' .$soapclient->__getLastRequest());
			\Log::info('Car - TATA - '.$log_msg.' - Xml Response - '.$trans_code.' :- ' .$soapclient->__getLastResponse());
    		// is_array($response)?Log::info("CAR - TATA - Quote Response",$response):Log::info("CAR - TATA - Quote Response".json_encode($response));
    		if(isset($response) && $response)
    			return $this->responseXmlToArray($response);
    		else
    			return 'null';
		} catch (\SoapFault $exception) {
		//	echo SoapClient::__getLastResponse();
			Log::error('Car - TATA - '.$trans_code.' Soap excempetion error callSoap function  :- '.$exception->getMessage().'<br> Line Number '.$exception->getLine());
		 } catch (\Exception $e) {
			Log::error('Car - TATA - '.$trans_code.' try catch excempetion error callSoap function  :- '.$e->getMessage().'<br> Line Number '.$e->getLine());
			return false;
		}
	}

	public static function callAccounting($url,$request_xml,$fn = null,$trans_code = null){
		$car_helper = new CarHelper;
		try {
			$atservices_wsdl = $url;
			$opts = array(
					'ssl' => array('ciphers'=>'RC4-SHA', 'verify_peer'=>false, 'verify_peer_name'=>false)
				);
			// SOAP 1.2 client
			$params = array ('trace' => 1,'encoding' => 'UTF-8', 'verifypeer' => false, 'verifyhost' => false, 'soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 1, "connection_timeout" => 180, 'stream_context' => stream_context_create($opts),'Content-Type'=>' application/.pdf');
			$soapclient = new \SoapClient($atservices_wsdl,$params);
    		$soapclient->__setLocation($atservices_wsdl);
    		if(!isset($fn))
		       $response = $soapclient->createQuote($request_xml);
		    else{
		       $response = $soapclient->$fn($request_xml);
		    }
			\Log::info('Car - TATA - Accounting - Xml Request - '.$trans_code.' :- ' .$soapclient->__getLastRequest());
			\Log::info('Car - TATA - Accounting - Xml Respinse - '.$trans_code.' :- ' .$soapclient->__getLastResponse());
			if(isset($response) && $response)
	    			return $car_helper->xmlToarray($response,[]);
	    		else
	    			return 'null';
    		
		} catch (\SoapFault $exception) {
		//	echo SoapClient::__getLastResponse();
			Log::error('Car - TATA -'.$trans_code.' Soap excempetion error callSoap function  :- '.$exception->getMessage().'<br> Line Number '.$exception->getLine());
		 } catch (\Exception $e) {
			Log::error('Car - TATA -'.$trans_code.' try catch excempetion error callSoap function  :- '.$e->getMessage().'<br> Line Number '.$e->getLine());
			return false;
		}
	}

	private function responseXmlToArray($data){
	    if(is_object($data)){
	        $data = get_object_vars($data);
	    }
	   
	    if(is_array($data)){
	        foreach ($data as $key => $value) {
	            if($key == 'ResponseXML'){
	            	 if(is_array($value)) {
		            	$this->responseXmlToArray($value);
		            } else {
		            	$value = str_replace('ns2:','',$value);
		            	$data = str_replace('ns3:','',$data);
						$data = str_replace('ns7:','',$data);
						$data = str_replace('soap:','',$data);
		            	$new_data = simplexml_load_string($value);
		                $return_xml_to_array = $this->xml2array($new_data);
		                $this->responseXmlToArray($return_xml_to_array);
		            }
	            } else {
	            	if(is_array($value)) {
		            	$this->responseXmlToArray($value);
		            } else {
		            	$this->formated[$key] = $value;
	            	}
	                // echo "<tr><td>".$key."</td><td>".$value."</td></tr>";       
	            }
	        }
	    }
	   	return $this->formated;
	}

	public function parse_premium_breakup_data_new($pb_data,$irdo){	    
		$data = $irdo['data'];

		$pb_data->setGrossPremium($data['NETPREM']);
		$pb_data->setTotalPremium($data['TOTALPAYABLE']);

		if(isset($data['C1']['premium']))
			$pb_data->setOdPremium($data['C1']['premium']);
		
		if(isset($data['C18']['premium']))
			$pb_data->setLlPremium($data['C18']['premium']);
		
		if(isset($data['C2']['premium']))	
			$pb_data->setTpPremium($data['C2']['premium']);
		
		if(isset($data['C3']['premium']))
			$pb_data->setPaPremium($data['C3']['premium']);
		
		//RTI				
		if(isset($data['C38']['premium']))
			$pb_data->setRtiPremium(round($data['C38']['premium']));
		
		//ZERODEP		
		if(isset($data['C35']['premium']))
			$pb_data->setZerodepPremium(round($data['C35']['premium']));
		
		//PAPASS		
		if(isset($data['C17']['premium']))
			$pb_data->setPapassPremium(round($data['C17']['premium']));
		
		//EP				
		if(isset($data['C44']['premium']))
			$pb_data->setEpPremium($data['C44']['premium']);
		
		//RSAC				
		if(isset($data['C47']['premium']))
			$pb_data->setRsacPremium($data['C47']['premium']);
		
		if(isset($data['C15']['premium']))
			$pb_data->setNcbDiscount($data['C15']['premium']); 
		
		//KEYREPLACE		
		if(isset($data['C43']['premium']))
			$pb_data->setKeyreplacePremium($data['C43']['premium']); 
		
		//LPB		
		if(isset($data['C41']['premium']))
			$pb_data->setLpbPremium($data['C41']['premium']); 
		
		//REPAIR_OF_GLASS		
		if(isset($data['C40']['premium']))
			$pb_data->setRepairOfGlassPremium($data['C40']['premium']); 
		
		//ET_HOTELEXPENSES		
		if(isset($data['C42']['premium']))
			$pb_data->setEtHotelexpenses($data['C42']['premium']);
		
		//COSUMABLE_EXPENSES		
		if(isset($data['C37']['premium']))
			$pb_data->setCosumableExpenses($data['C37']['premium']);
		
		//TS		
		if(isset($data['C45']['premium']))
			$pb_data->setTsPremium($data['C45']['premium']); 
		
		return $pb_data;
	}

	public function parse_premium_breakup_data($pb_data,$irdo){	    
		$pb_data->setGrossPremium($irdo['NetPremium']);
		$pb_data->setTotalPremium($irdo['TotalPremium']);

		if(isset($irdo['OD']))
			$pb_data->setOdPremium($irdo['OD']);
		
		if(isset($irdo['LL']))
			$pb_data->setLlPremium($irdo['LL']);
		
		if(isset($irdo['TP']))	
			$pb_data->setTpPremium($irdo['TP']);
		
		if(isset($irdo['PA']))
			$pb_data->setPaPremium($irdo['PA']);
		
		if(isset($irdo['RTI']))
			$pb_data->setRtiPremium(round($irdo['RTI']));

		if(isset($irdo['ZERODEP']))
			$pb_data->setZerodepPremium(round($irdo['ZERODEP']));

		if(isset($irdo['PAPASS']))
			$pb_data->setPapassPremium(round($irdo['PAPASS']));
		
		if(isset($irdo['EP']))
			$pb_data->setEpPremium($irdo['EP']);
		
		if(isset($irdo['RSAC']))
			$pb_data->setRsacPremium($irdo['RSAC']);
		
		if(isset($irdo['NCB']))
			$pb_data->setNcbDiscount($irdo['NCB']); 

		if(isset($irdo['KEYREPLACE']))
			$pb_data->setKeyreplacePremium($irdo['KEYREPLACE']); 

		if(isset($irdo['LPB']))
			$pb_data->setLpbPremium($irdo['LPB']); 

		if(isset($irdo['REPAIR_OF_GLASS']))
			$pb_data->setRepairOfGlassPremium($irdo['REPAIR_OF_GLASS']); 

		if(isset($irdo['ET_HOTELEXPENSES']))
			$pb_data->setEtHotelexpenses($irdo['ET_HOTELEXPENSES']);

		if(isset($irdo['COSUMABLE_EXPENSES']))
			$pb_data->setCosumableExpenses($irdo['COSUMABLE_EXPENSES']);

		if(isset($irdo['TS']))
			$pb_data->setTsPremium($irdo['TS']); 
		
		return $pb_data;
	}

	private function xml2array($xml){
		$arr = array();
		foreach ($xml->children() as $r) {
		    $t = array();
		    if(count($r->children()) == 0)
		    {
		        $arr[$r->getName()] = strval($r);
		    }
		    else
		    {
		    	$covers_tata	=	[
		    					'WFSystemID' => 'TRANSACTIONID',
								'Owner Driver' => 'PA',
								'Own Damage' => 'OD',
								'Road Side Assistance' => 'RSAC',
								'Basic TP  including TPPD premium' => 'TP',
								'Paid Driver cleaner conductor' => 'LL',
								// 'Personal Accident IMT 17' => '',  // this value is PA to PAID DRiver
								'Unnamed Passengers Personal Account' => 'PAPASS',
								'No Claim Bonus'=>'NCB',
								'Tyre Secure' => 'TS',
								'CNG Kit TP' => 'CNG_KIT',
								'No Claim Bonus NCB Protection' => 'NCBPROTECT',
								'Depreciation reimbursement'=>'ZERODEP',
								'Engine Secure'=>'EP',
								'Return to Invoice'=>'RTI',
								'Daily Allowance' => 'DAILY_ALLOWANCE',
								'Consumable Expense'=>'COSUMABLE_EXPENSES',
								'Loss of Personal belonging' =>	'LPB',
								'Emergency Transport Hotel Exp' =>	'ET_HOTELEXPENSES',
								'Key Replacement' => 'KEYREPLACE',
								'Repair Glass Fiber plastic' => 'REPAIR_OF_GLASS'
							];
		    	if($r->getName() == 'Risks_CoverDetails'){
						if(array_key_exists($r->PropCoverDetails_CoverGroups->__toString(), $covers_tata)){
							$arr[$covers_tata[$r->PropCoverDetails_CoverGroups->__toString()]] = $r->PropCoverDetails_EndorsementAmount->__toString();
						}
		    	} elseif($r->getName() == 'LoadingDiscount'){
						if(array_key_exists($r->PropLoadingDiscount_Description->__toString(), $covers_tata)){
							$arr[$covers_tata[$r->PropLoadingDiscount_Description->__toString()]] = $r->PropLoadingDiscount_CalculatedAmount->__toString();
						}
		    	} else{
		    		$arr[$r->getName()][] = $this->xml2array($r);
		    	}
		    }
		}
		return $arr;
	}

	public function reArrangeProduct($trans_code,$data,$request) {
		$car_lib = new CarLib;
		$car_helper = new CarHelper;
		$car_rto = new M \ CarRto;
		$state = $data['PropRisks_RegistrationNumber'];
		$car_m_products = new M\CarProducts;
		$products =	[];
		$tata_product_details = $car_m_products->getTataProductDetails();
		$products['totalpremium'] = $data['TotalPremium'];
		$products['netPremium'] = 0;
		//echo $products['netPremium'];
		$products['serviceTax'] = $data['ServiceTax'];
		$products['totalpremium'] = round($data['TotalPremium']);
		$products['idv_received'] = round($data['PropRisks_IDVofthevehicle']);
		$products['quotation_number'] = $data['QuotationNumber'];
		$products['addon_selected'] = $this->getAddonProductId($data['PropRisks_AddOnPlanSelected']);
		$products['insurer_id'] = $tata_product_details[$products['addon_selected']]['insurer_id'];
		$products['insurerName'] = $tata_product_details[$products['addon_selected']]['product_name'];
		$products['product_id'] = $tata_product_details[$products['addon_selected']]['product_id'];
		$products['insurerroute'] = 'tata';
		$products['logo'] = $tata_product_details[$products['addon_selected']]['product_img'];
		$products['warning_msg'] = $data['ProductServiceWarning'];
		$reformated_covers = $this->reformatIncludePackage($data);
		$products['covers'] = [];

		
		$OD_price = $car_lib->calculateOD($request['vehicle_cc']
				,$car_rto->getRtoZone($request['rto']),$request['vehicleAge']
				,$products['idv_received']);

		$covers_select_displayname = [
										'OD' => 'Own Damage',
										'TP' => 'Third Party Liability',
										'NCB' => 'No Claim Bonus',
										'DAILY_ALLOWANCE'=>'Daily Allowance ',
										'COSUMABLE_EXPENSES'=>'Comsumable Expenses',
										'LPB'=>'Loss of Personal Belongings',
										'ET_HOTELEXPENSES'=>'Emergency Hotel & Transportation',
										'KEYREPLACE'=>'Key Replacement',
										'REPAIR_OF_GLASS'=>'Repair of glass, plastic fibre and rubber glass',
										'RSAC' => 'Enhanced Roadside Assistance',
										'TS' => 'Tyre Secure',
										'ZERODEP' => 'Zero Depreciation',
										'RTI' => 'Return to Invoice',
										'EP' => 'Engine Protect',
										];
		$covers_select_addon_displayname = [
										
										'PA' => 'PA to Owner Driver (2 Lacs)',
										'LL' => 'Legal Liability',
										'PAPASS'	=>	'PA to Unnamed Passengers (1 Lac)',
										'NCBPROTECT' => 'NCB Protection'
										];

		foreach ($reformated_covers as $key => $value) {
			if($value != '0.0'){
				if(isset($covers_select_displayname[$key]))
				{
					if ($key === 'OD') {
						$products[strtolower($key).'_basic_price'] = $OD_price; // $basic['premium'];
						$products[strtolower($key).'_discounted_amount'] = $value;
						$products[strtolower($key).'_discount'] = $OD_price - $value;
						$products[strtolower($key).'_basic_displayname'] = $covers_select_displayname[$key];
						$products['premiumBreakup']['basic'][strtolower($key).'_basic_price'] = 	[
																	'displayName' => $products[strtolower($key).'_basic_displayname'],
																	'basic_premium' => ($OD_price)
																];
						$products['netPremium']	=	$products['netPremium'] + $value;
					}else {
						$products[strtolower($key).'_basic_displayname'] = $covers_select_displayname[$key];
						$products[strtolower($key).'_basic_price'] = ($value);
						if($key != 'NCB')
							$products['netPremium']	=	$products['netPremium'] + $value;
						else 
							$products['netPremium']	=	$products['netPremium'] - $value;
					}
					if($key != 'NCB'){
						if($key === 'OD'){
							$od_discount_price = $products['od_discount'];
							$od_discount_displayname = 'OD discount';
							$products['premiumBreakup']['discounts']['od_discount_price']['displayName']	=	$od_discount_displayname;
							$products['premiumBreakup']['discounts']['od_discount_price']['basic_premium']	=	($od_discount_price);
						} else {
							$products['premiumBreakup']['basic'][strtolower($key).'_basic_price'] = 	[
																	'displayName' => $products[strtolower($key).'_basic_displayname'],
																	'basic_premium' => ($value)
																];
						}
					} else if( $key === 'NCB') {
						$products['premiumBreakup']['discounts']['ncbbenefit_discount_price'] = [
																			'displayName' => $products[strtolower($key).'_basic_displayname'],
																			'basic_premium' => ($value)
																		];
					}
				} elseif (isset($covers_select_addon_displayname[$key])) {
					$products[strtolower($key).'_addon_displayname'] = $covers_select_addon_displayname[$key];
					$products[strtolower($key).'_addon_price'] = ($value);
					if(($key == 'PA') || ($key == 'LL')) {
						$products['premiumBreakup']['addon'][strtolower($key).'_addon_price'] = 	[
																	'displayName' => $products[strtolower($key).'_addon_displayname'],
																	'basic_premium' => ($value)
																	];
						$products['netPremium']	=	$products['netPremium'] + $value;
					}
					/*
					if(($key != 'PA') && ($key != 'LL')){
						$products['netPremium'] = $products['netPremium'] - $value;
					}
					*/
				} else {
					continue;
				}
			} elseif($key == 'RSAC') {
				$products[strtolower($key).'_basic_displayname'] = $covers_select_displayname[$key];
				$products[strtolower($key).'_basic_price'] = 116;
				// $products['netPremium']	=	$products['netPremium'] + $products[strtolower($key).'_basic_price'];
				$products['premiumBreakup']['basic'][strtolower($key).'_basic_price'] = 	[
																	'displayName' => $products[strtolower($key).'_basic_displayname'],
																	'basic_premium' => round(116)
																];
			} else {
				continue;
			}
		}

		
        /*if($gstData->get_active_tax() == 'SGSTCGST'){
           $servicetax = $gstData->get_sgst_value() + $gstData->get_cgst_value();
        }else{
           $servicetax = $gstData->get_igst_value();
        }*/

		//$servicetax = ($products['netPremium']*Car_Constants::GST)/100;

		$products['netPremium'] = $products['netPremium'];
		$products['serviceTax'] = round($servicetax);
		$products['totalpremium']	=	round($products['netPremium'] + $servicetax);

		if(isset($products['premiumBreakup']['basic']['rsac_basic_price'])){
			$rsac_premium = $products['premiumBreakup']['basic']['rsac_basic_price']['basic_premium'];

			$gstData = $gstBe->get_gst_values($vendor_gst_code,$cust_gst_code,$rsac_premium,false);
        	$rsac_servicetax = $gstData->get_total_tax();
        	$products['serviceTax'] = $servicetax + $rsac_servicetax;
        	$products['netPremium'] = $products['netPremium'] + $rsac_premium;
        	$products['totalpremium'] = round($products['netPremium']) + $products['serviceTax'];
        	// dd($products);
		} else {
			$products['serviceTax'] = $servicetax;
		}
		$products['premiumBreakup']['totalpremium'] = [
															'displayName'=>'Total Premium',
															'basic_premium'=>$products['totalpremium']
														];
		$products['premiumBreakup']['serviceTax'] = [
															'displayName'=>'Goods & Service Tax',
															'basic_premium'=>$products['serviceTax']
														];
		$products['premiumBreakup']['netPremium'] = [
															'displayName'=>'Net Premium',
															'basic_premium'=>$products['netPremium']
												];
		$display_name = Car_Constants::TATA_DISPLAY_NAME;
		$basic_premium_arrange = ['basic' => ['od','tp','ll', 'pa','rti','daily_allowance','zerodep','ep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','keyreplace','repair_of_glass','rsac']
						            //, 'addon' => ['rti', 'zerodep','papass','ep','rsac']
						            , 'discounts' => ['ncbbenefit', 'od',]
						            , 'totalpremium'
						            , 'serviceTax'
						            , 'netPremium'];
        $basic_arrange = ['basic' => ['od','tp','ll', 'pa','rti','daily_allowance','zerodep','ep','cosumable_expenses','pa','ll','lpb','et_hotelexpenses','keyreplace','repair_of_glass','rsac']];
		$premium_breakup = [];
		foreach ($basic_arrange as $key => $values) {
			$price_keys = ['basic' => '_basic_price', 'addon' => '_addon_price', 'discounts' => '_discount_price'];
			if($key == 'basic'){
				if (is_array($values)){
					 foreach ($values as $second_key) {
	                    if (isset($products[$second_key . $price_keys[$key]])){
	                    	$premium_breakup[$key][$second_key . $price_keys[$key]] = ['displayName' => $display_name[$key][$second_key],
	                                    'basic_premium' => $products[$second_key . $price_keys[$key]]];
	                    }
	                }
				}
			}
		}
  //       $products['premiumBreakup']['basic'] = $premium_breakup['basic'];
		return $products;
	}

	public function getAddonProductId($data){
		$product_id = [
						'P1' => 'tata_silver',
						'P2' =>'tata_gold',
						'P3' =>'tata_pearl',
						'P8' =>'tata_pearl_p',
						'P9' =>'tata_sapphire',
						'P10' =>'tata_sapphire_p',
						'P11' =>'tata_sapphire_pp'
					];
		return $product_id[$data];
	}

	private function reformatIncludePackage($covers){
		$re_covers = [];
		$covers_select	=	['OD','TP','LL','PA','RTI','ZERODEP','PAPASS'];
		$covers_tata	=	[
								'OD'=>'OD',
								'TP' => 'TP',
								'PA' => 'PA',
								'LL' => 'LL',
								'PAPASS' => 'PAPASS',
								'NCB'=>'NCB',
								'TS'=>'TS',
								'ZERODEP'=>'ZERODEP',
								'EP'=>'EP',
								'NCBPROTECT'=>'NCBPROTECT',
								'RTI'=>'RTI',
								'RSAC'=>'RSAC',
								'DAILY_ALLOWANCE'=>'DAILY_ALLOWANCE',
								'COSUMABLE_EXPENSES'=>'COSUMABLE_EXPENSES',
								'LPB'=>'LPB',
								'ET_HOTELEXPENSES'=>'ET_HOTELEXPENSES',
								'KEYREPLACE'=>'KEYREPLACE',
								'REPAIR_OF_GLASS'=>'REPAIR_OF_GLASS',
								'CNG_KIT' => 'CNG_KIT'
							];
		foreach($covers as $cover_product_attr => $cover_value){
			if(array_key_exists($cover_product_attr, $covers_tata)){
				$re_covers[$covers_tata[$cover_product_attr]] = $cover_value;
			}
		//	unset($re_covers[$cover_value['coverId']]['coverId']);
		}
		return $re_covers;
	}
}
?>
