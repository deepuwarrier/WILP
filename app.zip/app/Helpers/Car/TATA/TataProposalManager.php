<?php
namespace App\Helpers\Car\TATA;

use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use App\Be\Car as BE;
use App\Be\Common\GstBe;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use App\Be\Car\CarPolicyBe;
use Illuminate\Support\Facades\Log;
use App\Be\Common\PaymentParseBE;

class TataProposalManager{
	public $pdf_url = Car_Constants::TATA_POLICY_PDF_URL;

	public function __construct(){
		$this->http_config['content-type'] = 'application/x-www-form-urlencoded';
		$this->http_config['post-type'] = 'http';
		$this->refrel_col = "tata_code";
		$this->new_refrel_col = "tata_code";
		$this->refrel_variant_col = "lstdec_code";
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->title = Car_Constants::TITLE;
		$this->type_of_finance = Car_Constants::TYPE_OF_FINANCE;
		$this->nu_of_claim = Car_Constants::NUMBER_OF_CLAIM;
		$this->test = 0;
		$this->redirect = 0;
		$this->policy_type = Car_Constants::POLICY_TYPE;
		$this->type_of_finance = Car_Constants::TYPE_OF_FINANCE;
	}

	public function getProposalFormData($request_data){
		// $session_id = $request_data['session_id'];
		$car_m_products = new M\CarProducts;
		$tata_product_details = $car_m_products->getTataProductDetails();
		$trans_code = $request_data['trans_code'];
		$car_helper = new CarHelper;
		$this->getDbData($trans_code);
		$covers = array_key_exists('covers_selected',$this->user_data) ? explode(',',$this->user_data['covers_selected']) : [];
		$product_id = $request_data['product_id'];
		$cmp_name = $tata_product_details[$product_id]['product_name'];
		
		$user_data = CarTData::find($trans_code);
		$car_details = $car_helper->getCarBasicDetails($user_data);
		unset($user_data);
		
		$predefinedData = $this->getPredefinedData($request_data);
		$data = $this->requiredData($predefinedData['product_id']);
		$data['maritalstatus'] = [['id'=>'Single','value'=>'Single'],
								  ['id'=>'Married','value'=>'Married'],
								  ['id'=>'Others','value'=>'Others']];
		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
		$stateCity = $this->getStateCity('tata');
		$data = (!empty($stateCity)) ? array_merge($data, $stateCity) : array_merge($data, $this->stateCity);
		$this->changeDateFormate(); 
		$data['trans_code'] = $trans_code;
		$data['non_elect_ass'] = $this->non_elect_ass;
		$data['perm_diff'] = (($this->user_data['reg_add_is_same']) == 'N') ? '': 'checked';
		$data['reg_add_is_same'] = $predefinedData['reg_add_is_same'];
		$packages = array_flip(Car_Constants::TATA_PACKAGES[$product_id]['addon']);
		$preinsurer_addon_selected = (empty(json_decode($this->user_data['prev_addons'],true))?$packages:json_decode($this->user_data['prev_addons'],true));//['zerodep','ts','ep','rti'];
		
		$check_prev_addon = ['zerodep','ts','ep','rti'];
		foreach ($check_prev_addon as $key => $value) {
			if(array_key_exists($value, $preinsurer_addon_selected)){
				$preinsurer_addon_check[$value] = $preinsurer_addon_selected[$value];
			} else {
				$preinsurer_addon_check[$value] = 'N';
			}
		}
		foreach ($preinsurer_addon_check as $key => $value) {
			if(!isset($preinsurer_addon_check[$key])){
	   			$data['yes_prev_'.$key] = 'checked';
	   			$data['no_prev_'.$key] = '';
			} else if($preinsurer_addon_check[$key] === 'Y'){
	   			$data['yes_prev_'.$key] = 'checked';
	   			$data['no_prev_'.$key] = '';	
	   		} else {
	   			$data['yes_prev_'.$key] = '';
	   			$data['no_prev_'.$key] = 'checked';
	   		}
		}

   		$fullname = (isset($this->user_data['firstname']) && isset($this->user_data['lastname']))?$this->user_data['firstname'].' '.$this->user_data['lastname']:'';
   		$electric_acc_year = [];
   		$current_date = Carbon::now();
   		$diff_year = $current_date->year - $this->user_data['yom_selected'];
   		for($i=0; $i <=$diff_year  ; $i++) { 
   			$electric_acc_year[Carbon::now()->subYear($i)->format('Y/01/01')] = Carbon::now()->subYear($i)->format('Y');
   		}
   		$predefinedData['is_external_cng'] =  ((isset($car_details)) && ($car_details['fuel'] != 'CNG'))?true:false;

		return array_merge($data, ['minYear' => $this->carpolicybe->getMinYear(),
			'year_select' => $this->carpolicybe->getYears($trans_code),
			'electric_acc_year' => $electric_acc_year,
			'elect_ass' => $this->elect_ass,
			'non_elect_ass' => $this->non_elect_ass,
			'user_data' => $this->user_data,
			'title' => $this->title,
			'car_detail' => (!empty(session('details_selected')['make_name'])) ? session('details_selected') : $car_details,
			'cmp_name' => $cmp_name.' GI',
			'fullname'=>$fullname,
			'predefinedData' => $predefinedData,
			'totalpremium' => $predefinedData['totalpremium'],
			'netPremium' => $predefinedData['netPremium'],
			'return_quote_url' => $predefinedData['return_quote_url'],
			'typeOfBusiness' => $car_details['typeOfBusiness'],
			'requiredRollover' => (strtolower($car_details['typeOfBusiness']) == "rollover") ? "required" : "",
			'masterData' => (isset($this->master_data)) ? $this->master_data : [],
			'redirected' => $this->redirect,
			'policy_type' => $this->policy_type,
			'nu_of_claims' => $this->nu_of_claim,
			'type_of_finance' => $this->type_of_finance,
			'width_tab' => 20,

		]);
	}

	public function getPredefinedData($request_data){
		session(['request' => $request_data]);
		$carcfgobj = new CarConfig;
    	$yor_select_start = $carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$car_t_data = new CarTData;
		$user_data = $car_t_data->find($request_data['trans_code'])->toArray();
		$date = Carbon::now();
		$return_data_field = ['variant_code','product_id','insurer_id','totalpremium','netPremium','trans_code','return_quote_url','policyStartDate','idv','policyExpiryDate','rto','price','claim'];
		foreach ($return_data_field as $value) {
			$return_data[$value] = $request_data[$value];	
		}
		$product_id = $request_data['product_id'];
		$return_data['quote_id']   = $request_data['quote_id'];
		$return_data['session_id']   = $request_data['session_id'];
		$return_data['idv_opted'] = $request_data['idv'];
		$return_data['ncb'] = $request_data['new_ncb'];
		$return_data['pre_ncb'] = $request_data['ncb'];
		$return_data['year'] = (isset($request_data['year']))? $request_data['year'] : null;
		$return_data['sc'] = 5;
		$return_data['occupation'] = 0;
		$return_data['regDate'] =  (isset($request_data['regDate']) && $request_data['regDate'])  ? $request_data['regDate'] : $request_data['car_registration_date'];
		$this->getDbData($return_data['trans_code']);
		$policy_exp_status = (isset($this->db->policy_exp_status)) ? $this->db->policy_exp_status : 0;
		if (date('Y', strtotime($return_data['regDate'])) == $yor_select_start) {
			$return_data['typeOfBusiness'] = 'new_bussiness';
			$return_data['policyStartDate'] = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyStartDate'])));
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_NEWBUSINESS;
			
		} else {
			$return_data['typeOfBusiness'] = 'rollover';
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyExpiryDate'])));
			$return_data['policyStartDate'] = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_ROLLOVER;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_ROLLOVER;
		}
		if($policy_exp_status == 2){
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_NEWBUSINESS;
		}
		$return_data['perm_diff'] = (($this->user_data['reg_add_is_same']) == 'N') ? '': 'checked';
		
		$return_data['reg_add_is_same'] = (isset($this->user_data['reg_add_is_same']) && $this->user_data['reg_add_is_same']) ? $this->user_data['reg_add_is_same'] : 'Y';
		
		$return_data['prev_claim_status'] = $request_data['claim'];
   		$this->genrateTransactionTable($return_data);
   		$return_data['refrel_col'] = $this->refrel_col;

   		$default_package = Car_Constants::TATA_PACKAGES;
		$preinsurer_addon_check = ['zerodep','ts','ep','rti'];
		if(array_key_exists($product_id, $default_package)){
			foreach ($preinsurer_addon_check as $key1 => $value1) {
				if(in_array($value1, $default_package[$product_id]['addon'])){
					$return_data[$value1.'_selected'] = true;
				} else {
					$return_data[$value1.'_selected'] = false;
				}
			}
			/*foreach ($default_package[$product_id]['addon'] as $key1 => $value1) {
				if(in_array($value1, $preinsurer_addon_check)){
					$return_data[$value1.'_selected'] = true;
				} else {
					$return_data[$value1.'_selected'] = false;
				}
			}*/
		}

		$return_data['addon_status_url']  = route('car.tata.addon_status');
		$return_data['external_cng_status_url']  = route('car.tata.external_cng_status');
		return $return_data;
	}

    public function getStateCity($product_id) {
    	$car_helper = new CarHelper;
		if (!Session::has($product_id . 'apiDataState')) {
			$state = $car_helper->getMasterData($this->refrel_col, 'State');
			if (!empty($state)) {
				$field_name = $car_helper->getFieldName('COMMUNICATION', 'USR_STATE_CODE');
				$state_id = (isset($this->user_data[$field_name])) ? $this->user_data[$field_name] : $state[0]['id'];
				$city = $car_helper->getMasterCity($this->refrel_col, 'City', $state_id);
				$field_name = 'perm_statecode';
				$perm_state_id = (isset($this->user_data[$field_name])) ?
				$this->user_data[$field_name] : $state[0]['id'];
				$perm_city = $car_helper->getMasterCity($this->refrel_col, 'City', $perm_state_id);
				Session::put($product_id . 'apiDataState', ['state' => $state, 'city' => $city,'perm_city'=>$perm_city]);
				Session::save();
				return ['state' => $state, 'city' => $city,'perm_city'=>$perm_city];
			}else{
				return [];
			}
		}
		return Session::pull($product_id . 'apiDataState');
	}

	public function requiredData($product_id) {
		$response_data = array();
		$car_helper = new CarHelper;
		foreach (Car_Constants::TATA_MASTER as $value) {
			$refrel_col = $this->refrel_col;
			$result = $car_helper->getMasterData($refrel_col, $value);
			$response_data[strtolower($value)] = (!empty($result)) ? $result : array();
		}
		Session::put($product_id . 'apiData', $response_data);
		Session::save();
		return Session::pull($product_id . 'apiData');
	}

	public function genrateTransactionTable($data){
		$car_t_data = new CarTData;
    	$fields = ['trans_code'
				 ,'insurer_id'
				 ,'product_id'
				 ,'return_quote_url'
				 ,'totalpremium'
				 ,'netPremium'
				 ,'final_premium'
				 ,'quote_id'
				 ,'tax'];
		foreach ($fields as $value) 
			if(isset($data[$value]))
				$table[$value] = $data[$value];		

		if(isset($table['trans_code']))
			return $car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
		else 
			return false;
    }

    public function callProposal($req_param,$trans_code = null){
    	$car_helper = new CarHelper;
    	$tata_helper = new TataHelper;
    	$mode_operation = 'NEWPOLICY';
    	$InputXML = $car_helper->genrateXml('<PrivateCarInsurancePolicy/>',$req_param)
    				->asXML();
	    $proposal_request['ProductCode'] = Car_Constants::TATA_PRODUCT_CODE;
	    $proposal_request['AuthenticationToken'] = '';
	    $proposal_request['CIAName'] ='';
	    $proposal_request['Campaign'] = Car_Constants::TATA_CAMPAIGN;
	    $proposal_request['HashKey'] = '';
	    $proposal_request['HostAddress'] ='';
	    $proposal_request['Medium'] = Car_Constants::TATA_MEDIUM;
	    $proposal_request['Source'] = Car_Constants::TATA_SOURCE;
	    $proposal_request['InputXML'] =$InputXML;
	    $proposal_request['IsBankDataRequired'] ='false';
	    $proposal_request['IsCutomerAddressRequired'] ='false';
	    $proposal_request['IsFinanciarDataRequired'] ='false';
	    $proposal_request['IsManufacturerMappingRequired'] ='false';
	    $proposal_request['IsRTOMappingRequired'] ='false';
	    $proposal_request['ModeOfOperation'] = $mode_operation;
	    $proposal_request['UserId'] = Car_Constants::TATA_USER_ID;
	    $proposal_request['UserRole'] = Car_Constants::TATA_USER_ROLE;
	    if(is_array($proposal_request))
	    	Log::info('Car Tata Proposal Request - '.$trans_code.' - ',$proposal_request);
		else 
			Log::info('Caar Tata Proposal Request - '.$trans_code.' - '.$proposal_request);
		$response = $tata_helper->callSoap(Car_Constants::TATA_QUOTE_URL,$proposal_request,'saveProposal',$trans_code,'Proposal');
		 if(is_array($proposal_request))
	    	Log::info('Car Tata Proposal Response - '.$trans_code.' - ',$response);
		else 
			Log::info('Car Tata Proposal Response - '.$trans_code.' - '.$response);
	    return $response;
	}

	public function checkInspectionStatus($pg_trans_no){
		$car_helper = new CarHelper;
		$url = $this->service_url.'/GetBreakinInspectionStatus';
		$request_param['AgentCode'] = $this->AgentCode;
		$request_param['PGTransNo'] = $pg_trans_no;
		$response = $car_helper->callApi($url,$request_param,$this->http_config);
	}

	public function genrateProposalResponse($result,$data,$final_premium = false,$trans_code = null){
		$car_helper = new CarHelper;
		$car_policy = new CarPolicyBe;
		$payment_parse_be = new PaymentParseBE;
		$return_response = [];
		$breacking_case =  0;
		if($result){
			if($result['ErrorText'] != ''){
				$case = 'Error';
			} else {
				
				$gstBe = new GstBe();
				$stateDb = new M\MasterState();
		        $vendor_gst_code = Car_Constants::TATA_GST_CODE;
				$state = substr($data->car_rto,0,2);
				$cust_gst_code = $stateDb->getGSTCodeByState($state);	
				// $response_totalpremium = $result['TotalPremium'];
				if(isset($result['TotalPremium'])){
					if((array_key_exists('RSAC',$result)) && ($result['RSAC'] == "0.0")){
						$rsac_value = 116;
						$gstData = $gstBe->get_gst_values($vendor_gst_code,$cust_gst_code,$rsac_value);
		        		$rsac_servicetax =  $gstData->get_total_tax();
						$response_totalpremium = $result['TotalPremium'] + ($rsac_value + $rsac_servicetax);
					} else {
						$response_totalpremium = $result['TotalPremium'];
					}
				}
				$totalpremium = ($final_premium)? $data['final_premium'] : $data['totalpremium'];
				if(round($response_totalpremium) != round($totalpremium)) {
					if(!$car_policy->needConfirmation($response_totalpremium,$totalpremium))
						$case = 'Payment';	
					else
						$case = 'Premium Mismatch';
				} else {
					$case = 'Payment';
				}
			}
		} else{
			$case = 'ApiNotWorking';
		}

		if($case == 'Premium Mismatch' || $case == 'Payment'){
			$data->transaction_id = $result['WFSystemID'];
			$data->proposal_nu = $result['ProposalNo'];
			$data->customer_id = $result['PropCustomerDtls_CustomerID_Mandatary'];
			$data->save();
		}
		
		if(isset($data['policy_exp_status']) && $data['policy_exp_status'] != 0)
			$breacking_case =  1;
		
		switch ($case) {
    		case 'Premium Mismatch':
				//$result = $this->parsePremiumMissmatch($explode_result);
				$return_response['error'] = 'premium mismatch';
				$return_response['premiumPayable'] = $response_totalpremium;
				$return_response['passedPremium'] = $data['totalpremium'];
				$this->updatePremiumeValue($result,$data);
    			break;
    		case 'Payment':
    			$payment_parse_be->setPaymentIdentifier($trans_code,$trans_code);
				$return_response['url'] = Car_Constants::TATA_PAYMENT_URL;
				$fields["vendorcode"] = Car_Constants::TATA_VENDOR_CODE;
				$fields["referencenum"] = $trans_code;//round($car_helper->getMilitime());
				$fields['amount'] = round($response_totalpremium);
				$fields['productcode'] = Car_Constants::TATA_PRODUCT_CODE;
				$fields['action'] = Car_Constants::TATA_ACTION;
				$fields['producercode'] = Car_Constants::TATA_PRODUCER_CODE;
				$fields['hash'] = $this->getTataHashCode($fields);
				Log::info('Car Tata Payment Request - '.$trans_code.' - ',$fields);
				$return_response['fields'] = $fields;
				break;

    		case 'Error':
    			$return_response = ['error'=>$result['ErrorText']];
    			break;
    		default:
				$return_response = ['proposal_error' =>'Api Not Working'];
    			break;
    	}

    	if($breacking_case){
    		if($case == 'Payment'){
    			$return_response = ['proposal_error' =>'Congratulations!<br/>
Inspection of your vehicle has been scheduled.<br/>
The reference number is : '.$data['quote_id']];
    		}
    	}

		if(isset($return_response['proposal_error'])){
    		session()->put('flash_msg',$return_response['proposal_error']);
			$footer_msg = '<h5>You will be contacted by a representative of TATA Insurance Company shortly.</h5>
			  <h6>For any queries contact InstaInsure at: +91 7899-000-333</h6>';
			session()->put('footer_msg',$footer_msg);
			session()->save();
    	}

    	return $return_response;
    	
	}

	private function getTataHashCode($data){
		$url = Car_Constants::TATA_PAYMENT_URL;
		$string = $url.'?'.'vendorcode='.$data["vendorcode"].'&referencenum='.$data["referencenum"].'&amount='.$data['amount'].'&productcode='.$data['productcode'].'&action='.$data['action'].'&producercode='.$data['producercode'];
		$codestring = $string.Car_Constants::TATA_HASH_KEY;
		return md5(trim($codestring));
	}


	private function parsePremiumMissmatch($data){
		$premium = [];

		foreach ($data as $key => $value)
    						$data[$key] = explode(':', $data[$key]);

		foreach ($data as $key => $value) {
			if(is_array($value)){
				$len = count($value);
				if($len > 1)
					$premium[trim($value[$len-2])] = trim($value[$len-1]);
				else 
					$premium[$key] = trim($value[$len-1]);
			}
		}

		return $premium;
	}
	
	private function updatePremiumeValue($result,$data){
		$car_helper = new CarHelper;
		$gstBe = new GstBe();
		$stateDb = new M\MasterState();
        	$vendor_gst_code = Car_Constants::TATA_GST_CODE;
		$state = substr($data->car_rto,0,2);
		$cust_gst_code = $stateDb->getGSTCodeByState($state);
		if((array_key_exists('RSAC',$result)) && ($result['RSAC'] == "0.0")) {
			$rsac_value = 116;
			$gstData = $gstBe->get_gst_values($vendor_gst_code,$cust_gst_code,$rsac_value);
    		$rsac_servicetax =  $gstData->get_total_tax();
			$response_totalpremium = $result['TotalPremium'] + ($rsac_value + (($rsac_value*Car_Constants::GST)/100));
		}	else {
			$response_totalpremium = $result['TotalPremium'];
		}
		// $response_totalpremium = $result['TotalPremium'];
		$data = ['final_premium'=>$response_totalpremium
				 ,'trans_code'=>$car_helper->getSuid()];
		return $this->genrateTransactionTable($data);
	}

    public function getDbData($trans_code) {
    	$car_t_data = new CarTData;
    	$car_helper = new CarHelper;
		$this->field = 	$car_helper->getFieldMap();
		$user_data = $car_t_data->find($trans_code);
		$this->db = (!$user_data) ? [] : $user_data;
		$this->user_data = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $this->field);

		if(!$this->user_data['regno']){
            $car_lib = new CarLib;
            $this->user_data['regno'] = $car_lib->parseRegistrationNumber($user_data['car_rto']).'-';
            unset($car_lib);
            unset($user_data);
        }
	}

	

	public function parse_pgresp($pgstr){
		$pg_resp_arr = explode("||", $pgstr );
		if(is_array($pg_resp_arr) && count($pg_resp_arr) == 7){
			$pg_resp_arr = ['TID'=>$pg_resp_arr[0],
						'partnercode'=>$pg_resp_arr[1],
						'PostAuthCode'=>$pg_resp_arr[2],
						'referenceid'=>$pg_resp_arr[3],
						'ammount'=>$pg_resp_arr[4],
						'msg'=>$pg_resp_arr[5],
						'status'=>$pg_resp_arr[6],
					];	
			$pg_resp_arr = array_map('trim',$pg_resp_arr);
		}
		return $pg_resp_arr;
	}

	public function genPolicyNumber($response){
		$this->status = 0;
		$car_helper = new CarHelper;
		$session_id = $trans_code = $car_helper->getSuid();
		$user_data =  CarTData::find($trans_code);

		$car_helper->log_policy_status($trans_code,'policy_request');

		$AccountingObj = new AccountingRequest($user_data,$response);
		Log::info('Car TATA Accounting Request for '.$trans_code.' - '.print_r($AccountingObj->request,true));
		/*
		if(is_array($AccountingObj->request))
			Log::info('Car TATA Accounting Request - '.$session_id.' - ',$AccountingObj->request);
		else 
			Log::info('Car TATA Accounting Request - '.$session_id.' - '.$AccountingObj->request);
		*/
		
		$account_response = TataHelper::callAccounting(Car_Constants::TATA_ACCOUNTING_URL,$AccountingObj->request,'paymentEntryCumPolicyGen');
		
		if(isset($account_response)){
			Log::info('Car TATA Accounting Response for '.$trans_code.' - '.print_r($account_response,true));
			/*
			if(is_array($account_response))
				Log::info('Car TATA Accounting Response - '.$session_id.' - ',$account_response);
			else
				Log::info('Car TATA Accounting Response - '.$session_id.' - '.$account_response);
			*/
		} else 
			Log::info('Car TATA Accounting Response - '.$trans_code.' -  null');

		if(is_array($account_response)){
			if(isset($account_response['Body']))
				$account_response = $account_response['Body'];
			if(isset($account_response['PaymentEntryCumPolicyGenResponse']))
				$account_response = $account_response['PaymentEntryCumPolicyGenResponse'];
		}
		if(isset($account_response['return']['PolicyNo']) && $account_response['return']['PolicyNo'] != '')
			$this->status = 1; 
			$this->setPolicyRefNo($account_response['return']['PolicyNo']);
			if($user_data){
				$user_data->policy_nu = $account_response['return']['PolicyNo'];
				$user_data->order_nu = $account_response['return']['NewlyCreatedReceipts'];
				$user_data->save();	
			}
		else 
			$this->setPolicyRefNo($response['TID']);

		$car_helper->log_policy_result($trans_code,$this->status,['msg'=>$account_response['return']['ErrorMsg']]);
	}

	public function genPolicyPdf($user_data){
		$carlib = new CarLib;
		$tata_helper = new TataHelper;
		$request_param = ['source'=>0,
			'medium'=>0,
			'campaign'=>0,
			'strLVAuthToken'=>'',
			'objServiceResult'=>['UserData'=>[
				'CustomerId'=>$user_data->customer_id,
				'ProductCode'=>'',
				'ProposalDate'=>$user_data->updated_at,
				'ProposalNumber'=>$user_data->proposal_nu,
				'ReportTypeCode'=>4,
				'UserId'=>'3051994444',
				'UserRole'=>'Admin',
				]
			]
		];

		Log::info('Car Tata Policy Pdf Request - '.$user_data->trans_code.' - ',$request_param);
		$polcy_response = $tata_helper->callSoapPdf($this->pdf_url,$request_param,'getPolicyDocumentForPortal',null,'POLICY');

		if(isset($polcy_response) && is_array($polcy_response))
			Log::info('Car Tata Policy Pdf Request - '.$user_data->trans_code.' - ',$polcy_response);
		else 
			Log::info('Car Tata Policy Pdf Request - '.$user_data->trans_code.' - '.$polcy_response);
		
		$filename = 'tata_policy';
		if(isset($polcy_response['GetPolicyDocumentForPortalResult'])){
			$destination = public_path(). '/pdf/car/'.$filename.'.pdf';
			if(file_exists($destination))
				unlink($destination);
			$file = fopen($destination, "w+");
		    fputs($file,$polcy_response['GetPolicyDocumentForPortalResult']);
		    fclose($file);
		 	$headers = [
              'Content-Type' => 'application/pdf',
           ];
           if($user_data->type_of_business == 'Rollover')
           		$policy_file_name = 'PC_TATA_'.$user_data->veh_reg_no.'.pdf';
           	else
           		$policy_file_name = 'PC_TATA_'.$user_data->proposal_nu.'.pdf';
		   return response()->download($destination,$policy_file_name,$headers);
		}else{
			return response('<p>please try again later</p>');
		}
	}

	public function genratePaymentTable($payment_resp){
		$car_helper = new CarHelper;
		$session_id = $car_helper->getSuid();	
		$table['session_id'] = $session_id;
		$table[Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG']] = $payment_resp;
		$payment_resp_arr = $this->parse_pgresp($payment_resp);
		if(is_array($payment_resp_arr) && isset($payment_resp_arr['TID']))
			$table[Car_Constants::CAR_T_PROPOSALLOG['TRANSACTION_ID']] = $payment_resp_arr['TID'];
		$this->status = (isset($payment_resp_arr['status']) && $payment_resp_arr['status'] == '0300') ? 1 : 0;
		return $table;
	}

	// set policy refreance number
	public function setPolicyRefNo($no){
		$this->policy_ref_no = $no;
	}

	// retrived policy refreance number
	public function getPolicyRefNo(){
		return (isset($this->policy_ref_no))? $this->policy_ref_no : 0;
	}

	// helper function
	public function changeDateFormate() {
		$car_helper = new CarHelper;
		if (!empty($this->user_data)) {
			$field_name = $car_helper->getFieldName('PROPOSER', 'USR_DOB');
			$this->user_data[$field_name] = (isset($this->user_data[$field_name])) ?
			$car_helper->getFormDate($this->user_data[$field_name]) : null;
		}
	}

	// mapping function
	// map sql column with form field
}

