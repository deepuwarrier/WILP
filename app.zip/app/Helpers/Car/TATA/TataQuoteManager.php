<?php
namespace App\Helpers\Car\TATA;

/**
 * 
 */
use App\Constants\Car_Constants;

class TataQuoteManager
{
	
	private $request_param = '{
								"functionality": "validatequote",
								"quote_type": "quick",
								"vehicle": {
									"quotation_no": "",
									"segment_code": "3",
									"segment_name": "Mid Size",
									"cc": "1498",
									"sc": "5",
									"sol_id": "1001",
									"lead_id": "",
									"mobile_no": "",
									"email_id": "",
									"emp_email_id": "",
									"customer_type": "Individual",
									"product_code": "3121",
									"product_name": "Private Car",
									"subproduct_code": "45",
									"subproduct_name": "Private Car",
									"subclass_code": "",
									"subclass_name": "",
									"covertype_code": "1",
									"covertype_name": "Package",
									"btype_code": "2",
									"btype_name": "Roll Over",
									"risk_startdate": "20180404",
									"risk_enddate": "20190403",
									"purchase_date": "20180312",
									"veh_age": "",
									"manf_year": "2018",
									"make_code": "158",
									"make_name": "HONDA",
									"model_code": "1023492",
									"model_name": "NEW JAZZ",
									"variant_code": "1023496",
									"variant_name": "1.5 V I DTEC",
									"model_parent_code": "1023492",
									"fuel_code": "",
									"fuel_name": "Diesel",
									"gvw": "",
									"age": "",
									"miscdtype_code": "",
									"bodytype_id": "",
									"idv": "",
									"revised_idv": "",
									"regno_1": "",
									"regno_2": "",
									"regno_3": "BT",
									"regno_4": "7878",
									"rto_loc_code": "AP-16",
									"rto_loc_name": "",
									"rtolocationgrpcd": "2",
									"rto_zone": "B",
									"rating_logic": "Campaign",
									"campaign_id": "",
									"fleet_id": "",
									"discount_perc": "",
									"pp_covertype_code": "1",
									"pp_covertype_name": "Package",
									"pp_enddate": "",
									"pp_claim_yn": "",
									"pp_prev_ncb": "",
									"pp_curr_ncb": "",
									"addon_plan_code": "P2",
									"addon_choice_code": "",
									"cust_name": "",
									"ab_cust_id": "",
									"ab_emp_id": "",
									"usr_name": "",
									"producer_code": "",
									"pup_check": "",
									"pos_panNo": "",
									"pos_aadharNo": "",
									"is_cust_JandK": "",
									"cust_pincode": "600096",
									"cust_gstin": "",
									"tenure": "1",
									"uw_discount": "",
									"Uw_DisDb": "",
									"uw_load": "",
									"uw_loading_discount": "",
									"uw_loading_discount_flag": "",
									"engine_no": "",
									"chasis_no": ""
								},
								"cover": {
									"C1": {
										"opted": "Y"
									},
									"C2": {
										"opted": "Y"
									},
									"C3": {
										"opted": "Y"
									},
									"C4": {
										"opted": "N",
										"SI": ""
									},
									"C5": {
										"opted": "N",
										"SI": ""
									},
									"C7": {
										"opted": "N",
										"SI": ""
									},
									"C8": {
										"opted": "N"
									},
									"C10": {
										"opted": "N",
										"SI": ""
									},
									"C11": {
										"opted": "N"
									},
									"C12": {
										"opted": "N"
									},
									"C15": {
										"opted": "N",
										"perc": ""
									},
									"C17": {
										"opted": "N",
										"SI": "",
										"persons": "0"
									},
									"C18": {
										"opted": "Y",
										"persons": "1"
									},
									"C45": {
										"opted": "N"
									},
									"C29": {
										"opted": "N"
									},
									"C47": {
										"opted": "N"
									},
									"C39": {
										"opted": "N"
									},
									"C38": {
										"opted": "N"
									},
									"C37": {
										"opted": "N"
									},
									"C44": {
										"opted": "N"
									},
									"C48": {
										"opted": "N",
										"SI": ""
									},
									"C49": {
										"opted": "N",
										"SI": ""
									},
									"C50": {
										"opted": "N",
										"SI": ""
									},
									"C51": {
										"opted": "N",
										"SI": ""
									},
									"C13": {
										"opted": "N"
									},
									"C14": {
										"opted": "N"
									},
									"C6": {
										"opted": "N",
										"SI": ""
									},
									"C35": {
										"opted": "N",
										"no_of_claims": "2",
										"Deductibles": "0"
									}
								}
							}';

	private $Sol_id = Car_Constants::TATA_SOL_ID; // Partner Id;
	
	public function __construct(){
		$this->setQuoteRequestData();
	}

	public function setQuoteRequestData(){
		$request = json_decode($this->request_param,true);
		$request['vehicle']['sol_id'] = $this->Sol_id;
		$this->request = $request;
	}

	public function getQuoteRequest(){	
		return $this->request;
	}
}
?>