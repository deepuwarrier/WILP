<?php
namespace App\Helpers\Car\UIIC;

use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use App\Be\Car as BE;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use Log;

class UIICProposalManager{

	public function __construct(){
		$this->refrel_col = "uiic_code";
		$this->refrel_variant_col = "lstdec_code";
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->type_of_finance = Car_Constants::TYPE_OF_FINANCE;
		$this->title = Car_Constants::TITLE;
		$this->master = array('NomineeRelationship');
		$this->cmp_paid_up = ['More than Rs. 25 Crores' => 'more than 25cr'
            , 'From Rs. 10 to 25 Crores' => '10cr-25cr'
            , 'Upto Rs. 10 Crores' => 'upto 10 cr'];
		$this->test = 0;
	}

	public function getPredefinedData($request_data){
		session(['request' => $request_data]);
		$carcfgobj = new CarConfig;
        $yor_select_start = $carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
		$date = Carbon::now();
        $requiredData = array('Insurer', 'GarageType', 'Financier');
		$return_data_field = ['variant_code','product_id','insurer_id','totalpremium','netPremium','session_id','trans_code','return_quote_url','policyStartDate','idv','policyExpiryDate','rto','price','claim'];
		foreach ($return_data_field as $value) {
			$return_data[$value] = $request_data[$value];	
		}
		$return_data['idv_opted'] = (isset($request_data['idv_opted']))?$request_data['idv_opted']:$request_data['idv'];
		$return_data['ncb'] = $request_data['new_ncb'];
		$return_data['pre_ncb'] = $request_data['ncb'];
		$return_data['year'] = (isset($request_data['year']))? $request_data['year'] : null;
		$return_data['sc'] = 5;
		$return_data['occupation'] = 0;
		if (isset($request_data['regDate']) && $request_data['regDate']) {
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_NEWBUSINESS;
			$return_data['regDate'] = $request_data['regDate'];
		} else {
			$return_data['prev_tab_title'] = Car_Constants::PREV_TAB_TEXT_ROLLOVER;
			$return_data['prev_text'] = Car_Constants::PREV_TEXT_ROLLOVER;
			$return_data['regDate'] = $request_data['car_registration_date'];
		}
		if (date('Y', strtotime($return_data['regDate'])) == $yor_select_start) {
			$return_data['typeOfBusiness'] = 'new_bussiness';
			$return_data['policyStartDate'] = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyStartDate'])));
		} else {
			$return_data['typeOfBusiness'] = 'rollover';
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $return_data['policyExpiryDate'])));
			$return_data['policyStartDate'] = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
		}
		$return_data['vehicleId'] = $this->getVehicleId($return_data['variant_code']);
		$return_data['refrel_col'] = $this->refrel_col;
		return $return_data;
	}

	public function genrateTransactionTable($data){
		$car_t_data = new CarTData;
    	$fields = ['trans_code'
				 ,'insurer_id'
				 ,'product_id'
				 ,'return_quote_url'
				 ,'totalpremium'
				 ,'netPremium'];
		foreach ($fields as $value) {
			$table[$value] = $data[$value];		 	
		}
		$car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
    }

    // map sql column with form field

	public function getQuoteFieldMap($map_for = null) {
		$fields = [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
			Car_Constants::CAR_T_QUOTELOG['OPTED_IDV'] => 'idv_opted',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
			Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	public function getProposalMap(){
	}

    public function getDbData($session_id) {
        $car_helper = new CarHelper;
        $this->field = $car_helper->getFieldMap();
        $user_data = CarTData::find($session_id);
        
        $this->user_data = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $this->field);
        $this->user_data['fullname'] = (isset($this->user_data['firstname']) && isset($this->user_data['lastname'])) ? $this->user_data['firstname'] . ' ' . $this->user_data['lastname'] : '';

        if(!$this->user_data['regno']){
            $car_lib = new CarLib;
            $this->user_data['regno'] = $car_lib->parseRegistrationNumber($user_data['car_rto']).'-';
            unset($car_lib);
            unset($user_data);
        }
            
    }

    public function getStateCity($product_id, $insurer_id) {
        $car_helper = new CarHelper;
        if (!Session::has($product_id . 'apiDataState')) {
            $state = $car_helper->getMasterData($this->refrel_col, 'State');
            if (!empty($state)) {
                $field_name = $car_helper->getFieldName('COMMUNICATION', 'USR_STATE_CODE');
                $state_id = (isset($this->user_data[$field_name])) ? $this->user_data[$field_name] : $state[0]['id'];
                $city = $car_helper->getMasterCity($this->refrel_col, 'City', $state_id);
                Session::put($product_id . 'apiDataState', ['state' => $state, 'city' => $city]);
                Session::save();
                return ['state' => $state, 'city' => $city];
            }
        }
        return Session::pull($product_id . 'apiDataState');
    }

    public function requiredData($product_id, $insurer_id) {
        $car_helper = new CarHelper;
        $this->required_master = Car_Constants::UI_MASTER;
        $response_data = array();
        $insurer_diffmaster = array('139', '132', '106');
        $master_for = array('VehicleBody', 'NomineeRelationship');
        if (!Session::has($product_id . 'apiData')) {
            $refrel_col = $this->refrel_col;
            foreach ($this->required_master as $value) {
                $result = $car_helper->getMasterData($refrel_col, $value);
                $response_data[strtolower($value)] = (!empty($result)) ? $result : [];
                if (isset($orignale_pro_id)) {
                    $product_id = $orignale_pro_id;
                    $orignale_pro_id = NULL;
                }
                $refrel_col = $this->refrel_col;
            }
            $financierDb = new M\Financier();
            $response_data['financier'] = $financierDb->getUIICFinancier();
            Session::put($product_id . 'apiData', $response_data);
            Session::save();
        }
        //dd(Session::pull($product_id . 'apiData'));
        return Session::pull($product_id . 'apiData');
    }

    public function changeDateFormate() {
        $car_helper = new CarHelper;
        if (!empty($this->user_data)) {
            $field_name = $car_helper->getFieldName('PROPOSER', 'USR_DOB');
            $this->user_data[$field_name] = (isset($this->user_data[$field_name])) ?
                    $car_helper->getFormDate($this->user_data[$field_name]) : null;
        }
    }

    public function getDbFormatDate($date) {
        return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
    }

    public function getInsuranceCompanyName($product_id) {
        $car_helper = new CarHelper;
       return $car_helper->getInsuranceCompanyName($product_id);
    }

    public function getVehicleId($variant_code) {
        $car_m_variant = new M\CarVariant;
        $ref_col = $this->refrel_variant_col;
        return $car_m_variant->getVehicleId($variant_code, $ref_col)->$ref_col;
    }

       public function parsePaymentRequest($amount,$trans_code) {
        $car_helper = new CarHelper;
        $requestValue = ['MerchantID' => 'UIIINSTINS'
                        , 'CustomerID' => $trans_code

            , 'TxnAmount' => $amount
            , 'CurrencyType' => 'INR'
            , 'TypeField1' => 'R'
            , 'SecurityID' => 'uiiinstins'
            , 'TypeField2' => 'F'
            , 'txtadditional1' => 'PC'
            , 'txtadditional2' => 'PRD'
            , 'txtadditional3' => 'NA'
            , 'txtadditional4' => 'NA'
            , 'txtadditional5' => 'NA'
            , ' txtadditional6' => 'NA'
            , 'txtadditional7' => 'NA'
            , 'RU' =>  url('/').'/car-insurance/uiic/payment/status' //'https://www.instainsure.com/car-insurance/unitedindia/payment/status'
        ];

        $payentRequest = ['MerchantID', 'CustomerID', 'NA', 'TxnAmount', 'NA', 'NA', 'NA', 'CurrencyType', 'NA'
            , 'TypeField1', 'SecurityID', 'NA', 'NA', 'TypeField2', 'txtadditional1', 'txtadditional2', 'txtadditional3', 'txtadditional4', 'txtadditional5', ' txtadditional6', 'txtadditional7', 'RU'];

        foreach ($payentRequest as $key => $value)
            if (isset($requestValue[$value]))
                $payentRequest[$key] = $requestValue[$value];

        $this->payment_req = implode('|', $payentRequest);
        $this->payment_req .= '|' . $this->payment_hash($this->payment_req);
    }

    private function payment_hash($str) {
        $hash_txt = hash_hmac('sha256', $str, 'Sf5dEqfQPlEJ');
        return strtoupper($hash_txt);
    }

    public function sendPolicyInfo($data) {  
        $response = null;
        try {
            // $atservices_wsdl = "http://portal.uiic.in/uat/UGenericServiceUAT/UInstaService?wsdl"; // For UAT
            $atservices_wsdl = "https://portal.uiic.in/uiic/UGenericService/UInstaService?wsdl"; // For Production
            $soapclient = new \SoapClient($atservices_wsdl, [
                'trace' => true,
                'connection_timeout' => 50000,
                'cache_wsdl' => WSDL_CACHE_BOTH,
                'keep_alive' => false,
            ]);
            $params = array('application' => 'INSTAINS', 'userid' => 'INSTAINS', 'password' => 'uiic', 'productCode' => '3111', 'subproductCode' => '18', 'proposalXml' => $data);
            $response = $soapclient->policyInfoOffXml($params);
        } catch (\Exception $e) {
            $e->getMessage();
        } finally {
            return $response;
        }
    }

    public function parse_pgresp($pgstr) {
        try {
            $pg_resp_arr = explode("|", $pgstr);
            return ["MerchantID" => $pg_resp_arr[0],
                "CustomerID" => $pg_resp_arr[1],
                "TxnReferenceNo" => $pg_resp_arr[2],
                "BankReferenceNo" => $pg_resp_arr[3],
                "TxnAmount" => $pg_resp_arr[4],
                "BankID" => $pg_resp_arr[5],
                "BankMerchantID" => $pg_resp_arr[6],
                "TxnType" => $pg_resp_arr[7],
                "CurrencyName" => $pg_resp_arr[8],
                "ItemCode" => $pg_resp_arr[9],
                "SecurityType" => $pg_resp_arr[10],
                "SecurityID" => $pg_resp_arr[11],
                "SecurityPassword" => $pg_resp_arr[12],
                "TxnDate" => $pg_resp_arr[13],
                "AuthStatus" => $pg_resp_arr[14],
                "SettlementType" => $pg_resp_arr[15],
                "AdditionalInfo1" => $pg_resp_arr[16],
                "AdditionalInfo2" => $pg_resp_arr[17],
                "AdditionalInfo3" => $pg_resp_arr[18],
                "AdditionalInf o4" => $pg_resp_arr[19],
                "AdditionalInfo5" => $pg_resp_arr[20],
                "AdditionalInfo6" => $pg_resp_arr[21],
                "AdditionalInfo7" => $pg_resp_arr[22],
                "ErrorStatus" => $pg_resp_arr[23],
                "ErrorDescription" => $pg_resp_arr[24],
                "CheckSum" => $pg_resp_arr[25]];
        } catch (\Exception $ex) {
            return null;
        }
    }

    public function submit_policy($suid, $pgresp) {
        $car_helper = new CarHelper;
        $this->uiic_req = new UIICRequest($this);
        $this->uiic_req->setData($suid);
        $req['HEADER'] = (array) $this->uiic_req->data;
        $req['HEADER']['TXT_OEM_TRANSACTION_ID'] = $pgresp['TxnReferenceNo'];
        $req['HEADER']['TXT_MERCHANT_ID'] = $pgresp['MerchantID'];
        $req['HEADER']['TXT_BANK_CODE'] = $pgresp['BankID'];
        $req['HEADER']['NUM_UTR_PAYMENT_AMOUNT'] = $req['HEADER']['CUR_DEALER_GROSS_PREM'];
        $req['HEADER']['TXT_OEM_DEALER_CODE'] = Car_Constants::UIIC_OEM_DEALER_CODE;
        $req['HEADER']['TXT_UTR_NUMBER'] = $pgresp['BankMerchantID'];
        $req['HEADER']['TXT_BANK_NAME'] = '';
        $xml = $car_helper->genrateXml('<ROOT/>', $req);
        $web_req = $xml->asXML();
        Log::info('Car UIIC Proposal Request : - '.$suid.' - ' . $web_req);
        $response = $this->sendPolicyInfo($web_req);
        $policy_resp = (isset($response->return)) ? $response->return : $response;
        Log::info('Car UIIC Proposal Response : - '.$suid.' - ' .json_encode($policy_resp));
        return $policy_resp;
    }

}
?>

