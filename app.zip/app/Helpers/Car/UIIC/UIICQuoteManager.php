<?php

namespace App\Helpers\Car\UIIC;

use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use App\Be\Car as BE;
use Log;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;

class UIICQuoteManager {
    public function __construct($trans_code) {
        $car_helper = new CarHelper;
        $this->premium_breakup_fromat = ['basic' => ['od','tp','ll', 'pa']
            , 'addon' => ['rti', 'zerodep','papass']
            , 'discounts' => ['ncbbenefit', 'od']
            , 'totalpremium'
            , 'serviceTax'
            , 'netPremium'];

        $this->trans_code = $trans_code;
        $user_data = CarTData::find($this->trans_code);  
        
        $field = $car_helper->getQuoteFieldMap();
        $car_details = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $field);
        // car variant
        $carvariant = new M\CarVariant; 
        $carvariant = $carvariant->get_car_details($user_data->car_variant);
        $carvariant['seating_capacity'];
        $carvariant['vehicle_cc'];
        
        $car_m_rto = new M\CarRto;
        $rto_zone = $car_m_rto->getRtoZone($user_data->car_rto); 
        
        $stateDb = new M\MasterState();
        $cust_gst_code = $stateDb->getGSTCode($car_details['state']);
    
        $this->refrel_variant_col = "uiic_code";
        $this->car_details = $car_details;
        
        $data = ['rto_zone'=>$rto_zone,
                'vehicle_cc'=>$carvariant['vehicle_cc'],
                'seating_capacity'=>$carvariant['seating_capacity'],
                'cust_gst_code'=>$cust_gst_code,
                'price'=>$car_details['price'],
                'policy_start_date'=>$car_details['policyStartDate'],
                'registartion_date'=>$car_details['car_registration_date'],
                'new_ncb'=>$car_details['new_ncb'],
                'type_of_business'=>$car_details['typeOfBusiness'],
                'policy_type_selection' => $car_details['policy_type_selection']];

        $this->quote_be = new BE\UIICQuoteBe();
        $this->quote_be->setBasicDetails($data);
    }
    
    public function pre_quote_check(){
        $status = true;
        $state_code = $this->car_details['rto'];
        $state_code = substr($state_code,0,2);
        if($state_code != 'KA')
            $status = false;
        unset($state_code);
        return $status;
    }
    
    public function getQuote() {
        $this->premium = $this->quote_be->enable['premium'];
        $this->discount = $this->quote_be->enable['discount'];
        //$this->disableAddon('ZERODEP');
        $this->quote_be->getTotalPremium();
        $this->data = $this->quote_be->data;
        $all_premium_is_available = true;
        foreach ($this->premium as $key => $value) {
            if ($value) {
                if(in_array($key,['EA','NEA']))
                    continue;

                $premium_key = $this->premiumIsAvailabel($key);
                
                if (!$premium_key){
                    $all_premium_is_available = false;
                    //trigger_error($key.' is not availabel');
                }
                    
                if (!isset($this->quote_be->data[$premium_key]) || !$this->quote_be->data[$premium_key]){
                    $all_premium_is_available = false;
                    //trigger_error($premium_key.' is not availabel');
                }   
            }
        }

        if (!$all_premium_is_available)
            return false;
        
        $pb_data =  new PremiumBreakupData;
        $pb_data = $this->parse_premium_breakup_data($pb_data,$this->quote_be->data);
        $pb = new PremiumBreakup();             
        $pb->setPbDatat($pb_data);
        $PremiumBreakup = $pb->genratePremiumBreakup();

        $vehicle_idv = $this->data['vehicle_idv'];

        
        $this->quote = ['totalpremium' => $pb_data->getTotalPremium()
            ,'pb_data'=>$pb_data
            , 'insurer_id' => 'uiic'
            , 'product_id' => 'uiic'
            ,'insurerroute' => 'uiic'
            ,'trans_code' => $this->trans_code
            , 'idv_received' => $vehicle_idv
            , 'netPremium' => $pb_data->getGrossPremium()
            , 'insurerName' => 'United India Insurance GI'
            , 'serviceTax' => $pb_data->getServiceTax()
            , 'premiumBreakup' => $PremiumBreakup];
            
        unset($this->premium_breakup_fromat);
        unset($this->premium_breakup);
        unset($this->data['car_details']);
        unset($this->premium);
        unset($this->discount);
        unset($this->data);
        unset($pb);
        
        return true;
    }

    public function parse_premium_breakup_data($pb_data,$quote_response){
        $pb_data->setGrossPremium($quote_response['premium']);
        $pb_data->setTotalPremium($quote_response['total_premium']);
        $pb_data->setServiceTax($quote_response['service_tax']);
        $pb_data->setOdPremium($quote_response['od_premium']);
        $pb_data->setLlPremium($quote_response["driver_cover_premium"]);
        $pb_data->setTpPremium($quote_response['tp_premium']);
        $pb_data->setPaPremium($quote_response['PAOD_premium']);
        $pb_data->setRtiPremium(round($quote_response['rti_premium']));
        $pb_data->setZerodepPremium(round($quote_response['zerodep_premium']));
        $pb_data->setPapassPremium(round($quote_response['pa_cover_premium']));
        $pb_data->setNcbDiscount($quote_response['ncb_discount']); 
        $pb_data->setOdDiscount($quote_response['od_discount']); 
        return $pb_data;
    }

    public function premiumIsAvailabel($key) {
        $key = strtolower($key);
        $value_key = 0;

        // check key exist in basic premium
        if (!$value_key) {
            $basic = $this->getValueMappingKeys('basic');
            if (is_array($basic) && isset($basic[$key]))
                $value_key = $basic[$key];
        }

        // check key exist in addon premium
        if (!$value_key) {
            $addon = $this->getValueMappingKeys('addon');
            if (is_array($addon) && isset($addon[$key]))
                $value_key = $addon[$key];
        }


        if ($value_key)
            return $value_key;
        else
            Log::error($value_key . 'Key is not belongs to Premium Breakup');

        return false;
    }

    private function getValueMappingKeys($values_for = null) {
        $value_keys = ['basic' => ['od' => 'od_premium'
                , 'll' => 'driver_cover_premium'
                , 'pa' => 'PAOD_premium'
                , 'tp' => 'tp_premium']
            , 'addon' => ['zerodep' => 'zerodep_premium'
                         , 'rti' => 'rti_premium'
                         ,'papass' => 'pa_cover_premium']
            , 'discounts' => ['ncbbenefit' => 'ncb_discount'
                , 'od' => 'od_discount']
            , 'totalpremium' => 'total_premium'
            , 'serviceTax' => 'service_tax'
            , 'netPremium' => 'premium'];

        if (isset($values_for)) {
            if (is_array($values_for)) {
                $value_to_return = $value_keys;
                foreach ($values_for as $value) {
                    if (isset($value_to_return[$value]))
                        $value_to_return = $value_to_return[$value];
                    else
                        return false;
                }
                return $value_to_return;
            }else
            if (isset($value_keys[$values_for]))
                return $value_keys[$values_for];
            else
                return false;
        }else {
            return $value_keys;
        }
    }

    public function setAddons($covers) {
        $chks = isset($covers)? $covers : Car_Constants::DEFAULT_COVER_SELECTED;
        $addons = explode(",", $chks);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        if (property_exists($this, 'quote_be'))
            foreach ($addons as $addon_key) {
                $this->quote_be->enableAddon($addon_key);
            } else
            Log::notice("Uiic Quote Be is Not Init");
    }

    public function setTransCode($trans_code){
        $this->trans_code = $trans_code;
    }

    public function enableAddons($key){
        $this->quote_be->enableAddon($key);
    }

    public function disableAddon($key){
        $this->quote_be->disableAddon($key);
    }
    
    public function setIdv($key,$price){
        $this->quote_be->$key =  $price;  
    }

    public function mapAddonKey($key) {
        $addon_mapper = [];
    }

}

?>
