<?php

namespace App\Helpers\Car\UIIC;

use App\Libraries\CarLib;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use App\Models\Car as M;
use App\Be\Car as BE;
use Illuminate\Support\Facades\Log;

class UIICQuoteManager {

    public function __construct() {
        $this->premium_breakup_fromat = ['basic' => ['od','tp','ll', 'pa']
            , 'addon' => ['rti', 'zerodep','papass']
            , 'discounts' => ['ncbbenefit', 'od']
            , 'totalpremium'
            , 'serviceTax'
            , 'netPremium'];

        $test = 0;
        if ($test) {
            $car_details = '{
                "make_code": "IMK014",
                "model_code": "IM0087",
                "variant_code": "IV000834",
                "state": "14",
                "make_name": "Maruti Suzuki",
                "model_name": "Swift DZire",
                "fuel": "Petrol",
                "variant_name": "LXI",
                "ncb": 0,
                "rto": "MH11",
                "rto_zone": "B",
                "claim": "N",
                "vehicle_cc": "1298",
                "typeOfBusiness": "Rollover",
                "policyStartDate": "2017-07-30",
                "policyExpiryDate": "2017-07-29",
                "car_registration_date": "2016-07-31",
                "vehicleAge": 1,
                "ex_showroom_car_price": 536370,
                "price": 536370,
                "cov": "#,#,#,",
                "idv": 455915,
                "new_ncb": 20,
                "year": 2016,
                "car_regis_min": "01/01/2016",
                "car_regis_max": "31/12/2016",
                "session_id": "P9vLZ2LRfUpNIuQMC7X2SMYkWYB1Tb8VC7vmFq4R"
              }';

            $this->car_details = json_decode($car_details, true);
        } else {
            $session_id = CarHelper::getSuid();
            $this->car_details = CarHelper::getCarDetailsSessionValue($session_id);
        }
        $this->refrel_variant_col = "uiic_code";
        $this->quote_be = new BE\UIICQuoteBe($this->car_details);
    }

    public function getQuote() {
        $this->premium = $this->quote_be->enable['premium'];
        $this->discount = $this->quote_be->enable['discount'];
        //$this->disableAddon('ZERODEP');
        $this->quote_be->getTotalPremium();
        $this->data = $this->quote_be->data;
        $all_premium_is_available = true;
        foreach ($this->premium as $key => $value) {
            if ($value) {
                if(in_array($key,['EA','NEA']))
                    continue;

                $premium_key = $this->premiumIsAvailabel($key);
                
                if (!$premium_key){
                    $all_premium_is_available = false;
                    //trigger_error($key.' is not availabel');
                }
                    
                if (!isset($this->quote_be->data[$premium_key]) || !$this->quote_be->data[$premium_key]){
                    $all_premium_is_available = false;
                    //trigger_error($premium_key.' is not availabel');
                }   
            }
        }

        if (!$all_premium_is_available)
            return false;
        
        $this->getPremiumBreakup();
        $this->quote = ['totalpremium' => $this->data['total_premium']
            , 'insurer_id' => 'uiic'
            , 'product_id' => 'uiic'
            ,'insurerroute' => 'uiic'
            , 'idv_received' => $this->data['vehicle_idv']
            , 'netPremium' => $this->data['premium']
            , 'insurerName' => 'United India Insurance GI'
            , 'serviceTax' => $this->data['service_tax']
            , 'premiumBreakup' => $this->premium_breakup];
            
        // unset($this->premium_breakup_fromat);
        // unset($this->values);
        // unset($this->premium_breakup);
        // unset($this->quote_be);
        // unset($this->data['car_details']);
        return true;
    }

    private function getPremiumBreakup() {
        $this->premium_breakup = [];
        $addon_values = [];
        $display_name = Car_Constants::DISPLAY_NAME;
        $this->getValues();
        foreach ($this->premium_breakup_fromat as $first_key => $values) {
            $price_keys = ['basic' => '_basic_price', 'addon' => '_addon_price', 'discounts' => '_discount_price'];
            if (is_array($values))
                foreach ($values as $second_key) {
                    if (isset($this->values[$first_key][$second_key]))
                        $this->premium_breakup[$first_key][$second_key . $price_keys[$first_key]] = ['displayName' => $display_name[$first_key][$second_key],
                                    'basic_premium' => $this->values[$first_key][$second_key]];
                } else {
                $first_key = $values;
                if (isset($this->values[$first_key]))
                    $this->premium_breakup[$first_key] = ['displayName' => $display_name[$first_key],
                                'basic_premium' => $this->values[$first_key]];
            }
        }
    }

    private function getValues() {
        $keys = $this->getValueMappingKeys();
        foreach ($this->premium_breakup_fromat as $first_key => $values) {
            if (is_array($values)) {
                foreach ($values as $second_key) {
                    if (isset($keys[$first_key][$second_key]) && isset($this->data[$keys[$first_key][$second_key]]) && $this->data[$keys[$first_key][$second_key]])
                        $this->values[$first_key][$second_key] = $this->data[$keys[$first_key][$second_key]];
                }
            }else {
                $first_key = $values;
                if (isset($keys[$values]) && isset($this->data[$keys[$first_key]]) && $this->data[$keys[$first_key]])
                    $this->values[$first_key] = $this->data[$keys[$first_key]];
                unset($first_key);
            }
        }
    }

    public function premiumIsAvailabel($key) {
        $key = strtolower($key);
        $value_key = 0;

        // check key exist in basic premium
        if (!$value_key) {
            $basic = $this->getValueMappingKeys('basic');
            if (is_array($basic) && isset($basic[$key]))
                $value_key = $basic[$key];
        }

        // check key exist in addon premium
        if (!$value_key) {
            $addon = $this->getValueMappingKeys('addon');
            if (is_array($addon) && isset($addon[$key]))
                $value_key = $addon[$key];
        }


        if ($value_key)
            return $value_key;
        else
            Log::error($value_key . 'Key is not belongs to Premium Breakup');

        return false;
    }

    private function getValueMappingKeys($values_for = null) {
        $value_keys = ['basic' => ['od' => 'od_premium'
                , 'll' => 'driver_cover_premium'
                , 'pa' => 'PAOD_premium'
                , 'tp' => 'tp_premium']
            , 'addon' => ['zerodep' => 'zerodep_premium'
                         , 'rti' => 'rti_premium'
                         ,'papass' => 'pa_cover_premium']
            , 'discounts' => ['ncbbenefit' => 'ncb_discount'
                , 'od' => 'od_discount']
            , 'totalpremium' => 'total_premium'
            , 'serviceTax' => 'service_tax'
            , 'netPremium' => 'premium'];

        if (isset($values_for)) {
            if (is_array($values_for)) {
                $value_to_return = $value_keys;
                foreach ($values_for as $value) {
                    if (isset($value_to_return[$value]))
                        $value_to_return = $value_to_return[$value];
                    else
                        return false;
                }
                return $value_to_return;
            }else
            if (isset($value_keys[$values_for]))
                return $value_keys[$values_for];
            else
                return false;
        }else {
            return $value_keys;
        }
    }

    public function setAddons($addons) {
        $addons = explode(",", $addons);
        unset($addons[count($addons) - 1]);
        unset($addons[0]);
        unset($addons[1]);
        unset($addons[2]);
        if (property_exists($this, 'quote_be'))
            foreach ($addons as $addon_key) {
                $this->quote_be->enableAddon($addon_key);
            } else
            Log::notice("Uiic Quote Be is Not Init");
    }

    public function enableAddons($key){
        $this->quote_be->enableAddon($key);
    }

    public function disableAddon($key){
        $this->quote_be->disableAddon($key);
    }
    
    public function setIdv($key,$price){
        $this->quote_be->$key =  $price;  
    }

    public function mapAddonKey($key) {
        $addon_mapper = [];
    }

}

?>