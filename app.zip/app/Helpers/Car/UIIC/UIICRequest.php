<?php
namespace App\Helpers\Car\UIIC;

use App\Libraries\CarLib;
use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use App\Be\Common\GstBe;
use App\Models\Car\MasterInsurer;
use App\Models\Car\MasterNomineeRelationship;
use App\Models\Car\CarRto;
use App\Models\Car\CarVariant;
use App\Models\Car\MasterVehicleBody;
use App\Models\Car\Financier;

class UIICRequest {

    public function __construct(UIICProposalManager $manager){
        $this->manager = $manager;
    }

    public function setData($trans_code){
        $car_helper = new CarHelper;
        $user_data = CarTData::find($trans_code);
        if(!isset($this->quote_manger)){
            $this->quote_manger = new UIICQuoteManager($trans_code);
            $this->quote_manger->setAddons($user_data->covers_selected);
        }
        $this->genrate_proposal_request($trans_code,$user_data);
        $this->setPremium($user_data);
    }

    public function setPolicyData($user_data){ 
        $car_helper = new CarHelper;
        if(!isset($this->quote_manger)){
            $this->quote_manger = new UIICQuoteManager($user_data->trans_code);
            $this->quote_manger->setAddons($user_data->covers_selected);
        }
        $this->genrate_proposal_request($user_data->trans_code,$user_data);
        $this->setPremium($user_data);
    }

    public function genrate_proposal_request($trans_code,$user_data){
        $car_lib = new CarLib;
    	$req = new Data();
        	$req = $this->setProposerDetails($req,$user_data);
        	$req = $this->setCarDetails($req,$user_data);
        	$req = $this->setNominneeDetails($req,$user_data);
        	$req = $this->getElectReq($req,$user_data->veh_electricle);
            $req = $this->getNonElectReq($req,$user_data->veh_no_electricle);
            $req = $this->addFinacier($req,$user_data);
            $req->NUM_VEHICLE_TYPE_INTL_CODE = Car_Constants::UIIC_SUBPRODUCT_CODE;
            $req->TXT_GC_PRODUCT_CODE = Car_Constants::UIIC_PRODUCT_CODE;
    	if($user_data->type_of_business == 'Rollover'){
                $req->NUM_BUSINESS_CODE = 'Roll Over';
                $req->DAT_DATE_OF_EXPIRY_OF_POLICY = $this->dbToPD($user_data->policy_expiry_date
                                ,"+1 year");
                $req->DAT_DATE_OF_ISSUE_OF_POLICY = $this->dbToPD($user_data->policy_expiry_date
                                ,"+1 day");
                $req = $this->setPrevInsurerDetails($req,$user_data);
    	}else{
                $req->NUM_BUSINESS_CODE = 'New Business';
                $req->DAT_DATE_OF_ISSUE_OF_POLICY = $this->dbToPD($user_data->policy_start_date);
                $req->DAT_DATE_OF_EXPIRY_OF_POLICY = $this->dbToPD($user_data->policy_start_date,"+3 year");
                $req->CUR_BONUS_MALUS_PERCENT = $user_data->new_ncb;
                $req->YN_CLAIM = 'no';
    	}
        $req->NUM_LL1 = 1;
        $req->NUM_LL2 = '';
        $req->NUM_LL3 = '';

        $req->DAT_PROPOSAL_DATE =  date('d/m/Y');
        $req->DAT_UTR_DATE = $req->DAT_PROPOSAL_DATE;
        $date = explode("/",$req->DAT_DATE_OF_ISSUE_OF_POLICY);
        $req->NUM_POLICY_YEAR = $date[2];
        $req->DAT_HOURS_EFFECTIVE_FROM = '00:00';
        if($user_data->veh_reg_no && $req->NUM_BUSINESS_CODE != 'New Business'){
            $vehicle_reg = strtoupper($user_data->veh_reg_no);
            $req = $this->addRegReq($req,$vehicle_reg);			 

        }else
            $req = $this->addRegReq($req);
		
    	if ($req->NUM_CLIENT_TYPE == 'C') 
            $req->NUM_PAID_UP_CAPITAL = '1';
    	else
            $req->TXT_AADHAR_NUMBER = $user_data->usr_aadharno;
        $req->NUM_PIN_CODE = $user_data->usr_pincode;
 
        $this->data = $req;
        $this->setPremium($user_data);
    }

    private function dbToPD($date,$man = null){
        $date = strtotime($date);
        if($man)
            $date = strtotime($man,$date);
        return date('d/m/Y',$date);
    }

    public function addFinacier($req,$user_data){
        if(!isset($user_data->veh_financierName))
            return $req;

        $financierDb = new Financier();
        $financierDb = $financierDb->getUIICData($user_data->veh_financierName);

        $req->NUM_FINANCIER_NAME_1 = $financierDb->financer_name;
        $req->TXT_FIN_ACCOUNT_CODE_1 = $financierDb->uiic_code;
        $req->TXT_FIN_BRANCH_NAME_1 = $financierDb->financier_branch;
        $req->TXT_FINANCIER_BRANCH_ADDRESS1 = $financierDb->financier_addr;
        $req->NUM_AGREEMENT_NAME_1 = $user_data->veh_type_of_finance;
        return $req;
    }

    private function setProposerDetails($req,$user_data){
        if(strtoupper($user_data->usr_type) == 'O')
            $req->NUM_CLIENT_TYPE = 'C';
        else 
            $req->NUM_CLIENT_TYPE = 'I';
        
        if ($req->NUM_CLIENT_TYPE == 'C') {
            $req->TXT_GENDER = 'Male';
            $req->TXT_TITLE = 'M/s';
            $req->TXT_DOB = '';
            $req->TXT_NAME_OF_INSURED = $user_data->usr_companyname;
        }else{
            $req->TXT_GENDER = ($user_data->usr_gender == 'M')? 'Male' : 'Female';
            $req->TXT_TITLE = ('Male' == $req->TXT_GENDER) ? 'Mr' : 'Ms';
            $req->TXT_DOB = $this->dbToPD($user_data->usr_dob);
            $req->TXT_NAME_OF_INSURED = $user_data->usr_firstname.' '.$user_data->usr_lastname;
        }
        $req->TXT_TELEPHONE = $user_data->usr_mobile;
        $req->TXT_EMAIL_ADDRESS = $user_data->usr_email;
        $req->TXT_MOBILE = $user_data->usr_mobile;
        $req->MEM_ADDRESS_OF_INSURED = $user_data->usr_houseno.' , '.$user_data->usr_street.' , '.$user_data->usr_locality;
        //$req->TXT_OCCUPATION = $user_data->usr_occupation;
        $req->TXT_AADHAR_NUMBER = $user_data->usr_aadharno;	
        return $req;
    }

    private function setCarDetails($req,$user_data){
        $req->TXT_NAME_OF_MANUFACTURER = $user_data->make_name;
        $req->TXT_OTHER_MAKE = $user_data->model_name;
        $req->TXT_VARIANT = $user_data->variant_name;
        $req->NUM_YEAR_OF_MANUFACTURE = $user_data->veh_yom;
        $req->TXT_FUEL = $user_data->car_fuel;
        $bodyTypeDb = new MasterVehicleBody();
        $req->TXT_TYPE_BODY = $bodyTypeDb->getName($user_data->veh_bodytype);
        $req->TXT_VAHICLE_COLOR = strtoupper($user_data->veh_color);
        $req->TXT_ENGINE_NUMBER = $user_data->veh_eng_no;
        $req->TXT_CHASSIS_NUMBER = $user_data->veh_chassisno;
        
        if($user_data->idv_opted)
            $req->NUM_IEV_BASE_VALUE = $user_data->idv_opted;
        else
            $req->NUM_IEV_BASE_VALUE = $user_data->idv_calculated;
            

        $rtoDb = new CarRto();
        $rtoDb = $rtoDb->getData($user_data->car_rto,['rto','zone','uiic_code']);
        $req->TXT_VEHICLE_ZONE = $rtoDb->zone;
                $req->TXT_RTA_DESC = trim($rtoDb->uiic_code);	


        $variantDb =  new CarVariant();
    	$variantDb = $variantDb->getData($user_data->car_variant,['seat_capacity','weight','variant_cc']);
        $req->NUM_CUBIC_CAPACITY = $variantDb->variant_cc;
    	$req->NUM_RGSTRD_CARRYING_CAPACITY = $variantDb->seat_capacity;
    	$req->NUM_RGSTRD_SEATING_CAPACITY = $variantDb->seat_capacity;
        $req->NUM_RGSTRD_GROSS_VEH_WEIGHT = $variantDb->weight;
    	$req->DAT_DATE_OF_REGISTRATION = $this->dbToPD($user_data->car_registration_date);
        $car_reg_date = explode('/',$req->DAT_DATE_OF_REGISTRATION);
        $req->NUM_MONTH_OF_MANUFACTURE =  $car_reg_date[1];
        $req->NUM_YEAR_OF_MANUFACTURE = $car_reg_date[2];
        $req->NUM_TPPD_AMOUNT = '750000';
        $req->NUM_PA_NAMED_NUMBER = '0';
	return $req;
    }

    private function setNominneeDetails($req,$user_data){
        $req->TXT_NAME_OF_NOMINEE = $user_data->nominee_name;
        $relationDb = new MasterNomineeRelationship();
        $req->TXT_RELATION_WITH_NOMINEE = $relationDb->getCode('fgi',$user_data->nominee_rel);
        return $req;
    }

    private function setPrevInsurerDetails($req,$user_data){
        $req->DAT_PREV_POLICY_EXPIRY_DATE = $this->dbToPD($user_data->policy_expiry_date);
        $prePolicyStartdate = strtotime('- 1 year', strtotime(str_replace('/','-',$req->DAT_DATE_OF_EXPIRY_OF_POLICY)));
        $req->TXT_PREV_POL_EFFECTIVE_DATE = $user_data->getPrevPolicyStartDate('d/m/Y');
        $inusrerDb = new MasterInsurer();
        $req->NUM_POLICY_NUMBER = $user_data->prev_policyno;
        $req->TXT_PREV_INSURER_CODE = $inusrerDb->getCode($this->manager->refrel_col,$user_data->prev_insurance);
        $req->TXT_PREVIOUS_INSURER = $inusrerDb->getName($user_data->prev_insurance);
        $req->CUR_BONUS_MALUS_PERCENT = $user_data->new_ncb;
        $req->YN_CLAIM = $user_data->claim;
        if($user_data->claim == 'N'){
                $req->TXT_NCB_FLAG = 'Y';
                $req->TXT_YN_NCB_SUBMIT = 'Y';
        }else{
            $req->TXT_NCB_FLAG = 'N';
                $req->TXT_YN_NCB_SUBMIT = 'N';
        }
        return $req;
    }

    private function getElectReq($req,$val){
    	if($val){
            $req->NUM_IEV_ELEC_ACC_VALUE =  $val;
            $req->ELECTRICALACCESSORIESPREM = '';
            $req->TXT_ELEC_DESC = 'elec';				
    	}
    	return $req;
    }

    private function getNonElectReq($req,$val){
    	if($val){
            $req->NUM_IEV_NON_ELEC_ACC_VALUE =  $val;
            $req->NONELECTRICALACCESSORIESPREM = '';
            $req->TXT_NON_ELEC_DESC = 'nonelec';				
    	}
    	return $req;
    }

    private function addRegReq($req,$vehicle_reg = null){
        if($vehicle_reg){
            if(!is_array($vehicle_reg))
                $vehicle_reg = explode('-',$vehicle_reg);
            foreach ($vehicle_reg as $key => $value) 
                    $req->{'TXT_REGISTRATION_NUMBER_'.($key+1)}	= $value;
        }
        return $req;
    }

    public function setPremium($user_data){
        // check elect ass is selected
        if(isset($this->data->NUM_IEV_ELEC_ACC_VALUE) && $this->data->NUM_IEV_ELEC_ACC_VALUE != ''){
            $this->quote_manger->enableAddons('EA');
            $this->quote_manger->setIdv('elect_ass_idv',$this->data->NUM_IEV_ELEC_ACC_VALUE);
        }

        // check nonelect ass is selected
        if(isset($this->data->NUM_IEV_NON_ELEC_ACC_VALUE) && $this->data->NUM_IEV_NON_ELEC_ACC_VALUE != ''){
            $this->quote_manger->enableAddons('NEA');
            $this->quote_manger->setIdv('nonelect_ass_idv',$this->data->NUM_IEV_NON_ELEC_ACC_VALUE);
        }

        // disable "PA ADDON" on select owner type 
        if ($this->data->NUM_CLIENT_TYPE === 'C') 
                $this->quote_manger->disableAddon('PA');
        
        //genrate values 
        $this->quote_manger->getQuote();
        
        $data = (Object)$this->quote_manger->quote_be->data;

        if(isset($data->ncb_discount))
                $this->data->NOCLAIMBONUSDISCOUNT = $data->ncb_discount;
        
        $this->RTIAddon($data);
        $this->ZeroDepAddon($data);
        $this->PAAddon($data);
        $this->serviceTax($data,$user_data);
        
        $this->data->CUR_DEALER_NET_OD_PREM = $data->totoal_od_premium+$data->totoal_addOn_premium;
        $this->data->CUR_DEALER_NET_TP_PREM = $data->totoal_tp_premium;
        $this->data->CUR_DEALER_SERVICE_TAX = $data->service_tax;
        $this->data->CUR_DEALER_GROSS_PREM = $data->total_premium; 
        $this->data->COMPULSARY_PA_PREMIUM = $data->PAOD_premium;  // Added by sreehari

        if($user_data->usr_type == 'C')
            $this->data->TXT_GSTIN_NUMBER = $user_data->gstin;
        
        if($data->ea_premium)
            $this->data->ELECTRICALACCESSORIESPREM = $data->ea_premium;

        if($data->nea_premium)
            $this->data->NONELECTRICALACCESSORIESPREM = $data->nea_premium;

        $this->data->BasicODPremium = $data->od_premium;
        $this->data->ODDiscount = $data->od_discount;
        $this->data->TotalAddOnPremium = $data->totoal_addOn_premium;
        $this->data->PAODPremium = $data->PAOD_premium;
        $this->data->BasicTPPremium = $data->tp_premium;
                $this->data->PassengerCoverPremium = '';
    }
    
    private function serviceTax($data,$user_data){
        $stateDb = new M\MasterState();
        $cust_gst_code = $stateDb->getGSTCode($user_data->car_state);
        
        $this->data->CUST_GST_STATE_CODE = $cust_gst_code;
        $this->data->INS_OFF_GST_STATE_CODE = Car_Constants::UIIC_GST_CODE;

        if($this->data->INS_OFF_GST_STATE_CODE != $this->data->CUST_GST_STATE_CODE){
            $this->data->OEM_CUR_IGST_VALUE =  $data->service_tax;
            $this->data->OEM_NUM_IGST_RATE = 18;	
        }else{
            $tax = round($data->service_tax/2);
            $this->data->OEM_CUR_CGST_VALUE = $tax;
            $this->data->OEM_NUM_CGST_RATE = 9;
            $this->data->OEM_CUR_SGST_VALUE = $tax;
            $this->data->OEM_NUM_SGST_RATE = 9;
        }
    }

    // ADDON
    private function PAAddon($data){
        if($data->pa_cover_premium){
                        $this->data->NUM_PA_UNNAMED_NUMBER =  $this->data->NUM_RGSTRD_SEATING_CAPACITY;
            $this->data->NUM_PA_UNNAMED_AMOUNT =  '100000';

        }
    }
    
    private function ZeroDepAddon($data){
        if($data->zerodep_premium)
            $this->data->YN_NIL_DEPR_WITHOUT_EXCESS = -1;
    }
    
    private function RTIAddon($data){
        if($data->rti_premium){
            $this->data->ADDONIsInvoiceCover = -1;
            $this->data->InvoiceCoverPremium = $data->rti_premium;	
            $this->data->YN_RTI_APPLICABLE = -1;
        }
    }
}

Class Data{
    // registration number
    public $TXT_REGISTRATION_NUMBER_1	= 'NEW';
    public $TXT_REGISTRATION_NUMBER_2	= 'NEW';
    public $TXT_REGISTRATION_NUMBER_3	= 'NEW';
    public $TXT_REGISTRATION_NUMBER_4	= 'NEW';

    // financier details
    public $NUM_FINANCIER_NAME_1 = '';
    public $NUM_FINANCIER_NAME_2 = '';
    public $TXT_FIN_ACCOUNT_CODE_1 = '';
    public $TXT_FIN_ACCOUNT_CODE_2 = '';
    public $TXT_FIN_BRANCH_NAME_1 = '';
    public $TXT_FIN_BRANCH_NAME_2 = '';
    public $NUM_AGREEMENT_NAME_1 = '';
    public $NUM_AGREEMENT_NAME_2 = '';
    public $TXT_FINANCIER_BRANCH_ADDRESS1 = '';
    public $TXT_FINANCIER_BRANCH_ADDRESS2 = '';

    // tax related tag	    
    public $INS_OFF_CODE = '072300';
    public $TXT_GSTIN_NUMBER = '';	
    public $OEM_CUR_SGST_VALUE = '';
    public $OEM_NUM_SGST_RATE = '';
    public $OEM_CUR_UGST_VALUE= '';
    public $OEM_NUM_UGST_RATE = '';
    public $OEM_CUR_CGST_VALUE = '';
    public $OEM_NUM_CGST_RATE = '';
    public $OEM_CUR_IGST_VALUE = '';
    public $OEM_NUM_IGST_RATE = '';	
    
    // default paramaters
    public $NUM_PROPOSAL_TYPE = "NEWPOLICY";
    public $TXT_YN_PREV_POL_SUBMIT = "Y";
    public $TXT_YN_CUSTOMER_UNDERTAKE = "Y";
    public $TXT_PREVIOUS_INSURER = "";
    public $TXT_YN_NCB_SUBMIT = "Y";
    public $TXT_NCB_FLAG = "Y";
    public $TXT_GC_PRODUCT_CODE = "";
    public $NUM_VEHICLE_TYPE_INTL_CODE = "";
    public $NUM_RGSTRD_GROSS_VEH_WEIGHT = "";
    public $TXT_RTA_DESC = "";
    public $NUM_IEV_TRAILER_VALUE = "0";
    public $NUM_NUMBER_OF_TRAILERS = "0";
    public $YN_INBUILT_CNG = "0";
    public $YN_INBUILT_LPG = "0";
    public $NUM_SPECIAL_DISCOUNT_RATE = "60";
    public $NUM_VOLUNTARY_EXCESS_AMOUNT = "0";
    public $NUM_COMPULSORY_EXCESS_AMOUNT = "1000";
    public $NUM_IMPOSED_EXCESS_AMOUNT = "0";
    public $NUM_NO_OF_NAMED_DRIVERS = "0";
    public $NUM_LD_CLEANER_CONDUCTOR = "0";
    public $TXT_GEOG_AREA_EXTN_COUNTRY = "NoExtn";
    public $YN_HANDICAPPED = "0";
    public $YN_FOREIGN_EMBASSY = "0";
    public $YN_LIMITED_TO_OWN_PREMISES = "0";
    public $YN_DRIVING_TUTION = "0";
    public $YN_ANTI_THEFT = "0";
    public $YN_PERSONAL_EFFECT = "0";
    public $YN_COURTESY_CAR = "0";
    public $NUM_DAYS_COVER_FOR_COURTESY = "0";
    public $YN_MEDICLE_EXPENSE = "0";
    public $YN_COMPULSORY_PA_DTLS = "-1";
    public $TXT_NAME_OF_NOMINEE = "";
    public $TXT_RELATION_WITH_NOMINEE = "";
    public $YN_DELETION_OF_IMT26 = "0";
    public $YN_IMT32 = "0";
    public $YN_COMMERCIAL_FOR_PRIVATE = "0";
    public $ADDONISNCBPROTECTION = "0";
    public $ADDONIsConsumable = "0";
    public $ADDONIsEngineProtection = "0";
    public $ADDONIsRoadSideAssistance = "0";
    public $TXT_PAYMENT_MODE = "CC";
    public $TXT_ENROLLMENT_NO = "";
    public $DAT_ENROLEMENT_DATE = "";
    public $TXT_OCCUPATION = "others";
    public $NUM_POLICY_TYPE = "PackagePolicy";
    public $NUM_IEV_NON_ELEC_ACC_VALUE = "0";
    public $NUM_IEV_ELEC_ACC_VALUE = "0";
    
    // default
    public $NOCLAIMBONUSDISCOUNT = 0;
    
    // ADDON
    public $YN_NIL_DEPR_WITHOUT_EXCESS = 0;
    public $YN_RTI_APPLICABLE = 0;
    public $ADDONIsInvoiceCover = 0;
    public $NUM_PA_UNNAMED_NUMBER = 0;
    public $NUM_PA_UNNAMED_AMOUNT;

}

?>


