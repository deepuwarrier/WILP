<?php
namespace App\Helpers\Health\HDFC;
use App\Http\Controllers\Health\HealthPolicy;
use App\Models\Health\HealthRates;
use App\Models\Health\HealthPlans;
use App\Libraries\HealthLib;
use App\Be\Health\HealthQuoteBe;
use App\Be\Health\HDFCBe;
use App\Constants\Health_Constants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class HDFCHelper
{ 
	public function __construct(){  
	}

	// HDFC get Quotes
	public function get_hdfc_quote($data){ 
 		try{
  			$rate_mod = new HealthRates();
  			$mem_age  = explode('|',$data['agelist']);
  			$plan_list = $this->get_plan_list($data);
  			$pl = array();
  			if(!empty($plan_list)){
  				if($data['plan_type'] === 'INDV' && $data['product_type'] === 'S'){
   					return $this->get_super_topup_indv($mem_age, $plan_list);  
   				} 
  				if($data['plan_type'] === 'INDV' && $data['product_type'] === 'B' && (count($mem_age) >= 2)) {
      				return $this->get_basic_indv($mem_age, $plan_list); 
      			} 
  				foreach($plan_list as $plan){
   					$elder_member = max($mem_age);
      				if(($plan['plan_min_age']<= $elder_member)&&($plan['plan_max_age'] >= $elder_member)){
       					$pl[] = $plan; 
      				}  
     			}
        	}
    		if(isset($pl) && !empty($pl)){ 
      			foreach($pl as $index => $value){
       				$plancode = $value['plan_code'];
       				$planname = $value['plan_name'];
       				$plansi   = (isset($value['plan_si']))? $value['plan_si'] : '';
       				$hdfc_rates[] = $rate_mod->getpremium($plancode,$planname,$plansi);
      			} 
      			return $hdfc_rates;
  			}else { return 'Error'; }
  		}catch(\Exception $e){
         	return false;
        } 
   	}

	private function get_plan_list($data){
		$helth_plan = new HealthPlans();
		$quote_be = new HealthQuoteBe();
		$rate_mod = new HealthRates();
		$column  = array('plan_id','product_code','product_name','plan_code','plan_name','plan_min_age','plan_max_age','plan_insured_pattern','plan_si','plan_tenure','is_display');
  		$productcode = ($data['deductables'] == '0') ? 'HSP' : 'HSTOP';
    	$pattern = ($data['plan_type'] == "INDV") ? '1000' : $data['insured_pattern'];
    	if($data['product_type'] === 'S'){ 
    		//$data['sum_insured'] = $quote_be->get_deductables($data['deductables'],$data['sum_insured'], 'hdfc_code');
    		$data['topup'] = 'On';
    		$check_values  = array('plan_deductables'=> $data['deductables'],'product_code' => $productcode,'plan_insured_pattern' => $pattern, 'plan_si' => $data['sum_insured'], 'plan_tenure' => $data['tenure']);
    	}else{
    		$check_values  = array('product_code' => $productcode,'plan_insured_pattern' => $pattern, 'plan_si' => $data['sum_insured'], 'plan_tenure' => $data['tenure']);
    	}
    	return $helth_plan->get_data($column,$check_values);
	}


	private function get_basic_indv($mem_age, $plan_list){
		$rate_mod = new HealthRates();
  		foreach($mem_age as $age){
	    	foreach( $plan_list as $index => $plan){
			    if(($plan['plan_min_age']<= $age)&&($plan['plan_max_age'] >= $age)){
			    	$pl[] = $plan; } }
        }
    	$arr = array();
	    if(isset($pl) && !empty($pl)){ 
		    foreach($pl as $index1 => $value1){
		    	foreach($pl as $index2 => $value2){
		    		if(($value1['product_name'] == $value2['product_name']) && ($value1['plan_name'] == $value2['plan_name'])) {
		    			$plancode = $value1['plan_code'];
		    			$arr[$value1['product_name']][$index1] = $value1;
		    		}
		    	}
		    }
		}else { return 'Error'; }
		$plan_carry = array();
		$final_plan = array();
		$premium = 0;
		foreach($arr as $product){
			foreach($product as $in1 => $plan1){
				$premium = 0;
				foreach($product as $in2 => $plan2){
				  if($plan1['plan_name'] === $plan2['plan_name']){
				  	$productname = $plan2['product_name'];
					$plancode = $plan2['plan_code'];
		    		$planname = $plan2['plan_name'];
		    		$plansi   = (isset($plan2['plan_si']))? $plan2['plan_si'] : '';
		    		$hdfc_rates = $rate_mod->getpremium($plancode,$planname,$plansi);
		    		$plan_carry[$productname][$planname][$in2] = $hdfc_rates[0];
				  }
			    }
		    }
		}
        $temp_plan = array();
        $premium   = 0;
		foreach($plan_carry as $product){
          foreach($product as $plan){
          	$premium = 0;	
          	foreach($plan as $plan2){
          		$premium += $plan2['base_premium'];
            }
            // Applying 10% discount if eligible
            $plan2['base_premium'] = (count($mem_age) >= 2) ? $premium - ($premium * Health_Constants::HDFC_BASIC_INDV_DISCOUNT) : $premium ;
            $temp_plan[$plan2['product_name']][$plan2['plan_name']] = $plan2;
          }
        } 
        $arr1 = array(); 
        $i = 0;
        foreach ($temp_plan as $key1 => $value1) {
        	foreach ($value1 as $key2 => $value2) {
        		$arr1[] = $value2; }
        }
        $i = 0;
        $final_plan = array();
        foreach($arr1 as $plan){
        	$final_plan[$i][0] = $plan;
        	$i++; }
	    return $final_plan;
    }


    private function get_super_topup_indv($mem_age, $plan_list){
    	$rate_mod = new HealthRates();
  	    foreach($mem_age as $age){
  	    	if($age === '3m') $age = '3';	
	        foreach( $plan_list as $index => $plan){
			    if(($plan['plan_min_age']<= $age)&&($plan['plan_max_age'] >= $age)){
			    	$pl[] = $plan; }  }
        }
    	$arr = array();
	    if(isset($pl) && !empty($pl)){ 
		    foreach($pl as $index1 => $value1){
		    	foreach($pl as $index2 => $value2){
		    		if($value1['plan_si'] == $value2['plan_si']){
		    			$plancode = $value1['plan_code'];
		    			$arr[$value1['plan_si']][$index1] = $value1;
		    		}
		    	}
		    }
		}else { return 'Error'; }
		$plan_carry = '';
		$final_plan = array();
		$premium = 0;
		foreach($arr as $si){
			$premium = 0;
			foreach($si as $plan){
				$plancode = $plan['plan_code'];
		    	$planname = $plan['plan_name'];
		    	$plansi   = (isset($plan['plan_si']))? $plan['plan_si'] : '';
		    	$hdfc_rates = $rate_mod->getpremium($plancode,$planname,$plansi);	
		    	$premium += $hdfc_rates[0]['base_premium'];	
		    	$plan_carry =  $hdfc_rates[0];
		    }
		    // Applying 10% discount if eligible
		    $plan_carry['base_premium'] = (count($mem_age) > 2) ? $premium - ($premium * Health_Constants::HDFC_S_TOPUP_INDV_DISCOUNT) : $premium ;
		    $final_plan[][0] = $plan_carry;
		}
	    return $final_plan;
    }

	// Store data to response table
  	public function set_response($hdfcresponse, $user_id, $data){
		$hdfc_be = new HDFCBe();
	  	foreach($hdfcresponse as $response){
	  		$hdfc_covers = $hdfc_be->set_hdfc_covers($response[0]['plan_code']);
	  		$type = $data['plan_type']; 
	  		if($type == 'INDV'){$productType = 'NF'; }else{ $productType = 'WF';  }
			$serviceTax = round(($response[0]['base_premium'] * 18)/ 100);
			$cgst = round($serviceTax/2);
			$sgst = round($serviceTax/2);
			$totalPremium = ($response[0]['base_premium'] + $cgst+ $sgst);
			$premiumbreakup =[
			'base_premium' => $response[0]['base_premium'],
			'servicetax' => $serviceTax,
			'cgst' => $cgst,
			'sgst' => $sgst,
			'totalPremium' => $totalPremium ]; 
			$value['session_id'] = $data['trans_code'];
			$value['trans_code'] = $data['trans_code'];
			$value['productId'] = $response[0]['plan_code'];
			$value['insurerId'] = 'hdfc';
			$value['lob']       = 'Health';
			$value['planSI'] = (isset($response[0]['planSI'])) ? $response[0]['planSI'] :'';
			$value['health_user_id'] = $user_id;
			$value['productType'] = $productType;
			$value['productName'] = $response[0]['product_name'];
			$value['product_planname'] = $response[0]['plan_name'];
			$value['insurerName'] = 'hdfc';
			$value['netPremium'] = $response[0]['base_premium'];
			$value['serviceTax'] = $serviceTax;
			$value['cgst'] = $cgst;
			$value['sgst'] = $sgst;
			$value['totalPremium'] =$totalPremium;
			$value['covers'] = json_encode($hdfc_covers);
			$value['premiumbreakup'] = json_encode($premiumbreakup);
			$dataval[] = $value;
		}
		return $dataval;
  	}
}
