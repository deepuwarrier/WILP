<?php
namespace App\Helpers\Health\HDFC;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Be\Health\HDFCBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class HDFCPolicyHelper {

	public function __construct() {
    }

    public function get_proposal_response($proposal_req_data){ 
        $hdfc_be = new HDFCBe();
        if($proposal_req_data->get_product_type() == 'S'){
            $populated_request = $hdfc_be->populate_proposal_request_topup_plan($proposal_req_data);
            $proposal_response = $this->call_proposal_api_topup_plan($populated_request,$proposal_req_data->get_hl_trans_code());
            $parse_response = $hdfc_be->parse_hdfc_topup_response($proposal_response,$proposal_req_data);
            return $parse_response; 
        }else{
            $populated_request = $hdfc_be->populate_proposal_request_basic_plan($proposal_req_data);
            $proposal_response = $this->call_proposal_api_basic_plan($populated_request, $proposal_req_data->get_hl_trans_code());
            $parse_response = $hdfc_be->parse_hdfc_basic_response($proposal_response,$proposal_req_data);
            return $parse_response;
        }
    }

     private function call_proposal_api_basic_plan($populated_request, $hl_trans_code){
        Log::info('Health HDFC Basic Plan Proposal Request - '.$hl_trans_code.''.$populated_request);
        $url = Health_Constants::HDFC_PROPOSAL_URL;
        $client = new Client();
        try{
            $res = $client->request('POST', $url, [ 'form_params' => [ 'NewHealthCPURL' => $populated_request ], 'verify'=> false ]);
        }catch (\Exception $e) {
            Log::info($e->getMessage());  
        }
        $response = $res->getBody()->getContents();
        Log::info('HEALTH HDFC Basic Plan Proposal Response - '.$hl_trans_code.''.$response);
        return $response;
    }


    private function call_proposal_api_topup_plan($populated_request, $hl_trans_code){
        Log::info('HEALTH HDFC TOPUP Plan Proposal Request - '.$hl_trans_code.''.$populated_request);
        $url = Health_Constants::HDFC_SUPER_TOPUP_PROP;
        $client = new Client();
        try{
            $res = $client->request('POST', $url, [ 'form_params' => [ 'NewHealthCPURL' => $populated_request ], 'verify'=> false ]);
        }catch(\Exception $e){
            Log::info($e->getMessage());
        }
        $response = $res->getBody()->getContents();
        Log::info('HEALTH HDFC TOPUP Plan Proposal Response - '.$hl_trans_code.''.$response);
        return $response;

    }
}
?>
