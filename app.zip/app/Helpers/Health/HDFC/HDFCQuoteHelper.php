<?php
namespace App\Helpers\Health\HDFC;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Models\Health\HealthRates;
use App\Be\Health\HDFCBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class HDFCQuoteHelper {

    public function __construct() {
    }

    public function get_quote($quote_req_data){ 
        $mem_age = $quote_req_data->get_age_list();
        $hdfc_be = new HDFCBe();
        $plan_list = $hdfc_be->get_plan_list($quote_req_data);
        $hdfc_rates = new HealthRates();
        try{
            $pl = array();
            if(!empty($plan_list)){
                if($quote_req_data->get_plan_type() === 'INDV' && $quote_req_data->get_product_type() === 'S'){
                    $super_topup_rates =  $hdfc_be->get_super_topup_indv($mem_age, $plan_list); 
                    foreach($super_topup_rates as $topup_val){
                        $topup_indv_rates[] = $hdfc_be->parse_quote_response($topup_val[0], $quote_req_data);
                    }
                    return $topup_indv_rates;
                } 
                if($quote_req_data->get_plan_type() === 'INDV' && $quote_req_data->get_product_type() === 'B' && (count($mem_age) >= 2)) {
                    $basic_rates = $hdfc_be->get_basic_indv($mem_age, $plan_list); 
                    foreach($basic_rates as $base_val){
                        $base_indv_rates[] = $hdfc_be->parse_quote_response($base_val[0], $quote_req_data);
                    }
                    return $base_indv_rates;
                } 

                //Temp functions
                $temp_agelist = array();
                for($i=3;$i<=11;$i++){
                    $child_age[$i] = $i.'m';
                }   

                foreach($mem_age as $age){
                   if(in_array($age, $child_age)){
                        $temp_agelist[] = 0;
                   }else{
                        $temp_agelist[] = $age;
                   }

                }
                //Temp functions ends
                foreach($plan_list as $plan){
                    $elder_member = max($temp_agelist);
                    if(($plan['plan_min_age']<= $elder_member)&&($plan['plan_max_age'] >= $elder_member)){
                        $pl[] = $plan; 
                    }  
                }
            }

            if(isset($pl) && !empty($pl)){ 
                foreach($pl as $index => $value){
                    $plancode = $value['plan_code'];
                    $planname = $value['plan_name'];
                    $plansi   = (isset($value['plan_si']))? $value['plan_si'] : '';
                    $plan_rates = $hdfc_rates->getpremium($plancode,$planname,$plansi);
                    $parse_response[] = $hdfc_be->parse_quote_response($plan_rates[0],$quote_req_data);
                } 
                return $parse_response;
            }else { return false; }
        }catch(\Exception $e){
            return false;
        } 
    }
}
  
