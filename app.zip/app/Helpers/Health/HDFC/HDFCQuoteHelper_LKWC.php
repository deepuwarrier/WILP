<?php
namespace App\Helpers\Health\HDFC;
use App\Http\Controllers\Health\HealthPolicy;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use App\Models\Health\HealthUserData;
use Log;

class HDFCQuoteHelper
{ 
    public function __construct(){ 
    }

  // HDFC set Quotes
    public function set_HDFC_data($data){ 
        $hdfc['agelist'] = $data['age_list'];
        $hdfc['sum_insured']  = $data['sum_insured'];
        $hdfc['tenure']  = $data['tenure'];
        $hdfc['deductables']  = ($data['product_type'] === 'S') ? $data['deductables'] : '0';
        $hdfc['product_type'] = $data['product_type'];
        $hdfc['memberslist']  = $data['members_list'];
        $hdfc['members'] = $this->calculate_age($hdfc['agelist'],$hdfc['memberslist'], $data['product_type']);
        $hdfc['insured_pattern'] = $this->get_insured_pattern($hdfc['members']);
        // No quotes for 1A1C for individual suminsured, super topup
        if($data['product_type'] === 'S' && $data['plan_type'] === 'INDV' && ($hdfc['insured_pattern'] == 1010 || $hdfc['insured_pattern'] == 1020 || $hdfc['insured_pattern'] == 1030)) {
            return null;  }
        // No quotes for 1A3C, basic product
        if($data['product_type'] === 'B' && ($hdfc['insured_pattern'] == 1030)){
            return null; }
        return $hdfc;
    }

    private function calculate_age($age_list, $mem_list, $product_type){
        $agelist = explode(',',$age_list);
        $memlist = explode(',',$mem_list);
        $child_age_limit = ($product_type === 'S') ? '23' : '25';
        $adult = $children = 0;
        for($i=0; $i<sizeof($memlist);$i++){
            if($memlist[$i] == 'WIFE' || $memlist[$i] == 'MOTH' || $memlist[$i] == 'FATH' || $memlist[$i] == 'HUS'){ $adult++; }
            elseif($memlist[$i] == 'SELF' && $agelist[$i] >=18 ){ $adult++; }
            elseif($memlist[$i] == 'SONM' || $memlist[$i] == 'UDTR'){
                if($agelist[$i] === '3m'){ $adult++;}
                elseif($agelist[$i] > (int)$child_age_limit){ $adult++;
                }else { $children++; }
            }
        }
        $res['adult'] = $adult;
        $res['children'] = $children;
        return $res;
    }

    private function get_insured_pattern($members){  
        if(($members['adult'] == 2) && ($members['children'] == 2)) {
            $ins_pattern = 1120; }
        elseif(($members['adult'] == 2) && ($members['children'] == 1)) {
            $ins_pattern = 1110; }
        elseif(($members['adult'] == 1) && ($members['children'] == 2)) {
            $ins_pattern = 1020; }
        elseif(($members['adult'] == 1) && ($members['children'] == 3)) {
            $ins_pattern = 1030; }
        elseif(($members['adult'] == 1) && ($members['children'] == 1)) {
            $ins_pattern = 1010; }
        elseif(($members['adult'] == 2) &&($members['children'] == 0)){
            $ins_pattern = 1100; }
        elseif(($members['adult'] == 1) &&($members['children'] == 0)){
            $ins_pattern = 1000; }
        return $ins_pattern;
    }
}
