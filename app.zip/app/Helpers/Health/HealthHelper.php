<?php

namespace App\Helpers\Health;

use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class HealthHelper {

	public static $auth = array('accesskey'=>'TTIBI','secretkey'=>'TTIBI');

	public function callApi($url,$postFields){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 120,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => "".json_encode($postFields),
			CURLOPT_HTTPHEADER => array("content-type: application/json"),
		));
		$response = array();
		$data = curl_exec($curl);
		$response['data'] = json_decode($data,true);
		if(empty($response['data'])){
			$response['error'] = curl_error($curl);
			$response['status'] = "0";
		}
		curl_close($curl);
		return $response;
	}

	public function addDataToFile($filename, $data) {
		$filename = self::getSuid();
		$exists = Storage::disk('local')->exists(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' . $filename);
		if ($exists) {
			$data_fetch = json_decode(Storage::get(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' . $filename), true);
			foreach ($data as $key => $value) {
				$data_fetch[$key] = $value;
			}
			Storage::disk('local')->put(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' . $filename, json_encode($data_fetch));
		} else {
			Storage::disk('local')->put(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' . $filename, json_encode($data));
		}
	}

	public function getSessionValue($key = null, $trans_code) {
		if($key)
			return json_decode(Storage::get(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' . $trans_code), true)[$key];	
		else
			return json_decode(Storage::get(Health_Constants::HEALTH_QUOTE_FILE_PATH . '/' .$trans_code), true);
	}

	// get session id
	public function getSuid() {
		return (session()->has('suid')) ? session('suid') : session()->getId();
	}

	public function getUserType($dob){
		return (Carbon::parse(date("m/d/Y", strtotime(str_replace("/","-",$dob))))->age >= 21)? 'A' : 'C';
	}	
	

	public function reArrangeProduct($old_products){
		$products = array();
		foreach ($old_products as $result_product_attr => $product) {
			foreach($product as $product_attr => $product_value){
				if(is_array($product_value)){
					if(strtolower($product_attr) == 'covers'){
						$tmp_value = $this->reformatCover($product_value);
					}else if(strtolower($product_attr) == 'attributes'){
						$tmp_value = $this->reformatAttributes($product_value);
					}else if(strtolower($product_attr) == 'premiumbreakup'){
						$tmp_value = $this->reformatPremiumBreakup($product_value);
					}
					$products[$product['productId']][$product_attr] = $tmp_value;
				}else{
					$products[$product['productId']][$product_attr] = $product_value;
				}
			}
			unset($products[$product['productId']]['productId']);
		}
		return $products;
	}

	private function reformatCover($covers){
		$re_covers = [];
		foreach($covers as $cover_product_attr => $cover_value){
			$re_covers[$cover_value['coverId']] = $cover_value;
		}
		return $re_covers;
	}

	private function reformatAttributes($attributes){
		$re_attribute = [];
		foreach($attributes as $attribute_product_attr => $attribute_value){
			if(is_array($attribute_value) && count($attribute_value) == 1){
				foreach ($attribute_value as $attribute_value_product_attr => $attribute_value_value) {
					$re_attribute[$attribute_value_product_attr] = $attribute_value_value;
				}
			}else{
				$re_attribute[$attribute_product_attr] = $attribute_value;	
			}
		}
		return $re_attribute;
	}

	private function reformatPremiumBreakup($premiumBreakups){
		$rePremiumBreakup = [];
		foreach ($premiumBreakups as $premiumBreakup_product_attr => $premiumBreakup_value) {
			if(is_array($premiumBreakup_value)){
				foreach ($premiumBreakup_value as $premiumBreakup_value_product_attr => $premiumBreakup_value_value) {
					$rePremiumBreakup[$premiumBreakup_product_attr][$premiumBreakup_value_value['coverId']] = $premiumBreakup_value_value;
					unset($rePremiumBreakup[$premiumBreakup_product_attr][$premiumBreakup_value_value['coverId']]['coverId']);
				}
			}
		}
		return $rePremiumBreakup;
	}

public function get_proposer_name ($trans_data) {
		$first_name = explode('|', $trans_data['firstname']); 
		$last_name = explode('|', $trans_data['lastname']); 
		$proposer_name = $first_name[0].' '.$last_name[0];
		if(empty($first_name[0]) || empty($last_name[0])){
			$proposer_name = '-';
		}
		return $proposer_name; 
	}

}

?>