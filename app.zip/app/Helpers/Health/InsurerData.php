<?php
namespace App\Helpers\Health;

use App\Models\Base\UserMasterM;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthState;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\InstaInsurers;

class InsurerData{
	public function insr_city ($column_name, $city_code, $null_check = false) {
		$city_db = new HealthCity();
		$ret_value = "";
		if($null_check){
			if($city_code!= null){
				$ret_value =  $city_db->city_details($city_code)->$column_name;
			}
		}else{
			$ret_value =  $city_db->city_details($city_code)->$column_name;
		}
		return $ret_value;
	}
	
	public function insr_state ($column_name, $state_code, $null_check = false) { 
		$state_db = new HealthState();
		$ret_value = "";
		if($null_check){
			if($state_code!= null){
				$ret_value =  $state_db->state_details($state_code)->$column_name;
			}
		}else{
			$ret_value =  $state_db->state_details($state_code)->$column_name;
		}
		return $ret_value;
	}
	
	public function insurer_data($column_name, $insr_code, $null_check = false) {
		$insr_db = new InstaInsurers();
		$ret_value = "";
		if($null_check){
			if($insr_code!= null){
				$ret_value = $insr_db->insurer_details($insr_code)->$column_name;
			}
		}else{
			$ret_value = $insr_db->insurer_details($insr_code)->$column_name;
		}
		return $ret_value;
	}
	
	public function user_data($column_name, $agent_code, $null_check = false) {
		$user_data = new UserMasterM();
		$ret_value = "";
		if($null_check){
			if($agent_code != null){
				$ret_value = $user_data->user_details($agent_code)->$column_name;
			}
		}else{
			$ret_value = $user_data->user_details($agent_code)->$column_name;
		}
		return $ret_value;
	} 

	public function nomrel_data($column_name, $nomrel_code) {
		
	}
	
	public function proposer_occu($column_name, $occ_code) {
		
	}
	
} // end of class
