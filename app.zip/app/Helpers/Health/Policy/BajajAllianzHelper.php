<?php

namespace App\Helpers\Health\Policy;

use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Carbon\Carbon;

class BajajAllianzHelper 
{

    /********************************************************************************************
     *  Function to get Policy API Response
    *********************************************************************************************/

    public static function getPolicy($data) 
    { 
        return 'success';
        
}
}
?>