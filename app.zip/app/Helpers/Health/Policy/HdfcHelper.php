<?php
namespace App\Helpers\Health\Policy;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Constants\Health_Constants;
use App\Helpers\Health\HealthHelper;
use App\Be\Health\HealthPolicyBe;
use App\Libraries\HealthLib;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthQuoteResponse;
use Illuminate\Support\Facades\File;
use DateTime;
use Log;

class HdfcHelper {
    
    public function get_super_topup( $user_data ){
        $h_lib = new HealthLib();
        $usertdata = new HealthUserData();
        $u_data = $usertdata->getUserTData($user_data['trans_code']);
        $user_data['sum_insured'] = $u_data['sum_insured'];
        list($xml, $user_data) =  $this->set_super_topup($user_data);
        Log::info('HEALTH_HDFC_S_TOPUP_PROPOSAL_REQUEST '.$xml);
        $client = new Client();
        try{
            $res = $client->request('POST', Health_Constants::HDFC_SUPER_TOPUP_PROP, [
              'form_params' => [ 'NewHealthCPURL' => $xml ],
              'verify'=> false ]);
        }catch(\Exception $e){
            Log::info('HEALTH_HDFC_S_TOPUP_PROPOSAL_REQUEST'. print_r($e->getMessage(),true));
        }
        $response = $res->getBody()->getContents();
        Log::info('HEALTH_HDFC_S_TOPUP_PROPOSAL_RESPONSE '.$response);
        return  $h_lib->parse_super_topup($response,$user_data);
    }

     // HDFC basic plan policy
    public function getPolicy($user_data){
        $h_lib = new HealthLib();
        $usertdata = new HealthUserData();
        $xml = $this->set_hdfc_policy($user_data);
        $userdata = $usertdata->getUserTData($user_data['trans_code']);
        $client = new Client();
        try{
          $res = $client->request('POST', Health_Constants::HDFC_PROPOSAL_URL, [
              'form_params' => [ 'NewHealthCPURL' => $xml ],
              'verify'=> false ]);
        }catch(\Exception $e){
           Log::info($e->getMessage());         
        }
        $response = $res->getBody()->getContents();
        Log::info('HEALTH HDFC Proposal Response '.$response);
        return  $h_lib->parse_hdfc_basic($response,$userdata);
    }

    private function set_super_topup( $user_data ){
        $h_pol_be = new HealthPolicyBe();
        $usertdata = new HealthUserData();
        $column       = array('tenure');
        $check_values = array('session_id' => $user_data['session_id']);
        $usr_response = $usertdata->get_data($column,$check_values);
        $tenure       = $usr_response[0]['tenure'];
        $quote_resp = new HealthQuoteResponse();
        $relationshipId = explode('|',$user_data['relationshipId']);
        $totalPremium = '';
        $change_flag  = false;
        if(isset($user_data['new_premium']) && !empty($user_data['new_premium'])){
            $totalPremium = $user_data['new_premium'] + $user_data['new_service_tax'];
            $input['totalPremium'] = $totalPremium;
            $input['serviceTax'] = $user_data['new_service_tax'];
            $input['cgst'] = $user_data['new_service_tax']/2;
            $input['sgst'] = $user_data['new_service_tax']/2;
            $change_flag   = true;
            $input['basePremium'] = $user_data['new_premium'];
            $usertdata->update_or_create(['trans_code'=>$user_data['trans_code']],$input);
            $rtotalPremium = $user_data['new_premium'] + $user_data['new_service_tax'];
            $val['totalPremium'] = $rtotalPremium;
            $val['serviceTax'] = $user_data['new_service_tax'];
            $val['cgst'] = $user_data['new_service_tax']/2;
            $val['sgst'] = $user_data['new_service_tax']/2;
            $val['netPremium'] = $user_data['new_premium'];
            $user_data['totalPremium'] = $totalPremium;
            $quote_resp->update_or_create(['trans_code'=>$user_data['trans_code']],$val);
        }
        $xml = File::get(base_path().'/app/Helpers/Health/HDFC'.Health_Constants::HDFC_PROP_FILE);
        $additional_insured_template = File::get(base_path().'/app/Helpers/Health/HDFC'.Health_Constants::HDFC_INSR_PROP_FILE);
        $token_values = array();
        $token_values[] = $user_data['firstname'][0];
        $token_values[] = $user_data['lastname'][0];
        $token_values[] = $user_data['dob'][0];
        $token_values[] = $user_data['gender'][1];
        $token_values[] = $user_data['houseno'];
        $token_values[] = $user_data['street'];
        $token_values[] = $user_data['locality'];
        $token_values[] = $user_data['state'];
        $token_values[] = $user_data['city'];
        $token_values[] = $user_data['cust_pincode'];
        $token_values[] = strtolower($user_data['email']);
        $token_values[] = $user_data['mobile'];
        $token_values[] = Health_Constants::HDFC_SUPER_TOPUP_PRODUCER_CODE;
        $token_values[] = Health_Constants::HDFC_S_TOPUP_P_CODE;
        $token_values[] = $user_data['product_id'];
        $token_values[] = ($change_flag == true)? $user_data['new_premium'] : $user_data['basePremium'];
        $token_values[] = ($change_flag == true)? $user_data['new_service_tax'] : $user_data['serviceTax'];
        $token_values[] = ($change_flag == true)? $totalPremium : $user_data['totalPremium'];
        $token_values[] = $user_data['sum_insured'];
        $token_values[] = ($user_data['plan_type'] == 'INDV') ?  'NF' : 'WF';
        $token_values[] = $tenure;
        $token_values[] = $user_data['deductable']; // Deductable
        $token_values[] = $h_pol_be->get_uid($user_data['mobile']);
        $token_values[] = ((isset($user_data['agree_med_chkup']) && $user_data['agree_med_chkup'] == '1')) ? '1' : '0' ;
        $tokens         = explode(',',Health_Constants::HDFC_S_TOPUP_TOKENS);
        $xml            = str_replace($tokens, $token_values, $xml);
        $tokens  = explode(',',Health_Constants::HDFC_S_TOPUP_ADDI_TOKENS);
        $insured = ''; 
        unset($token_values); $token_values = array();
        for($i=0; $i<$user_data['membercount']; $i++){ 
            if($relationshipId[$i] == 'SELF'){ $rel_id = 'I'; }
            if($relationshipId[$i] == 'WIFE'){ $rel_id = 'W'; }
            if($relationshipId[$i] == 'HUS'){ $rel_id = 'H'; }
            if($relationshipId[$i] == 'SONM'){ $rel_id = 'S'; }
            if($relationshipId[$i] == 'UDTR'){ $rel_id = 'D'; } 
        $insured .= $additional_insured_template;
        $token_values[] = $user_data['firstname'][$i].' '.$user_data['lastname'][$i];
        $token_values[] = $user_data['firstname'][$i];
        $token_values[] = $user_data['lastname'][$i];
        $token_values[] = $user_data['dob'][$i];
        $age = $this->calculate_age($user_data['dob'][$i]);
        $token_values[] = $rel_id;
        $token_values[] = $user_data['gender'][$i+1];
        $token_values[] = $user_data['nomineename'];
        $token_values[] = $user_data['nomineerel'];
        $token_values[] = round($h_pol_be->convert_feet_to_cm($user_data['feet'][$i],$user_data['inches'][$i]));
        $token_values[] = $user_data['weight'][$i];
        $ped_name       = 'disease_member_'. (string) ($i + 1);
        $token_values[] = (isset($user_data['pedname'][$ped_name])) ? $user_data['pedname'][$ped_name] : '';
        $token_values[] = ($user_data['ped']['illness'] == '1')? 'true' : 'false' ;
        $insured  = str_replace($tokens, $token_values, $insured);
        unset($token_values); $token_values = array();
        }  
        $xml = str_replace('{ADDITIONAL_INSURED}', $insured, $xml); 
      return [$xml, $user_data]; 
    }

    private function set_hdfc_policy($data){ 
        $cudt_details = $this->calculate_CustDetails($data);
        $plan_details = $this->calculate_PlanDetails($data);
        $payment_details = $this->calculate_PaymentDetails($data);
        $member_details = $this->calculate_InsuredDetails($data);
        $hdfc_xml = '<InsuranceDetails>
                         <CustDetails>'.$cudt_details.'</CustDetails>
                         <PlanDetails>'.$plan_details.'</PlanDetails>
                         <PaymentDetails>'.$payment_details.'</PaymentDetails>
                         <Member>'.implode("",$member_details).'</Member>
                     </InsuranceDetails>';
        Log::info('HEALTH HDFC Proposal Request '.$hdfc_xml);
        return $hdfc_xml;
    }

    private function calculate_CustDetails($data){
        $h_pol_be = new HealthPolicyBe();
        $title = $data['title'];
        $uid_no = $h_pol_be->get_uid($data['mobile']); 
        $ped = 0;
        if(isset($data['agree_med_chkup']) && $data['agree_med_chkup'] == 1){
            $ped = 1; }
        // Updating Gender and Title for Self
        $gender_list = $data['gender'];
        $replacements = array(0 => $data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        unset($gender['1']);
        if($gender['0'] == 'M') {
            $title_list = $title;
            $replacements = array(0 => 'Mr');
            $title = array_replace($title_list, $replacements);  }
        if($gender['0'] == 'F'){
            $title_list = $title;
            $replacements = array(0 => 'Ms');
            $title = array_replace($title_list, $replacements);  }
        $test = implode('|',$gender);
        $gender = explode('|',$test);
        if($gender[0] == 'M'){$mem_gender = 'M'; }else{ $mem_gender = 'F';}
        $custdetails ='<ApplFirstName>'.$data['firstname'][0].'</ApplFirstName>
                        <ApplLastName>'.$data['lastname'][0].'</ApplLastName>
                        <ApplDOB>'.$data['dob'][0].'</ApplDOB>
                        <ApplGender>'.$mem_gender.'</ApplGender>
                        <Address1>'.$data['houseno'].' ' .$data['street'].'</Address1>
                        <Address2>'.$data['locality'].'</Address2>
                        <Address3>/</Address3>
                        <State>'.$data['state'].'</State>
                        <City>'.$data['city'].'</City>
                        <Pincode>'.$data['cust_pincode'].'</Pincode>
                        <EmailId>'.strtolower($data['email']).'</EmailId>
                        <MobileNo>'.$data['mobile'].'</MobileNo>
                        <Title>'.$title[0].'</Title>
                        <IsCustomerAcceptedPPCPED>'.$ped.'</IsCustomerAcceptedPPCPED>
                        <IsProposerSameAsInsured>Y</IsProposerSameAsInsured>
                        <IsCustomerAuthenticationDone>1</IsCustomerAuthenticationDone>
                        <AuthenticationType>OTP</AuthenticationType>
                        <UIDNo>'.$uid_no.'</UIDNo>';
        return $custdetails;               
    }

    private function calculate_PlanDetails($data){
        $plan = ($data['plan_type'] == 'FF') ? 'WF' : 'NF'; 
        $usertdata = new HealthUserData();
        $quote_resp = new HealthQuoteResponse();
        $column = array('tenure');
        $chk_val = array('trans_code'=> $data['trans_code']);
        $tenure = $usertdata->get_data($column, $chk_val);
        $totalPremium = '';
        $change_flag  = false;
        if(isset($data['new_premium']) && !empty($data['new_premium'])){
          $totalPremium = $data['new_premium'] + $data['new_service_tax'];
          $input['totalPremium'] = $totalPremium;
          $input['serviceTax'] = $data['new_service_tax'];
          $input['cgst'] = $data['new_service_tax']/2;
          $input['sgst'] = $data['new_service_tax']/2;
          $change_flag   = true;
          $input['basePremium'] = $data['new_premium'];
          $usertdata->update_or_create(['trans_code'=>$data['trans_code']],$input);
          $rtotalPremium = $data['new_premium'] + $data['new_service_tax'];
          $val['totalPremium'] = $rtotalPremium;
          $val['serviceTax'] = $data['new_service_tax'];
          $val['cgst'] = $data['new_service_tax']/2;
          $val['sgst'] = $data['new_service_tax']/2;
          $val['netPremium'] = $data['new_premium'];
          $quote_resp->update_or_create(['trans_code'=>$data['trans_code']],$val);
        }
        $basePremium = ($change_flag == true)? $data['new_premium'] : $data['basePremium'];
        $serviceTax = ($change_flag == true)? $data['new_service_tax'] : $data['serviceTax'];
        $totalPremium = ($change_flag == true)? $totalPremium : $data['totalPremium'];  
        $plandetails ='<ProducerCd>'.Health_Constants::HDFC_BASIC_PRODUCER_CODE.'</ProducerCd>
                        <ProductCd>'.Health_Constants::HDFC_PRODUCT_CODE.'</ProductCd>
                        <PlanCd>'.$data['product_id'].'</PlanCd>
                        <coverType>'.$data['product_planname'].'</coverType>
                        <BasePremium>'.$basePremium.'</BasePremium>
                        <ServiceTax>'.$serviceTax.'</ServiceTax>
                        <TotalPremiumAmt>'.$totalPremium.'</TotalPremiumAmt>
                        <SumInsured>'.$data['suminsured'][0].'</SumInsured>
                        <TypeOfPlan>'.$plan.'</TypeOfPlan>
                        <PolicyPeriod>'.$tenure[0]['tenure'].'</PolicyPeriod>';
        return $plandetails;
    }

    private function calculate_PaymentDetails($data){
        $paymentdetails ='<PaymentMode>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentMode>
                            <PaymentReferance>'.Health_Constants::PROPOSAL_POLICY['payment_mode'].'</PaymentReferance>
                            <CoInsurance>N</CoInsurance>';
        return $paymentdetails;
    }

    private function calculate_InsuredDetails($data){
    
        $insured_data = [];
        $relationship = explode('|',$data['relationshipId']);
        
        $data['ped_lifestyle'] = $this->set_ped_list($data);
       
        
        foreach ($relationship as $i => $relationship_id){
            if($relationship_id == 'SELF'){ $rel_id = 'I'; }
            if($relationship_id == 'WIFE'){ $rel_id = 'W'; } 
            if($relationship_id == 'HUS'){ $rel_id = 'H'; } 
            if($relationship_id == 'SONM'){ $rel_id = 'S'; } 
            if($relationship_id == 'UDTR'){ $rel_id = 'D'; } 
            $gender_list = $data['gender'];
            $replacements = array(0 => $data['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            unset($gender['1']);
            $test = implode('|',$gender);
            $gender = explode('|',$test);
            if($gender[$i] == 'M'){$mem_gender = 'M'; }else{ $mem_gender = 'F';}
            $srl_no = $i+1;
            $insured_data[] = '<InsuredDetails SrNo="'.$srl_no.'" FirstName="'.$data['firstname'][$i].'" LastName="'.$data['lastname'][$i].'" DOB="'.$data['dob'][$i].'" RelationShip="'.$rel_id.'" InsuredId="'.$srl_no.'" Gender="'.$mem_gender.'" NomineeName="'.$data['nomineename'].'" NomineeRelationship="'.$data['nomineerel'].'" PreExistingDisease="'.$data['ped_lifestyle'][$i].'" />';
        }
        return $insured_data;
    }

    private function set_ped_list($data){
        $usertdata = new HealthUserData();
        $ped_lifestyle = [
            '0'=> isset($data['pedname']['disease_member_1']) ? $data['pedname']['disease_member_1']: '',
            '1' => isset($data['pedname']['disease_member_2']) ? $data['pedname']['disease_member_2'] : '',
            '2' => isset($data['pedname']['disease_member_3']) ? $data['pedname']['disease_member_3'] : '',
            '3' => isset($data['pedname']['disease_member_4']) ? $data['pedname']['disease_member_4'] : '', ];
        $input['ped_lifestyle'] = json_encode($ped_lifestyle);
        $check_values = array('trans_code' => $data['trans_code']);
        $usertdata->update_data($input, $check_values);
        return $ped_lifestyle;
    }

    private function calculate_age($date){
        $dt   = DateTime::createFromFormat('d/m/Y', $date);
        $dob  = $dt->format('d-m-Y');
        $from = new DateTime($dob);
        $to   = new DateTime('today');
        return $from->diff($to)->y;
    }
}
?>
