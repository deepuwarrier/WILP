<?php

namespace App\Helpers\Health\Policy;

use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Constants\Health_Constants;
use App\Helpers\Health\HealthHelper;
use App\Be\Health\HealthPolicyBe;

class ReligareHelper 
{
    //Store the proposer input value
    private static $proposerInput,$predefinedVal;  

     public static function getPolicy($user_data)
    {
        self::$proposerInput = $user_data; 
        self::$predefinedVal = Health_Constants::PROPOSAL_POLICY;
        $sections = [] ;
        $covers = self::getCoversSection($user_data['covers']);
        $sections['authentication'] = Health_Constants::AUTH;
        $sections['productId'] = self::$proposerInput['productId'];
        $sections['policy'] = self::getPolicySection();
        $sections['insured'] = self::getInsuredSection();
        $sections['proposer'] = self::getProposerSection();
        $sections['covers'] = $covers;
        Log::info('Health Religare Proposal Request', $sections);
        return $sections;
    }
   
    /*  Prepare the value for for POLICY section */
     
    private static function getPolicySection()
    {  
       //For individual
        $policy = ['floater' => 'N', 
                   'productType' => self::$predefinedVal['product_type']['N']];
        //For family floater
        if (self::$proposerInput['plan_type'] == 'FF') { 
            $policy['floater'] = 'Y';
            $policy['floaterSi'] = self::$proposerInput['floaterSI'];                
            $policy['productType'] = self::$predefinedVal['product_type'][$policy['floater']]; } 
        $policy['policyStartdate'] = self::$proposerInput['p_start'];
        $policy['policyEnddate'] = self::$proposerInput['p_ends'];
        $policy['tenure'] = ''.self::$predefinedVal['tenure'].'';
        $policy['numAdults'] =   self::$proposerInput['adults'];
        $policy['numChildren'] = self::$proposerInput['children'];
        // Policy details if any premium miss match
        if (isset(self::$proposerInput['new_premium']) && !empty(self::$proposerInput['new_premium'])){ 
            $basePremium = self::$proposerInput['new_premium'];}
        else{ $basePremium = self::$proposerInput['basePremium']; }
        $basePremium = $basePremium;
        if (isset(self::$proposerInput['new_service_tax']) && !empty(self::$proposerInput['new_service_tax'])) {
            $serviceTax = self::$proposerInput['new_service_tax'];
            $cgst = ($serviceTax / 2 );
            $sgst = ($serviceTax / 2 );  }
        else{
            $serviceTax = (self::$proposerInput['cgst'] + self::$proposerInput['sgst']);
            $cgst = self::$proposerInput['cgst'];
            $sgst = self::$proposerInput['sgst'];  }
        $policy['basePremium'] = $basePremium;
        $policy['serviceTax'] = ''.$serviceTax.'';
        $policy['CGST'] = ''.$cgst.'';
        $policy['SGST'] = ''.$sgst.'';
        $policy['premiumPayable'] = ''.$basePremium + $serviceTax.'';
        $policy['paymentMode'] = self::$predefinedVal['payment_mode'];
        $policy['declarationAgree'] = self::$predefinedVal['declaration_agree'];
        return $policy;
    }


    /* Prepare the value for for INSURED section */
     private static function getInsuredSection()
     {   
        $h_helper = new HealthHelper();
        $insured = [];
        // PED List
        foreach(self::$proposerInput['ped'] as $key => $value)
        {
            $ped_list[] = [
                'pedName' => $key,
                'pedCode' => self::$proposerInput[$key.'_code'],
                'exists'  => ($value)? 'Y' : 'N'
            ];
        }
        $reltionid = explode('|', self::$proposerInput['relationshipId']);
        foreach ($reltionid as $i => $relationship_id) 
        {
            if($relationship_id == 'WIFE' || $relationship_id == 'HUS'){ 
                $relationship_id = 'SPSE'; }

            $userType = $h_helper->getUserType(self::$proposerInput['dob'][$i]);

            // Updating Gender and Title for Self
            $gender_list = self::$proposerInput['gender'];
            $replacements = array(0 => self::$proposerInput['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            unset($gender['1']);
                if($gender['0'] == 'M') {
                  $title_list = self::$proposerInput['title'];
                  $replacements = array(0 => 'MR');
                  $title = array_replace($title_list, $replacements);
                }
                if($gender['0'] == 'F'){
                  $title_list = self::$proposerInput['title'];
                  $replacements = array(0 => 'MS');
                  $title = array_replace($title_list, $replacements);
                }
                $test = implode('|',$gender);
                $gender = explode('|',$test);

                if($i == '0'){
                    $idtype = isset(self::$proposerInput['pan']) ? 'PAN' : '' ;
                    $idnumber = isset(self::$proposerInput['pan']) ? strtoupper(self::$proposerInput['pan']) : '';
                }else{

                    $idtype = '';
                    $idnumber = '';
                }



            $insured [] = [
                'type'  => $userType,
                'title' => $title[$i],
                'firstName' => self::$proposerInput['firstname'][$i],
                'middleName' => '',
                'lastName'  => self::$proposerInput['lastname'][$i],
                'gender'    => $gender[$i],       
                'dob'       => self::getFormatedDate(self::$proposerInput['dob'][$i]),
                'relationshipId'  => $relationship_id,
                'idType' =>  $idtype,
                'idNumber' => $idnumber,
                'sumInsured'     => self::$proposerInput['floaterSI'],
                'pedList'  => $ped_list,
            ];         
        }
        return $insured;
    }  

    /* Prepare the value for for PROPOSER section */
     private static function getProposerSection()
     {

         // Updating Gender and Title for Self
            $gender_list = self::$proposerInput['gender'];
            $replacements = array(0 => self::$proposerInput['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            unset($gender['1']);
                if($gender['0'] == 'M') {
                  $title_list = self::$proposerInput['title'];
                  $replacements = array(0 => 'MR');
                  $title = array_replace($title_list, $replacements);
                }
                if($gender['0'] == 'F'){
                  $title_list = self::$proposerInput['title'];
                  $replacements = array(0 => 'MS');
                  $title = array_replace($title_list, $replacements);
                }
                $test = implode('|',$gender);
                $gender = explode('|',$test);

        $proposer = [
            'isPrimaryInsured' => self::$predefinedVal['is_primary_insured'],
            'title'            => $title[0],
            'firstName'        => self::$proposerInput['firstname'][0],
            'middleName'=> '',
            'lastName'         => self::$proposerInput['lastname'][0],            
            'gender'           => $gender[0],
            'proposerDob'  => self::getFormatedDate(self::$proposerInput['dob'][0]),
            'nomineeName'  => self::$proposerInput['nomineename'],
            'nomineeRel'   =>  self::$proposerInput['nomineerel'],
            'nomineeAge'   => self::$proposerInput['nomineeage'],
            'appointeeName' => isset(self::$proposerInput['appointeename']) ? self::$proposerInput['appointeename'] : '',
            'appointeeAge' => isset(self::$proposerInput['appointeeage']) ? self::$proposerInput['appointeeage'] : '',
            'appointeeRel' => isset(self::$proposerInput['appointeerel']) ? self::$proposerInput['appointeerel'] : '',
            'contacts' => [
                [ 'contactType' => 'mobile','contactText'   => self::$proposerInput["mobile"]], 
                [ 'contactType' => 'email', 'contactText'   => self::$proposerInput['email']]
            ], 
            'address' => [
                ['addressType' => self::$predefinedVal['address_type'],
                'addressLine1' => self::$proposerInput['houseno']. ' ' . self::$proposerInput['street'],
                  'addressLine2' => self::$proposerInput['street'],
                  'addressLine3' => self::$proposerInput['locality'],
                  'areaCode' => '',
                  'city'     => self::$proposerInput['city'],
                  'cityCode' => '',
                  'state'    => self::$proposerInput['state'],
                  'stateCode'=> '',
                  'pincode'  => self::$proposerInput['cust_pincode']
                ],
                [ 
                'addressType' => self::$predefinedVal['permanent_address_type'],
                'addressLine1'=> self::$proposerInput['houseno']. ' ' . self::$proposerInput['street'],
                'addressLine2'=> self::$proposerInput['street'],
                'addressLine3'=> self::$proposerInput['locality'],
                'areaCode'    => '',
                'city'        => self::$proposerInput['city'],
                'cityCode'    => '',
                'state'       => self::$proposerInput['state'],
                'stateCode'   => '',
                'pincode'     => self::$proposerInput['cust_pincode']
                ]
            ]
        ];
        return $proposer;
     }

     public static function getCoversSection($covers){
       $reltionid = explode('|', self::$proposerInput['relationshipId']);
       $covername = explode('|',$covers);
       $cover = [];
        foreach ($reltionid as $k => $relationship_id) 
        {
       $cover [] = [
                'name'  => $covername[$k],
                'si' => 'N'
            ]; 
        }
        return $cover;
     }


      public static function getFormatedDate( $date ) 
     {  
        return date('Y-m-d', strtotime(strtr($date, '/', '-')));
     } 
}
?>
