<?php

namespace App\Helpers\Health\Policy;

use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Constants\Health_Constants;
use App\Helpers\Health\HealthHelper;
use App\Be\Health\HealthPolicyBe;

class StarHealthHelper {
    
    public function getPolicy($user_data) {
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
        $sections = [] ;
        $h_helper = new HealthHelper();
        //$covers = $h_helper->getSessionValue('proposal_cover',$user_data['trans_code']);
        $sections['authentication'] = Health_Constants::AUTH;
        $sections['productId'] = $user_data['productId'];
        $sections['policy'] = $this->getPolicySection($user_data);
        $sections['insured'] = $this->getInsuredSection($user_data);
        $sections['proposer'] = $this->getProposerSection($user_data);
        $sections['covers'] = $this->set_covers($user_data['covers']);
        Log::info('Health Star Proposal Request', $sections);
        return $sections;
    }

    /*  Prepare the value for for POLICY section */
    private function getPolicySection($user_data){  
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
       //For individual
        $policy = ['floater' => 'N','productType' => $predefinedVal['product_type']['N']];
        //For family floater
        if($user_data['plan_type'] == 'FF') { 
            $policy['floater'] = 'Y';
            $policy['floaterSi'] = $user_data['floaterSI'];                
            $policy['productType'] =$predefinedVal['product_type'][$policy['floater']];  
        } 
        $policy['policyStartdate'] = $user_data['p_start'];
        $policy['policyEnddate'] = $user_data['p_ends'];
        $policy['tenure'] = ''.$predefinedVal['tenure'].'';
        $policy['numAdults'] =   $user_data['adults'];
        $policy['numChildren'] = $user_data['children'];
        // Policy details if any premium miss match
        if (isset($user_data['new_premium']) && !empty($user_data['new_premium'])){ 
            $basePremium = $user_data['new_premium'];}
        else{  $basePremium = $user_data['basePremium'];  }
        $basePremium = $basePremium;
        if (isset($user_data['new_service_tax']) && !empty($user_data['new_service_tax'])){ 
            $serviceTax = $user_data['new_service_tax'];
            $cgst = ($serviceTax / 2 );
            $sgst = ($serviceTax / 2 ); }
        else{ 
            $serviceTax = ($user_data['cgst'] + $user_data['sgst']);
            $cgst = $user_data['cgst'];
            $sgst = $user_data['sgst']; }
        $policy['basePremium'] = $basePremium;
        $policy['serviceTax'] = ''.$serviceTax.'';
        $policy['CGST'] = ''.$cgst.'';
        $policy['SGST'] = ''.$sgst.'';
        $policy['premiumPayable'] = ''.$basePremium + $serviceTax.'';
        $policy['paymentMode'] = $predefinedVal['payment_mode'];
        return $policy;
    }

    /* Prepare the value for for INSURED section */
    private function getInsuredSection($user_data) {  
        $predefinedVal = Health_Constants::PROPOSAL_POLICY; 
        $h_pol_be = new HealthPolicyBe();
        $h_helper = new HealthHelper();
        $insured = [];
        // PED List
        foreach($user_data['ped'] as $key => $value) {
            $ped_list[] = [
                'pedName' => $key,
                'pedCode' => $user_data[$key.'_code'],
                'exists'  => ($value)? 'Y' : 'N'
            ];
        }
        foreach ($user_data['relationshipId'] as $i => $relationship_id){
            if($relationship_id == 'SELF'){ $relationship_id = '1'; }
             // mediclassic
            if($user_data['productId'] == '129HL05I01') {
               if($relationship_id=='WIFE'||$relationship_id=='HUS'){ $relationship_id='2';}
               if($relationship_id=='SONM'||$relationship_id=='UDTR'){$relationship_id='3';}
               if($relationship_id=='FATH'||$relationship_id=='MOTH'){$relationship_id='4';}
            }
            //  FHO  
            if($user_data['productId'] == '129HL07F01'){
               if($relationship_id=='WIFE'||$relationship_id=='HUS'){$relationship_id='2';}
               if($relationship_id=='SONM'||$relationship_id=='UDTR'){$relationship_id='3';}
               if($relationship_id=='FATH'||$relationship_id=='MOTH'){$relationship_id='4';}
            }
           // comprensive 
            if($user_data['productId'] == '129HL01F01'){
                if($relationship_id=='WIFE'||$relationship_id=='HUS'){$relationship_id='2';}
                if($relationship_id=='SONM'||$relationship_id=='UDTR'){$relationship_id='3';}
                if($relationship_id=='FATH'||$relationship_id=='MOTH'){$relationship_id='4';}
            }
            // Red carpet 
            if($user_data['productId'] == '129HL08I01'){
                if($relationship_id=='WIFE'||$relationship_id=='HUS'){$relationship_id='3';}
                if($relationship_id=='SONM'){ $relationship_id = '12'; }
                if($relationship_id=='UDTR'){ $relationship_id = '15';}
                if($relationship_id=='FATH'){ $relationship_id = '4';}
                if($relationship_id=='MOTH'){ $relationship_id = '5'; }
            }  
            $userType = $h_helper->getUserType($user_data['dob'][$i]);
            $height = $h_pol_be->convert_feet_to_cm($user_data['feet'][$i],$user_data['inches'][$i]);
            if(isset($user_data['illnessBeforeTwelveMonths']) && $user_data['illnessBeforeTwelveMonths'] == '0')
            { $illness_before = 'Y'; } else{ $illness_before = 'NILL';}

            // Updating Gender and Title for Self
            $gender_list = $user_data['gender'];
            $replacements = array(0 => $user_data['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            unset($gender['1']);

            if($gender['0'] == 'M') {
                $title_list = $user_data['title'];
                $replacements = array(0 => 'MR');
                $title = array_replace($title_list, $replacements);
            }
            if($gender['0'] == 'F'){
                $title_list = $user_data['title'];
                $replacements = array(0 => 'MS');
                $title = array_replace($title_list, $replacements);
            }
                $test = implode(',',$gender);
                $gender = explode(',',$test);

            $insured [] = [
                'type'  => $userType,
                'title' => $title[$i],
                'firstName' => $user_data['firstname'][$i],
                'middleName' => '',
                'lastName'  => $user_data['lastname'][$i],
                'gender'    => $gender[$i],       
                'dob'       => $this->getFormatedDate($user_data['dob'][$i]),
                'relationshipId'  => $relationship_id,
                'occupationType'  => '',
                'height' => round(''.$height.''),
                'weight' => $user_data['weight'][$i],
                'illness' => '',
                'mannualLabour'=> 'NONE',
                'winterSports'=> 'NONE',
                'illnessBeforeTwelveMonths' => $illness_before,
                'sumInsured'     => $user_data['floaterSI'],
                'pedList'  => $ped_list,
            ];         
        }
        return $insured;
    }  

     /* Prepare the value for for PROPOSER section */

    private function getProposerSection($user_data) {
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
         // Updating Gender and Title for Self
        $gender_list = $user_data['gender'];
        $replacements = array(0 => $user_data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        unset($gender['1']);
        if($gender['0'] == 'M') {
            $title_list = $user_data['title'];
            $replacements = array(0 => 'MR');
            $title = array_replace($title_list, $replacements);
        }
        if($gender['0'] == 'F'){
            $title_list = $user_data['title'];
            $replacements = array(0 => 'MS');
            $title = array_replace($title_list, $replacements);
        }
        $test = implode(',',$gender);
        $gender = explode(',',$test);
        $proposer = [
            'isPrimaryInsured' => $predefinedVal['is_primary_insured'],
            'title'            => $title[0],
            'firstName'        => $user_data['firstname'][0],
            'middleName'=> '',
            'lastName'         => $user_data['lastname'][0],            
            'gender'           => $gender[0],
            'proposerDob'  => $this->getFormatedDate($user_data['dob'][0]),
            'nomineeName'  => $user_data['nomineename'],
            'nomineeRel'   =>  $user_data['nomineerel'],
            'nomineeAge'   => $user_data['nomineeage'],
            'appointeeName' => isset($user_data['appointeename']) ? $user_data['appointeename'] : '',
            'appointeeAge' => isset($user_data['appointeeage']) ? $user_data['appointeeage'] : '',
            'appointeeRel' => isset($user_data['appointeerel']) ? $user_data['appointeerel'] : '',

            'socialStatus'=> $user_data['social_status'],
            'socialStatusBpl'=>isset($user_data['below-poverty']) ? $user_data['below-poverty']: '0',
            'socialStatusUnorganized'=> isset($user_data['unorganized-sector']) ? $user_data['unorganized-sector']: '0' ,
            'socialStatusDisabled'=>isset($user_data['handicaped']) ? $user_data['handicaped']: '0',
            'socialStatusInformal'=> isset($user_data['informal-sector'])? $user_data['informal-sector']: '0',

            'contacts' => [
                [ 'contactType' => 'mobile','contactText'   => $user_data["mobile"]], 
                [ 'contactType' => 'email', 'contactText'   => $user_data['email']]
            ], 
            'address' => [
                ['addressType' => $predefinedVal['address_type'],
                'addressLine1' => $user_data['houseno'] . ' ' . $user_data['street'],
                  'addressLine2' => $user_data['street'],
                  'addressLine3' => $user_data['locality'],
                  'areaCode' => isset($user_data['cust_area']) ? $user_data['cust_area'] : '1234',
                  'city'     => $user_data['city'],
                  'cityCode' => '',
                  'state'    => $user_data['state'],
                  'stateCode'=> '',
                  'pincode'  => $user_data['cust_pincode']
                ]
            ]
        ];
        return $proposer;
    }

    private function set_covers($data){
        $cover_list = explode(',', $data);
            foreach ($cover_list as $value) {

                $covers[] = [
                    'name' => $value,
                    'si' =>'N'
                ];
            }

        return $covers;
    }


    private function getFormatedDate( $date ) {  
        return date('Y-m-d', strtotime(strtr($date, '/', '-')));
    }  
}

?>
