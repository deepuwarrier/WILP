<?php

namespace App\Helpers\Health\Policy;

use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Constants\Health_Constants;
use App\Helpers\Health\HealthHelper;
use App\Be\Health\HealthPolicyBe;


class UnisompoHelper {

    public function getPolicy($user_data) {
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
        $sections = [] ;
        $h_helper = new HealthHelper();
        $sections['authentication'] = Health_Constants::AUTH;
        $sections['productId'] = $user_data['product_id'];
        $sections['policy'] = $this->getPolicySection($user_data);
        $sections['insured'] = $this->getInsuredSection($user_data);
        $sections['proposer'] = $this->getProposerSection($user_data);
        $sections['covers'] = $this->set_covers($user_data['covers']);
        Log::info('Health Unisompo Proposal Request', $sections);
        return $sections;
    }

    /*  Prepare the value for for POLICY section */
    private function getPolicySection($user_data) { 

        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
       //For individual
        $policy = ['floater' => 'N','productType' => $predefinedVal['product_type']['N']];
        //For family floater
        if ($user_data['plan_type'] == 'FF') { 
            $policy['floater'] = 'Y';
            $policy['floaterSi'] = $user_data['floaterSI'];                
            $policy['productType'] = $predefinedVal['product_type'][$policy['floater']]; } 
        $policy['policyStartdate'] = date('Y-m-d', strtotime($user_data['p_start']));
        $policy['policyEnddate'] = date('Y-m-d', strtotime($user_data['p_ends']));
        $policy['tenure'] = ''.$predefinedVal['tenure'].'';
        $policy['numAdults'] =   $user_data['adults'];
        $policy['numChildren'] = $user_data['children'];
        // Policy details if any premium miss match
        if (isset($user_data['new_premium']) && !empty($user_data['new_premium'])) {
            $basePremium = $user_data['new_premium']; }
        else{  $basePremium = $user_data['basePremium']; }
        $basePremium = $basePremium;
        if (isset($user_data['new_service_tax']) && !empty($user_data['new_service_tax'])) {
            $serviceTax = $user_data['new_service_tax'];
            $cgst = ($serviceTax / 2 );
            $sgst = ($serviceTax / 2 ); }
        else{
            $serviceTax = ($user_data['cgst'] + $user_data['sgst']);
            $cgst = $user_data['cgst'];
            $sgst = $user_data['sgst']; }
        $policy['basePremium'] = $basePremium;
        $policy['serviceTax'] = ''.$serviceTax.'';
        $policy['CGST'] = ''.$cgst.'';
        $policy['SGST'] = ''.$sgst.'';
        $policy['premiumPayable'] = ''.$basePremium + $serviceTax.'';
        $policy['paymentMode'] = $predefinedVal['payment_mode'];
        $policy['eSaleDiscount'] = $predefinedVal['eSaleDiscount'];
        $policy['tieredHospitalDiscount'] = $predefinedVal['tieredHospitalDiscount'];
        return $policy;
    }

    /* Prepare the value for for INSURED section */
    private function getInsuredSection($user_data) {   
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
        $h_pol_be = new HealthPolicyBe();
        $h_helper = new HealthHelper();
        $insured = [];
        // PED List
        foreach($user_data['ped'] as $key => $value) {
            $ped_list[] = [
                'pedName' => $key,
                'pedCode' => $user_data[$key.'_code'],
                'exists'  => ($value)? 'Y' : 'N'
            ];
        }
        foreach ($user_data['relationshipId'] as $i => $relationship_id) {
            if($relationship_id == 'WIFE' || $relationship_id == 'HUS'){ 
                $relationship_id = 'Spouse'; }
            if($relationship_id == 'SELF') { $relationship_id = 'Self'; }
            if($relationship_id == 'SONM') { $relationship_id = 'Son'; }
            if($relationship_id == 'UDTR'){ $relationship_id = 'Daughter'; }
            $userType = $h_helper->getUserType($user_data['dob'][$i]);
            $height = $h_pol_be->convert_feet_to_cm($user_data['feet'][$i],$user_data['inches'][$i]);
            $bmi = $h_pol_be->BMI_calculation($height,$user_data['weight'][$i]);
            // Updating Gender and Title for Self
            $gender_list = $user_data['gender'];
            $replacements = array(0 => $user_data['gender']['1']);
            $gender = array_replace($gender_list, $replacements);
            unset($gender['1']);
                if($gender['0'] == 'M') {
                  $title_list = $user_data['title'];
                  $replacements = array(0 => 'MR');
                  $title = array_replace($title_list, $replacements);
                }
                if($gender['0'] == 'F'){
                  $title_list = $user_data['title'];
                  $replacements = array(0 => 'MS');
                  $title = array_replace($title_list, $replacements);
                }
                $test = implode('|',$gender);
                $gender = explode('|',$test);

            $insured [] = [
                'type'  => $userType,
                'title' => $title[$i],
                'firstName' => $user_data['firstname'][$i],
                'lastName'  => $user_data['lastname'][$i],
                'gender'    => $gender[$i],       
                'dob'       => $this->getFormatedDate($user_data['dob'][$i]),
                'relationshipId'  => $relationship_id,
                'occupationType'  => $user_data['occupation'][$i],
                'bmi'             =>  ''.$bmi.'',
                'nomineeName'     => $user_data['nomineename'],
                'nomineeRel'      => $user_data['nomineerel'],
                'bloodSugarLevel' => $user_data['blood_sugar_level'][$i],
                'bloodPressureSystolic'  => $user_data['bp_systolic'][$i],
                'bloodPressureDiastolic' => $user_data['bp_diastolic'][$i],
                'cholesterolLevel'       => $user_data['cholesterol_level'][$i],
                'tobacoAcohol'   => "",
                'comorbidity'    => 'N',
                'sumInsured'     => $user_data['floaterSI'],
                'pedList'  => $ped_list,
            ];         
        }
        return $insured;
    }  

    /* Prepare the value for for PROPOSER section */
    private function getProposerSection($user_data) {
        $predefinedVal = Health_Constants::PROPOSAL_POLICY;
         // Updating Gender and Title for Self
        $gender_list = $user_data['gender'];
        $replacements = array(0 => $user_data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        unset($gender['1']);
        if($gender['0'] == 'M') {
            $title_list = $user_data['title'];
            $replacements = array(0 => 'MR');
            $title = array_replace($title_list, $replacements);
        }
        if($gender['0'] == 'F'){
            $title_list = $user_data['title'];
            $replacements = array(0 => 'MS');
            $title = array_replace($title_list, $replacements);
        }
        $test = implode('|',$gender);
        $gender = explode('|',$test);
        $proposer = [
            'isPrimaryInsured' => $predefinedVal['is_primary_insured'],
            'title'            => $title[0],
            'firstName'        => $user_data['firstname'][0],
            'lastName'         => $user_data['lastname'][0],            
            'gender'           => $gender[0],
            'proposerDob'  => $this->getFormatedDate($user_data['dob'][0]),
            'nomineeName'  => $user_data['nomineename'],
            'nomineeRel'   =>  $user_data['nomineerel'],
            'nomineeAge'   => $user_data['nomineeage'],
            'appointeeName' => isset($user_data['appointeename']) ? $user_data['appointeename'] : '',
            'appointeeAge' => isset($user_data['appointeeage']) ? $user_data['appointeeage'] : '',
            'appointeeRel' => isset($user_data['appointeerel']) ? $user_data['appointeerel'] : '',
            'contacts' => [
                [ 'contactType' => 'mobile','contactText'   => $user_data["mobile"]], 
                ['contactType'  => 'homeTel', 'contactText' => '' ],
                [ 'contactType' => 'email', 'contactText'   => $user_data['email']]
            ], 
            'address' => [
                ['addressType' => $predefinedVal['address_type'],
                'addressLine1' => $user_data['houseno'] . ' ' . $user_data['street'],
                  'addressLine2' => $user_data['street'],
                  'addressLine3' => $user_data['locality'],
                  'areaCode' => '',
                  'city'     => $user_data['city'],
                  'cityCode' => '',
                  'state'    => $user_data['state'],
                  'stateCode'=> '',
                  'pincode'  => $user_data['cust_pincode']
                ],
                [ 
                'addressType' => $predefinedVal['permanent_address_type'],
                'addressLine1'=> $user_data['houseno'].' '.$user_data['street'],
                'addressLine2'=> $user_data['street'],
                'addressLine3'=> $user_data['locality'],
                'areaCode'    => '',
                'city'        => $user_data['city'],
                'cityCode'    => '',
                'state'       => $user_data['state'],
                'stateCode'   => '',
                'pincode'     => $user_data['cust_pincode']
                ]
            ]
        ];
        return $proposer;
    }

    private function set_covers($data){
        $cover_list = explode('|', $data);
            foreach ($cover_list as $value) {

                $covers[] = [
                    'name' => $value,
                    'si' =>'N'
                ];
            }

        return $covers;
    }
    
    private function getFormatedDate( $date ) {  
        return date('Y-m-d', strtotime(strtr($date, '/', '-')));
    }           
}
?>