<?php

namespace App\Helpers\Health;

use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Log;

class QuoteHelper {
   
    public function getQuotes($data) { 
        Log::info("Health LastDecimal Quote Request :",$data);
        $auth_user = 'TTIBI'; $auth_pass = 'TTIBI';
        $lob = 'Health';
        $age = explode('|' , $data['agelist']);
        $dob = explode('|' , $data['doblist']);
        $gender = explode('|', $data['genderlist']);

        foreach($age as $ageli){
            if($ageli == '10m' || $ageli == '3m'){ $agelist[] ='0'; }
            else { $agelist[] = $ageli;  }
        }
        $memberlist = $data['memberslist'];
        try{
            // Guzzle API request and response  
            $client = new Client(['headers' => [ 'Content-Type' => 'application/json']]);
            $response = $client->post('http://api.brokeredge.in/rest/quote/allquotes/'.$lob.'/'.$data['productType'].'',
            ['body' => json_encode([
                'authentication' => [
                    'accesskey' =>  $auth_user,
                    'secretkey' => $auth_pass
                    ],
                    'doblist' => implode(',', $dob),
                    'agelist' => implode(',', $agelist),
                    'pincode' => $data['pincode'],
                    'tenure' => $data['tenure'],
                    'adult' => $data['adult'],
                    'children' => $data['children'],
                    'genderlist' => implode(',', $gender),
                    'sa' => $data['sa']
                ])
            ]);
            Log::info("Health LastDecimal Quote Response : ".$response->getBody());
            $obj = json_decode($response->getBody(), true);
        }catch (\Exception $e) {
            Log::error($e);
        } 
        if(isset($obj['result'])) {
            // remove quote if online policy is false
            foreach($obj['result'] as $key => $value){ 
                if($value['online'] == false){
                    unset($obj['result'][$key]); 
                }
                if($value['insurerId'] == 'hdfc'){
                    unset($obj['result'][$key]);
                }
            }    
        // Individual plan for Bharti AXA and HDFC is not available hiding from response 
        if($data['productType'] == 'INDV') {
            foreach($obj['result'] as $key => $value ){ 
                  // hide unisompo for dependent parents
                $members = explode('|', $memberlist);
                foreach($members as $mem){
                    if($value['insurerId'] == '134' && ($mem == 'FATH' || $mem == 'MOTH')){
                        unset($obj['result'][$key]); }
                }
                if($value['insurerId'] == 'hdfc' && $data['sa'] < '400000'){
                    unset($obj['result'][$key]); }
                // Hide Bharti Axa Quote
                if($value['insurerId'] == '139'){
                    unset($obj['result'][$key]);  }
                //  Hide Bajaj Quote
                if($value['insurerId'] == '113'){
                    unset($obj['result'][$key]); }
                    // HDFC 
                if($value['insurerId'] == '125'){
                    unset($obj['result'][$key]); }
                    // Religare
                if($value['insurerId'] == '148'){
                    unset($obj['result'][$key]); }
                     // Star
                if($value['insurerId'] == '129'){
                    unset($obj['result'][$key]); }
            }
        }
        // Floater plan for HDFC is not available hiding from response 
         if($data['productType'] == 'FF') 
        {   
            foreach($obj['result'] as $key => $value ){ 
                // hide unisompo for dependent parents
                $members = explode('|', $memberlist);
                foreach($members as $mem){
                    if($value['insurerId'] == '134' && ($mem == 'FATH' || $mem == 'MOTH')){
                        unset($obj['result'][$key]);  }
                }
                foreach($members as $mem){
                    if($value['insurerId'] == '139' && ($mem == 'FATH' || $mem == 'MOTH')){
                        unset($obj['result'][$key]);  }
                }
                if($value['insurerId'] == 'hdfc' && $data['sa'] < '300000'){
                    unset($obj['result'][$key]);  }
                //  Hide Bajaj Quote
                if($value['insurerId'] == '113'){
                    unset($obj['result'][$key]); }
                    // HDFC
                    if($value['insurerId'] == '125'){
                    unset($obj['result'][$key]); }
                    // Religare
                if($value['insurerId'] == '148'){
                    unset($obj['result'][$key]); }
                     // Star
                if($value['insurerId'] == '129'){
                    unset($obj['result'][$key]); }
            }
        }
            return $obj['result'];
        }else{
            return 'Error';
        }
    }
}

?>
