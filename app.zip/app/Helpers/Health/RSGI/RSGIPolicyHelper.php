<?php
namespace App\Helpers\Health\RSGI;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Be\Health\RSGIBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class RSGIPolicyHelper {

	public function __construct() {
    }

    public function get_proposal_response($proposal_req_data){ 
        $rsgi_be = new RSGIBe();
       	$populated_request = $rsgi_be->populate_proposal_request($proposal_req_data);
        $proposal_response = $this->call_proposal_api($populated_request, $proposal_req_data->get_hl_trans_code());
        if(!empty($proposal_response)){
            $parse_response = $rsgi_be->parse_proposal_response($proposal_response,$proposal_req_data);
            return $parse_response;
        } 
        return null;
    }


    private function call_proposal_api($populated_request, $hl_trans_code){
        Log::info('Health RSGI Proposal Request - '.$hl_trans_code.''.$populated_request);
        $url = Health_Constants::RSGI_PROPOSAL_URL;
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/xml' ]]);
            $request = $client->post($url, ['body' => $populated_request]);
            $response = $request->getBody()->getContents();
            $xml_response = json_encode(simplexml_load_string($response)) or die("Error: Cannot create object");
            // Convert Xml response to Array format
            $res_data = json_decode($xml_response, true);
            Log::info('Health RSGI Proposal Response - '.$hl_trans_code.'', ['response'=>$res_data]);
        }catch (\Exception $e) {
            Log::error($e);
        }
        if($res_data['Result']['statusCode'] == 'S-001'){ 
            return $res_data; }
        else{  
            return $res_data['Result']['message']; 
        }
    }
}
?>
