<?php
namespace App\Helpers\Health\RSGI;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Be\Health\RSGIBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class RSGIQuoteHelper {

	public function __construct() {
    }

   	public function get_quote($quote_req_data){ 
        $rsgi_be = new RSGIBe();
        $product_map = $rsgi_be->product_map($quote_req_data);
        $rsgi_plans = $this->set_available_plans($product_map); 
           if(!empty($rsgi_plans)){  
                foreach($rsgi_plans as $plans){
                    $quote_req_data->set_rsgi_plans($plans);
                    $populated_request[] = $rsgi_be->populate_quote_request($quote_req_data);
                }
            } 
            if(isset($populated_request)){
                foreach ($populated_request as $req_data) {
                    $quote_response =$this->call_quote_api($req_data,$quote_req_data->get_trans_code());
                    $parse_response[] = $rsgi_be->parse_quote_response($quote_response,$req_data,$quote_req_data);
                }
                if(!empty($parse_response) && $parse_response[0] !== null){
                return $parse_response;
                }else { return null; }
            }
        return null;
    }


    private function call_quote_api($populated_request, $hl_trans_code){
        $xml = $populated_request['xml'];
        $url = Health_Constants::RSGI_PREMIUM_CALCULATION_URL;
        Log::info('Health RSGI Quote Request - '.$hl_trans_code.'', ['request'=>$xml]);
        try{
            $client = new Client(['verify' => false, 'headers' => ['Content-Type' => 'application/xml']]);
            $request = $client->post($url, ['body' => $xml ] );
            $response = $request->getBody()->getContents();
            $xml_response = json_encode(simplexml_load_string($response)) or die("Error: Cannot create object");
            // Convert Xml response to Array format
            $res_data = json_decode($xml_response, true);
            Log::info('Health RSGI Quote Response - '.$hl_trans_code.'', ['response'=>$res_data]);
        }catch (\Exception $e) {
            Log::error($e);
        }

        if(isset($res_data['Result']['statusCode']) && $res_data['Result']['statusCode'] == 'S-001'){
            return $res_data;
        }else{ 
            if(isset($res_data['Result']['statusCode']) && $res_data['Result']['statusCode'] == 'E-0508'){
                $input['city'] = 'BENGALURU';
                $check_values = array('trans_code'=>$populated_request['trans_code']);
                $user_db = new HealthUserData();
                $user_db->set_by_usrdata($input, $check_values);
            }
        return 'Error'; }
    }


    private function set_available_plans($product_map){
        $avl_plans = null;
        foreach($product_map as $key => $plans){
             if(!empty($plans)){
                $avl_plans[] = $key;
             }
        }
        return $avl_plans;
    }
}
?>
