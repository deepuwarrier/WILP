<?php
namespace App\Helpers\Health\RSGI;
use App\Constants\Health_Constants;
use App\Libraries\HealthLib;
use App\Models\Health\HealthUserData;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use DOMDocument;

class RsgiHelper {

    public function callRSGIquoteAPI($postFields) {  
        $usertdata = new HealthUserData();
        $rsgi_rel_mem = explode('|',$postFields['members']);
        $url = Health_Constants::RSGI_PREMIUM_CALCULATION_URL;

        $xml = '<?xml version="1.0" encoding="UTF-8"?><CalculatePremiumRequest><calculatePremiumData><coverageType>'.$postFields['coverageType'].'</coverageType><noOfPersons>'.$postFields['noOfPersons'].'</noOfPersons><noOfAdults>'.$postFields['noOfAdults'].'</noOfAdults><noOfChilds>'.$postFields['noOfChilds'].'</noOfChilds><elderMemberDob>'.$postFields['elderMemberDob'].'</elderMemberDob><planType>'.$postFields['planType'].'</planType><sumInsured>'.$postFields['sumInsured'].'</sumInsured><city>'.$postFields['city'].'</city><periodOfInsurance>'.$postFields['periodOfInsurance'].'</periodOfInsurance><hospitalCashbenefitOpted>'.$postFields['hospitalCashbenefitOpted'].'</hospitalCashbenefitOpted><opttopupOpted>'.$postFields['opttopupOpted'].'</opttopupOpted><deductibleAmount>'.$postFields['deductibleAmount'].'</deductibleAmount><internationalTreatmentOpted>'.$postFields['internationalTreatmentOpted'].'</internationalTreatmentOpted></calculatePremiumData><proposerDetailsData><firstName>'.$postFields['firstName'].'</firstName><mobileNumber>'.$postFields['mobileNumber'].'</mobileNumber><emailId>'.$postFields['emailId'].'</emailId></proposerDetailsData><authenticationData><apikey>'.$postFields['apikey'].'</apikey><agentId>'.$postFields['agentId'].'</agentId></authenticationData><process>calculatePremium</process></CalculatePremiumRequest>';

            Log::info('Health RSGI Quote Request.', ['request'=>$xml]);
        try{
            $client = new Client(['verify' => false, 'headers' => ['Content-Type' => 'application/xml']]);
            
            $request = $client->post($url, ['body' => $xml ] );
            $response = $request->getBody()->getContents();
            $xml_response = json_encode(simplexml_load_string($response)) or die("Error: Cannot create object");
            // Convert Xml response to Array format
            $res_data = json_decode($xml_response, true);
            Log::info('Health RSGI Quote Response.', ['response'=>$res_data]);
        }catch (\Exception $e) {
            Log::error($e);
        }  
        
        if(isset($res_data['Result']['statusCode']) && $res_data['Result']['statusCode'] == 'S-001'){
            return $res_data;
        }else{ 
            if(isset($res_data['Result']['statusCode']) && $res_data['Result']['statusCode'] == 'E-0508'){
                $input['city'] = 'BENGALURU';
                $check_values = array('trans_code'=>$postFields['trans_code']);
                $usertdata->update_data($input, $check_values);
            }
        return 'Error'; }
    }

}
?>
