<?php
namespace App\Helpers\Health\RSGI;
use App\Http\Controllers\Health\HealthPolicy;
use App\Be\Health\HealthQuoteBe;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use Log;

class SetQuoteHelper
{ 
    public function __construct(){ 
    }
  
    public function set_RSGI_data($data){ 
        $quote_be = new HealthQuoteBe();
        // RSGI Super TopUp opted
        if($data['product_type'] === 'S'){ 
            $data['sum_insured'] = $quote_be->get_deductables($data['deductables'],$data['sum_insured'],'rsgi_code');
            $data['topup'] = 'On';
        }
        // RSGI Basic Plans 
        $plan_type = $this->rsgi_plans($data['sum_insured']);
        
        $pl = array();
        if(isset($plan_type) && !empty($plan_type)){
            foreach($plan_type as $plan){
                $rsgiplans[] = $this->set_rsgi_plans($data, $plan);
            }
            return $rsgiplans;
        }
        else{ return 'Null'; }
    }


    private function set_rsgi_plans($data, $plan_type){
        $members = $this->calculate_adults_childs_age($data['age_list'],$data['members_list']);
        $user_data = $this->set_proposerDetailsData($data);
        // Calculate elder member dob from age list
        $elder_age = max(explode('|', $data['age_list']));
        $elderMemberDob = date("d/m/Y", strtotime($elder_age. 'years ago'));
        if(!empty($data['rsgi_hosp_cash'])){ 
            $hospitalcash = $data['rsgi_hosp_cash']; } else{
            $hospitalcash = 'off'; }
        $rsgi_req['trans_code'] = $data['trans_code']; 
        $rsgi_req['coverageType'] = $user_data['coverageType']; 
        $rsgi_req['noOfPersons'] = count(explode('|',$data['members_list']));
        $rsgi_req['members'] = $data['members_list']; 
        $rsgi_req['noOfAdults'] = $members['adult']; 
        $rsgi_req['noOfChilds'] = $members['children']; 
        $rsgi_req['elderMemberDob'] = $elderMemberDob; 
        $rsgi_req['planType'] = $plan_type; 
        $rsgi_req['sumInsured'] = $data['sum_insured']; 
        $rsgi_req['city'] = $user_data['city'];
        $rsgi_req['periodOfInsurance'] = $data['tenure'];  
        $rsgi_req['hospitalCashbenefitOpted']=$hospitalcash; 
        $rsgi_req['opttopupOpted']= isset($data['topup']) ? $data['topup'] : 'off'; 
        $rsgi_req['deductibleAmount']= (isset($data['deductables']) && $data['deductables'] !== "") ? $data['deductables'] : '0'; 
        $rsgi_req['internationalTreatmentOpted']='off'; 
        $rsgi_req['firstName'] = $user_data['firstname']; 
        $rsgi_req['mobileNumber']= $user_data['mobile'];
        $rsgi_req['emailId']=$user_data['email'];  
        $rsgi_req['apikey'] =  Health_Constants::RSGI_APIKEY;
        $rsgi_req['agentId'] = Health_Constants::RSGI_AgentID;
        return $rsgi_req;
    }

    private function set_proposerDetailsData($data){
        if(!empty($data['city'])){ $prop['city'] = $data['city']; } 
        else { $prop['city'] = 'Bengaluru'; }
        if(!empty($data['firstname'])){ 
            $first_name = explode('|',$data['firstname']);
            $prop['firstname'] = $first_name['0']; } else{ $prop['firstname'] = 'Rashmi'; 
        }
        if(!empty($data['mobile'])){ $prop['mobile'] = $data['mobile']; } else{ $prop['mobile'] ='7899000333'; }
        if(!empty($data['email'])){ $prop['email'] = $data['email'];} else{ $prop['email'] ='rashmi@instainsure.com'; }
        if($data['plan_type'] == 'INDV'){ $prop['coverageType'] = 'individual';} else {$prop['coverageType'] = 'familyfloater' ; }
        return $prop;
    }

    private function rsgi_plans($sum_insured){
        $plan_type = array();
        
        if($sum_insured == '200000' || $sum_insured == '300000' || $sum_insured == '400000'){ $plan_type[] = 'Classic'; }
        if($sum_insured == '500000' || $sum_insured == '1000000' || $sum_insured == '1500000' || $sum_insured == '2000000' || $sum_insured == '5000000')
            { $plan_type[] = 'Supreme'; }
        if($sum_insured == '2500000' || $sum_insured == '3000000' || $sum_insured == '5000000' || $sum_insured == '10000000' || $sum_insured == '15000000')
            { $plan_type[] = 'Elite';  }
        if(isset($plan_type) && !empty($plan_type))
            { return $plan_type; }
    } 

    public function calculate_adults_childs_age($age_list, $mem_list){
        $agelist = explode('|',$age_list);
        $memlist = explode('|',$mem_list);
        $adult = $children = 0;
        for($i=0; $i<sizeof($memlist);$i++){
            if($memlist[$i] == 'WIFE' || $memlist[$i] == 'HUS' || $memlist[$i] == 'MOTH' || $memlist[$i] == 'FATH'){
                $member[] = 'adult';
                $adult++;
            }elseif($memlist[$i] == 'SELF' && $agelist[$i] >=18 ){
                $member[] = 'adult';
                $adult++;
            }elseif(($memlist[$i] == 'SONM' || $memlist[$i] == 'UDTR') && $agelist[$i] > 21){
                $member[] = 'adult';
                $adult++;
            }else{
                $member[] = 'child';
                $children++;
            }
        }
        $res['member'] = $member;
        $res['adult'] = $adult;
        $res['children'] = $children;
        return $res;
    }
}
