<?php
namespace App\Helpers\Health\Reliance;
use App\Constants\Health_Constants;
use App\Be\Health\RelianceBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class ReliancePolicyHelper {

    public function __construct() {
    }

    public function get_proposal_response($proposal_req_data){ 
        $reliance_be = new RelianceBe();
       	$populated_request = $reliance_be->populate_proposal_request($proposal_req_data);
        $proposal_response = $this->call_proposal_api($populated_request, $proposal_req_data->get_hl_trans_code());
        $parse_response =$reliance_be->parse_proposal_response($proposal_response,$proposal_req_data);
        return $parse_response;
    }

    

	public function call_proposal_api($populated_request, $hl_trans_code){
		$url = Health_Constants::RELIANCE_PROPOSAL_URL;
        Log::info('Health RELIANCE Proposal Request -'.$hl_trans_code.'', ['request'=>$populated_request]);
        try{
            $client = new Client(['verify' => false, 'headers' => ['Content-Type' => 'application/xml']]);
            $request = $client->post($url, ['body' => $populated_request ] );
            $response = $request->getBody()->getContents();
            $xml_response = json_encode(simplexml_load_string($response)) or die("Error: Cannot create object");
            // Convert Xml response to Array format
            $res_data = json_decode($xml_response, true);
            Log::info('Health RELIANCE Proposal Response -'.$hl_trans_code.'', ['response'=>$res_data]);
            return $res_data; 
        }catch (\Exception $e) {
            Log::error($e);
        }

	}
}
  
