<?php
namespace App\Helpers\Health\Reliance;
use App\Constants\Health_Constants;
use App\Be\Health\RelianceBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class RelianceQuoteHelper {

    public function __construct() {
    }

    public function get_quote($quote_req_data){ 
    if($quote_req_data->get_product_type() == 'B'){
        $reliance_be = new RelianceBe();
        $product_map = $reliance_be->product_map($quote_req_data);
        $reliance_plans = $this->set_available_plans($product_map);
        if(!empty($reliance_plans)){  
                foreach($reliance_plans as $plans){
                    $quote_req_data->set_reliance_plans($plans);
                    $populated_request[] = $reliance_be->populate_quote_request($quote_req_data);
                }
            } 
        if(isset($populated_request)){
            foreach ($populated_request as $req_data) {
                $quote_response = $this->call_quote_api($req_data, $quote_req_data->get_trans_code());
                $parse_response[] = $reliance_be->parse_quote_response($quote_response,$req_data,$quote_req_data);
            }
            if(!empty($parse_response)){
                return $parse_response;
            }else { return null; }
        }
    }
        return null;
    }

    private function call_quote_api($populated_request, $hl_trans_code){
        $url = Health_Constants::RELIANCE_PREMIUM_URL;
        Log::info('Health RELIANCE Quote Request - '.$hl_trans_code.'', ['request'=>$populated_request]);
        try{
            $client = new Client(['verify' => false, 'headers' => ['Content-Type' => 'application/xml']]);
            $request = $client->post($url, ['body' => $populated_request ] );
            $response = $request->getBody()->getContents();
            $xml_response = json_encode(simplexml_load_string($response)) or die("Error: Cannot create object");
            // Convert Xml response to Array format
            $res_data = json_decode($xml_response, true);
            Log::info('Health RELIANCE Quote Response - '.$hl_trans_code.'', ['response'=>$res_data]);
            return $res_data; 
        }catch (\Exception $e) {
            Log::error($e);
        }
    }


    private function set_available_plans($product_map){
        $avl_plans = null;
        foreach($product_map as $key => $plans){
             if(!empty($plans)){
                $avl_plans[] = $key;
             }
        }
        return $avl_plans;
    }
}
  
