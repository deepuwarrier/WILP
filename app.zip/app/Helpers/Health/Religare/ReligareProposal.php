<?php
namespace App\Helpers\Health\Religare;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use Illuminate\Http\Request;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\ReligareBe;
use SoapClient;
use SoapFault;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\File;
use Log;
use DateTime;

class ReligareProposal{

    public function get_policy($trans_code){
        $bl = new ReligareBe;
        $request_xml = $bl->set_policy($trans_code);
        return $this->callApi($request_xml);
    }

    public function get_policy_pdf($policy_number){
        $xml_post_string = '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">
          <S:Header />
          <S:Body>
            <ns2:GET_PDF xmlns:ns2="http://web.com/">
              <policyNo>'.$policy_number.'</policyNo>
              <ltype>POLSCHD</ltype>
            </ns2:GET_PDF>
          </S:Body>
        </S:Envelope>';        
        try{
            $username  = Health_Constants::RELIGARE_PDF_USERNAME;  
            $password = Health_Constants::RELIGARE_PDF_PASSWORD;
            $soap_req = curl_init();
            curl_setopt($soap_req, CURLOPT_URL, Health_Constants::RELIGARE_PDF_URL); 
            curl_setopt($soap_req, CURLOPT_CONNECTTIMEOUT, 90);
            curl_setopt($soap_req, CURLOPT_TIMEOUT, 90);
            curl_setopt($soap_req, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
            curl_setopt($soap_req, CURLOPT_USERPWD, "$username:$password");
            curl_setopt($soap_req, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($soap_req, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($soap_req, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($soap_req, CURLOPT_POST, true);
            curl_setopt($soap_req, CURLOPT_POSTFIELDS, $xml_post_string);
            curl_setopt($soap_req, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/soap+xml; charset=utf-8',
            'Content-Length: ' . strlen($xml_post_string)
        ));
            $result = curl_exec($soap_req);
            $err    = curl_error($soap_req);

        }catch (\Exception $e){
            Log::info('HEALTH_RELIGARE_PDF_RESPONSE_PARSING' .  print_r($e->getMessage(),true));
        }
        
        $bl = new ReligareBe;
        if($data = $bl->parse_pdf_response($result)){ 
            return $data;
        }
        return false;
    }

    private function callApi($request_xml){   
        Log::info('HEALTH_RELIGARE_PROPOSAL_REQUEST'. print_r($request_xml,true));
        try{
            $client   = new Client();
            $soap_req = curl_init();
            curl_setopt($soap_req, CURLOPT_URL, Health_Constants::RELIGARE_PROPOSAL_URL); 
            curl_setopt($soap_req, CURLOPT_CONNECTTIMEOUT, 90);
            curl_setopt($soap_req, CURLOPT_TIMEOUT, 90);
            curl_setopt($soap_req, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($soap_req, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($soap_req, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($soap_req, CURLOPT_POST, true);
            curl_setopt($soap_req, CURLOPT_POSTFIELDS, $request_xml);
            curl_setopt($soap_req, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/soap+xml; charset=utf-8',
            'Content-Length: ' . strlen($request_xml)
        ));
            $result = curl_exec($soap_req);
            $err    = curl_error($soap_req);

        }catch (\Exception $e){
            return array('status' => 0, 'mismatch' => 0, 'error' => 0);
        }
        
        if ($result === false) {
            // Close handle
            curl_close($soap_req);
            Log::info('HEALTH_RELIGARE_PROPOSAL_REQUEST' .$err);
            return array('status' => 0, 'ppc_data'=> false, 'mismatch' => 0, 'error' => 0);
        } else {
            // Close handle
            curl_close($soap_req);
            Log::info('HEALTH_RELIGARE_PROPOSAL_RESPONSE'. print_r($result,true));
            $bl = new ReligareBe;
            return $bl->parse_proposal_response($result);
        } 

    }    

}