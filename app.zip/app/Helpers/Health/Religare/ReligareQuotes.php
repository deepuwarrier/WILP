<?php
namespace App\Helpers\Health\Religare;
use App\Libraries\HealthLib;
use App\Constants\Health_Constants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use App\Be\Health\ReligareBe;
use Log;

class ReligareQuotes{ 
  public function get_quotes($data){ 
    $agelist  = explode(',',$data['age_list']);
    $rel      = explode(',',$data['members_list']);
    $bl       = new ReligareBe;
    if($bl->age_range($agelist,$rel)){
    		return $bl->calculate_quote($data);
    }else{
	   return null;
	  }
  }
}  