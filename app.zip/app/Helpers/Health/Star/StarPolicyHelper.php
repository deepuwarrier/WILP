<?php
namespace App\Helpers\Health\Star;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Be\Health\StarBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class StarPolicyHelper {

	public function __construct() {
    }

    public function get_proposal_response($proposal_req_data){ 
        $star_be = new StarBe();
       	$populated_request = $star_be->populate_proposal_request($proposal_req_data);
        $proposal_response = $this->call_proposal_api($populated_request, $proposal_req_data->get_hl_trans_code());
        if(!empty($proposal_response)){
            $parse_response = $star_be->parse_proposal_response($proposal_response,$proposal_req_data);
            return $parse_response;
        } 
        return null;
    }

    private function call_proposal_api($populated_request, $hl_trans_code){
        Log::info('Health Star Proposal Request - '.$hl_trans_code.''.$populated_request);
        $url = Health_Constants::STAR_PROPOSAL_URL;
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/json']]);
            $request = $client->post($url, ['body' => $populated_request]);
            $response = $request->getBody()->getContents();
            Log::info('Health Star Proposal Response - '.$hl_trans_code.''.$response);
            return json_decode($response);
        }catch (\Exception $e) {
            Log::error($e);
        }
    }


    public function policy_token_api($referenceId){
        $data = [
            'APIKEY' => Health_Constants::STAR_APIKEY,
            'SECRETKEY' => Health_Constants::STAR_SECRETKEY,
            'referenceId' => $referenceId
        ];
        $request_data = json_encode($data);
        Log::info("Health Star Policy Token Request : ".$request_data);
        $url = Health_Constants::STAR_TOKEN_URL.'/'.$referenceId.'/token';
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/json']]);
            $request = $client->post($url, ['body' => $request_data]);
            $response = $request->getBody()->getContents();
            Log::info("Health Star Policy Token Response : ".$response);
            return json_decode($response);
        }catch (\Exception $e) {
            Log::error($e);
        }
    }


    public function policy_purchase_status_api($purchase_token){
        $data = [
            'APIKEY' => Health_Constants::STAR_APIKEY,
            'SECRETKEY' => Health_Constants::STAR_SECRETKEY,
            'purchaseToken' => $purchase_token
        ];
        $request_data = json_encode($data);
        Log::info("Health Star Policy Purchase Status Request : ".$request_data);
        $url = Health_Constants::STAR_POLICY_STATUS_URL.'/'.$purchase_token.'/purchase/response';
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/json']]);
            $request = $client->post($url, ['body' => $request_data]);
            $response = $request->getBody()->getContents();
            Log::info("Health Star Policy Purchase Status Response : ".$response);
            return json_decode($response);
        }catch (\Exception $e) {
            Log::error($e);
        }
    }


    public function policy_schedule_api($referenceId){
        $data = [
            'APIKEY' => Health_Constants::STAR_APIKEY,
            'SECRETKEY' => Health_Constants::STAR_SECRETKEY,
            'referenceId' => $referenceId
        ];
        $request_data = json_encode($data);
        Log::info("Health Star Policy Schedule Request : ".$request_data);
        $url = Health_Constants::STAR_POLICY_SCHEDULE_URL.'/'.$referenceId.'/schedule';
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/json']]);
            $request = $client->post($url, ['body' => $request_data]);
            $response = $request->getBody()->getContents();
        

            Log::info("Health Star Policy Schedule Response : ".$response);
            return json_decode($response);
        }catch (\Exception $e) {
            Log::error($e);
        }
    } 

}
?>
