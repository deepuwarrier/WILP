<?php
namespace App\Helpers\Health\Star;
use App\Models\Health\HealthUserData;
use App\Constants\Health_Constants;
use App\Models\Health\data\QuoteReqData;
use App\Be\Health\StarBe;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;
use Log;

class StarQuoteHelper {

	public function __construct() {
    }

    public function get_quote($quote_req_data){ 
        $star_be = new StarBe();
        if($quote_req_data->get_product_type() == 'B'){
            $product_map = $star_be->product_map($quote_req_data);
            $star_plans = $this->set_available_plans($product_map);
            if(!empty($star_plans)){  
                foreach($star_plans as $plans){
                    $quote_req_data->set_star_plans($plans);
                    $populated_request[] = $star_be->populate_quote_request($quote_req_data);
                }
            } 
            if(isset($populated_request)){
                foreach ($populated_request as $req_data) {
                    $quote_response =$this->call_quote_api($req_data,$quote_req_data->get_trans_code());
                    $parse_response[] = $star_be->parse_quote_response($quote_response,$req_data,$quote_req_data);
                }
                if(!empty($parse_response)){
                return $parse_response;
                }else { return null; }
            }
        }   
        return null;
       
    }


    private function call_quote_api($populated_request, $hl_trans_code){
        Log::info("Health Star Quote Request - ".$hl_trans_code."".$populated_request);
        $url = Health_Constants::STAR_PREMIUM_CALCULATION_URL;
        try{
            $client = new Client(['verify' => false, 'headers' => [ 'Content-Type' => 'application/json']]);
            $request = $client->post($url, ['body' => $populated_request]);
            $response = $request->getBody()->getContents();
            Log::info("Health Star Quote Response - ".$hl_trans_code."".$response);
            return json_decode($response);
        }catch (\Exception $e) {
            Log::error($e);
        }
    }


    private function set_available_plans($product_map){
        $avl_plans = null;
        foreach($product_map as $key => $plans){
             if(!empty($plans)){
                $avl_plans[] = $key;
             }
        }
        return $avl_plans;
    }
}
?>
