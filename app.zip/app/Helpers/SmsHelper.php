<?php

namespace App\Helpers;
use App\Constants\Common_Constants;

class SmsHelper
{
	
	function __construct()
	{
		$this->authkey = '144436ANRojLkxlCea58c23479';
		$this->senderId  = 'instai';
		$this->route = 99;
		$this->title = 'Insta Insure';
	}

	function genrateOtp($mobile,$password_length = 8){
		$password = $this->genratePassword($password_length);
		session(['otp'=>$password]);
		// For Producation
		$data = $this->sendSms($mobile,'your verification code '.$password);
		
		// For UAT
	//	\Log::info('_otp = '.$password);
	//	$data = ['status'=>1,'_otp'=>$password];
		return $data;
	}

	function genratePassword($password_length = 8) {
	    //$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
	    $alphabet = '1234567890';
	    $pass = array(); //remember to declare $pass as an array
	    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	    for ($i = 0; $i < $password_length; $i++) {
	        $n = rand(0, $alphaLength);
	        $pass[] = $alphabet[$n];
	    }
	   return implode($pass); //turn the array into a string
	}

	function sendSms($mobile,$message){
		$this->url = 'https://control.msg91.com/api/sendhttp.php';
        $encodedMessage = urlencode($this->title.' '.$message);
        $postData = array(
		    'authkey' => $this->authkey,
		    'mobiles' => $mobile,
		    'message' => $encodedMessage,
		    'sender' => $this->senderId,
		    'route' => $this->route
		);
		$ch = curl_init();
		curl_setopt_array($ch, array(
		    CURLOPT_URL => $this->url,
		    CURLOPT_RETURNTRANSFER => true,
		    CURLOPT_POST => true,
		    CURLOPT_POSTFIELDS => $postData
		    //,CURLOPT_FOLLOWLOCATION => true
		));
		//Ignore SSL certificate verification
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		//get response
		$output = curl_exec($ch);
		$status = 1;
		//Print error if any
		if(curl_errno($ch))
		{
		    $status = 0;
		    $output = 'error:' . curl_error($ch);
		}
		curl_close($ch);
		return array('status'=>$status,'msg'=>$output);
		
	}

}
