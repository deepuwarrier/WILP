<?php
namespace App\Helpers\TW\Bajaj;

use App\Models\TW\data\QuoteData;
use Illuminate\Support\Facades\Log;
use SoapClient;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwVariant;
			
 class BajajPolicyFactory {
 
 	
 

public function get_quote($quote_req_data){	
	
	$usr_db = new TwUsrData();
	$ued_db_data = $usr_db->quote_req_data($quote_req_data["SSN_KEY"]);
	$variant_db = new TwVariant();
	
	
	//get bajaj specifc details from masters	
	$quote_req_data["VARIANT_CODE"] = $variant_db->bajaj_code($ued_db_data->variant_id)->variant_code;
	$quote_req_data["RTO_CODE"] = $ued_db_data->rto_code;
	$quote_req_data["TW_YOR"] = $ued_db_data->yor;
	
	
	$raw_quote_resp = $this->init_quote($quote_req_data);
	return $this->parse_quote($raw_quote_resp);

}


/**
 * This function basically parse data from api call to defined object so that can be presented at view.
 * This way data passed to view will be specific format irrespective to data received from different api.  
 */
public function parse_quote($raw_quote_resp){
	$data = new QuoteData();
	
	$data->_idv( $raw_quote_resp['pWeoMotPolicyIn_inout']->vehicleIdv);
	
	$data->_insurer_logo("bajajallianzgi_logo.png");
	$data->_insurer_name("Bajaj Allianz");
	$data->_insurer_code("IITW01");
	
	foreach ($raw_quote_resp['premiumSummeryList_out']->WeoMotPremiumSummaryUser as $covers ) {
		
		switch ($covers->paramRef) {
			case "OD":
				$data->_od_value(round($covers->od, 2));break;
			case "ACT":
				$data->_tp_value(round($covers->act, 2));	break;
			case "PA_DFT":
				$data->_pa_value(round($covers->act, 2)); break;
			case "NCB":
				$data->_ncb_value(round($covers->od, 2)); break;
			case "COMMDISC":
				$data->_cmdisc_value(round($covers->od, 2)); 	break;
			case "LTERM_DISC":
				$data->_ltdisc_value(round($covers->od, 2)); break;
			default:
				 Log::info("No values initialized from addon",$covers->od);
		}
	}
	
	$base_premium = $data->od_value() + $data->tp_value() + $data->pa_value();
	$tot_deduction = $data->ncb_value() - $data->cmdisc_value() - $data->ltdisc_value();
	$gross_premium = $base_premium - $tot_deduction;
	$service_tax = $gross_premium * 0.15;
	$final_premium = $gross_premium + $service_tax;
	$data->_service_tax(round($service_tax, 2));
	$data->_final_premium( $raw_quote_resp['premiumDetailsOut_out']->finalPremium);

	return $data;
}

public function init_quote($quote_req_data){
	ini_set("soap.wsdl_cache_enabled", 0);
	$client = new SoapClient("http://webservicesuat.bajajallianz.com/WebServicePolicy/WebServicePolicyPort?WSDLcalculate");
	
	
	$plan_detail = new WeoMotPlanDetailsUser();
	$plan_detail->setPolType(3);
	$plan_detail->setRegistrationNo($quote_req_data['RTO_CODE']);
	$plan_detail->setNcb($quote_req_data['CURRENT_NCB']);
	$plan_detail->setPrvClaimStatus($quote_req_data['CLAIM_STATUS']);
	$plan_detail->setRegistrationDate($quote_req_data['TW_REG_DATE']);
	$plan_detail->setTermStartDate($quote_req_data['TERM_START_DATE']);
	$plan_detail->setTermEndDate($quote_req_data['TERM_END_DATE']);
	$plan_detail->setBranchCode(9906);
	$plan_detail->setPrvNcb($quote_req_data['CURRENT_NCB']);
	$plan_detail->setPrvInsCompany(3);
	$plan_detail->setEngineNo('');
	$plan_detail->setProduct4digitCode(1843);
	$plan_detail->setPrvExpiryDate($quote_req_data['POL_EXP_DATE']);
	$plan_detail->setDeptCode('18');
	
	
	$accessory = null;
	$addonCover = null;
	$motExtraCover = null;
	$pQuestList_inout = null;
	$pDetariffObj_inout = null;
	$premiumDetailsOut_out = null;
	$premiumSummeryList_out = null;
	$pError_out = null;
	$pAdditionalField_inout = null;
	
	
	$result = $client->calculatePremiumWrapper1843(
			'policy@instainsure.com'
			, 'newpas12'
			, $quote_req_data['VARIANT_CODE']
			, 'MUMBAI'
			, $plan_detail
			, $accessory
			, $addonCover
			, $motExtraCover
			, $pQuestList_inout
			, $pDetariffObj_inout
			, $premiumDetailsOut_out
			, $premiumSummeryList_out
			, $pError_out, null, null, null, null, $pAdditionalField_inout);
	
	if (isset($result['pError_out']->WeoTygeErrorMessageUser->errNumber)) {
		echo $result['pError_out']->WeoTygeErrorMessageUser->errText;
	} else {
// 		Log::info("Quote Response", $result);
		
	}
	return $result;
}


}
