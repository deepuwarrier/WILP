<?php
namespace App\Helpers\TW\Bajaj;

use App\Be\TW\BajajBe;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use Illuminate\Support\Facades\Log;
use SoapClient;
						
 class BajajQuoteFactory {
 
 	public function get_quote(QuoteReqData $quote_req_data){	 
	
	if( $quote_req_data->get_add_on_zrdp() || $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
		$pre_resp_data = new QuoteRespData();
		$pre_resp_data->_addon_flag(false);
		return $pre_resp_data;
	} 
	
	$bajaj_be = new BajajBe();
	
	// populate quote request
	$fillded_request = $bajaj_be->populate_quote_request($quote_req_data); 
	// initi quote api
	$raw_quote_resp = $this->init_quote($fillded_request);
	
	if($raw_quote_resp == null) {	return null;}
	
	// parse quote response
	$quote_resp_data = $bajaj_be->parse_quote_response($quote_req_data, $raw_quote_resp);
	
	return $quote_resp_data;
}

public function init_quote($fillded_request){  
	ini_set("soap.wsdl_cache_enabled", 0); 
// 	$client = new SoapClient("http://webservicesuat.bajajallianz.com/BagicMotorWS/BagicMotorWSPort?WSDL");
	$client = new SoapClient("http://webservicesdev.bajajallianz.com/BagicMotorWS/BagicMotorWSPort?wsdl");
	
	$result = $client->calculatePremiumWrapper1843( 
			$fillded_request["API_USER"],
			$fillded_request["API_PASS"],
			$fillded_request["VARIANT_CODE"],
			$fillded_request["LOCATION_NAME"],
			$fillded_request["PLAN_DETAILS"],
			$fillded_request["ACCESSORY"],
			$fillded_request["ADDONCOVER"],
			$fillded_request["MOTEXTRACOVER"],
			$fillded_request["PQUESTLIST_INOUT"],
			$fillded_request["PDETARIFFOBJ_INOUT"],
			$fillded_request["PREMIUMDETAILSOUT_OUT"],
			$fillded_request["PREMIUMSUMMERYLIST_OUT"],
		    $fillded_request["PERROR_OUT"], $fillded_request["EXT1"], $fillded_request["EXT2"], $fillded_request["EXT3"],
		    $fillded_request["EXT4"], $fillded_request["PADDITIONALFIELD_INOUT"]
	);
	
	if (isset($result['pError_out']->WeoTygeErrorMessageUser->errNumber)) {
		Log::error($result['pError_out']->WeoTygeErrorMessageUser->errText);
		$result = null;
	} else {
		Log::info("TW BAJAJ QUOTE RESPONSE : ". $fillded_request["TRANS_CODE"] ." ". print_r($result, true));
	}
	
	return $result;
}




}
