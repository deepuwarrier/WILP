<?php
namespace App\Helpers\TW\Bajaj;

class WeoMotPlanDetailsBase
{

    
    public function __construct()
    {
    
    }

}
