<?php

namespace App\Helpers\TW\Bajaj;

class WeoMotPlanDetailsUser /* extends WeoMotPlanDetailsBase  */
{

    /**
     * @var float $vehicleTypeCode
     */
    protected $vehicleTypeCode = null;

    /**
     * @var string $vehicleSubtype
     */
    protected $vehicleSubtype = null;

    /**
     * @var float $elecAccTotal
     */
    protected $elecAccTotal = null;

    /**
     * @var string $addLoadingOn
     */
    protected $addLoadingOn = null;

    /**
     * @var float $nonElecAccTotal
     */
    protected $nonElecAccTotal = null;

    /**
     * @var string $polType
     */
    protected $polType = null;

    /**
     * @var string $registrationNo
     */
    protected $registrationNo = null;

    /**
     * @var string $partnerType
     */
    protected $partnerType = null;

    /**
     * @var float $ncb
     */
    protected $ncb = null;

    /**
     * @var string $prvClaimStatus
     */
    protected $prvClaimStatus = null;

    /**
     * @var string $registrationDate
     */
    protected $registrationDate = null;

    /**
     * @var float $miscVehType
     */
    protected $miscVehType = null;

    /**
     * @var string $fuel
     */
    protected $fuel = null;

    /**
     * @var string $chassisNo
     */
    protected $chassisNo = null;

    /**
     * @var float $contractId
     */
    protected $contractId = null;

    /**
     * @var string $yearManf
     */
    protected $yearManf = null;

    /**
     * @var float $spDiscRate
     */
    protected $spDiscRate = null;

    /**
     * @var float $cubicCapacity
     */
    protected $cubicCapacity = null;

    /**
     * @var string $regiLocOther
     */
    protected $regiLocOther = null;

    /**
     * @var float $addLoading
     */
    protected $addLoading = null;

    /**
     * @var float $vehicleSubtypeCode
     */
    protected $vehicleSubtypeCode = null;

    /**
     * @var string $prvPolicyRef
     */
    protected $prvPolicyRef = null;

    /**
     * @var string $vehicleMake
     */
    protected $vehicleMake = null;

    /**
     * @var string $autoMembership
     */
    protected $autoMembership = null;

    /**
     * @var string $termStartDate
     */
    protected $termStartDate = null;

    /**
     * @var float $carryingCapacity
     */
    protected $carryingCapacity = null;

    /**
     * @var string $termEndDate
     */
    protected $termEndDate = null;

    /**
     * @var string $hypo
     */
    protected $hypo = null;

    /**
     * @var float $branchCode
     */
    protected $branchCode = null;

    /**
     * @var float $prvNcb
     */
    protected $prvNcb = null;

    /**
     * @var float $vehicleMakeCode
     */
    protected $vehicleMakeCode = null;

    /**
     * @var float $vehicleIdv
     */
    protected $vehicleIdv = null;

    /**
     * @var float $prvInsCompany
     */
    protected $prvInsCompany = null;

    /**
     * @var string $engineNo
     */
    protected $engineNo = null;

    /**
     * @var float $product4digitCode
     */
    protected $product4digitCode = null;

    /**
     * @var string $color
     */
    protected $color = null;

    /**
     * @var string $vehicleModel
     */
    protected $vehicleModel = null;

    /**
     * @var string $vehicleType
     */
    protected $vehicleType = null;

    /**
     * @var string $prvExpiryDate
     */
    protected $prvExpiryDate = null;

    /**
     * @var float $tpFinType
     */
    protected $tpFinType = null;

    /**
     * @var float $deptCode
     */
    protected $deptCode = null;

    /**
     * @var float $vehicleModelCode
     */
    protected $vehicleModelCode = null;

    /**
     * @var string $registrationLocation
     */
    protected $registrationLocation = null;

    /**
     * @var string $zone
     */
    protected $zone = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return float
     */
    public function getVehicleTypeCode()
    {
      return $this->vehicleTypeCode;
    }

    /**
     * @param float $vehicleTypeCode
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleTypeCode($vehicleTypeCode)
    {
      $this->vehicleTypeCode = $vehicleTypeCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleSubtype()
    {
      return $this->vehicleSubtype;
    }

    /**
     * @param string $vehicleSubtype
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleSubtype($vehicleSubtype)
    {
      $this->vehicleSubtype = $vehicleSubtype;
      return $this;
    }

    /**
     * @return float
     */
    public function getElecAccTotal()
    {
      return $this->elecAccTotal;
    }

    /**
     * @param float $elecAccTotal
     * @return WeoMotPlanDetailsUser
     */
    public function setElecAccTotal($elecAccTotal)
    {
      $this->elecAccTotal = $elecAccTotal;
      return $this;
    }

    /**
     * @return string
     */
    public function getAddLoadingOn()
    {
      return $this->addLoadingOn;
    }

    /**
     * @param string $addLoadingOn
     * @return WeoMotPlanDetailsUser
     */
    public function setAddLoadingOn($addLoadingOn)
    {
      $this->addLoadingOn = $addLoadingOn;
      return $this;
    }

    /**
     * @return float
     */
    public function getNonElecAccTotal()
    {
      return $this->nonElecAccTotal;
    }

    /**
     * @param float $nonElecAccTotal
     * @return WeoMotPlanDetailsUser
     */
    public function setNonElecAccTotal($nonElecAccTotal)
    {
      $this->nonElecAccTotal = $nonElecAccTotal;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolType()
    {
      return $this->polType;
    }

    /**
     * @param string $polType
     * @return WeoMotPlanDetailsUser
     */
    public function setPolType($polType)
    {
      $this->polType = $polType;
      return $this;
    }

    /**
     * @return string
     */
    public function getRegistrationNo()
    {
      return $this->registrationNo;
    }

    /**
     * @param string $registrationNo
     * @return WeoMotPlanDetailsUser
     */
    public function setRegistrationNo($registrationNo)
    {
      $this->registrationNo = $registrationNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartnerType()
    {
      return $this->partnerType;
    }

    /**
     * @param string $partnerType
     * @return WeoMotPlanDetailsUser
     */
    public function setPartnerType($partnerType)
    {
      $this->partnerType = $partnerType;
      return $this;
    }

    /**
     * @return float
     */
    public function getNcb()
    {
      return $this->ncb;
    }

    /**
     * @param float $ncb
     * @return WeoMotPlanDetailsUser
     */
    public function setNcb($ncb)
    {
      $this->ncb = $ncb;
      return $this;
    }

    /**
     * @return string
     */
    public function getPrvClaimStatus()
    {
      return $this->prvClaimStatus;
    }

    /**
     * @param string $prvClaimStatus
     * @return WeoMotPlanDetailsUser
     */
    public function setPrvClaimStatus($prvClaimStatus)
    {
      $this->prvClaimStatus = $prvClaimStatus;
      return $this;
    }

    /**
     * @return string
     */
    public function getRegistrationDate()
    {
      return $this->registrationDate;
    }

    /**
     * @param string $registrationDate
     * @return WeoMotPlanDetailsUser
     */
    public function setRegistrationDate($registrationDate)
    {
      $this->registrationDate = $registrationDate;
      return $this;
    }

    /**
     * @return float
     */
    public function getMiscVehType()
    {
      return $this->miscVehType;
    }

    /**
     * @param float $miscVehType
     * @return WeoMotPlanDetailsUser
     */
    public function setMiscVehType($miscVehType)
    {
      $this->miscVehType = $miscVehType;
      return $this;
    }

    /**
     * @return string
     */
    public function getFuel()
    {
      return $this->fuel;
    }

    /**
     * @param string $fuel
     * @return WeoMotPlanDetailsUser
     */
    public function setFuel($fuel)
    {
      $this->fuel = $fuel;
      return $this;
    }

    /**
     * @return string
     */
    public function getChassisNo()
    {
      return $this->chassisNo;
    }

    /**
     * @param string $chassisNo
     * @return WeoMotPlanDetailsUser
     */
    public function setChassisNo($chassisNo)
    {
      $this->chassisNo = $chassisNo;
      return $this;
    }

    /**
     * @return float
     */
    public function getContractId()
    {
      return $this->contractId;
    }

    /**
     * @param float $contractId
     * @return WeoMotPlanDetailsUser
     */
    public function setContractId($contractId)
    {
      $this->contractId = $contractId;
      return $this;
    }

    /**
     * @return string
     */
    public function getYearManf()
    {
      return $this->yearManf;
    }

    /**
     * @param string $yearManf
     * @return WeoMotPlanDetailsUser
     */
    public function setYearManf($yearManf)
    {
      $this->yearManf = $yearManf;
      return $this;
    }

    /**
     * @return float
     */
    public function getSpDiscRate()
    {
      return $this->spDiscRate;
    }

    /**
     * @param float $spDiscRate
     * @return WeoMotPlanDetailsUser
     */
    public function setSpDiscRate($spDiscRate)
    {
      $this->spDiscRate = $spDiscRate;
      return $this;
    }

    /**
     * @return float
     */
    public function getCubicCapacity()
    {
      return $this->cubicCapacity;
    }

    /**
     * @param float $cubicCapacity
     * @return WeoMotPlanDetailsUser
     */
    public function setCubicCapacity($cubicCapacity)
    {
      $this->cubicCapacity = $cubicCapacity;
      return $this;
    }

    /**
     * @return string
     */
    public function getRegiLocOther()
    {
      return $this->regiLocOther;
    }

    /**
     * @param string $regiLocOther
     * @return WeoMotPlanDetailsUser
     */
    public function setRegiLocOther($regiLocOther)
    {
      $this->regiLocOther = $regiLocOther;
      return $this;
    }

    /**
     * @return float
     */
    public function getAddLoading()
    {
      return $this->addLoading;
    }

    /**
     * @param float $addLoading
     * @return WeoMotPlanDetailsUser
     */
    public function setAddLoading($addLoading)
    {
      $this->addLoading = $addLoading;
      return $this;
    }

    /**
     * @return float
     */
    public function getVehicleSubtypeCode()
    {
      return $this->vehicleSubtypeCode;
    }

    /**
     * @param float $vehicleSubtypeCode
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleSubtypeCode($vehicleSubtypeCode)
    {
      $this->vehicleSubtypeCode = $vehicleSubtypeCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getPrvPolicyRef()
    {
      return $this->prvPolicyRef;
    }

    /**
     * @param string $prvPolicyRef
     * @return WeoMotPlanDetailsUser
     */
    public function setPrvPolicyRef($prvPolicyRef)
    {
      $this->prvPolicyRef = $prvPolicyRef;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleMake()
    {
      return $this->vehicleMake;
    }

    /**
     * @param string $vehicleMake
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleMake($vehicleMake)
    {
      $this->vehicleMake = $vehicleMake;
      return $this;
    }

    /**
     * @return string
     */
    public function getAutoMembership()
    {
      return $this->autoMembership;
    }

    /**
     * @param string $autoMembership
     * @return WeoMotPlanDetailsUser
     */
    public function setAutoMembership($autoMembership)
    {
      $this->autoMembership = $autoMembership;
      return $this;
    }

    /**
     * @return string
     */
    public function getTermStartDate()
    {
      return $this->termStartDate;
    }

    /**
     * @param string $termStartDate
     * @return WeoMotPlanDetailsUser
     */
    public function setTermStartDate($termStartDate)
    {
      $this->termStartDate = $termStartDate;
      return $this;
    }

    /**
     * @return float
     */
    public function getCarryingCapacity()
    {
      return $this->carryingCapacity;
    }

    /**
     * @param float $carryingCapacity
     * @return WeoMotPlanDetailsUser
     */
    public function setCarryingCapacity($carryingCapacity)
    {
      $this->carryingCapacity = $carryingCapacity;
      return $this;
    }

    /**
     * @return string
     */
    public function getTermEndDate()
    {
      return $this->termEndDate;
    }

    /**
     * @param string $termEndDate
     * @return WeoMotPlanDetailsUser
     */
    public function setTermEndDate($termEndDate)
    {
      $this->termEndDate = $termEndDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getHypo()
    {
      return $this->hypo;
    }

    /**
     * @param string $hypo
     * @return WeoMotPlanDetailsUser
     */
    public function setHypo($hypo)
    {
      $this->hypo = $hypo;
      return $this;
    }

    /**
     * @return float
     */
    public function getBranchCode()
    {
      return $this->branchCode;
    }

    /**
     * @param float $branchCode
     * @return WeoMotPlanDetailsUser
     */
    public function setBranchCode($branchCode)
    {
      $this->branchCode = $branchCode;
      return $this;
    }

    /**
     * @return float
     */
    public function getPrvNcb()
    {
      return $this->prvNcb;
    }

    /**
     * @param float $prvNcb
     * @return WeoMotPlanDetailsUser
     */
    public function setPrvNcb($prvNcb)
    {
      $this->prvNcb = $prvNcb;
      return $this;
    }

    /**
     * @return float
     */
    public function getVehicleMakeCode()
    {
      return $this->vehicleMakeCode;
    }

    /**
     * @param float $vehicleMakeCode
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleMakeCode($vehicleMakeCode)
    {
      $this->vehicleMakeCode = $vehicleMakeCode;
      return $this;
    }

    /**
     * @return float
     */
    public function getVehicleIdv()
    {
      return $this->vehicleIdv;
    }

    /**
     * @param float $vehicleIdv
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleIdv($vehicleIdv)
    {
      $this->vehicleIdv = $vehicleIdv;
      return $this;
    }

    /**
     * @return float
     */
    public function getPrvInsCompany()
    {
      return $this->prvInsCompany;
    }

    /**
     * @param float $prvInsCompany
     * @return WeoMotPlanDetailsUser
     */
    public function setPrvInsCompany($prvInsCompany)
    {
      $this->prvInsCompany = $prvInsCompany;
      return $this;
    }

    /**
     * @return string
     */
    public function getEngineNo()
    {
      return $this->engineNo;
    }

    /**
     * @param string $engineNo
     * @return WeoMotPlanDetailsUser
     */
    public function setEngineNo($engineNo)
    {
      $this->engineNo = $engineNo;
      return $this;
    }

    /**
     * @return float
     */
    public function getProduct4digitCode()
    {
      return $this->product4digitCode;
    }

    /**
     * @param float $product4digitCode
     * @return WeoMotPlanDetailsUser
     */
    public function setProduct4digitCode($product4digitCode)
    {
      $this->product4digitCode = $product4digitCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getColor()
    {
      return $this->color;
    }

    /**
     * @param string $color
     * @return WeoMotPlanDetailsUser
     */
    public function setColor($color)
    {
      $this->color = $color;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleModel()
    {
      return $this->vehicleModel;
    }

    /**
     * @param string $vehicleModel
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleModel($vehicleModel)
    {
      $this->vehicleModel = $vehicleModel;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleType()
    {
      return $this->vehicleType;
    }

    /**
     * @param string $vehicleType
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleType($vehicleType)
    {
      $this->vehicleType = $vehicleType;
      return $this;
    }

    /**
     * @return string
     */
    public function getPrvExpiryDate()
    {
      return $this->prvExpiryDate;
    }

    /**
     * @param string $prvExpiryDate
     * @return WeoMotPlanDetailsUser
     */
    public function setPrvExpiryDate($prvExpiryDate)
    {
      $this->prvExpiryDate = $prvExpiryDate;
      return $this;
    }

    /**
     * @return float
     */
    public function getTpFinType()
    {
      return $this->tpFinType;
    }

    /**
     * @param float $tpFinType
     * @return WeoMotPlanDetailsUser
     */
    public function setTpFinType($tpFinType)
    {
      $this->tpFinType = $tpFinType;
      return $this;
    }

    /**
     * @return float
     */
    public function getDeptCode()
    {
      return $this->deptCode;
    }

    /**
     * @param float $deptCode
     * @return WeoMotPlanDetailsUser
     */
    public function setDeptCode($deptCode)
    {
      $this->deptCode = $deptCode;
      return $this;
    }

    /**
     * @return float
     */
    public function getVehicleModelCode()
    {
      return $this->vehicleModelCode;
    }

    /**
     * @param float $vehicleModelCode
     * @return WeoMotPlanDetailsUser
     */
    public function setVehicleModelCode($vehicleModelCode)
    {
      $this->vehicleModelCode = $vehicleModelCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getRegistrationLocation()
    {
      return $this->registrationLocation;
    }

    /**
     * @param string $registrationLocation
     * @return WeoMotPlanDetailsUser
     */
    public function setRegistrationLocation($registrationLocation)
    {
      $this->registrationLocation = $registrationLocation;
      return $this;
    }

    /**
     * @return string
     */
    public function getZone()
    {
      return $this->zone;
    }

    /**
     * @param string $zone
     * @return WeoMotPlanDetailsUser
     */
    public function setZone($zone)
    {
      $this->zone = $zone;
      return $this;
    }

}
