<?php

namespace App\Helpers\TW;

class EmailDataFormat{
	
public function format($usr_data) {
	
	$mstr_data = new InsurerData();
	
	$temp_arr = array(
			
			"Transcation Details" => "",
			"Transaction Code" => $usr_data->trans_code,
			"Policy Type" => 	$usr_data->policy_type ,
			"OD Value" => $usr_data->od_premium,
			"TP Value" => $usr_data->tp_premium,
			"Addon Covers" => $usr_data->addon_covers,
			"Addon Premium" => $usr_data->addon_premium,
			"Total Tax" => $usr_data->total_tax,
			"Total Premium" =>$usr_data->final_premium,
			
			
			"Vechicle Details" => "",
			"Registration Number" =>  $usr_data->rto_code ."". $usr_data->tw_reg_no, 
			"Vehicle Name" => $mstr_data->insr_variant("vechicle_name_desc", $usr_data->variant_code) ,
			"Policy Expiry Date" => $usr_data->policy_exp_date,
			
			"Customer Details" => "",
			"Customer Name" => $usr_data->proposer_name,
			"Customer Phone / Email" => $usr_data->proposer_mobile . " / " . $usr_data->proposer_email
	);
// 	dd($temp_arr);
	return $temp_arr;
}	
	
} // end of class
