<?php
namespace App\Helpers\TW\HDFC;

							
 use App\Models\TW\TwUsrData;
use App\Constants\Tw_Constants;
use GuzzleHttp\Client;
use App\Models\OtpTData;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\HDFC\Hdfc_Policy_Request;
use Illuminate\Support\Facades\Log;
use App\Models\TW\TwCovers;
use App\Be\TW\TwPolicyBe;
use App\Libraries\TwLib;
use App\Libraries\InstaLib;
use App\Be\TW\HdfcBe;
					
 class HDFCPolicyManager {
 

 	public function submit_policy($tw_trans_code, $agreed_premium){
    $usr_db = new TwUsrData();
    $policy_usr_data = $usr_db->get_by_tc($tw_trans_code);  
   
    if( $agreed_premium !== null ) {
    	$policy_usr_data->total_premium= $agreed_premium;
   
    }
 

//     // code for otp
    $this->policy["isAuthenticated"] = "Y";
    $this->policy["authType"] = "OTP";
    $result = OtpTData::where('mobile', $policy_usr_data->proposer_mobile)->first();
    if (isset($result->recv_otp)) {
        //otp value
        $this->policy["authNumber"] = $result->recv_otp;
    }
    // end code of otp
    
    $hdfc_be = new HdfcBe();
    
//     $populated_req_str = $this->populate_req_params(  $req_raw_str, $policy_usr_data );
    
    $populated_req_str =  $hdfc_be->populate_proposal_request( $policy_usr_data );
    
	try {

		$proposal_resp_raw = $this->call_submit_proposal( $tw_trans_code, $populated_req_str);
		
		return $this->parse_response( $proposal_resp_raw,$tw_trans_code);
	}catch (Exception $ex){
		return null; 
	}
	
}// end of method



private function parse_response( $proposal_resp,$tw_trans_code = null){
		$final_resp = array();
		$insta_lib = new InstaLib();
		$usr_db = new TwUsrData(); 
		$proposal_resp_msg = explode("|", $proposal_resp->WsMessage);
		$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
		if( $proposal_resp->WsStatus == 0) {
			
			$final_resp["type"] = "success";
			$final_resp["pr_customerid"] = $proposal_resp_msg[0];
			$proposal_status_code = 'TS15';
		} else {
			// Error state. now check if premium mismatch
			
			$resp_text_raw = $proposal_resp_msg;
			// dd($resp_text_raw);
			if(strpos($resp_text_raw[0], "Total Premium provided is incorrect") !== false) {
				
				$final_resp["type"] = "premismatch";
				$resp_err_arr =   $proposal_resp_msg;
				$new_pre_arr =  (explode(":", $resp_err_arr[5]));
				$final_resp["revised_premium"] = $new_pre_arr[1];
				$proposal_status_code = 'TS20';
				
			}else{
				// Not premimum mismatch... pass this error to user. 
				$final_resp["type"] = "error";
				$final_resp["error_message"] = $proposal_resp_msg[0];
				$proposal_status_code = 'TS01';
			}
		} // end of out if else.

		$proposal_status['proposal_status'] = $proposal_status_code;
		$proposal_status['trans_status'] = $proposal_status_code;
		$proposal_status['proposal_desc'] = json_encode($proposal_resp_msg);
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);
		return $final_resp;
} // method end. 

private function call_submit_proposal($tw_trans_code, $policy_req_str) {
	
	Log::info("TW HDFC PROPOSAL REQUEST - ". $tw_trans_code ." - " . $policy_req_str);
	$proposal_resp = null;
	$client = new Client();
	try {
		$response = $client->request(
				'POST',
				'https://hewspool.hdfcergo.com/TWWS/service.asmx/GenerateTWTransNo',
				[	'form_params' => [		'NewTWCPURL' => $policy_req_str		]	]
				);
		$proposal_resp_raw =  $response->getBody()->getContents();
		$xml_raw = str_replace('&lt;?xml version="1.0" encoding="utf-8"?&gt;','',$proposal_resp_raw);
		$xml_resp = simplexml_load_string(html_entity_decode($xml_raw));
		$proposal_resp = $xml_resp->WsResult->WsResultSet;  
		Log::info("TW HDFC PROPOSAL RESPONSE - " . $tw_trans_code . " - " . print_r($proposal_resp->WsMessage, true));
		
	}catch (Exeception $ex) {	
		Log::error("Error in TW HDFC Proposal Response - " . $tw_trans_code . " - " . $ex->getMessage());
	}
	return $proposal_resp;
}




 } // end of class
