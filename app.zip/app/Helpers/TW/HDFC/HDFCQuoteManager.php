<?php
namespace App\Helpers\TW\HDFC;

use App\Be\TW\HdfcBe;
use App\Helpers\TW\InsurerData;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
												
 class HDFCQuoteManager {
 
 

public function get_quote(QuoteReqData $quote_req_data){	
	
	if( $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
		$pre_resp_data = new QuoteRespData();
		$pre_resp_data->_addon_flag(false);
		return $pre_resp_data;
	} 
	$tw_trans_code = $quote_req_data->get_tw_trans_code();
	$mstr_ob = new InsurerData();
	$hdfc_be = new HdfcBe();
	
	
	$quote_req_data->set_rto_zone( $mstr_ob->insr_rto("zone", $quote_req_data->get_rto_code() ) );
	
	// call and update idv in quote. 	
	$idv_req_str = $hdfc_be->populate_idv_request($quote_req_data);
	Log::info("Hdfc calculated IDV : ". $quote_req_data->get_desired_idv());
	$hdfc_api_idv = $this->init_quote_idv($tw_trans_code,$idv_req_str);
	if ($hdfc_api_idv != null)  {
		$quote_req_data->set_desired_idv($hdfc_api_idv);
	}
	Log::info("Hdfc API IDv is : " . $hdfc_api_idv);
	$filled_request_str = $hdfc_be->populate_quote_request($quote_req_data);
	$raw_quote_resp = $this->init_quote($tw_trans_code, $filled_request_str);
	$resp_data = $hdfc_be->parse_quote_response($quote_req_data, $raw_quote_resp);  
	
	if( $quote_req_data->get_add_on_zrdp()){ 
		if ( $resp_data->addon_zrdp() == 0){
			$resp_data->_addon_flag(false);
		}
	} 
	return $resp_data;
}



private function init_quote_idv($tw_trans_code,$filled_request_str) {
	
	$client = new Client();
	try {
		$response = $client->request(
				'POST',
				'https://hewspool.hdfcergo.com/wscalculate/service.asmx/getIDV',
				[	'form_params' => [ 	'str' =>  $filled_request_str ] ]
				);
		
		$api_resp = $response->getBody()->getContents();
		$idv_xml_obj = simplexml_load_string(html_entity_decode($api_resp));
		return $idv_xml_obj->IDV->idv_amount;
	}catch (\Exception $ee) {
		Log::error( "TW HDFC IDV Error: ". $tw_trans_code ." - ".$ee->getMessage());
		return null;
	}
	
}


private function init_quote($tw_trans_code, $filled_request_str){
	Log::info("TW HDFC QUOTE REQUEST - ". $tw_trans_code . " - " . $filled_request_str);
	$client = new Client();
	try {
		$response = $client->request(
				'POST',
				'https://hewspool.hdfcergo.com/wscalculate/service.asmx/getPremium',
				[	'form_params' => [ 	'str' =>  $filled_request_str , 'VehicleClassCode' => "37"] ]
				);
		
		$api_resp = $response->getBody()->getContents();   

		Log::info("TW HDFC QUOTE RESPONSE -". $tw_trans_code ." - " . html_entity_decode($api_resp) );
		return  html_entity_decode($api_resp);
	}catch (\Exception $ee) {
		Log::error( "HDFC Quote : Execption while calling quote : ". $tw_trans_code ." - ".$ee->getMessage());
	}
	return null;
} // end of method



private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}



 } // end of class
