<?php

namespace App\Helpers\TW\HDFC;

class Hdfc_Policy_Request {
	
	public function prepare_policy_request( $req_arr ) {
		$proposal_req_str = "<xmlmotorpolicy><AgentCode>TTIB0002</AgentCode><Policy_Type>C</Policy_Type><Type_of_Business>ROLLOVER</Type_of_Business><Occupation_Type>0</Occupation_Type><CustAge>Upto35</CustAge><Policy_Startdate></Policy_Startdate><Policy_Enddate></Policy_Enddate><Registration_Citycode></Registration_Citycode><Vehicle_Modelcode></Vehicle_Modelcode><Manufacturer_Code></Manufacturer_Code><Purchase_Regndate></Purchase_Regndate><Ex-showroom_Price></Ex-showroom_Price><Sum_Insured></Sum_Insured><Electical_Acc></Electical_Acc><NonElectical_Acc></NonElectical_Acc><No_of_Lldrivers>0</No_of_Lldrivers><Paiddriver_Si>0</Paiddriver_Si><No_of_Employees>0</No_of_Employees><Unnamed_Si>0</Unnamed_Si><LPG-CNG_Kit>0</LPG-CNG_Kit><IsPrevious_Claim></IsPrevious_Claim><NCB_ExpiringPolicy></NCB_ExpiringPolicy><PrePolicy_Startdate></PrePolicy_Startdate><PrePolicy_Enddate></PrePolicy_Enddate><Vehicle_Ownedby></Vehicle_Ownedby><IsEmergency_Cover>0</IsEmergency_Cover><is_pa_cover_owner_driver>1</is_pa_cover_owner_driver><IsZeroDept_Cover>0</IsZeroDept_Cover><IsZeroDept_RollOver>0</IsZeroDept_RollOver><Year_of_Manufacture></Year_of_Manufacture><NCB_RenewalPolicy></NCB_RenewalPolicy><Total_Premium></Total_Premium><Service_Tax></Service_Tax><Total_Amoutpayable></Total_Amoutpayable><Name_Financial_Institution></Name_Financial_Institution><Manufacture_Name></Manufacture_Name><Vehicle_Model></Vehicle_Model><Registration_City></Registration_City><Vehicle_Regno></Vehicle_Regno><Engine_No></Engine_No><Chassis_No></Chassis_No><PreInsurerCode></PreInsurerCode><PrePolicy_Number></PrePolicy_Number><First_Name></First_Name><Last_Name></Last_Name><Date_of_Birth></Date_of_Birth><Gender></Gender><Email_Id></Email_Id><Contactno_Office></Contactno_Office><Contactno_Home></Contactno_Home><Contactno_Mobile></Contactno_Mobile><Car_Address1></Car_Address1><Car_Address2></Car_Address2><Car_Address3></Car_Address3><Car_Citycode></Car_Citycode><Car_City></Car_City><Car_Statecode></Car_Statecode><Car_State></Car_State><Car_Pin></Car_Pin><Corres_Address1></Corres_Address1><Corres_Address2></Corres_Address2><Corres_Address3></Corres_Address3><Corres_Citycode></Corres_Citycode><Corres_City></Corres_City><LocationCode></LocationCode><Corres_Statecode></Corres_Statecode><Corres_State></Corres_State><Corres_Pin></Corres_Pin><Data1>CC</Data1><Data2></Data2><Data3></Data3><Data4></Data4><Data5></Data5><Owner_Driver_Nominee_Name></Owner_Driver_Nominee_Name><Owner_Driver_Nominee_Age></Owner_Driver_Nominee_Age><Owner_Driver_Nominee_Relationship></Owner_Driver_Nominee_Relationship><Owner_Driver_Appointee_Name></Owner_Driver_Appointee_Name><Owner_Driver_Appointee_Relationship></Owner_Driver_Appointee_Relationship><PAN_Card></PAN_Card><Fuel_Type>Petrol</Fuel_Type><Premium_Year>1</Premium_Year></xmlmotorpolicy>";
		
		foreach ($req_arr as $xml_key => $xml_value) {
			
			$proposal_req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$proposal_req_str
					);
		}
		return $proposal_req_str;
	} 
  
} // end of class
