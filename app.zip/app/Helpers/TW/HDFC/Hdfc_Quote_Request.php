<?php

namespace App\Helpers\TW\HDFC;

class Hdfc_Quote_Request {
	
	public function idv_request_str( $req_arr ) {
		
		$req_str = "<IDV>
		<policy_start_date></policy_start_date>
		<vehicle_class_cd>37</vehicle_class_cd>
		<rtolocationcode></rtolocationcode>
		<vehiclemodelcode></vehiclemodelcode>
		<manufacturer_code></manufacturer_code>
		<purchaseregndate></purchaseregndate>
		<manufacturingyear></manufacturingyear>
		</IDV>";
		
		foreach ($req_arr as $xml_key => $xml_value) {
			
			$req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$req_str
					);
		}
		return $req_str;
	} 
	
	
	public function prepare_quote_init( $req_arr ) {
		
		$quote_init_req_str = "<PCVPremiumCalc><agentcode>TTIB0002</agentcode>
	<basedon_IDV_ExShowRoom>1</basedon_IDV_ExShowRoom><typeofbusiness>ROLLOVER</typeofbusiness>
	<occupationtype>0</occupationtype><custage>Up to 35</custage>
	<policystartdate></policystartdate><policyenddate></policyenddate>
	<rtolocationcode></rtolocationcode><vehiclemodelcode></vehiclemodelcode>
	<manufacturer_code></manufacturer_code><purchaseregndate></purchaseregndate>
	<exshowroomprice></exshowroomprice><Sum_Insured></Sum_Insured>
	<electicalacc>0</electicalacc><nonelecticalacc>0</nonelecticalacc>
	<nooflldrivers>0</nooflldrivers><paiddriversi>0</paiddriversi>
	<noofemployees>0</noofemployees><unnamedsi>0</unnamedsi>
	<lpg_cngkit>0</lpg_cngkit><IsPreviousClaim></IsPreviousClaim>
	<previousdiscount></previousdiscount><prepolstartdate></prepolstartdate>
	<prepolicyenddate></prepolicyenddate><txt_cust_type>I</txt_cust_type>
	<num_is_emr_asst_cvr></num_is_emr_asst_cvr><is_pa_cover_owner_driver>1</is_pa_cover_owner_driver>
	<num_is_zero_dept></num_is_zero_dept><manufacturingyear></manufacturingyear></PCVPremiumCalc>";
		
		foreach ($req_arr as $xml_key => $xml_value) {
			
			$quote_init_req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$quote_init_req_str
					);
		}
		return $quote_init_req_str;
	} 

} // end of class
