<?php
namespace App\Helpers\TW\ITGI;

use App\Be\TW\ITGIBe;
					
 class ITGIQuoteFactory {
 
 	public function get_quote($quote_req_data){	 
	
	if( $quote_req_data->get_add_on_zrdp() || $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
		$pre_resp_data = new QuoteRespData();
		$pre_resp_data->_addon_flag(false);
		return $pre_resp_data;
	} 
	
	$itgi_be = new ITGIBe();
	
	// populate quote request
	$fillded_request = $itgi_be->populate_quote_request($quote_req_data);
	// initi quote api
//	$raw_quote_resp = $this->init_quote($quote_req_data);
	// parse quote response
	$quote_resp_data = $itgi_be->parse_quote_response($quote_req_data, null);
	
	return $quote_resp_data;
	

}



public function init_quote($quote_req_data){
	
	return true;
}




} // end of class
