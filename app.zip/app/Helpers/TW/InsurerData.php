<?php

namespace App\Helpers\TW;

use App\Models\TW\TwVariant;
use App\Models\TW\TwMakes;
use App\Models\TW\TwRTO;
use App\Models\TW\TwCities;
use App\Models\TW\TwStates;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwModels;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwPincode;
use App\Models\TW\TwOccupation;
use App\Models\TW\TwMaritalStatus;
use App\Models\Base\UserMasterM;
use App\Models\TW\TwInsurers;

class InsurerData{
	
	public function insr_make($column_name, $make_code) {
		$make_db = new TwMakes();
		return $make_db->make_details($make_code)->$column_name;
	}
	
	public function model_data($column_name, $model_code) {
		$model_db = new TwModels();
		return $model_db->model_details($model_code)->$column_name;
	}
	
	public function insr_variant($column_name, $variant_code, $null_check = false){
		
		$variant_db = new TwVariant();
		$ret_value = "";
		try{
			if($null_check){
				if($variant_code!= null){
					$ret_value =  $variant_db->variant_details($variant_code)->$column_name;
				}
			}else{
				$ret_value =  $variant_db->variant_details($variant_code)->$column_name;
			}
		}catch (\Exception $ex){}
		return $ret_value;
	} //end
	
	public function insr_rto($column_name, $rto_code) {
		$rto_db = new TwRTO();
		return  $rto_db->rto_details($rto_code)->$column_name;
	}
	
	public function insr_city ($column_name, $city_code, $null_check = false) {
		$city_db = new TwCities();
		$ret_value = "";
		if($null_check){
			if($city_code!= null){
				$ret_value =  $city_db->city_details($city_code)->$column_name;
			}
		}else{
			$ret_value =  $city_db->city_details($city_code)->$column_name;
		}
		return $ret_value;
	}
	
	public function insr_state ($column_name, $state_code, $null_check = false) { 
	$state_db = new TwStates();
	$ret_value = "";
	if($null_check){
		if($state_code!= null){
			$ret_value =  $state_db->state_details($state_code)->$column_name;
		}
	}else{
		$ret_value =  $state_db->state_details($state_code)->$column_name;
	}
	return $ret_value;
	}
	
	public function  insr_preinsr($column_name, $pinsr_code) { 
	  $prinsr_db = new TwPreInsurers() ; 
	  return $prinsr_db->preinsr_details($pinsr_code)->$column_name; 
	}
	
	public function nomrel_data($column_name, $nomrel_code) {
		$nomrel_db = new TwNomRel();
		return  $nomrel_db->nomrel_details($nomrel_code)->$column_name; 
	}
	
	public function proposer_occu($column_name, $occ_code) {
		$occ_db = new TwOccupation();
		return  $occ_db->occupation_details($occ_code)->$column_name;
	}

	public function proposer_maritialstatus($column_name, $ms_code) {
		$ms_db = new TwMaritalStatus();
		return  $ms_db->maritialstatus_details($ms_code)->$column_name;
	}
	
	public function insurer_data($column_name, $insr_code, $null_check = false) {
		$insr_db = new TwInsurers();
		$ret_value = "";
		if($null_check){
			if($insr_code!= null){
				$ret_value = $insr_db->insurer_details($insr_code)->$column_name;
			}
		}else{
			$ret_value = $insr_db->insurer_details($insr_code)->$column_name;
		}
		return $ret_value;
	}
	
	public function user_data($column_name, $agent_code, $null_check = false) {
		$user_data = new UserMasterM();
		$ret_value = "";
		if($null_check){
			if($agent_code != null){
				$ret_value = $user_data->user_details($agent_code)->$column_name;
			}
		}else{
			$ret_value = $user_data->user_details($agent_code)->$column_name;
		}
		return $ret_value;
	} // end of function

	public function insr_pincode($column_name,$pincode) {
		$pincode_db = new TwPincode();
		return  $pincode_db->pincode_details($pincode)->$column_name;
	}
	
	
} // end of class
