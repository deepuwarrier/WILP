<?php
namespace App\Helpers\TW\MHDI;

use App\Helpers\TW\InsurerData;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use Illuminate\Support\Facades\Log;
use App\Be\TW\TwQuoteBe;
use App\Models\TW\TwODRates;
use App\Helpers\TW\MHDI\SoapDAO\Authenticate;
use App\Helpers\TW\MHDI\SoapDAO\AuthenticateResponse;
use App\Helpers\TW\MHDI\SoapDAO\GenerateProposalAndQuotationResponse;
use App\Helpers\TW\MHDI\SoapDAO\GenerateProposalAndQuotation;
use App\Helpers\TW\MHDI\SoapDAO\QuotationRequest;
															
 class MHDI_Quote_Factory {

public function get_quote(QuoteReqData $quote_req_data){	   
	
 		if( $quote_req_data->get_add_on_zrdp() || $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
		$pre_resp_data = new QuoteRespData();
		$pre_resp_data->_addon_flag(false);
		return $pre_resp_data;
	} 
	
	$token_obj = new Authenticate();
	$token_key = $this->get_token_key($token_obj);
	
	//populate request obj
	
	
	dd($token_key);
	
// 	$mstr_ob = new InsurerData();
// 	$quote_req_data->set_rto_zone( $mstr_ob->insr_rto("zone", $quote_req_data->get_rto_code() ) );

	$fillded_request = $this->populate_request($quote_req_data ); 

	// Prepare quote  request and call to quote to be parsed in Quote response object. 
	
	$raw_quote_resp= $this->init_quote( $fillded_request );  
	$resp_data = $this->parse_quote_resp($quote_req_data, $raw_quote_resp);  
	return $resp_data;
}

public function parse_quote_resp(QuoteReqData $quote_req_data, $xml_obj ){ // $xml_obj = Raw Quote Response. 
	$resp_data = new QuoteRespData();
	
	$ssn_key = $quote_req_data->get_ssn_key();
	$resp_data->_insurer_code("IITW005");
	$resp_data->_insurer_logo("mhdi_logo.png");
	$resp_data->_insurer_name("Magma HDI GI");
	$resp_data->_proposal_url("two-wheeler-insurance/mhdi");
	
	$resp_data->set_quote_id( $xml_obj->QUOTE_ID);
	
	$rec_idv_value =  (int)  $xml_obj->IDV;
	$calc_od_value = $this->calc_od($quote_req_data->get_tw_age() , $quote_req_data->get_tw_cc() , $quote_req_data->get_rto_zone(), $rec_idv_value);
	$od_disc_value = $calc_od_value - (int) $xml_obj->OD_PREMIUM->BASIC_PREMIUM_AND_NON_ELECTRICAL_ACCESSORIES;
	
	$resp_data->_od_value( $calc_od_value );
	$resp_data->_od_disc( $od_disc_value );
	$resp_data->_ncb_value( $xml_obj->OD_PREMIUM->NO_CLAIM_BONUS);
	$resp_data->_tp_value( $xml_obj->LIABILITY->BASIC_PREMIUM_INCLUDING_PREMIUM_FOR_TPPD);
	$resp_data->_pa_value( $xml_obj->LIABILITY->UNDER_SECTION_III_OWNER_DRIVER);
	$resp_data->_idv( $rec_idv_value);
	$resp_data->_gross_premium( $xml_obj->PACKAGE_PREMIUM);
	$resp_data->_service_tax( (int)$xml_obj->CGST + (int)$xml_obj->SGST);
	$resp_data->_final_premium(  $xml_obj->PREMIUM, 0 );
	
	$resp_data->_addon_zrdp( 0 );
	
	return $resp_data;
}

private function get_soap_object(){
	$wsdl_url = "https://webportal.magma-hdi.co.in:444/CIP-UAT-SERVICE/Retail.svc?wsdl";
	return new \SoapClient($wsdl_url);
}

// API (External) Call
private function get_token_key( $token_obj ) {
	$client = $this->get_soap_object();
	$resp = new AuthenticateResponse($client->Authenticate($token_obj));
	return $resp->getAuthenticateResult()->AuthenticateResult;
}

public function init_quote($quote_req_data){
	
	$req_obj = new QuotationRequest();
	$req_obj->setAuthenticationToken("97729e47-14b4-4a3b-aa99-0ecbaa8c446b");
	$req_obj->setProductCode("4102");
	$req_obj->setUserRole("Admin");
	$req_obj->setModeOfOperation("NEWPOLICY");
	$req_obj->setTypeofOperation("DetailQuote");
	try {
		
		$client = $this->get_soap_object();
		
		$req_obj->setInputXML($InputXML);
		
		
		$resp = $client->GenerateProposalAndQuotation($strLVAuthToken, $sresult)	;
		
		
		Log::info("TW RSGI Quote Response : ".  print_r($api_resp->DATA, true));
		return  $api_resp->DATA;
	}catch (\Exception $ee) {
		Log::error( "RSGI Quote : Execption while calling quote : ".$ee->getMessage());
	}
	return null;
} // end of method

private function populate_request(QuoteReqData $quote_req_data) {

	$mhdi_req_obj = new MHDI_Quote_Request();

	
	
	
	
	$mstr_map = new InsurerData();
	
	$req_params = array(
		"vehicleManufacturerName" => $mstr_map->insr_make("rsgi_code", $quote_req_data->get_make_code()),
		"vehicleModelCode" => $mstr_map->insr_variant("variant_name", $quote_req_data->get_variant_code()),
		"modelName" => $mstr_map->insr_variant("rsgi_code",  $quote_req_data->get_variant_code()),
		"engineCapacityAmount" =>$quote_req_data->get_tw_cc()." CC",
		"yearOfManufacture" => $quote_req_data->get_yom() ,
		"idv" => $quote_req_data->get_desired_idv(),
		"vehicleRegDate" => $this->format_date( $quote_req_data->get_registration_date()),
		"previousPolicyExpiryDate" => $this->format_date( $quote_req_data->get_prepolicy_end_date()) ,
		"policyStartDate" => $this->format_date( $quote_req_data->get_policy_start_date() ),
		"claimsMadeInPreviousPolicy" => $quote_req_data->get_claim_status() =="Y" ? "Yes" : "No",
		"ncbcurrent" => $quote_req_data->get_eligible_ncb(),
		"ncbprevious" => $quote_req_data->get_current_ncb(),
			"noClaimBonusPercent" => $this->ncb_rank( $quote_req_data->get_eligible_ncb())
	);

	$quote_init_req = $req_obj->prepare_quote_init($req_params);
	
	Log:info("TW RSGI Quote Request : ".$quote_init_req);
	return $quote_init_req;
} // end of method

private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}

private function calc_od ($tw_age, $tw_cc, $tw_rtozone, $idv_value) {
	$od_rate_db = new TwODRates();
	$tw_quote_be = new TwQuoteBe();
	$od_rate_data =  $tw_quote_be->tw_od_rate($tw_age, $tw_cc, $tw_rtozone);  
	return  ($idv_value * $od_rate_data->od_rate) / 100;  
} // end of method.


 } // end of class
