<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class Authenticate
{

    /**
     * @var string $UserID
     */
	protected $UserID = "tester_sec";

    /**
     * @var string $Password
     */
    protected $Password = "password1";

    /**
     * @param string $UserID
     * @param string $Password
     */
    public function __construct()
    {
    }

    /**
     * @return string
     */
    public function getUserID()
    {
      return $this->UserID;
    }

    /**
     * @param string $UserID
     * @return Authenticate
     */
    public function setUserID($UserID)
    {
      $this->UserID = $UserID;
      return $this;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
      return $this->Password;
    }

    /**
     * @param string $Password
     * @return Authenticate
     */
    public function setPassword($Password)
    {
      $this->Password = $Password;
      return $this;
    }

}
