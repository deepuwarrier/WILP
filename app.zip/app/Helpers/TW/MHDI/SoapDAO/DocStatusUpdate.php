<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class DocStatusUpdate
{

    /**
     * @var string $pAuthenticationKey
     */
    protected $pAuthenticationKey = null;

    /**
     * @var string $pProposalNo
     */
    protected $pProposalNo = null;

    /**
     * @var string $pRemarks
     */
    protected $pRemarks = null;

    /**
     * @param string $pAuthenticationKey
     * @param string $pProposalNo
     * @param string $pRemarks
     */
    public function __construct($pAuthenticationKey, $pProposalNo, $pRemarks)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      $this->pProposalNo = $pProposalNo;
      $this->pRemarks = $pRemarks;
    }

    /**
     * @return string
     */
    public function getPAuthenticationKey()
    {
      return $this->pAuthenticationKey;
    }

    /**
     * @param string $pAuthenticationKey
     * @return DocStatusUpdate
     */
    public function setPAuthenticationKey($pAuthenticationKey)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      return $this;
    }

    /**
     * @return string
     */
    public function getPProposalNo()
    {
      return $this->pProposalNo;
    }

    /**
     * @param string $pProposalNo
     * @return DocStatusUpdate
     */
    public function setPProposalNo($pProposalNo)
    {
      $this->pProposalNo = $pProposalNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getPRemarks()
    {
      return $this->pRemarks;
    }

    /**
     * @param string $pRemarks
     * @return DocStatusUpdate
     */
    public function setPRemarks($pRemarks)
    {
      $this->pRemarks = $pRemarks;
      return $this;
    }

}
