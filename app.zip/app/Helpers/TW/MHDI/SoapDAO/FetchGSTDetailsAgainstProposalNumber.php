<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchGSTDetailsAgainstProposalNumber
{

    /**
     * @var string $strLVTokenID
     */
    protected $strLVTokenID = null;

    /**
     * @var string $pReferenceNumber
     */
    protected $pReferenceNumber = null;

    /**
     * @param string $strLVTokenID
     * @param string $pReferenceNumber
     */
    public function __construct($strLVTokenID, $pReferenceNumber)
    {
      $this->strLVTokenID = $strLVTokenID;
      $this->pReferenceNumber = $pReferenceNumber;
    }

    /**
     * @return string
     */
    public function getStrLVTokenID()
    {
      return $this->strLVTokenID;
    }

    /**
     * @param string $strLVTokenID
     * @return FetchGSTDetailsAgainstProposalNumber
     */
    public function setStrLVTokenID($strLVTokenID)
    {
      $this->strLVTokenID = $strLVTokenID;
      return $this;
    }

    /**
     * @return string
     */
    public function getPReferenceNumber()
    {
      return $this->pReferenceNumber;
    }

    /**
     * @param string $pReferenceNumber
     * @return FetchGSTDetailsAgainstProposalNumber
     */
    public function setPReferenceNumber($pReferenceNumber)
    {
      $this->pReferenceNumber = $pReferenceNumber;
      return $this;
    }

}
