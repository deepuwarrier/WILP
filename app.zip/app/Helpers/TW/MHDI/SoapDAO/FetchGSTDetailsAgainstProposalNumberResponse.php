<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchGSTDetailsAgainstProposalNumberResponse
{

    /**
     * @var clsGSTAmount $FetchGSTDetailsAgainstProposalNumberResult
     */
    protected $FetchGSTDetailsAgainstProposalNumberResult = null;

    /**
     * @param clsGSTAmount $FetchGSTDetailsAgainstProposalNumberResult
     */
    public function __construct($FetchGSTDetailsAgainstProposalNumberResult)
    {
      $this->FetchGSTDetailsAgainstProposalNumberResult = $FetchGSTDetailsAgainstProposalNumberResult;
    }

    /**
     * @return clsGSTAmount
     */
    public function getFetchGSTDetailsAgainstProposalNumberResult()
    {
      return $this->FetchGSTDetailsAgainstProposalNumberResult;
    }

    /**
     * @param clsGSTAmount $FetchGSTDetailsAgainstProposalNumberResult
     * @return FetchGSTDetailsAgainstProposalNumberResponse
     */
    public function setFetchGSTDetailsAgainstProposalNumberResult($FetchGSTDetailsAgainstProposalNumberResult)
    {
      $this->FetchGSTDetailsAgainstProposalNumberResult = $FetchGSTDetailsAgainstProposalNumberResult;
      return $this;
    }

}
