<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchGSTRate
{

    /**
     * @var string $strLVTokenID
     */
    protected $strLVTokenID = null;

    /**
     * @var string $pGstStateCode
     */
    protected $pGstStateCode = null;

    /**
     * @var string $pProductCode
     */
    protected $pProductCode = null;

    /**
     * @var int $pServiceType
     */
    protected $pServiceType = null;

    /**
     * @var string $pEffectiveDate
     */
    protected $pEffectiveDate = null;

    /**
     * @param string $strLVTokenID
     * @param string $pGstStateCode
     * @param string $pProductCode
     * @param int $pServiceType
     * @param string $pEffectiveDate
     */
    public function __construct($strLVTokenID, $pGstStateCode, $pProductCode, $pServiceType, $pEffectiveDate)
    {
      $this->strLVTokenID = $strLVTokenID;
      $this->pGstStateCode = $pGstStateCode;
      $this->pProductCode = $pProductCode;
      $this->pServiceType = $pServiceType;
      $this->pEffectiveDate = $pEffectiveDate;
    }

    /**
     * @return string
     */
    public function getStrLVTokenID()
    {
      return $this->strLVTokenID;
    }

    /**
     * @param string $strLVTokenID
     * @return FetchGSTRate
     */
    public function setStrLVTokenID($strLVTokenID)
    {
      $this->strLVTokenID = $strLVTokenID;
      return $this;
    }

    /**
     * @return string
     */
    public function getPGstStateCode()
    {
      return $this->pGstStateCode;
    }

    /**
     * @param string $pGstStateCode
     * @return FetchGSTRate
     */
    public function setPGstStateCode($pGstStateCode)
    {
      $this->pGstStateCode = $pGstStateCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getPProductCode()
    {
      return $this->pProductCode;
    }

    /**
     * @param string $pProductCode
     * @return FetchGSTRate
     */
    public function setPProductCode($pProductCode)
    {
      $this->pProductCode = $pProductCode;
      return $this;
    }

    /**
     * @return int
     */
    public function getPServiceType()
    {
      return $this->pServiceType;
    }

    /**
     * @param int $pServiceType
     * @return FetchGSTRate
     */
    public function setPServiceType($pServiceType)
    {
      $this->pServiceType = $pServiceType;
      return $this;
    }

    /**
     * @return string
     */
    public function getPEffectiveDate()
    {
      return $this->pEffectiveDate;
    }

    /**
     * @param string $pEffectiveDate
     * @return FetchGSTRate
     */
    public function setPEffectiveDate($pEffectiveDate)
    {
      $this->pEffectiveDate = $pEffectiveDate;
      return $this;
    }

}
