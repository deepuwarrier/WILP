<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchGSTRateResponse
{

    /**
     * @var clsGstRateEngine $FetchGSTRateResult
     */
    protected $FetchGSTRateResult = null;

    /**
     * @param clsGstRateEngine $FetchGSTRateResult
     */
    public function __construct($FetchGSTRateResult)
    {
      $this->FetchGSTRateResult = $FetchGSTRateResult;
    }

    /**
     * @return clsGstRateEngine
     */
    public function getFetchGSTRateResult()
    {
      return $this->FetchGSTRateResult;
    }

    /**
     * @param clsGstRateEngine $FetchGSTRateResult
     * @return FetchGSTRateResponse
     */
    public function setFetchGSTRateResult($FetchGSTRateResult)
    {
      $this->FetchGSTRateResult = $FetchGSTRateResult;
      return $this;
    }

}
