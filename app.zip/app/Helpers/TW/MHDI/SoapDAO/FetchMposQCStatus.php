<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchMposQCStatus
{

    /**
     * @var string $pAuthenticationKey
     */
    protected $pAuthenticationKey = null;

    /**
     * @var string $pProposalNo
     */
    protected $pProposalNo = null;

    /**
     * @var string $pStatusType
     */
    protected $pStatusType = null;

    /**
     * @param string $pAuthenticationKey
     * @param string $pProposalNo
     * @param string $pStatusType
     */
    public function __construct($pAuthenticationKey, $pProposalNo, $pStatusType)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      $this->pProposalNo = $pProposalNo;
      $this->pStatusType = $pStatusType;
    }

    /**
     * @return string
     */
    public function getPAuthenticationKey()
    {
      return $this->pAuthenticationKey;
    }

    /**
     * @param string $pAuthenticationKey
     * @return FetchMposQCStatus
     */
    public function setPAuthenticationKey($pAuthenticationKey)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      return $this;
    }

    /**
     * @return string
     */
    public function getPProposalNo()
    {
      return $this->pProposalNo;
    }

    /**
     * @param string $pProposalNo
     * @return FetchMposQCStatus
     */
    public function setPProposalNo($pProposalNo)
    {
      $this->pProposalNo = $pProposalNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getPStatusType()
    {
      return $this->pStatusType;
    }

    /**
     * @param string $pStatusType
     * @return FetchMposQCStatus
     */
    public function setPStatusType($pStatusType)
    {
      $this->pStatusType = $pStatusType;
      return $this;
    }

}
