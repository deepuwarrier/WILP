<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchResultDistanceApprovalForInspection
{

    /**
     * @var string $pAuthenticationKey
     */
    protected $pAuthenticationKey = null;

    /**
     * @var PreinspectionSalesEntry $pPreInnspection
     */
    protected $pPreInnspection = null;

    /**
     * @param string $pAuthenticationKey
     * @param PreinspectionSalesEntry $pPreInnspection
     */
    public function __construct($pAuthenticationKey, $pPreInnspection)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      $this->pPreInnspection = $pPreInnspection;
    }

    /**
     * @return string
     */
    public function getPAuthenticationKey()
    {
      return $this->pAuthenticationKey;
    }

    /**
     * @param string $pAuthenticationKey
     * @return FetchResultDistanceApprovalForInspection
     */
    public function setPAuthenticationKey($pAuthenticationKey)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      return $this;
    }

    /**
     * @return PreinspectionSalesEntry
     */
    public function getPPreInnspection()
    {
      return $this->pPreInnspection;
    }

    /**
     * @param PreinspectionSalesEntry $pPreInnspection
     * @return FetchResultDistanceApprovalForInspection
     */
    public function setPPreInnspection($pPreInnspection)
    {
      $this->pPreInnspection = $pPreInnspection;
      return $this;
    }

}
