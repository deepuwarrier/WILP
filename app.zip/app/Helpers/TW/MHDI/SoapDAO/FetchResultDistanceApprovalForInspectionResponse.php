<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchResultDistanceApprovalForInspectionResponse
{

    /**
     * @var PreinspectionSalesEntry $FetchResultDistanceApprovalForInspectionResult
     */
    protected $FetchResultDistanceApprovalForInspectionResult = null;

    /**
     * @param PreinspectionSalesEntry $FetchResultDistanceApprovalForInspectionResult
     */
    public function __construct($FetchResultDistanceApprovalForInspectionResult)
    {
      $this->FetchResultDistanceApprovalForInspectionResult = $FetchResultDistanceApprovalForInspectionResult;
    }

    /**
     * @return PreinspectionSalesEntry
     */
    public function getFetchResultDistanceApprovalForInspectionResult()
    {
      return $this->FetchResultDistanceApprovalForInspectionResult;
    }

    /**
     * @param PreinspectionSalesEntry $FetchResultDistanceApprovalForInspectionResult
     * @return FetchResultDistanceApprovalForInspectionResponse
     */
    public function setFetchResultDistanceApprovalForInspectionResult($FetchResultDistanceApprovalForInspectionResult)
    {
      $this->FetchResultDistanceApprovalForInspectionResult = $FetchResultDistanceApprovalForInspectionResult;
      return $this;
    }

}
