<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class FetchVIInboxStageResponse
{

    /**
     * @var clsMPOSFetchVIStatus $FetchVIInboxStageResult
     */
    protected $FetchVIInboxStageResult = null;

    /**
     * @param clsMPOSFetchVIStatus $FetchVIInboxStageResult
     */
    public function __construct($FetchVIInboxStageResult)
    {
      $this->FetchVIInboxStageResult = $FetchVIInboxStageResult;
    }

    /**
     * @return clsMPOSFetchVIStatus
     */
    public function getFetchVIInboxStageResult()
    {
      return $this->FetchVIInboxStageResult;
    }

    /**
     * @param clsMPOSFetchVIStatus $FetchVIInboxStageResult
     * @return FetchVIInboxStageResponse
     */
    public function setFetchVIInboxStageResult($FetchVIInboxStageResult)
    {
      $this->FetchVIInboxStageResult = $FetchVIInboxStageResult;
      return $this;
    }

}
