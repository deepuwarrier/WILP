<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GeneratePolicy
{

    /**
     * @var string $strLVAuthToken
     */
    protected $strLVAuthToken = null;

    /**
     * @var PolicyRequest $objServiceResult
     */
    protected $objServiceResult = null;

    /**
     * @param string $strLVAuthToken
     * @param PolicyRequest $objServiceResult
     */
    public function __construct($strLVAuthToken, $objServiceResult)
    {
      $this->strLVAuthToken = $strLVAuthToken;
      $this->objServiceResult = $objServiceResult;
    }

    /**
     * @return string
     */
    public function getStrLVAuthToken()
    {
      return $this->strLVAuthToken;
    }

    /**
     * @param string $strLVAuthToken
     * @return GeneratePolicy
     */
    public function setStrLVAuthToken($strLVAuthToken)
    {
      $this->strLVAuthToken = $strLVAuthToken;
      return $this;
    }

    /**
     * @return PolicyRequest
     */
    public function getObjServiceResult()
    {
      return $this->objServiceResult;
    }

    /**
     * @param PolicyRequest $objServiceResult
     * @return GeneratePolicy
     */
    public function setObjServiceResult($objServiceResult)
    {
      $this->objServiceResult = $objServiceResult;
      return $this;
    }

}
