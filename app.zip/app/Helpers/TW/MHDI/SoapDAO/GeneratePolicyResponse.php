<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GeneratePolicyResponse
{

    /**
     * @var PolicyResponse $GeneratePolicyResult
     */
    protected $GeneratePolicyResult = null;

    /**
     * @var PolicyRequest $objServiceResult
     */
    protected $objServiceResult = null;

    /**
     * @param PolicyResponse $GeneratePolicyResult
     * @param PolicyRequest $objServiceResult
     */
    public function __construct($GeneratePolicyResult, $objServiceResult)
    {
      $this->GeneratePolicyResult = $GeneratePolicyResult;
      $this->objServiceResult = $objServiceResult;
    }

    /**
     * @return PolicyResponse
     */
    public function getGeneratePolicyResult()
    {
      return $this->GeneratePolicyResult;
    }

    /**
     * @param PolicyResponse $GeneratePolicyResult
     * @return GeneratePolicyResponse
     */
    public function setGeneratePolicyResult($GeneratePolicyResult)
    {
      $this->GeneratePolicyResult = $GeneratePolicyResult;
      return $this;
    }

    /**
     * @return PolicyRequest
     */
    public function getObjServiceResult()
    {
      return $this->objServiceResult;
    }

    /**
     * @param PolicyRequest $objServiceResult
     * @return GeneratePolicyResponse
     */
    public function setObjServiceResult($objServiceResult)
    {
      $this->objServiceResult = $objServiceResult;
      return $this;
    }

}
