<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GeneratePolicySchedulePDFResponse
{

    /**
     * @var GenerateScheduleResponse $GeneratePolicySchedulePDFResult
     */
    protected $GeneratePolicySchedulePDFResult = null;

    /**
     * @var GenerateScheduleRequest $objServiceResult
     */
    protected $objServiceResult = null;

    /**
     * @param GenerateScheduleResponse $GeneratePolicySchedulePDFResult
     * @param GenerateScheduleRequest $objServiceResult
     */
    public function __construct($GeneratePolicySchedulePDFResult, $objServiceResult)
    {
      $this->GeneratePolicySchedulePDFResult = $GeneratePolicySchedulePDFResult;
      $this->objServiceResult = $objServiceResult;
    }

    /**
     * @return GenerateScheduleResponse
     */
    public function getGeneratePolicySchedulePDFResult()
    {
      return $this->GeneratePolicySchedulePDFResult;
    }

    /**
     * @param GenerateScheduleResponse $GeneratePolicySchedulePDFResult
     * @return GeneratePolicySchedulePDFResponse
     */
    public function setGeneratePolicySchedulePDFResult($GeneratePolicySchedulePDFResult)
    {
      $this->GeneratePolicySchedulePDFResult = $GeneratePolicySchedulePDFResult;
      return $this;
    }

    /**
     * @return GenerateScheduleRequest
     */
    public function getObjServiceResult()
    {
      return $this->objServiceResult;
    }

    /**
     * @param GenerateScheduleRequest $objServiceResult
     * @return GeneratePolicySchedulePDFResponse
     */
    public function setObjServiceResult($objServiceResult)
    {
      $this->objServiceResult = $objServiceResult;
      return $this;
    }

}
