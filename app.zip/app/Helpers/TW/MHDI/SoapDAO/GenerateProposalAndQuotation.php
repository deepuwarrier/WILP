<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GenerateProposalAndQuotation
{

    /**
     * @var string $strLVAuthToken
     */
    protected $strLVAuthToken = null;

    /**
     * @var QuotationRequest $sresult
     */
    protected $sresult = null;

    /**
     * @param string $strLVAuthToken
     * @param QuotationRequest $sresult
     */
    public function __construct($strLVAuthToken, $sresult)
    {
      $this->strLVAuthToken = $strLVAuthToken;
      $this->sresult = $sresult;
    }

    /**
     * @return string
     */
    public function getStrLVAuthToken()
    {
      return $this->strLVAuthToken;
    }

    /**
     * @param string $strLVAuthToken
     * @return GenerateProposalAndQuotation
     */
    public function setStrLVAuthToken($strLVAuthToken)
    {
      $this->strLVAuthToken = $strLVAuthToken;
      return $this;
    }

    /**
     * @return QuotationRequest
     */
    public function getSresult()
    {
      return $this->sresult;
    }

    /**
     * @param QuotationRequest $sresult
     * @return GenerateProposalAndQuotation
     */
    public function setSresult($sresult)
    {
      $this->sresult = $sresult;
      return $this;
    }

}
