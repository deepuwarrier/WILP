<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GenerateScheduleResponse extends clsResponseProperties
{

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var base64Binary $PDFFile
     */
    protected $PDFFile = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return GenerateScheduleResponse
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return base64Binary
     */
    public function getPDFFile()
    {
      return $this->PDFFile;
    }

    /**
     * @param base64Binary $PDFFile
     * @return GenerateScheduleResponse
     */
    public function setPDFFile($PDFFile)
    {
      $this->PDFFile = $PDFFile;
      return $this;
    }

}
