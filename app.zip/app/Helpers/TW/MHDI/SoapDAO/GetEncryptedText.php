<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GetEncryptedText
{

    /**
     * @var string $strPlainText
     */
    protected $strPlainText = null;

    /**
     * @var string $strPassKey
     */
    protected $strPassKey = null;

    /**
     * @param string $strPlainText
     * @param string $strPassKey
     */
    public function __construct($strPlainText, $strPassKey)
    {
      $this->strPlainText = $strPlainText;
      $this->strPassKey = $strPassKey;
    }

    /**
     * @return string
     */
    public function getStrPlainText()
    {
      return $this->strPlainText;
    }

    /**
     * @param string $strPlainText
     * @return GetEncryptedText
     */
    public function setStrPlainText($strPlainText)
    {
      $this->strPlainText = $strPlainText;
      return $this;
    }

    /**
     * @return string
     */
    public function getStrPassKey()
    {
      return $this->strPassKey;
    }

    /**
     * @param string $strPassKey
     * @return GetEncryptedText
     */
    public function setStrPassKey($strPassKey)
    {
      $this->strPassKey = $strPassKey;
      return $this;
    }

}
