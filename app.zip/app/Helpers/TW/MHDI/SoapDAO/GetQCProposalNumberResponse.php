<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GetQCProposalNumberResponse
{

    /**
     * @var clsQCProposalNumber $GetQCProposalNumberResult
     */
    protected $GetQCProposalNumberResult = null;

    /**
     * @param clsQCProposalNumber $GetQCProposalNumberResult
     */
    public function __construct($GetQCProposalNumberResult)
    {
      $this->GetQCProposalNumberResult = $GetQCProposalNumberResult;
    }

    /**
     * @return clsQCProposalNumber
     */
    public function getGetQCProposalNumberResult()
    {
      return $this->GetQCProposalNumberResult;
    }

    /**
     * @param clsQCProposalNumber $GetQCProposalNumberResult
     * @return GetQCProposalNumberResponse
     */
    public function setGetQCProposalNumberResult($GetQCProposalNumberResult)
    {
      $this->GetQCProposalNumberResult = $GetQCProposalNumberResult;
      return $this;
    }

}
