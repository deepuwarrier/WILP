<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GetTxnIdForPartnerCompanyTransactionResponse
{

    /**
     * @var clsPartnerInfoForPaymentResponse $GetTxnIdForPartnerCompanyTransactionResult
     */
    protected $GetTxnIdForPartnerCompanyTransactionResult = null;

    /**
     * @param clsPartnerInfoForPaymentResponse $GetTxnIdForPartnerCompanyTransactionResult
     */
    public function __construct($GetTxnIdForPartnerCompanyTransactionResult)
    {
      $this->GetTxnIdForPartnerCompanyTransactionResult = $GetTxnIdForPartnerCompanyTransactionResult;
    }

    /**
     * @return clsPartnerInfoForPaymentResponse
     */
    public function getGetTxnIdForPartnerCompanyTransactionResult()
    {
      return $this->GetTxnIdForPartnerCompanyTransactionResult;
    }

    /**
     * @param clsPartnerInfoForPaymentResponse $GetTxnIdForPartnerCompanyTransactionResult
     * @return GetTxnIdForPartnerCompanyTransactionResponse
     */
    public function setGetTxnIdForPartnerCompanyTransactionResult($GetTxnIdForPartnerCompanyTransactionResult)
    {
      $this->GetTxnIdForPartnerCompanyTransactionResult = $GetTxnIdForPartnerCompanyTransactionResult;
      return $this;
    }

}
