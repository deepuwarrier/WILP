<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class GetUWStatusResponse
{

    /**
     * @var clsUWStatus $GetUWStatusResult
     */
    protected $GetUWStatusResult = null;

    /**
     * @param clsUWStatus $GetUWStatusResult
     */
    public function __construct($GetUWStatusResult)
    {
      $this->GetUWStatusResult = $GetUWStatusResult;
    }

    /**
     * @return clsUWStatus
     */
    public function getGetUWStatusResult()
    {
      return $this->GetUWStatusResult;
    }

    /**
     * @param clsUWStatus $GetUWStatusResult
     * @return GetUWStatusResponse
     */
    public function setGetUWStatusResult($GetUWStatusResult)
    {
      $this->GetUWStatusResult = $GetUWStatusResult;
      return $this;
    }

}
