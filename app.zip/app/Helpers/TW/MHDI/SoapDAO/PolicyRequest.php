<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class PolicyRequest extends clsRequestProperties
{

    /**
     * @var string $Info1
     */
    protected $Info1 = null;

    /**
     * @var string $Info2
     */
    protected $Info2 = null;

    /**
     * @var string $Info3
     */
    protected $Info3 = null;

    /**
     * @var string $Info4
     */
    protected $Info4 = null;

    /**
     * @var string $InputXML
     */
    protected $InputXML = null;

    /**
     * @var string $InstantPolicy
     */
    protected $InstantPolicy = null;

    /**
     * @var string $IsCDAccount
     */
    protected $IsCDAccount = null;

    /**
     * @var string $ModeOfOperation
     */
    protected $ModeOfOperation = null;

    /**
     * @var string $MsgType
     */
    protected $MsgType = null;

    /**
     * @var string $PolicyNumber
     */
    protected $PolicyNumber = null;

    /**
     * @var string $ProposalNumber
     */
    protected $ProposalNumber = null;

    /**
     * @var string $UserId
     */
    protected $UserId = null;

    /**
     * @var string $UserRole
     */
    protected $UserRole = null;

    /**
     * @var string $VehicleClassCode
     */
    protected $VehicleClassCode = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getInfo1()
    {
      return $this->Info1;
    }

    /**
     * @param string $Info1
     * @return PolicyRequest
     */
    public function setInfo1($Info1)
    {
      $this->Info1 = $Info1;
      return $this;
    }

    /**
     * @return string
     */
    public function getInfo2()
    {
      return $this->Info2;
    }

    /**
     * @param string $Info2
     * @return PolicyRequest
     */
    public function setInfo2($Info2)
    {
      $this->Info2 = $Info2;
      return $this;
    }

    /**
     * @return string
     */
    public function getInfo3()
    {
      return $this->Info3;
    }

    /**
     * @param string $Info3
     * @return PolicyRequest
     */
    public function setInfo3($Info3)
    {
      $this->Info3 = $Info3;
      return $this;
    }

    /**
     * @return string
     */
    public function getInfo4()
    {
      return $this->Info4;
    }

    /**
     * @param string $Info4
     * @return PolicyRequest
     */
    public function setInfo4($Info4)
    {
      $this->Info4 = $Info4;
      return $this;
    }

    /**
     * @return string
     */
    public function getInputXML()
    {
      return $this->InputXML;
    }

    /**
     * @param string $InputXML
     * @return PolicyRequest
     */
    public function setInputXML($InputXML)
    {
      $this->InputXML = $InputXML;
      return $this;
    }

    /**
     * @return string
     */
    public function getInstantPolicy()
    {
      return $this->InstantPolicy;
    }

    /**
     * @param string $InstantPolicy
     * @return PolicyRequest
     */
    public function setInstantPolicy($InstantPolicy)
    {
      $this->InstantPolicy = $InstantPolicy;
      return $this;
    }

    /**
     * @return string
     */
    public function getIsCDAccount()
    {
      return $this->IsCDAccount;
    }

    /**
     * @param string $IsCDAccount
     * @return PolicyRequest
     */
    public function setIsCDAccount($IsCDAccount)
    {
      $this->IsCDAccount = $IsCDAccount;
      return $this;
    }

    /**
     * @return string
     */
    public function getModeOfOperation()
    {
      return $this->ModeOfOperation;
    }

    /**
     * @param string $ModeOfOperation
     * @return PolicyRequest
     */
    public function setModeOfOperation($ModeOfOperation)
    {
      $this->ModeOfOperation = $ModeOfOperation;
      return $this;
    }

    /**
     * @return string
     */
    public function getMsgType()
    {
      return $this->MsgType;
    }

    /**
     * @param string $MsgType
     * @return PolicyRequest
     */
    public function setMsgType($MsgType)
    {
      $this->MsgType = $MsgType;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyNumber()
    {
      return $this->PolicyNumber;
    }

    /**
     * @param string $PolicyNumber
     * @return PolicyRequest
     */
    public function setPolicyNumber($PolicyNumber)
    {
      $this->PolicyNumber = $PolicyNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getProposalNumber()
    {
      return $this->ProposalNumber;
    }

    /**
     * @param string $ProposalNumber
     * @return PolicyRequest
     */
    public function setProposalNumber($ProposalNumber)
    {
      $this->ProposalNumber = $ProposalNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserId()
    {
      return $this->UserId;
    }

    /**
     * @param string $UserId
     * @return PolicyRequest
     */
    public function setUserId($UserId)
    {
      $this->UserId = $UserId;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserRole()
    {
      return $this->UserRole;
    }

    /**
     * @param string $UserRole
     * @return PolicyRequest
     */
    public function setUserRole($UserRole)
    {
      $this->UserRole = $UserRole;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleClassCode()
    {
      return $this->VehicleClassCode;
    }

    /**
     * @param string $VehicleClassCode
     * @return PolicyRequest
     */
    public function setVehicleClassCode($VehicleClassCode)
    {
      $this->VehicleClassCode = $VehicleClassCode;
      return $this;
    }

}
