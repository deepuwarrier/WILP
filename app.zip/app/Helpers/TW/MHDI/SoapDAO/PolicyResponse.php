<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class PolicyResponse extends clsResponseProperties
{

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var float $NetPremium
     */
    protected $NetPremium = null;

    /**
     * @var string $PaymentID
     */
    protected $PaymentID = null;

    /**
     * @var string $PolicyNumber
     */
    protected $PolicyNumber = null;

    /**
     * @var string $ProposalNumber
     */
    protected $ProposalNumber = null;

    /**
     * @var string $ResponseXML
     */
    protected $ResponseXML = null;

    /**
     * @var float $ServiceTax
     */
    protected $ServiceTax = null;

    /**
     * @var float $TotalPremium
     */
    protected $TotalPremium = null;

    /**
     * @var string $VoucherNumber
     */
    protected $VoucherNumber = null;

    /**
     * @var string $WorkflowID
     */
    protected $WorkflowID = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return PolicyResponse
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return float
     */
    public function getNetPremium()
    {
      return $this->NetPremium;
    }

    /**
     * @param float $NetPremium
     * @return PolicyResponse
     */
    public function setNetPremium($NetPremium)
    {
      $this->NetPremium = $NetPremium;
      return $this;
    }

    /**
     * @return string
     */
    public function getPaymentID()
    {
      return $this->PaymentID;
    }

    /**
     * @param string $PaymentID
     * @return PolicyResponse
     */
    public function setPaymentID($PaymentID)
    {
      $this->PaymentID = $PaymentID;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyNumber()
    {
      return $this->PolicyNumber;
    }

    /**
     * @param string $PolicyNumber
     * @return PolicyResponse
     */
    public function setPolicyNumber($PolicyNumber)
    {
      $this->PolicyNumber = $PolicyNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getProposalNumber()
    {
      return $this->ProposalNumber;
    }

    /**
     * @param string $ProposalNumber
     * @return PolicyResponse
     */
    public function setProposalNumber($ProposalNumber)
    {
      $this->ProposalNumber = $ProposalNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getResponseXML()
    {
      return $this->ResponseXML;
    }

    /**
     * @param string $ResponseXML
     * @return PolicyResponse
     */
    public function setResponseXML($ResponseXML)
    {
      $this->ResponseXML = $ResponseXML;
      return $this;
    }

    /**
     * @return float
     */
    public function getServiceTax()
    {
      return $this->ServiceTax;
    }

    /**
     * @param float $ServiceTax
     * @return PolicyResponse
     */
    public function setServiceTax($ServiceTax)
    {
      $this->ServiceTax = $ServiceTax;
      return $this;
    }

    /**
     * @return float
     */
    public function getTotalPremium()
    {
      return $this->TotalPremium;
    }

    /**
     * @param float $TotalPremium
     * @return PolicyResponse
     */
    public function setTotalPremium($TotalPremium)
    {
      $this->TotalPremium = $TotalPremium;
      return $this;
    }

    /**
     * @return string
     */
    public function getVoucherNumber()
    {
      return $this->VoucherNumber;
    }

    /**
     * @param string $VoucherNumber
     * @return PolicyResponse
     */
    public function setVoucherNumber($VoucherNumber)
    {
      $this->VoucherNumber = $VoucherNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getWorkflowID()
    {
      return $this->WorkflowID;
    }

    /**
     * @param string $WorkflowID
     * @return PolicyResponse
     */
    public function setWorkflowID($WorkflowID)
    {
      $this->WorkflowID = $WorkflowID;
      return $this;
    }

}
