<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class PreinspectionSalesEntry
{

    /**
     * @var string $ApprovalRemarks
     */
    protected $ApprovalRemarks = null;

    /**
     * @var string $ApprovalStatus
     */
    protected $ApprovalStatus = null;

    /**
     * @var string $AvoType
     */
    protected $AvoType = null;

    /**
     * @var string $DistanceTravelled
     */
    protected $DistanceTravelled = null;

    /**
     * @var string $EmpID
     */
    protected $EmpID = null;

    /**
     * @var string $EmpName
     */
    protected $EmpName = null;

    /**
     * @var string $InspectionDate
     */
    protected $InspectionDate = null;

    /**
     * @var string $InspectionDistance
     */
    protected $InspectionDistance = null;

    /**
     * @var string $InspectionNo
     */
    protected $InspectionNo = null;

    /**
     * @var string $OldInspectionID
     */
    protected $OldInspectionID = null;

    /**
     * @var string $PageMode
     */
    protected $PageMode = null;

    /**
     * @var string $PlaceFrom
     */
    protected $PlaceFrom = null;

    /**
     * @var string $PlaceTo
     */
    protected $PlaceTo = null;

    /**
     * @var string $RejectionDate
     */
    protected $RejectionDate = null;

    /**
     * @var string $Remarks
     */
    protected $Remarks = null;

    /**
     * @var string $StatusReturned
     */
    protected $StatusReturned = null;

    /**
     * @var string $TransFlag
     */
    protected $TransFlag = null;

    /**
     * @var string $UserID
     */
    protected $UserID = null;

    /**
     * @var string $UserRemarks
     */
    protected $UserRemarks = null;

    /**
     * @var string $VehicleClassCode
     */
    protected $VehicleClassCode = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getApprovalRemarks()
    {
      return $this->ApprovalRemarks;
    }

    /**
     * @param string $ApprovalRemarks
     * @return PreinspectionSalesEntry
     */
    public function setApprovalRemarks($ApprovalRemarks)
    {
      $this->ApprovalRemarks = $ApprovalRemarks;
      return $this;
    }

    /**
     * @return string
     */
    public function getApprovalStatus()
    {
      return $this->ApprovalStatus;
    }

    /**
     * @param string $ApprovalStatus
     * @return PreinspectionSalesEntry
     */
    public function setApprovalStatus($ApprovalStatus)
    {
      $this->ApprovalStatus = $ApprovalStatus;
      return $this;
    }

    /**
     * @return string
     */
    public function getAvoType()
    {
      return $this->AvoType;
    }

    /**
     * @param string $AvoType
     * @return PreinspectionSalesEntry
     */
    public function setAvoType($AvoType)
    {
      $this->AvoType = $AvoType;
      return $this;
    }

    /**
     * @return string
     */
    public function getDistanceTravelled()
    {
      return $this->DistanceTravelled;
    }

    /**
     * @param string $DistanceTravelled
     * @return PreinspectionSalesEntry
     */
    public function setDistanceTravelled($DistanceTravelled)
    {
      $this->DistanceTravelled = $DistanceTravelled;
      return $this;
    }

    /**
     * @return string
     */
    public function getEmpID()
    {
      return $this->EmpID;
    }

    /**
     * @param string $EmpID
     * @return PreinspectionSalesEntry
     */
    public function setEmpID($EmpID)
    {
      $this->EmpID = $EmpID;
      return $this;
    }

    /**
     * @return string
     */
    public function getEmpName()
    {
      return $this->EmpName;
    }

    /**
     * @param string $EmpName
     * @return PreinspectionSalesEntry
     */
    public function setEmpName($EmpName)
    {
      $this->EmpName = $EmpName;
      return $this;
    }

    /**
     * @return string
     */
    public function getInspectionDate()
    {
      return $this->InspectionDate;
    }

    /**
     * @param string $InspectionDate
     * @return PreinspectionSalesEntry
     */
    public function setInspectionDate($InspectionDate)
    {
      $this->InspectionDate = $InspectionDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getInspectionDistance()
    {
      return $this->InspectionDistance;
    }

    /**
     * @param string $InspectionDistance
     * @return PreinspectionSalesEntry
     */
    public function setInspectionDistance($InspectionDistance)
    {
      $this->InspectionDistance = $InspectionDistance;
      return $this;
    }

    /**
     * @return string
     */
    public function getInspectionNo()
    {
      return $this->InspectionNo;
    }

    /**
     * @param string $InspectionNo
     * @return PreinspectionSalesEntry
     */
    public function setInspectionNo($InspectionNo)
    {
      $this->InspectionNo = $InspectionNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getOldInspectionID()
    {
      return $this->OldInspectionID;
    }

    /**
     * @param string $OldInspectionID
     * @return PreinspectionSalesEntry
     */
    public function setOldInspectionID($OldInspectionID)
    {
      $this->OldInspectionID = $OldInspectionID;
      return $this;
    }

    /**
     * @return string
     */
    public function getPageMode()
    {
      return $this->PageMode;
    }

    /**
     * @param string $PageMode
     * @return PreinspectionSalesEntry
     */
    public function setPageMode($PageMode)
    {
      $this->PageMode = $PageMode;
      return $this;
    }

    /**
     * @return string
     */
    public function getPlaceFrom()
    {
      return $this->PlaceFrom;
    }

    /**
     * @param string $PlaceFrom
     * @return PreinspectionSalesEntry
     */
    public function setPlaceFrom($PlaceFrom)
    {
      $this->PlaceFrom = $PlaceFrom;
      return $this;
    }

    /**
     * @return string
     */
    public function getPlaceTo()
    {
      return $this->PlaceTo;
    }

    /**
     * @param string $PlaceTo
     * @return PreinspectionSalesEntry
     */
    public function setPlaceTo($PlaceTo)
    {
      $this->PlaceTo = $PlaceTo;
      return $this;
    }

    /**
     * @return string
     */
    public function getRejectionDate()
    {
      return $this->RejectionDate;
    }

    /**
     * @param string $RejectionDate
     * @return PreinspectionSalesEntry
     */
    public function setRejectionDate($RejectionDate)
    {
      $this->RejectionDate = $RejectionDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getRemarks()
    {
      return $this->Remarks;
    }

    /**
     * @param string $Remarks
     * @return PreinspectionSalesEntry
     */
    public function setRemarks($Remarks)
    {
      $this->Remarks = $Remarks;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatusReturned()
    {
      return $this->StatusReturned;
    }

    /**
     * @param string $StatusReturned
     * @return PreinspectionSalesEntry
     */
    public function setStatusReturned($StatusReturned)
    {
      $this->StatusReturned = $StatusReturned;
      return $this;
    }

    /**
     * @return string
     */
    public function getTransFlag()
    {
      return $this->TransFlag;
    }

    /**
     * @param string $TransFlag
     * @return PreinspectionSalesEntry
     */
    public function setTransFlag($TransFlag)
    {
      $this->TransFlag = $TransFlag;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserID()
    {
      return $this->UserID;
    }

    /**
     * @param string $UserID
     * @return PreinspectionSalesEntry
     */
    public function setUserID($UserID)
    {
      $this->UserID = $UserID;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserRemarks()
    {
      return $this->UserRemarks;
    }

    /**
     * @param string $UserRemarks
     * @return PreinspectionSalesEntry
     */
    public function setUserRemarks($UserRemarks)
    {
      $this->UserRemarks = $UserRemarks;
      return $this;
    }

    /**
     * @return string
     */
    public function getVehicleClassCode()
    {
      return $this->VehicleClassCode;
    }

    /**
     * @param string $VehicleClassCode
     * @return PreinspectionSalesEntry
     */
    public function setVehicleClassCode($VehicleClassCode)
    {
      $this->VehicleClassCode = $VehicleClassCode;
      return $this;
    }

}
