<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class QCStatusUpdate
{

    /**
     * @var string $pAuthenticationKey
     */
    protected $pAuthenticationKey = null;

    /**
     * @var string $pProposalNo
     */
    protected $pProposalNo = null;

    /**
     * @var string $pCaseType
     */
    protected $pCaseType = null;

    /**
     * @var string $pStatus
     */
    protected $pStatus = null;

    /**
     * @var string $pRemarks
     */
    protected $pRemarks = null;

    /**
     * @param string $pAuthenticationKey
     * @param string $pProposalNo
     * @param string $pCaseType
     * @param string $pStatus
     * @param string $pRemarks
     */
    public function __construct($pAuthenticationKey, $pProposalNo, $pCaseType, $pStatus, $pRemarks)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      $this->pProposalNo = $pProposalNo;
      $this->pCaseType = $pCaseType;
      $this->pStatus = $pStatus;
      $this->pRemarks = $pRemarks;
    }

    /**
     * @return string
     */
    public function getPAuthenticationKey()
    {
      return $this->pAuthenticationKey;
    }

    /**
     * @param string $pAuthenticationKey
     * @return QCStatusUpdate
     */
    public function setPAuthenticationKey($pAuthenticationKey)
    {
      $this->pAuthenticationKey = $pAuthenticationKey;
      return $this;
    }

    /**
     * @return string
     */
    public function getPProposalNo()
    {
      return $this->pProposalNo;
    }

    /**
     * @param string $pProposalNo
     * @return QCStatusUpdate
     */
    public function setPProposalNo($pProposalNo)
    {
      $this->pProposalNo = $pProposalNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getPCaseType()
    {
      return $this->pCaseType;
    }

    /**
     * @param string $pCaseType
     * @return QCStatusUpdate
     */
    public function setPCaseType($pCaseType)
    {
      $this->pCaseType = $pCaseType;
      return $this;
    }

    /**
     * @return string
     */
    public function getPStatus()
    {
      return $this->pStatus;
    }

    /**
     * @param string $pStatus
     * @return QCStatusUpdate
     */
    public function setPStatus($pStatus)
    {
      $this->pStatus = $pStatus;
      return $this;
    }

    /**
     * @return string
     */
    public function getPRemarks()
    {
      return $this->pRemarks;
    }

    /**
     * @param string $pRemarks
     * @return QCStatusUpdate
     */
    public function setPRemarks($pRemarks)
    {
      $this->pRemarks = $pRemarks;
      return $this;
    }

}
