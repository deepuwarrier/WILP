<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class QCStatusUpdateResponse
{

    /**
     * @var string $QCStatusUpdateResult
     */
    protected $QCStatusUpdateResult = null;

    /**
     * @param string $QCStatusUpdateResult
     */
    public function __construct($QCStatusUpdateResult)
    {
      $this->QCStatusUpdateResult = $QCStatusUpdateResult;
    }

    /**
     * @return string
     */
    public function getQCStatusUpdateResult()
    {
      return $this->QCStatusUpdateResult;
    }

    /**
     * @param string $QCStatusUpdateResult
     * @return QCStatusUpdateResponse
     */
    public function setQCStatusUpdateResult($QCStatusUpdateResult)
    {
      $this->QCStatusUpdateResult = $QCStatusUpdateResult;
      return $this;
    }

}
