<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class QuotationRequest extends clsRequestProperties
{

    /**
     * @var string $Info1
     */
    protected $Info1 = null;

    /**
     * @var string $InputXML
     */
    protected $InputXML = null;

    /**
     * @var string $ModeOfOperation
     */
    protected $ModeOfOperation = null;

    /**
     * @var string $MsgType
     */
    protected $MsgType = null;

    /**
     * @var string $QuotationNumber
     */
    protected $QuotationNumber = null;

    /**
     * @var string $QuotationVersion
     */
    protected $QuotationVersion = null;

    /**
     * @var string $TypeofOperation
     */
    protected $TypeofOperation = null;

    /**
     * @var string $UserId
     */
    protected $UserId = null;

    /**
     * @var string $UserRole
     */
    protected $UserRole = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getInfo1()
    {
      return $this->Info1;
    }

    /**
     * @param string $Info1
     * @return QuotationRequest
     */
    public function setInfo1($Info1)
    {
      $this->Info1 = $Info1;
      return $this;
    }

    /**
     * @return string
     */
    public function getInputXML()
    {
      return $this->InputXML;
    }

    /**
     * @param string $InputXML
     * @return QuotationRequest
     */
    public function setInputXML($InputXML)
    {
      $this->InputXML = $InputXML;
      return $this;
    }

    /**
     * @return string
     */
    public function getModeOfOperation()
    {
      return $this->ModeOfOperation;
    }

    /**
     * @param string $ModeOfOperation
     * @return QuotationRequest
     */
    public function setModeOfOperation($ModeOfOperation)
    {
      $this->ModeOfOperation = $ModeOfOperation;
      return $this;
    }

    /**
     * @return string
     */
    public function getMsgType()
    {
      return $this->MsgType;
    }

    /**
     * @param string $MsgType
     * @return QuotationRequest
     */
    public function setMsgType($MsgType)
    {
      $this->MsgType = $MsgType;
      return $this;
    }

    /**
     * @return string
     */
    public function getQuotationNumber()
    {
      return $this->QuotationNumber;
    }

    /**
     * @param string $QuotationNumber
     * @return QuotationRequest
     */
    public function setQuotationNumber($QuotationNumber)
    {
      $this->QuotationNumber = $QuotationNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getQuotationVersion()
    {
      return $this->QuotationVersion;
    }

    /**
     * @param string $QuotationVersion
     * @return QuotationRequest
     */
    public function setQuotationVersion($QuotationVersion)
    {
      $this->QuotationVersion = $QuotationVersion;
      return $this;
    }

    /**
     * @return string
     */
    public function getTypeofOperation()
    {
      return $this->TypeofOperation;
    }

    /**
     * @param string $TypeofOperation
     * @return QuotationRequest
     */
    public function setTypeofOperation($TypeofOperation)
    {
      $this->TypeofOperation = $TypeofOperation;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserId()
    {
      return $this->UserId;
    }

    /**
     * @param string $UserId
     * @return QuotationRequest
     */
    public function setUserId($UserId)
    {
      $this->UserId = $UserId;
      return $this;
    }

    /**
     * @return string
     */
    public function getUserRole()
    {
      return $this->UserRole;
    }

    /**
     * @param string $UserRole
     * @return QuotationRequest
     */
    public function setUserRole($UserRole)
    {
      $this->UserRole = $UserRole;
      return $this;
    }

}
