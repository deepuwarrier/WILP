<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class Retail extends \SoapClient
{

    /**
     * @var array $classmap The defined classes
     */
    private static $classmap = array (
      'QuotationRequest' => '\\QuotationRequest',
      'clsRequestProperties' => '\\clsRequestProperties',
      'clsCommonProperties' => '\\clsCommonProperties',
      'GenerateScheduleResponse' => '\\GenerateScheduleResponse',
      'clsResponseProperties' => '\\clsResponseProperties',
      'QuotationResponse' => '\\QuotationResponse',
      'PolicyResponse' => '\\PolicyResponse',
      'GenerateScheduleRequest' => '\\GenerateScheduleRequest',
      'PolicyRequest' => '\\PolicyRequest',
      'clsPartnerInfoForPaymentRequest' => '\\clsPartnerInfoForPaymentRequest',
      'clsPartnerInfoForPaymentResponse' => '\\clsPartnerInfoForPaymentResponse',
      'clsMPOSFetchVIStatus' => '\\clsMPOSFetchVIStatus',
      'clsRejection' => '\\clsRejection',
      'clsUWStatus' => '\\clsUWStatus',
      'clsQCStatus' => '\\clsQCStatus',
      'clsQCProposalNumber' => '\\clsQCProposalNumber',
      'clsGstRateEngine' => '\\clsGstRateEngine',
      'clsGSTAmount' => '\\clsGSTAmount',
      'PreinspectionSalesEntry' => '\\PreinspectionSalesEntry',
      'Authenticate' => '\\Authenticate',
      'AuthenticateResponse' => '\\AuthenticateResponse',
      'GenerateProposalAndQuotation' => '\\GenerateProposalAndQuotation',
      'GenerateProposalAndQuotationResponse' => '\\GenerateProposalAndQuotationResponse',
      'GeneratePolicy' => '\\GeneratePolicy',
      'GeneratePolicyResponse' => '\\GeneratePolicyResponse',
      'GetTxnIdForPartnerCompanyTransaction' => '\\GetTxnIdForPartnerCompanyTransaction',
      'GetTxnIdForPartnerCompanyTransactionResponse' => '\\GetTxnIdForPartnerCompanyTransactionResponse',
      'GetEncryptedText' => '\\GetEncryptedText',
      'GetEncryptedTextResponse' => '\\GetEncryptedTextResponse',
      'GeneratePolicySchedulePDF' => '\\GeneratePolicySchedulePDF',
      'GeneratePolicySchedulePDFResponse' => '\\GeneratePolicySchedulePDFResponse',
      'FetchVIInboxStage' => '\\FetchVIInboxStage',
      'FetchVIInboxStageResponse' => '\\FetchVIInboxStageResponse',
      'GetQCProposalNumber' => '\\GetQCProposalNumber',
      'GetQCProposalNumberResponse' => '\\GetQCProposalNumberResponse',
      'FetchMposQCStatus' => '\\FetchMposQCStatus',
      'FetchMposQCStatusResponse' => '\\FetchMposQCStatusResponse',
      'GetUWStatus' => '\\GetUWStatus',
      'GetUWStatusResponse' => '\\GetUWStatusResponse',
      'FetchGSTRate' => '\\FetchGSTRate',
      'FetchGSTRateResponse' => '\\FetchGSTRateResponse',
      'FetchGSTDetailsAgainstProposalNumber' => '\\FetchGSTDetailsAgainstProposalNumber',
      'FetchGSTDetailsAgainstProposalNumberResponse' => '\\FetchGSTDetailsAgainstProposalNumberResponse',
      'QCStatusUpdate' => '\\QCStatusUpdate',
      'QCStatusUpdateResponse' => '\\QCStatusUpdateResponse',
      'DocStatusUpdate' => '\\DocStatusUpdate',
      'DocStatusUpdateResponse' => '\\DocStatusUpdateResponse',
      'FetchResultDistanceApprovalForInspection' => '\\FetchResultDistanceApprovalForInspection',
      'FetchResultDistanceApprovalForInspectionResponse' => '\\FetchResultDistanceApprovalForInspectionResponse',
    );

    /**
     * @param string $wsdl The wsdl file to use
     * @param array $options A array of config values
     */
    public function __construct(array $options = array(), $wsdl = null)
    {
      foreach (self::$classmap as $key => $value) {
        if (!isset($options['classmap'][$key])) {
          $options['classmap'][$key] = $value;
        }
      }
      $options = array_merge(array (
      'authentication' => 0,
      'login' => 'username',
      'password' => 'secret',
      'connection_timeout' => 60,
      'features' => 1,
    ), $options);
      if (!$wsdl) {
        $wsdl = 'MHDI.xml';
      }
      parent::__construct($wsdl, $options);
    }

    /**
     * @param Authenticate $parameters
     * @return AuthenticateResponse
     */
    public function Authenticate(Authenticate $parameters)
    {
      return $this->__soapCall('Authenticate', array($parameters));
    }

    /**
     * @param GenerateProposalAndQuotation $parameters
     * @return GenerateProposalAndQuotationResponse
     */
    public function GenerateProposalAndQuotation(GenerateProposalAndQuotation $parameters)
    {
      return $this->__soapCall('GenerateProposalAndQuotation', array($parameters));
    }

    /**
     * @param GeneratePolicy $parameters
     * @return GeneratePolicyResponse
     */
    public function GeneratePolicy(GeneratePolicy $parameters)
    {
      return $this->__soapCall('GeneratePolicy', array($parameters));
    }

    /**
     * @param GetTxnIdForPartnerCompanyTransaction $parameters
     * @return GetTxnIdForPartnerCompanyTransactionResponse
     */
    public function GetTxnIdForPartnerCompanyTransaction(GetTxnIdForPartnerCompanyTransaction $parameters)
    {
      return $this->__soapCall('GetTxnIdForPartnerCompanyTransaction', array($parameters));
    }

    /**
     * @param GetEncryptedText $parameters
     * @return GetEncryptedTextResponse
     */
    public function GetEncryptedText(GetEncryptedText $parameters)
    {
      return $this->__soapCall('GetEncryptedText', array($parameters));
    }

    /**
     * @param GeneratePolicySchedulePDF $parameters
     * @return GeneratePolicySchedulePDFResponse
     */
    public function GeneratePolicySchedulePDF(GeneratePolicySchedulePDF $parameters)
    {
      return $this->__soapCall('GeneratePolicySchedulePDF', array($parameters));
    }

    /**
     * @param FetchVIInboxStage $parameters
     * @return FetchVIInboxStageResponse
     */
    public function FetchVIInboxStage(FetchVIInboxStage $parameters)
    {
      return $this->__soapCall('FetchVIInboxStage', array($parameters));
    }

    /**
     * @param GetQCProposalNumber $parameters
     * @return GetQCProposalNumberResponse
     */
    public function GetQCProposalNumber(GetQCProposalNumber $parameters)
    {
      return $this->__soapCall('GetQCProposalNumber', array($parameters));
    }

    /**
     * @param FetchMposQCStatus $parameters
     * @return FetchMposQCStatusResponse
     */
    public function FetchMposQCStatus(FetchMposQCStatus $parameters)
    {
      return $this->__soapCall('FetchMposQCStatus', array($parameters));
    }

    /**
     * @param GetUWStatus $parameters
     * @return GetUWStatusResponse
     */
    public function GetUWStatus(GetUWStatus $parameters)
    {
      return $this->__soapCall('GetUWStatus', array($parameters));
    }

    /**
     * @param FetchGSTRate $parameters
     * @return FetchGSTRateResponse
     */
    public function FetchGSTRate(FetchGSTRate $parameters)
    {
      return $this->__soapCall('FetchGSTRate', array($parameters));
    }

    /**
     * @param FetchGSTDetailsAgainstProposalNumber $parameters
     * @return FetchGSTDetailsAgainstProposalNumberResponse
     */
    public function FetchGSTDetailsAgainstProposalNumber(FetchGSTDetailsAgainstProposalNumber $parameters)
    {
      return $this->__soapCall('FetchGSTDetailsAgainstProposalNumber', array($parameters));
    }

    /**
     * @param QCStatusUpdate $parameters
     * @return QCStatusUpdateResponse
     */
    public function QCStatusUpdate(QCStatusUpdate $parameters)
    {
      return $this->__soapCall('QCStatusUpdate', array($parameters));
    }

    /**
     * @param DocStatusUpdate $parameters
     * @return DocStatusUpdateResponse
     */
    public function DocStatusUpdate(DocStatusUpdate $parameters)
    {
      return $this->__soapCall('DocStatusUpdate', array($parameters));
    }

    /**
     * @param FetchResultDistanceApprovalForInspection $parameters
     * @return FetchResultDistanceApprovalForInspectionResponse
     */
    public function FetchResultDistanceApprovalForInspection(FetchResultDistanceApprovalForInspection $parameters)
    {
      return $this->__soapCall('FetchResultDistanceApprovalForInspection', array($parameters));
    }

}
