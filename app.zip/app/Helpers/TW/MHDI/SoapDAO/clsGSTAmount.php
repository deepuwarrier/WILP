<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsGSTAmount
{

    /**
     * @var string $AccountingCode
     */
    protected $AccountingCode = null;

    /**
     * @var float $CessAmount
     */
    protected $CessAmount = null;

    /**
     * @var float $CgstAmount
     */
    protected $CgstAmount = null;

    /**
     * @var string $ChallanDate
     */
    protected $ChallanDate = null;

    /**
     * @var string $ChallanNo
     */
    protected $ChallanNo = null;

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $GSTInvoiceNumber
     */
    protected $GSTInvoiceNumber = null;

    /**
     * @var string $GSTNumberOfMHDI
     */
    protected $GSTNumberOfMHDI = null;

    /**
     * @var float $GstAmount
     */
    protected $GstAmount = null;

    /**
     * @var float $IgstAmount
     */
    protected $IgstAmount = null;

    /**
     * @var string $NetPremium
     */
    protected $NetPremium = null;

    /**
     * @var string $PlaceOfService
     */
    protected $PlaceOfService = null;

    /**
     * @var string $PolicyEndDate
     */
    protected $PolicyEndDate = null;

    /**
     * @var string $PolicyIssueDate
     */
    protected $PolicyIssueDate = null;

    /**
     * @var string $PolicyServicingOfficeAddress
     */
    protected $PolicyServicingOfficeAddress = null;

    /**
     * @var string $PolicyServicingOfficeCode
     */
    protected $PolicyServicingOfficeCode = null;

    /**
     * @var string $PolicyStartDate
     */
    protected $PolicyStartDate = null;

    /**
     * @var string $PolicyStartTime
     */
    protected $PolicyStartTime = null;

    /**
     * @var string $ReceiptDate
     */
    protected $ReceiptDate = null;

    /**
     * @var string $ReceiptNumber
     */
    protected $ReceiptNumber = null;

    /**
     * @var string $ReferenceNumber
     */
    protected $ReferenceNumber = null;

    /**
     * @var float $SgstAmount
     */
    protected $SgstAmount = null;

    /**
     * @var string $TotalPremium
     */
    protected $TotalPremium = null;

    /**
     * @var float $UgstAmount
     */
    protected $UgstAmount = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getAccountingCode()
    {
      return $this->AccountingCode;
    }

    /**
     * @param string $AccountingCode
     * @return clsGSTAmount
     */
    public function setAccountingCode($AccountingCode)
    {
      $this->AccountingCode = $AccountingCode;
      return $this;
    }

    /**
     * @return float
     */
    public function getCessAmount()
    {
      return $this->CessAmount;
    }

    /**
     * @param float $CessAmount
     * @return clsGSTAmount
     */
    public function setCessAmount($CessAmount)
    {
      $this->CessAmount = $CessAmount;
      return $this;
    }

    /**
     * @return float
     */
    public function getCgstAmount()
    {
      return $this->CgstAmount;
    }

    /**
     * @param float $CgstAmount
     * @return clsGSTAmount
     */
    public function setCgstAmount($CgstAmount)
    {
      $this->CgstAmount = $CgstAmount;
      return $this;
    }

    /**
     * @return string
     */
    public function getChallanDate()
    {
      return $this->ChallanDate;
    }

    /**
     * @param string $ChallanDate
     * @return clsGSTAmount
     */
    public function setChallanDate($ChallanDate)
    {
      $this->ChallanDate = $ChallanDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getChallanNo()
    {
      return $this->ChallanNo;
    }

    /**
     * @param string $ChallanNo
     * @return clsGSTAmount
     */
    public function setChallanNo($ChallanNo)
    {
      $this->ChallanNo = $ChallanNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsGSTAmount
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getGSTInvoiceNumber()
    {
      return $this->GSTInvoiceNumber;
    }

    /**
     * @param string $GSTInvoiceNumber
     * @return clsGSTAmount
     */
    public function setGSTInvoiceNumber($GSTInvoiceNumber)
    {
      $this->GSTInvoiceNumber = $GSTInvoiceNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getGSTNumberOfMHDI()
    {
      return $this->GSTNumberOfMHDI;
    }

    /**
     * @param string $GSTNumberOfMHDI
     * @return clsGSTAmount
     */
    public function setGSTNumberOfMHDI($GSTNumberOfMHDI)
    {
      $this->GSTNumberOfMHDI = $GSTNumberOfMHDI;
      return $this;
    }

    /**
     * @return float
     */
    public function getGstAmount()
    {
      return $this->GstAmount;
    }

    /**
     * @param float $GstAmount
     * @return clsGSTAmount
     */
    public function setGstAmount($GstAmount)
    {
      $this->GstAmount = $GstAmount;
      return $this;
    }

    /**
     * @return float
     */
    public function getIgstAmount()
    {
      return $this->IgstAmount;
    }

    /**
     * @param float $IgstAmount
     * @return clsGSTAmount
     */
    public function setIgstAmount($IgstAmount)
    {
      $this->IgstAmount = $IgstAmount;
      return $this;
    }

    /**
     * @return string
     */
    public function getNetPremium()
    {
      return $this->NetPremium;
    }

    /**
     * @param string $NetPremium
     * @return clsGSTAmount
     */
    public function setNetPremium($NetPremium)
    {
      $this->NetPremium = $NetPremium;
      return $this;
    }

    /**
     * @return string
     */
    public function getPlaceOfService()
    {
      return $this->PlaceOfService;
    }

    /**
     * @param string $PlaceOfService
     * @return clsGSTAmount
     */
    public function setPlaceOfService($PlaceOfService)
    {
      $this->PlaceOfService = $PlaceOfService;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyEndDate()
    {
      return $this->PolicyEndDate;
    }

    /**
     * @param string $PolicyEndDate
     * @return clsGSTAmount
     */
    public function setPolicyEndDate($PolicyEndDate)
    {
      $this->PolicyEndDate = $PolicyEndDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyIssueDate()
    {
      return $this->PolicyIssueDate;
    }

    /**
     * @param string $PolicyIssueDate
     * @return clsGSTAmount
     */
    public function setPolicyIssueDate($PolicyIssueDate)
    {
      $this->PolicyIssueDate = $PolicyIssueDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyServicingOfficeAddress()
    {
      return $this->PolicyServicingOfficeAddress;
    }

    /**
     * @param string $PolicyServicingOfficeAddress
     * @return clsGSTAmount
     */
    public function setPolicyServicingOfficeAddress($PolicyServicingOfficeAddress)
    {
      $this->PolicyServicingOfficeAddress = $PolicyServicingOfficeAddress;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyServicingOfficeCode()
    {
      return $this->PolicyServicingOfficeCode;
    }

    /**
     * @param string $PolicyServicingOfficeCode
     * @return clsGSTAmount
     */
    public function setPolicyServicingOfficeCode($PolicyServicingOfficeCode)
    {
      $this->PolicyServicingOfficeCode = $PolicyServicingOfficeCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyStartDate()
    {
      return $this->PolicyStartDate;
    }

    /**
     * @param string $PolicyStartDate
     * @return clsGSTAmount
     */
    public function setPolicyStartDate($PolicyStartDate)
    {
      $this->PolicyStartDate = $PolicyStartDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getPolicyStartTime()
    {
      return $this->PolicyStartTime;
    }

    /**
     * @param string $PolicyStartTime
     * @return clsGSTAmount
     */
    public function setPolicyStartTime($PolicyStartTime)
    {
      $this->PolicyStartTime = $PolicyStartTime;
      return $this;
    }

    /**
     * @return string
     */
    public function getReceiptDate()
    {
      return $this->ReceiptDate;
    }

    /**
     * @param string $ReceiptDate
     * @return clsGSTAmount
     */
    public function setReceiptDate($ReceiptDate)
    {
      $this->ReceiptDate = $ReceiptDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getReceiptNumber()
    {
      return $this->ReceiptNumber;
    }

    /**
     * @param string $ReceiptNumber
     * @return clsGSTAmount
     */
    public function setReceiptNumber($ReceiptNumber)
    {
      $this->ReceiptNumber = $ReceiptNumber;
      return $this;
    }

    /**
     * @return string
     */
    public function getReferenceNumber()
    {
      return $this->ReferenceNumber;
    }

    /**
     * @param string $ReferenceNumber
     * @return clsGSTAmount
     */
    public function setReferenceNumber($ReferenceNumber)
    {
      $this->ReferenceNumber = $ReferenceNumber;
      return $this;
    }

    /**
     * @return float
     */
    public function getSgstAmount()
    {
      return $this->SgstAmount;
    }

    /**
     * @param float $SgstAmount
     * @return clsGSTAmount
     */
    public function setSgstAmount($SgstAmount)
    {
      $this->SgstAmount = $SgstAmount;
      return $this;
    }

    /**
     * @return string
     */
    public function getTotalPremium()
    {
      return $this->TotalPremium;
    }

    /**
     * @param string $TotalPremium
     * @return clsGSTAmount
     */
    public function setTotalPremium($TotalPremium)
    {
      $this->TotalPremium = $TotalPremium;
      return $this;
    }

    /**
     * @return float
     */
    public function getUgstAmount()
    {
      return $this->UgstAmount;
    }

    /**
     * @param float $UgstAmount
     * @return clsGSTAmount
     */
    public function setUgstAmount($UgstAmount)
    {
      $this->UgstAmount = $UgstAmount;
      return $this;
    }

}
