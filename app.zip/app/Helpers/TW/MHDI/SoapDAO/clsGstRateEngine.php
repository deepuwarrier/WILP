<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsGstRateEngine
{

    /**
     * @var string $CessRate
     */
    protected $CessRate = null;

    /**
     * @var string $CgstRate
     */
    protected $CgstRate = null;

    /**
     * @var string $EffectiveDate
     */
    protected $EffectiveDate = null;

    /**
     * @var string $ErrorCode
     */
    protected $ErrorCode = null;

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $GCStateCode
     */
    protected $GCStateCode = null;

    /**
     * @var string $IGstRate
     */
    protected $IGstRate = null;

    /**
     * @var string $ProductCode
     */
    protected $ProductCode = null;

    /**
     * @var string $SGstRate
     */
    protected $SGstRate = null;

    /**
     * @var int $ServiceType
     */
    protected $ServiceType = null;

    /**
     * @var string $TotalGstRate
     */
    protected $TotalGstRate = null;

    /**
     * @var string $UGstRate
     */
    protected $UGstRate = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getCessRate()
    {
      return $this->CessRate;
    }

    /**
     * @param string $CessRate
     * @return clsGstRateEngine
     */
    public function setCessRate($CessRate)
    {
      $this->CessRate = $CessRate;
      return $this;
    }

    /**
     * @return string
     */
    public function getCgstRate()
    {
      return $this->CgstRate;
    }

    /**
     * @param string $CgstRate
     * @return clsGstRateEngine
     */
    public function setCgstRate($CgstRate)
    {
      $this->CgstRate = $CgstRate;
      return $this;
    }

    /**
     * @return string
     */
    public function getEffectiveDate()
    {
      return $this->EffectiveDate;
    }

    /**
     * @param string $EffectiveDate
     * @return clsGstRateEngine
     */
    public function setEffectiveDate($EffectiveDate)
    {
      $this->EffectiveDate = $EffectiveDate;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorCode()
    {
      return $this->ErrorCode;
    }

    /**
     * @param string $ErrorCode
     * @return clsGstRateEngine
     */
    public function setErrorCode($ErrorCode)
    {
      $this->ErrorCode = $ErrorCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsGstRateEngine
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getGCStateCode()
    {
      return $this->GCStateCode;
    }

    /**
     * @param string $GCStateCode
     * @return clsGstRateEngine
     */
    public function setGCStateCode($GCStateCode)
    {
      $this->GCStateCode = $GCStateCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getIGstRate()
    {
      return $this->IGstRate;
    }

    /**
     * @param string $IGstRate
     * @return clsGstRateEngine
     */
    public function setIGstRate($IGstRate)
    {
      $this->IGstRate = $IGstRate;
      return $this;
    }

    /**
     * @return string
     */
    public function getProductCode()
    {
      return $this->ProductCode;
    }

    /**
     * @param string $ProductCode
     * @return clsGstRateEngine
     */
    public function setProductCode($ProductCode)
    {
      $this->ProductCode = $ProductCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getSGstRate()
    {
      return $this->SGstRate;
    }

    /**
     * @param string $SGstRate
     * @return clsGstRateEngine
     */
    public function setSGstRate($SGstRate)
    {
      $this->SGstRate = $SGstRate;
      return $this;
    }

    /**
     * @return int
     */
    public function getServiceType()
    {
      return $this->ServiceType;
    }

    /**
     * @param int $ServiceType
     * @return clsGstRateEngine
     */
    public function setServiceType($ServiceType)
    {
      $this->ServiceType = $ServiceType;
      return $this;
    }

    /**
     * @return string
     */
    public function getTotalGstRate()
    {
      return $this->TotalGstRate;
    }

    /**
     * @param string $TotalGstRate
     * @return clsGstRateEngine
     */
    public function setTotalGstRate($TotalGstRate)
    {
      $this->TotalGstRate = $TotalGstRate;
      return $this;
    }

    /**
     * @return string
     */
    public function getUGstRate()
    {
      return $this->UGstRate;
    }

    /**
     * @param string $UGstRate
     * @return clsGstRateEngine
     */
    public function setUGstRate($UGstRate)
    {
      $this->UGstRate = $UGstRate;
      return $this;
    }

}
