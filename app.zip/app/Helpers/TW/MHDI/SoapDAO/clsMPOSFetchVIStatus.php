<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsMPOSFetchVIStatus extends clsRejection
{

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $InspectionID
     */
    protected $InspectionID = null;

    /**
     * @var string $Remarks
     */
    protected $Remarks = null;

    /**
     * @var string $Status
     */
    protected $Status = null;

    /**
     * @var string $Type
     */
    protected $Type = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsMPOSFetchVIStatus
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getInspectionID()
    {
      return $this->InspectionID;
    }

    /**
     * @param string $InspectionID
     * @return clsMPOSFetchVIStatus
     */
    public function setInspectionID($InspectionID)
    {
      $this->InspectionID = $InspectionID;
      return $this;
    }

    /**
     * @return string
     */
    public function getRemarks()
    {
      return $this->Remarks;
    }

    /**
     * @param string $Remarks
     * @return clsMPOSFetchVIStatus
     */
    public function setRemarks($Remarks)
    {
      $this->Remarks = $Remarks;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatus()
    {
      return $this->Status;
    }

    /**
     * @param string $Status
     * @return clsMPOSFetchVIStatus
     */
    public function setStatus($Status)
    {
      $this->Status = $Status;
      return $this;
    }

    /**
     * @return string
     */
    public function getType()
    {
      return $this->Type;
    }

    /**
     * @param string $Type
     * @return clsMPOSFetchVIStatus
     */
    public function setType($Type)
    {
      $this->Type = $Type;
      return $this;
    }

}
