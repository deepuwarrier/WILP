<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsPartnerInfoForPaymentRequest
{

    /**
     * @var float $BillingAmount
     */
    protected $BillingAmount = null;

    /**
     * @var string $BillingPaymentMode
     */
    protected $BillingPaymentMode = null;

    /**
     * @var string $ErrorCode
     */
    protected $ErrorCode = null;

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $FailureURL
     */
    protected $FailureURL = null;

    /**
     * @var string $PartnerCustomerId
     */
    protected $PartnerCustomerId = null;

    /**
     * @var string $PartnerEmail
     */
    protected $PartnerEmail = null;

    /**
     * @var string $PartnerSource
     */
    protected $PartnerSource = null;

    /**
     * @var string $PaymentGatewayType
     */
    protected $PaymentGatewayType = null;

    /**
     * @var float $ProposalNo
     */
    protected $ProposalNo = null;

    /**
     * @var string $SuccessURL
     */
    protected $SuccessURL = null;

    /**
     * @var float $TransactionId
     */
    protected $TransactionId = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return float
     */
    public function getBillingAmount()
    {
      return $this->BillingAmount;
    }

    /**
     * @param float $BillingAmount
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setBillingAmount($BillingAmount)
    {
      $this->BillingAmount = $BillingAmount;
      return $this;
    }

    /**
     * @return string
     */
    public function getBillingPaymentMode()
    {
      return $this->BillingPaymentMode;
    }

    /**
     * @param string $BillingPaymentMode
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setBillingPaymentMode($BillingPaymentMode)
    {
      $this->BillingPaymentMode = $BillingPaymentMode;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorCode()
    {
      return $this->ErrorCode;
    }

    /**
     * @param string $ErrorCode
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setErrorCode($ErrorCode)
    {
      $this->ErrorCode = $ErrorCode;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getFailureURL()
    {
      return $this->FailureURL;
    }

    /**
     * @param string $FailureURL
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setFailureURL($FailureURL)
    {
      $this->FailureURL = $FailureURL;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartnerCustomerId()
    {
      return $this->PartnerCustomerId;
    }

    /**
     * @param string $PartnerCustomerId
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setPartnerCustomerId($PartnerCustomerId)
    {
      $this->PartnerCustomerId = $PartnerCustomerId;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartnerEmail()
    {
      return $this->PartnerEmail;
    }

    /**
     * @param string $PartnerEmail
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setPartnerEmail($PartnerEmail)
    {
      $this->PartnerEmail = $PartnerEmail;
      return $this;
    }

    /**
     * @return string
     */
    public function getPartnerSource()
    {
      return $this->PartnerSource;
    }

    /**
     * @param string $PartnerSource
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setPartnerSource($PartnerSource)
    {
      $this->PartnerSource = $PartnerSource;
      return $this;
    }

    /**
     * @return string
     */
    public function getPaymentGatewayType()
    {
      return $this->PaymentGatewayType;
    }

    /**
     * @param string $PaymentGatewayType
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setPaymentGatewayType($PaymentGatewayType)
    {
      $this->PaymentGatewayType = $PaymentGatewayType;
      return $this;
    }

    /**
     * @return float
     */
    public function getProposalNo()
    {
      return $this->ProposalNo;
    }

    /**
     * @param float $ProposalNo
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setProposalNo($ProposalNo)
    {
      $this->ProposalNo = $ProposalNo;
      return $this;
    }

    /**
     * @return string
     */
    public function getSuccessURL()
    {
      return $this->SuccessURL;
    }

    /**
     * @param string $SuccessURL
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setSuccessURL($SuccessURL)
    {
      $this->SuccessURL = $SuccessURL;
      return $this;
    }

    /**
     * @return float
     */
    public function getTransactionId()
    {
      return $this->TransactionId;
    }

    /**
     * @param float $TransactionId
     * @return clsPartnerInfoForPaymentRequest
     */
    public function setTransactionId($TransactionId)
    {
      $this->TransactionId = $TransactionId;
      return $this;
    }

}
