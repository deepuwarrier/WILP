<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsQCProposalNumber
{

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $ProposalNumber
     */
    protected $ProposalNumber = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsQCProposalNumber
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getProposalNumber()
    {
      return $this->ProposalNumber;
    }

    /**
     * @param string $ProposalNumber
     * @return clsQCProposalNumber
     */
    public function setProposalNumber($ProposalNumber)
    {
      $this->ProposalNumber = $ProposalNumber;
      return $this;
    }

}
