<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsQCStatus extends clsRejection
{

    /**
     * @var string $BounceBackRemarks
     */
    protected $BounceBackRemarks = null;

    /**
     * @var string $ErrorText
     */
    protected $ErrorText = null;

    /**
     * @var string $Status
     */
    protected $Status = null;

    /**
     * @var string $StatusType
     */
    protected $StatusType = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getBounceBackRemarks()
    {
      return $this->BounceBackRemarks;
    }

    /**
     * @param string $BounceBackRemarks
     * @return clsQCStatus
     */
    public function setBounceBackRemarks($BounceBackRemarks)
    {
      $this->BounceBackRemarks = $BounceBackRemarks;
      return $this;
    }

    /**
     * @return string
     */
    public function getErrorText()
    {
      return $this->ErrorText;
    }

    /**
     * @param string $ErrorText
     * @return clsQCStatus
     */
    public function setErrorText($ErrorText)
    {
      $this->ErrorText = $ErrorText;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatus()
    {
      return $this->Status;
    }

    /**
     * @param string $Status
     * @return clsQCStatus
     */
    public function setStatus($Status)
    {
      $this->Status = $Status;
      return $this;
    }

    /**
     * @return string
     */
    public function getStatusType()
    {
      return $this->StatusType;
    }

    /**
     * @param string $StatusType
     * @return clsQCStatus
     */
    public function setStatusType($StatusType)
    {
      $this->StatusType = $StatusType;
      return $this;
    }

}
