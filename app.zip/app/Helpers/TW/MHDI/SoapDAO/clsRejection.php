<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsRejection
{

    /**
     * @var string $RejectedByRole
     */
    protected $RejectedByRole = null;

    /**
     * @var string $RejectedByWhom
     */
    protected $RejectedByWhom = null;

    /**
     * @var string $RejectedReason
     */
    protected $RejectedReason = null;

    
    public function __construct()
    {
    
    }

    /**
     * @return string
     */
    public function getRejectedByRole()
    {
      return $this->RejectedByRole;
    }

    /**
     * @param string $RejectedByRole
     * @return clsRejection
     */
    public function setRejectedByRole($RejectedByRole)
    {
      $this->RejectedByRole = $RejectedByRole;
      return $this;
    }

    /**
     * @return string
     */
    public function getRejectedByWhom()
    {
      return $this->RejectedByWhom;
    }

    /**
     * @param string $RejectedByWhom
     * @return clsRejection
     */
    public function setRejectedByWhom($RejectedByWhom)
    {
      $this->RejectedByWhom = $RejectedByWhom;
      return $this;
    }

    /**
     * @return string
     */
    public function getRejectedReason()
    {
      return $this->RejectedReason;
    }

    /**
     * @param string $RejectedReason
     * @return clsRejection
     */
    public function setRejectedReason($RejectedReason)
    {
      $this->RejectedReason = $RejectedReason;
      return $this;
    }

}
