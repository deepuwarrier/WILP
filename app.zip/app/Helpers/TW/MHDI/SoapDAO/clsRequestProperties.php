<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsRequestProperties extends clsCommonProperties
{

    /**
     * @var string $AuthenticationToken
     */
    protected $AuthenticationToken = null;

    /**
     * @var string $ServiceConsumer
     */
    protected $ServiceConsumer = null;

    
    public function __construct()
    {
      parent::__construct();
    }

    /**
     * @return string
     */
    public function getAuthenticationToken()
    {
      return $this->AuthenticationToken;
    }

    /**
     * @param string $AuthenticationToken
     * @return clsRequestProperties
     */
    public function setAuthenticationToken($AuthenticationToken)
    {
      $this->AuthenticationToken = $AuthenticationToken;
      return $this;
    }

    /**
     * @return string
     */
    public function getServiceConsumer()
    {
      return $this->ServiceConsumer;
    }

    /**
     * @param string $ServiceConsumer
     * @return clsRequestProperties
     */
    public function setServiceConsumer($ServiceConsumer)
    {
      $this->ServiceConsumer = $ServiceConsumer;
      return $this;
    }

}
