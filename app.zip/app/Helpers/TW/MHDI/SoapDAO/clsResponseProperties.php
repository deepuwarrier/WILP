<?php
namespace App\Helpers\TW\MHDI\SoapDAO;
class clsResponseProperties extends clsCommonProperties
{

    
    public function __construct()
    {
      parent::__construct();
    }

}
