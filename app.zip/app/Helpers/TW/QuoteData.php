<?php

namespace App\Helpers\TW;

class QuoteData {
	private $product_code = "";
	private $idv = 0;
	private $insurer_code = "";
	private $insurer_name = "";
	private $insurer_logo = "";
	private $od_value = 0;
	private $tp_value = 0;
	private $pa_value = 0;
	private $cmdisc_value = 0;
	private $ltdisc_value = 0;
	private $ncb_perc = 0;
	private $ncb_value = 0;
	private $gross_premium = 0;
	private $service_tax = 0;
	private $final_premium = 0;
	
	
	public function product_code(){return $this->product_code;}
	public function idv(){return $this->idv;}
	public function insurer_code() { return $this->insurer_code; }
	public function insurer_name() { return $this->insurer_name; }
	public function insurer_logo() { return $this->insurer_logo; }
	public function od_value() { return $this->od_value; }
	public function tp_value() { return $this->tp_value; }
	public function pa_value() { return $this->pa_value; }
	public function cmdisc_value() { return $this->cmdisc_value; }
	public function ltdisc_value() { return $this->ltdisc_value; }
	public function ncb_perc() { return $this->ncb_perc; }
	public function ncb_value() { return $this->ncb_value; }
	public function gross_premium() { return $this->gross_premium; }
	public function service_tax() { return $this->service_tax; }
	public function final_premium() { return $this->final_premium; }
	
	public function _product_code($product_code){return $this->product_code= $product_code; }
	public function _idv($idv){return $this->idv = $idv; }
	public function _insurer_code($insurer_code) { $this->insurer_code = $insurer_code; }
	public function _insurer_name($insurer_name) {  $this->insurer_name = $insurer_name; }
	public function _insurer_logo($insurer_logo) {  $this->insurer_logo = $insurer_logo; }
	public function _od_value($od_value) {  $this->od_value = $od_value; }
	public function _tp_value($tp_value) {  $this->tp_value = $tp_value; }
	public function _pa_value($pa_value) {  $this->pa_value = $pa_value; }
	public function _cmdisc_value($cmdisc_value) {  $this->cmdisc_value= $cmdisc_value; }
	public function _ltdisc_value($ltdisc_value) {  $this->ltdisc_value= $ltdisc_value; }
	public function _ncb_perc($ncb_perc) {  $this->ncb_perc = $ncb_perc; }
	public function _ncb_value($ncb_value) {  $this->ncb_value = $ncb_value; }
	public function _gross_premium($gross_premium) {  $this->gross_premium = $gross_premium; }
	public function _service_tax($service_tax) {  $this->service_tax = $service_tax; }
	public function _final_premium($final_premium) {  $this->final_premium = $final_premium; }
	
}
