<?php
namespace App\Helpers\TW\RSGI;
							
 use App\Helpers\TW\InsurerData;
 use App\Libraries\TwLib;
 use App\Models\TW\data\PRData;
 use Illuminate\Support\Facades\Log;
 use App\Constants\Tw_Constants;
						
 class RSGI_Policy_Factory extends RSGI_Policy_Request {
 
 	
 	
public function update_quote($qupdate_usrdata, $agreed_premium){  
   
    if( $agreed_premium !== null ) {	$qupdate_usrdata->total_premium= $agreed_premium;	}
 
    $fillded_request = $this->populate_quote_update($qupdate_usrdata);   
    
    $raw_qupdate_resp= $this->call_update_quote( $fillded_request );  
    $resp_data = $this->parse_qupdate_resp($qupdate_usrdata, $raw_qupdate_resp);
    return $resp_data;
	
}// end of method

private function populate_quote_update( $qupdate_usrdata) {
	$financier_value = ['HYPOTHECATION'=>'Hypothecation','HIRE PURCHASE'=>'Hire purchase','LEASE'=>'Lease'];
	$mstr_map = new InsurerData();
	$insr_column = "rsgi_code";
	$tw_lib = new TwLib();
	
	$tw_regno_arr = explode("-", $qupdate_usrdata->tw_reg_no); 
	$tw_regno_fmtd = $tw_regno_arr["0"]."".$tw_regno_arr["1"]."".$tw_regno_arr["2"]."".$tw_regno_arr["3"];
	
	$req_params = array(
			//vechicle details
			"vehicleManufacturerName" => $mstr_map->insr_make( $insr_column, $qupdate_usrdata->make_code ),
			"vehicleModelCode" => $mstr_map->insr_variant( $insr_column,  $qupdate_usrdata->variant_code),
			"modelName" => $mstr_map->model_data("model_name", $qupdate_usrdata->model_code) . " " . $mstr_map->insr_variant("variant_name", $qupdate_usrdata->variant_code),
			"engineCapacityAmount" =>$qupdate_usrdata->variant_cc ." CC",
			"yearOfManufacture" => $qupdate_usrdata->yom,
			
			// quote details
			"quoteId" => $qupdate_usrdata->temp_col_1,
			"idv" => $qupdate_usrdata->opt_idv,
			"vehicleRegDate" => $this->format_date( $qupdate_usrdata->tw_reg_date),
			"previousPolicyExpiryDate" => $this->format_date( $qupdate_usrdata->policy_exp_date) ,
			"policyStartDate" => $this->format_date( $qupdate_usrdata->term_start_date ),
			"claimsMadeInPreviousPolicy" => $qupdate_usrdata->pre_claim_status=="Y" ? "Yes" : "No",
			"claimAmountReceived" => $qupdate_usrdata->pre_claim_status=="Y" ? "9999" : "0",
			"claimsReported" => $qupdate_usrdata->pre_claim_status=="Y" ? "1" : "0",
			"ncbcurrent" => $qupdate_usrdata->eli_ncb,
			"ncbprevious" => $qupdate_usrdata->curr_ncb,
			"noClaimBonusPercent" => $this->ncb_rank( $qupdate_usrdata->eli_ncb),
			"quoteId"=>$qupdate_usrdata->temp_col_1,
			
			//proposal details
			"title" => $qupdate_usrdata->proposer_gender == "M" ? "Mr": "Ms",
			"firstName" => $tw_lib->get_fname( $qupdate_usrdata->proposer_name),
			"lastName" => $tw_lib->get_lname( $qupdate_usrdata->proposer_name),
			"emailId" => $qupdate_usrdata->proposer_email,
			"mobileNo" => $qupdate_usrdata->proposer_mobile,
			"dateOfBirth" => $this->format_date( $qupdate_usrdata->proposer_dob),
			"occupation" => $mstr_map->proposer_occu($insr_column, $qupdate_usrdata->proposer_occupation) ,
			"emailId" => $qupdate_usrdata->proposer_email,
			"drivingExperience" => $qupdate_usrdata->tw_age == "0" ? 1 :$qupdate_usrdata->tw_age,
			"permanentAddress1" => $qupdate_usrdata->regn_addr1,
			"permanentAddress2" => $qupdate_usrdata->regn_addr2,
			"permanentAddress3" => $qupdate_usrdata->regn_addr3,
			"permanentCity" => $mstr_map->insr_city($insr_column, $qupdate_usrdata->regn_city_code) ,	
			"permanentPincode" => $qupdate_usrdata->regn_pincode,
			"sameAdressReg" => $qupdate_usrdata->same_comm_addr == "Y" ? "Yes" : "No",
			"ResidenceAddressOne" => $qupdate_usrdata->same_comm_addr == "Y" ? $qupdate_usrdata->regn_addr1 : $qupdate_usrdata->proposer_addr1,
			"ResidenceAddressTwo" => $qupdate_usrdata->same_comm_addr == "Y" ? $qupdate_usrdata->regn_addr2: $qupdate_usrdata->proposer_addr2,
			"ResidenceAddressThree" => $qupdate_usrdata->same_comm_addr == "Y" ? $qupdate_usrdata->regn_addr3: $qupdate_usrdata->proposer_addr3,
			"ResidenceCity" => $qupdate_usrdata->same_comm_addr == "Y" ? $mstr_map->insr_city($insr_column, $qupdate_usrdata->regn_city_code) : $mstr_map->insr_city($insr_column, $qupdate_usrdata->proposer_city_code),
			"ResidencePinCode" => $qupdate_usrdata->same_comm_addr == "Y" ? $qupdate_usrdata->regn_pincode : $qupdate_usrdata->proposer_pincode,
			
			//vechicle details
			"registrationNumber" =>$tw_regno_fmtd,
			"engineNumber" => $qupdate_usrdata->tw_engine_no,
			"chassisNumber" => $qupdate_usrdata->tw_chassis_no,
			"vechileOwnerShipChanged" => $qupdate_usrdata->owner_changed == "Y" ? "Yes" : "No",
			"claimsMadeInPreviousPolicy" =>  $qupdate_usrdata->pre_claim_status == "Y" ? "Yes" : "No",
			"claimAmountReceived" =>  $qupdate_usrdata->pre_claim_amount,
			"claimsReported" =>  $qupdate_usrdata->pre_claim_count,
			"voluntaryDeductible" => $qupdate_usrdata->voluentry_deductables,

			"isTwoWheelerFinanced" => $qupdate_usrdata->is_financed == "Y" ? "Yes" : "No",

			"isTwoWheelerFinancedValue" => $qupdate_usrdata->is_financed == "Y" ? $financier_value[$qupdate_usrdata->type_of_finance] : "",
			"financierName" => $qupdate_usrdata->financier_name,

			"carRegisteredCity" => $mstr_map->insr_city($insr_column, $qupdate_usrdata->regn_city_code),
			
			//previous insurance. 
			"previousPolicyNo" => $qupdate_usrdata->pre_policy_number,
			"previousInsurerName" => $mstr_map->insr_preinsr($insr_column, $qupdate_usrdata->pre_insurer_code),   		
			"nomineeName" => $qupdate_usrdata->nomi_name,
			"nomineeAge" => $qupdate_usrdata->nomi_age,
			"relationshipWithNominee" => $mstr_map->nomrel_data($insr_column, $qupdate_usrdata->nomi_rel_code),
			"premium" => $qupdate_usrdata->total_premium .".0"
	);
	
	$quote_update_req = $this->prepare_quote_update($req_params);
	
	return $quote_update_req;
} // end of method

private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}

private function ncb_rank( $curr_ncb ) {
	switch ($curr_ncb) {
		case 20: return 1; break;	case 25: return 2; break; case 35: return 3; break; case 45: return 4; break;case 50: return 5; break;
		default: return 0;
	}
}

private function parse_qupdate_resp($qupdate_usrdata, $raw_qupdate_resp){ 
	$prdata = new PRData();
	if( $raw_qupdate_resp == null) {return $prdata; }	
	
	$resp_status_ob = $raw_qupdate_resp->Status;
	$resp_data_ob = $raw_qupdate_resp->DATA;
	
	if( $resp_status_ob->StatusCode== "S-0005"){
			// Check for Premium mismatch.
		if( $qupdate_usrdata->total_premium == $resp_data_ob->PREMIUM){
				// premium success -
			$prdata->set_pr_type("success");
				
			}else{
				// premium mismatch case. 
				$prdata->set_pr_type("premium_mismatch");
				$prdata->set_revisedpremium($resp_data_ob->PREMIUM);
			}
		
	}else {
		$prdata->set_pr_type("error");
		$prdata->set_errormsg($raw_qupdate_resp->Status->Message);
	}
	return $prdata;
}

private function call_update_quote($quote_req_data){
	
	Log:info("TW RSGI QuoteUpdate Request : ". print_r($quote_req_data, true));
	
	$curl = curl_init();
	curl_setopt_array($curl, array(
			CURLOPT_URL => Tw_Constants::RSGI_QUOTE_UPDATE_URL,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $quote_req_data,
			CURLOPT_HTTPHEADER => array( "Content-Type: application/xml" ),
	));
	
	try {
		$quote_raw_resp = curl_exec($curl);   
		$api_resp = simplexml_load_string($quote_raw_resp);  
		Log::info("TW RSGI QuoteUpdate Response : ".  print_r ($api_resp, true));
		if($api_resp->DATA->PREMIUM == '0.0'){
			return $this->call_update_quote($quote_req_data);
		} 
	}catch (\Exception $ee) {
		Log::error( "TW RSGI QuoteUpdate Response Exeption : ".$ee->getMessage(). " | Trace - ". $ee->getTraceAsString());
		return null;
	}

	return  $api_resp;
} // end of method



// ----------------------------- Proposal & Payment Methods ----------------------------------- //

public function submit_proposal ($final_premium, $usr_data ) {
		
	$proposal_req_arr = array(
			"quoteId" => $usr_data->temp_col_1,
			"premium" => $usr_data->final_premium .'.0',
			"emailId" => $usr_data->proposer_email
	);
	
	$proposal_req_str = $this->prepare_policy($proposal_req_arr);  
	
	return $this->call_submit_proposal( $proposal_req_str);
	
}

private function call_submit_proposal( $proposal_req_str ) {
	Log:info("TW RSGI Proposal Request : ". print_r($proposal_req_str, true));
	
	$curl = curl_init();
	curl_setopt_array($curl, array(
			CURLOPT_URL => Tw_Constants::RSGI_PROPOSAL_URL,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 100,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $proposal_req_str,
			CURLOPT_HTTPHEADER => array( "Content-Type: application/xml" ),
	));
	
	try {
		$proposal_raw_resp = curl_exec($curl);
		$api_resp = simplexml_load_string($proposal_raw_resp);
		Log::info("TW RSGI Proposal Response : ".  print_r ($api_resp, true));
		
	}catch (\Exception $ee) {
		Log::error( "TW RSGI Proposal Response Exeption : ".$ee->getMessage(). " | Trace - ". $ee->getTraceAsString());
		return null;
	}
	return  $api_resp;
	
	
}// end of method

 } // end of class
