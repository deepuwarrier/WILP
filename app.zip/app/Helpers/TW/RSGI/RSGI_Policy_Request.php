<?php

namespace App\Helpers\TW\RSGI;

class RSGI_Policy_Request {

protected function prepare_quote_update( $req_arr ) {
		
	$quote_update_req_str = "<CALCULATEPREMIUMREQUEST>
   <quoteId></quoteId>
   <premium></premium>
   <authenticationDetails>
      <apiKey>310ZQmv/bYJMYrWQ1iYa7s43084=</apiKey>
      <agentId>BA503014</agentId>
   </authenticationDetails>
   <proposerDetails>
      <title></title>
      <firstName></firstName>
      <lastName></lastName>
      <emailId></emailId>
      <mobileNo></mobileNo>
      <dateOfBirth></dateOfBirth>
      <occupation></occupation>
      <nomineeName></nomineeName>
      <nomineeAge></nomineeAge>
      <relationshipWithNominee></relationshipWithNominee>
      <guardianName></guardianName>
      <guardianAge></guardianAge>
      <relationshipwithGuardian></relationshipwithGuardian>
      <permanentAddress1></permanentAddress1>
      <permanentAddress2></permanentAddress2>
	  <permanentAddress3></permanentAddress3>
      <permanentAddress4></permanentAddress4>
      <permanentCity></permanentCity>
      <permanentPincode></permanentPincode>
      <sameAdressReg></sameAdressReg>
      <ResidenceAddressOne></ResidenceAddressOne>
      <ResidenceAddressTwo></ResidenceAddressTwo>
	  <ResidenceAddressThree></ResidenceAddressThree>
      <ResidenceAddressFour></ResidenceAddressFour>
      <ResidenceCity></ResidenceCity>
      <ResidencePinCode></ResidencePinCode>
      <passwordResetted />
      <clientName />
	  <strStdCode></strStdCode>
	  <strPhoneNo></strPhoneNo>
   </proposerDetails>
   <vehicleDetails>
      <vehicleModelCode></vehicleModelCode>
      <planOpted>Flexi Plan</planOpted>
      <yearOfManufacture></yearOfManufacture>
      <drivingExperience></drivingExperience>
      <voluntaryDeductible></voluntaryDeductible>
      <vehicleManufacturerName></vehicleManufacturerName>
      <engineProtectorPremium />
      <idv></idv>
      <vehicleMostlyDrivenOn>City roads</vehicleMostlyDrivenOn>
      <vehicleRegisteredInTheNameOf>Individual</vehicleRegisteredInTheNameOf>
      <modelName></modelName>
      <vehicleRegDate></vehicleRegDate>
	<policyStartDate></policyStartDate>
      <isPreviousPolicyHolder>true</isPreviousPolicyHolder>
      <previousPolicyExpiryDate></previousPolicyExpiryDate>
      <previousPolicyNo></previousPolicyNo>
      <previousInsurerName></previousInsurerName>
      <registrationNumber></registrationNumber>
      <productName>RolloverTwoWheeler</productName>
      <engineProtector>off</engineProtector>
	  <depreciationWaiver>off</depreciationWaiver>
      <companyNameForCar></companyNameForCar>
      <engineNumber></engineNumber>
      <chassisNumber></chassisNumber>
      <isTwoWheelerFinanced></isTwoWheelerFinanced>
      <isTwoWheelerFinancedValue></isTwoWheelerFinancedValue>
      <financierName></financierName>
      <vehicleSubLine>motorCycle</vehicleSubLine>
      <registrationchargesRoadtax>off</registrationchargesRoadtax>
      <fuelType>Petrol</fuelType>
      <automobileAssociationMembership>No</automobileAssociationMembership>
      <region></region>
      <carRegisteredCity></carRegisteredCity>
      <averageMonthlyMileageRun>1000</averageMonthlyMileageRun>
      <isProductCheck>true</isProductCheck>
      <engineCapacityAmount></engineCapacityAmount>
      <personalAccidentCoverForUnnamedPassengers>0</personalAccidentCoverForUnnamedPassengers>
      <accidentCoverForPaidDriver>0</accidentCoverForPaidDriver>
      <legalliabilityToPaidDriver>No</legalliabilityToPaidDriver>
      <legalliabilityToEmployees>No</legalliabilityToEmployees>
	  <cover_elec_acc>No</cover_elec_acc> 
      <nonElectricalAccesories/>
      <electricalAccessories/>
	<previousPolicyType>Comprehensive</previousPolicyType>
	<vechileOwnerShipChanged></vechileOwnerShipChanged>
    <noClaimBonusPercent></noClaimBonusPercent>
    <ncbcurrent></ncbcurrent>
    <claimsMadeInPreviousPolicy></claimsMadeInPreviousPolicy>
    <claimAmountReceived></claimAmountReceived>
    <claimsReported></claimsReported>
    <ncbprevious></ncbprevious>
   </vehicleDetails>
</CALCULATEPREMIUMREQUEST>";
		
		foreach ($req_arr as $xml_key => $xml_value) {
			$quote_update_req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$quote_update_req_str
					);
		}
		return $quote_update_req_str;
	} // end of method.
	
protected function prepare_policy ( $req_arr ) {
	$policy_req_str = "
<GPROPOSALREQUEST>
   <quoteId></quoteId>
   <premium></premium>
   <emailId></emailId>
   <authenticationDetails>
      <apiKey>310ZQmv/bYJMYrWQ1iYa7s43084=</apiKey>
      <agentId>BA503014</agentId>
   </authenticationDetails>
</GPROPOSALREQUEST>";
	
	foreach ($req_arr as $xml_key => $xml_value) {
		$policy_req_str= str_replace(
				"<". $xml_key ."></". $xml_key .">",
				"<". $xml_key .">". $xml_value ."</". $xml_key .">",
				$policy_req_str
				);
	}
	return $policy_req_str;
}	
  
} // end of class
