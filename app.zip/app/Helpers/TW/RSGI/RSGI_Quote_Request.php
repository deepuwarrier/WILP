<?php

namespace App\Helpers\TW\RSGI;

class RSGI_Quote_Request {
	
public function prepare_quote_init( $req_arr ) {  
	
$quote_init_req_str = "<CALCULATEPREMIUMREQUEST>
   <authenticationDetails>
      <apiKey>310ZQmv/bYJMYrWQ1iYa7s43084=</apiKey>
      <agentId>BA503014</agentId>
   </authenticationDetails>
   <proposerDetails>
		      <title>Mr</title>
		      <firstName>TEST</firstName>
		      <lastName>Name</lastName>
			<emailId>testname@gamil.com</emailId>	
		      <mobileNo>9876543210</mobileNo>
		      <dateOfBirth>10/06/1998</dateOfBirth>
		      <occupation>Professional</occupation>
		      <nomineeName>TEST NOMINEE</nomineeName>
		      <nomineeAge>22</nomineeAge>
		      <relationshipWithNominee>Cousin</relationshipWithNominee>
		      <permanentAddress1>address1</permanentAddress1>
		      <permanentAddress2>address2</permanentAddress2>
		    <permanentAddress3>address3</permanentAddress3>
		      <permanentAddress4></permanentAddress4>
		      <permanentCity>Bengaluru</permanentCity>
		      <permanentPincode>560078</permanentPincode>
		      <sameAdressReg>Yes</sameAdressReg>
		      <ResidenceAddressOne>address1</ResidenceAddressOne>
		      <ResidenceAddressTwo>address2</ResidenceAddressTwo>
		    <ResidenceAddressThree>address3</ResidenceAddressThree>
		      <ResidenceAddressFour></ResidenceAddressFour>
		      <ResidenceCity>Bengaluru</ResidenceCity>
		      <ResidencePinCode>560078</ResidencePinCode>
		      <passwordResetted />
		      <clientName />
		    <strStdCode></strStdCode>
		      <strPhoneNo></strPhoneNo>
   </proposerDetails>
   <vehicleDetails>
      <vehicleModelCode></vehicleModelCode>
      <planOpted>Flexi Plan</planOpted>
      <yearOfManufacture></yearOfManufacture>
      <drivingExperience>3</drivingExperience>
      <voluntaryDeductible>0</voluntaryDeductible>
      <vehicleManufacturerName></vehicleManufacturerName>
      <engineProtectorPremium />
      <idv></idv>
      <vehicleMostlyDrivenOn>City roads</vehicleMostlyDrivenOn>
      <vehicleRegisteredInTheNameOf>Individual</vehicleRegisteredInTheNameOf>
      <modelName></modelName>
      <vehicleRegDate></vehicleRegDate>
      <isPreviousPolicyHolder>true</isPreviousPolicyHolder>
      <previousPolicyType>Comprehensive</previousPolicyType>
      <previousPolicyExpiryDate></previousPolicyExpiryDate>
      <previousPolicyNo>12365478788</previousPolicyNo>
      <previousInsurerName>bajaj insurance</previousInsurerName>
      <registrationNumber></registrationNumber>
      <productName>RolloverTwoWheeler</productName>
      <engineProtector>off</engineProtector>
    <depreciationWaiver></depreciationWaiver>
      <companyNameForCar>xerago</companyNameForCar>
      <engineNumber>565465466</engineNumber>
      <chassisNumber>5654656</chassisNumber>
      <isTwoWheelerFinanced>No</isTwoWheelerFinanced>
      <isTwoWheelerFinancedValue />
      <financierName />
      <vehicleSubLine>MotorCycle</vehicleSubLine>
      <registrationchargesRoadtax>off</registrationchargesRoadtax>
      <fuelType>Petrol</fuelType>
      <automobileAssociationMembership>No</automobileAssociationMembership>
      <region></region>
      <carRegisteredCity></carRegisteredCity>
      <averageMonthlyMileageRun>1000</averageMonthlyMileageRun>
      <isProductCheck>true</isProductCheck>
    <searchEngine></searchEngine>
      <product></product>
      <engineCapacityAmount></engineCapacityAmount>
      <personalAccidentCoverForUnnamedPassengers>0</personalAccidentCoverForUnnamedPassengers>
      <accidentCoverForPaidDriver>0</accidentCoverForPaidDriver>
      <legalliabilityToPaidDriver>No</legalliabilityToPaidDriver>
      <legalliabilityToEmployees>No</legalliabilityToEmployees>
      <policyStartDate></policyStartDate>
    <cover_elec_acc>No</cover_elec_acc>
      <nonElectricalAccesories/>
      <electricalAccessories/>
     <vechileOwnerShipChanged>No</vechileOwnerShipChanged>
     <claimsMadeInPreviousPolicy></claimsMadeInPreviousPolicy>
     <noClaimBonusPercent></noClaimBonusPercent>
     <ncbcurrent></ncbcurrent>
     <claimAmountReceived></claimAmountReceived>
     <claimsReported></claimsReported>
     <ncbprevious></ncbprevious>
   </vehicleDetails>
</CALCULATEPREMIUMREQUEST>";
	
	
		foreach ($req_arr as $xml_key => $xml_value) {    
			
			$quote_init_req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$quote_init_req_str
					);
		} 
		return $quote_init_req_str; 
	} // end of method.
	
} // end of class
