<?php
namespace App\Helpers\TW\Reliance;

use App\Models\TW\data\QuoteData;
use Illuminate\Support\Facades\Log;
use App\Be\TW\RelianceBe;
 use App\Models\TW\data\PRData;
use App\Constants\Tw_Constants;
use SoapClient;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwVariant;
			
class ReliancePolicyFactory{
 
	public function submit_policy($qupdate_usrdata, $agreed_premium){  
		$tw_trans_code = $qupdate_usrdata->trans_code;
		$usr_db = new TwUsrData();
    	$policy_usr_data = $usr_db->get_by_tc($tw_trans_code);  

	    if( $agreed_premium !== null ) {
	    	$qupdate_usrdata->total_premium= $agreed_premium;
	    }
	
		$reliance_be = new RelianceBe();

		// populate quote request
		$fillded_request = $reliance_be->populate_proposal_request($qupdate_usrdata); 
		
		// initi quote api
		Log::info("TW Reliance Proposal Request " . $tw_trans_code . " - ". $fillded_request);
		$raw_proposal_resp = $this->init_proposal($fillded_request);
		Log::info("TW Reliance Proposal Response " . $tw_trans_code . " - ". print_r($raw_proposal_resp, true));

		$error_status = $reliance_be->post_proposal_check($qupdate_usrdata,$raw_proposal_resp);
		$resp_data = $this->parse_proposal_resp($qupdate_usrdata, $raw_proposal_resp);
    	return $resp_data;
		
	}// end of method

	private function parse_proposal_resp($qupdate_usrdata, $raw_proposal_resp){ 
		$prdata = new PRData();
		if( $raw_proposal_resp == null) {return $prdata; }	
		if(empty($raw_proposal_resp->MotorPolicy->ErrorMessages)){
				// Check for Premium mismatch.
			if( $qupdate_usrdata->total_premium == $raw_proposal_resp->MotorPolicy->FinalPremium){
					// premium success
				$prdata->set_pr_type("success");
					
				}else{
					// premium mismatch case. 
					$prdata->set_pr_type("premium_mismatch");
					$prdata->set_revisedpremium($raw_proposal_resp->MotorPolicy->FinalPremium);
				}
			$usr_db = new TwUsrData();
			$usr_db->where('trans_code', $qupdate_usrdata->trans_code)
					->update([
								'temp_col_1' =>	$raw_proposal_resp->MotorPolicy->QuoteNo,
								'temp_col_2' => $raw_proposal_resp->MotorPolicy->ProposalNo
								]);
		}else {
			$prdata->set_pr_type("error");
			$prdata->set_errormsg($raw_proposal_resp->MotorPolicy->ErrorMessages);
		}
		return $prdata;
	}

	public function init_proposal($fillded_request){  
	
		$ret_response = null;
		$curl = curl_init();
		curl_setopt_array($curl, array(
			//	CURLOPT_PORT => "91",
				CURLOPT_URL => Tw_Constants::RELIANCE_PROPOSAL_URL,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => $fillded_request ,
				CURLOPT_HTTPHEADER => array(
						"content-type: application/xml"
				),
		));
		
		$response = curl_exec($curl); 
		$err = curl_error($curl);
		
		curl_close($curl);
		
		if ($err) {
			Log::error("TW Reliance Proposal Error : " .$err);
		} else {
			$ret_response = json_decode($response); 
		} 
		return $ret_response; 
	}  // method end. 

} // End of ReliancePolicyFactory Class
