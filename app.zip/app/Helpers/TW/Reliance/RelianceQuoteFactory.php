<?php
namespace App\Helpers\TW\Reliance;

use App\Be\TW\RelianceBe;
use App\Constants\Tw_Constants;
use App\Models\TW\TwUsrData;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\data\QuoteRespData;
use Illuminate\Support\Facades\Log;
								
 class RelianceQuoteFactory {
 
 	public function get_quote(QuoteReqData $quote_req_data){	 
	$quote_loop = 0;
	QUOTE_CALL:

	if( $quote_req_data->get_add_on_zrdp() || $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
		$pre_resp_data = new QuoteRespData();
		$pre_resp_data->_addon_flag(false);
		return $pre_resp_data;
	} 
	
	$reliance_be = new RelianceBe();
	
	// populate quote request
	$fillded_request = $reliance_be->populate_quote_request($quote_req_data); 
	

	// initi quote api
	Log::info("TW Reliance Quote Request " . $quote_req_data->get_tw_trans_code() . " - ". $fillded_request);
	$raw_quote_resp = $this->init_quote($fillded_request);
	Log::info("TW Reliance Quote Response " . $quote_req_data->get_tw_trans_code() . " - ". print_r($raw_quote_resp, true));
	

	if($raw_quote_resp == null || strlen( $raw_quote_resp->MotorPolicy->ErrorMessages ) > 0 ) {
		$idv_issue = strpos($raw_quote_resp->MotorPolicy->ErrorMessages,"User IDV should be in range");

		
	
		if(isset($idv_issue) && $idv_issue === 0 && $quote_loop == 0){
			$quote_loop++;
			$expected_idv =  $this->getIDV($raw_quote_resp->MotorPolicy->ErrorMessages,
								$quote_req_data->get_desired_idv());
			$quote_req_data->set_desired_idv($expected_idv);

			
			goto QUOTE_CALL;
		}
		

		if($raw_quote_resp != null){
			Log::error("Quote Error :". $quote_req_data->get_tw_trans_code() . " - "  . $raw_quote_resp->MotorPolicy->ErrorMessages);
		}
		return null;
	}
	
	// parse quote response
	$quote_resp_data = $reliance_be->parse_quote_response($quote_req_data, $raw_quote_resp);

	return $quote_resp_data;
}

public function init_quote($fillded_request){  
	
	$ret_response = null;
	$curl = curl_init();
	curl_setopt_array($curl, array(
		//	CURLOPT_PORT => "91",
			CURLOPT_URL => Tw_Constants::RELIANCE_QUOTE_URL,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $fillded_request ,
			CURLOPT_HTTPHEADER => array(
					"content-type: application/xml"
			),
	));
	
	$response = curl_exec($curl); 
	$err = curl_error($curl);
	
	curl_close($curl);
	
	if ($err) {
		Log::error("TW Reliance Quote Error : " .$err);
	} else {
		$ret_response = json_decode($response); 
	} 
	return $ret_response; 
}  // method end. 

	public function getIDV($error,$current_idv){
		preg_match('#\((.*?)\)#',$error, $match);
		if(isset($match[1])){
			$idvs = explode(",",$match[1]);
		}
		$min = trim($idvs[0]);
		$max = trim($idvs[1]);

		if($current_idv < $min)
			return ceil($min);

		return floor($max);
	}

	public function get_coverage(QuoteReqData $quote_req_data){	 
		$quote_loop = 0;
		QUOTE_CALL:

		if(  $quote_req_data->get_add_on_zrdp() || $quote_req_data->get_add_on_rtin() || $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() ) {
			$pre_resp_data = new QuoteRespData();
			$pre_resp_data->_addon_flag(false);
			return $pre_resp_data;
		} 
		
		$reliance_be = new RelianceBe();
		
		// populate quote request
		$fillded_request = $reliance_be->populate_quote_request($quote_req_data); 
		

		// initi quote api
		Log::info("TW Reliance Coverage Request " . $quote_req_data->get_tw_trans_code() . " - ". $fillded_request);
		$raw_quote_resp = $this->init_coverage($fillded_request);
		Log::info("TW Reliance Coverage Response " . $quote_req_data->get_tw_trans_code() . " - ". print_r($raw_quote_resp, true));
		
		

		if($raw_quote_resp == null || strlen( $raw_quote_resp->ErrorMessages ) > 0 ) {
			$idv_issue = strpos($raw_quote_resp->ErrorMessages,"User IDV should be in range");

			if($raw_quote_resp != null){
				Log::error("Coverage Error :". $quote_req_data->get_tw_trans_code() . " - "  . $raw_quote_resp->MotorPolicy->ErrorMessages);
			}
			return null;
		}
		
		$addon_list = [];
		if(!is_null($raw_quote_resp->LstAddonCovers)){
			foreach ($raw_quote_resp->LstAddonCovers as $key => $value) {
				$addon_list[$value->CoverageName] = $value->rate;
			}
		}
		if(!is_null($addon_list['Nil Depreciation'])){
			$data['reliance_nildep_rate'] = $addon_list['Nil Depreciation'];
		}
		// parse quote response
		// $quote_resp_data = $reliance_be->parse_quote_response($quote_req_data, $raw_quote_resp);
		$usr_db = new TwUsrData();
		$usr_db->set_by_tc($quote_req_data->get_tw_trans_code(),['misc_desc'=>json_encode($data)]);
	}

	public function init_coverage($fillded_request){  
	
		$ret_response = null;
		$curl = curl_init();
		curl_setopt_array($curl, array(
				CURLOPT_PORT => "91",
				CURLOPT_URL => Tw_Constants::RELIANCE_COVERAGE_URL,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => $fillded_request ,
				CURLOPT_HTTPHEADER => array(
						"content-type: application/xml"
				),
		));
		
		$response = curl_exec($curl); 
		$err = curl_error($curl);
		
		curl_close($curl);
		
		if ($err) {
			Log::error("TW Reliance Coverage Error : " .$err);
		} else {
			$ret_response = json_decode($response); 
		} 
		return $ret_response; 
	}  // method end. 


} // end of class
