<?php

namespace App\Helpers\TW\Reliance;

use App\Libraries\TwLib;

class Reliance_Policy_Request {
	
	public function raw_policy_req_arr( ) {
		$raw_xml_str = $this->raw_xml_str();
		$xml = simplexml_load_string($raw_xml_str, "SimpleXMLElement", LIBXML_NOCDATA);
		$json = json_encode($xml);
		return json_decode($json,TRUE);
	}

	public function filled_policy_req_str($filled_req_arr) {
		$ret_str = "";
		$tw_lib = new TwLib();
		$ret_str = $tw_lib->array_to_xml($filled_req_arr, "PolicyDetails");
		return $ret_str; 
	}

	public function raw_xml_str() {
		return "<PolicyDetails>
				  <CoverDetails />
				  <TrailerDetails />
				  <ClientDetails>
				    <ClientType>0</ClientType>
				    <LastName>Sekhar</LastName>
				    <MidName />
				    <ForeName>Mani</ForeName>
				    <OccupationID>26</OccupationID>
				    <DOB>1991-11-09</DOB>
				    <Gender>Male</Gender>
				    <PhoneNo />
				    <MobileNo>9876543210</MobileNo>
				    <RegisteredUnderGST>0</RegisteredUnderGST>
				    <RelatedParty>0</RelatedParty>
				    <GSTIN />
				    <GroupCorpID />
				    <ClientAddress>
				      <RegistrationAddress>
				        <AddressType>0</AddressType>
				        <Address1>Anna Salai</Address1>
				        <Address2>Gemini</Address2>
				        <Address3 />
				        <CityID>542328</CityID>
				        <DistrictID>473</DistrictID>
				        <StateID>30</StateID>
				        <Pincode>600006</Pincode>
				        <Country>1</Country>
				        <NearestLandmark />
				      </RegistrationAddress>
				      <CommunicationAddress>
				        <AddressType>0</AddressType>
				        <Address1>Anna Salai</Address1>
				        <Address2>Gemini</Address2>
				        <Address3>Chennai</Address3>
				        <CityID>542328</CityID>
				        <DistrictID>473</DistrictID>
				        <StateID>30</StateID>
				        <Pincode>600006</Pincode>
				        <Country>1</Country>
				        <NearestLandmark />
				      </CommunicationAddress>
				      <PermanentAddress>
				        <AddressType>0</AddressType>
				        <Address1>Anna Salai</Address1>
				        <Address2>Gemini</Address2>
				        <Address3 />
				        <CityID>542328</CityID>
				        <DistrictID>473</DistrictID>
				        <StateID>30</StateID>
				        <Pincode>600006</Pincode>
				        <Country>1</Country>
				        <NearestLandmark />
				      </PermanentAddress>
				    </ClientAddress>
				    <EmailID>sekhar@upcreativeinc.com</EmailID>
				    <Salutation>Mr</Salutation>
				    <MaritalStatus>1952</MaritalStatus>
				    <Nationality />
				  </ClientDetails>
				  <Policy>
				    <BusinessType>5</BusinessType>
				    <Cover_From>2016-08-17</Cover_From>
				    <Cover_To>2017-08-16</Cover_To>
				    <Branch_Code>9202</Branch_Code>
				    <AgentName>Direct</AgentName>
				    <productcode>2312</productcode>
				    <OtherSystemName>1</OtherSystemName>
				    <isMotorQuote>true</isMotorQuote>
				    <isMotorQuoteFlow>true</isMotorQuoteFlow>
				  </Policy>
				  <Risk>
				    <VehicleMakeID>114</VehicleMakeID>
				    <VehicleModelID>22154</VehicleModelID>
				    <CubicCapacity>125</CubicCapacity>
				    <RTOLocationID>756</RTOLocationID>
				    <ExShowroomPrice>56607</ExShowroomPrice>
				    <IDV>53777.0</IDV>
				    <DateOfPurchase>2016-08-17</DateOfPurchase>
				    <ManufactureMonth>08</ManufactureMonth>
				    <ManufactureYear>2016</ManufactureYear>
				    <EngineNo>Enquo1234567</EngineNo>
				    <Chassis>chasi1234567</Chassis>
				    <IsRegAddressSameasCommAddress>false</IsRegAddressSameasCommAddress>
				    <IsRegAddressSameasPermanentAddress>false</IsRegAddressSameasPermanentAddress>
				    <IsPermanentAddressSameasCommAddress>true</IsPermanentAddressSameasCommAddress>
				    <VehicleVariant>STD</VehicleVariant>
				    <StateOfRegistrationID>30</StateOfRegistrationID>
				  </Risk>
				  <Vehicle>
				    <Registration_Number>New</Registration_Number>
				    <Registration_date>2016-08-17</Registration_date>
				    <TypeOfFuel>1</TypeOfFuel>
				    <MiscTypeOfVehicleID />
				    <ISNewVehicle>true</ISNewVehicle>
				  </Vehicle>
				  <Cover>
				    <IsPAToUnnamedPassengerCovered>false</IsPAToUnnamedPassengerCovered>
				    <IsAutomobileAssociationMember>false</IsAutomobileAssociationMember>
				    <IsPAToOwnerDriverCoverd>true</IsPAToOwnerDriverCoverd>
				    <IsLiabilityToPaidDriverCovered>false</IsLiabilityToPaidDriverCovered>
				    <IsAntiTheftDeviceFitted>false</IsAntiTheftDeviceFitted>
				    <IsTPPDCover>true</IsTPPDCover>
				    <IsBasicODCoverage>true</IsBasicODCoverage>
				    <IsBasicLiability>true</IsBasicLiability>
				    <IsInsurancePremium>false</IsInsurancePremium>
				    <ElectricItems />
				    <NonElectricItems />
				    <BasicODCoverage />
				    <GeographicalExtension />
				    <BifuelKit />
				    <DrivingTuitionCoverage />
				    <FibreGlassFuelTank />
				    <AdditionalTowingCoverage />
				    <VoluntaryDeductible />
				    <AntiTheftDeviceDiscount />
				    <SpeciallyDesignedforChallengedPerson />
				    <AutomobileAssociationMembershipDiscount />
				    <UseOfVehiclesConfined />
				    <TotalCover />
				    <RegistrationCost />
				    <RoadTax />
				    <InsurancePremium />
				    <NilDepreciationCoverage />
				    <BasicLiability />
				    <TPPDCover />
				    <PACoverToOwner>
				      <PACoverToOwner>
				        <IsChecked>true</IsChecked>
				        <NoOfItems />
				        <PackageName />
				        <AppointeeName />
				        <NomineeName>Reddy</NomineeName>
				        <NomineeDOB>1970-01-07</NomineeDOB>
				        <NomineeRelationship>Father</NomineeRelationship>
				        <NomineeAddress />
				        <OtherRelation />
				      </PACoverToOwner>
				    </PACoverToOwner>
				    <PAToNamedPassenger />
				    <PAToUnNamedPassenger>
				      <PAToUnNamedPassenger>
				        <IsChecked>false</IsChecked>
				        <NoOfItems>0</NoOfItems>
				        <SumInsured>0</SumInsured>
				      </PAToUnNamedPassenger>
				    </PAToUnNamedPassenger>
				    <PAToPaidDriver>
				      <PAToPaidDriver>
				        <IsChecked />
				        <NoOfItems />
				        <SumInsured />
				      </PAToPaidDriver>
				    </PAToPaidDriver>
				    <PAToPaidCleaner />
				    <LiabilityToPaidDriver>
				      <LiabilityToPaidDriver>
				        <NoOfItems>1</NoOfItems>
				      </LiabilityToPaidDriver>
				    </LiabilityToPaidDriver>
				    <LiabilityToEmployee />
				    <NFPPIncludingEmployees />
				    <NFPPExcludingEmployees />
				    <WorkmenCompensationExcludingDriver />
				    <PAToConductor />
				    <LiabilityToConductor />
				    <LiabilitytoCoolie />
				    <LegalLiabilitytoCleaner />
				    <IndemnityToHirer />
				    <TrailerDetails />
				    <BifuelKitLiability />
				    <BifuelKitTP />
				    <HiredVehicleDrivenByHirer />
				    <ODDiscount />
				    <ODLoading />
				    <SecurePlus />
				    <SecurePremium />
				    <TrailerLiability />
				    <SideCar />
				    <SideCarDiscount />
				    <SideCarLiability />
				    <GeoExtension />
				    <CommercialVehicleUsedAsPrivate />
				    <CommercialVehicleUsedAsPrivateLiability />
				    <Imt23LampOrTyreTubeOrHeadlight />
				    <LegalLiabToFarePayingPassenger />
				    <LiabilityToPersonEmployedForLoadUnloading />
				    <DrivingTuitionLiabilityCoverage />
				    <IndemnityToHirerLiability />
				    <OverTurningCovered />
				    <ImportedVehicleCover />
				    <IMT32DefenceOfficialCoverage />
				    <RelaibilityTrialsAndRallies />
				    <LossOfAccessoriesCovered />
				    <EMIprotectionCover />
				    <IsGeographicalAreaExtended>false</IsGeographicalAreaExtended>
				    <IsBiFuelKit>false</IsBiFuelKit>
				  </Cover>
				  <PreviousInsuranceDetails>
				    <PrevInsuranceID />
				    <IsVehicleOfPreviousPolicySold>false</IsVehicleOfPreviousPolicySold>
				    <IsNCBApplicable>true</IsNCBApplicable>
				    <PrevYearInsurer />
				    <PrevYearPolicyNo />
				    <PrevYearInsurerAddress />
				    <DocumentProof />
				    <PrevYearPolicyType>1</PrevYearPolicyType>
				    <PrevYearPolicyStartDate>1900-01-01</PrevYearPolicyStartDate>
				    <MTAReason />
				    <PrevYearPolicyEndDate>1900-01-01</PrevYearPolicyEndDate>
				    <PrevYearNCB>0</PrevYearNCB>
				    <IsInspectionDone>false</IsInspectionDone>
				    <InspectionDate />
				    <Inspectionby />
				    <InspectorName />
				    <IsNCBEarnedAbroad>false</IsNCBEarnedAbroad>
				    <ODLoading />
				    <IsClaimedLastYear>false</IsClaimedLastYear>
				    <ODLoadingReason />
				    <PreRateCharged />
				    <PreSpecialTermsAndConditions />
				    <IsTrailerNCB>false</IsTrailerNCB>
				    <InspectionID />
				  </PreviousInsuranceDetails>
				  <ProductCode>2312</ProductCode>
				  <UserID>14BRG281B05</UserID>
				  <NCBEligibility>
				    <NCBEligibilityCriteria>1</NCBEligibilityCriteria>
				    <NCBReservingLetter />
				    <PreviousNCB>0</PreviousNCB>
				  </NCBEligibility>
				  <LstCoveragePremium />
				  <SourceSystemID>14BRG281B05</SourceSystemID>
				  <AuthToken>TTIBL30052018</AuthToken>
				</PolicyDetails>";
	} 
  
} // end of class
