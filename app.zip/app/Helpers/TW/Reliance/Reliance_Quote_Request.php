<?php

namespace App\Helpers\TW\Reliance;

use App\Libraries\TwLib;

class Reliance_Quote_Request {
	
	public function raw_quote_req_arr( ) {
		$raw_xml_str = $this->raw_xml_str();
		$xml = simplexml_load_string($raw_xml_str, "SimpleXMLElement", LIBXML_NOCDATA);
		$json = json_encode($xml);
		return json_decode($json,TRUE);
	}
	
	public function filled_quote_req_str($filled_req_arr) {
		$ret_str = "";
		$tw_lib = new TwLib();
		$ret_str = $tw_lib->array_to_xml($filled_req_arr, "PolicyDetails");
		return $ret_str; 
	}
		
	private function raw_xml_str(){
		return "<PolicyDetails>
	<CoverDetails />
	<TrailerDetails />
	<ClientDetails>
		<ClientType>0</ClientType>
		<LastName>test</LastName>
		<MidName>test</MidName>
		<ForeName>test</ForeName>
		<OccupationID />
		<DOB>1990-01-01</DOB>
		<Gender>Male</Gender>
		<PhoneNo />
		<MobileNo />
		<ClientAddress>
			<CommunicationAddress>
				<AddressType>0</AddressType>
				<Address1 />
				<Address2 />
				<Address3 />
				<CityID>0</CityID>
				<DistrictID />
				<StateID>0</StateID>
				<Pincode />
				<Country>1</Country>
				<NearestLandmark />
			</CommunicationAddress>
			<PermanentAddress>
				<AddressType>0</AddressType>
				<Address1 />
				<Address2 />
				<Address3 />
				<CityID>0</CityID>
				<DistrictID />
				<StateID>0</StateID>
				<Pincode />
				<Country>1</Country>
				<NearestLandmark />
			</PermanentAddress>
			<RegistrationAddress>
				<AddressType>0</AddressType>
				<Address1 />
				<Address2 />
				<Address3 />
				<CityID />
				<DistrictID>302</DistrictID>
				<StateID>14</StateID>
				<Pincode />
				<Country>1</Country>
				<NearestLandmark />
			</RegistrationAddress>
		</ClientAddress>
		<EmailID />
		<Salutation />
		<MaritalStatus>1952</MaritalStatus>
		<Nationality>1949</Nationality>
	</ClientDetails>
	<Policy>
		<BusinessType>5</BusinessType>
		<Cover_From>2017-07-10</Cover_From>
		<Cover_To>2017-07-09</Cover_To>
		<Branch_Code>9202</Branch_Code>
		<AgentName>Direct</AgentName>
		<productcode>2312</productcode>
		<OtherSystemName>1</OtherSystemName>
		<isMotorQuote>false</isMotorQuote>
		<isMotorQuoteFlow>false</isMotorQuoteFlow>
	</Policy>
	<Risk>
		<VehicleMakeID>201</VehicleMakeID>
		<VehicleModelID>4717</VehicleModelID>
		<Colour />
		<BodyType />
		<OtherColour />
		<GrossVehicleWeight />
		<CubicCapacity>135</CubicCapacity>
		<RTOLocationID>302</RTOLocationID>
		<ExShowroomPrice>58873</ExShowroomPrice>
		<IDV>0</IDV>
		<DateOfPurchase>2011-07-01</DateOfPurchase>
		<LicensedCarryingCapacity>2</LicensedCarryingCapacity>
		<NoOfWheels>2</NoOfWheels>
		<PurposeOfUsage />
		<ManufactureMonth>01</ManufactureMonth>
		<ManufactureYear>2011</ManufactureYear>
		<EngineNo />
		<Chassis />
		<TrailerIDV />
		<IsVehicleHypothicated>false</IsVehicleHypothicated>
		<FinanceType />
		<FinancierName />
		<FinancierAddress />
		<FinancierCity />
		<IsRegAddressSameasCommAddress>false</IsRegAddressSameasCommAddress>
		<IsRegAddressSameasPermanentAddress>false</IsRegAddressSameasPermanentAddress>
		<IsPermanentAddressSameasCommAddress>true</IsPermanentAddressSameasCommAddress>
		<SalesManagerCode>Direct</SalesManagerCode>
		<SalesManagerName>Direct</SalesManagerName>
		<VehicleVariant>135 DTSI ES</VehicleVariant>
		<StateOfRegistrationID>14</StateOfRegistrationID>
		<BodyIDV>0</BodyIDV>
		<ChassisIDV>0</ChassisIDV>
		<Rto_State_City>Ghumarvi</Rto_State_City>
		<Rto_RegionCode>HIMACHAL PRADESH</Rto_RegionCode>
	</Risk>
	<Vehicle>
		<Registration_Number>HP-23-H-4444</Registration_Number>
		<RegistrationNumber_New>HP-23-H-4444</RegistrationNumber_New>
		<Registration_date>2011-07-01</Registration_date>
		<RoadTypes>
			<RoadType>
				<RoadTypeID />
				<TypeOfRoad />
			</RoadType>
		</RoadTypes>
		<Permit>
			<PermitType>
				<TypeOfPermit />
			</PermitType>
		</Permit>
		<SeatingCapacity>135</SeatingCapacity>
		<MiscTypeOfVehicle />
		<TypeOfFuel>1</TypeOfFuel>
		<MiscTypeOfVehicleID />
		<ISNewVehicle>false</ISNewVehicle>
	</Vehicle>
	<Cover>
		<PACoverToNamedPassengerSI>0</PACoverToNamedPassengerSI>
		<IsPAToUnnamedPassengerCovered>false</IsPAToUnnamedPassengerCovered>
		<NoOfUnnamedPassenegersCovered>2</NoOfUnnamedPassenegersCovered>
		<UnnamedPassengersSI>0</UnnamedPassengersSI>
		<IsRacingCovered>false</IsRacingCovered>
		<IsLossOfAccessoriesCovered>false</IsLossOfAccessoriesCovered>
		<IsVoluntaryDeductableOpted>false</IsVoluntaryDeductableOpted>
		<VoluntaryDeductableAmount>0</VoluntaryDeductableAmount>
		<IsElectricalItemFitted>false</IsElectricalItemFitted>
		<ElectricalItemsTotalSI>0</ElectricalItemsTotalSI>
		<IsNonElectricalItemFitted>false</IsNonElectricalItemFitted>
		<NonElectricalItemsTotalSI>0</NonElectricalItemsTotalSI>
		<IsGeographicalAreaExtended>false</IsGeographicalAreaExtended>
		<IsBiFuelKit>false</IsBiFuelKit>
		<BiFuelKitSi>0</BiFuelKitSi>
		<IsAutomobileAssociationMember>False</IsAutomobileAssociationMember>
		<IsVehicleMadeInIndia>false</IsVehicleMadeInIndia>
		<IsUsedForDrivingTuition>false</IsUsedForDrivingTuition>
		<IsInsuredAnIndividual>true</IsInsuredAnIndividual>
		<IsIndividualAlreadyInsured>false</IsIndividualAlreadyInsured>
		<IsPAToOwnerDriverCoverd>true</IsPAToOwnerDriverCoverd>
		<ISLegalLiabilityToDefenceOfficialDriverCovered>false</ISLegalLiabilityToDefenceOfficialDriverCovered>
		<IsLiabilityToPaidDriverCovered>False</IsLiabilityToPaidDriverCovered>
		<IsLiabilityToEmployeeCovered>false</IsLiabilityToEmployeeCovered>
		<IsPAToDriverCovered>False</IsPAToDriverCovered>
		<IsPAToPaidCleanerCovered>false</IsPAToPaidCleanerCovered>
		<IsAdditionalTowingCover>false</IsAdditionalTowingCover>
		<IsLegalLiabilityToCleanerCovered>false</IsLegalLiabilityToCleanerCovered>
		<IsLegalLiabilityToNonFarePayingPassengersCovered>false</IsLegalLiabilityToNonFarePayingPassengersCovered>
		<IsLegalLiabilityToCoolieCovered>false</IsLegalLiabilityToCoolieCovered>
		<IsCoveredForDamagedPortion>false</IsCoveredForDamagedPortion>
		<IsImportedVehicle>false</IsImportedVehicle>
		<IsFibreGlassFuelTankFitted>false</IsFibreGlassFuelTankFitted>
		<IsConfinedToOwnPremisesCovered>false</IsConfinedToOwnPremisesCovered>
		<IsAntiTheftDeviceFitted>False</IsAntiTheftDeviceFitted>
		<IsTPPDLiabilityRestricted>false</IsTPPDLiabilityRestricted>
		<IsTPPDCover>true</IsTPPDCover>
		<IsBasicODCoverage>true</IsBasicODCoverage>
		<IsBasicLiability>true</IsBasicLiability>
		<IsUseOfVehiclesConfined>false</IsUseOfVehiclesConfined>
		<IsTotalCover />
		<IsRegistrationCover>false</IsRegistrationCover>
		<IsRoadTaxcover>false</IsRoadTaxcover>
		<IsInsurancePremium>false</IsInsurancePremium>
		<IsCoverageoFTyreBumps>false</IsCoverageoFTyreBumps>
		<IsImportedVehicleCover>false</IsImportedVehicleCover>
		<IsVehicleDesignedAsCV>false</IsVehicleDesignedAsCV>
		<IsWorkmenCompensationExcludingDriver>false</IsWorkmenCompensationExcludingDriver>
		<IsLiabilityForAccidentsInclude>false</IsLiabilityForAccidentsInclude>
		<IsLiabilityForAccidentsExclude>false</IsLiabilityForAccidentsExclude>
		<IsLiabilitytoCoolie>false</IsLiabilitytoCoolie>
		<IsLiabilitytoCleaner>false</IsLiabilitytoCleaner>
		<IsLiabilityToConductor>false</IsLiabilityToConductor>
		<IsPAToConductorCovered>false</IsPAToConductorCovered>
		<IsNFPPIncludingEmployees>false</IsNFPPIncludingEmployees>
		<IsNFPPExcludingEmployees>false</IsNFPPExcludingEmployees>
		<IsNCBRetention>false</IsNCBRetention>
		<IsHandicappedDiscount>false</IsHandicappedDiscount>
		<IsTrailerAttached>false</IsTrailerAttached>
		<cAdditionalCompulsoryExcess>0</cAdditionalCompulsoryExcess>
		<iNumberOfLegalLiabilityCoveredPaidDrivers>0</iNumberOfLegalLiabilityCoveredPaidDrivers>
		<NoOfLiabilityCoveredEmployees>0</NoOfLiabilityCoveredEmployees>
		<PAToDriverSI>0</PAToDriverSI>
		<PAToCleanerSI>0</PAToCleanerSI>
		<NumberOfPACoveredPaidDrivers>0</NumberOfPACoveredPaidDrivers>
		<NoOfPAtoPaidCleanerCovered>0</NoOfPAtoPaidCleanerCovered>
		<AdditionalTowingCharge>0</AdditionalTowingCharge>
		<NoOfLegalLiabilityCoveredCleaners>0</NoOfLegalLiabilityCoveredCleaners>
		<NoOfLegalLiabilityCoveredNonFarePayingPassengers>0</NoOfLegalLiabilityCoveredNonFarePayingPassengers>
		<NoOfLegalLiabilityCoveredCoolies>0</NoOfLegalLiabilityCoveredCoolies>
		<iNoOfLegalLiabilityCoveredPeopleOtherThanPaidDriver>0</iNoOfLegalLiabilityCoveredPeopleOtherThanPaidDriver>
		<ISLegalLiabilityToConductorCovered>false</ISLegalLiabilityToConductorCovered>
		<NoOfLegalLiabilityCoveredConductors>0</NoOfLegalLiabilityCoveredConductors>
		<PAToConductorSI>0</PAToConductorSI>
		<CompulsoryDeductible>0</CompulsoryDeductible>
		<PACoverToOwnerDriver>1</PACoverToOwnerDriver>
		<ElectricItems>
			<ElectricalItems>
				<ElectricalItemsID />
				<PolicyId />
				<SerialNo />
				<MakeModel />
				<ElectricPremium>0</ElectricPremium>
				<Description />
				<ElectricalAccessorySlNo />
				<SumInsured>0</SumInsured>
			</ElectricalItems>
		</ElectricItems>
		<NonElectricItems>
			<NonElectricalItems>
				<NonElectricalItemsID />
				<PolicyID />
				<SerialNo />
				<MakeModel />
				<NonElectricPremium>0</NonElectricPremium>
				<Description />
				<Category />
				<NonElectricalAccessorySlNo />
				<SumInsured>0</SumInsured>
			</NonElectricalItems>
		</NonElectricItems>
		<BasicODCoverage>
			<BasicODCoverage>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</BasicODCoverage>
		</BasicODCoverage>
		<GeographicalExtension>
			<GeographicalExtension>
				<Countries />
				<IsChecked>false</IsChecked>
			</GeographicalExtension>
		</GeographicalExtension>
		<BifuelKit>
			<BifuelKit>
				<ISLpgCng>false</ISLpgCng>
				<SumInsured>0</SumInsured>
			</BifuelKit>
		</BifuelKit>
		<DrivingTuitionCoverage>
			<DrivingTuitionCoverage>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</DrivingTuitionCoverage>
		</DrivingTuitionCoverage>
		<FibreGlassFuelTank>
			<FibreGlassFuelTank>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</FibreGlassFuelTank>
		</FibreGlassFuelTank>
		<AdditionalTowingCoverage>
			<AdditionalTowingCoverage>
				<PolicyCoverID />
				<SumInsured>0</SumInsured>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</AdditionalTowingCoverage>
		</AdditionalTowingCoverage>
		<VoluntaryDeductible>
			<VoluntaryDeductible>
				<SumInsured>0</SumInsured>
			</VoluntaryDeductible>
		</VoluntaryDeductible>
		<AntiTheftDeviceDiscount>
			<AntiTheftDeviceDiscount>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
				<PackageName />
			</AntiTheftDeviceDiscount>
		</AntiTheftDeviceDiscount>
		<SpeciallyDesignedforChallengedPerson>
			<SpeciallyDesignedforChallengedPerson>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</SpeciallyDesignedforChallengedPerson>
		</SpeciallyDesignedforChallengedPerson>
		<AutomobileAssociationMembershipDiscount>
			<AutomobileAssociationMembershipDiscount>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
				<PackageName />
			</AutomobileAssociationMembershipDiscount>
		</AutomobileAssociationMembershipDiscount>
		<UseOfVehiclesConfined>
			<UseOfVehiclesConfined>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</UseOfVehiclesConfined>
		</UseOfVehiclesConfined>
		<TotalCover>
			<TotalCover>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</TotalCover>
		</TotalCover>
		<HelmetCover />
		<RegistrationCost>
			<RegistrationCost>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<SumInsured>0</SumInsured>
			</RegistrationCost>
		</RegistrationCost>
		<RoadTax>
			<RoadTax>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<SumInsured>0</SumInsured>
				<PolicyCoverID />
			</RoadTax>
		</RoadTax>
		<InsurancePremium>
			<InsurancePremium>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</InsurancePremium>
		</InsurancePremium>
		<NilDepreciationCoverage>
			<NilDepreciationCoverage>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<PolicyCoverID />
				<ApplicableRate>1</ApplicableRate>
			</NilDepreciationCoverage>
		</NilDepreciationCoverage>
		<BasicLiability>
			<BasicLiability>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
			</BasicLiability>
		</BasicLiability>
		<TPPDCover>
			<TPPDCover>
				<PolicyCoverID />
				<SumInsured>720</SumInsured>
				<PackageName />
			</TPPDCover>
		</TPPDCover>
		<PACoverToOwner>
			<PACoverToOwner>
				<IsChecked>true</IsChecked>
				<AppointeeName />
				<NomineeName />
				<NomineeDOB />
				<NomineeRelationship />
				<NomineeAddress />
				<OtherRelation />
			</PACoverToOwner>
		</PACoverToOwner>
		<PAToNamedPassenger>
			<PAToNamedPassenger>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<SumInsured />
				<PassengerName />
				<NomineeName />
				<NomineeDOB />
				<NomineeRelationship />
				<NomineeAddress />
				<OtherRelation />
				<AppointeeName />
			</PAToNamedPassenger>
		</PAToNamedPassenger>
		<PAToUnNamedPassenger>
			<PAToUnNamedPassenger>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
				<PackageName />
				<PolicyCoverID />
				<SumInsured>0</SumInsured>
			</PAToUnNamedPassenger>
		</PAToUnNamedPassenger>
		<PAToPaidDriver>
			<PAToPaidDriver>
				<NoOfItems>0</NoOfItems>
				<SumInsured>0</SumInsured>
			</PAToPaidDriver>
		</PAToPaidDriver>
		<PAToPaidCleaner>
			<PAToPaidCleaner>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<PolicyCoverID />
				<SumInsured>0</SumInsured>
			</PAToPaidCleaner>
		</PAToPaidCleaner>
		<LiabilityToPaidDriver>
			<LiabilityToPaidDriver>
				<NoOfItems>0</NoOfItems>
			</LiabilityToPaidDriver>
		</LiabilityToPaidDriver>
		<LiabilityToEmployee>
			<LiabilityToEmployee>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<PackageName />
				<PolicyCoverID />
			</LiabilityToEmployee>
		</LiabilityToEmployee>
		<NFPPIncludingEmployees>
			<NFPPIncludingEmployees>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
			</NFPPIncludingEmployees>
		</NFPPIncludingEmployees>
		<NFPPExcludingEmployees>
			<NFPPExcludingEmployees>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
			</NFPPExcludingEmployees>
		</NFPPExcludingEmployees>
		<WorkmenCompensationExcludingDriver>
			<WorkmenCompensationExcludingDriver>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
			</WorkmenCompensationExcludingDriver>
		</WorkmenCompensationExcludingDriver>
		<PAToConductor>
			<PAToConductor>
				<IsChecked>false</IsChecked>
				<NoOfItems />
				<SumInsured />
			</PAToConductor>
		</PAToConductor>
		<LiabilityToConductor>
			<LiabilityToConductor>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
			</LiabilityToConductor>
		</LiabilityToConductor>
		<LiabilitytoCoolie>
			<LiabilitytoCoolie>
				<IsChecked>false</IsChecked>
				<NoOfItems>0</NoOfItems>
			</LiabilitytoCoolie>
		</LiabilitytoCoolie>
		<LegalLiabilitytoCleaner />
		<IndemnityToHirer>
			<IndemnityToHirer>
				<IsChecked>false</IsChecked>
				<NoOfItems />
			</IndemnityToHirer>
		</IndemnityToHirer>
		<TrailerDetails>
			<TrailerInfo>
				<MakeandModel />
				<IDV />
				<Registration_No />
				<ChassisNumber />
				<ManufactureYear />
				<SerialNumber />
			</TrailerInfo>
		</TrailerDetails>
		<BifuelKitLiability />
		<BifuelKitTP />
		<HiredVehicleDrivenByHirer />
		<ODDiscount />
		<ODLoading />
		<SecurePlus />
		<SecurePremium />
		<TrailerLiability />
		<SideCar />
		<SideCarDiscount />
		<SideCarLiability />
		<GeoExtension />
		<CommercialVehicleUsedAsPrivate />
		<CommercialVehicleUsedAsPrivateLiability />
		<Imt23LampOrTyreTubeOrHeadlight />
		<LegalLiabToFarePayingPassenger />
		<LiabilityToPersonEmployedForLoadUnloading />
		<DrivingTuitionLiabilityCoverage />
		<IndemnityToHirerLiability />
		<OverTurningCovered />
		<ImportedVehicleCover />
		<IMT32DefenceOfficialCoverage />
		<RelaibilityTrialsAndRallies />
		<LossOfAccessoriesCovered />
		<IsSpeciallyDesignedForHandicapped>false</IsSpeciallyDesignedForHandicapped>
		<IsPAToNamedPassenger>false</IsPAToNamedPassenger>
		<IsOverTurningCovered>false</IsOverTurningCovered>
		<IsLLToPersonsEmployedInOperations_PaidDriverCovered>false</IsLLToPersonsEmployedInOperations_PaidDriverCovered>
		<NoOfLLToPersonsEmployedInOperations_PaidDriver>0</NoOfLLToPersonsEmployedInOperations_PaidDriver>
		<IsLLToPersonsEmployedInOperations_CleanerConductorCoolieCovered>false</IsLLToPersonsEmployedInOperations_CleanerConductorCoolieCovered>
		<NoOfLLToPersonsEmployedInOperations_CleanerConductorCoolie>0</NoOfLLToPersonsEmployedInOperations_CleanerConductorCoolie>
		<IsLLUnderWCActForCarriageOfMoreThanSixEmpCovered>false</IsLLUnderWCActForCarriageOfMoreThanSixEmpCovered>
		<NoOfLLUnderWCAct />
		<IsLLToNFPPNotWorkmenUnderWCAct>false</IsLLToNFPPNotWorkmenUnderWCAct>
		<NoOfLLToNFPPNotWorkmenUnderWCAct>0</NoOfLLToNFPPNotWorkmenUnderWCAct>
		<IsIndemnityToHirerCovered>false</IsIndemnityToHirerCovered>
		<IsAccidentToPassengerCovered>false</IsAccidentToPassengerCovered>
		<NoOfAccidentToPassengerCovered>0</NoOfAccidentToPassengerCovered>
		<IsNilDepreciation>false</IsNilDepreciation>
		<IsDetariffRateForOverturning>false</IsDetariffRateForOverturning>
		<IsAddOnCoverforTowing>false</IsAddOnCoverforTowing>
		<AddOnCoverTowingCharge>0</AddOnCoverTowingCharge>
		<EMIprotectionCover />
	</Cover>
	<PreviousInsuranceDetails>
		<PrevInsuranceID />
		<IsNCBApplicable>true</IsNCBApplicable>
		<PrevYearInsurer>United Insurance company Ltd</PrevYearInsurer>
		<PrevYearPolicyNo />
		<PrevYearInsurerAddress />
		<PrevYearPolicyStartDate>2016-07-10</PrevYearPolicyStartDate>
		<MTAReason />
		<PrevYearPolicyEndDate>2017-07-09</PrevYearPolicyEndDate>
		<IsInspectionDone>false</IsInspectionDone>
		<InspectionDate />
		<Inspectionby />
		<InspectorName />
		<IsNCBEarnedAbroad>false</IsNCBEarnedAbroad>
		<ODLoading />
		<IsClaimedLastYear>false</IsClaimedLastYear>
		<ODLoadingReason />
		<PreRateCharged />
		<PreSpecialTermsAndConditions />
		<IsTrailerNCB>false</IsTrailerNCB>
		<InspectionID />
	</PreviousInsuranceDetails>
	<ProductCode>2312</ProductCode>
	<UserID>14BRG281B05</UserID>
	<NCBEligibility>
		<NCBEligibilityCriteria>2</NCBEligibilityCriteria>
		<NCBReservingLetter>wchkReservingLetter</NCBReservingLetter>
		<PreviousNCB>5</PreviousNCB>
	</NCBEligibility>
	<LstCoveragePremium />
	<ValidateFlag>false</ValidateFlag>
	<SourceSystemID>14BRG281B05</SourceSystemID>
	<AuthToken>TTIBL30052018</AuthToken>
	<LstTaxComponentDetails />
</PolicyDetails>";
		
	} 

	
	
} // end of class
