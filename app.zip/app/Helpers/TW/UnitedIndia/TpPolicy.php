<?php

namespace App\Helpers\TW\UnitedIndia;

use App\Helpers\TW\InsurerData;
use App\Libraries\TwLib;
use Illuminate\Support\Facades\Log;

class TpPolicy {

	public function submit_policy ( $proposal_usr_data, $payment_resp_arr) {
		
		// now populate policy data with user data.
		$populated_policy_arr = $this->populate_policy_request ($proposal_usr_data, $payment_resp_arr) ;
		
		$policy_req_xml_str = $this->prepare_quote_request($populated_policy_arr);
		
		$policy_response = $this->call_submit_policy($policy_req_xml_str);
		
		if( $policy_response !== null ) {
			return simplexml_load_string($policy_response->return);
		}else {return null;}
		
	}
	
	
	private function populate_policy_request ($pr_usr_data, $pg_resp_arr) {
	
		$tw_lib = new TwLib();
		$insurer_data = new InsurerData();
		$rto_code = $pr_usr_data->rto_code; 
		// transcational details
		$policy_arr["TXT_OEM_TRANSACTION_ID"] = $pr_usr_data->trans_code;
		
		//details
		$policy_arr["TXT_NAME_OF_MANUFACTURER"] = $insurer_data->insr_make("make_name", $pr_usr_data->make_code);
		$policy_arr["TXT_OTHER_MAKE"] = $insurer_data->model_data("model_name", $pr_usr_data->model_code);
		$policy_arr["TXT_VARIANT"] = $insurer_data->insr_variant("variant_name", $pr_usr_data->variant_code);
		$policy_arr["TXT_RTA_DESC"] = $insurer_data->insr_rto("uiic_code", $rto_code);
		$policy_arr["TXT_VEHICLE_ZONE"] = $insurer_data->insr_rto("zone", $rto_code );
		$policy_arr["TXT_TYPE_BODY"] = $insurer_data->insr_variant("body_type", $pr_usr_data->variant_code);
		
		//quote
		$policy_arr["NUM_POLICY_YEAR"] = $tw_lib->get_curr_year();
		$policy_arr["DAT_PREV_POLICY_EXPIRY_DATE"] = $this->format_date( $pr_usr_data->policy_exp_date);
		$policy_arr["DAT_DATE_OF_ISSUE_OF_POLICY"] = $this->format_date( $pr_usr_data->term_start_date);
		$policy_arr["DAT_DATE_OF_EXPIRY_OF_POLICY"] = $this->format_date( $pr_usr_data->term_end_date);
		$policy_arr["DAT_PROPOSAL_DATE"] = $tw_lib->date_today("d/m/Y");
		$policy_arr["DAT_DATE_OF_REGISTRATION"] = $this->format_date( $pr_usr_data->tw_reg_date);
		
		
		
		$addon_pre_arr = explode("|", $pr_usr_data->addon_premium) ;
		$tot_add_premium = 0;
		foreach ($addon_pre_arr as $add_value) {
			$tot_add_premium = $tot_add_premium + $add_value;
		}
		
		// addon specific tags
		$addon_cover_arr = explode("|", $pr_usr_data->addon_covers );
		// PA OD
		if(isset($addon_cover_arr[0])){
			$policy_arr["YN_COMPULSORY_PA_DTLS"] = "-1";
			$policy_arr["PAODPremium"] =  $addon_pre_arr[0];
			$policy_arr["TXT_NAME_OF_NOMINEE"] = $pr_usr_data->proposer_name;
			$policy_arr["TXT_RELATION_WITH_NOMINEE"] = "SELF";
		}else{
			$policy_arr["YN_COMPULSORY_PA_DTLS"] = "0";
			$policy_arr["PAODPremium"] =  "0";
			$policy_arr["TXT_NAME_OF_NOMINEE"] = "";
			$policy_arr["TXT_RELATION_WITH_NOMINEE"] = "";
		}
		// ll to unnamed passengers. 
		if(isset($addon_cover_arr[1])){
			$policy_arr["NUM_PA_UNNAMED_NUMBER"] = "2";
			$policy_arr["NUM_PA_UNNAMED_AMOUNT"] = "100000";
			$policy_arr["PassengerCoverPremium"] = "100";
		} else {
			$policy_arr["NUM_PA_UNNAMED_NUMBER"] = "0";
			$policy_arr["NUM_PA_UNNAMED_AMOUNT"] = "";
			$policy_arr["PassengerCoverPremium"] = "0";
		}
		
		$net_tp_premium = $pr_usr_data->tp_premium + $tot_add_premium; 
		
		$policy_arr["TotalAddOnPremium"] =  "";
		
		$policy_arr["BasicTPPremium"] =  $pr_usr_data->tp_premium;
		$policy_arr["CUR_DEALER_NET_TP_PREM"] =  $net_tp_premium;
		$policy_arr["CUR_DEALER_SERVICE_TAX"] =  $pr_usr_data->total_tax;
		$policy_arr["CUR_DEALER_GROSS_PREM"] = $pr_usr_data->final_premium;
		
		//proposer
		if($pr_usr_data->owner_type == "I"){
			$policy_arr["NUM_CLIENT_TYPE"] = "I";
			$policy_arr["NUM_PAID_UP_CAPITAL"] = "";
			$policy_arr["TXT_AADHAR_NUMBER"] = $pr_usr_data->proposer_aadharno;
			$policy_arr["TXT_TITLE"] = $pr_usr_data->proposer_gender == "MALE" ? "Mr" : "Ms";
		}else{
			$policy_arr["NUM_CLIENT_TYPE"] = "C";
			$policy_arr["TXT_TITLE"] = "M/S";
			$policy_arr["NUM_PAID_UP_CAPITAL"] = "1";
			$policy_arr["TXT_GSTIN_NUMBER"] = $pr_usr_data->proposer_aadharno;   // org. gstn is getting stored in this feild
		}
		
		
		$policy_arr["TXT_GENDER"] = $pr_usr_data->proposer_gender;
		$policy_arr["TXT_NAME_OF_INSURED"] = $pr_usr_data->proposer_name;
		$policy_arr["TXT_DOB"] = $this->format_date( $pr_usr_data->proposer_dob);
		$policy_arr["TXT_EMAIL_ADDRESS"] = $pr_usr_data->proposer_email;
		$policy_arr["TXT_MOBILE"] = $pr_usr_data->proposer_mobile;
		$policy_arr["TXT_TELEPHONE"] = $pr_usr_data->proposer_mobile;
		$policy_arr["MEM_ADDRESS_OF_INSURED"] = $pr_usr_data->regn_addr1;
		$policy_arr["NUM_PIN_CODE"] = $pr_usr_data->regn_pincode;
		$policy_arr["TXT_PREV_INSURER_CODE"] = $insurer_data->insr_preinsr("uiic_code", $pr_usr_data->pre_insurer_code);
		$policy_arr["TXT_PREVIOUS_INSURER"] = $insurer_data->insr_preinsr("preinsr_name", $pr_usr_data->pre_insurer_code);
		
		//vechicle 
		$policy_arr["TXT_ENGINE_NUMBER"] = $pr_usr_data->tw_engine_no;
		$policy_arr["TXT_CHASSIS_NUMBER"] = $pr_usr_data->tw_chassis_no;
		$policy_arr["NUM_CUBIC_CAPACITY"] = $pr_usr_data->variant_cc;
		$policy_arr["TXT_VAHICLE_COLOR"] = $pr_usr_data->color;
		$policy_arr["NUM_YEAR_OF_MANUFACTURE"] = $pr_usr_data->yom;
		
		$raw_tw_no = $pr_usr_data->tw_reg_no; 
		$tw_no_arr = explode("-",$raw_tw_no);   
		
		$policy_arr["TXT_REGISTRATION_NUMBER_1"] = $tw_no_arr[0];
		$policy_arr["TXT_REGISTRATION_NUMBER_2"] = $tw_no_arr[1];
		$policy_arr["TXT_REGISTRATION_NUMBER_3"] = $tw_no_arr[2];
		$policy_arr["TXT_REGISTRATION_NUMBER_4"] = $tw_no_arr[3];
		
		// pg values
		$policy_arr["TXT_OEM_TRANSACTION_ID"] = $pg_resp_arr["TxnReferenceNo"];
		$policy_arr["TXT_PAYMENT_MODE"] = "CC";
		$policy_arr["TXT_UTR_NUMBER"] = $pg_resp_arr["BankMerchantID"];
		$policy_arr["DAT_UTR_DATE"] =   $this->format_date( explode(" ", $pg_resp_arr["TxnDate"])[0]);
	//	$policy_arr["NUM_UTR_PAYMENT_AMOUNT"] = $pg_resp_arr["TxnAmount"];
	     $policy_arr["NUM_UTR_PAYMENT_AMOUNT"] = $pr_usr_data->final_premium;
		$policy_arr["TXT_BANK_CODE"] = $pg_resp_arr["BankID"];
		$policy_arr["TXT_BANK_NAME"] = "";
		
		//gst values to populate
		$customer_gst_code = $insurer_data->insr_state("gst_code", $pr_usr_data->regn_state_code);
		$policy_arr["CUST_GST_STATE_CODE"] = $customer_gst_code;
		$policy_arr["INS_OFF_GST_STATE_CODE"] = "29";  // 29 is for karnataka.
		$policy_arr["INS_OFF_CODE"] = "072300";
		
		if($pr_usr_data->regn_state_code== "II0017") {
			$policy_arr["OEM_NUM_SGST_RATE"] = "9";
			$policy_arr["OEM_CUR_SGST_VALUE"] = $this->get_sgst_cgst($pr_usr_data->total_tax);
			$policy_arr["OEM_NUM_CGST_RATE"] = "9";
			$policy_arr["OEM_CUR_CGST_VALUE"] =  $this->get_sgst_cgst($pr_usr_data->total_tax);
		}else{
			$policy_arr["OEM_NUM_IGST_RATE"] = "18";
			$policy_arr["OEM_CUR_IGST_VALUE"] = $pr_usr_data->total_tax;
		}
		
		return $policy_arr;
	}
	
	private function get_sgst_cgst($total_tax) { return round($total_tax/2);}
	
	private function call_submit_policy($policy_req_str) {  
		Log::info("TW_UIIC_TP_POLICY_REQUEST : ". $policy_req_str);
	
      	$wsdlurl = "https://portal.uiic.in/uiic/UGenericService/UInstaService?wsdl";      // this is produciton.
		$api_resp = null;
		try {
			$client = new \SoapClient($wsdlurl) ;
			$params = array('application'=>'INSTAINS','userid'=> 'INSTAINS','password'=>'uiic','productCode'=>'3112','subproductCode'=> '3','proposalXml'=> $policy_req_str );
			$api_resp = $client->policyInfoOffXml($params);
			
		}catch (\Exception $ex) {	
			Log::info("TW_UIIC_TP_POLICY_RESPONSE : EXCEPTION :" . $ex->getMessage());
			return null;
		}
		Log::info("TW_UIIC_TP_POLICY_RESPONSE : " . print_r($api_resp,true));
		return $api_resp;
	}
	
    private function prepare_quote_request( $req_arr ) {
		
	$quote_req_str = "<ROOT>
	<HEADER>
		<TXT_OEM_TRANSACTION_ID></TXT_OEM_TRANSACTION_ID>
		<TXT_OEM_DEALER_CODE>BRC0000702</TXT_OEM_DEALER_CODE>
		<TXT_GC_PRODUCT_CODE>3112</TXT_GC_PRODUCT_CODE>
		<NUM_VEHICLE_TYPE_INTL_CODE>3</NUM_VEHICLE_TYPE_INTL_CODE>
		<NUM_VEHICLE_SPECS_INTL_CODE></NUM_VEHICLE_SPECS_INTL_CODE>	
		<NUM_POLICY_TYPE>LiabilityOnly</NUM_POLICY_TYPE>
		<NUM_PROPOSAL_TYPE>NEWPOLICY</NUM_PROPOSAL_TYPE>
		<NUM_POLICY_YEAR></NUM_POLICY_YEAR>
		<DAT_DATE_OF_ISSUE_OF_POLICY></DAT_DATE_OF_ISSUE_OF_POLICY>
		<DAT_DATE_OF_EXPIRY_OF_POLICY></DAT_DATE_OF_EXPIRY_OF_POLICY>
		<DAT_HOURS_EFFECTIVE_FROM>00:00</DAT_HOURS_EFFECTIVE_FROM>
		<NUM_BUSINESS_CODE>Roll Over</NUM_BUSINESS_CODE>
		<DAT_PROPOSAL_DATE></DAT_PROPOSAL_DATE>
		<TXT_YN_PREV_POL_SUBMIT>0</TXT_YN_PREV_POL_SUBMIT>
		<TXT_YN_CUSTOMER_UNDERTAKE>0</TXT_YN_CUSTOMER_UNDERTAKE>
		<NUM_POLICY_NUMBER></NUM_POLICY_NUMBER>
		<TXT_PREV_POL_EFFECTIVE_DATE></TXT_PREV_POL_EFFECTIVE_DATE>
		<DAT_PREV_POLICY_EXPIRY_DATE></DAT_PREV_POLICY_EXPIRY_DATE>
		<NUM_PREVIOUS_IDV></NUM_PREVIOUS_IDV>
		<TXT_PREV_INSURER_CODE></TXT_PREV_INSURER_CODE>
		<TXT_PREVIOUS_INSURER></TXT_PREVIOUS_INSURER>
		<YN_CLAIM></YN_CLAIM>
		<TXT_YN_NCB_SUBMIT></TXT_YN_NCB_SUBMIT>
		<TXT_NCB_FLAG></TXT_NCB_FLAG>
		<CUR_BONUS_MALUS_PERCENT>0</CUR_BONUS_MALUS_PERCENT>
		<NOCLAIMBONUSDISCOUNT>0</NOCLAIMBONUSDISCOUNT>
		<TXT_NAME_OF_INSURED></TXT_NAME_OF_INSURED>
		<TXT_TITLE></TXT_TITLE>
		<TXT_GENDER></TXT_GENDER>
		<TXT_DOB></TXT_DOB>
		<MEM_ADDRESS_OF_INSURED></MEM_ADDRESS_OF_INSURED>
		<TXT_TELEPHONE></TXT_TELEPHONE>
		<TXT_MOBILE></TXT_MOBILE>
		<NUM_PIN_CODE></NUM_PIN_CODE>
		<TXT_EMAIL_ADDRESS></TXT_EMAIL_ADDRESS>
		<TXT_PAN_NO></TXT_PAN_NO>
		<NUM_CLIENT_TYPE></NUM_CLIENT_TYPE>
		<NUM_PAID_UP_CAPITAL></NUM_PAID_UP_CAPITAL>
		<TXT_OCCUPATION>Others</TXT_OCCUPATION>
		<TXT_NAME_OF_MANUFACTURER></TXT_NAME_OF_MANUFACTURER>
		<TXT_OTHER_MAKE></TXT_OTHER_MAKE>
		<TXT_VARIANT></TXT_VARIANT>
		<TXT_TYPE_BODY></TXT_TYPE_BODY>
		<DAT_DATE_OF_REGISTRATION></DAT_DATE_OF_REGISTRATION>
		<NUM_MONTH_OF_MANUFACTURE>01</NUM_MONTH_OF_MANUFACTURE>
		<NUM_YEAR_OF_MANUFACTURE></NUM_YEAR_OF_MANUFACTURE>
		<NUM_RGSTRD_SEATING_CAPACITY>2</NUM_RGSTRD_SEATING_CAPACITY>
		<TXT_ENGINE_NUMBER></TXT_ENGINE_NUMBER>
		<TXT_CHASSIS_NUMBER></TXT_CHASSIS_NUMBER>
		<NUM_CUBIC_CAPACITY></NUM_CUBIC_CAPACITY>
		<TXT_FUEL>Petrol</TXT_FUEL>
		<TXT_VAHICLE_COLOR></TXT_VAHICLE_COLOR>
		<TXT_REGISTRATION_NUMBER_1></TXT_REGISTRATION_NUMBER_1>
		<TXT_REGISTRATION_NUMBER_2></TXT_REGISTRATION_NUMBER_2>
		<TXT_REGISTRATION_NUMBER_3></TXT_REGISTRATION_NUMBER_3>
		<TXT_REGISTRATION_NUMBER_4></TXT_REGISTRATION_NUMBER_4>
		<NUM_RGSTRD_GROSS_VEH_WEIGHT>150</NUM_RGSTRD_GROSS_VEH_WEIGHT>
		<NUM_RGSTRD_CARRYING_CAPACITY>2</NUM_RGSTRD_CARRYING_CAPACITY>
		<NUM_IEV_BASE_VALUE>0</NUM_IEV_BASE_VALUE>
		<NUM_IEV_TRAILER_VALUE>0</NUM_IEV_TRAILER_VALUE>
		<TXT_RTA_DESC></TXT_RTA_DESC>
		<TXT_VEHICLE_ZONE></TXT_VEHICLE_ZONE>
		<NUM_IEV_ELEC_ACC_VALUE>0</NUM_IEV_ELEC_ACC_VALUE>
		<ELECTRICALACCESSORIESPREM>0</ELECTRICALACCESSORIESPREM>
		<TXT_ELEC_DESC></TXT_ELEC_DESC>
		<NUM_IEV_NON_ELEC_ACC_VALUE>0</NUM_IEV_NON_ELEC_ACC_VALUE>
		<NONELECTRICALACCESSORIESPREM>0</NONELECTRICALACCESSORIESPREM>
		<TXT_NON_ELEC_DESC></TXT_NON_ELEC_DESC>
		<NUM_IEV_SIDECAR_VALUE>0</NUM_IEV_SIDECAR_VALUE>
		<NUM_NUMBER_OF_TRAILERS>0</NUM_NUMBER_OF_TRAILERS>
		<NUM_IEV_FIBRE_TANK_VALUE>0</NUM_IEV_FIBRE_TANK_VALUE>
		<YN_INBUILT_CNG>0</YN_INBUILT_CNG>
		<NUM_IEV_CNG_VALUE>0</NUM_IEV_CNG_VALUE>
		<YN_INBUILT_LPG>0</YN_INBUILT_LPG>
		<NUM_IEV_LPG_VALUE></NUM_IEV_LPG_VALUE>  
		<BIFUELKITODPREMIUM>0</BIFUELKITODPREMIUM>
		<BIFUELKITTPPREMIUM>0</BIFUELKITTPPREMIUM>
		<NUM_FINANCIER_NAME_1></NUM_FINANCIER_NAME_1>
		<NUM_FINANCIER_NAME_2></NUM_FINANCIER_NAME_2>
		<TXT_FIN_ACCOUNT_CODE_1></TXT_FIN_ACCOUNT_CODE_1>
		<TXT_FIN_ACCOUNT_CODE_2></TXT_FIN_ACCOUNT_CODE_2>
		<TXT_FIN_BRANCH_NAME_1></TXT_FIN_BRANCH_NAME_1>
		<TXT_FIN_BRANCH_NAME_2></TXT_FIN_BRANCH_NAME_2>
		<NUM_AGREEMENT_NAME_1></NUM_AGREEMENT_NAME_1>
		<NUM_AGREEMENT_NAME_2></NUM_AGREEMENT_NAME_2>
		<TXT_FINANCIER_BRANCH_ADDRESS1></TXT_FINANCIER_BRANCH_ADDRESS1>
		<TXT_FINANCIER_BRANCH_ADDRESS2></TXT_FINANCIER_BRANCH_ADDRESS2>
		<NUM_SPECIAL_DISCOUNT_RATE>0</NUM_SPECIAL_DISCOUNT_RATE>
		<TXT_AA_FLAG></TXT_AA_FLAG>
		<TXT_AA_MEMBERSHIP_NUMBER></TXT_AA_MEMBERSHIP_NUMBER>
		<DAT_AA_EXPIRY_DATE></DAT_AA_EXPIRY_DATE>
		<TXT_AA_MEMBERSHIP_NAME></TXT_AA_MEMBERSHIP_NAME>
		<TXT_MEMBERSHIP_CODE></TXT_MEMBERSHIP_CODE>
		<TXT_AA_DISC_PREM></TXT_AA_DISC_PREM>
		<NUM_VOLUNTARY_EXCESS_AMOUNT>0</NUM_VOLUNTARY_EXCESS_AMOUNT>
		<NUM_COMPULSORY_EXCESS_AMOUNT>0</NUM_COMPULSORY_EXCESS_AMOUNT>
		<NUM_IMPOSED_EXCESS_AMOUNT>0</NUM_IMPOSED_EXCESS_AMOUNT>
		<NUM_TPPD_AMOUNT>100000</NUM_TPPD_AMOUNT>
		<NUM_LL1>0</NUM_LL1>
		<NUM_LL2></NUM_LL2>
		<NUM_LL3></NUM_LL3>
		<NUM_NO_OF_NAMED_DRIVERS></NUM_NO_OF_NAMED_DRIVERS>
		<NUM_LD_CLEANER_CONDUCTOR>0</NUM_LD_CLEANER_CONDUCTOR>
		<NUM_GEOGRAPHICAL_EXTN_PREM>0</NUM_GEOGRAPHICAL_EXTN_PREM>
		<TXT_GEOG_AREA_EXTN_COUNTRY>NoExtn</TXT_GEOG_AREA_EXTN_COUNTRY>
		<YN_HANDICAPPED>0</YN_HANDICAPPED>
		<YN_FOREIGN_EMBASSY>0</YN_FOREIGN_EMBASSY>
		<YN_LIMITED_TO_OWN_PREMISES>0</YN_LIMITED_TO_OWN_PREMISES>
		<YN_DRIVING_TUTION>0</YN_DRIVING_TUTION>
		<YN_ANTI_THEFT>0</YN_ANTI_THEFT>
		<YN_NIL_DEPR_WITHOUT_EXCESS>0</YN_NIL_DEPR_WITHOUT_EXCESS>
		<YN_RTI_APPLICABLE>0</YN_RTI_APPLICABLE>
		<YN_PERSONAL_EFFECT>0</YN_PERSONAL_EFFECT>
		<YN_COURTESY_CAR>0</YN_COURTESY_CAR>
		<NUM_DAYS_COVER_FOR_COURTESY>0</NUM_DAYS_COVER_FOR_COURTESY>
		<YN_MEDICLE_EXPENSE>0</YN_MEDICLE_EXPENSE>
		<TXT_MEDICLE_COVER_LIMIT></TXT_MEDICLE_COVER_LIMIT>
		<NUM_PILION_RIDER_PREMIUM></NUM_PILION_RIDER_PREMIUM>
		<NUM_PA_NAMED_NUMBER>0</NUM_PA_NAMED_NUMBER>
		<NUM_PA_NAMED_AMOUNT></NUM_PA_NAMED_AMOUNT>
		<NUM_PA_NAME1_AMOUNT></NUM_PA_NAME1_AMOUNT>
		<TXT_PA_NAME1></TXT_PA_NAME1>
		<TXT_NAMED_PA_NOMINEE1></TXT_NAMED_PA_NOMINEE1>
		<NUM_PA_NAME2_AMOUNT></NUM_PA_NAME2_AMOUNT>
		<TXT_PA_NAME2></TXT_PA_NAME2>
		<TXT_NAMED_PA_NOMINEE2></TXT_NAMED_PA_NOMINEE2>
		<NUM_PA_NAME3_AMOUNT></NUM_PA_NAME3_AMOUNT>
		<TXT_PA_NAME3></TXT_PA_NAME3>
		<TXT_NAMED_PA_NOMINEE3></TXT_NAMED_PA_NOMINEE3>
		<NUM_PA_NAME4_AMOUNT></NUM_PA_NAME4_AMOUNT>
		<TXT_PA_NAME4></TXT_PA_NAME4>
		<TXT_NAMED_PA_NOMINEE4></TXT_NAMED_PA_NOMINEE4>
		<NUM_PA_NAME5_AMOUNT></NUM_PA_NAME5_AMOUNT>
		<TXT_PA_NAME5></TXT_PA_NAME5>
		<TXT_NAMED_PA_NOMINEE5></TXT_NAMED_PA_NOMINEE5>
		<NUM_PA_NAME6_AMOUNT></NUM_PA_NAME6_AMOUNT>
		<TXT_PA_NAME6></TXT_PA_NAME6>
		<TXT_NAMED_PA_NOMINEE6></TXT_NAMED_PA_NOMINEE6>
		<NUM_PA_NAME7_AMOUNT></NUM_PA_NAME7_AMOUNT>
		<TXT_PA_NAME7></TXT_PA_NAME7>
		<TXT_NAMED_PA_NOMINEE7></TXT_NAMED_PA_NOMINEE7>
		<NUM_PA_NAME8_AMOUNT></NUM_PA_NAME8_AMOUNT>
		<TXT_PA_NAME8></TXT_PA_NAME8>
		<TXT_NAMED_PA_NOMINEE8></TXT_NAMED_PA_NOMINEE8>
		<NUM_PA_UNNAMED_NUMBER></NUM_PA_UNNAMED_NUMBER>
		<NUM_PA_UNNAMED_AMOUNT></NUM_PA_UNNAMED_AMOUNT>
		<YN_COMPULSORY_PA_DTLS></YN_COMPULSORY_PA_DTLS>
		<TXT_DRIVING_LICENSE_NO></TXT_DRIVING_LICENSE_NO>
		<DAT_DRIVING_LICENSE_EXP_DATE></DAT_DRIVING_LICENSE_EXP_DATE>
		<TXT_LICENSE_ISSUING_AUTHORITY></TXT_LICENSE_ISSUING_AUTHORITY>
		<TXT_NAME_OF_NOMINEE></TXT_NAME_OF_NOMINEE>
		<TXT_RELATION_WITH_NOMINEE></TXT_RELATION_WITH_NOMINEE>
		<YN_DELETION_OF_IMT26></YN_DELETION_OF_IMT26>
		<YN_IMT32></YN_IMT32>
		<YN_COMMERCIAL_FOR_PRIVATE>0</YN_COMMERCIAL_FOR_PRIVATE>
		<ADDONISNCBPROTECTION>0</ADDONISNCBPROTECTION>        
		<NCBPROTECTIONPREMIUM>0</NCBPROTECTIONPREMIUM>        
		<ADDONIsConsumable>0</ADDONIsConsumable>              
		<CONSUMABLESPREMIUM>0</CONSUMABLESPREMIUM>             
		<ADDONIsEngineProtection>0</ADDONIsEngineProtection>   
		<engineprotectionpremium>0</engineprotectionpremium>   
		<ADDONIsInvoiceCover>0</ADDONIsInvoiceCover>          
		<InvoiceCoverPremium>0</InvoiceCoverPremium>        
		<ADDONIsRoadSideAssistance>0</ADDONIsRoadSideAssistance>
		<RoadSideAssistancePremium>0</RoadSideAssistancePremium>
		<BasicODPremium></BasicODPremium>
		<ODDiscount></ODDiscount>
		<TotalAddOnPremium></TotalAddOnPremium>
		<PAODPremium></PAODPremium>
		<BasicTPPremium></BasicTPPremium>
		<PassengerCoverPremium></PassengerCoverPremium>
        <CUR_DEALER_NET_OD_PREM>0</CUR_DEALER_NET_OD_PREM>
        <CUR_DEALER_NET_TP_PREM></CUR_DEALER_NET_TP_PREM>
		<CUR_DEALER_SERVICE_TAX></CUR_DEALER_SERVICE_TAX>
		<CUR_DEALER_GROSS_PREM></CUR_DEALER_GROSS_PREM>
		<TXT_PAYMENT_MODE>CC</TXT_PAYMENT_MODE>
		<TXT_UTR_NUMBER></TXT_UTR_NUMBER>
		<DAT_UTR_DATE></DAT_UTR_DATE>
		<NUM_UTR_PAYMENT_AMOUNT></NUM_UTR_PAYMENT_AMOUNT>
		<TXT_MERCHANT_ID>UIIINSTINS</TXT_MERCHANT_ID>
		<TXT_BANK_CODE></TXT_BANK_CODE>
		<TXT_BANK_NAME></TXT_BANK_NAME>
		<CUST_GST_STATE_CODE></CUST_GST_STATE_CODE>
		<INS_OFF_GST_STATE_CODE></INS_OFF_GST_STATE_CODE>
		<INS_OFF_CODE></INS_OFF_CODE>
		<TXT_GSTIN_NUMBER></TXT_GSTIN_NUMBER>
		<OEM_CUR_SGST_VALUE></OEM_CUR_SGST_VALUE>
		<OEM_NUM_SGST_RATE></OEM_NUM_SGST_RATE>
		<OEM_CUR_UGST_VALUE></OEM_CUR_UGST_VALUE>
		<OEM_NUM_UGST_RATE></OEM_NUM_UGST_RATE>
		<OEM_CUR_CGST_VALUE></OEM_CUR_CGST_VALUE>
		<OEM_NUM_CGST_RATE></OEM_NUM_CGST_RATE>
		<OEM_CUR_IGST_VALUE></OEM_CUR_IGST_VALUE>
		<OEM_NUM_IGST_RATE></OEM_NUM_IGST_RATE>
	   <TXT_AADHAR_NUMBER></TXT_AADHAR_NUMBER>
		<TXT_ENROLLMENT_NO></TXT_ENROLLMENT_NO>
		<DAT_ENROLEMENT_DATE></DAT_ENROLEMENT_DATE>
	</HEADER>
</ROOT>";
		
		foreach ($req_arr as $xml_key => $xml_value) {
			$quote_req_str= str_replace(
					"<". $xml_key ."></". $xml_key .">",
					"<". $xml_key .">". $xml_value ."</". $xml_key .">",
					$quote_req_str
					);
		}
		return $quote_req_str;
	} // end of method.

	private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}
	
}
