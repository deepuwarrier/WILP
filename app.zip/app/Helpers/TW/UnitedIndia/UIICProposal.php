<?php
namespace App\Helpers\TW\UnitedIndia;
								
 use App\Models\TW\TwUsrData;
 use App\Models\TW\TwODRates;
 use App\Models\TW\TwRTO;
 use Illuminate\Http\Request;
 use Illuminate\Support\Facades\Log;
use App\Libraries\TwLib;
use App\Libraries\InstaLib;
use App\Helpers\TW\InsurerData;
use App\Be\TW\TwQuoteBe;
			 
 class UIICProposal {
	 	
 	
public function validate_proposal_submit ( TwUsrData $usr_data ) {
	
	$proposal_errors = null;
	
	return $proposal_errors;
	
	$tw_lib = new TwLib();
	$policy_exp_date = $usr_data->policy_exp_date;  
	if( $tw_lib->date_isin_past( $policy_exp_date)) {
		$proposal_errors = "Your Policy Expired in Past. Please contact our support team to buy this Policy.";
	} 
 	 	return $proposal_errors;
 }//method
 
 public function validate_premium_submit ( TwUsrData $usr_data ) {
 	
 	$final_premium  = (int) $usr_data->total_premium ; 
 	$ele_acc_pre = 0;
 	$non_ele_acc_pre = 0;
 	
 	if ( $usr_data->ele_acc !== null ) {
 		$ele_acc_pre = $usr_data->ele_acc * 0.04;
 	}
 	if ( $usr_data->non_ele_acc !== null ) {
 		$od_rate_db = new TwODRates();
 		$rto_db = new TwRTO();
 		
 		$rto_data = $rto_db->rto_details($usr_data->rto_code);
 		$od_rate_data = $od_rate_db->od_rates($usr_data->tw_age, $usr_data->variant_cc, $rto_data->zone);    
 		
 		$non_ele_acc_pre = round(( $usr_data->non_ele_acc * $od_rate_data->od_rate) / 100);
 		
 	}
 	
 	return  $final_premium + $ele_acc_pre + $non_ele_acc_pre;
 	
 }//method
 
 // Post payment this method will prepare proposal request and initiate to UIIC server for policy number. 
 public function submit_policy( $tw_trans_code, $pgresp) {  
	//get usr data. 
 	$usr_db = new TwUsrData();
 	$policy_usr_data = $usr_db->get_by_tc($tw_trans_code);  
 	
	//get policy factory object. 
	$policy_factory = new UIIC_Policy_Factory();
	$policy_arr = $policy_factory->base_request_xmlarr();
	
	// now populate policy data with user data.
	$populated_policy_arr = $this->populate_policy_request($policy_usr_data, $policy_arr, $pgresp) ; 
	
	$policy_req_xml_str = $policy_factory->prepare_request($populated_policy_arr);
	$insta_lib = new InstaLib();
	$proposal_status['policy_date'] = $insta_lib->today_date_dMY();
	$proposal_status['policy_status'] = 'TS18';
	$proposal_status['trans_status'] = 'TS18';
	$usr_db->set_by_tc($tw_trans_code, $proposal_status);
	$policy_response = $this->call_submit_policy($tw_trans_code,$policy_req_xml_str);
	
	if( $policy_response !== null ) {
        return simplexml_load_string($policy_response->return);
	}else {return null;}
	
} // end of method. 

private function populate_policy_request ($usr_data , $policy_arr, $pgresp) {
	$tw_lib = new TwLib();
	$insurer_data = new InsurerData();
	$quote_be = new TwQuoteBe();
	
	//details
	$policy_arr["TXT_NAME_OF_MANUFACTURER"] = $insurer_data->insr_make("make_name", $usr_data->make_code);
	$policy_arr["TXT_OTHER_MAKE"] = $insurer_data->model_data("model_name", $usr_data->model_code);
	$policy_arr["TXT_VARIANT"] = $insurer_data->insr_variant("variant_name", $usr_data->variant_code);
	$policy_arr["TXT_RTA_DESC"] = $insurer_data->insr_rto("uiic_code", $usr_data->rto_code);
	$policy_arr["TXT_VEHICLE_ZONE"] = $insurer_data->insr_rto("zone", $usr_data->rto_code);
	$policy_arr["TXT_TYPE_BODY"] = $insurer_data->insr_variant("body_type", $usr_data->variant_code);
	
	//quote
	$policy_arr["NUM_POLICY_YEAR"] = $tw_lib->get_curr_year();
	$policy_arr["NUM_IEV_BASE_VALUE"] = $usr_data->opt_idv;
	$policy_arr["DAT_DATE_OF_ISSUE_OF_POLICY"] = $this->format_date( $usr_data->term_start_date);
	$policy_arr["DAT_DATE_OF_EXPIRY_OF_POLICY"] = $this->format_date( $usr_data->term_end_date);
	$policy_arr["DAT_PROPOSAL_DATE"] = $tw_lib->date_today("d/m/Y");
	$policy_arr["CUR_BONUS_MALUS_PERCENT"] = $usr_data->eli_ncb;
	$policy_arr["NOCLAIMBONUSDISCOUNT"] = $usr_data->ncb_disc_value;
	$policy_arr["DAT_DATE_OF_REGISTRATION"] = $this->format_date( $usr_data->tw_reg_date );
	$policy_arr["YN_NIL_DEPR_WITHOUT_EXCESS"] = $usr_data->addon_covers == 'ZRDP' ? '-1' : '0' ; 
	$policy_arr["NUM_SPECIAL_DISCOUNT_RATE"] = $quote_be->od_disc_rate( $usr_data->tw_age);
	
	$pa_premium = explode("|", $usr_data->addon_premium)[0];
	$addon_premium = explode("|", $usr_data->addon_premium)[1];
	
	$net_od_value = $usr_data->od_premium + $addon_premium - $usr_data->ncb_disc_value - $usr_data->od_disc_value;
	
	$net_tp_value = $usr_data->tp_premium + $pa_premium;
	
	
	$policy_arr["BasicODPremium"] =  $usr_data->od_premium ;
	$policy_arr["ODDiscount"] =  $usr_data->od_disc_value ;
	$policy_arr["TotalAddOnPremium"] =  $addon_premium;
	$policy_arr["PAODPremium"] =  $pa_premium;
	$policy_arr["BasicTPPremium"] =  $usr_data->tp_premium;
	$policy_arr["CUR_DEALER_NET_OD_PREM"] =  $net_od_value;
	$policy_arr["CUR_DEALER_NET_TP_PREM"] =  $net_tp_value;
	$policy_arr["CUR_DEALER_SERVICE_TAX"] =  $usr_data->total_tax;
	$policy_arr["CUR_DEALER_GROSS_PREM"] =  $usr_data->final_premium;
	
	
	//proposer
	$policy_arr["TXT_TITLE"] = $usr_data->proposer_gender == "M" ? "Mr" : "Ms";
	$policy_arr["TXT_GENDER"] = $usr_data->proposer_gender == "M" ? "Male" : "Female";
	$policy_arr["TXT_NAME_OF_INSURED"] = $usr_data->proposer_name;
	$policy_arr["TXT_DOB"] = $this->format_date($usr_data->proposer_dob);
	$policy_arr["TXT_EMAIL_ADDRESS"] = $usr_data->proposer_email;
	$policy_arr["TXT_MOBILE"] = $usr_data->proposer_mobile;
	$policy_arr["TXT_TELEPHONE"] = $usr_data->proposer_mobile;
	$policy_arr["TXT_AADHAR_NUMBER"] = str_replace("-","", $usr_data->proposer_aadharno);
	
	//address
	$policy_arr["MEM_ADDRESS_OF_INSURED"] = $usr_data->proposer_addr1 ." ".$usr_data->proposer_addr2." ".$usr_data->proposer_addr3;
	$policy_arr["NUM_PIN_CODE"] = $usr_data->proposer_pincode;
	
	
	//vechicle
	$policy_arr["TXT_ENGINE_NUMBER"] = $usr_data->tw_engine_no;
	$policy_arr["TXT_CHASSIS_NUMBER"] = $usr_data->tw_chassis_no;
	$policy_arr["NUM_CUBIC_CAPACITY"] = $usr_data->variant_cc;
	$policy_arr["TXT_VAHICLE_COLOR"] = $usr_data->color;
	$policy_arr["NUM_YEAR_OF_MANUFACTURE"] = $usr_data->yom;
	
	$tw_no_arr = explode("-",$usr_data->tw_reg_no);   
	$policy_arr["TXT_REGISTRATION_NUMBER_1"] = $tw_no_arr["0"];
	$policy_arr["TXT_REGISTRATION_NUMBER_2"] = $tw_no_arr["1"];
	$policy_arr["TXT_REGISTRATION_NUMBER_3"] = $tw_no_arr["2"];
	$policy_arr["TXT_REGISTRATION_NUMBER_4"] = $tw_no_arr["3"];
	

	//pre insur
	$policy_arr["TXT_PREV_INSURER_CODE"] = $insurer_data->insr_preinsr("uiic_code", $usr_data->pre_insurer_code);
	$policy_arr["TXT_PREVIOUS_INSURER"] = $insurer_data->insr_preinsr("preinsr_name", $usr_data->pre_insurer_code);
	$policy_arr["NUM_POLICY_NUMBER"] = $usr_data->pre_policy_number;
	$policy_arr["TXT_PREV_POL_EFFECTIVE_DATE"] = $this->format_date( $usr_data->policy_start_date);
	$policy_arr["DAT_PREV_POLICY_EXPIRY_DATE"] = $this->format_date( $usr_data->policy_exp_date);
	$policy_arr["YN_CLAIM"] = $usr_data->pre_claim_status == "Yes" ? "" : "No";
	$policy_arr["TXT_NAME_OF_NOMINEE"] = $usr_data->nomi_name ;
	$policy_arr["TXT_RELATION_WITH_NOMINEE"] = $insurer_data->nomrel_data( "uiic_code", $usr_data->nomi_rel_code );
	
	// pg values
	$policy_arr["TXT_OEM_TRANSACTION_ID"] = $pgresp["TxnReferenceNo"];
	$policy_arr["TXT_PAYMENT_MODE"] = "CC";
	$policy_arr["TXT_UTR_NUMBER"] = $pgresp["BankMerchantID"];
	$policy_arr["DAT_UTR_DATE"] =   $this->format_date( explode(" ", $pgresp["TxnDate"])[0]);
// 	$policy_arr["NUM_UTR_PAYMENT_AMOUNT"] = $pgresp["TxnAmount"];
	$policy_arr["NUM_UTR_PAYMENT_AMOUNT"] = $usr_data->final_premium .".00";
	$policy_arr["TXT_BANK_CODE"] = $pgresp["BankID"];
	$policy_arr["TXT_BANK_NAME"] = "";
	
	//gst values to populate
	$customer_gst_code = $insurer_data->insr_state("gst_code", $usr_data->proposer_state_code);
	$policy_arr["CUST_GST_STATE_CODE"] = $customer_gst_code;     
	$policy_arr["INS_OFF_GST_STATE_CODE"] = "29";  // 29 is for karnataka.   
	$policy_arr["INS_OFF_CODE"] = "072300";					
	$policy_arr["TXT_GSTIN_NUMBER"] = "";
	if($usr_data->proposer_state_code == "II0017") {
		$policy_arr["OEM_NUM_SGST_RATE"] = "9";
		$policy_arr["OEM_CUR_SGST_VALUE"] = $this->get_sgst($usr_data->total_tax);
		$policy_arr["OEM_NUM_CGST_RATE"] = "9";
		$policy_arr["OEM_CUR_CGST_VALUE"] =  $this->get_cgst($usr_data->total_tax);
	}else{
			$policy_arr["OEM_NUM_IGST_RATE"] = "18";
			$policy_arr["OEM_CUR_IGST_VALUE"] = $usr_data->total_tax;
	}
	return $policy_arr;
}

private function get_sgst($total_tax) { return round($total_tax/2);}
private function get_cgst($total_tax) { return round($total_tax/2);}

private function format_date($dt) { 	return date("d/m/Y", strtotime($dt));	}

private function call_submit_policy($tw_trans_code, $policy_req_str) {   
	$usr_db = new TwUsrData();
	$insta_lib = new InstaLib();
	$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
	$proposal_status['proposal_status'] = 'TS14';
	$proposal_status['trans_status'] = 'TS14';
	$usr_db->set_by_tc($tw_trans_code, $proposal_status);

	Log::info("TW UIIC Policy Request : ". $policy_req_str);

 		$wsdlurl = "https://portal.uiic.in/uiic/UGenericService/UInstaService?wsdl";      // this is produciton.
	$api_resp = null;
	try {
		$client = new \SoapClient($wsdlurl) ;
		$params = array('application'=>'INSTAINS','userid'=> 'INSTAINS','password'=>'uiic','productCode'=>'3112','subproductCode'=> '3','proposalXml'=> $policy_req_str );
		$api_resp = $client->policyInfoOffXml($params); 
		
	}catch (Exeception $ex) {	return null;} 
	Log::info("TW_UIIC_Policy_Response : ". print_r( $api_resp->return, true));
	
	return $api_resp;
}
 
} // end of class
