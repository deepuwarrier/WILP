<?php
namespace App\Helpers\TW\UnitedIndia;
			
 use App\Models\TW\data\QuoteRespData;
use App\Models\TW\TwUsrData;
use App\Be\TW\TwQuoteBe;
use App\Models\TW\TwIdvRate;
use App\Models\TW\TwODRates;
use App\Models\TW\TwRTO;
use App\Models\TW\TwConfig;
use App\Models\TW\data\QuoteReqData;
use Illuminate\Support\Facades\Log;
								
 class UIICQuoteManager {
 
 	public function get_quotes(QuoteReqData $quote_req_data){	      
 		
	$resp_data = new QuoteRespData();
	$ssn_key = $quote_req_data->get_ssn_key();
	$resp_data->_insurer_code("IITW002");
	$resp_data->_insurer_logo("uiicgi_logo.png");
	$resp_data->_insurer_name("United India GI");
	$resp_data->_proposal_url("two-wheeler-insurance/unitedindia");
	
	$resp_data->_tp_value($this->calc_tp( $ssn_key));
	$resp_data->_pa_value($this->calc_pa());
	$resp_data->_idv($this->calc_idv( $ssn_key));
	$resp_data->_od_value($this->calc_od( $ssn_key, $resp_data->idv() ));
	$resp_data->_od_disc($this->calc_od_disc( $ssn_key, $resp_data->od_value()));
	$resp_data->_ncb_value(  $quote_req_data->get_claim_status() == 'N' ? $this->calc_ncb($ssn_key, $resp_data->od_value(), $resp_data->od_disc())  : 0 );
	
	
	$resp_data->_addon_zrdp(  $quote_req_data->get_add_on_zrdp() === true  ?  $this->calc_zrdp_addon( $ssn_key, $resp_data->od_value() ) : 0 );
	
	$rtin_calc = $quote_req_data->get_add_on_rtin() ?  $this->calc_rtin_addon( $ssn_key, $resp_data->od_value() ) : 0 ;   //dd( $rtin_calc);
	if( $rtin_calc == -1 ) { $resp_data->_addon_flag(false); }
	else { $resp_data->_addon_rtin($rtin_calc);}
	
// 	dd($resp_data->addon_flag() );
	
	if(  $quote_req_data->get_add_on_cnsm() || $quote_req_data->get_add_on_ncbp() || $quote_req_data->get_add_on_rsac() ) {
		$resp_data->_addon_flag(false);
	} 
	
	$base_premium = $resp_data->od_value() + $resp_data->tp_value() + $resp_data->pa_value() + $resp_data->addon_zrdp() + $resp_data->addon_cnsm() + $resp_data->addon_ncbp() + $resp_data->addon_rsac() + $resp_data->addon_rtin();
	$gross_premium = $base_premium -  ( $resp_data->ncb_value() +$resp_data->od_disc());
	$gs_tax = round  ($gross_premium * 0.18);  
	$final_premium = $gross_premium + $gs_tax;
	
	$resp_data->_service_tax($gs_tax);
	$resp_data->_final_premium($final_premium);
	
	return $resp_data;
}

private function calc_od_disc( $ssn_key, $od_value) {
	$usrtdb = new TwUsrData();
	$config_db = new TwConfig();
	$usrdata = $usrtdb->getValue($ssn_key);
	$vehicle_age = $usrdata->tw_age;
	$od_disc_rate = 0;
	$od_disc_rate_arr = explode("|", $config_db->getValue("UIIC_OD_DISC_RATE")->config_value);
	Log::info("xxx ". print_r( $od_disc_rate_arr, true));
	
	if($vehicle_age <= 2) { $od_disc_rate = $od_disc_rate_arr[0]; }
	if($vehicle_age > 2 && $vehicle_age <= 5) { $od_disc_rate = $od_disc_rate_arr[1];}
	if($vehicle_age > 5) { $od_disc_rate = $od_disc_rate_arr[2]; }
	  
	return ( $od_value * $od_disc_rate) / 100 ;
}

private function calc_od ($ssn_key, $idv_value) {
	$usrtdb = new TwUsrData();
	$od_rate_db = new TwODRates();
	$rto_db = new TwRTO();
	
	$usrdata = $usrtdb->getValue($ssn_key);
	$rto_data = $rto_db->rto_details($usrdata->rto_code);
	$od_rate_data = $od_rate_db->od_rates($usrdata->tw_age, $usrdata->variant_cc, $rto_data->zone);    
	return ($idv_value * $od_rate_data->od_rate) / 100;
}

private function calc_tp ($ssn_key) {
	$usrtdb = new TwUsrData();
	$usrdata = $usrtdb->getValue($ssn_key);
	$tw_cc = $usrdata->variant_cc;
	if ($tw_cc <= 75) {	return 569;	}
	if ( $tw_cc > 75 && $tw_cc <= 150) {	return 720;	}
	if ( $tw_cc > 150 && $tw_cc <= 350) {	return 887;	}
	if ($tw_cc > 350) {	return 1019;	}
	return 0;
}

private function calc_pa() {
	return 50;
}

private function calc_idv( $session_key ){
	$usrtdb = new TwUsrData();
	$tw_quote_be = new TwQuoteBe();
	$usrdata = $usrtdb->getValue($session_key);
	
	$idv_value =(( $usrdata->variant_price * $this->idv_rate_uiic($usrdata->tw_age) )/ 100 ) ;
	return intval(round( $idv_value ));
}

private function calc_ncb( $session_key, $od_value, $od_disc ){
	
	$tw_quote_be = new TwQuoteBe();
	$usrtdb = new TwUsrData();
	$od_after_oddisc = $od_value - $od_disc;
	$usrdata = $usrtdb->getValue($session_key);
	$ele_ncb_rate = (int) $usrdata->eli_ncb;
	
	return round( ( $od_after_oddisc * $ele_ncb_rate) / 100  );
}

private function idv_rate_uiic($age) {
	$db = new TwIdvRate();
	$idv_rate =  $db->idv_rate_uiic($age);  
	return $idv_rate->uiic_rate;
}

private function calc_zrdp_addon( $ssn_key, $odvalue ) {  
	$zrdp_value = 0;
	$usrtdb = new TwUsrData(); $usrdata = $usrtdb->getValue($ssn_key); $vehicle_age = $usrdata->tw_age;  
	$zrdp_rate = 10;
	if($vehicle_age == 1) { $zrdp_rate = 10; }
	if($vehicle_age == 2) { $zrdp_rate = 20; }
	if($vehicle_age > 2 && $vehicle_age <= 5) { $zrdp_rate = 30; }
	
	$zrdp_value = ($odvalue * $zrdp_rate) / 100;  

	return round ($zrdp_value);
}

private function calc_rtin_addon( $ssn_key, $odvalue) {
	$rtin_value = 0;
	$usrtdb = new TwUsrData(); $usrdata = $usrtdb->getValue($ssn_key); $vehicle_age= $usrdata->tw_age;
	if ($vehicle_age > 3) {return -1;}
	
	$rtin_rate = 0;
	if( $vehicle_age == 0 || $vehicle_age == 1) { $rtin_rate= 15; }
	if($vehicle_age == 2) { $rtin_rate= 20; }
	if($vehicle_age > 2 && $vehicle_age <= 3) { $rtin_rate= 25; }
	
	$rtin_value= ($odvalue* $rtin_rate) / 100;    
	return round( $rtin_value) ;
}

}
