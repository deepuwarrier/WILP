<?php
namespace App\Http\Controllers\Admin;

use App\Be\Common\AuthBe;
use App\Http\Controllers\Controller;

class AdminCntlr extends Controller
{
    
    public function load_dashboard(){ 
        $user_code = !empty(session('user_code'))?session('user_code'):NULL;
        return view('admin/_dashboard');
        
    }
    
    public function logout(){
    		$auth_be = new AuthBe();
    		$auth_be->execute_logout();
    		return redirect("/login");
    }
    
    
}
