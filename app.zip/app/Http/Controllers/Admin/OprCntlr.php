<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Be\Admin\AdminReportsBe;
use Illuminate\Http\Request;
use App\Libraries\CommonLib;
use App\Be\Admin\AdminOprBe;
use App\Helpers\Car\CarHelper;
use App\Models\Car as M;
use App\Models\Car\Data\PolicyPDFData;
use App\Helpers\Car\UIIC\UIICProposalManager;
use App\Helpers\Car\UIIC\UIICRequest;
use App\Models\Car\MasterNomineeRelationship;
use App\Libraries\CarLib;
use App\Models\Car\CarVariant;
use App\Libraries\TwLib;
use App\Models\TW\TwUsrData;
use App\Helpers\TW\InsurerData;


class OprCntlr extends Controller
{
    
	public function generateSchedule (Request $request)  { 
		$params = $request->all();
        $reports_be = new AdminReportsBe();
        $filter_list = $reports_be->get_filter_map();
		return view('admin/opr_policy_sche',[ 'filter_list'=> $filter_list, 'policy_list' => null ]);     
    }

    public function downloadPolicySchedule(Request $request){
        $params = $request->all();
        $product = $params['product'];
        $company = $params['company'];
        return  call_user_func_array([$this,'down'.$product.'Schedule'], [$params]);
    }


    public function downPCSchedule($params){
        switch ($params['company']) {
            case 'UIIC':
                return $this->pc_uiic_schedule($params['policy_number']);
                break;
            
            default:
                # code...
                break;
        }
    }

    public function downTWSchedule($params){
        switch ($params['company']) {
            case 'UIIC':
                return $this->tw_uiic_schedule($params['policy_number']);
                break;
            
            default:
                # code...
                break;
        }
    }

    public function downTWTPSchedule($params){
        switch ($params['company']) {
            case 'UIIC':
                return $this->twtp_uiic_schedule($params['policy_number']);
                break;
            
            default:
                # code...
                break;
        }
    }

    private function tw_uiic_schedule ($policy_no)  {  
              
        $usr_db = new TwUsrData();
        $tw_lib = new TwLib();
        $usr_data = $usr_db->values_by_policyno($policy_no); 
        
        if($usr_data == null) {
            return "<br> Policy Does Not Exists in Policy Database.";
        }
        $insur_db = new InsurerData();
        $pdf_data = new PolicyPDFData();
        
        $pdf_data->set_broker_code("BRC0000702");
        $pdf_data->set_policy_number($usr_data->policy_number);
        

        $pdf_data->set_proposer_name($usr_data->proposer_name);

        $pdf_data->set_policy_start_date($usr_data->term_start_date);
        $pdf_data->set_policy_end_date($usr_data->term_end_date);

        $pdf_data->set_make_name($insur_db->insr_make("make_name", $usr_data->make_code));
        $pdf_data->set_model_name($insur_db->model_data("model_name", $usr_data->model_code));
        $pdf_data->set_reg_city_name($insur_db->insr_city("city_name", $usr_data["proposer_city_code"]));
        $pdf_data->set_reg_state_name($insur_db->insr_state("state_name", $usr_data["proposer_state_code"]));
        $pdf_data->set_net_premium_words($tw_lib->spell_amount( $usr_data["final_premium"]));
        $pdf_data->set_rto_location($insur_db->insr_rto("rto", $usr_data->rto_code));
        $pdf_data->set_rto_code($usr_data->rto_code);
        
        $pdf_data->set_nomine_age($usr_data->nomi_age);
        $pdf_data->set_nomine_relationship($insur_db->nomrel_data("nomrel_name", $usr_data->nomi_rel_code));
        

        $pdf_data->set_od_disc_value($usr_data->od_disc_value);
        
        $cover_value_arr = explode("|", $usr_data->addon_premium);
        
        if($cover_value_arr[0] != 0){
            $pdf_data->set_pa_to_od_status(true);
            $pdf_data->set_pa_to_od_value($cover_value_arr[0]);
        }
        $pdf_data->set_ll_to_pd_status(false);
    
        if($cover_value_arr[1] != 0){
            $pdf_data->set_zerodept_status(true);                     // Need to check for Zero Dept
            $pdf_data->set_zerodept_value($cover_value_arr[1]);
        }
        
        $pdf_data->set_od_value($usr_data->od_premium);
        $pdf_data->set_eli_ncb_value($usr_data->ncb_disc_value);
        $pdf_data->set_eli_ncb_rate($usr_data->eli_ncb);
        $pdf_data->set_gross_od_value(
                $pdf_data->get_od_value() + $pdf_data->get_zerodept_value() - $pdf_data->get_eli_ncb_value() - $pdf_data->get_od_disc_value()
                );
        
        $pdf_data->set_pa_to_pass_status(false);
        $pdf_data->set_pa_to_pass_value(0);
        
        
        $pdf_data->set_tp_value($usr_data->tp_premium );
        $pdf_data->set_gross_tp_value($pdf_data->get_tp_value() + $pdf_data->get_pa_to_od_value());
        
        $pdf_data->set_reg_number($usr_data->tw_reg_no);
        $pdf_data->set_reg_addr($usr_data->proposer_addr1.','.$usr_data->proposer_addr2.','.$usr_data->proposer_addr2);
        $pdf_data->set_reg_pincode($usr_data->proposer_pincode);
        $pdf_data->set_proposer_mobile($usr_data->proposer_mobile);
        $pdf_data->set_policy_issue_date($usr_data->policy_date);

        if ($usr_data->opt_idv)
            $pdf_data->set_idv_value($usr_data->opt_idv);
        else
            $pdf_data->set_idv_value($usr_data->calc_idv);
        $pdf_data->set_engine_no($usr_data->tw_engine_no);
        $pdf_data->set_chassis_no($usr_data->tw_chassis_no);
        $pdf_data->set_yom($usr_data->yom);
        $pdf_data->set_reg_date($usr_data->tw_reg_date);
        $pdf_data->set_variant_cc($usr_data->variant_cc);
        $pdf_data->set_gross_premium($usr_data->gross_total_premium);
        $pdf_data->set_gst_value($usr_data->total_tax);
        $pdf_data->set_net_premium($usr_data->final_premium);
        $pdf_data->set_pg_reference_no($usr_data->pg_refno);
        $pdf_data->set_propoers_email($usr_data->proposer_email);
        $pdf_data->set_nomine_name($usr_data->nomi_name);

        $xpdf = \PDF::loadView('tw.policy.unitedindia.policy_pdf', compact("pdf_data"));
        return $xpdf->download("TW_UIIC_". $pdf_data->get_reg_number().".pdf");
    }

    private function twtp_uiic_schedule ($policy_no)  {  
              
        $usr_db = new TwUsrData();
        $tw_lib = new TwLib();
        $usr_data = $usr_db->values_by_policyno($policy_no); 
        
        if($usr_data == null) {
            return "<br> Policy Does Not Exists in Policy Database.";
        }
        $insur_db = new InsurerData();
        $pdf_data = new PolicyPDFData();
        
        $pdf_data->set_broker_code("BRC0000702");
        $pdf_data->set_policy_number($usr_data->policy_number);
        

        $pdf_data->set_proposer_name($usr_data->proposer_name);

        $pdf_data->set_policy_start_date($usr_data->term_start_date);
        $pdf_data->set_policy_end_date($usr_data->term_end_date);

        $pdf_data->set_make_name($insur_db->insr_make("make_name", $usr_data->make_code));
        $pdf_data->set_model_name($insur_db->model_data("model_name", $usr_data->model_code));
        $pdf_data->set_reg_city_name($insur_db->insr_city("city_name", $usr_data["proposer_city_code"]));
        $pdf_data->set_reg_state_name($insur_db->insr_state("state_name", $usr_data["proposer_state_code"]));
        $pdf_data->set_net_premium_words($tw_lib->spell_amount( $usr_data["final_premium"]));
        $pdf_data->set_rto_location($insur_db->insr_rto("rto", $usr_data->rto_code));
        $pdf_data->set_rto_code($usr_data->rto_code);
        
        $pdf_data->set_nomine_age($usr_data->nomi_age);
        $pdf_data->set_nomine_relationship($insur_db->nomrel_data("nomrel_name", $usr_data->nomi_rel_code));
        

        $pdf_data->set_od_disc_value($usr_data->od_disc_value);
        
        $cover_value_arr = explode("|", $usr_data->addon_premium);
        
        if($cover_value_arr[0] != 0){
            $pdf_data->set_pa_to_od_status(true);
            $pdf_data->set_pa_to_od_value($cover_value_arr[0]);
        }
        $pdf_data->set_ll_to_pd_status(false);
    
        if($cover_value_arr[1] != 0){
            $pdf_data->set_zerodept_status(true);                     // Need to check for Zero Dept
            $pdf_data->set_zerodept_value($cover_value_arr[1]);
        }
        
        $pdf_data->set_od_value($usr_data->od_premium);
        $pdf_data->set_eli_ncb_value($usr_data->ncb_disc_value);
        $pdf_data->set_eli_ncb_rate($usr_data->eli_ncb);
        $pdf_data->set_gross_od_value(
                $pdf_data->get_od_value() + $pdf_data->get_zerodept_value() - $pdf_data->get_eli_ncb_value() - $pdf_data->get_od_disc_value()
                );
        
        $pdf_data->set_pa_to_pass_status(false);
        $pdf_data->set_pa_to_pass_value(0);
        
        
        $pdf_data->set_tp_value($usr_data->tp_premium );
        $pdf_data->set_gross_tp_value($pdf_data->get_tp_value() + $pdf_data->get_pa_to_od_value());
        
        $pdf_data->set_reg_number($usr_data->tw_reg_no);
        $pdf_data->set_reg_addr($usr_data->proposer_addr1.','.$usr_data->proposer_addr2.','.$usr_data->proposer_addr2);
        $pdf_data->set_reg_pincode($usr_data->proposer_pincode);
        $pdf_data->set_proposer_mobile($usr_data->proposer_mobile);
        $pdf_data->set_policy_issue_date($usr_data->policy_date);

        if ($usr_data->opt_idv)
            $pdf_data->set_idv_value($usr_data->opt_idv);
        else
            $pdf_data->set_idv_value($usr_data->calc_idv);
        $pdf_data->set_engine_no($usr_data->tw_engine_no);
        $pdf_data->set_chassis_no($usr_data->tw_chassis_no);
        $pdf_data->set_yom($usr_data->yom);
        $pdf_data->set_reg_date($usr_data->tw_reg_date);
        $pdf_data->set_variant_cc($usr_data->variant_cc);
        $pdf_data->set_gross_premium($usr_data->gross_total_premium);
        $pdf_data->set_gst_value($usr_data->total_tax);
        $pdf_data->set_net_premium($usr_data->final_premium);
        $pdf_data->set_pg_reference_no($usr_data->pg_refno);
        $pdf_data->set_propoers_email($usr_data->proposer_email);
        $pdf_data->set_nomine_name($usr_data->nomi_name);

        $xpdf = \PDF::loadView('tw.policy.unitedindia.policy_pdf', compact("pdf_data"));
        return $xpdf->download("TW_UIIC_". $pdf_data->get_reg_number().".pdf");
    }

    private function pc_uiic_schedule($policy_no){
        $proposal_man = new UIICProposalManager();
        $car_helper = new CarHelper;
        $car_rto = new M\CarRto;
        $user_data = M\CarTPolicy::where(['policy_nu' => $policy_no])
        ->orderBy('created_at', 'desc')->first();
        if (!isset($user_data))
            return '<p>Policy Not Found</p>';

        $suid = $user_data->trans_code; 
        $pdf_data = new PolicyPDFData();
        $user_data->policy_reciept_date = $car_helper->changeFormat($user_data->updated_at,'d-M-Y'); 
        $this->uiic_req = new UIICRequest($proposal_man);

        $this->uiic_req->setPolicyData($user_data);

        $quote = $this->uiic_req->quote_manger->quote_be->data;

        foreach ($quote as $key => $value)
            $user_data->$key = $value;

        $pdf_data->set_pre_policy_no($user_data->prev_policyno);
        $pdf_data->set_policy_number($user_data->policy_nu);
        $pdf_data->set_policy_issue_date($car_helper->changeFormat($user_data->payment_date, 'd-M-Y'));
        $pdf_data->set_reg_number(strtoupper($user_data->veh_reg_no));

        if ($user_data->idv_opted)
            $pdf_data->set_total_idv_value($user_data->idv_opted);
        else
            $pdf_data->set_total_idv_value($user_data->idv_calculated);

        $pdf_data->set_policy_start_date($user_data->getPolicyStartDate('d-M-Y'));
        $pdf_data->set_policy_end_date($user_data->getPolicyEndDate('d-M-Y'));

        if (strtoupper($user_data->usr_type) == 'O') {
            $pdf_data->set_proposer_name($user_data->usr_companyname);
        } else {
            $pdf_data->set_proposer_name($user_data->usr_firstname . ' ' . $user_data->usr_lastname);
        }

        $pdf_data->set_proposer_mobile($user_data->usr_mobile);
        $pdf_data->set_propoers_email($user_data->usr_email);
        $pdf_data->set_reg_addr($user_data->usr_houseno . ',' . $user_data->usr_street . ',' . $user_data->usr_locality);
        $pdf_data->set_reg_city_name($car_helper->getMasterName('City', $user_data->usr_city_code));
        $pdf_data->set_reg_state_name($car_helper->getMasterName('State', $user_data->usr_state_code));
        $pdf_data->set_reg_pincode($user_data->usr_pincode);
        $pdf_data->set_nomine_name($user_data->nominee_name);
        if ($user_data->nominee_age)
            $pdf_data->set_nomine_age($user_data->nominee_age);

        if ($user_data->nominee_rel) {
            $relDb = new MasterNomineeRelationship();
            $pdf_data->set_nomine_relationship($relDb->getName($user_data->nominee_rel));
        }

        $pdf_data->set_engine_no($user_data->veh_eng_no);
        $pdf_data->set_chassis_no($user_data->veh_chassisno);
        $pdf_data->set_make_name($user_data->make_name);
        $pdf_data->set_model_name($user_data->model_name);
        $pdf_data->set_yom($user_data->veh_yom);
        $pdf_data->set_reg_date($user_data->car_registration_date);
        $pdf_data->set_rto_code(strtoupper($user_data->car_rto));
        $pdf_data->set_rto_location($car_rto->getRtoName($user_data->car_rto));
        $pdf_data->set_body_type($car_helper->getMasterName('VehicleBody', $user_data->veh_bodytype));
        $pdf_data->set_broker_code("BRC0000702");
        // premium 
        $pdf_data->set_od_value($user_data->totoal_od_premium + $user_data->ncb_discount + $user_data->od_discount);
        $pdf_data->set_net_basic_od($user_data->totoal_od_premium + $user_data->ncb_discount);
        $pdf_data->set_tp_value($user_data->tp_premium);

        $variantDb = new CarVariant();
        $variantDb = $variantDb->getData($user_data->car_variant, ['seat_capacity', 'weight', 'variant_cc']);
        $pdf_data->set_seating_capacity($variantDb->seat_capacity);
        $pdf_data->set_variant_cc($variantDb->variant_cc);

        $pdf_data->set_gross_tp_value($user_data->totoal_tp_premium);
        $pdf_data->set_gross_od_value($user_data->totoal_od_premium + $user_data->totoal_addOn_premium);
        $pdf_data->set_od_disc_value($user_data->od_discount);
        $pdf_data->set_eli_ncb_rate($user_data->new_ncb);
        $pdf_data->set_eli_ncb_value($user_data->ncb_discount);

        if ($user_data->veh_electricle)
            $pdf_data->set_ea_value($user_data->veh_electricle);

        if ($user_data->veh_no_electricle)
            $pdf_data->set_nea_value($user_data->veh_no_electricle);

        if ($user_data->totoal_addOn_premium)
            $pdf_data->set_od_addon_status(true);

        if ($user_data->zerodep_premium) {
            $pdf_data->set_zerodept_status(true);
            $pdf_data->set_zerodept_value($user_data->zerodep_premium);
        }

        if ($user_data->rti_premium) {
            $pdf_data->set_rti_status(true);
            $pdf_data->set_rti_value($user_data->rti_premium);
        }

        if ($user_data->PAOD_premium) {
            $pdf_data->set_pa_to_od_status(true);
            $pdf_data->set_pa_to_od_value($user_data->PAOD_premium);
        } else {
            $pdf_data->set_pa_to_od_status(false);
        }

        if ($user_data->pa_cover_premium) {
            $pdf_data->set_pa_to_pass_status(true);
            $pdf_data->set_pa_to_pass_value($user_data->pa_cover_premium);
        }

        if ($user_data->driver_cover_premium) {
            $pdf_data->set_ll_to_pd_status(true);
            $pdf_data->set_ll_to_pd_value($user_data->driver_cover_premium);
        }

        $pdf_data->set_gross_premium($user_data->totoal_od_premium + $user_data->totoal_tp_premium + $user_data->totoal_addOn_premium);
        $pdf_data->set_gst_value($user_data->service_tax);
        $pdf_data->set_net_premium($user_data->total_premium);
        $pdf_data->set_pg_reference_no($user_data->transaction_id);
        $pdf_data->set_payment_date($car_helper->changeFormat($user_data->updated_at, 'd-M-Y'));

        $lib = new CarLib;
        $pdf_data->set_net_premium_words($lib->spell_amount($pdf_data->get_net_premium()));

        $pdf_data->set_idv_value($pdf_data->get_total_idv_value() - $pdf_data->get_ea_value() - $pdf_data->get_nea_value());

        $xpdf = \PDF::loadView('car.policy.policy_pdf', compact("pdf_data"));
        return $xpdf->download("PC_UIIC_" . $pdf_data->get_reg_number() . ".pdf");
    }
    
    public function premium_summary_report_xls (Request $request)  {
    	$params = $request->all();
    	$reports_be = new AdminReportsBe();
    	$filter_list = $reports_be->get_filter_map();
    	
    	if( ! isset($params["from_date_filter"] ) || $params["from_date_filter"] == null){
    		return view('admin/premium_summary_report',[ 'filter_list'=> $filter_list, 'policy_list' => null ]);
    	}
    	
    	$filter_param = array();
    	if( $params["branch_filter"] != "-1") { $filter_param["branch_code"] = $params["branch_filter"]; }
    	if( $params["product_filter"] != "-1") { $filter_param["module_name"] = $params["product_filter"]; }
    	if( $params["insurer_filter"] != "-1") { $filter_param["insurer_code"] = $params["insurer_filter"]; }
    	if( $params["agent_filter"] != "-1") { $filter_param["agent_name"] = $params["agent_filter"]; }
    	
    	
    	$reports_be = new AdminReportsBe();
   $common_lib = new CommonLib();
    $report_data =  $reports_be->premium_summary_report($params["from_date_filter"],$params["to_date_filter"], $filter_param);
    $hdr_arr = array("Branch Name","Product","Insurer","Agent Name","Policy Count","OD Premium","TP Premium","Brokerage");
    return $common_lib->export_xls("Premium Summary Report", $report_data, $hdr_arr);
    	
    }
    

    
    
}
