<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Be\Admin\AdminReportsBe;
use Illuminate\Http\Request;
use App\Libraries\CommonLib;

class ReportCntlr extends Controller
{
    
	public function premium_summary_report (Request $request)  { 
		$params = $request->all();  
		$reports_be = new AdminReportsBe();
		$filter_list = $reports_be->get_filter_map();
		
		if( ! isset($params["from_date_filter"] ) || $params["from_date_filter"] == null){
			return view('admin/premium_summary_report',[ 'filter_list'=> $filter_list, 'policy_list' => null ]);
		}
		
		$filter_param = array();
		if( $params["branch_filter"] != "-1") { $filter_param["branch_code"] = $params["branch_filter"]; }
		if( $params["product_filter"] != "-1") { $filter_param["module_name"] = $params["product_filter"]; }
		if( $params["insurer_filter"] != "-1") { $filter_param["insurer_code"] = $params["insurer_filter"]; }
		if( $params["agent_filter"] != "-1") { $filter_param["agent_name"] = $params["agent_filter"]; }
		if( ( $params["agent_filter"] != "-1") &&  $filter_param["agent_name"] == 'direct'){
            $filter_param["agent_code"] = null;
            $filter_param["agent_name"] = null;
        }
		$reports_be = new AdminReportsBe(); 
        return view('admin/premium_summary_report',
        	[
        			'filter_list'=> $filter_list,
        			'policy_list' => $reports_be->premium_summary_report($params["from_date_filter"],$params["to_date_filter"], $filter_param)
        ]);
        
    }
    
    public function premium_summary_report_xls (Request $request)  {
    	$params = $request->all();
    	$reports_be = new AdminReportsBe();
    	$filter_list = $reports_be->get_filter_map();
    	
    	if( ! isset($params["from_date_filter"] ) || $params["from_date_filter"] == null){
    		return view('admin/premium_summary_report',[ 'filter_list'=> $filter_list, 'policy_list' => null ]);
    	}
    	
    	$filter_param = array();
    	if( $params["branch_filter"] != "-1") { $filter_param["branch_code"] = $params["branch_filter"]; }
    	if( $params["product_filter"] != "-1") { $filter_param["module_name"] = $params["product_filter"]; }
    	if( $params["insurer_filter"] != "-1") { $filter_param["insurer_code"] = $params["insurer_filter"]; }
    	if( $params["agent_filter"] != "-1") { $filter_param["agent_name"] = $params["agent_filter"]; }
    	
    	
    	$reports_be = new AdminReportsBe();
   $common_lib = new CommonLib();
    $report_data =  $reports_be->premium_summary_report($params["from_date_filter"],$params["to_date_filter"], $filter_param);
    $hdr_arr = array("Branch Name","Product","Insurer","Agent Name","Policy Count","OD Premium","TP Premium","Brokerage");
    return $common_lib->export_xls("Premium Summary Report", $report_data, $hdr_arr);
    	
    }

    public function dashboard_chart(Request $request){
        $params = $request->all();
        
        $filter_param = array();
        $params["branch_filter"] = "-1";
        $params["product_filter"] = "-1";
        $params["insurer_filter"] = "-1";
       
        // $filter_param["agent_code"] = session('user_code');
        $from_date = date('01-M-Y');
        $to_date = date('d-M-Y');
        $reports_be = new AdminReportsBe();
        $common_lib = new CommonLib();
        $data['bar'] =  $reports_be->get_policy_count($from_date,$to_date, $filter_param,'module_name');
        $data['pie'] =  $reports_be->get_policy_count($from_date,$to_date, $filter_param,'insurer_code');
        // $hdr_arr = array("Branch Name","Product","Insurer","Agent Name","Policy Count","OD Premium","TP Premium","Brokerage");
        // $data['labels'] = ["Health", "Private Car", "Two Wheeler", "Travel"];
        // $data['value'] = [12, 19, 3, 15];
        return $data;
    }


    public function policy_summary_report(Request $request){
        $params = $request->all();
        $reports_be = new AdminReportsBe();
        $filter_list = $reports_be->get_filter_map();
        if((isset($params['is_view']))&& ($params['is_view'] == true)){
            return $this->policy_summary_view($request);
        }
        if((isset($params['is_xls_download']))&& ($params['is_xls_download'] == true)){
            return $this->policy_summary_report_xls($request);
        }
        return view('admin/policy_summary_report',
            [ 
                'filter_list'=> $filter_list, 
                'from_date' => '',
                'to_date' => '',
                'policy_list' => null ]);
    }

    private function policy_summary_view(Request $request){
        $params = $request->all();  
        $filter_param = array();
        $reports_be = new AdminReportsBe();
        if( $params["branch_filter"] != "-1") { $filter_param["branch_code"] = $params["branch_filter"]; }
        if( $params["product_filter"] != "-1") { $filter_param["module_name"] = $params["product_filter"]; }
        if( $params["insurer_filter"] != "-1") { $filter_param["insurer_code"] = $params["insurer_filter"]; }
        if( $params["agent_filter"] != "-1") { $filter_param["agent_name"] = $params["agent_filter"]; }
        if( ( $params["agent_filter"] != "-1") &&  $filter_param["agent_name"] == 'direct'){
            $filter_param["agent_code"] = null;
            $filter_param["agent_name"] = null;
        }  
        return view('admin/w_policy_summary',
            [
                    'from_date' => $params['from_date_filter'],
                    'to_date' => $params['to_date_filter'],
                    'policy_list' => $reports_be->premium_summary_report($params["from_date_filter"],$params["to_date_filter"], $filter_param)
        ]);
    }

    private function policy_summary_report_xls (Request $request)  {
        $params = $request->all();
        // dd($params);
        $reports_be = new AdminReportsBe();
        $filter_list = $reports_be->get_filter_map();
        
        if( ! isset($params["from_date_filter"] ) || $params["from_date_filter"] == null){
            return view('admin/premium_summary_report',[ 'filter_list'=> $filter_list, 'policy_list' => null ]);
        }
        
        $filter_param = array();
        if( $params["branch_filter"] != "-1") { $filter_param["branch_code"] = $params["branch_filter"]; }
        if( $params["product_filter"] != "-1") { $filter_param["module_name"] = $params["product_filter"]; }
        if( $params["insurer_filter"] != "-1") { $filter_param["insurer_code"] = $params["insurer_filter"]; }
        if( $params["agent_filter"] != "-1") { $filter_param["agent_name"] = $params["agent_filter"]; }
        if( ( $params["agent_filter"] != "-1") &&  $filter_param["agent_name"] == 'direct'){
            $filter_param["agent_code"] = null;
            $filter_param["agent_name"] = null;
        }  
        $common_lib = new CommonLib();
        $report_data =  $reports_be->premium_summary_report($params["from_date_filter"],$params["to_date_filter"], $filter_param);
        $hdr_arr = array("Branch Name","Product","Insurer","Agent Name","Policy Count","OD Premium","TP Premium","Brokerage");
        $common_lib->export_xls("Premium Summary Report", $report_data, $hdr_arr);
    }

    public function trans_summary_search() {
        $reports_be = new AdminReportsBe();
        $filter_list = $reports_be->get_filter_map_users();
        // dd($filter_list);
        return view('admin/reports_trans_summary',['filter_list'=> $filter_list]);
    }
    public function trans_summary_data (Request $request){
        // dd( $request->all() );
        $report_be = new AdminReportsBe();
        $trans_data_list =  $report_be->trans_summary_report( $request->all() );
   
        return view('admin/w_trans_summary',
                [
                    'trans_data_list'=> $trans_data_list
                ]);
    }
 
    

    
    
}
