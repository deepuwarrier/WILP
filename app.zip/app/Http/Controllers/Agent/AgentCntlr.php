<?php
namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Be\Common\AuthBe;
use App\Be\Agent\AgentHomeBe;

class AgentCntlr extends Controller
{
    
    public function load_dashboard(){ 
        $user_code = !empty(session('user_code'))?session('user_code'):NULL;
//         dd($this->active_leads());
        return view('agent/_dashboard',
        	[
        		'lead_list' => $this->active_leads()
        ]);
        
    }
    
    public function logout(){
    		$auth_be = new AuthBe();
    		$auth_be->execute_logout();
    		return redirect("/login");
    }
    
    public function active_leads(){
    	$agent_code = session("user_code");
    	$agent_home_be = new AgentHomeBe();
    	return $agent_home_be->get_active_leads($agent_code);
    }
    
}
