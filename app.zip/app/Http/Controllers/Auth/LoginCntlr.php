<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Models\Agent\AgentDetails;
use App\Models\Car AS M;
use App\Http\Controllers\Controller;
use App\Be\Common\AuthBe;

class LoginCntlr extends Controller
{
    public function login_page(){
    	if(!empty(session('user_agent'))){
    		return redirect('/agent/dashboard');
    	} else{
    		return view('agent/agent_login');       
    	}
    	
    }

    public function validate_login(Request $request) 
    {	
    	
    	$auth_params = $request->all();
    	$auth_be = new AuthBe();
    	$auth_resp = $auth_be->validate_login($auth_params);
    	
    	switch ($auth_resp) {
    		case "ADMIN":
    			return redirect('/admin/dashboard');
    			break;
    		case "AGENT":
    			return redirect('/agent/dashboard');
    			break;
    		default:
    			return back()->with('error_password', 'User /Password is Incorrect.!')->withInput();
  //  			return back()->with('error_email', 'Oh ho! Please register first.!')->withInput();
    			break;
    	}
    }

    public function logout(Request $request)
    {
        $session_value = ['user_id','user_email','user_agent'];
        session()->forget($session_value);
        $request->session()->flush();
        return redirect('/login');

    }

    public function updatePassword(Request $request){
        $auth_be = new AuthBe();
        $auth_resp = $auth_be->changePassword($request);
        switch ($auth_resp) {
            case '0':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => 'Old Password entered by you does not match'
                    );
                break;
            case '1':
                return array(
                        'error'     => 'false',
                        'user_status'     => '1',
                        'message'   => 'Your password changed Succesfully'
                    );
            case '2':
                return array(
                        'error'     => 'true',
                        'user_status'     => '2',
                        'message'   => 'New Password and Confirm password does not match'
                    );
                break;
            default:
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => 'Sorry for trouble. Please contact administrator.'
                    );
                break;
        }
    }

    
}
