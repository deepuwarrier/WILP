<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\EmailSender;
use App\Constants\Common_Constants;
use App\Models\Calc;

class Calculator extends Controller {

    public function __construct() {
        $this->calc = new Calc();
    }

    public function index() {

        $session_data = session()->get('CALC_PRODUCTS');
        if (!session()->has('CALC_PRODUCTS')) {
            session()->put('CALC_PRODUCTS', array());
            session()->save();
        }
        $data['product_data'] = $this->calc->getProducts();
        $data['category_data'] = $this->calc->getCategories();
        $session_data = session()->get('CALC_PRODUCTS');
        $data['products'] = array();
        $total_value = 0;
        $insure_value = 0;
        foreach ($session_data as $key => $value) {
            $data['products'][$key] = $this->calc->getCategoryProduct($value['product_id']);
            $data['products'][$key]->product_value = $value['product_value'];
            $total_value += $value['product_value'];
            $insure_value += ($value['product_value'] * $data['products'][$key]->percentage) / 100;
        }
        $data['total_value'] = $total_value;
        $data['insure_value'] = $insure_value;
        return view('pages/calc', $data);
        //return view('pages/prmcalc', $data);
    }

    public function add_products(Request $request) {

        if (isset($request->product_id) && isset($request->product_value)) {
            $data['products'] = array();
            $categories = $this->calc->getCategoryProduct($request->product_id);
            $data['category_data'] = $this->calc->getCategories();
            if (count($categories) > 0) {
                $session = array(
                    'product_id' => $categories->calc_product_id,
                    'product_value' => $request->product_value,
                );
                session()->push('CALC_PRODUCTS', $session);
                session()->save();
                $session_data = session()->get('CALC_PRODUCTS');
                $data['products'] = array();
                $total_value = 0;
                $insure_value = 0;
                foreach ($session_data as $key => $value) {
                    $data['products'][$key] = $this->calc->getCategoryProduct($value['product_id']);
                    $data['products'][$key]->product_value = $value['product_value'];
                    $total_value += $value['product_value'];
                    $insure_value += ($value['product_value'] * $data['products'][$key]->percentage) / 100;
                }
            }

            $html_view = view('pages/calc_list', $data)->render();
            echo json_encode(array('result' => 'success', 'html_view' => $html_view, 'total_value' => $total_value, 'insure_value' => $insure_value));
            die;
        }
    }

    public function remove_products(Request $request) {

        if (isset($request->product_id) && isset($request->product_value)) {
            $data['category_data'] = $this->calc->getCategories();
            $data['products'] = array();
            $product_id = $request->product_id;
            $product_value = $request->product_value;
            $session_data = session()->get('CALC_PRODUCTS');
            foreach ($session_data as $key => $value) {
                if ($value['product_id'] == $product_id && $value['product_value'] == $product_value) {
                    unset($session_data[$key]);
                    break;
                }
            }
            session()->put('CALC_PRODUCTS', $session_data);
            session()->save();
            $session_data = session()->get('CALC_PRODUCTS');
            $data['products'] = array();
            $total_value = 0;
            $insure_value = 0;
            foreach ($session_data as $key => $value) {
                $data['products'][$key] = $this->calc->getCategoryProduct($value['product_id']);
                $data['products'][$key]->product_value = $value['product_value'];
                $total_value += $value['product_value'];
                $insure_value += ($value['product_value'] * $data['products'][$key]->percentage) / 100;
            }
            $html_view = view('pages/calc_list', $data)->render();
            echo json_encode(array('result' => 'success', 'html_view' => $html_view, 'total_value' => $total_value, 'insure_value' => $insure_value));
            die;
        }
    }
    
    public function send_email(Request $request){
        if(isset($request->email)){
            $data['product_data'] = $this->calc->getProducts();
            $data['category_data'] = $this->calc->getCategories();
            $session_data = session()->get('CALC_PRODUCTS');
            $total_value = 0;
            $insure_value = 0;
            foreach ($session_data as $key => $value) {
                $data['products'][$key] = $this->calc->getCategoryProduct($value['product_id']);
                $data['products'][$key]->product_value = $value['product_value'];
                $total_value += $value['product_value'];
                $insure_value += ($value['product_value'] * $data['products'][$key]->percentage) / 100;
            }
            $data['total_value'] = $total_value;
            $data['insure_value'] = $insure_value;
            $insurance_type = '';
            $subject = 'Premium Calculator';
            $name = '';
            $mobile = '';
            $email = Common_Constants::DEFAULT_FROM_EMAIL;;
            $to = $request->email;
            $data['client_email'] = $to;
            $view_email_internal = view('pages/calc_email_internal', $data);
            $view_email_external = view('pages/calc_email_external', $data);
            $data = array('from' => $email, 'to' => $to, 'name' => $name, 'insurance_type' => $insurance_type, 'subject' => $subject, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal);
            $this->email_sender = new EmailSender;
            if($this->email_sender->calculatorMail($data)){
                echo json_encode(array('result' => 'success'));die;
            }
            else
            {
                echo json_encode(array('result' => 'fail'));die;
            }
        }
    }
}
