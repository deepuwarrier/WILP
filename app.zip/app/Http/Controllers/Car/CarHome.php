<?php
namespace App\Http\Controllers\Car;

use App\Http\Controllers\Controller;
use  Illuminate\Http\Request;
use  Illuminate\Support\Facades\Session;
use App\Be\Car\CarDetailBe;
use App\Be\Car\CarQuoteBe;
use App\Http\Controllers as C;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarTData;
use App\Models\Car\CarVariant;
use App\Constants\Car_Constants;
use App\Models\Car\CarRto;
use App\Models\PortalPages;
use App\Constants\Common_Constants;
use App\Libraries\InstaLib;


class CarHome extends Controller
{
	private $car_detail;
    private $variants = [];
	private	$rtos = [];
	private	$models = [];

	public function __construct()
	{	
		$this->car_detail = new CarDetailBe();
		$this->car_rto = new CarRto();
	}


	public function uatindex($uat_mode = null){
		$car_helper = new CarHelper;
		if($uat_mode == 'uat'){
			session(['mode_uat' => 'true']);
			return $this->index();
		} else {
			// $car_helper->addFileData(['uat_mode' => 'false']);
			return $this->index();
		}
	}

    /*
    public function index()
	{
		$car_helper = new CarHelper;
		$insta = new InstaLib();
		$trans_code = $insta->get_pc_tc();
	    $session_id = session()->getId();
	    $portalPgs = new PortalPages();
		
		$make_code = $this->car_detail->getDefaultMakeCode();
		$makes = $this->car_detail->getMakes();
		$states = $this->car_detail->getState();

			$car_details = ["make_code" => '',
						  "model_code" => '',
						  "variant_code" => '',
						  "state" => '',
						  "rto" => '',
						  "year" => '',
						  "fuel" => ''];
	*/	
		/* Added by vivek for url based on session id*/
	/*	$car_details['trans_code']= $trans_code; */
        /* Code added by vivek ends here */
    /*
        return view('car/car-home', ['car_makes' => $makes,
			'car_models'=>$this->models,
			'car_states'=>$states,
			'car_variants'=>$this->variants,
			'car_max_year'=>$this->car_detail->getCarMaxYear(),
			'car_min_year'=>$this->car_detail->getCarMinYear(),
			'car_yor'=>$this->car_detail->getYorList(),
			'car_details'=>$car_details,
			'trans_code'=>$trans_code,
			'MTxt' => $portalPgs->getMeta(Common_Constants::CARDETAILS)
			]);
	} */


    public function index()
	{
		
		$variant_db = new CarVariant();
		$vehicle_data = $variant_db->variant_list();
		$rto_db = new CarRto();
		$rto_data = $rto_db->rto_list();
		$portal_pages = new PortalPages();
		return view('car/car-home',
				[
						'MTxt' => $portal_pages->getMeta(Common_Constants::TWDETAILS),
						'vehicle_list' => $vehicle_data,
						'rto_list'=> $rto_data,
						'yor_list'=>$this->car_detail->getYorList(),
				]);
	} 
	
	public function getModelFromMake(Request $request){
		Session::put('make_code',$request->make);
		Session::save();
		$models = $this->car_detail->getModel($request->make);
		if($request->ajax()){
			return response()->json($models);
		}
		return $models;
	}

	public function getVariant(Request $request){
		Session::put('model_code',$request->model_code);
		Session::save();
		$variants = $this->car_detail->getVariant($request->model_code);
        $data = $this->car_detail->filter_variant($variants,$request->variant_type);
		if($request->ajax()){
			return response()->json($data);
		}
		return $data;
	}

    public function getRTO(Request $request)
    {
    	Session::put('state_id',$request->state_id);
    	Session::save();
    	$rto = $this->car_detail->getRto($request->state_id);
    	if($request->ajax()){
    		return response()->json($rto);
    	}
    	return $rto;
    }

    public function getModelCode(){
        return (isset($this->modelCode))? $this->modelCode : null;
    }

    public function setModelCode($model_code){
    	$this->modelCode = $model_code;
    }

    public function getVariantType(){
        return (isset($this->variantId))? $this->variantId : null;
    }

    public function setVariantType($variant_id){
    	$this->variantId = $variant_id;
    }

    public function getFuelShortName($fuel_name){
    	if(strtolower(trim($fuel_name)) == "petrol")
    		return "P";
    	elseif(strtolower(trim($fuel_name)) == "diesel") 
    		return "D";
    	else
    		return "CNG";
    }

    public function checkrto(Request $request){
    	$rto_details = $this->car_rto->get_rto_from_code($request->rto_code);
    	if(count($rto_details) > 0){
			$rto = 'true';
		} else {
			$rto = 'false';
		}
    	if($request->ajax()){
    			return response()->json($rto);
    	} else {
    		return $rto;
    	}
    }

	public function partner_cartisan(Request $request){
		$partner = 'cartisan';
	    session(['partner'=>$partner]);
	    $trans_code = $request->trans_code;
        $this->car_detail->setPartnerId($trans_code);
        return $this->index($request);
	}

	public function setDetailData(Request $request){
		$car_variant = new CarVariant;
		$data = $request->all();
		$data['session_id']	= $request->trans_code;
		$data['trans_code'] = $request->trans_code;
		$field = $this->getFieldMap();

		if(isset($data['year'])){
			$data['fuel'] = $car_variant->fetchFuelType($data['variant_code']);
		}

		foreach ($field as $key => $value){
			$table[$key] = $data[$value];
		}
		try{
			$table['user_code'] = !empty(session('user_code'))?session('user_code'):NULL;
			$car_transaction = CarTData::updateOrCreate(array('trans_code'=>$table['trans_code']),$table);
			$agent_store = new C\Customers\Customers();
			//$agent_store->agentUserCode($user_code);
			$agent_store->setModule('car');
			$agent_store->setUserCode($table['user_code']);
			$agent_store->storeAgentCode($data['trans_code']);
		}catch(Exception $e){
			echo $e->getMessage();
			die;
		}
	}
	// map sql column with form field
    public function getFieldMap($map_for = null){
      $fields = [
                Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
                Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
                Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
				Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
         ];
      return ($map_for)? $fields[$map_for] :  $fields;
	}

	public function storeQuoteData(Request $request,$trans_code = null){
		$data = $request->all();
		if($this->validate_selectbox($data)){ 
	 		return redirect('/car-insurance');
	 	}
		$car_be = new CarDetailBe();
		$insta = new InstaLib();
	 	$data = $car_be->get_storable_details($data);
		$trans_code = $insta->get_pc_tc();
	 	$data['user_code'] = session("user_agent") != true ? session("user_code") : null;
	 	$data['agent_code'] = session("user_role") == '_AGENT'  ? session("user_code") : null;
		$data['session_id']	= $trans_code;
		$data['trans_code'] = $trans_code;
		$car_helper = new CarHelper;
		$user_data = CarTData::updateOrCreate(['trans_code'=>$trans_code],$data);		
		$car_helper->log_quote_status($trans_code,'create_quote');
		return redirect()->route('car-insurance.getquote',$trans_code);
	}

	
	private function validate_selectbox($params) {
	 	$is_error = false;
	 	foreach ($params as $key=>$value)
	 		if($value == "-1")
	 			 $is_error = true;
	 	return $is_error;
	}
	
}

