<?php

namespace App\Http\Controllers\Car;

use App\Constants\Car_Constants;
use App\Constants\Common_Constants;
use App\Helpers\Car\CarHelper;
use App\Helpers\EmailHelper;
use App\Helpers\SmsHelper;
use App\Models\Car as M;
use App\Http\Controllers\Controller;
use App\Models\OtpTData;
use Illuminate\Http\Request;
use App\Http\Controllers\EmailSender;
use  App\Models\Car\CarConfig;
use App\Models\Car\CarTData;
use App\Models\Car\MasterCity;
use App\Libraries\CarLib;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\MasterData;
use App\Models\Car\MasterFinancier;

class CarPolicy extends Controller {
	public function getPremiumStatus(Request $request) {
		$car_m_products = new M\CarProducts;
		$user_data = CarTData::find($request->trans_code);
		$cmp_detials_obj = $car_m_products->getCompDetails($user_data->product_id);
		$html = view('car/status/premium_status', ['price' => round($user_data->totalpremium)
			, 'insurer_id' => $user_data->insurer_id
			,'logo'=>$cmp_detials_obj->product_img])->render();
		return response()->json(['html' => $html]);
	}

	public function getReConfirmStatus() {
		$html = view('car/status/reconfirm_status')->render();
		return response()->json(['html' => $html]);
	}

	public function getInspectionConfirmStatus() {
		$html = view('car/status/inspection_confirm_status')->render();
		return response()->json(['html' => $html]);
	}

	public function getBadResponseStatus() {
		$html = view('car/status/badresponse')->render();
		return response()->json(['html' => $html]);
	}

	public function getPremiumMissmatchStatus(Request $request) {
		$car_helper = new CarHelper;
		$car_m_products = new M\CarProducts;
		$user_data = CarTData::find($request->trans_code);
		$cmp_detials_obj = $car_m_products->getCompDetails($user_data->product_id);
		$html = view('car/status/premium_missmatch',
			['price' => round($user_data->final_premium),
				'passed_price' => round($user_data->totalpremium),
				'insurer_id' => $user_data->insurer_id,
				'logo'=>$cmp_detials_obj->product_img])
			->render();
		return response()->json(['html' => $html]);
	}

	public function setProductId($product_id) {
		session(['product_id' => $product_id]);
	}

	public function getProductId() {
		return session('product_id');
	}

	/*
		 *@modified 24-04-2017
		 *@auther shailesh
		 *@desc Store mobile in session
	*/
	public function genrateOtp(Request $request) {
		$sms = new SmsHelper;
		$car_config = new CarConfig;
		$otp_t_data = new OtpTData;
		session(['mobile' =>$request->mobile]);
		
		if(session('otp_record'.$request->mobile)){
			$count = session('otp_record'.$request->mobile)['count'] + 1;
			session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
						 'count'=>$count]]);
		}else{
			session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
						 'count'=>1]]);
		}
		$num_allowed_otp = $car_config->getValue('MAX_NUM_OTP')->first()->config_value;
		//get old Otp Id
		$result = $otp_t_data->where('mobile', $request->mobile)->first();
		if (is_object($result) && $result->status) {
			session(['UIDNo' => $result->otp_id]);
			return array('otp' => $result->otp_id,'status'=>$result->status); // status added by vivek at 15-May-2017

		}else if(session('otp_record'.$request->mobile)['count'] > $num_allowed_otp){
			return json_encode(['overLimit'=>1,'count'=>session('otp_record'.$request->mobile)['count'],'max'=>$num_allowed_otp]);
		}else {
			$output = $sms->genrateOtp($request->mobile, Car_Constants::OTP_LENGTH);
			return $output;
		}
	}

	/*
		 *@auther shailesh
		 *@modified 24-04-2017
		 *@desc Add mobile in OTP table
	*/
	public function verifyOtp(Request $request) {
		$status = 0;
		$sent_otp = session('otp');
		$recv_otp = $request->code;
		if ($sent_otp && $recv_otp == $sent_otp) {
			$status = 1;
		}
		session(['UIDNo' => $this->storeOtpVlaues($recv_otp, $sent_otp, $status, session('mobile'))]);
		return json_encode(['status' => $status]);
	}

	/*
		 *@auther shailesh
		 *@modified 24-04-2017
		 *@params $mobile Store Mobile no. in otp table
	*/
	public function storeOtpVlaues($recv_otp, $sent_otp, $status, $mobile) {
		$otp = new OtpTData;
		// $otp->fill([OtpTData::MAPPER['SENT_OTP'] => $sent_otp,
		// 	OtpTData::MAPPER['RECIVE_OTP'] => $recv_otp,
		// 	OtpTData::MAPPER['STATUS'] => $status,
		// 	OtpTData::MAPPER['MOBILE'] => $mobile]);
		$query = $otp->updateOrCreate([OtpTData::MAPPER['MOBILE'] => $mobile],[OtpTData::MAPPER['SENT_OTP'] => $sent_otp,
			OtpTData::MAPPER['RECIVE_OTP'] => $recv_otp,
			OtpTData::MAPPER['STATUS'] => $status,
			OtpTData::MAPPER['MOBILE'] => $mobile]);
		return ($query) ? $otp->otp_id : 0;
	}

	public function badResponse() {
		$car_helper = new CarHelper;
		$trans_code = 	$car_helper->getSuid();
		
		$user_data = CarTData::find($trans_code);

		// $company_name = isset($car_helper->getSessionValue($trans_code)['insurance_company'])?$car_helper->getSessionValue($trans_code)['insurance_company']:'';
		// // dd($company_name);
		
		// $proposal_form_data = isset($car_helper->getSessionValue($trans_code)['proposal_form_data'])?$car_helper->getSessionValue($trans_code)['proposal_form_data']:'';
		
		// $proposal_request_url = isset($car_helper->getSessionValue($trans_code)['proposal_request_url'])?$car_helper->getSessionValue($trans_code)['proposal_request_url']:'';
		
		// $proposal_form_result = isset($car_helper->getSessionValue($trans_code)['proposal_form_result'])?$car_helper->getSessionValue($trans_code)['proposal_form_result']:'';
		
		$proposal_form_data = [];
		
		$this->email = new EmailSender;
		if (!empty($proposal_form_data)) {
			try{
				$proposer_fill_details = json_decode($proposal_form_data);
				if($company_name != 'Royal Sundram'){
					if($proposer_fill_details->proposer->custType === 'O'){
			            $name = $proposer_fill_details->proposer->contactName;
			        } else {
			            $name = $proposer_fill_details->proposer->firstName . ' ' . $proposer_fill_details->proposer->lastName;
			        }
					$mobile = $proposer_fill_details->proposer->mobile;
					$client_email = $proposer_fill_details->proposer->email;
				} else {
					$proposer_fill_details->request_url = $proposal_request_url;
					$proposer_fill_details->result = $proposal_form_result;
					$proposer_fill_details->company_name = $company_name;
					$mobile = $proposer_fill_details->proposerDetails->strMobileNo;
					$client_email = $proposer_fill_details->proposerDetails->strEmail;
					$name = $proposer_fill_details->proposerDetails->userName;
				}
				$proposer_fill_details->request_url = $proposal_request_url;
				$proposer_fill_details->result = $proposal_form_result;
				$proposer_fill_details->company_name = $company_name;
				$subject = 'Car Proposal Error '.$company_name;
				$content_internal = view('car.templates.proposal_error.internal_email', ['data_value' => $proposer_fill_details,'agent_name' => $car_helper->getAgentFromQuoteId()]);
				$content_external = view('car.templates.proposal_error.external_email',['name'=>$name,'company_name'=>$company_name]);
				$mail_data = array('subject'=>$subject,'content_external'=>$content_external,'content_internal'=>$content_internal,'proposal_form_data' => $proposer_fill_details, 'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'mobile'=>$mobile);
				if($this->email->proposalErrMail($mail_data)){
					return view('api-bad-response');
				} else {

				}
			} catch (\Exception $e) {
	      		Log::info('CAR - try excempetion error in badResponse :- '.$e->getMessage());
			}
		}
		if(isset($proposer_fill_details) && ($proposer_fill_details->vehicleDetails->previousPolicyType == 'Liability')){
			return view('car.status.prev_policy_liability');
		} else {
			return view('api-bad-response');	
		}
	}

	public function proposalError(){
		$car_helper = new CarHelper;
		// send mail for error 
		$car_m_products = new M\CarProducts;
		$trans_code = 	$car_helper->getSuid();
		$user_data = CarTData::find(['trans_code'=>$trans_code]);
		$logo = null;
		if($user_data && isset($user_data[0]['product_id'])){
			$product_id = $user_data[0]['product_id'];
			$insurer_id = $user_data[0]['insurer_id'];
			$company_details = $car_m_products->getCompProductDetails($product_id);
			$logo_name = $company_details[$product_id]['product_img'];
			$logo = \URL::asset(asset('image/logos/').'/'.$logo_name);
			/*
			if(array_key_exists($insurer_id,Car_Constants::CMP_LOGO))
				$logo = \URL::asset(Car_Constants::CMP_LOGO[$insurer_id]);
			else
				$logo = \URL::asset('image/logos/')."/".$insurer_id.".png";
			*/
		}
		$msg = (session('flash_msg') != '')? session('flash_msg') : 'Transferred to a Offline Team';

		 $footer_msg = (session('footer_msg') != '')? session('footer_msg') : null;	
			session()->forget('flash_msg');
			session()->forget('footer_msg');		 
		/*$company_name = isset($car_helper->getSessionValue($trans_code)['insurance_company'])?$car_helper->getSessionValue($trans_code)['insurance_company']:'';
		$proposal_form_data = isset($car_helper->getSessionValue($trans_code)['proposal_form_data'])?$car_helper->getSessionValue($trans_code)['proposal_form_data']:'';
		$proposal_request_url = isset($car_helper->getSessionValue($trans_code)['proposal_request_url'])?$car_helper->getSessionValue($trans_code)['proposal_request_url']:'';
		$proposal_form_result = isset($car_helper->getSessionValue($trans_code)['proposal_form_result'])?$car_helper->getSessionValue($trans_code)['proposal_form_result']:'';
		$this->email = new EmailSender;
		if (!empty($proposal_form_data)) {
			try{
				$proposer_fill_details = json_decode($proposal_form_data);
				if($company_name != 'Royal Sundram'){
					if($proposer_fill_details->proposer->custType === 'O'){
			            $name = $proposer_fill_details->proposer->contactName;
			        } else {
			            $name = $proposer_fill_details->proposer->firstName . ' ' . $proposer_fill_details->proposer->lastName;
			        }
					$mobile = $proposer_fill_details->proposer->mobile;
					$client_email = $proposer_fill_details->proposer->email;
				} else {
					$proposer_fill_details->request_url = $proposal_request_url;
					$proposer_fill_details->result = $proposal_form_result;
					$proposer_fill_details->company_name = $company_name;
					$mobile = $proposer_fill_details->proposerDetails->strMobileNo;
					$client_email = $proposer_fill_details->proposerDetails->strEmail;
					$name = $proposer_fill_details->proposerDetails->userName;
				}
				$proposer_fill_details->request_url = $proposal_request_url;
				$proposer_fill_details->result = $proposal_form_result;
				$proposer_fill_details->company_name = $company_name;
				
				$subject = 'Car '.$company_name.' Proposal_Failure';
				
				$content_internal = view('car.templates.proposal_error.internal_email', ['data_value' => $proposer_fill_details,'agent_name' => $car_helper->getAgentFromQuoteId()]);
				$content_external = view('car.templates.proposal_error.external_email',['name'=>$name,'company_name'=>$company_name]);
				$mail_data = array('subject'=>$subject,'content_external'=>$content_external,'content_internal'=>$content_internal,'proposal_form_data' => $proposer_fill_details, 'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'mobile'=>$mobile);
				$this->email->proposalErrMail($mail_data);
				
			} catch (\Exception $e) {
	      		Log::info('CAR - try excempetion error in badResponse :- '.$e->getMessage());
			} finally {
				$msg = (session('flash_msg') != '')? session('flash_msg') : 'Transferred to a Offline Team';
				session()->forget('flash_msg');	
				return view('car.policy.proposal_error_page',['msg'=>$msg,'TRN'=>'','footer_msg'=>$footer_msg,'logo'=>$logo]);
			}
		}*/
		// $msg = (session('flash_msg') != '')? session('flash_msg') : 'Transferred to a Offline Team';		
		return view('car.policy.proposal_error_page',['msg'=>$msg,'TRN'=>'','footer_msg'=>$footer_msg,'logo'=>$logo]);
	}
	
	public function collectMasters() {
		return ['State'];

		$main_master = [];
		$masters = [Car_Constants::FG_MASTER
			, Car_Constants::HDFC_MASTER
			, Car_Constants::UI_MASTER
			, Car_Constants::IT_MASTER
			, Car_Constants::BJ_MASTER
			, Car_Constants::UNISOMPO_MASTER
			, Car_Constants::BA_MASTER,
		];

		foreach ($masters as $key => $master) {
			foreach ($master as $key => $master_name) {
				(!in_array($master_name, $main_master)) && ($main_master[] = $master_name);
			}
		};
		return $main_master;

	}

	public function getMasters() {
		$car_helper = new CarHelper;
		$company = ['125MO01PC1', '132MO01PC1', '545MO01PC1', '106MO01PC1', '139MO01PC1', '106MO01PC1', '134MO01PC1'];

		$company_name = ['125MO01PC1' => 'hdfc',
			'132MO01PC1' => 'fgi',
			'545MO01PC1' => 'unitedindia',
			'106MO01PC1' => 'itgi',
			'139MO01PC1' => 'bajaj',
			'134MO01PC1' => 'unisompo'];

		$masters = $this->collectMasters();
		$result = [];
		foreach ($masters as $key => $master_name) {
			foreach ($company as $key => $product_id) {
				$data = $car_helper->callGenericMaster($product_id, $master_name);
				if (!isset($data['data']['error'])) {
					$result[$master_name][$company_name[$product_id]] = $data['data']['result'];
				}

			}

		}
		/*
			foreach ($result as $key => $value) {
				Log::info(json_encode($value, true));
			}

			\
			return true;
		*/
		// self::genrateMasterTable($result);
		Log::info(json_encode($result, true, JSON_UNESCAPED_UNICODE));
		return $result;
	}

	public function getCompany() {
		return ['125' => 'hdfc',
			'132' => 'fgi',
			'545' => 'unitedindia',
			'106' => 'itgi',
			'139' => 'bajaj',
			'134' => 'unisompo'];
	}

	public function getCity(Request $request) {
		$refrel_col = $request->input('refrel_col');
		$state_code = $request->input('stateid');
		$city_db = new MasterCity();
		if($refrel_col == 'bajaj_code')
			$refrel_col = 'code';
		return $city_db->retriveCity($refrel_col,$state_code);
	}

	public function getPincode(Request $request){
		$refrel_col = $request->input('refrel_col');
		$city_code = $request->input('city_code');
		$master_data = new MasterData();
		$response = $master_data->getPincodeList($city_code);
		unset($master_data);
		return $response;
	}

	public function setProposalData(Request $request) {
		$car_helper = new CarHelper;
		$car_lib = new CarLib;
		$values = $request->all();
		$prev_addon = [];
		$field = $car_helper->getFieldMap(strtoupper($values['id']));
		// map and genrate a array table columna name and value
		foreach ($field as $key => $value) {
			if (isset($values[$value])) {
				$table[$key] = $values[$value];
			}else{
				if(($key != 'covers_selected') && ($key != 'quote_id') )
					$table[$key] = null;
			}
		}

		if(in_array("firstname", $field) && isset($values['fullname'])) {
			$key = array_search("firstname", $field);
			$table[$key] = $car_lib->getFirstName($values['fullname']);
			$key = array_search("lastname", $field);
			$table[$key] = $car_lib->getLastName($values['fullname']);
		}

		if($values['id'] == 'communication'){
			if(isset($values['reg_add_is_same']) && $values['reg_add_is_same'] == 'Y'){
				$table['reg_add_is_same'] = 'Y';
			} else {
				$table['reg_add_is_same'] = 'N';
			}
		}
		if($values['id'] == 'previousinsurer'){
			$preinsurer_addon_check = ['zerodep','ts','ep','rti'];
			foreach ($preinsurer_addon_check as $key => $value) {
				if(isset($values['prev'.$value])){
					$prev_addon[$value] = $values['prev'.$value];
				}
			}
			$table['prev_addons'] = json_encode($prev_addon);
		}

		$table['user_code'] = !empty(session('user_code')) ? session('user_code') : NULL;
		
		try {
			$ct = CarTData::find($table['trans_code']);
			foreach ($table as $key => $value) {
				$ct->setAttribute($key,$value);
			}
			$ct->save();
		} catch (\Exception $e) {
			echo $e->getMessage();
			die;
		}
	}

	public function initiatePayment(Request $request){
		$trans_code = $request->input('trans_code');
		$car_helper = new CarHelper;
		$car_helper->log_payment_status($trans_code,'payment_request');
		unset($trans_code);
		echo json_encode(['status'=>1]);
		die;
	}

	public function getFinancier(Request $request){
		$finan = new MasterFinancier();
		$list = $finan->serachFinancier("hdfc_code",$request->input('term'));
		$result["results"] = !empty($list) ?  $list : [];
		return json_encode($result);
	}
}
