<?php
namespace App\Http\Controllers\Car;

use App\Http\Controllers\Controller;
use App\Models\Car as M;
use App\Be\Car as BE;
use App\Http\Controllers\Customers\Customers;
use App\Be\Car\CarQuoteBe;
use App\Helpers\Car\CarHelper;
use App\Models\Car\CarConfig;
use App\Models\Car\CarQuoteModel;
use App\Models\Car\CarTData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session\Store;
use App\Be\Car\CarDetailBe;
use App\Constants\Car_Constants;
use App\Helpers\Car\UIIC\UIICQuoteManager;
use App\Helpers\Car\HDFC\HDFCQuoteManager;
use App\Helpers\Car\BAJAJ\BajajManager;
use App\Models\Car\data\QuoteDetail;
use PDF;
use App\Models\Car\Data\PremiumBreakupData;
use App\Helpers\Car\PremiumBreakup;
use App\Helpers\Car\RELIANCE\RelianceQuoteManager;
use App\Libraries\InstaLib; 
use App\Be\Car\UIICQuoteBe;


class CarQuote extends Controller
{

	public function __construct()
	{
        $this->call = 0;
	}

/*  Below function is executed when the page is refreshed 
    and default loaded quotes are shown
*/

	// public function callIndex(Request $request,$trans_code){
	// 	$request = new Request(['trans_code'=>$trans_code]);
	// 	return $this->index($request);
	// }

/*
	Car Quote index page is loaded
*/
	public function index(Request $request,$trans_code = null)
	{
		$car_helper = new CarHelper;
		$carquotebe = new CarQuoteBe();
		$user_data = CarTData::find($trans_code);
		$user_data = $carquotebe->setQuoteDetailInDb($user_data);
		$covers = $this->getCoversValue();
		$car_details = $carquotebe->getCarDetails($user_data);
		$car_details['covers_description'] = $covers;
		$this->setisProductDiplayOnLoad();
		$this->setInsurerList();
		return view('car/car-quote',
			['trans_code'=>$trans_code,
			'car_details'=>$car_details,
			'covers'=>$covers,
			'selected_chcks'=>explode(',',$user_data->covers_selected),
			'view_data'=>'']);
	}

	public function filter_quote(Request $request){
		$car_t_data = CarTData::find($request->trans_code);
		$car_t_data->covers_selected = $request->chks;
		$car_t_data->save();
		$car_helper = new CarHelper;
		$car_helper->log_quote_status($request->trans_code,'update_quote');
		unset($car_t_data);
		
	}

	public function updateQuoteView($request){
		$car_helper = new CarHelper;
		$view_data = '';
		$trans_code = $request['trans_code'];
		$filtered_array = [];
		$car_details = $this->getIDVData($trans_code);
		$policy_status = isset($request['expiry_status'])?$request['expiry_status']:0;
		if($policy_status == 0 ){
			$carquotebe = new CarQuoteBe;
			$data = $carquotebe->getQuotes();
			foreach ($data['return_data'] as $key=>$quotes) {
					if(($this->getProductIsDisplay($trans_code,$data['return_data'][$key]['product_id']) != '3')|| ($this->getProductIsDisplay($trans_code,$data['return_data'][$key]['product_id']) === '0')){
						continue;
					} else {
						$filtered_array[$key] = $quotes;
						$view_data .=  view('car/quote/quote_update',['error'=>'false'
																	,'quotes'=>$quotes
																	,'car_details'=>$car_details
																	])->render();
					}
			}
		} else {
			$view_data .=  '';
		}
		return response()->json($view_data);
	}

	public function setisProductDiplayOnLoad(){
		$car_products = new M \CarProducts;
		$this->productdisplay =  $car_products->getProductIsDisplay();
		session(['productdisplay' => $this->productdisplay]);
	}

	private function isSupportBreakingCase($product_id){
		if (isset(session('productdisplay')[$product_id])) {
			$breaking_status = session('productdisplay')['breaking_case_'.$product_id];
		} else {
			$breaking_status = 0;
		}
		return $breaking_status;
	}

	public function getProductIsDisplay($trans_code,$product_id){
		$car_helper = new CarHelper;
		$breaking_case = 1;
		$trans_code = $trans_code;
		$car_details = $this->getIDVData($trans_code);
		if(isset($car_details['expiry_status']) && $car_details['expiry_status'] != '0')
			$breaking_case = $this->isSupportBreakingCase($product_id);

		if($breaking_case)
			if (isset(session('productdisplay')[$product_id])) {
				$display_status = session('productdisplay')[$product_id];
			} else {
				$display_status = '1';
			}
		else 
			$display_status = '1';

		return $display_status;
	}

	public function getInsurerList(){
		return $this->insurerList;
	}

	public function setInsurerList(){
		$car_m_products = new M\CarProducts;
		$this->insurerList =  $car_m_products->getInsurerList();
	}

	public function setDetailData(Request $request){
		$car_helper = new CarHelper;
		$car_details = $request->all();
		$carquotebe = new CarQuoteBe();
		$car_t_data = $carquotebe->setCarDetails($car_details);
		if($car_t_data){
			$car_helper->log_quote_status($car_t_data->trans_code,'update_quote');
		}
		unset($car_helper);
		unset($carquotebe);
		//trans_code//quote_update_date
		return json_encode([]);
	}

	public function reset_idv(Request $request){
		$car_quote_be = new CarQuoteBe;
		$trans_code = $request->trans_code;
		$user_data = CarTData::find($trans_code);
		$data = $car_quote_be->calculateIDV($request->input('car_price'),$user_data);
		echo $data['idv'];
	}
	public function check_ncb(Request $request){
		$check_ncb = new CarQuoteBe;
		$data = $check_ncb->checkNcb($request->input('typeofbussiness'),$request->input('ncb'));
		echo $data;
	}

	public function updatePrevPolicyStatus(Request $request){
		$carquotemodel = new CarTData();
		$carquotemodel->updatePolicyStatus($request->all());
	}

	public function defaultvalue(){
		$carcfgobj = new CarConfig();
		$carregistration_diff = $carcfgobj->getValue(Car_Constants::CAR_REGIS_DATE_DIFF)[0]['config_value'];
		$policyenddate_diff = $carcfgobj->getValue(Car_Constants::POLICY_E_DATE_DIFF)[0]['config_value'];
		$policystartdate_diff = $carcfgobj->getValue(Car_Constants::POLICY_S_DATE_DIFF)[0]['config_value'];
		$car_regis_max_days = $carcfgobj->getValue(Car_Constants::CAR_REGIS_MAX_DAYS)[0]['config_value'];
		$car_regis_min_days = $carcfgobj->getValue(Car_Constants::CAR_REGIS_MIN_DAYS)[0]['config_value'];
		$policy_start_max_days = $carcfgobj->getValue(Car_Constants::POLICY_START_MAX_DAYS)[0]['config_value'];
		$policy_start_min_days = $carcfgobj->getValue(Car_Constants::POLICY_START_MIN_DAYS)[0]['config_value'];
		$policy_exp_max_days = $carcfgobj->getValue(Car_Constants::POLICY_EXP_MAX_DAYS)[0]['config_value'];
		$policy_exp_min_days = $carcfgobj->getValue(Car_Constants::POLICY_EXP_MIN_DAYS)[0]['config_value'];
		$dob_min_year = $carcfgobj->getValue(Car_Constants::DOB_AGE_RESTRICTION)[0]['config_value'];
		return response()->json(array('success' => true,
			'carregistration_diff'=>$carregistration_diff,
			'policyenddate_diff'=>$policyenddate_diff,
			'policystartdate_diff'=>$policystartdate_diff,
			'car_regis_max_days'=>$car_regis_max_days,
			'car_regis_min_days'=>$car_regis_min_days,
			'policy_start_max_days'=>$policy_start_max_days,
			'policy_start_min_days'=>$policy_start_min_days,
			'policy_exp_max_days'=>$policy_exp_max_days,
			'policy_exp_min_days'=>$policy_exp_min_days,
			'dob_min_year'=>$dob_min_year
			)
		);
	}

	public function setProductId($product_id){
		session(['product_id'=>$product_id]);
	}

	public function setModelCall($model_call){
		session(['model_call'=>$model_call]);
	}

	public function setChks($chks){
		session(['chks'=>$chks]);
	}

	public function getChks(){
		return session('chks');
	}
	
	public function getProductId(){
		return session('product_id');
	}

	public function getModelCall(){
		return session('model_call');
	}

	public function getPdf(Request $request){
		$car_helper = new CarHelper;
		$data = $request->all();	

		$pb_data = new PremiumBreakupData();
		
		if(isset($data['pb'])){
			$pb_data = $car_helper->pb_to_pb_data($pb_data,$data['pb']);
			$product_id = $data['product_id'];
			$product_data['modal_value']['insurer_id'] = $data['insurer_id'];
			$product_data['modal_value']['idv_received'] = $data['idv_opted'];
		}else{
			$user_data = CarTData::find($data['trans_code']);
			$pb_data = $car_helper->db_to_pb_data($pb_data,$user_data);

			$product_id = $user_data->product_id;
			$product_data['modal_value']['insurer_id'] = $user_data->insurer_id;
			$product_data['modal_value']['idv_received'] = $user_data->idv_opted;
		}
		
		$pb = new PremiumBreakup();
		$pb->setPbDatat($pb_data);
		$premium_breakup = $pb->genratePremiumBreakup();

		$car_m_products = new M\CarProducts;
		$product_image = $car_m_products->getCompDetails($product_id,'product_img')->product_img;
		
		$product_data['logo'] = $product_image;
		$product_data['modal_value']['premiumBreakup'] = $premium_breakup;
		$file_name = $data['pdf_type'];

		$product_data['policy_type_selection'] = $data['policy_type_selection'];
		$product_data['typeOfBusiness'] = $data['typeOfBusiness'];

		unset($pb);
		unset($pb_data);
		unset($car_m_products);
		unset($product_image);

		$pdf = PDF::loadView('car/quote/'.$file_name.'_pdf',$product_data);
		return $pdf->stream('CarInsurance.pdf');
	}

	public function getCoversValue(){
		$carquotemodel = new CarQuoteModel;
		$covers  = $carquotemodel->getCoversValue();
		return $covers;
	}

	public function getCarDetails($trans_code){
		return $this->getIDVData($trans_code);
	}

	public function  setSessionValue($property,$sessionvalue){
		session([$property =>$sessionvalue]);
	}
	
	public function getSessionValue($property){
		return session($property);
	}

	public function getQuoteFieldMap($map_for = null) {
		$fields = [
			//Car_Constants::CAR_T_USERLOG['trans_code'] => 'trans_code',
		Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
						Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
			Car_Constants::CAR_T_QUOTELOG['EXP_STATUS'] => 'policy_exp_status'
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	public function getRSGIQuote(Request $request){
		$idv_data = $this->getIDVData($request->trans_code);

		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		$idv_data['product_id'] = 'rsgi';
		
		$product_display = $this->isProductDisplay($idv_data);
		
		$is_uat = (session('mode_uat') == 'true')?1:0;
		$is_uat = 1;
		
		$view = '';
		
		$display = $this->isDisplay($product_display,$filtered_only);

		if($display && $is_uat){
			return $this->getRSGIQuoteView($idv_data);	
		}else{
			return '';
		}
	}

	public function getRSGIQuoteView($idv_data){
		try {
			$car_helper = new CarHelper;
			$is_uat = 1;
			$view_data = '';
			
			$rsgiquotebe = new BE\RsgiQuoteBe;
			$car_m_products = new M\CarProducts;
			$company_details = $car_m_products->getCompProductDetails($idv_data['product_id']);
			$logo = $company_details[$idv_data['product_id']]['product_img'];	
			$idv_data['car_registration_date'] = $car_helper->changeFormat($idv_data['car_registration_date'],'d/m/Y'); 
			$idv_data['policy_expiry_date'] = $car_helper->changeFormat($idv_data['policyExpiryDate'],'d/m/Y');
			$quotes = $rsgiquotebe->getRsgiQuoteCall($idv_data);

			if(!$quotes)
				return $view_data;
			
			return  view('car/quote/quote_update',['trans_code'=>$idv_data['trans_code'],
				'error'=>'false',
				'url_reloaded'=>'false',
				'quotes'=>$quotes,
				'car_details'=>$idv_data, 
				'pb_data' => $quotes['pb_data'],
				'selected_chcks'=>$idv_data['cov'],
				'logo' => $logo
			])->render();
		} catch (\Exception $e) {
			return '';
		}
	}

	private function isFilterOn($selected_chcks){
		$status = 0;
		if($selected_chcks != '#,#,#,')
			$status = 1;
		return $status;
	}

	private function isProductDisplay($data){
		$car_helper = new CarHelper;
		$product_id = $data['product_id'];
		$breaking_case = 1;
		$trans_code = $data['trans_code'];	
		$car_details = $this->getIDVData($trans_code);
		
		if(isset($car_details['expiry_status']) && $car_details['expiry_status'] != '0')
			$breaking_case = $this->isSupportBreakingCase($product_id);

		if($breaking_case){
			if (isset(session('productdisplay')[$product_id])) {
				$display_status = session('productdisplay')[$product_id];
			} else {
				$display_status = 0;
			}
		}else 
			$display_status = 0;

		return $display_status;
	}

    // CAALLED WHEN JS CALL
	public function getUIICQuote(Request $request){

		$idv_data = $this->getIDVData($request->trans_code);
		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		$idv_data['product_id'] = 'uiic';
		$product_display = $this->isProductDisplay($idv_data);
		$is_uat = 0;
		$view = '';
		$display = $this->isDisplay($product_display,$filtered_only);
		
				$uiic_quote_be = new UIICQuoteBe;
		
		if(!$display || !$uiic_quote_be->pre_quote_check($idv_data))
			    return '';

    		return $this->getUIICQuoteView($idv_data);	


	}

	private function getUIICQuoteView($data){
		try {
			$car_helper = new CarHelper;
			$selected_chcks = $data['selected_chcks'];
			$quote_manger = $this->getUIICQuoteManager($data);
			$view_data1 = '';
	      	if(isset($quote_manger->quote)){
				$view_data1 .=  view('car/quote/quote_update',[
				'error'=>'false',
				'trans_code' =>$data['trans_code'],
				'quotes'=>$quote_manger->quote,
				'car_details'=>$data,
				'pb_data'=>$quote_manger->quote['pb_data'],
				'selected_chcks'=>$selected_chcks])->render();
	      	}
			return $view_data1;
		} catch (\Exception $e) {
			return '';
		}
	}

	private function getUIICQuoteManager($data){
		$car_helper = new CarHelper;
		$quote_manger = new UIICQuoteManager($data['trans_code']);
		$quote_manger->setTransCode($data['trans_code']);
		$quote_manger->setAddons($data['selected_chcks']);
		$quote_manger->getQuote();
		return $quote_manger;
	}

	private function getIDVData($trans_code,$user_data = null){
		$carQuoteBe = new CarQuoteBe;
		if(!isset($user_data))
			$user_data =  CarTData::find($trans_code);
        
        $od_start_date = 0;
		$od_end_date   = 0;
		$tp_start_date = 0;
		$tp_end_date   = 0;
		
		if($user_data->policy_type_selection == '3'){
			$od_start_date = date('d-m-Y');
			$od_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));

			$tp_start_date = date('d-m-Y');
			$tp_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));
	    }

	    if($user_data->policy_type_selection == '1'){
			$od_start_date = date('d-m-Y');
			$od_end_date   = date('d-m-Y', strtotime('-1 Day +1 Year', strtotime(date('Y-m-d'))));

			$tp_start_date = date('d-m-Y');
			$tp_end_date   = date('d-m-Y', strtotime('-1 Day +3 Year', strtotime(date('Y-m-d'))));
	    }

	    $user_data->od_start_date = $od_start_date;
	    $user_data->od_end_date = $od_end_date;
	    $user_data->tp_start_date = $tp_start_date;
	    $user_data->tp_end_date = $tp_end_date;

		$idv_data = $carQuoteBe->getCarDetails($user_data);
		$idv_data['selected_chcks'] = $idv_data['cov'];
		unset($user_data);
		unset($carQuoteBe);
		return $idv_data;
	}

	public function getBAJAJQuote(Request $request){
		if(!isset($idv_data))
			$idv_data  = $this->getIDVData($request->trans_code);
		
		$data = $request->all();
		$trans_code = $data['trans_code'];
		
		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		$idv_data['product_id'] = 'bajaj';
		$idv_data['trans_code'] = $request->trans_code;
		// return $this->getBAJAJQuoteView($data);
		//$product_display = 1;
		$product_display = $this->isProductDisplay($idv_data);
		//$is_uat = (session('mode_uat') == 'true')?1:0;
		$is_uat = 1;
		$view = '';
		
		$display = $this->isDisplay($product_display,$filtered_only);

		if($display && $is_uat){
			return $this->getBAJAJQuoteView($idv_data);	
		}else{
			return '';
		}
	}

	private function getBAJAJQuoteView($data){
		$view_data1 = '';
		$bajaj_manager = new BajajManager();
		$car_helper = new CarHelper;
		$car_m_products = new M\CarProducts;
		$selected_chcks = $data['selected_chcks'];
		$trans_code = $data['trans_code'];
		$bajaj_manager->setAddons($selected_chcks);
		$bajaj_manager->getQuote($data);
		$company_details = $car_m_products->getCompProductDetails($bajaj_manager->product_id);
		$logo = $company_details[$bajaj_manager->product_id]['product_img'];		
		if(isset($bajaj_manager->quote)){
			$view_data1 .=  view('car/quote/quote_update',[
									'error'=>'false',
									'quotes'=>$bajaj_manager->quote,
									'car_details'=>$bajaj_manager->car_details,
									'selected_chcks'=>$selected_chcks,
									'trans_code'=>$trans_code,
									'logo' => $logo,
									'pb_data'=>$bajaj_manager->quote['pb_data']
								])->render();
      	}

		return $view_data1;
	}


	public function getRelianceQuote(Request $request){
	    try{
		$manager =  new RelianceQuoteManager();

		$idv_data = $this->getIDVData($request->trans_code);
		$manager->setIDVData($idv_data);
		
		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		
		$idv_data['product_id'] = $manager->product_id;
		
		$product_display = 3;
		$is_uat = 1;
		$view = '';

		$display = $this->isDisplay($product_display,$filtered_only);

		if($display && $is_uat){
			return $this->getRelianceQuoteView($manager);	
		}else{
			return '';
		}
	    }catch(\Exception $ex){
	        return '';
	    }
		
	}

	private function getRelianceQuoteView($manager){
		$car_m_products = new M\CarProducts;
		$view_data = '';
		$quote_data = $manager->getQuote();
		$company_details = $car_m_products->getCompProductDetails($manager->product_id);
		$logo = $company_details[$manager->product_id]['product_img'];	
		if($quote_data && is_array($quote_data)){
			$idv_data = $manager->getIDVData();
			
			$view_data .=  view('car/quote/quote_update',[
									'error'=>'false',
									'quotes'=>$quote_data,
									'car_details'=>$idv_data,
									'trans_code'=>$idv_data['trans_code'],
									'selected_chcks'=>$idv_data['selected_chcks'],
									'pb_data' =>$quote_data['pb_data'],
									'logo' => $logo,
							])->render();
      	}
		return $view_data;
	}

	private function isDisplay($product_display,$filtered_only){
		$display = 0;
		if($product_display == 3){
			$display = 1;
		} else if($product_display == 2 && $filtered_only){
			$display = 1;
		} else if($product_display == 1 && !$filtered_only){
			$display = 1;
		}
		return $display;
	}

	public function getHDFCQuote(Request $request){
		$idv_data = $this->getIDVData($request->trans_code);
		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		$idv_data['product_id'] = 'hdfc';
		$product_display = $this->isProductDisplay($idv_data);
		$is_uat = 1;
		$view = '';
		$display = $this->isDisplay($product_display,$filtered_only);
		if($display && $is_uat){
			return $this->getHDFCQuoteView($idv_data);	
		}else{
			return '';
		}
	}

	private function getQuote($product_id,$is_uat,$call_func,$trans_code){
		$idv_data = $this->getIDVData($trans_code);
		$filtered_only = $this->isFilterOn($idv_data['selected_chcks']);
		$idv_data['product_id'] = $product_id;
		$product_display = $this->isProductDisplay($idv_data);
		$view = '';
		$display = $this->isDisplay($product_display,$filtered_only);
		if($display && $is_uat){
			return call_user_func([$this,$call_func],$idv_data);
			return $this->getUIICQuoteView($idv_data);	
		}else{
			return '';
		}

	}

	private function getHDFCQuoteView($idv_data){
		try{
			$car_helper = new CarHelper;
			$car_variant = new M\CarVariant;
			$car_rto = new M\CarRto;
			$trans_code = $idv_data['trans_code'];
			$selected_chcks = $idv_data['selected_chcks'];
	        $this->car_details = $this->getIDVData($trans_code);
	        $this->car_details['vm_code'] = $car_variant->getVehicleId($this->car_details['variant_code'],'hdfc_code')->hdfc_code;

	       	$this->car_details['rto_location'] = $car_rto->getRTOData($this->car_details['rto'],'hdfc_code')->hdfc_code;
	        $data = ['car_details'=>$this->car_details,'selected_chcks'=>$selected_chcks,'trans_code' => $trans_code];
			$quote_manger = new HDFCQuoteManager($data);
			$view_data1 = '';
			if(isset($quote_manger->quote)){
				$view_data1 .=  view('car/quote/quote_update',[
				'error'=>'false',
				'quotes'=>$quote_manger->quote,
				'car_details'=>$quote_manger->car_details,
				'trans_code'=>$trans_code,
				'selected_chcks'=>$selected_chcks,
				'pb_data' => $quote_manger->quote['pb_data'],
				'logo'=>$quote_manger->logo
			])->render();
	      	}
			return $view_data1;
		} catch (\Exception $e) {
			return '';
		}
	}

	public function refresh(){
		session()->forget('pc_suid');
		session()->regenerate();
		return redirect()->to('/'); 
	}

	public function getTataQuote(Request $request){
	    return null;
		$car_helper = new CarHelper;
		$trans_code =  $request->trans_code;
		$is_uat = (session('mode_uat') == 'true')?1:0;
		$is_uat = 1;
		$idv_details = $this->getIDVData($trans_code);
		
		if(!$is_uat)
			return '';

		$covers = $this->getCoversValue();
		$car_details = $this->getCarDetails($trans_code);
		$product_id = $this->getProductId();
		$selected_chcks = session('chcks');
		$tataquotebe = new BE\TataQuoteBe;
		$tataquotebe->setSelectedCovers($request->chks);
		$data = $tataquotebe->tataQuoteCall($idv_details);
		$view_data = '';
		if(isset($data['error']) != 'true' && is_array($data)){
			foreach ($data as $key=>$quotes) {
				if($this->getProductIsDisplay($trans_code,$data[$key]['product_id']) != '3'){
						continue;
					} else {
							$quotes_retrived[$key] = $quotes;
							$view_data .=  view('car/quote/quote_update',['trans_code'=>$trans_code,
								'error'=>'false',
								'url_reloaded'=>'false',
								'quotes'=>$quotes,
								'pb_data'=>$quotes['pb_data'],
								'car_details'=>$car_details,
								'selected_chcks'=>$selected_chcks,
								'logo'=>$quotes['logo']])->render();
					}
			}
		} else {
			$array = array(
				'tata_return_data' => '',
			);
			$view_data = '';
		}
		return  $view_data;
			
			
	}

	public function load_proposal_page(Request $request){
		$data = $request->all();
        $car_helper = new CarHelper();
        $pb_data = $car_helper->storeQuoteValue($data);
        // store ip
        $car_helper->storeIp($request);
        $car_helper->storeOptedIDV($request);

        //store agent details
        $user_code = !empty(session('user_code')) ? session('user_code') : NULL;
        $agent_store = new Customers();
        //$agent_store->agentUserCode($user_code);
        $agent_store->setModule('car');
        $agent_store->setUserCode($user_code);
        $agent_store->storeAgentCode($request->trans_code);

        unset($data['pb']);
		$car_helper->log_quote_status($data['trans_code'],'buy_quote');
		return redirect($data['action_url']);
	}

	public function get_idv_section(Request $request){
		$car_helper = new CarHelper;
		$session_id = $request->input('session_id');
		$data = CarTData::find($session_id);
		$obj = new \StdClass();
		if(isset($data->car_registration_date))
			$obj->car_reg_date = $car_helper->changeFormat($data->car_registration_date,'d/m/Y');
		if(isset($data->policy_expiry_date))
			$obj->policy_exp_date = $car_helper->changeFormat($data->policy_expiry_date,'d/m/Y');
		if(isset($data->policy_start_date))
			$obj->policy_start_date = $car_helper->changeFormat($data->policy_start_date,'d/m/Y');
		$obj->policy_exp_status = $data->policy_exp_status;
		$obj->claim = $data->claim;
		$obj->prev_ncb = $data->ncb;
		$obj->new_ncb = $data->new_ncb;			
		$obj->idv = $data->idv_calculated;
		echo json_encode($obj);
	}



}

