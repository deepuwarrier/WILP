<?php
namespace App\Http\Controllers\Car\Policy;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers as C;
use App\Helpers\Car\CarHelper;
use App\Helpers\Car\HDFC\HDFCProposalManager;
use App\Helpers\Car\HDFC\HDFCRequest;
use App\Be\Car\CarPolicyBe;
use App\Libraries\CarLib;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;
use URL;
use Log;

class HDFC extends Controller
{
	 public $agentCode = 'TTIB0001';

	public function __construct(){
		$this->proposal_man = new HDFCProposalManager();	
		$this->car_helper = new CarHelper;
		$this->redirect = 0;	
		$this->proposal_man->agent_code = $this->agentCode;
	}

	public function loadProposalUrl(Request $request,$trans_code){
		$car_t_data = new CarTData;
		$request->trans_code = $trans_code;
		$this->car_helper->storeIp($request);
		$this->car_helper->checkTransaction($trans_code);
		$user_data = $car_t_data->find($trans_code);
		$field = $this->car_helper->getQuoteFieldMap();
		$field['insurer_id'] = 'insurer_id';
		$field['product_id'] = 'product_id';
		$field['totalpremium'] = 'totalpremium';
		$field['netPremium'] = 'netPremium';
		$field['return_quote_url'] = 'return_quote_url';
		$this->proposal_man->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $field);
		$this->proposal_man->user_data['trans_code'] = $trans_code;
		// if ($sessionid != session()->getId()) {
		// 	$this->redirect = 1;
		// }
		$request = new Request($this->proposal_man->user_data);
		return $this->index($request);
	}

	public function index(Request $request){
		$data = $request->all();
		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($data['trans_code']);
        $trans_code = $data['trans_code'];
        $pb_data = $this->car_helper->getQuoteValue($trans_code);
        $user_data = CarTData::find($trans_code);
        $user_data = $this->car_helper->update_proposal_status($trans_code,'proposal_load');
        $car_details = $this->car_helper->getCarBasicDetails($user_data);
        
        $premium_breakup = $this->car_helper->getPremiumBreakup($user_data,$pb_data);
      	$request_data = $request->all();
    	$trans_code = $request_data['trans_code'];
    	$this->preDefinedData = $this->proposal_man->getPredefinedData($request_data);
    	$user_code = $this->car_helper->getUserCode();
		
		$stateCity = $this->proposal_man->getStateCity('hdfc');
		$data = $this->proposal_man->requiredData($this->preDefinedData['product_id']);
		$data = (!empty($stateCity)) ? array_merge($data, $stateCity) : $data;
		// convert date format
		$this->proposal_man->changeDateFormate(); 
		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
		$fullname = (isset($this->proposal_man->user_data['firstname']) && isset($this->proposal_man->user_data['lastname']))?$this->proposal_man->user_data['firstname'].' '.$this->proposal_man->user_data['lastname']:'';
		$data = array_merge($data, ['minYear' => $this->carpolicybe->getMinYear(),
			'year_select' => $this->carpolicybe->getYears($this->preDefinedData['trans_code']),
			'exp_status' => (isset($this->proposal_man->db->policy_exp_status)) ? $this->proposal_man->db->policy_exp_status : 0,
			'elect_ass' => $this->proposal_man->elect_ass,
			'non_elect_ass' => $this->proposal_man->non_elect_ass,
			'cmp_paid_up' => $this->proposal_man->cmp_paid_up,
			'user_data' => $this->proposal_man->user_data,
			'title' => $this->proposal_man->title,
			'type_of_finance' => $this->proposal_man->type_of_finance,
			'fullname'=>$fullname,
			'car_detail' => (!empty(session('details_selected')['make_name'])) ? session('details_selected') : $car_details,
			'cmp_name' => $this->car_helper->getInsuranceCompanyName($this->preDefinedData['product_id']),
			'predefinedData' => $this->preDefinedData,
			'perm_diff' => $this->preDefinedData['perm_diff'],
			'reg_add_is_same' => $this->preDefinedData['reg_add_is_same'],
			'totalpremium' => $this->preDefinedData['totalpremium'],
			'netPremium' => $this->preDefinedData['netPremium'],
			'return_quote_url' => $this->preDefinedData['return_quote_url'],
			'typeOfBusiness' => $car_details['typeOfBusiness'],
			'requiredRollover' => (strtolower($car_details['typeOfBusiness']) == "rollover") ? "required" : "",
			'redirected' => $this->redirect,
			'width_tab' => 20,
			'logo' => $this->proposal_man->logo
		]);
		if(!isset($this->proposal_man->user_data['prevzerodep'])){
   			$data['yes_prev_zerodep'] = 'checked';
   			$data['no_prev_zerodep'] = '';
		} else if($this->proposal_man->user_data['prevzerodep'] == 'Y'){
   			$data['yes_prev_zerodep'] = 'checked';
   			$data['no_prev_zerodep'] = '';	
   		} else {
   			$data['yes_prev_zerodep'] = '';
   			$data['no_prev_zerodep'] = 'checked';
   		}
   		$data['trans_code'] = $trans_code;
   		$data['modal_value'] = $premium_breakup;
   		return view('car.policy.hdfc', $data);
	}

	public function getPolicy(Request $request) {
		$car_t_data = new CarTData;
		$car_helper = new CarHelper;
		$trans_code = $request->trans_code;
		Log::info('CAR HDFC PROPOSAL TRANS_CODE '.$trans_code);
		$car_helper->setSuid($trans_code);
		$this->car_helper->storeUserLoginId();
    	$this->hdfc_req = new HDFCRequest($this->proposal_man);
		$user_data = $car_t_data->find($trans_code);

		// $validation_arr = $this->validate_data($user_data);
        
  //       if($validation_arr["verror"]){ 
  //           return response()->json( ["error" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
  //       } 
        

		if($request->input('new_premium') != null){
			$this->hdfc_req->req_prem = 'final';	
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit_new_premium');
		}else{
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit');
		}
    	$this->hdfc_req->setData($trans_code,$user_data);
    	$param = $this->car_helper->genrateXml("<xmlmotorpolicy/>",$this->hdfc_req->req)->asXML();
    	$result = $this->proposal_man->submit_policy($param,$trans_code);
    	$response =  $this->proposal_man->genrateProposalResponse($result,$this->hdfc_req->req,$trans_code);
    	$this->updateProposalResponse($car_helper,$trans_code,$response);
    
    	return response()->json($response);
    	
	}

	private function validate_data($usr_data){
        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->usr_mobile,
                            'customer_name' => $usr_data->usr_firstname.' '.$usr_data->usr_lastname,
                            'pc_customer_dob' => $usr_data->usr_dob,
                            'customer_panno' => $usr_data->usr_pan,
                            'pc_customer_aadharno' => $usr_data->usr_aadharno,
                            'customer_email' => $usr_data->usr_email,
                            'customer_add1' => $usr_data->usr_houseno,
                            'customer_add2' => $usr_data->usr_street,
                            'customer_add3' => $usr_data->usr_locality,
                            'customer_pincode' => $usr_data->usr_pincode,
                            'pc_reg_no' => $usr_data->veh_reg_no,
                            'pc_engine_no' => $usr_data->veh_eng_no,
                            'pc_chasis_no' => $usr_data->veh_chassisno,
                            'pc_pre_policy' => $usr_data->prev_policyno,
                            'nominee_name' => $usr_data->nominee_name,
                            'number' => $usr_data->nominee_age
                        ];
        if($usr_data->usr_type == 'O'){
            $required_array['customer_gstin'] = $usr_data->gstin;
        }
        return $valid_lib->proposalSubmit($required_array);
    }

	private function updateProposalResponse($car_helper,$trans_code,$response){
		if(array_key_exists('fields',$response))
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted');
    	else if(array_key_exists('error',$response))
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',['msg'=>$response['error']]);
    	else if(array_key_exists('proposal_error',$response))
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',['msg'=>$response['proposal_error']]);
	}

	public function returnPage(Request $request){
		$car_helper = new CarHelper;
		$payment_resp = $request->all();
		$car_t_data = new CarTData;
		$response = $this->proposal_man->parsePaymentResponse($payment_resp);
		$trans_code = $response['trans_code'];
		$user_data = CarTData::find($trans_code);
		
		$car_helper->log_payment_result($trans_code,$this->proposal_man->status,['msg'=>$payment_resp['Msg']]);

		Log::info("CAR HDFC Payment Return URL - ".$response['trans_code'].":- ".$request->fullUrl());
		Log::info("CAR HDFC Payment Response - ".$response['trans_code'].":- ".json_encode($payment_resp));
		Log::info('CAR HDFC PAYMENT TRANS_CODE '.$response['trans_code']);
		$data = ['status' => $this->proposal_man->status,
					     'logo' => Car_Constants::LOGO['hdfcergo'], 
					     'udata' => $payment_resp];
		$data['udata']['ref_no'] = $this->proposal_man->getPolicyRefNo();
		
		$car_transaction = $car_t_data->update(array('trans_code' =>$response['trans_code']),$response);
		
		$car_helper->log_policy_result($trans_code,$this->proposal_man->status);

		$this->proposal_man->storeStatusAndTransaction($this->proposal_man->status,$response['trans_code']);
		
		return view('car.return_page.hdfc', $data);
	}

	public function getZerodepStatus(Request $request){
		$data = $request->all();
		$car_t_data = new CarTData;
		$user_data = $car_t_data->find($data['trans_code']);
		$covers = explode(',',$user_data->covers_selected);
		$user_data->covers_selected = implode(',',$covers);
		$addon = json_decode($user_data->addon_premium,true);
		if(array_key_exists('zerodep',$addon)){
			$zerodep_value = $addon['zerodep'];
			$zerodep_tax = (($zerodep_value*Car_Constants::GST)/100);
			$approx_value = round($user_data->totalpremium-($zerodep_value+$zerodep_tax));
			$html = view('car/status/zerodep_status',['premium'=>$approx_value])->render();
			return response()->json(['html' => $html]);
		}else{
			return response()->json(['zerodep_excluded'=>'']);
		}
		
	}

	public function update_pay_mode(Request $request){
       	$car_t_data = new CarTData;
        $columns['pay_mode']  = $request->input('pay_mode');
        $car_t_data->set_by_tc($request->input('trans_code'),$columns);
        return json_encode(['status' => true]);
    }

	
}
