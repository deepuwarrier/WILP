<?php
namespace App\Http\Controllers\Car\Policy;

use App\Helpers\Car\RELIANCE\ProposalManager;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Car\CarHelper;
use App\Be\Car\CarPolicyBe;
use App\Libraries\CarLib;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\PolicyPageData;
// master
use App\Models\Car\MasterState;
use App\Models\Car\MasterFinancier;
use App\Models\Car\MasterNomineeRelationship;
use App\Models\Car\MasterCity;
use App\Models\Car\MasterInsurer;
use App\Models\Car\Data\MasterData;

class Reliance extends Controller{

	public function __construct(){
		$this->manager = new ProposalManager();	
		$this->redirect = 0;	
	}

	public function index(Request $request,$trans_code = null){
		$request_data = $request->all();
		
		if(empty($request_data))
			$request_data['trans_code'] = $trans_code;

		$car_helper = new CarHelper;
		$trans_code = isset($request_data['trans_code'])?$request_data['trans_code']:$trans_code;

		$request_data['session_id'] = $trans_code;
		// genrate premium breakup
		$pb_data = $car_helper->getQuoteValue($request_data['trans_code']);
    	$user_data = CarTData::find($trans_code);
    	$user_data = $car_helper->update_proposal_status($trans_code,'proposal_load');
   		$premium_breakup = $car_helper->getPremiumBreakup($user_data,$pb_data);
		
		//return redirect('https://www.reliancegeneral.co.in/insurance/landing.aspx?PCode=2311&RGIPartnerid=8&RGIPartnerprocessid=1');

		$policy_page_data = new PolicyPageData($user_data);
		$policy_page_data->setRefrelCol($this->manager->refrel_code);
		
		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
		$policy_page_data->setMinYear($this->carpolicybe->getMinYear());
		$policy_page_data->setManfYearList($this->carpolicybe->getYears($trans_code));

		$stateDb = new MasterState();
		$policy_page_data->setStateList($stateDb->getStateList($this->manager->refrel_code));

		$relDb = new MasterNomineeRelationship();
		$policy_page_data->setRelationshipList($relDb->getNomineerelationshipList($this->manager->refrel_code));

		$insurerDb = new MasterInsurer();
		$insurer_list = $insurerDb->getInsurerList($this->manager->refrel_code);
		$policy_page_data->setInsurerList($insurer_list);
		$policy_page_data->setTypeOfFinanceList(Car_Constants::TYPE_OF_FINANCE);

		$user_data_list = $this->manager->getDbData($user_data->trans_code,$user_data);
		$user_data_list = $this->manager->changeDateFormate($user_data_list);

		if(isset($user_data_list['statecode'])){
			$cityDb = new MasterCity();
			$policy_page_data->setCityList($cityDb->retriveCity($this->manager->refrel_code,$user_data_list['statecode']));
			$policy_page_data->setPermCityList($policy_page_data->getCityList());
			unset($cityDb);
		}

		if(isset($user_data_list['perm_statecode']) 
				&& $user_data_list['perm_statecode'] == $user_data_list['statecode']){
			$cityDb = new MasterCity();
			$policy_page_data->setPermCityList($cityDb->retriveCity($this->manager->refrel_code,$user_data_list['perm_statecode']));
			unset($cityDb);
		}

		$master_data = new MasterData();
		$policy_page_data->setPincodeList(
				$master_data->getPincodeList($user_data['usr_city_code'])
		);
		$policy_page_data->setPermPincodeList(
				$master_data->getPincodeList($user_data['prem_usr_city_code'])
		);
		
		unset($master_data);
		
		return view('car.policy.reliance',['quote'=>$policy_page_data,
		 'user_data_list'=>$user_data_list
		,'user_data'=>$user_data
		,'redirected'=>0
		,'predefinedData'=>['prev_tab_title'=>$policy_page_data->getPreviousTabText()],
		'logo'=>'reliance_logo.png',
		'trans_code'=>$trans_code,
		'modal_value' =>$premium_breakup
		]);
	}


	public function getPolicy(Request $request){
		$form_data = $request->all();
		$car_helper = new CarHelper;
		$car_helper->setSuid($request->trans_code);
		$trans_id = $car_helper->getSuid();
		$car_helper->storeUserLoginId();
		$user_data = CarTData::find($trans_id);
		$trans_code = $request->trans_code;
		if(!array_key_exists('new_premium',$form_data))
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit');
		else 
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit_new_premium');
			
		$prop_request = $this->manager->genProposalRequest($user_data,$request);
		$response = $this->manager->callApi($prop_request);
		
		$response = $this->manager->genProposalResponse($form_data,$response,$user_data);
		
		if(is_array($response) && array_key_exists('error',$response))
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',$response['error']);
		else if(is_array($response) && array_key_exists('fields',$response))
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted');
		
		unset($car_helper);
                Log::info("Car Reliance Payment Request :". $trans_code . "". print_r($response, true));
		echo json_encode($response);
	}
	
	public function returnPage(Request $request){
		$payment_resp = $request->all();
		$car_helper = new CarHelper;
		$trans_code = $car_helper->getSuid();
		$car_t_data = CarTData::find($trans_code);
		
		if(!$car_t_data){
			$car_t_data = CarTData::find($trans_code.'_DONE');
			$data = ['status' => 1,
			     'logo' => Car_Constants::LOGO['reliance'], 
				 'udata' => ['ref_no'=>$car_t_data->policy_nu]];		
			$data['download_link'] = $this->manager->getPolicyPdfUrl($car_t_data->policy_nu);
			return view('car.return_page.reliance', $data);
		}

		Log::info($request->fullUrl()); 
		Log::info("CAR Reliance Payment Response : ".json_encode($payment_resp));
		$payment_resp = $this->manager->parse_pgresp($payment_resp);
		
		$response = $this->manager->store_payment_data($payment_resp);

		$user_data =  CarTData::find($response['trans_code']);
		
		$car_helper->log_payment_result($trans_code,$this->manager->status,['ref_no'=>$payment_resp['Transaction Number'],'msg'=>$payment_resp['Transaction Status']]);
		$car_helper->log_policy_result($trans_code,$this->manager->status,['msg'=>$payment_resp['Policy Number']]);
		
		Log::info('CAR Reliance PAYMENT TRANS_CODE '.$response['trans_code']);

		$data = ['status' => $this->manager->status,
			     'logo' => Car_Constants::LOGO['reliance'], 
				 'udata' => $response];

		
		$data['udata']['ref_no'] = $this->manager->getPolicyRefNo();
		
		foreach ($response as $key => $value) {
			$car_t_data->{$key} = $value;
		}
	
		$car_transaction = $car_t_data->save();
		
		$this->manager->storeStatusAndTransaction($this->manager->status,$response['trans_code']);
		$data['download_link'] = $this->manager->getPolicyPdfUrl($car_t_data->policy_nu);
		return view('car.return_page.reliance', $data);
	}
}

