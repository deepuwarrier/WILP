<?php
namespace App\Http\Controllers\Car\Policy;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Car\CarHelper;
use App\Helpers\Car\RSGI\RsgiHelper;
use App\Http\Controllers as C;
use App\Helpers\Car\RSGI\RsgiPolicyManager;
use App\Http\Controllers\EmailSender;
use App\Constants\Car_Constants;
use App\Models\Car\CarConfig;
use Carbon\Carbon;
use App\Models\Car\CarTData;
use App\Libraries\CarLib;
use App\Models\Car as M;
use App\Be\Car\CarPolicyBe;
use App\Be\Common\PaymentParseBE;
use Log;
use App\Libraries\ValidatorLib;

class RoyalSundram extends Controller
{
	public function __construct(){
		$rsgi_policy_manager = new RsgiPolicyManager;
		$this->refrel_col = 'fgi';
		$this->required_master = Car_Constants::ROYAL_SUNDRAM_MASTER;
		$this->policy_type = Car_Constants::POLICY_TYPE;
		$this->type_of_finance = Car_Constants::TYPE_OF_FINANCE;
		$this->email = new EmailSender;
		$this->car_helper = new CarHelper;
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->nu_of_claim = Car_Constants::NU_OF_CLAIM;  //Added by vivek
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->refrel_variant_col = "rsgi_code";
		$this->vd = $rsgi_policy_manager->VD;
		$this->nominee_rel = Car_Constants::NOMINEE_REL;
	}

	/* Created by vivek */
	public function loadProposalUrl(Request $request,$trans_code){
		$car_t_data = new CarTData;
		$request->trans_code = $trans_code;
		$this->car_helper->checkTransaction($trans_code);
		$user_data = $car_t_data->find($trans_code);
		if (empty($user_data)) {
            return redirect()->route('car_insurance');
        }
		$field = $this->getQuoteFieldMap();
		$field['insurer_id'] = 'insurer_id';
		$field['product_id'] = 'product_id';
		$field['totalpremium'] = 'totalpremium';
		$field['netPremium'] = 'netPremium';
		$field['return_quote_url'] = 'return_quote_url';

		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $field);
		$this->user_data['trans_code'] = $trans_code;
		$request = new Request($this->user_data);
		return $this->index($request);
		//return view('car.policy.unitedindia', $this->user_data);
	}
	/* Created by vivek ends here */


   	public function index(Request $request){
   		$trans_code = $request->trans_code;
   		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($trans_code);
		$rsgi_policy_manager = new RsgiPolicyManager;
   		$pb_data = $this->car_helper->getQuoteValue($request->input('trans_code'));
   		$user_data =  CarTData::find($request->trans_code);
   		$user_data = $this->car_helper->update_proposal_status($trans_code,'proposal_load');
   		$premium_breakup = $this->car_helper->getPremiumBreakup($user_data,$pb_data);
   		$this->trans_code = $request->trans_code;
   		$this->user_data = $rsgi_policy_manager->getDbData($this->trans_code); // retrive db data
   		$this->request_data = [];
   		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
   		// retrived db data
   		$predefinedData = $this->getPredefinedData($request);
   		$car_details = $this->car_helper->getCarBasicDetails($user_data);
   		unset($user_data);

   		$this->request_data['predefinedData'] = $predefinedData;
   		$this->request_data['predefinedData']['model_name'] = $car_details['model_name'];
   		$this->request_data['car_detail'] = $car_details;
		$this->request_data['car_detail']['trans_code'] = $this->trans_code;
   		$this->request_data['cmp_name'] = 'Royal Sundram';
   		$this->request_data['redirected'] = '';
		$this->request_data['nu_of_claim'] = $this->nu_of_claim;  //Added by vivek
   		$this->request_data['elect_ass'] = $this->elect_ass;
   		$this->request_data['non_elect_ass'] = $this->non_elect_ass;
   		$this->request_data['policy_type'] = $this->policy_type;
   		$this->request_data['type_of_finance'] = $this->type_of_finance;
   		$this->request_data['year_select'] = $this->carpolicybe->getYears($this->trans_code);
   		// set user data
   		$this->request_data['user_data'] = $this->user_data;
   		$this->request_data['vd'] = $this->vd;
		$stateCity = $this->getStateCity('125MO01PC5', '125');
   		$master_data = $rsgi_policy_manager->requiredData($this->required_master);
   		$this->request_data = array_merge($this->request_data,$master_data);
   		$this->request_data['perm_diff'] = (($this->request_data['user_data']['reg_add_is_same']) == 'N') ? '': 'checked';
   		$this->request_data['reg_add_is_same'] = (is_null(($this->request_data['user_data']['reg_add_is_same']))?'Y':$this->request_data['user_data']['reg_add_is_same']);
   		$this->request_data['requiredRollover'] = (strtolower($this->request_data['predefinedData']['typeOfBusiness']) == "rollover") ? "required" : "";
   		
   		$this->request_data = array_merge($this->request_data, $stateCity);
   		if(isset($this->request_data['user_data']['ownership_change'])){
   			if($this->request_data['user_data']['ownership_change'] == 'N'){
	   			$this->request_data['ownership_change_n'] = 'checked';
	   		} else {
	   			$this->request_data['ownership_change_y'] = 'checked';
	   			$this->request_data['predefinedData']['actual_ncb'] = $this->request_data['predefinedData']['ncb'];
	   			$this->request_data['predefinedData']['ncb'] = '0';
	   		}
   		} else {
   			$this->request_data['ownership_change_n'] = 'checked';
   		}
   		$this->request_data['nominee_rel'] = $this->nominee_rel;
   		$this->request_data['trans_code'] = $this->trans_code;
   		$this->request_data['fullname'] = (isset($this->user_data['firstname']) && isset($this->user_data['lastname']))?$this->user_data['firstname'].' '.$this->user_data['lastname']:'';
   		$this->request_data['modal_value'] = $premium_breakup;
   		return view('car.policy.royal_sundram',$this->request_data);
   	}

   	public function getPredefinedData($request){
   		$car_variant = new M\CarVariant;
   		$car_rsgi_idv = new M\CarRsgiIDV;
		$carcfgobj = new CarConfig;
        	$yor_select_start = $carcfgobj->getValue(Car_Constants::YOR_SELECT_START)[0]['config_value'];
   		$prev_tab_title = Car_Constants::PREV_TAB_TEXT_ROLLOVER;
		$prev_text = Car_Constants::PREV_TEXT_ROLLOVER;
		$trans_code = $request->trans_code;
   		$this->changeDateFormate();
   		$policyStartDate = $request->policyStartDate;
		$policyExpiryDate = $request->policyExpiryDate;
   		$carcfgobj = new CarConfig();
		$dob_min_age = $carcfgobj->getValue(Car_Constants::DOB_AGE_RESTRICTION)[0]['config_value'];
		$min_year = Carbon::now()->addYear(-$dob_min_age)->format('d/m/Y');
		$this->request_data['minYear'] = $min_year;
		/* Temp Data */
		if ($request->input('regDate')) {
			$regDate = $request->input('regDate');
		} else {
			$regDate = $request->input('car_registration_date');
		}
		if (date('Y', strtotime($regDate)) == $yor_select_start) {
			$prev_tab_title = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$prev_text = Car_Constants::PREV_TEXT_NEWBUSINESS;
			$typeOfBusiness = 'new_bussiness';
			$policyStartdate = date('Y-m-d', strtotime(str_replace("/", "-", $policyStartDate)));
		} else {
			$typeOfBusiness = 'rollover';
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $policyExpiryDate)));
			$policyStartDate = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
		}
		/* Temp Data ends here */
		$this->product_id = $request->input('product_id');
		$this->insurer_id = $request->input('insurer_id');
		$this->totalpremium = $request->input('totalpremium');
		$this->netPremium = $request->input('netPremium');
		$this->trans_code = $request->input('trans_code');
		$this->quote_id   = $request->quote_id;
		$this->return_quote_url = $request->input('return_quote_url');
		// $table = ['session_id' => $this->session_id,
		// 	'insurer_id' => $this->insurer_id,
		// 	'product_id' => $this->product_id,
		// 	'return_quote_url' => $this->return_quote_url,
		// 	'totalpremium' => $this->totalpremium,
		// 	'netPremium' => $this->netPremium,
		// 	'quote_id' => $this->quote_id
		// ];
		// CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);

		$car_helper = new CarHelper();


		$user_code = !empty(session('user_code'))?session('user_code'):NULL;
		$agent_store = new C\Customers\Customers();
		//$agent_store->agentUserCode($user_code);
		$agent_store->setModule('car');
		$agent_store->setUserCode($user_code);
		$agent_store->storeAgentCode($this->trans_code);
		
		$user_data = CarTData::find($trans_code);
		$car_details = $this->car_helper->getCarBasicDetails($user_data);
   		unset($user_data);

		$vehicleModelCode = $car_variant->getVehicleId($car_details['variant_code'],$this->refrel_variant_col)->{$this->refrel_variant_col};
		$regDate = $car_helper->changeFormat($regDate,'Y-m-d');
		return 	[
			        'refrel_col' => $this->refrel_variant_col,
					'typeOfBusiness'=>$typeOfBusiness,
					'regDate'=>$regDate,
					'totalpremium' =>  $this->totalpremium,
					'session_id' => $this->trans_code,
					'trans_code' => $this->trans_code,
					'product_id' => $this->product_id ,
					'year' => $request->year,
					'insurer_id' => $this->insurer_id,
					'regDate' => $regDate,
					'policyStartDate' => $policyStartDate,
					'policyExpiryDate' => $policyExpiryDate,
					'vehicleId' => $request->variant_code,
					'rto' =>  $request->rto,
					'idv' => $request->idv,
					'idv_opted' => $request->input('idv_opted'),
					'netPremium' => $this->netPremium,
					'engineCapacityAmount'=>$request->engineCapacityAmount,
					'ncb' => $request->new_ncb,
					'pre_ncb' => $request->ncb,
					'price' => $request->price,
					'sc' => '5',
//					'occupation' => 0,
					'prev_tab_title' => $prev_tab_title,
					'prev_text' => $prev_text,
					'prev_claim_status' => $request->claim, //Added by vivek
					'quote_id' =>$this->quote_id,
					'engine_cc' => $car_variant->fetchCC($car_details['variant_code'])->variant_cc.' CC',
					'fuelType'=>$car_details['fuel'],
					'vehicleModelCode' => $vehicleModelCode,
					'vehicleManufacturerName' => $car_rsgi_idv->getIdvValue($vehicleModelCode,'make')->make
		];
   	}

   	public function sendPolicyAppliedMail($result,$user_data,$proposal_req_json,$proposal_request_url,$proposal_form_result){
		try {
			if (isset($result['data']['result'])) {
				$data = $result['data']['result'];
			} else if (isset($result['data'])) {
				$data = $result['data'];
			} else if (isset($result['DATA'])) {
				$data = $result['DATA'];
			} else {
				$data['result'] = 'Api response is null';
			}
			
			$company_name =  'Royal Sundaram GI';

			$proposal_form_data = json_decode($proposal_req_json);
	
			$name = $proposal_form_data->proposerDetails->userName;
	        $client_email = $proposal_form_data->proposerDetails->strEmail;
			
			$proposal_request_url = $proposal_request_url;

			$user_code = !empty(session('user_code'))?session('user_code'):NULL;
			$agent_name = $this->car_helper->getAgentFromQuoteId();

			$internal_data = [
								'company_name'=>$company_name,
								'name'=>$name, 
								'client_email'=>$client_email,
								'data_value' => $data, 
								'proposal_form_data' => $proposal_form_data, 
								'proposal_request_url' => $proposal_request_url, 
								'proposal_form_result' => $proposal_form_result,
								'agent_name' => $agent_name
							];
			if (!empty($proposal_form_data)) {
				$subject = 'Car insurance policy hit for '.$company_name.' - '.$name;
				$view_email_internal = view('car.templates.proposal_payment_hit.internal_email', $internal_data);
				$mail_data = array('agent_email' => $this->car_helper->getAgentEmailQuoteId(),'proposal_form_data' => $proposal_form_data, 'subject'=>$subject,'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'content_internal' => $view_email_internal);
				$status = $this->email->proposalHitMail($mail_data);
			} 
		} catch (\Exception $e) {
			Log::info("CAR - RSGI - Email sending to admin for the buy policy details in policy page failed".$e->getMessage());
		} 
	}

	public function getPolicy(Request $request){
		// $session_id = $request->session_id;
		$trans_code = $request->trans_code;
		$car_helper = new CarHelper;
		$car_policy_be = new CarPolicyBe;
		$payment_parse_be = new PaymentParseBE;
		
		$user_data =  CarTData::find($trans_code);
        // $validation_arr = $this->validate_data($user_data);
        // if($validation_arr["verror"]){ 
        //     return response()->json( ["error" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
        // } 

		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit');
		Log::info('CAR RSGI PROPOSAL TRANS_CODE '.$trans_code);
		$car_helper->setSuid($trans_code);
		$data = $request->all();
		$car_lib = new CarLib;
		$rsgi_helper = new RsgiHelper;
		$maximum_call = Car_Constants::MAXIUM_CALL_API;
		$rsgi_policy_manager = new RsgiPolicyManager();
		manipulateResult: 
		$this->proposer_request = $rsgi_policy_manager->setData($data,$user_data);
		$current_premium = $data['totalpremium'];

		if($user_data->covers_selected)
			$this->setCovers($user_data->covers_selected,'true');
		
		

		$this->proposer_request['vehicleDetails']['modified_idv_value'] = $this->proposer_request['vehicleDetails']['idv'];
		$this->proposer_request['vehicleDetails']['totalIdv'] = $this->proposer_request['vehicleDetails']['idv'];
		$url = Car_Constants::RSGI_QUOTE_UPDATE_URL;
		$proposal_req_json = json_encode($this->proposer_request, true);

		if(isset($data['previousPolicyType'])){
			if($data['previousPolicyType'] == 'L'){
				session()->put('flash_msg','Since your previous policy was a liability on policy, your car has to be inspected first before issuing a comprehensive policy!');
				session()->save();
				echo 'L';
				die;  // Kept to pass it on error page
			} else {
				$data['previousPolicyType'] = 'Comprehensive';
			}
		}
		if((isset($this->proposer_request['vehicleDetails']['claimAmountReceived'])) && ($this->proposer_request['vehicleDetails']['claimAmountReceived'] > 100000)){
		 echo 	route('car.policy.badresponse');
		 die;
		}
		$result = $rsgi_helper->callRsgiUpdateQuoteApi($url,$this->proposer_request,$trans_code);
		// if response null than recall only one time
		(!isset($result['DATA']) and !isset($result['error'])) &&
			($result = $rsgi_helper->callRsgiUpdateQuoteApi($url,$this->proposer_request,$trans_code));
		
		// if found any error display it 
		if(isset($result['error'])){
			echo json_encode($result); die;
		}

		if(!$result || (!isset($result['DATA']) and !isset($result['error']))){
			echo 'Got null in proposal response from API';
			die;
		}

		
		// store request id in the car_t_userdata
		$storeRequestId = $car_lib->storeRequestId($result);
		
		if ($storeRequestId != 1) {
			return $storeRequestId;
		}

		$proposal_form_result = $result;

		// call api for payment process and proposal service
		// if you get proper result 
		if($result['DATA']['PREMIUM'] == $current_premium){
				$pm = [];
		}else{
			if (!$car_policy_be->needConfirmation($result['DATA']['PREMIUM']
				,$current_premium)) {
				logger("Call is" . $maximum_call);
				$data['totalpremium'] = $result['DATA']['PREMIUM'];
				if ($maximum_call) {
					$maximum_call--;
					goto manipulateResult;
				}
			}else{
				$user_data->final_premium = $result['DATA']['PREMIUM'];
				$user_data->save();
				$pm["premiumPayable"] = $result['DATA']['PREMIUM'];
				$pm["passedPremium"] = $current_premium;
				$pm["error"] = "Premium mismatch";	
			}
		}

		/*
			Send email to admin when a buyer click on Finish button in policy page
		*/
		
		$this->sendPolicyAppliedMail($result,
				$user_data,
				$proposal_req_json,
				$request->headers->get('referer'),
				$proposal_form_result);

		/*
			Email functionality ends here
		*/

			if(isset($result['error'])){
				echo "Error hey";
			    die;
			}
			else
			{
				$fields = [];
				$fields['premium'] = $result['DATA']['PREMIUM'];
				$fields['quoteId'] = $result['DATA']['QUOTE_ID'];
				$fields['strEmail'] = $this->proposer_request['proposerDetails']['strEmail'];
				$result = $rsgi_helper->callRsgiProposalServiceApi($fields,$trans_code);
				if(isset($result['error'])){
					Log::error($result['error']);
					echo "Error  ";
					$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',['msg'=>$result['error']]);
			    	die;
				}else{
					$fields = [];
					$data = $result['PREMIUMDETAILS']['DATA'];
					$result = [];
					$result['url'] = Car_Constants::RSGI_PAYMENT_URL;
					$result['field']['reqType'] = 'JSON';
					$result['field']['paymentOption'] = 'process';
					$result['field']['apikey'] = Car_Constants::RSGI_API_KEY;
					$result['field']['agentId'] = Car_Constants::RSGI_AGENT_CODE;
					$result['field']['premium'] =  $data['PREMIUM'];
					$result['field']['quoteId'] = $data['QUOTE_ID'];
					$result['field']['version_no'] = $data['VERSION_NO'];
					$result['field']['strEmail'] = $data['EMAIL'];
					$result['field']['isQuickRenew'] = '';
					$result['field']['crossSellProduct'] = '';
					$result['field']['crossSellQuoteid'] = '';
					$result['field']['elc_value'] = '';
					$result['field']['nonelc_value'] = '';
					$result['field']['vehicleSubLine'] = 'privatePassengerCar';
					$result['field']['returnUrl'] = url('/').'/car-insurance/rsgi/payment/status';
					$result['field']['paymentType'] = 'billDesk';
					$result['field']['strFirstName'] =
					$this->proposer_request['proposerDetails']['strFirstName'];
					$result = array_merge($result,$pm);
					Log::info('CAR RSGI Payment Request - '.$trans_code.' - ',$result);
					$payment_parse_be->setPaymentIdentifier($trans_code,$data['QUOTE_ID']);
					$user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted');
					echo json_encode($result,true);
					die;
			}
		}
		
	}

	private function validate_data($usr_data){
        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->usr_mobile,
                            'customer_name' => $usr_data->usr_firstname.' '.$usr_data->usr_lastname,
                            'pc_customer_dob' => $usr_data->usr_dob,
                            'pc_customer_aadharno' => $usr_data->usr_aadharno,
                            'customer_email' => $usr_data->usr_email,
                            'customer_add1' => $usr_data->usr_houseno,
                            'customer_add2' => $usr_data->usr_street,
                            'customer_add3' => $usr_data->usr_locality,
                            'customer_pincode' => $usr_data->usr_pincode,
                            'pc_reg_no' => $usr_data->veh_reg_no,
                            'pc_engine_no' => $usr_data->veh_eng_no,
                            'pc_chasis_no' => $usr_data->veh_chassisno,
                            'pc_pre_policy' => $usr_data->prev_policyno,
                            'nominee_name' => $usr_data->nominee_name
                            // '' => 
                            // previnsurance_addr
                            // prev_policyno
                            // usr_occupation
                        ];
        if($usr_data->veh_vehicle_financed == 'Y'){
        	$required_array['empty'] = [$usr_data->veh_type_of_finance,$usr_data->veh_financierName];
        }
        return $valid_lib->proposalSubmit($required_array);
    }

	public function returnPage(Request $request)
	{	
		$data = $request->all();
		$ref_data = explode("|",$data['BDresmsg']);
		$payment_parse_be = new PaymentParseBE;
		$trans_code = $payment_parse_be->getPaymentIdentifier($data['quoteId']);
		
		$car_helper = new CarHelper;
		// $trans_code = $this->car_helper->getSuid();
		Log::info('CAR RSGI PAYMENT TRANS_CODE '.$trans_code);
		$rsgi_policy_manager = new RsgiPolicyManager();
		$car_t_data = CarTData::find($trans_code.'_DONE');
		
		// allready entry than
		if($car_t_data){
			$data['policy_nu'] = $car_t_data->policy_nu;
			$data_main = ['status' => $car_t_data->t_status,
						  'logo' => Car_Constants::LOGO['rsgi'],
						  'udata'=>$data];
						  
			return view('car.return_page.rsgi', $data_main);
		}


		Log::info('Car RSGI Payment URI - '.$trans_code.' - '.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]);
		
		Log::info('Car RSGI Payment Log - '.$trans_code.' - ',$data);
		
		$car_lib = new CarLib;
		// by default status is 0 (FAIL)
		$status = (isset($data['status']) && $data['status'] == 'success') ? 1 : 0 ;		
		
		$car_helper->log_payment_result($trans_code,$status,['msg'=>$ref_data[24]]);
		
		// store transaction detail
		$table = ['trans_code' => $trans_code,
				 Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($data),
				 Car_Constants::CAR_T_PROPOSALLOG['TRANSACTION_ID'] => $ref_data[2]

			    ];

	    // if policy no is
	    if(isset($data['policyNO']))
			$table[Car_Constants::CAR_T_PROPOSALLOG['POLICY_NU']] = $data['policyNO'];		    
		$car_t_data = CarTData::find($table['trans_code']);
		$car_transaction = $car_t_data->update($table);
		$car_helper->log_policy_result($trans_code,$status);
		$data['policy_nu'] = (isset($data['policyNO'])) ? $data['policyNO'] : $ref_data['2'];
		// pass to view 
		$data_main = ['status' => $status, 'logo' => Car_Constants::LOGO['rsgi'],'udata'=>$data];	
		// change payment  flag
		$t_status = ($status) ? 1 : 2;
		$user_data = $car_lib->storeStatus($t_status,$trans_code);
		// if payment success insert into tarnsaction table
		$rsgi_policy_manager->insertIntoTranscation($user_data,$trans_code);
		try {
		
		} catch (\Exception $e) {
			Log::info($e->getMessage());
		} finally {
			return view('car.return_page.rsgi', $data_main);
		}
	}

	private function changeDateFormate() {
		$car_helper = new CarHelper;
		$rsgi_policy_manager = new RsgiPolicyManager;
		if (!empty($this->user_data)) {
			$field_name = $car_helper->getFieldName('PROPOSER', 'USR_DOB');
			$this->user_data[$field_name] = (isset($this->user_data[$field_name])) ?
			$this->car_helper->getFormDate($this->user_data[$field_name]) : null;
		}
	}

	private function setCovers($data,$filter){
		$valu_chc = explode(',',$data);
		$covers = [];
		$array_filer_addon = array('ZERODEP'=>'hdnDepreciation','EP'=>'hdnProtector','NCBPROTECT'=>'hdnNCBProtector','RSAC'=>'rsac','RTI'=>'hdnInvoicePrice','PAPASS'=>'personalAccidentCoverForUnnamedPassengers');
		foreach ($valu_chc as $key => $value) {
			//array_key_exists($value,$array_filer_addon)
			if(array_key_exists($value,$array_filer_addon))
				if($value === 'PAPASS'){
					$this->proposer_request['vehicleDetails'][$array_filer_addon[$value]] = 100000;
					$this->proposer_request['vehicleDetails'][strtolower($array_filer_addon[$value])] = 100000;
				} else {
					$this->proposer_request['vehicleDetails'][$array_filer_addon[$value]] = ($filter === 'true') ? 'true' : 'false';
				}
		}
	}

	public function getApiMasters(Request $request) {
		$master = $request->master;
		$stateid = $request->stateid;
		$refrel_col = $this->refrel_col;
		if ($master == "City") {
			$refrel_col = $this->refrel_variant_col;
			return \App\Models\Car\MasterCity::getCity($refrel_col, $request->stateid);
		} else {
			return $this->car_helper->getMasterData($refrel_col, $master);
		}
	}

	private function getStateCity() {
		$refrer_col = $this->refrel_variant_col;
		$rsgi_policy_manager = new RsgiPolicyManager;
		$car_helper = new CarHelper;
		$state['data']['result'] = $this->car_helper->getMasterData($refrer_col, 'State');
		if (!empty($state['data']['result'])) {
			$state = $state['data']['result'];
			$field_name = $car_helper->getFieldName('COMMUNICATION', 'USR_STATE_CODE');
			$state_id = (isset($this->user_data[$field_name])) ?
			$this->user_data[$field_name] : $state[0]['id'];
			$field_name = 'perm_statecode';
			$perm_state_id = (isset($this->user_data[$field_name])) ?
			$this->user_data[$field_name] : $state[0]['id'];
			return ['state' => $state
			, 'city' =>$this->getCity($state_id)
			,'perm_city'=>$this->getCity($perm_state_id)];
		}
	}

   	private function getCity($state_id){
   		 return $this->car_helper->getMasterCity($this->refrel_variant_col, 'City', $state_id);
   	}

	public function getQuoteFieldMap($map_for = null) {
		$fields = [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
			Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_USERLOG['USR_AADHARNO'] => "aadharno",
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
			Car_Constants::CAR_T_QUOTELOG['OPTED_IDV'] => 'idv_opted',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
			Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_ID'] =>'quote_id'
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}
}
