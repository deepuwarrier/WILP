<?php
namespace App\Http\Controllers\Car\Policy;

use App\Be\Car\CarPolicyBe;
use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use App\Helpers\Car as H;
use App\Http\Controllers\Controller;
use App\Http\Controllers\EmailSender;
use App\Libraries\CarLib;
use App\Http\Controllers as C;
use App\Models\Car as M;
use App\Models\Car\CarTData;
use App\Models\Car\CarTPolicy;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Helpers\Car\TATA\TataProposalManager;
use App\Helpers\Car\TATA\AccountingRequest;
use Illuminate\Support\Facades\Log;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;
use App\Be\Car\CarQuoteBe;
use App\Be\Car\TataQuoteBe;
use App\Helpers\Car\TATA\ProposalManager;

class TataAig extends Controller {
	public $policy_service_url = Car_Constants::TATA_POLICY_URL;
	public $policy_pdf_url = Car_Constants::TATA_POLICY_PDF_URL;
	public $src = Car_Constants::TATA_SRC;
	public $T = Car_Constants::TATA_TOKEN;
	
	public function __construct() {
		$this->proposal_man = new H\TATA\TataProposalManager();
		$this->test = 0;
		$this->email = new EmailSender;
		$this->car_helper = new CarHelper;
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->title = Car_Constants::TITLE;
		$this->required_master = Car_Constants::UI_MASTER;
		$this->refrel_col = "tata_code";
		$this->refrel_variant_col = "tata_code";
	}

	public function callIndex() {
		if (!empty(session('request'))) {
			$request = new Request(session('request'));
			return $this->index($request);
		}
	}

	/* Created by vivek */
	public function loadProposalUrl(Request $request,$trans_code){
		$car_t_data = new CarTData;
		$request->trans_code = $trans_code;
		$this->car_helper->storeIp($request);
		$this->car_helper->checkTransaction($trans_code);
		$user_data = $car_t_data->find($trans_code);
		$field = $this->car_helper->getQuoteFieldMap();
		$field['insurer_id'] = 'insurer_id';
		$field['product_id'] = 'product_id';
		$field['totalpremium'] = 'totalpremium';
		$field['netPremium'] = 'netPremium';
		$field['return_quote_url'] = 'return_quote_url';
		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $field);
		// $this->user_data['session_id'] = $sessionid;
		$this->user_data['trans_code'] = $trans_code;
		// if ($sessionid != session()->getId())
		// 	$this->proposal_man->redirect = 1;
		$request = new Request($this->user_data);
		return $this->index($request);
	}
	
	private function getQuote($trans_code,$user_data = NULL){
		$tataquotebe = new TataQuoteBe;
		$idv_details = $this->getIDVData($trans_code,$user_data);
		$tataquotebe->setSelectedCovers("");
		$data = $tataquotebe->tataQuoteCall($idv_details);
		return $data;
	}

	public function index(Request $request) {
		$request_data = $request->all();
		$trans_code = $request_data['trans_code'];
		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($request_data['trans_code']);
		$pb_data = $this->car_helper->getQuoteValue($trans_code);
    	$user_data = CarTData::find($trans_code);
    	$user_data = $this->car_helper->update_proposal_status($trans_code,'proposal_load');
   		$premium_breakup = $this->car_helper->getPremiumBreakup($user_data,$pb_data);

		$trans_code = $request_data['trans_code'];
		$car_m_products = new M\CarProducts;
		$master_data = new M\Data\MasterData();
		$pincode_list = $master_data->getPincodeList($user_data['usr_city_code']);
		$tata_product_details = $car_m_products->getTataProductDetails();
		$data = $this->proposal_man->getProposalFormData($request_data);
		$data['logo'] = $tata_product_details[$data['predefinedData']['product_id']]['product_img'];
		$data['modal_value'] = $premium_breakup;
		$data['pincode_list'] = $pincode_list;
   		return view('car.policy.tata', $data);
	}

	private function getIDVData($trans_code,$user_data = null){
		$carQuoteBe = new CarQuoteBe;
		if(!isset($user_data))
			$user_data =  CarTData::find($trans_code);
		$idv_data = $carQuoteBe->getCarDetails($user_data);
		$idv_data['selected_chcks'] = $idv_data['cov'];
		unset($user_data);
		unset($carQuoteBe);
		return $idv_data;
	}

	public function getPolicy(Request $request) {
		$car_t_data = new CarTData;
		$car_helper  = new CarHelper;
		$trans_code = $request->trans_code;
		$this->car_helper->storeUserLoginId();
		$data = $request->all();
		$user_data = $car_t_data->find($trans_code);
		// check validation
		// $validation_arr = $this->validate_data($user_data);
  //       if($validation_arr["verror"]){ 
  //           return response()->json( ["error" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
  //       } 
        
        $quote_data = [];

        // if($user_data->veh_electricle || $user_data->veh_no_electricle || ($user_data->veh_cng_external == 'Y')){
        	$tataquotebe = new TataQuoteBe;
			$idv_details = $this->getIDVData($trans_code,$user_data);
			$quote_data = $tataquotebe->tataQuoteCallMismatch($idv_details,$request->product_id);
        // }

		if(isset($user_data->prev_policy_type) && $user_data->prev_policy_type == 'L'){
			session()->put('flash_msg','Since your previous policy was a liability on policy, your car has to be inspected first before issuing a comprehensive policy!');
				session()->save();
				return response()->json($user_data->prev_policy_type);
		}
        
        // check wether premium is new 
        if(!isset($data['new_premium'])){
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit');
			$premium = $user_data->totalpremium;
		}else{
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit_new_premium');
			$premium = $user_data->final_premium;
		}

		// if new quote genrated 
		if($quote_data && !empty($quote_data)){
        	$new_premium = $quote_data[$user_data->product_id]['totalpremium'];
        	if($new_premium != $premium){
            	$user_data->final_premium = $new_premium;
            	$user_data->save();
            	$response = ['error'=>'premium mismatch',
                    'premiumPayable'=>$new_premium,
                    'passedPremium'=>$premium];   
            	$this->updateProposalResponse($car_helper,$trans_code,$response);
            	return response()->json($response);
        	}
        }


		$proposal_man = new ProposalManager();
		$proposal_req = $proposal_man->genProposalRequest($user_data);
		$proposal_res = $proposal_man->callProposal($proposal_req,$trans_code);
		$response  =  $proposal_man->getProposalResponse($proposal_res);

		// update the response
		$this->updateProposalResponse($car_helper,$trans_code,$response);
		
		// if error return the errror 
		if(array_key_exists('error',$response))
			return response()->json($response);
		
		$user_data->proposal_nu = $response['data']['proposalno'];
		$user_data->quote_id = $response['data']['quotationno'];
		$user_data->proposal_ref_number = $response['refno'];
		$user_data->save();
		
		$payment_resp = $proposal_man->genPaymentResuest($user_data,$response);

		
		$user_data->transaction_id = $payment_resp['fields']['pgiRequest']['transactionID'];
		$user_data->policy_nu = $payment_resp['fields']['pgiRequest']['policyNumber'];
		$user_data->save();
		$str = json_encode($payment_resp['fields']['pgiRequest']);
		$payment_resp['fields']['pgiRequest'] = base64_encode($str); 
		Log::info('Tata Payment Request',$payment_resp);
		return response()->json($payment_resp);
	}

	private function validate_data($usr_data){
        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->usr_mobile,
                            'customer_name' => $usr_data->usr_firstname.' '.$usr_data->usr_lastname,
                            'pc_customer_dob' => $usr_data->usr_dob,
                            'customer_panno' => $usr_data->usr_pan,
                            'pc_customer_aadharno' => $usr_data->usr_aadharno,
                            'customer_email' => $usr_data->usr_email,
                            'customer_add1' => $usr_data->usr_houseno,
                            'customer_add2' => $usr_data->usr_street,
                            'customer_add3' => $usr_data->usr_locality,
                            'customer_pincode' => $usr_data->usr_pincode,
                            'pc_engine_no' => $usr_data->veh_eng_no,
                            'pc_chasis_no' => $usr_data->veh_chassisno,
                            'pc_pre_policy' => $usr_data->prev_policyno,
                            'nominee_name' => $usr_data->nominee_name,
                            'number' => $usr_data->nominee_age
                        ];
        if($usr_data->type_of_business != 'New Business'){
        	$required_array['pc_reg_no'] = $usr_data->veh_reg_no;
        }
        if($usr_data->usr_type == 'O'){
            $required_array['customer_gstin'] = $usr_data->gstin;
        }

        if($usr_data->veh_cng_external == 'Y'){
        	$required_array['empty'][] =	$usr_data->veh_cng_external_value; 
        }

        if($usr_data->veh_vehicle_financed == 'Y'){
        	$required_array['empty'][] =	$usr_data->veh_type_of_finance;
			$required_array['empty'][] =	$usr_data->veh_financierName; 	
        }

        return $valid_lib->proposalSubmit($required_array);
    }

	private function updateProposalResponse($car_helper,$trans_code,$response){
		if(array_key_exists('error',$response))
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',['msg'=>$response['error']]);
    	else if(array_key_exists('proposal_error',$response))
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_error',['msg'=>$response['proposal_error']]);
    	else
    		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted',['ref_no'=>$response['data']['proposalno']]);
	}

	public function getVehicleId($variant_code){
		$car_variant = new M\CarVariant;
		$ref_col = $this->refrel_variant_col;
		return $car_variant>getVehicleId($variant_code,$ref_col)->$ref_col;
	}

	public function getApiMasters(Request $request) {
		$master = $request->master;
		$refrel_col = $this->refrel_col;
		if ($master == "City") {
			$master_city = new \App\Models\Car\MasterCity;
			return $master_city->getCity($refrel_col, $request->stateid);
		} else {
			return $this->car_helper->getMasterData($refrel_col, $master);
		}
	}

	
	public function returnPage(Request $request){
		$car_helper = new CarHelper;
		$proposal_man =  new ProposalManager;
		$response = $request->input('pgiResponse');
		Log::info("CAR TATA Payment base64 encoded Response : ".$response);
		$payment_resp = base64_decode($response);
		// $payment_resp = '{"consumerAppTransId":"PC1806141749296429","bankId":"OTH","cardType":"Visa","consumerAppId":"TTIB01","paymentMode":"OTH","premiumAmount":"1.0","responseCode":"0","responseDescription":"Success","pgiTransactionid":"5046979","gatewayTxnid":"NCTR6388552916","gatewayName":"BillDesk","transactionStatus":"Success","txnEndTime":"Jun 13, 2018 04:15:13 PM","chequeType":"NA"}  ';
		$payment_resp = json_decode($payment_resp,true);
		Log::info($request->fullUrl()); 
		Log::info("CAR TATA Payment Response : ".json_encode($payment_resp));

		// $trans_code = $car_helper->getSuid();
		$payment_parse_be = new PaymentParseBE;
		$trans_code = $payment_parse_be->getPaymentIdentifier($payment_resp['consumerAppTransId']);
		$user_data = CarTData::find($trans_code);
		
		if(!$user_data){
			$user_data = CarTData::find($trans_code.'_DONE');
			$data = ['status' => 1,
			     'logo' => Car_Constants::LOGO['tata'], 
				 'udata' => ['ref_no'=>$user_data->policy_nu]];		
			return view('car.return_page.tata', $data);	
		}
		
		// $payment_resp = '{
		// 		"consumerAppTransId": "SID61000019292",	"bankId": "Master ",	"cardType": "Master ",	"consumerAppId": "WEB001",	"paymentMode": "DC",	"premiumAmount": "886.0",	"responseCode": "1",	"responseDescription": "Incorrect card details,Please try again or use another mode of payment",	"pgiTransactionid": "3633",	"gatewayTxnid": "LHMP6073770171",	"gatewayName": "BillDesk",	"transactionStatus": "Success",	"chequeType": "NA"
		// 	}';
			
		
		$pay_status = 0;
		if($payment_resp['transactionStatus'] != 'Failure'){
			$pay_status = 1;
			$policy_details  = $this->generatePolicy($payment_resp,$user_data);
			$policy_nu  = $policy_details['data']['policyno'];
			$key 		= $policy_details['data']['rnd_str'];
			/*
		https://pipuat.tataaiginsurance.in/tagichubws/twpolicyschedule.jsp?polno=064001/0177550347/000000/00&src=app&key=zcmkV5rR0fczX8R3X2pnUz1NL
		*/
			$data['download_link'] =  $this->policy_pdf_url.$policy_nu."&src=app&key=".$key;
		} else {
			$policy_nu = '';
		}

		$car_helper->log_payment_result($trans_code,$pay_status,
			['msg'=>$payment_resp['responseDescription'],'ref_no'=>$payment_resp['gatewayTxnid']]);
		$car_helper->log_policy_result($trans_code,$pay_status,
			['msg'=>$payment_resp['responseDescription'],'ref_no'=>$user_data->policy_nu]);


		$table = ['ref_no'=>$policy_nu,
				 'transaction_id'=>$user_data->transaction_id];

		$data = ['status' => $pay_status,
				 'logo' => Car_Constants::LOGO['tataaig'], 
				 'udata' => $table,
				 'download_link' => !empty($data['download_link'])?$data['download_link']:null
				];
		$proposal_man->storeStatusAndTransaction($pay_status,$trans_code);
		
		// $data['download_link'] = $this->manager->getPolicyPdfUrl($car_t_data->policy_nu);
		return view('car.return_page.tata', $data);	
		
	}

	public function generatePolicy($response,$user_data){
		// dd($response,$user_data);
		/*
			{
			  "paymenttype": "manual",
			  "proposalno": "PHP/3121/0000001418",
			  "source": "TP",
			  "transno": "PC1528886559382",
			  "transdate": "20180613",
			  "premiumamt": "22125.0",
			  "paydat": "20180613"
			}
			{"paymenttype":"manual","proposalno":"PHP/3121/0000001431","source":"TP","transno":"PC1806141415110997","transdate":"20180613","premiumamt":22125.0,"paydat":"20180613"}
		*/
		$request_data = [
							"paymenttype"	=>	'manual',
							"proposalno"	=>	$user_data->proposal_nu,
							"source"	=>	$this->src,
							"transno"	=>	$response['gatewayTxnid'],//$user_data->trans_code,
							"transdate"	=>	date('Ymd',strtotime($response['txnEndTime'])),
							"premiumamt"	=>	''.((empty($user_data->final_premium))?$user_data->totalpremium:$user_data->final_premium),
							"paydat"	=>	date('Ymd',strtotime($response['txnEndTime']))
						];
		$postFields = 	[
						'T'	=>	$this->T,
						'PDATA'	=>	json_encode($request_data)
					];
		$car_h = new CarHelper;
		$title = "TATA Policy";
		$url = $this->policy_service_url;
		
		$config['content-type'] = "application/x-www-form-urlencoded";
		$config['post-type'] = "http";
		$proposal_man = new ProposalManager();
		$policy_response = $proposal_man->call_curl_api($title,$url, $postFields,$config,$user_data->trans_code);
		return json_decode($policy_response['data'],true);
	//policy_nu	
	}

	public function tata_policy_pdf($policy_nu){
		if(!isset($this->proposal_man))
			$this->proposal_man = new H\TATA\TataProposalManager();
		$user_data =  CarTPolicy::where('policy_nu',$policy_nu)->first();
		return $this->proposal_man->genPolicyPdf($user_data);
		
	}

	public function getStatus(Request $request){
		$car_helper = new CarHelper;
		$data = $request->all();
		$trans_code = $data['trans_code'];
		$product_id = $data['product_id'];
		$prev_addon_selected = [];
		// $check_prev_addon = ['zerodep' =>$data['prevzerodep'],'ts'=>$data['prevts'],'ep'=>$data['prevep'],'rti'=>$data['prevrti']];
		$check_prev_addon = [
								'zerodep' 	=>	isset($data['prevzerodep'])?$data['prevzerodep']:null,
								'ts'		=>	isset($data['prevts'])?$data['prevts']:null,
								'ep'		=>	isset($data['prevep'])?$data['prevep']:null,
								'rti'		=>	isset($data['prevrti'])?$data['prevrti']:null
							];
		foreach ($check_prev_addon as $key => $value) {
			if(($value === 'N') && (!is_null($value))){
				$prev_addon_selected[] = $key;
			}
		}
		$car_t_data = new CarTData;
		$user_data = $car_t_data->find($data['trans_code']);
		$covers = explode(',',$user_data->covers_selected);
		$addon = json_decode($user_data->prev_addons,true);//['zerodep','ts','ep','rti'];
		$packages = Car_Constants::TATA_PACKAGES;

		foreach ($packages as $key => $value) {
			$contains = (count(array_diff($prev_addon_selected, $value['addon'])) == count($prev_addon_selected));
			if($contains){
				$package_addon_contain = $key;
			}
		}
		// $return_tata_packages = !empty($car_helper->getSessionValue($trans_code)['tata_return_data'])?$car_helper->getSessionValue($trans_code)['tata_return_data']:[];
		if(!empty($prev_addon_selected)){
			$display_name_status = [];
			$display_name = Car_Constants::TATA_DISPLAY_NAME;
			foreach ($prev_addon_selected as $key => $value) {
				$display_name_status[$value] = $display_name['basic'][$value];
			}
			$package_name = $packages[$package_addon_contain]['package'];
			$html = view('car/status/tata_status',[	
													'display_name'=>implode(',',$display_name_status),
													'package_name' => $package_name,
													'package_addon_contain' =>$package_addon_contain,
													'trans_code' => $trans_code,
													'return_quote_url'=>$data['return_quote_url']
													])->render();
			// $car_helper->setSuid($trans_code);
			return response()->json(['html' => $html]);
		}else{
			return response()->json(['addon_excluded'=>'']);
		}
		
	}

	public function checkExternalCngValue(Request $request){
		$external_cng_kit_value = isset($request->e_cng_value)?$request->e_cng_value:0;
		if($external_cng_kit_value > 50000){
			$html = view('car/status/external_cng_status',[
															'return_quote_url'=>$request->return_quote_url,
															'trans_code' => $request->trans_code
													])->render();
			return response()->json(['html' => $html]);
		}else{
			return response()->json(['external_cng_approved'=>'']);
		}
	}

	public function proposalError(Request $request){
		$payment_parse_be = new PaymentParseBE;
		$trans_code = $request->trans_code;
		$error_type = isset($request->proposal_error_type)?$request->proposal_error_type:'';
		$display_name = isset($request->display_name)?$request->display_name:'';
		$car_helper = new CarHelper;
		// send mail for error 
		$car_m_products = new M\CarProducts;
		// $trans_code = 	!empty($car_helper->getSuid())?$car_helper->getSuid():$request->trans_code;
		$user_data = CarTData::find(['trans_code'=>$trans_code]);
		$logo = null;
		if($user_data && isset($user_data[0]['product_id'])){
			$product_id = $user_data[0]['product_id'];
			$insurer_id = $user_data[0]['insurer_id'];
			$company_details = $car_m_products->getCompProductDetails($product_id);
			$logo_name = $company_details[$product_id]['product_img'];
			$logo = \URL::asset(asset('image/logos/').'/'.$logo_name);
			/*
			if(array_key_exists($insurer_id,Car_Constants::CMP_LOGO))
				$logo = \URL::asset(Car_Constants::CMP_LOGO[$insurer_id]);
			else
				$logo = \URL::asset('image/logos/')."/".$insurer_id.".png";
			*/
		}
				 
		switch ($error_type) {
			case 'cng_external_no':
				$msg = 'Since your External CNG Kit value is above 50,000 you cannot buy this policy online. ';
				/*$footer_msg = '<h5>You will be contacted by a representative of TATA Insurance Company shortly.</h5>
							  <h6>For any queries contact InstaInsure at: +91 7899-000-333</h6>';	*/
				$footer_msg = '';
				break;
			case 'addon_include_proposal_no':
				$msg = 'Since you dont have '.$display_name.' in your previous policy, you cannot buy this package online.';
				$footer_msg = '';
				break;
			
			default:
				$msg = (session('flash_msg') != '')? session('flash_msg') : 'Transferred to a Offline Team';
				$footer_msg = (session('footer_msg') != '')? session('footer_msg') : null;	
				session()->forget('flash_msg');
				session()->forget('footer_msg');
				break;
		}
		return view('car.policy.proposal_error_page',['msg'=>$msg,'TRN'=>$trans_code,'footer_msg'=>$footer_msg,'logo'=>$logo]);
	}

	public function checkprevaddon(Request $request){
		$data = $request->all();
		$trans_code = $data['trans_code'];
		$product_id = $data['product_id'];
		$prev_addon_selected = [];
		switch ($product_id) {
			case 'tata_sapphire_pp':
				$prev_addon_selected = ['ZERODEP','TS','RTI','EP'];
				break;
			case 'tata_sapphire_p':
				$prev_addon_selected = ['ZERODEP','TS','EP'];
				break;
			case 'tata_sapphire':
				$prev_addon_selected = ['ZERODEP','TS'];
				break;
			case 'tata_pearl_p':
				$prev_addon_selected = ['ZERODEP','EP'];
				break;
			case 'tata_pearl':
				$prev_addon_selected = ['ZERODEP'];
				break;
			default:
				$prev_addon_selected = [];
				break;
		}
		$packages = Car_Constants::TATA_PACKAGES;
		if(!empty($prev_addon_selected)){
			$display_name_status = [];
			$display_name = Car_Constants::TATA_DISPLAY_NAME;
			foreach ($prev_addon_selected as $key => $value) {
				$display_name_status[$value] = $display_name['basic'][strtolower($value)];
			}
			$package_name = $packages[$product_id]['package'];
			$html = view('car/status/tata_quote_status',[	
													'display_name'=>implode(', ',$display_name_status),
													'package_name' => $package_name,
													'package_addon_contain' =>$product_id,
													'trans_code' => $trans_code,
													'return_quote_url'=>null
													])->render();
			return response()->json(['html' => $html]);
		}else{
			return response()->json(['addon_excluded'=>'']);
		}
	}
}
?>
