<?php
namespace App\Http\Controllers\Car\Policy\UAT;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Car\CarHelper;
use App\Be\Car\CarPolicyBe;
use App\Libraries\CarLib;
use App\Models\Car\CarTData;
use App\Constants\Car_Constants;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\PolicyPageData;
use App\Helpers\Car\BAJAJ\BajajManager;

// master
use App\Models\Car\MasterState;
use App\Models\Car\MasterFinancier;
use App\Models\Car\MasterNomineeRelationship;
use App\Models\Car\MasterCity;
use App\Models\Car\MasterInsurer;

class BajajAllianz extends Controller{

	public function __construct(){
		$this->manager = new BajajManager();	
		$this->redirect = 0;	
	}

	public function index(Request $request,$trans_code = null){
		$request_data = $request->all();
		$trans_code = isset($request_data['trans_code'])?$request_data['trans_code']:$trans_code;
		$user_data = CarTData::find($trans_code);
		$car_helper = new CarHelper;
		$user_data = $car_helper->update_proposal_status($trans_code,'proposal_load');
		
		$pb_data = $car_helper->getQuoteValue($trans_code);
        $premium_breakup = $car_helper->getPremiumBreakup($user_data,$pb_data);
        
        if(!isset($trans_code))
			$trans_code = $request_data['session_id'];
	
		return redirect('https://general.bajajallianz.com/MotorInsurance/onlineportal/motorNew/indexCar.jsp?p_product_code=1801&src=CBM_02641');
		
		$policy_page_data = new PolicyPageData($user_data);
		$policy_page_data->setRefrelCol('bajaj_code');
		
		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
		$policy_page_data->setMinYear($this->carpolicybe->getMinYear());
		$policy_page_data->setManfYearList($this->carpolicybe->getYears($trans_code));

		$stateDb = new MasterState();
		$policy_page_data->setStateList($stateDb->getStateList());
		
		$insurerDb = new MasterInsurer();
		$insurer_list = $insurerDb->getInsurerList($this->manager->refrel_code);
		$policy_page_data->setInsurerList($insurer_list);
		$policy_page_data->setTypeOfFinanceList(Car_Constants::TYPE_OF_FINANCE);

		$user_data_list = $this->manager->getDbData($user_data);
		
		if(isset($user_data_list['statecode'])){
			$cityDb = new MasterCity();
			$policy_page_data->setCityList($cityDb->retriveCity('code',$user_data_list['statecode']));
		}
		
		return view('car.policy.uat.bajaj',['quote'=>$policy_page_data,
		 'user_data_list'=>$user_data_list
		,'user_data'=>$user_data
		,'redirected'=>0
		,'predefinedData'=>['prev_tab_title'=>$policy_page_data->getPreviousTabText()],
		'logo'=>'bajaj_logo.png',
		'trans_code'=>$trans_code,
		'modal_value' => $premium_breakup
		]);
	}


	public function getPolicy(Request $request){
		$car_helper = new CarHelper;
		$trans_code = $request->trans_code;
		$car_helper->setSuid($trans_code);
		$car_helper->update_proposal_status($trans_code,'proposal_submit');
		$car_helper->storeUserLoginId();
		$user_data = CarTData::find($trans_code);
		$response = $this->manager->genProposalRequest($user_data,$request);
		if(is_array($response) && array_key_exists('error',$response))
			$car_helper->update_proposal_status($trans_code,'proposal_error',$response['error']);
		else
			$user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted');
		echo  json_encode($response); die; 
	}

	public function returnPage(Request $request){
		$payment_resp = $request->all();
		Log::info($request->fullUrl()); 
		Log::info("CAR Bajaj Payment Response : ".json_encode($payment_resp));
		$car_helper = new CarHelper;
		$trans_code = $car_helper->getSuid();
		Log::info('CAR Bajaj PAYMENT TRANS_CODE '.$trans_code);
		// if already transaction_done
		$car_t_data = CarTData::find($trans_code);
		$page_success = $this->returnPageSuccess($car_t_data,$trans_code);
		if($page_success)
			return $page_success;
		$response = $this->manager->store_payment_data($payment_resp,$trans_code);
		$car_helper->log_payment_result($trans_code,$this->manager->status,['ref_no'=>$payment_resp['requestId'],'msg'=>$payment_resp['p_pay_status']]);

		// check policy success
		$status = 0;
		if($payment_resp['policyref'] != "null")
			$status = 1;
		
		$car_helper->log_policy_result($trans_code,$status,['msg'=>$payment_resp['p_policy_ref']]);

		$data = ['status' => $status,
			     'logo' => Car_Constants::LOGO['bajajallianz'], 
				 'udata' => $response];
		$data['udata']['ref_no'] = $this->manager->getPolicyRefNo();

		//save user data
		foreach ($response as $key => $value)
			$car_t_data->{$key} = $value;
		$car_transaction = $car_t_data->save();
		$this->manager->storeStatusAndTransaction($status,$response['trans_code']);
		return view('car.return_page.bajaj', $data);
	}


	private function returnPageSuccess($car_t_data,$trans_code){
		if($car_t_data)
			return 0;
		$car_t_data = CarTData::find($trans_code.'_DONE');
		$data = ['status' => 1,
		     'logo' => Car_Constants::LOGO['bajajallianz'], 
			 'udata' => ['ref_no'=>$car_t_data->policy_nu]];		
		//$data['download_link'] = $this->manager->getPolicyPdfUrl($car_t_data->policy_nu);
		return view('car.return_page.bajaj', $data);	
	}

	public function downloadPolicy($trans_code,$policy_nu){
		$this->manager->downloadPolicy($policy_nu,$trans_code);
	}
}

