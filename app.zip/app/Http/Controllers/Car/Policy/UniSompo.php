<?php

namespace App\Http\Controllers\Car\Policy;

use App\Be\Car\CarPolicyBe;
use App\Http\Controllers as C;
use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use App\Http\Controllers\Controller;
use App\Http\Controllers\EmailSender;
use App\Libraries\CarLib;
use App\Models\Car as M;
use App\Models\Car\CarTData;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Log;

class UniSompo extends Controller {

	var $authentication,
	$policy,
	$vehicle,
	$proposer,
	$prevpolicy,
	$covers, $ci;

	public function __construct() {
		$this->refrel_col = 'unisompo';
		$this->refrel_variant_col = "lstdec_code";
		$this->redirect = 0;
		$this->test = 0;
		$this->email = new EmailSender;
		$this->elect_ass = Car_Constants::ELECT_ASS;
		$this->non_elect_ass = Car_Constants::NONELECT_ASS;
		$this->required_master = Car_Constants::UNISOMPO_MASTER;
		$this->nu_of_claim = Car_Constants::NU_OF_CLAIM;
		$this->car_helper = new CarHelper;
	}

	public function callIndex() {
		if (!empty(session('request'))) {
			$request = new Request(session('request'));
			return $this->index($request);
		}
	}

	public function getPredefinedData($request) {
		$car_policy_be = new CarPolicyBe;
		$prev_tab_title = Car_Constants::PREV_TAB_TEXT_ROLLOVER;
		$prev_text = Car_Constants::PREV_TEXT_ROLLOVER;
		session(['request' => $request->all()]);
		$date = Carbon::now();
		$policyStartDate = $request->input('policyStartDate');
		$policyExpiryDate = $request->input('policyExpiryDate');
		if ($request->input('regDate')) {
			$regDate = $request->input('regDate');
		} else {
			$regDate = $request->input('car_registration_date');
		}
		$typeOfBusiness = $car_policy_be->getTypeOfBusiness($regDate);

		if (date('Y', strtotime($regDate)) == date('Y')) {
			$prev_tab_title = Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
			$prev_text = Car_Constants::PREV_TEXT_NEWBUSINESS;
			$policyStartdate = date('Y-m-d', strtotime(str_replace("/", "-", $policyStartDate)));
		} else {
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $policyExpiryDate)));
			$policyStartDate = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
		}

		$this->product_id = $request->input('product_id');
		$this->insurer_id = $request->input('insurer_id');
		$this->totalpremium = $request->input('totalpremium');
		$this->netPremium = $request->input('netPremium');
		$this->session_id = $request->input('session_id');
		$this->return_quote_url = $request->input('return_quote_url');
		// $table = ['session_id' => $this->session_id,
		// 	'insurer_id' => $this->insurer_id,
		// 	'product_id' => $this->product_id,
		// 	'return_quote_url' => $this->return_quote_url,
		// 	'totalpremium' => $this->totalpremium,
		// 	'netPremium' => $this->netPremium,
		// ];
		// CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);

		$car_helper = new CarHelper();
		$car_helper->storePremiumDetails($this->getTransCode(),$this->product_id);

		$user_code = !empty(session('user_code'))?session('user_code'):NULL;
		$agent_store = new C\Customers\Customers();
		//$agent_store->agentUserCode($user_code);
		$agent_store->setModule('car');
		$agent_store->setUserCode($user_code);
		$agent_store->storeAgentCode();
		/* Added by vivek ends here */
		return array(
			'session_id' => $this->session_id,
			'product_id' => $this->product_id,
			'insurer_id' => $this->insurer_id,
			'year' => $request->year,
			'regDate' => $regDate,
			'policyStartDate' => $policyStartDate,
			'policyExpiryDate' => $policyExpiryDate,
			'vehicleId' => $this->getVehicleId($request->input('variant_code')),
			'rto' => $request->input('rto'),
			'idv' => $request->input('idv'),
			'idv_opted' => $request->input('idv_opted'),
			'netPremium' => $request->input('netPremium'),
			'totalpremium' => $request->input('totalpremium'),
			'typeOfBusiness' => $typeOfBusiness,
			'return_quote_url' => $request->input('return_quote_url'),
			'ncb' => $request->input('new_ncb'),
			'pre_ncb' => $request->input('ncb'),
			'prev_claim_status' => $request->input('claim'),
			'price' => $request->input('price'),
			'sc' => Car_Constants::SEATING_CAPACITY,
			'occupation' => Car_Constants::OCCUPATION,
			'prev_tab_title' => $prev_tab_title,
			'prev_text' => $prev_text,
			'trans_code'=>$this->getTransCode()
		);
	}

	/* Created by vivek */
	public function loadProposalUrl(Request $request,$trans_code){
		$car_t_data = new CarTData;
		$request->trans_code = $trans_code;
		$this->car_helper->storeIp($request);
		$user_data = $car_t_data->find($trans_code);
		$field = $this->getQuoteFieldMap();
		$field['insurer_id'] = 'insurer_id';
		$field['product_id'] = 'product_id';
		$field['totalpremium'] = 'totalpremium';
		$field['return_quote_url'] = 'return_quote_url';
		$field['netPremium'] = 'netPremium';
		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $field);
		$this->user_data['session_id'] = $trans_code;
//        dd($this->user_data);
		/*if ($trans_code != session()->getId()) {
			$this->redirect = 1;
		}*/

		$request = new Request($this->user_data);
		return $this->index($request);
		//return view('car.policy.unitedindia', $this->user_data);
	}
	/* Created by vivek ends here */

	public function getDbData($session_id) {
		$car_t_data = new CarTData;
		$this->field = $this->getFieldMap();
		$user_data = $car_t_data->find($session_id);
		$this->user_data = (!$user_data) ? [] : $this->car_helper->getFieldData($user_data, $this->field);
		$this->resetMasterUserData();
	}

	public function resetMasterUserData() {
		$this->master_field = Car_Constants::UNISOMPO_FORM_FIELD;
		if (!empty($this->user_data)) {
			foreach ($this->master_field as $master_field_name) {
				if (isset($this->user_data[$master_field_name])) {
					$this->master_data[$master_field_name] = $this->user_data[$master_field_name];
					// unset($this->user_data[$master_field_name]);
				} else {
					$this->master_data[$master_field_name] = "";
				}
			}
		}

	}

	public function index(Request $request) {
		$this->setTransCode($request->trans_code);
		$this->car_helper->storeIp($request);
		$this->car_helper->storeOptedIDV($request);
		$request_data = $request->all();
		// $session_id = $request_data['session_id'];
		$trans_code = $request_data['trans_code'];

		$car_details = $this->car_helper->getCarDetailsSessionValue($trans_code);
		$predefinedData = $this->getPredefinedData($request);
		$this->getDbData($trans_code);
		$stateCity = $this->getStateCity($this->product_id, $this->insurer_id);
		$data = $this->requiredData($this->product_id, $this->insurer_id);
		$this->getDbData($trans_code);
		$data = array_merge($data, $stateCity);
		$this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
		$this->changeDateFormate(); // convert date format
		$fullname = (isset($this->user_data['firstname']) && isset($this->user_data['lastname']))?$this->user_data['firstname'].' '.$this->user_data['lastname']:'';
		$data = array_merge($data, ['minYear' => $this->carpolicybe->getMinYear(),
			'year_select' => $this->carpolicybe->getYears($trans_code),
			'elect_ass' => $this->elect_ass,
			'fullname'=>$fullname,
			'non_elect_ass' => $this->non_elect_ass,
			'user_data' => $this->user_data,
			'nu_of_claim' => $this->nu_of_claim,
			'predefinedData' => $predefinedData,
			'cmp_name' => $this->getInsuranceCompanyName($trans_code, $predefinedData['product_id']),
			'car_detail' => (!empty(session('details_selected')['make_name'])) ? session('details_selected') : $car_details,
			'requiredRollover' => (strtolower($car_details['typeOfBusiness']) == "rollover") ? "required" : "",
			'masterData' => (isset($this->master_data)) ? $this->master_data : [],
			'redirected' => $this->redirect,
			'trans_code'=>$this->getTransCode()
		]);
		return view('car.policy.unisompo', $data);
	}

	public function getFieldName($type, $mapper_name) {
		if (isset($this->field) && !empty($this->field)) {
			return $this->field[$type][Car_Constants::CAR_T_USERLOG[$mapper_name]];
		}

	}

	public function changeDateFormate() {
		if (!empty($this->user_data)) {
			$field_name = $this->getFieldName('PROPOSER', 'USR_DOB');
			$this->user_data[$field_name] = (isset($this->user_data[$field_name])) ?
			$this->car_helper->getFormDate($this->user_data[$field_name]) : null;
		}
	}

	public function getInsuranceCompanyName($trans_code, $product_id) {
		$return_data = $this->car_helper->getReturnDataSessionValue($trans_code);
		return $return_data[$product_id]['insurerName'];
	}

	// set policy refreance number
	private function setPolicyRefNo($no){
		$this->policy_ref_no = $no;
	}

	// retrived policy refreance number
	private function getPolicyRefNo(){
		return (isset($this->policy_ref_no))? $this->policy_ref_no : 0;
	}
	
	// route method for payment status
	public function returnPage(Request $request) {
		$car_lib = new CarLib;
		$car_t_data = new CarTData;
		Log::info($_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"]);
		$data = $request->all();
		logger($data);

		

		// store transaction detail
		$table = ['trans_code' => $this->car_helper->getSuid(),
				 Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($data)
			    ];


		if(isset($data['MSG'])){
			$ref_no  = explode('|',$data['MSG']);
			$table[Car_Constants::CAR_T_PROPOSALLOG['TRANSACTION_ID']] = $ref_no[2];
		}

		$car_transaction = $car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
		// end store transaction detail

		$status = 0;
		$car_transaction = $car_t_data->where(['trans_code' => $this->car_helper->getSuid()])->first();
		
		$data['policy_nu'] = (isset($car_transaction->transaction_id))?
			$car_transaction->transaction_id : 0;
		
		$this->setPolicyRefNo($data['policy_nu']);


		$t_status = ($status) ? 1 : 2;

		$data['ref_no'] = $this->getPolicyRefNo();
		$data_main = ['status' => $status, 'logo' => Car_Constants::LOGO['unisompo'],'udata' => $data];

		// store success or failed in databse
		$checkStatus = $car_lib->storeStatus($t_status);
		if ($checkStatus != 1) {
			return $checkStatus;
		}

		if (1 == $t_status) {
			$sessionid = $this->car_helper->getSuid();
			$user_data = $car_t_data->find($sessionid)->toArray();
			if($user_data['car_make'] && $user_data['car_model'])
				M\CarTPolicy::updateOrCreate(array('trans_code' =>
				$sessionid),$user_data);
		}


		try {
			$trans_code = $this->car_helper->getSuid();
			$company_name = $this->car_helper->getSessionValue($trans_code)['insurance_company'];
			$proposal_form_data = json_decode($this->car_helper->getSessionValue($trans_code)['proposal_form_data']);
			if($proposal_form_data->proposer->custType === 'O'){
	            $name = $proposal_form_data->proposer->contactName;
	        } else {
	            $name = $proposal_form_data->proposer->firstName . ' ' . $proposal_form_data->proposer->lastName;
	        }
	        $client_email = $proposal_form_data->proposer->email;
			$proposal_request_url = $this->car_helper->getSessionValue($trans_code)['proposal_request_url'];
			$proposal_form_result = $this->car_helper->getSessionValue($trans_code)['proposal_form_result'];
			// dd($proposal_form_data);
			if (!empty($proposal_form_data)) {

				if ($status) {
					$subject = 'Car insurance purchased for '.$company_name;
					$subject_success = "Congrats you have successfully puchased car insurance from ".$company_name;
					$view_email_internal = view('car.templates.payment_success.internal_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'agent_name' => $this->car_helper->getAgentFromQuoteId(),'agent_email' => $this->car_helper->getAgentEmailQuoteId()]);
					$view_email_external = view('car.templates.payment_success.external_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'agent_name' => $this->car_helper->getAgentFromQuoteId(),'agent_email' => $this->car_helper->getAgentEmailQuoteId()]);
					$mail_data = array('proposal_form_data' => $proposal_form_data,'name'=>$name,'subject'=>$subject,'subject_success'=>$subject_success,'client_email'=>$client_email, 'company_name' => $company_name, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
					$status = $this->email->proposalSuccMail($mail_data);
				} else {
					$subject = 'Payment failed for Car insurance - '.$company_name;
					$subject_failure = "Sorry, there has been some issue while purchasing car insurance from ".$company_name;
					$view_email_internal = view('car.templates.payment_failed.internal_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'agent_name' => $this->car_helper->getAgentFromQuoteId(),'agent_email' => $this->car_helper->getAgentEmailQuoteId()]);
					$view_email_external = view('car.templates.payment_failed.external_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'agent_name' => $this->car_helper->getAgentFromQuoteId(),'agent_email' => $this->car_helper->getAgentEmailQuoteId()]);
					$mail_data = array('proposal_form_data' => $proposal_form_data,'name'=>$name,'subject'=>$subject,'subject_failure'=>$subject_failure,'client_email'=>$client_email, 'company_name' => $company_name, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
					$status = $this->email->proposalFailMail($mail_data);
				}
			}
		} catch (\Exception $e) {

		} finally {
			return view('car.return_page.unisompo', $data_main);
		}
	}

	public function getVehicleId($variant_code){
		$car_variant = new M\CarVariant;
		$ref_col = $this->refrel_variant_col;
		return $car_variant->getVehicleId($variant_code,$ref_col)->$ref_col;
	}

	public function getPolicy(Request $request) {
		// $session_id = $request->session_id;
		$car_t_data = new CarTData;
		$car_policy_be = new CarPolicyBe;
		$trans_code = $request->trans_code;
		$this->car_helper->storeUserLoginId();
		$car_lib = new CarLib;
		$this->car_helper->addDataToFile(Car_Constants::getQuoteFileName($trans_code), [Car_Constants::PROPOSAL_REQUEST_URL => $request->headers->get('referer'), 'insurance_company' => 'UniSompo']);
		$this->setData($request->all());
		$endPoint = "http://api.brokeredge.in";
		$url = Car_Constants::API_BASE . '/rest/submitProposal/motor/' . $request->insurer_id . '/' . $request->product_id;
		$postFields = ['authentication' => Car_Constants::AUTH,
			'policy' => $this->policy,
			'vehicle' => $this->vehicle,
			'proposer' => $this->proposer,
			'prevpolicy' => $this->prevpolicy,
			'covers' => $this->covers];

		$maximum_call = Car_Constants::MAXIUM_CALL_API;

		$proposal_req_json = json_encode($postFields, true);

		//session([Car_Constants::PROPOSAL_FORM_DATA => $proposal_req_json]);
		$this->car_helper->addDataToFile(Car_Constants::getQuoteFileName($trans_code), [Car_Constants::PROPOSAL_FORM_DATA => $proposal_req_json]);
		manipulateResult:
		$result = $this->car_helper->callApi($url, $postFields);

		// if response null than recall
		(!isset($result['data'])) &&
			($result = $this->car_helper->callApi($url, $postFields));

		// if premiuem mismatch is minor than don't ask to user
		if (isset($result['data']['error'])
			&& $result['data']['error'] == "Premium Mismatch") {
			$data = $result['data'];
			if (!$car_policy_be->needConfirmation($data['premiumPayable']
				, $data['premiumPassed'])) {
				$postFields['policy']['premiumPayable'] = $data['premiumPayable'];
				logger("Call is" . $maximum_call);
				if ($maximum_call) {
					$maximum_call--;
					goto manipulateResult;
				}
			}
		}

		// store request id in the car_t_userdata
		$storeRequestId = $car_lib->storeRequestId($result);
		if ($storeRequestId != 1) {
			return $storeRequestId;
		}
		$this->car_helper->addDataToFile(Car_Constants::getQuoteFileName($trans_code), [Car_Constants::PROPOSAL_FORM_RESULT => $result]);

		/*
			Send email to admin when a buyer click on Finish button in policy page
		*/	
			if (isset($result['data']['result'])) {
				$data = $result['data']['result'];
			} else if (isset($result['data'])) {
				$data = $result['data'];
			} else {
				$data['result'] = 'Got null in proposal response from API';
			}
			try {
				$company_name = $this->car_helper->getSessionValue($trans_code)['insurance_company'];
				$proposal_form_data = json_decode($this->car_helper->getSessionValue($trans_code)['proposal_form_data']);
				if($proposal_form_data->proposer->custType === 'O'){
		            $name = $proposal_form_data->proposer->contactName;
		        } else {
		            $name = $proposal_form_data->proposer->firstName . ' ' . $proposal_form_data->proposer->lastName;
		        }
				$subject = 'Car insurance policy hit for '.$company_name.' - '.$name;
		        $client_email = $proposal_form_data->proposer->email;
				$proposal_request_url = $this->car_helper->getSessionValue($trans_code)['proposal_request_url'];
				$proposal_form_result = $this->car_helper->getSessionValue($trans_code)[Car_Constants::PROPOSAL_FORM_RESULT];
				$user_code = !empty(session('user_code'))?session('user_code'):NULL;
				$agent_name = $this->car_helper->getAgentFromQuoteId();

				$internal_data =	 [
										'company_name'=>$company_name,
										'name'=>$name, 
										'client_email'=>$client_email,
										'data_value' => $data, 
										'proposal_form_data' => $proposal_form_data, 
										'proposal_request_url' => $proposal_request_url, 
										'proposal_form_result' => $proposal_form_result,
										'agent_name' => $agent_name
										];

				if (!empty($proposal_form_data)) {
					$view_email_internal = view('car.templates.proposal_payment_hit.internal_email',$internal_data);
					$mail_data = array('agent_email' => $this->car_helper->getAgentEmailQuoteId(),'proposal_form_data' => $proposal_form_data,  'subject'=>$subject,'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'content_internal' => $view_email_internal);
					$status = $this->email->proposalHitMail($mail_data);
				} else {

				}
			} catch (\Exception $e) {
				logger("Email sending to admin for the buy policy details in policy page failed" . $e->getMessage());
			} 

		/*
			Email functionality ends here
		*/

		// STORED PROPOSAL RESPONSE 
		if(isset($result['data']['result']['payUrl'])){
			$parts = parse_url($result['data']['result']['payUrl']);
			parse_str($parts['query'], $query);
			
			$table = ['trans_code' => $trans_code,
					  Car_Constants::CAR_T_PROPOSALLOG['POLICY_NU'] => $query['PosPolicyNo']
					 ];
			$car_transaction = $car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
		}
		if (isset($result['data']['result'])) {
			$result = json_encode($result['data']['result'], true);
		} else if (isset($result['data'])) {
			$result = json_encode($result['data'], true);
		}
		
		echo (is_array($result)) ? ( !empty($result['data']) ? json_encode($result['data'], true): 'Api responded null for proposal api.') : $result;
	}

	public function retriveResult() {

	}

	public function getApiMasters(Request $request) {
		$master = $request->master;
		$refrel_col = $this->refrel_col;
		if ($master == "City") {
			return \App\Models\Car\MasterCity::getCity($refrel_col, $request->stateid);
		} else {
			return $this->car_helper->getMasterData($refrel_col, $master);
		}
	}

	public function setCovers($data) {
		$return_data = $this->car_helper->getSelectedCoversSessionValue($data['trans_code']);
		$covers = $return_data[$data['product_id']];
		$product_id = $data['product_id'];
		if(array_key_exists('PAPASS', $covers) && isset($this->car_helper->getReturnDataSessionValue($data['trans_code'])[$product_id]['papass_addon_price'])){
			$covers['PAPASS']['num'] = $this->car_helper->getReturnDataSessionValue($data['trans_code'])[$product_id]['papass_addon_price']/50;
		}
		$proposer_details = $this->proposer;
		/* If the customer is an organisation then PA will not be send in covers */
		if ($proposer_details['custType'] === 'O') {
			$covers = array_except($covers, ['PA']);
		}

		/* PA will not be send in covers ends here */
		foreach ($covers as $key => $value) {
			$new_covers[] = $value;
		}

		$this->covers = $new_covers;
	}

	/* ------------ Controller Helper Function -------------- */

	public function setData($data) {
		$car_lib = new CarLib;
		$trans_code = $data['trans_code'];
		if ($data['redirected']) {
			foreach (Car_Constants::UNISOMPO_FORM_FIELD as $master_field_name) {
				(!isset($data[$master_field_name]) || $data[$master_field_name] == '') && isset($data['master_' . $master_field_name]) && $data[$master_field_name] = $data['master_' . $master_field_name];
			}
		}
		if(isset($data['fullname']) && $data['fullname'] != ""){
			// grab firstname and lastname from the fullname
		$data['firstname'] = $car_lib->getCorrect($car_lib->getFirstName($data['fullname']));
		$data['lastname'] = $car_lib->getCorrect($car_lib->getLastName($data['fullname']));	
		}

		// get id from code relevant master
		$master_for = array('VehicleBody', 'Occupation', 'GarageType', 'MaritalStatus', 'NomineeRelationship');
		foreach (Car_Constants::IDS as $field => $field_master) {
			$refrel_col = $this->refrel_col;
			if ($field_master == 'Insurer')
					$refrel_col = 'hdfc';
			if (in_array($field_master,$master_for))
					$refrel_col = 'fgi';

			if (isset($data[$field]))
				  $data[$field] = $this->car_helper->getMasterId($refrel_col,$field_master,$data[$field]);
		}
		
		$data = $car_lib->parseDataInUpperCase((array) $data);
		$data['trans_code'] = $trans_code;
		$this->setProposer($data);
		$this->setPolicy($data);
		$this->setVehicle($data);
		$this->setPrevpolicy($data);
		$this->setCovers($data);
		$this->policy['paymentMode'] = Car_Constants::PROPOSAL_DEFAULT['PAYMENT_MODE'];
		//  $this->policy['policyType'] = Car_Constants::PROPOSAL_DEFAULT['POLICY_TYPE'];
	}

	public function setPrevpolicy($data) {
		$this->prevpolicy['previousNcb'] = Car_Constants::PROPOSAL_DEFAULT['PREVIOUS_NCB'];
		$this->prevpolicy['currNcb'] = Car_Constants::PROPOSAL_DEFAULT['CUR_NCB'];
		$this->prevpolicy['previousPolicyType'] = Car_Constants::PROPOSAL_DEFAULT['PREVIOUS_POLICY_TYPE'];
		$this->prevpolicy['previousClaim'] = Car_Constants::PROPOSAL_DEFAULT['PREVIOUS_CLAIM'];
		$this->prevpolicy['numberClaims'] = Car_Constants::PROPOSAL_DEFAULT['NUMBER_CLAIMS'];

		if ($this->policy['typeOfBusiness'] == 'ROLLOVER') {
			$this->prevpolicy['previousNcb'] = $data['pre_ncb'];
			$this->prevpolicy['currNcb'] = $data['ncb'];

			$this->prevpolicy['previousClaim'] = $data['prev_claim_status'];

			if ($data['prev_claim_status'] == 'Y') {
				$this->prevpolicy['numberClaims'] = $data['claim'];
			}

			$this->prevpolicy['prePolicyenddate'] = date('Y-m-d', strtotime(str_replace("/", "-", $data['policyExpiryDate'])));
			$prePolicyStartdate = strtotime('- 1 year', strtotime($this->prevpolicy['prePolicyenddate']));
			$this->prevpolicy['prePolicystartdate'] = date('Y-m-d', strtotime('+1 days', $prePolicyStartdate));
			$this->prevpolicy['prePolicynumber'] = $data['policyno'];
			$this->prevpolicy['preInsurercode'] = (isset($data['previnsurance'])) ? $data['previnsurance'] : "";
		}
		//else
		//$this->prevpolicy['prePolicynumber'] = "OGwe325435";
	}

	public function setVehicle($data) {
		$reg_rto = str_split($data['rto'], 2);
		$car_lib = new CarLib;
		$this->vehicle['vehicleId'] = $data['vehicleId'];
		$date = date('Y-m-d', strtotime(str_replace("/", "-", $data['regDate'])));
		$this->vehicle['yom'] = $data['yom_selected']; //date('Y',strtotime($date));
		$this->vehicle['rto'] = $data['rto'];
		$this->vehicle['vehicleRegistrationDate'] = date('Y-m-d', strtotime($date));
		if ($this->policy['typeOfBusiness'] == 'ROLLOVER') {
			$this->vehicle['vehicleRegno'] = $reg_rto[0] . '-' . $reg_rto[1] . '-' . strtoupper($car_lib->parseRegistrationNumber($data['regno']));
		} else {
			$this->vehicle['vehicleRegno'] = '';
		}

		$this->vehicle['engineNo'] = $data['engno'];
		$this->vehicle['chassisNo'] = $data['chassisno'];
		// $this->vehicle['vehicleOwnedby'] = $data['type'];
		$this->vehicle['idv'] = $data['idv'];
		$this->vehicle['ElectricalAcc'] = (isset($data['electrical']) && $data['electrical'] != '') ? $data['electrical'] : 0;
		$this->vehicle['nonElectricalAcc'] = (isset($data['non_electrical']) && $data['non_electrical'] != '') ? $data['non_electrical'] : 0;
		$this->vehicle['price'] = $data['price'];
		$this->vehicle['sc'] = $data['sc'];
		$this->vehicle['bankName'] = (isset($data['bank']) && $data['bank']) ? $data['bank'] : '';
		$this->vehicle['bodyType'] = $data['bodyType'];
		$this->vehicle['color'] = $data['color'];
	}

	public function setPolicy($data) {
		$trans_code = $data['trans_code'];
		$return_data = $this->car_helper->getReturnDataSessionValue($trans_code);
		$product_id = $data['product_id'];
		$this->proposer['custType'] = $data['type'];
		$this->policy['typeOfBusiness'] = 'ROLLOVER';
		$date = date('Y-m-d', strtotime(str_replace("/", "-", $data['regDate'])));
		//for policy new
		if (date('Y', strtotime($date)) == date('Y')) {
			$this->policy['typeOfBusiness'] = 'New Business';
			$this->policy['policyStartdate'] = date('Y-m-d', strtotime(str_replace("/", "-", $data['policyStartDate'])));
		} else {
			$prevPolicyEndDate = date('Y-m-d', strtotime(str_replace("/", "-", $data['policyExpiryDate'])));
			$this->policy['policyStartdate'] = date("Y-m-d", strtotime("+1 day", strtotime($prevPolicyEndDate)));
		}
		$nextYearDate = strtotime('+ 1 year', strtotime($this->policy['policyStartdate']));
		$this->policy['policyEnddate'] = date('Y-m-d', strtotime('-1 days', $nextYearDate));
		$this->policy["basePremium"] = round($data['netPremium']);
		$proposer_details = $this->proposer;
		if ($proposer_details['custType'] === 'O') {
			$policy_data = $return_data[$product_id];
			$base_premium = $this->policy["basePremium"];
			if (isset($policy_data['premiumBreakup']['basic']['pa_basic_price'])) {
				$this->policy["basePremium"] = $base_premium - $policy_data['premiumBreakup']['basic']['pa_basic_price']['basic_premium'];
			} elseif (isset($policy_data['premiumBreakup']['addon']['pa_addon_price'])) {
				$this->policy["basePremium"] = $base_premium - $policy_data['premiumBreakup']['addon']['pa_addon_price']['basic_premium'];
			}
		}
		$this->policy["serviceTax"] = round((($this->policy["basePremium"] * Car_Constants::GST) / 100));
		$this->policy['premiumPayable'] = round(($this->policy["basePremium"] + $this->policy["serviceTax"]));
		if (isset($data['new_premium'])) {
			$this->policy["basePremium"] = round((($data["new_premium"] / (100+Car_Constants::GST)) * 100));
			$this->policy["serviceTax"] = round((($this->policy["basePremium"] * Car_Constants::GST) / 100));
			$this->policy['premiumPayable'] = $data['new_premium'];
		}
	}

	public function setProposer($data) {

		$this->proposer['custType'] = $data['type'];
		if (strtolower($this->proposer['custType']) == "i") {
			$this->proposer['firstName'] = $data['firstname'];
			$this->proposer['lastName'] = $data['lastname'];
			$this->proposer['proposerDob'] = date('Y-m-d', strtotime($data['cust_dob']));
			$this->proposer['gender'] = $data['gender'];
			$this->proposer['title'] = ('M' == $data['gender']) ? 'MR' : 'MS';
		} else {
			$this->proposer['orgName'] = $data['companyname'];
			$this->proposer['contactName'] = $data['contactperson'];
		}
		// count age from customer dob
		$this->proposer['custage'] = (date('Y') - date('Y', strtotime($data['cust_dob'])));
		$proposer = array('policyPincode' => $data['pincode'],
			'corrPincode' => $data['pincode'],
			//'policyCitycode' => (isset($data['citycode'])) ? $data['citycode'] : "",
			//'policyStatecode' => (isset($data['statecode'])) ? $data['statecode'] : "",
			'policyCity' => $data['city'],
			'policyState' => $data['state'],
			// 'corrCitycode' => (isset($data['citycode'])) ? $data['citycode'] : "",
			// 'corrStatecode' => (isset($data['statecode'])) ? $data['statecode'] : "",
			'workTel' => '',
			'corrCity' => $data['city'],
			'corrState' => $data['state'],
			'email' => $data['email'],
			'mobile' => $data['mobile'],
			'homeTel' => $data['mobile'],
			'policyAddress1' => $data['address'],
			'corrAddress1' => $data['address'],
			'policyAddress2' => $data['address'],
			'corrAddress2' => $data['address'],
			'policyAddress3' => $data['address'],
			'corrAddress3' => $data['address'],
			'pan' => $data['pan'],
			'nomineeName' => $data['nomineeName'],
			'nomineeRel' => $data['nomineeRel'],
			'occupationType' => $data['occupation'],
			'maritalStatus' => $data['martitalStatus'],

		);
		$this->proposer = array_merge($this->proposer, $proposer);
	}

	// store Data in Database
	public function setProposalData(Request $request) {
		$values = $request->all();
		$car_lib = new CarLib;
		$car_t_data = new CarTData;
		$field = $this->getFieldMap(strtoupper($values['id']));
		if ($values['id'] == 'proposer') {
			$field_name = $field[Car_Constants::CAR_T_USERLOG['USR_DOB']];
			if (isset($values[$field_name])) {
				$values[$field_name] = $this->getDbFormatDate($values[$field_name]);
			}

		}
		if(in_array("firstname", $field) && isset($values['fullname'])) {
			
			$key = array_search("firstname", $field);
			$table[$key] = $car_lib->getFirstName($values['fullname']);
			
			$key = array_search("lastname", $field);
			$table[$key] = $car_lib->getLastName($values['fullname']);
		}

		// map and genrate a array table columna name and value
		foreach ($field as $key => $value) {
			if (isset($values[$value])) {
				$table[$key] = $values[$value];
			}
		}
		$table['user_id'] = !empty(session('user_id')) ? session('user_id') : NULL;
		try {
			$car_transaction = $car_t_data->updateOrCreate(array('trans_code' => $table['trans_code']), $table);
		} catch (\Exception $e) {
			echo $e->getMessage();
			die;
		}
	}

	public function getStateCity($product_id, $insurer_id) {
		//if (!Session::has($product_id . 'apiDataState')) {
			$state['data']['result'] = $this->car_helper->getMasterData($this->refrel_col, 'State');
			if (!empty($state['data']['result'])) {
				$state = $state['data']['result'];
				$field_name = $this->getFieldName('COMMUNICATION', 'USR_STATE_CODE');
				$state_id = (isset($this->user_data[$field_name])) ? $this->user_data[$field_name] : $state[0]['id'];
				$city['data']['result'] = $this->car_helper->getMasterCity($this->refrel_col, 'City', $state_id);
				$city = $city['data']['result'];
				Session::put($product_id . 'apiDataState', ['state' => $state, 'city' => $city]);
				Session::save();
				return ['state' => $state, 'city' => $city];
			}
		//}
		return Session::pull($product_id . 'apiDataState');
	}

	public function requiredData($product_id, $insurer_id) {
		$response_data = array();
		session()->forget($product_id . 'apiData');
		if (!Session::has($product_id . 'apiData')) {
			$insurer_id = substr($product_id, 0, 3);
			$master_for = array('VehicleBody', 'Occupation', 'GarageType', 'MaritalStatus', 'NomineeRelationship');

			foreach ($this->required_master as $value) {
				$refrel_col = $this->refrel_col;

				if ($value == 'Insurer') {
					$refrel_col = 'hdfc';
				}

				if ($value == 'Title' || in_array($value, $master_for)) {
					$refrel_col = 'fgi';
				}

				$result['data']['result'] = $this->car_helper->getMasterData($refrel_col, $value);

				$response_data[strtolower($value)] = (!empty($result['data']['result'])) ? $result['data']['result'] : array();

				if (isset($orignale_pro_id)) {
					$product_id = $orignale_pro_id;
					$orignale_pro_id = NULL;
				}
			}
			Session::put($product_id . 'apiData', $response_data);
			Session::save();
		}
		return Session::pull($product_id . 'apiData');
	}

	// map sql column with form field
	public function getFieldMap($map_for = null) {
		$fields = ['PROPOSER' => [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_USERLOG['USR_TYPE'] => 'type',
			Car_Constants::CAR_T_USERLOG['USR_GENDER'] => 'gender',
			Car_Constants::CAR_T_USERLOG['USR_DOB'] => "cust_dob",
			Car_Constants::CAR_T_USERLOG['USR_COMPANYNAME'] => "companyname",
			Car_Constants::CAR_T_USERLOG['USR_CONTACTPERSON'] => "contactperson",
			Car_Constants::CAR_T_USERLOG['USR_FIRSTNAME'] => "firstname",
			Car_Constants::CAR_T_USERLOG['USR_LASTNAME'] => "lastname",
			Car_Constants::CAR_T_USERLOG['USR_EMAIL'] => "email",
			Car_Constants::CAR_T_USERLOG['USR_MOBILE'] => "mobile",
			Car_Constants::CAR_T_USERLOG['USR_PAN'] => "pan",
			Car_Constants::CAR_T_USERLOG['USR_AADHARNO'] => "aadharno",
			Car_Constants::CAR_T_USERLOG['USR_TITLE'] => "title",
			Car_Constants::CAR_T_USERLOG['OCCUPATION'] => "occupation",
			Car_Constants::CAR_T_USERLOG['USR_MARITALSTATUS'] => "martitalStatus",
		],
			'COMMUNICATION' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['HOUSENO'] => 'houseno',
				Car_Constants::CAR_T_USERLOG['STREET'] => "street",
				Car_Constants::CAR_T_USERLOG['LOCALITY'] => "locality",
				Car_Constants::CAR_T_USERLOG['PINCODE'] => "pincode",
				Car_Constants::CAR_T_USERLOG['USR_STATE_CODE'] => "statecode",
				Car_Constants::CAR_T_USERLOG['USR_CITY_CODE'] => "citycode",
			],
			'VEHICLE' => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['CHASSISNO'] => 'chassisno',
				Car_Constants::CAR_T_USERLOG['ELECTRICAL'] => 'electrical',
				Car_Constants::CAR_T_USERLOG['ENGNO'] => 'engno',
				Car_Constants::CAR_T_USERLOG['NON_ELECTRICAL'] => 'non_electrical',
				Car_Constants::CAR_T_USERLOG['REGNO'] => 'regno',
				Car_Constants::CAR_T_USERLOG['YOM'] => 'yom_selected',
				Car_Constants::CAR_T_USERLOG['COLOR'] => 'color',
				Car_Constants::CAR_T_USERLOG['BODYTYPE'] => 'bodyType',
			],
			"PREVIOUSINSURER" => [
				Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
				Car_Constants::CAR_T_USERLOG['POLICYNO'] => 'policyno',
				Car_Constants::CAR_T_USERLOG['PREVINSURANCE'] => 'previnsurance',
				Car_Constants::CAR_T_USERLOG['NOMINEENAME'] => 'nomineeName',
				Car_Constants::CAR_T_USERLOG['NOMINEEREL'] => 'nomineeRel',
				Car_Constants::CAR_T_USERLOG['PREVCLAIM'] => 'claim',
			],
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	public function getDbFormatDate($date) {
		return date('Y-m-d', strtotime(str_replace('/', '-', $date)));
	}

	public function getQuoteFieldMap($map_for = null) {
		$fields = [
			Car_Constants::CAR_T_USERLOG['SESSION_ID'] => 'session_id',
				Car_Constants::CAR_T_USERLOG['TRANS_CODE'] => 'trans_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE'] => 'make_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL'] => 'model_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT'] => 'variant_code',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_STATE'] => 'state',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_RTO'] => 'rto',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_YEAR'] => 'year',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_FUEL'] => 'fuel',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MAKE_NAME'] => 'make_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_MODEL_NAME'] => 'model_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VARIANT_NAME'] => 'variant_name',
			Car_Constants::CAR_T_QUOTELOG['DETAIL_VEHICLE_ID'] => 'vehicleId',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NCB'] => 'ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_NEW_NCB'] => 'new_ncb',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CLAIM'] => 'claim',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_TYPE_OF_BUSINESS'] => 'typeOfBusiness',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_START_DATE'] => 'policyStartDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_POLICY_EXPIRY_DATE'] => 'policyExpiryDate',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_CAR_REGISTRATION_DATE'] => 'car_registration_date',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_VEHICLEAGE'] => 'vehicleAge',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_EX_SHOWROOM_CAR_PRICE'] => 'ex_showroom_car_price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_PRICE'] => 'price',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_COV'] => 'cov',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_IDV'] => 'idv',
			Car_Constants::CAR_T_QUOTELOG['OPTED_IDV'] => 'idv_opted',
			Car_Constants::CAR_T_QUOTELOG['FILE_PATH'] => 'quote_response_file',
			Car_Constants::CAR_T_QUOTELOG['TOTAL_PREMIUM'] => 'totalpremium',
			Car_Constants::CAR_T_QUOTELOG['NET_PREMIUM'] => 'netPremium',
			Car_Constants::CAR_T_QUOTELOG['QUOTE_RETURN_URL'] => 'return_quote_url',
		];
		return ($map_for) ? $fields[$map_for] : $fields;
	}

	private function setTransCode($trans_code){
		$this->trans_code = $trans_code;
	}

	private function getTransCode(){
		return $this->trans_code;
	}

}
