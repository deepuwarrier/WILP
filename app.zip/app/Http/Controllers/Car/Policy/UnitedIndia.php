<?php

namespace App\Http\Controllers\Car\Policy;

use Illuminate\Http\Request;
use App\Constants\Car_Constants;
use App\Libraries\CarLib;
use App\Http\Controllers as C;
use App\Http\Controllers\Controller;
use App\Models\Car\CarTData;
use App\Helpers\Car\CarHelper;
use App\Helpers\Car\UIIC\UIICProposalManager;
use App\Helpers\Car\UIIC\UIICRequest;
use App\Be\Car\CarPolicyBe;
use App\Models\Car as M;
use Illuminate\Support\Facades\Log;
use App\Models\Car\Data\PolicyPDFData;
use App\Models\Car\MasterNomineeRelationship;
use App\Models\Car\CarVariant;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;

class UnitedIndia extends Controller {

    public function __construct() {
        $this->proposal_man = new UIICProposalManager();
        $this->redirect = 0;
    }

    public function index(Request $request) {
        $data = $request->all();
        $car_helper = new CarHelper();
        $pb_data = $car_helper->getQuoteValue($request->input('trans_code'));
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($data['trans_code']);
        $user_data = CarTData::find($data['trans_code']);
        $premium_breakup = $car_helper->getPremiumBreakup($user_data,$pb_data);
        $request_data = $request->all();
        $trans_code = $request_data['trans_code'];
        $user_data = $car_helper->update_proposal_status($trans_code,'proposal_load');
        $this->preDefinedData = $this->proposal_man->getPredefinedData($request_data);
        $this->proposal_man->genrateTransactionTable($this->preDefinedData);
        

        //get car details
        $car_details = $car_helper->getCarBasicDetails($user_data);
        
        //retrive db data
        $this->proposal_man->getDbData($this->preDefinedData['session_id']); // retrive db data
        $stateCity = $this->proposal_man->getStateCity('545MO01PC1', '545');
        $data = $this->proposal_man->requiredData($this->preDefinedData['product_id'], $this->preDefinedData['insurer_id']);
        $data = (!empty($stateCity)) ? array_merge($data, $stateCity) : array_merge($data, $this->stateCity);
        // convert date format
        $this->proposal_man->changeDateFormate();
        $this->carpolicybe = (isset($this->carpolicybe)) ? $this->carpolicybe : new CarPolicyBe;
        $fullname = (isset($this->proposal_man->user_data['firstname']) && isset($this->proposal_man->user_data['lastname'])) ? $this->proposal_man->user_data['firstname'] . ' ' . $this->proposal_man->user_data['lastname'] : '';

       if(isset($user_data['veh_financierName'])){
            $financierDb = new M\Financier();
            $result = $financierDb->getUIICData($user_data['veh_financierName']);
            $financer_name = $result['financer_name'];
            $financier_branch_list = $financierDb->getUiicBranch($financer_name);
            $financier_code = $user_data['veh_financierName'];
        }

        $data = array_merge($data, ['minYear' => $this->carpolicybe->getMinYear(),
            'year_select' => $this->carpolicybe->getYears($this->preDefinedData['session_id']),
            'elect_ass' => $this->proposal_man->elect_ass,
            'non_elect_ass' => $this->proposal_man->non_elect_ass,
            'type_of_finance' => $this->proposal_man->type_of_finance,
            'cmp_paid_up' => $this->proposal_man->cmp_paid_up,
            'user_data' => $this->proposal_man->user_data,
            'fullname' => $fullname,
            'title' => $this->proposal_man->title,
            'car_detail' => (!empty(session('details_selected')['make_name'])) ? session('details_selected') : $car_details,
            'cmp_name' => $this->proposal_man->getInsuranceCompanyName($this->preDefinedData['product_id']),
            'predefinedData' => $this->preDefinedData,
            'totalpremium' => $this->preDefinedData['totalpremium'],
            'netPremium' => $this->preDefinedData['netPremium'],
            'return_quote_url' => $this->preDefinedData['return_quote_url'],
            'typeOfBusiness' => $car_details['typeOfBusiness'],
            'requiredRollover' => (strtolower($car_details['typeOfBusiness']) == "rollover") ? "required" : "",
            'redirected' => $this->redirect,
            'width_tab' => 20,
            'master_url' => route("car.policy.city"),
            'proposal_data_url' => route("car.policy.setproposaldata"),
            'proposal_form_url' => \URL::to('/car-insurance/uiic/getpolicy'),
            'modal_value' => $premium_breakup,
            'financer_name' =>isset($financer_name)?$financer_name:null,
            'financier_code' =>isset($financier_code)?$financier_code:null,
            'financier_branch_list'=>isset($financier_branch_list)?$financier_branch_list:null
        ]);
        $data['trans_code'] = $trans_code;
        return view('car.policy.unitedindia', $data);
    }

    public function getPolicy(Request $request) {
        $car_helper = new CarHelper;
        $session_id = $request->session_id;
        $trans_code = $request->trans_code;
        //$car_helper->setSuid($trans_code);
        $car_helper->storeUserLoginId();
        $this->uiic_req = new UIICRequest($this->proposal_man);
        $this->uiic_req->setData($trans_code);            
        $user_data = CarTData::find($trans_code);
        // $validation_arr = $this->validate_data($user_data);
        
        // if($validation_arr["verror"]){ 
        //     return response()->json( ["error" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
        // } 
        

        // check premium missmatch 
        if (isset($this->uiic_req->quote_manger)) {
            $total_premium = $request->input('totalpremium');
            if ($request->input('new_premium') && $request->input('new_service_tax')){
                $total_premium = $request->input('new_premium') + $request->input('new_service_tax');

                $user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit_new_premium');
            }else{
                $user_data = $car_helper->update_proposal_status($trans_code,'proposal_submit');
            }

            if ($total_premium != $this->uiic_req->quote_manger->quote['totalpremium']) {
                $table = ['final_premium' => $this->uiic_req->quote_manger->quote['totalpremium']
                    , 'trans_code' => $trans_code];
                $car_transaction = CarTData::updateOrCreate(array('trans_code' => $trans_code), $table);

                return response()->json(['error' => 'premium mismatch'
                            , 'premiumPayable' => $this->uiic_req->quote_manger->quote['totalpremium']
                            , 'premiumPassed' => $total_premium
                            , 'basePremium' => $this->uiic_req->quote_manger->quote['netPremium']
                            , 'serviceTax' => $this->uiic_req->quote_manger->quote['serviceTax']]);
            }
        }
        //$this->sendPolicyAppliedMail();
        // just for testing
       
        $user_data = $car_helper->update_proposal_status($trans_code,'proposal_accepted');
        $this->proposal_man->parsePaymentRequest($this->uiic_req->quote_manger->quote['totalpremium'], $trans_code);
        Log::info('CAR UIIC Payment Request ',['msg' => $this->proposal_man->payment_req]);

        return response()->json(['msg' => $this->proposal_man->payment_req]);
    }

    private function validate_data($usr_data){
        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->usr_mobile,
                            'customer_name' => $usr_data->usr_firstname.' '.$usr_data->usr_lastname,
                            'pc_customer_dob' => $usr_data->usr_dob,
                            'pc_customer_aadharno' => $usr_data->usr_aadharno,
                            'customer_email' => $usr_data->usr_email,
                            'customer_add1' => $usr_data->usr_houseno,
                            'customer_add2' => $usr_data->usr_street,
                            'customer_add3' => $usr_data->usr_locality,
                            'customer_pincode' => $usr_data->usr_pincode,
                            'pc_reg_no' => $usr_data->veh_reg_no,
                            'pc_engine_no' => $usr_data->veh_eng_no,
                            'pc_chasis_no' => $usr_data->veh_chassisno,
                            'color' => $usr_data->veh_color,
                            'pc_pre_policy' => $usr_data->prev_policyno,
                            'nominee_name' => $usr_data->nominee_name
                        ];
        if($usr_data->usr_type == 'O'){
            $required_array['customer_gstin'] = $usr_data->gstin;
        }
        return $valid_lib->proposalSubmit($required_array);
    }

    public function loadProposalUrl(Request $request, $trans_code) {
        
         return redirect()->route('car_insurance');
        
        $car_helper = new CarHelper;
        $request->trans_code = $trans_code;
        $car_helper->storeIp($request);
        $car_helper->checkTransaction($trans_code);
        $user_data = CarTData::find($trans_code);
        if (empty($user_data)) {
            return redirect()->route('car_insurance');
        }
        $field = $this->proposal_man->getQuoteFieldMap();
        $field['insurer_id'] = 'insurer_id';
        $field['product_id'] = 'product_id';
        $field['totalpremium'] = 'totalpremium';
        $field['netPremium'] = 'netPremium';
        $field['return_quote_url'] = 'return_quote_url';
        $this->proposal_man->user_data = (!$user_data) ? [] : $car_helper->getFieldData($user_data, $field);
        $this->proposal_man->user_data['trans_code'] = $trans_code;
        $request = new Request($this->proposal_man->user_data);
        return $this->index($request);
    }

    public function getApiMasters(Request $request) {
        $car_helper = new CarHelper;
        $master_city = new \App\Models\Car\MasterCity;
        $master = $request->master;
        $refrel_col = $this->proposal_man->refrel_col;
        if ($master == "City") {
            return $master_city->getCity($refrel_col, $request->stateid);
        } else {
            return $car_helper->getMasterData($refrel_col, $master);
        }
    }


    public function returnPage(Request $request) {
        $car_helper = new CarHelper;

        // take payment response
        $pgresp_raw = $request->input("msg");
        $pgresp = $this->proposal_man->parse_pgresp($pgresp_raw);

        $payment_parse_be = new PaymentParseBE;
        $trans_code = $payment_parse_be->getPaymentIdentifier($pgresp['CustomerID']);
        // $trans_code = $car_helper->getSuid();

        Log::info('CAR UIIC PAYMENT TRANS_CODE '.$trans_code);
        $data = CarTData::find($trans_code.'_DONE');
        if($data){
            $download_link = route('car.uiic.policy_pdf', [$data->policy_nu]);
            $data['transaction_id'] = $data->transaction_id;
            
            $data['ref_no'] = $data->policy_nu;
            $data = ['status' => 1,
                'logo' => Car_Constants::LOGO['unitedindia'],
                'udata' => $data];

            $data['download_link'] = $download_link;
            return view('car.return_page.unitedindia', $data);
        }

        $car_t_data = CarTData::find($trans_code);
        $data = $request->all();
        $table = ['trans_code' => $trans_code,
        
        Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($data)];

        Log::info("CAR UIIC Full Response Url - ".$trans_code." : " .$request->fullUrl());
        Log::info("CAR UIIC Payment Response - ".$trans_code." : " . $request->input("msg"));

        

        if (isset($pgresp['TxnReferenceNo']))
            $table[Car_Constants::CAR_T_PROPOSALLOG['TRANSACTION_ID']] = $pgresp['TxnReferenceNo'];

        if (isset($pgresp['CustomerID']))
            $table[Car_Constants::CAR_T_PROPOSALLOG['CUSTOMER_ID']] = $pgresp['CustomerID'];

        if ($pgresp["AuthStatus"] == "0300") {
            $car_t_data = $car_helper->log_payment_status($trans_code
                    ,'payment_success',['ref_no'=>$pgresp['TxnReferenceNo']]);
            $trans_code = $table['trans_code'];
            $table['trans_code'] = $table['trans_code'].'_DONE';
	        $table[Car_Constants::CAR_T_PROPOSALLOG['PAYMENT_DATE']] = date('Y-m-d');
            $car_transaction = CarTData::where('trans_code',$trans_code)->update($table);
            $trans_code = $table['trans_code'];
            $car_t_data = $car_helper->log_policy_status($trans_code,'policy_request');

            $policy_resp = $this->proposal_man->submit_policy($trans_code, $pgresp);
            if ($policy_resp != null) {
                $policy_resp = (array) simplexml_load_string($policy_resp);
                if (isset($policy_resp['HEADER']->TXT_ERR_MSG)) {
                    $car_t_data = $car_helper->log_policy_result($trans_code,0,['msg'=>$policy_resp['HEADER']->TXT_ERR_MSG]);
                    $data = ['msg' => $policy_resp['HEADER']->TXT_ERR_MSG, 'TRN' => 0];
                    return view('car.policy.proposal_error_page', $data);
                }
                $status = (isset($policy_resp['Message']) && strtolower($policy_resp['Message']) == 'approved') ? 1 : 0;

                // set polcy no
                if ($status)
                    if (isset($policy_resp['InsPolicyNo'])){
                        $table[Car_Constants::CAR_T_PROPOSALLOG['POLICY_NU']] = $policy_resp['InsPolicyNo'];
                        $this->setPolicyRefNo($policy_resp['InsPolicyNo']);
                        $download_link = route('car.uiic.policy_pdf', [$policy_resp['InsPolicyNo']]);
                    }
                //set proposal nu
                if (isset($policy_resp['InsProposalNo']))
                    $table[Car_Constants::CAR_T_PROPOSALLOG['PROPOSAL_NU']] = $policy_resp['InsProposalNo'];
                $msg = $policy_resp['Message'];
                $invoiceNo = $policy_resp['InsInvoiceNo'];
                
                $trans_code = $table['trans_code'];
                
                CarTData::updateOrCreate(array('trans_code' => $trans_code), $table);

                $car_t_data = $car_helper->log_policy_result($trans_code,$status,['msg'=>$policy_resp['Message']]);

                if ($status)
                    $table['trans_code'] = $trans_code;

                $car_transaction = CarTData::updateOrCreate(array('trans_code' => $trans_code), $table);

                // store plocy status in user table and tarnsaction table
                $this->storeStatusAndTransaction($status,$trans_code);

                $data['transaction_id'] = $car_transaction->transaction_id;
                $data['ref_no'] = $this->getPolicyRefNo();
                $data = ['status' => $status,
                'logo' => Car_Constants::LOGO['unitedindia'],
                'udata' => $data];

                if (isset($download_link))
                    $data['download_link'] = $download_link;
            }else {
                $car_helper->log_policy_result($trans_code,0);
                $car_transaction = CarTData::updateOrCreate(array('trans_code' => $table['trans_code']), $table);
                $this->storeStatusAndTransaction(0,$trans_code);
                $data = ['status' => 0,
                'logo' => Car_Constants::LOGO['unitedindia'],
                'udata' => ['transaction_id' => 0]];
            }
            return view('car.return_page.unitedindia', $data);
        } else {
            $car_helper->log_payment_status($trans_code,'payment_error',
                ['ref_no'=>$pgresp['TxnReferenceNo'],'msg'=>$pgresp['ErrorDescription']]);
            $car_helper->log_policy_result($trans_code,0);

            $car_transaction = CarTData::updateOrCreate(array('trans_code' => $table['trans_code']), $table);
            $data = ['msg' => $pgresp["ErrorDescription"], 'TRN' => $pgresp["TxnReferenceNo"]];
            return view('car.policy.proposal_error_page', $data);
        }
    }

    // set policy refreance number
    private function setPolicyRefNo($no) {
        $this->policy_ref_no = $no;
    }

    // retrived policy refreance number
    private function getPolicyRefNo() {
        return (isset($this->policy_ref_no)) ? $this->policy_ref_no : 0;
    }

    private function storeStatusAndTransaction($status,$suid) {
        $car_lib = new CarLib;
        $t_status = ($status) ? 1 : 2;
        // store success or failed in databse
	    $user_data = $car_lib->storeStatus($t_status,$suid);

    	if ($user_data->t_status != 'TS19') {
            return $user_data->t_status;
        }

        if ($user_data && 'TS19' == $user_data->t_status) {
            $user_data = $user_data->toArray();
            if($user_data['car_make'] && $user_data['car_model']){
                M\CarTPolicy::updateOrCreate(['trans_code'=>$user_data['trans_code']],$user_data);

            }
        }
    }

    public function uiic_policy_pdf($policy_no) {
        $car_helper = new CarHelper;
        $car_rto = new M\CarRto;
        $user_data = M\CarTPolicy::where(['policy_nu' => $policy_no])
        ->orderBy('created_at', 'desc')->first();
        if (!isset($user_data))
            return '<p>Policy Not Found</p>';

        $suid = $user_data->trans_code; 
        $pdf_data = new PolicyPDFData();
        $user_data->policy_reciept_date = $car_helper->changeFormat($user_data->updated_at,'d-M-Y'); 
        $this->uiic_req = new UIICRequest($this->proposal_man);

        $this->uiic_req->setPolicyData($user_data);

        $quote = $this->uiic_req->quote_manger->quote_be->data;

        foreach ($quote as $key => $value)
            $user_data->$key = $value;

        $pdf_data->set_pre_policy_no($user_data->prev_policyno);
        $pdf_data->set_policy_number($user_data->policy_nu);
        $pdf_data->set_policy_issue_date($car_helper->changeFormat($user_data->payment_date, 'd-M-Y'));
        $pdf_data->set_reg_number(strtoupper($user_data->veh_reg_no));

        if ($user_data->idv_opted)
            $pdf_data->set_total_idv_value($user_data->idv_opted);
        else
            $pdf_data->set_total_idv_value($user_data->idv_calculated);

        $pdf_data->set_policy_start_date($user_data->getPolicyStartDate('d-M-Y'));
        $pdf_data->set_policy_end_date($user_data->getPolicyEndDate('d-M-Y'));

        if (strtoupper($user_data->usr_type) == 'O') {
            $pdf_data->set_proposer_name($user_data->usr_companyname);
        } else {
            $pdf_data->set_proposer_name($user_data->usr_firstname . ' ' . $user_data->usr_lastname);
        }

        $pdf_data->set_proposer_mobile($user_data->usr_mobile);
        $pdf_data->set_propoers_email($user_data->usr_email);
        $pdf_data->set_reg_addr($user_data->usr_houseno . ',' . $user_data->usr_street . ',' . $user_data->usr_locality);
        $pdf_data->set_reg_city_name($car_helper->getMasterName('City', $user_data->usr_city_code));
        $pdf_data->set_reg_state_name($car_helper->getMasterName('State', $user_data->usr_state_code));
        $pdf_data->set_reg_pincode($user_data->usr_pincode);
        $pdf_data->set_nomine_name($user_data->nominee_name);
        if ($user_data->nominee_age)
            $pdf_data->set_nomine_age($user_data->nominee_age);

        if ($user_data->nominee_rel) {
            $relDb = new MasterNomineeRelationship();
            $pdf_data->set_nomine_relationship($relDb->getName($user_data->nominee_rel));
        }

        $pdf_data->set_engine_no($user_data->veh_eng_no);
        $pdf_data->set_chassis_no($user_data->veh_chassisno);
        $pdf_data->set_make_name($user_data->make_name);
        $pdf_data->set_model_name($user_data->model_name);
        $pdf_data->set_yom($user_data->veh_yom);
        $pdf_data->set_reg_date($user_data->car_registration_date);
        $pdf_data->set_rto_code(strtoupper($user_data->car_rto));
        $pdf_data->set_rto_location($car_rto->getRtoName($user_data->car_rto));
        $pdf_data->set_body_type($car_helper->getMasterName('VehicleBody', $user_data->veh_bodytype));
        $pdf_data->set_broker_code("BRC0000702");
        // premium 
        $pdf_data->set_od_value($user_data->totoal_od_premium + $user_data->ncb_discount + $user_data->od_discount);
        $pdf_data->set_net_basic_od($user_data->totoal_od_premium + $user_data->ncb_discount);
        $pdf_data->set_tp_value($user_data->tp_premium);

        $variantDb = new CarVariant();
        $variantDb = $variantDb->getData($user_data->car_variant, ['seat_capacity', 'weight', 'variant_cc']);
        $pdf_data->set_seating_capacity($variantDb->seat_capacity);
        $pdf_data->set_variant_cc($variantDb->variant_cc);

        $pdf_data->set_gross_tp_value($user_data->totoal_tp_premium);
        $pdf_data->set_gross_od_value($user_data->totoal_od_premium + $user_data->totoal_addOn_premium);
        $pdf_data->set_od_disc_value($user_data->od_discount);
        $pdf_data->set_eli_ncb_rate($user_data->new_ncb);
        $pdf_data->set_eli_ncb_value($user_data->ncb_discount);

        if ($user_data->veh_electricle)
            $pdf_data->set_ea_value($user_data->veh_electricle);

        if ($user_data->veh_no_electricle)
            $pdf_data->set_nea_value($user_data->veh_no_electricle);

        if ($user_data->totoal_addOn_premium)
            $pdf_data->set_od_addon_status(true);

        if ($user_data->zerodep_premium) {
            $pdf_data->set_zerodept_status(true);
            $pdf_data->set_zerodept_value($user_data->zerodep_premium);
        }

        if ($user_data->rti_premium) {
            $pdf_data->set_rti_status(true);
            $pdf_data->set_rti_value($user_data->rti_premium);
        }

        if ($user_data->PAOD_premium) {
            $pdf_data->set_pa_to_od_status(true);
            $pdf_data->set_pa_to_od_value($user_data->PAOD_premium);
        } else {
            $pdf_data->set_pa_to_od_status(false);
        }

        if ($user_data->pa_cover_premium) {
            $pdf_data->set_pa_to_pass_status(true);
            $pdf_data->set_pa_to_pass_value($user_data->pa_cover_premium);
        }

        if ($user_data->driver_cover_premium) {
            $pdf_data->set_ll_to_pd_status(true);
            $pdf_data->set_ll_to_pd_value($user_data->driver_cover_premium);
        }

        $pdf_data->set_gross_premium($user_data->totoal_od_premium + $user_data->totoal_tp_premium + $user_data->totoal_addOn_premium);
        $pdf_data->set_gst_value($user_data->service_tax);
        $pdf_data->set_net_premium($user_data->total_premium);
        $pdf_data->set_pg_reference_no($user_data->transaction_id);
        $pdf_data->set_payment_date($car_helper->changeFormat($user_data->updated_at, 'd-M-Y'));

        $lib = new CarLib;
        $pdf_data->set_net_premium_words($lib->spell_amount($pdf_data->get_net_premium()));

        $pdf_data->set_idv_value($pdf_data->get_total_idv_value() - $pdf_data->get_ea_value() - $pdf_data->get_nea_value());

        $xpdf = \PDF::loadView('car.policy.policy_pdf', compact("pdf_data"));
        return $xpdf->download("PC_UIIC_" . $pdf_data->get_reg_number() . ".pdf");
    }

    public function getUiicBranch(Request $request) {
        $financierDb = new M\Financier();
        $result = $financierDb->getUiicBranch($request->input('financiername'));
        return view('car.policy.select_branch',['aa'=>$result]);
    }
}
