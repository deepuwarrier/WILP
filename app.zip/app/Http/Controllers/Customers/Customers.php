<?php

namespace App\Http\Controllers\Customers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Customers\CustomerDetails;
use App\Models\Customers as C;
use App\Models\Car AS M;
use App\Constants\Common_Constants;
use App\Models\OtpTData;

class Customers extends Controller
{
    
    public function login(Request $request)
    {
    	$user_status = CustomerDetails::validateUserLogin($request);
    	switch ($user_status) {
    		case '0':
    			return array(
    					'error'		=> 'true',
                        'user_status'     => '0',
    					'message'	=> 'Password entered is incorrect.'
					);
    			break;
    		case '1':
    			return array(
                        'error'         =>'false',
                        'user_status'   => '1',
                        'username'      => (session('username'))?session('username'):'Customer',
    					'message'      	=> '',
                        'isagent'       => $this->checkagentUserCode(session('user_code'))
					);
    			break;
            case '5':
                return array(
                        'error'         =>'false',
                        'user_status'   => '5',
                        'username'      => '',
                        'message'       => '',
                        'isagent'       => ''
                    );
                break;
    		default:
    			return array(
    					'error'		=> 'true',
                        'user_status'     => '2',
    					'message'	=> 'Oh ho! Please register first.'
					);
    			break;
    	}
    }

    public function uatlogin(Request $request)
    {
        $password = 'uatxyz';
        if ($request->password === $password) {
                session(['uat_username'=>'uat_testing']);
                return redirect('/');
            } else
            {
                 return redirect('/uat-login')->with('errors', ['password'=>'Password is incorrect']);;
            }
    }

    public function register(Request $request){
        if($request->register_mobile_number != ''){
            $result = OtpTData::where('mobile', $request->register_mobile_number)->first();
            if (!is_object($result) || !$result->status) {
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::REGISTRATION_FAILUER_MESSAGE
                );
                die;
            }
        }else{
            return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::REGISTRATION_FAILUER_MESSAGE
                );
            die;
        }
        $user_register = CustomerDetails::registerUser($request);
        /* New user registered then response would be '1' */
        switch ($user_register) {
            case '0':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::REGISTRATION_FAILUER_MESSAGE
                    );
                break;
            case '1':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::USER_EMAIL_EXISTS_MESSAGE
                    );
                break;
            case '2':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::USER_MOBILE_EXISTS_MESSAGE
                    );
                break;
            default:
                return array(
                        'error'     => 'false',
                        'user_status'     => '1',
                        'message'   => Common_Constants::REGISTRATION_SUCCESS_MESSAGE
                    );
                break;
        }
    }

    public function forgotPassword(Request $request){
        $user_resetpassword = CustomerDetails::resetpassword($request);
        /* New user registered then response would be '1' */
        switch ($user_resetpassword) {
            case '0':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => Common_Constants::FORGOT_USER_NOT_EXIST_MESSAGE
                    );
                break;
            default:
                return array(
                        'error'     => 'false',
                        'user_status'     => '1',
                        'message'   => Common_Constants::FORGOT_SUCCESS_MESSAGE
                    );
                break;
        }
    }

    public function logout(){
        $session_value = ['user_id','user_email','user_agent','isagent'];
        session()->forget($session_value);
        session()->regenerate();
        return ['u_logout'=>true,'redirect'=> url('/car-insurance')];
        // return redirect('/');
    }

    public function updatePassword(Request $request){
        $user_password = CustomerDetails::changePassword($request);
        switch ($user_password) {
            case '0':
                return array(
                        'error'     => 'true',
                        'user_status'     => '0',
                        'message'   => 'Old Password entered by you does not match'
                    );
                break;
            case '2':
                return array(
                        'error'     => 'true',
                        'user_status'     => '2',
                        'message'   => 'New Password and Confirm password does not match'
                    );
                break;
            default:
                return array(
                        'error'     => 'false',
                        'user_status'     => '1',
                        'message'   => 'Your password changed Succesfully'
                    );
                break;
        }
    }

    public function getRegisterForm(){
        return response()->json(view('layouts.registration_form')->render());
    }

    public function getForgetPasswordForm(){
        return response()->json(view('layouts.forget_password_form')->render());
    }

    public function getLoginForm(){
        return response()->json(view('layouts.login_form')->render());
    }

    public function checkUserEmail(Request $request){
        $email = $request->email;
        return C \ CustomerDetails::checkUser($email);
    }

    public function storeUserCode($user_code){
         $cartdata = new M \ CarTData();
         return $cartdata->storeUserCode($user_code);
    }

    public function agentUserCode($user_code){
        if($this->getUserType($user_code) ==  Common_Constants::INSTA_USER_TYPE_AGENT){
            $car_t_data = new M \ CarTData;
            return $car_t_data->agentUserCode($user_code);
        } else {
            return false;
        }
    }

    public function checkagentUserCode($user_code){

        return ($this->getUserType($user_code) ==  Common_Constants::INSTA_USER_TYPE_AGENT) ? 'true' : 'false';
    }

    public function getUserType($user_code){
        return !empty(C \ CustomerDetails::checkUserType($user_code))?C \ CustomerDetails::checkUserType($user_code)->user_type:0;
    }

    public function agentDashboard(){
        $user_code = !empty(session('user_code'))?session('user_code'):NULL;
        $cartdata = new M \ CarTData();
        $data = $cartdata->getAgentDashboardData($user_code);
        return view('agent.dashboard',['today' => $data['today'] ,'till_date' => $data['till_date'] ,'prospects_details' => $data['prospects_details']]);
    }

    public function storeAgentCode($trans_code){
        $user_code = $this->getUserCode();
        $module = $this->getModule();
        switch ($module) {
            case 'car':
                $module = 'App\Models\Car\CarTData';
                break;
            case 'health':
                $module = 'App\Models\Health\HealthUserData';
                break;
            case 'travel':
                $module = 'App\Models\Travel\TravelUsrData';
                break;
            case 'tw':
                $module = 'App\Models\TW\TwUsrData';
                break;
            
            default:
                # code...
                break;
        }
        $module_obj = new $module;
        return ($this->getUserType($user_code) ==  Common_Constants::INSTA_USER_TYPE_AGENT) && $module_obj->agentUserCode($user_code,$trans_code);
    }

    public function setUserCode($user_code){
        $this->user_code = $user_code;
    }

    public function getUserCode(){
        return $this->user_code;
    }

    public function setModule($module){
        $this->module = $module;
    }

    public function getModule(){
        return $this->module;
    }
}
