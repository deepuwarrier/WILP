<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\EmailHelper;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;
use App\Models\Car\CarTData;
use App\Models\Car as M;
use App\Libraries\CarLib;
use App\Models\EmailModel;
use App\Constants\Common_Constants;

class EmailSender extends Controller
{
	function __construct() {
		$this->email = new EmailHelper;
        $this->email_model = new EmailModel;
	}
    public function send(Request $request){
        $status = false;
    	$name = $request->name;
    	$email = $request->email;
    	$mobile = $request->mobile;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
    	$insurance_type = $request->insurance_type;
    	$subject = 'Enquiry';
        $email_ids = $this->email_model->getContactUsEmailId();
    	$data = array('name' => $name,'mobile' => $mobile,'email'=>$email);
    	$content = view('layouts.email',$data)->render();
    	$data = array('from'=>$email,'name'=>$name,'insurance_type'=>$insurance_type,'subject'=>$subject,'content'=>$content);
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            $data['to'] = $to;
            if($this->email->instaMail($email, $name, $to, $subject, $content)){
                $status = true;
            }
        }
    	if($status != true){
    		return response()->json(['message' => 'Sorry there has been some issue.']);
    	} else {
            switch ($insurance_type) {
                case 'home_insurance':
                    $insurance_type = 'Home Insurance';
                    break;
                case 'term_insurance':
                    $insurance_type = 'Life Insurance';
                    break;
                default:
                    # code...
                    break;
            }
            $subject = "Thanks for Enquiring with Us";
            $view_email_external = view('layouts.email_inquiry_external',['name'=>$name,'insurance_type'=>$insurance_type])->render();
            $data = array('from'=>$default_mail,'to'=>$email,'name'=>$name,'insurance_type'=>$insurance_type,'subject'=>$subject,'content'=>$view_email_external);
            $this->email->instaMail($email, $name, $to, $subject, $content);
    		return response()->json(['message' => 'Your Request has been received']);
    	}
    }
	
	//Send inquiry from contact us form
	public function inquiry(Request $request){	  
        $data = $request->all();
        if(empty($data['g-recaptcha-response'])){
           echo  'Please verify you are not robot';
           exit;
        }
        $status = false;
        $name = $request->name;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $email = $request->email;
        $mobile = $request->mobile;
        $message = $request->message;

        $subject = 'Enquiry from Contact us form';
        $email_ids = $this->email_model->getContactUsEmailId();
        $data = array('name' => $name,'mobile' => $mobile,'email'=>$email);
        $content = '<p>Name: '.$name.'</p>';
        $content .= '<p>Email: '.$email.'</p>';
        $content .= '<p>Mobile: '.$mobile.'</p>';
        $content .= '<p>Message: '.$message.'</p>';
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            if($this->email->instaMail($email, $name, $to, $subject, $content)){
                $status = true;
            }
        }
        if($status === true){
            $subject = "Thanks for contacting us";
            $view_email_external = view('layouts.email_contactus_external',['name'=>$name])->render();
            $this->email->instaMail($default_mail, 'Instainsure.com', $email, $subject, $view_email_external);
            echo  'Your Request has been received';
        }     
        exit;
    }

    // Send Proposal error Page mails

    public function proposalErrMail($data){
        $proposer_fill_details = $data['proposal_form_data'];
        $status = false;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $company_name = $data['company_name'];
        $subject = $data['subject'];
        $name = $data['name'];
        $mobile = $data['mobile'];
        $email = $data['client_email'];
        $email_ids = $this->email_model->getProposalErrEmailId()->toArray();
        $agent_email = isset($data['agent_email'])?$data['agent_email']:'';
        if(($agent_email != 'NA') && ($agent_email != '')){
            $email_ids[] = (object) ['email' => $agent_email];
        }
        $view_email_internal = $data['content_internal']->render();
        $view_email_external = $data['content_external']->render();
        if(!empty($email_ids)){
            foreach ($email_ids as $key => $value) {
                sleep(5);
                $to = $value->email;
                if($this->email->instaMail($email, $name, $to, $subject, $view_email_internal)){
                    $status = true;
                }
            }
        } else {
            $to = 'deepak@instainsure.com';
            if($this->email->instaMail($email, $name, $to, $subject, $view_email_internal)){
                $status = true;
            }
        }
        
        if ($status === true) {
            $this->email->instaMail($default_mail, 'Instainsure.com', $email, $subject, $view_email_external);
            return true;
        }
        session()->forget('proposal_form_data');
    }

    public function proposalSuccMail($data){
        $proposer_fill_details = $data['proposal_form_data'];
        $status = false;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $name = $data['name'];
        $client_email = $data['client_email'];
        $insurance_type = $data['company_name'];
        $view_email_internal = $data['content_internal']->render();
        $view_email_external = $data['content_external']->render();
        $subject = $data['subject'];//'Car insurance purchased for '.$insurance_type;
        $email_ids = $this->email_model->getProposalSuccEmailId()->toArray();
        $agent_email = isset($data['agent_email'])?$data['agent_email']:'';
        if(($agent_email != 'NA') && ($agent_email != '')){
            $email_ids[] = (object) ['email' => $agent_email];
        }
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            if($this->email->instaMail($client_email, $name, $to, $subject, $view_email_internal)){
                $status = true;
            }
        }
        if ($status === true) {
            $subject    =   $data['subject_success'];
            // $subject = "Congrats you have successfully puchased car insurance from ".$insurance_type;
            $this->email->instaMail($default_mail, 'Instainsure.com', $client_email, $subject, $view_email_external);
            return true;
        }
    }

    public function proposalFailMail($data){
        $proposer_fill_details = $data['proposal_form_data'];
        $status = false;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $name = $data['name'];
        $client_email = $data['client_email'];
        $insurance_type = $data['company_name'];
        $view_email_internal = $data['content_internal']->render();
        $view_email_external = $data['content_external']->render();
        $subject = $data['subject'];//'Payment failed for Car insurance for  '.$insurance_type;
        $email_ids = $this->email_model->getProposalFailEmailId()->toArray();
        $agent_email = isset($data['agent_email'])?$data['agent_email']:'';
        if(($agent_email != 'NA') && ($agent_email != '')){
            $email_ids[] = (object) ['email' => $agent_email];
        }
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            if($this->email->instaMail($client_email, $name, $to, $subject, $view_email_internal)){
                $status = true;
            }
        }
        if ($status === true) {
            $subject = $data['subject_failure'];
            $this->email->instaMail($default_mail, 'Instainsure.com', $client_email, $subject, $view_email_external);
            return true;
        }
    }

    public function calculatorMail($data){
        $status = false;
        $name = $data['name'];
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $client_email = $data['to'];
        $view_email_internal = $data['content_internal']->render();
        $view_email_external = $data['content_external']->render();
        $subject = $data['subject'];
        $email_ids = $this->email_model->getProposalFailEmailId();
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            if($this->email->instaMail($client_email, $name, $to, $subject, $view_email_internal)){
                $status = true;
            }
        }
        if ($status === true) {
            $this->email->instaMail($default_mail, 'Instainsure.com', $client_email, $subject, $view_email_external);
            return true;
        } else {
            return false;
        }
    }

    public function quotEmail(Request $request){
        $car_m_products = new M\CarProducts;
        $car_helper = new CarHelper;
        $session_id = $car_helper->getSuid();
        $proposer_fill_details = $car_helper->getSessionValue($session_id);
        $status = false;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $client_email = $request->email_quote;
        if(isset($request->email_quote_name)){
            $name = $request->email_quote_name;
        } else {
            $name = 'Guest';
        }
        if(isset($name) && $name != ""){
                // grab firstname and lastname from the fullname
                $data['firstname'] = CarLib::getCorrect(CarLib::getFirstName($name));
                $data['lastname'] = CarLib::getCorrect(CarLib::getLastName($name)); 
            }
        $table = ['session_id' => $session_id,
            Car_Constants::CAR_T_USERLOG['USR_FIRSTNAME'] => $data['firstname'],
            Car_Constants::CAR_T_USERLOG['USR_LASTNAME'] => $data['lastname'],
            Car_Constants::CAR_T_USERLOG['USR_EMAIL'] => $client_email
        ];
        $car_store_email_data = CarTData::updateOrCreate(array('session_id' => $table['session_id']), $table);
        $quotes_box = '';
        $quotes_retrived = $proposer_fill_details['quotes_retrived'];

        if(isset($proposer_fill_details['hdfc']) && is_array($proposer_fill_details['hdfc'])){
            $quotes_retrived['hdfc'] = $proposer_fill_details['hdfc'];
            // $quotes_retrived['hdfc']['logo'] =  array_key_exists('hdfc',Car_Constants::CMP_LOGO) ? Car_Constants::CMP_LOGO['hdfc'] : null;//$company_details[$key]['product_img'];
        }
            
        if(isset($proposer_fill_details['uiic']) && is_array($proposer_fill_details['uiic'])){
            $quotes_retrived['uiic'] = $proposer_fill_details['uiic'];
            // $quotes_retrived['uiic']['logo'] =  array_key_exists('uiic',Car_Constants::CMP_LOGO) ? Car_Constants::CMP_LOGO['uiic'] : null;
        }

        foreach ($quotes_retrived as $key => $row)
        {
            $price[$key] = $row['totalpremium'];
        }
        array_multisort($price, SORT_ASC, $quotes_retrived);

        foreach ($quotes_retrived as $key => $row)
        {
            $company_details = $car_m_products->getCompProductDetails($key);
            $quotes_retrived[$key]['logo'] =  $company_details[$key]['product_img'];
        }
        $quotes_box =  view('car.templates.quote.filter_quote_email_template',['error'=>'false','filter_quotes'=>$quotes_retrived,'return_quote_url'=>$proposer_fill_details['return_quote_url'],'car_details'=>$proposer_fill_details['car_details']])->render();
        $view_email_internal = view('car.templates.quote.internal_email', ['quotes_box'=>$quotes_box,'email_quote' => $client_email,'proposer_fill_details'=>$proposer_fill_details,'name'=>$name])->render();
        $view_email_external = view('car.templates.quote.external_email', ['quotes_box'=>$quotes_box,'email_quote' => $client_email,'proposer_fill_details'=>$proposer_fill_details,'name'=>$name])->render();
        $subject = 'Your requested quote is attached with this mail from InstaInsure.com';
        $email_ids = $this->email_model->getProposalFailEmailId()->toArray();
        $agent_email = isset($data['agent_email'])?$data['agent_email']:'';
        if(($agent_email != 'NA') && ($agent_email != '')){
            $email_ids[] = (object) ['email' => $agent_email];
        }
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            $view = 'car.templates.quote.internal_email';
            // if($this->email->instaMail($client_email, $name, $to, $subject, ['view'=>$view,'quotes_box'=>$quotes_box,'email_quote' => $client_email,'proposer_fill_details'=>$proposer_fill_details,'name'=>$name])){
            if($this->email->instaMail($client_email, $name, $to, $subject, $view_email_internal)){
                $status = true;
            }
        }
        if ($status === true) {
            $view = 'car.templates.quote.external_email';
            // $this->email->instaMail($default_mail, 'Instainsure.com', $client_email, $subject, ['view'=>$view,'quotes_box'=>$quotes_box,'email_quote' => $client_email,'proposer_fill_details'=>$proposer_fill_details,'name'=>$name]);
            $this->email->instaMail($default_mail, 'Instainsure.com', $client_email, $subject, $view_email_external);
            return json_encode(['error'=>'false']);
        }
    }

    public function proposalHitMail($data){
        $proposer_fill_details = $data['proposal_form_data'];
        $status = false;
        $default_mail = Common_Constants::DEFAULT_FROM_EMAIL;
        $name = $data['name'];
        $client_email = $data['client_email'];
        $insurance_type = $data['company_name'];
        $view_email_internal = $data['content_internal']->render();
        $subject = $data['subject'];
        // $subject = 'Car insurance policy hit for '.$insurance_type.' - '.$name;
        $email_ids = $this->email_model->getProposalFinishHitEmailId()->toArray();
        $agent_email = isset($data['agent_email'])?$data['agent_email']:'';
        if(($agent_email != 'NA') && ($agent_email != '')){
            $email_ids[] = (object) ['email' => $agent_email];
        }
        foreach ($email_ids as $key => $value) {
            $to = $value->email;
            try {
                $this->email->instaMail($client_email, $name, $to, $subject, $view_email_internal);
            } catch (\Exception $e) {
                \Log::info('Error in Proposal hit mail '. $e->getMessage());
            }
        }
    }
}
