<?php
namespace App\Http\Controllers\Health;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Http\Requests\Health\StoreUserDataRequest;
use App\Http\Requests\Health\StoreAppendValueRequest;
use App\Models\Health\HealthRelationship;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthCovers;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Helpers\Health\QuoteHelper;
use App\Helpers\Health\HealthHelper;
use App\Models\PortalPages;
use App\Constants\Common_Constants;
use App\Be\Health\HealthHomeBe;
use App\Be\Health\HealthQuoteBe;
use Input;
use Validator; 
use App\Helpers\Health as H;

class HealthHome extends Controller {

    //Campaign
    public function ShowCampaignIndex($trans_code = null){
        $be = new HealthHomeBe;
        $usr_tbl = new HealthUserData;
        $data = $be->get_campagin_detail_data($trans_code);
        if(!$trans_code){
            $this->ClearCampaignSessions();
            session(['customer_details_modal' => 1]);
        }
        if($trans_code !=null){
            session(['customer_details_modal' => 0]);
        }

        $column = array('campaign_customer_pointer');
        $check_values = array('trans_code' => $trans_code);
        $tbl_response = $usr_tbl->get_data($column,$check_values);
        if(!$tbl_response)
            $this->ClearCampaignSessions();

        if($tbl_response)
            $this->SetCampaignSessions($trans_code, $tbl_response[0]['campaign_customer_pointer']);

        return view('health.campaign.home', ['data' => $data]);
    }

    
    public function saveCustomerModalData(Request $request){
        $request_data = $request->all();
        session(['customer_data' => json_encode($request_data)]);
        return json_encode(['status' => true]);
    }

    public function SaveInitialInputs(Request $request){
        $quote_be = new HealthQuoteBe;
        $usr_tbl = new HealthUserData;
        $health_trans_code = new InstaLib();
        $customer_request = $request->all();
        $trans_code = $health_trans_code->get_health_tc();
        if(session()->has('trans_code')){
            $trans_code = session('trans_code');
        }
        $request  = $quote_be ->format_campaign_inputs($customer_request, $trans_code);
        $quote_be->get_quotes($request , $trans_code);

        //Getting and saving customer data
        if( session()->has('customer_data') ){
            $customer_data = json_decode( session('customer_data'), true);
            $column = array('firstname' => $customer_data['customer_first_name'],
                            'lastname' => $customer_data['customer_last_name'],
                            'email' => $customer_data['customer_email'],
                            'mobile' => $customer_data['customer_mobile'],
                            'pay_mode' => '');
            $check_values = array('trans_code' => $trans_code);
            $res = $usr_tbl->set_by_usrdata($trans_code, $column);
            session()->forget('customer_data');
        }

        $column = array('campaign_initial_inputs' => json_encode( $customer_request ));
        $check_values = array('trans_code' => $trans_code);
        $res = $usr_tbl->set_by_usrdata($trans_code, $column);

        $this->SetCampaignSessions($trans_code, 'quote');
        return redirect()->route('health.campaign.show_quote', $trans_code);
    }

    private function SetCampaignSessions($trans_code, $pointer){
        $usr_tbl = new HealthUserData;
        $column = array('campaign_customer_pointer' => $pointer);
        $check_values = array('trans_code' => $trans_code);
        $usr_tbl->set_by_usrdata($trans_code, $column);
        session(['trans_code' => $trans_code,  'pointer' => $pointer]);
    }

    private function ClearCampaignSessions(){
        session()->forget('trans_code');
        session()->forget('pointer');
    }
    
    public function index() {
        $h_helper = new HealthHelper();
        $usertdata = new HealthUserData();
        $session_id = $h_helper->getSuid();
        $portalPgs = new PortalPages();
        $MTxt =  $portalPgs->getMeta(Common_Constants::HEALTHDETAILS);
        $column = array('session_id','members_list','age_list','dob_list');
        $check_value  = array('session_id'=>$session_id);
        $userdetails = $usertdata->get_data($column,$check_value);
        $userdetails = isset($userdetails[0]) ? $userdetails[0] : $userdetails; 
        $health_trans_code = new InstaLib();
        $trans_code = $health_trans_code->get_health_tc();
        if(isset($userdetails) && !empty($userdetails)){
            $session_id = $userdetails['session_id'];
            $members = explode("|", $userdetails['members_list']); 
            $age = explode("|", $userdetails['age_list']); 
            $h_lib = new HealthLib();
            $relmembers = $h_lib->list_rel_members($members);
            $age_list = [];
            foreach($members as $key => $val) {
                $age_list[$val] = $this->get_age_list($val, $age[0]);
            }
            $data = compact('userdetails','relmembers','age_list','session_id','trans_code','MTxt');
        } 
        $data = !empty($data) ? $data : compact('session_id','trans_code','MTxt');
        return view('health.health-home', $data);
    }

    public function add_members(Request $request) {
        $html = '';
        $data = $request->all(); 
        $counter = $data['counter'];
        $h_lib = new HealthLib();
        $relmembers = $h_lib->list_members($data['memberslist']);
        $html = view('health.partials.health-append-fields', compact('relmembers', 'counter'));
        return $html;
    }

    public function age_list(Request $request) {
        $member_id = $request->get('member_id');
        $age = $request->get('age');
        $age_limit = $age-18;
        if(in_array($member_id,['SONM', 'GDAU', 'GSON', 'UDTR']) && ($age_limit == '0')){
            $out = '<option value="">Please check Self/Spouse age</option>';
        }else{
            $out = '<option value="">Select Age</option>';
        }
        if(in_array($member_id, ['SONM', 'GDAU', 'GSON', 'UDTR'])){
            for ($j=1;$j<=$age_limit;$j++){ 
                $k = '';
                $year = 'Years';
                if($j == 1) { $year = 'Year'; }
                $k = $j;
                $out .= '<option value="'.$k.'">'.$j.' '.$year.'</option>';
            }
        } else {
            for($i=18; $i<=100;$i++) {
                $out .= '<option value="'.$i.'">'.$i.' Years</option>';
            }
        }
        echo $out;
    }

    public function get_age_list($member_id, $age) {
        $age_limit = $age-19;
        $agelist = [];
        if(in_array($member_id, ['SONM', 'GDAU', 'GSON', 'UDTR'])){
            for ($j=1;$j<=$age_limit;$j++){ 
                $agelist[$j+0] = $j; }
        }else if($member_id == 'WIFE'){
            for($i=19; $i<=100;$i++) {
                $agelist[$i] = $i; }
        } else {
            for($i=18; $i<=100;$i++) {
                $agelist[$i] = $i; }
        }
        return  $agelist;
    }

}