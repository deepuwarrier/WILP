<?php
namespace App\Http\Controllers\Health;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Be\Health\HealthQuoteBe;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\RSGIBe;
use App\Be\Health\HDFCBe;
use App\Be\Health\StarBe;
use App\Be\Health\RelianceBe;
use App\Be\Health\ReligareBe;
use App\Libraries\InstaLib;
use App\Libraries\HealthLib;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthCity;
use App\Helpers\Health\HealthHelper;
use App\Models\Health\HealthRelationship;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthQuoteResponse;
use App\Http\Controllers\EmailSender;
use App\Constants\Health_Constants;
use App\Helpers\SmsHelper;
use App\Models\OtpTData;
use App\Models\Car\CarConfig;
use Input;
use Log;
use Validator;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;

class HealthPolicy extends Controller {
    
    
    public function trigger_sms(Request $request) {
        $data = $request->all();
        Log::info('SMS TRIGGER FOR FB '. print_r($data, true));
    }
    
    public function campaign_report(Request $request) {
        return view('health/campaign/reports');
    }

    public function fetch_campaign_report(Request $request) {
        $request = $request->all();
        $bl = new HealthPolicyBe;
        
        if(isset($request['report_passcode']) && $request['report_passcode'] === 'Ttibi@999'){
            //dd($request);
            $data['from_date'] = isset($request['from_date']) ? $request['from_date']  :date('d-M-Y');
            $data['to_date']   = isset($request['to_date']) ? $request['to_date']  :date('d-M-Y');
            $response = $bl->get_campagin_customer_records($data);
            return view('health.campaign.report-page', ['status'=> $response['status'], 'count'=> $response['count'],'data' => $response['data'], 'date'=> $response['date']]);
        }

        session(['error' => 'Invalid passcode']);
        return redirect()->route('health.campaign.report');

    }

    public function load_campaign_proposal(Request $request) {
        $health_lib = new HealthLib;
        $quote_tbl = new HealthQuoteResponse;
        $bl = new HealthPolicyBe;
        $column = array('totalPremium');
        $customer_inital_data = array();
        $customer_proposal_data = array();

        $check_values = array('trans_code' => $request['trans_code']);
        $q_response = $quote_tbl->get_data($column, $check_values);

        $usr_tbl = new HealthUserData;
        $column = array('deductables', 'sum_insured', 'tenure', 'campaign_initial_inputs');
        $check_values = array('trans_code' => $request['trans_code']);
        $u_response = $usr_tbl->get_data($column, $check_values);

        if(isset($u_response[0]['campaign_initial_inputs'])){
            $customer_inital_data = json_decode($u_response[0]['campaign_initial_inputs'], true);
            $customer_inital_data = $bl->get_campaign_proposal_cust_data($customer_inital_data, $request['trans_code']);
            $customer_proposal_data = $bl->get_campaign_saved_customer_data($request['trans_code']);

        }

        //insured html data rending
        $insured = view('health/campaign/proposal/insured_details', ['data' => $customer_inital_data, 
                                                                     'saved_data' => $customer_proposal_data])->render();
        $address = view('health/campaign/proposal/address_details', ['data' => $customer_inital_data, 
                                                                     'saved_data' => $customer_proposal_data])->render();
        $medical_history = view('health/campaign/proposal/medical_history', ['data' => $customer_inital_data, 
                                                                             'saved_data' => $customer_proposal_data])->render();
        $payment = view('health/campaign/proposal/payment', ['pay_mode' => $customer_proposal_data['pay_mode']])->render();

        if($q_response && $u_response){ 
            $this->SetCampaignSessions($request['trans_code'], 'proposal');
            return response()->json(['status' => true, 
                                     'state_list' => $customer_inital_data['state_list'],
                                     'insured_data' => $insured,
                                     'address_data' => $address,
                                     'medical_history_data' => $medical_history,
                                     'payment_data' => $payment,
                                     'premium' => $health_lib->format_number(round($q_response['totalPremium'])), 
                                     'sum_insured' => $health_lib->get_readable_amount($u_response[0]['sum_insured']),
                                     'deductables' => $health_lib->get_readable_amount($u_response[0]['deductables']),
                                     'tenure' => $u_response[0]['tenure']]);
        }

        Log::info('ERR002 HealthPolicy Controlller: load_campaign_proposal() '. print_r($request->all(), true));
        return response()->json(['status' => false, 'error_title' => 'Server Error ERR02', 'error_msg' => 'Please contact the support team']);
    }

    
    public function connect_campaign_pg(Request $request){
        $trans_code = $request['trans_code'];
        $customer_acceptance = $request['customer_acceptance'];
        $bl = new HealthPolicyBe;
        return $bl->connect_campaign_pg($trans_code, $customer_acceptance);
    }

    public function check_campaign_otp_status(Request $request){
        $sms = new SmsHelper;
        $car_config = new CarConfig;
        $otp_t_data = new OtpTData;
        $num_allowed_otp = '5';
        $otp_length = '4';
        $result = $otp_t_data->where('mobile', $request->mobile)->first();
        if (is_object($result)) {
            if($result->status){
                return json_encode(['status' => true, 'attempt_otp' => false, 'msg' => 'OTP verification completed']);
            }else{
                $attempts = json_decode($result->attempts, true); 
                if($attempts){
                    if($attempts['current'] <  $attempts['limit']){
                       return json_encode(['status' => true, 'attempt_otp' => true, 'attempts' => $attempts['current'].'&sol;'.$num_allowed_otp]);
                    }else{
                       return json_encode(['status' => false, 'attempt_otp' => false, 'msg' => 'OTP verification failed for '.$request->mobile.', try another number']);
                    }
                }else{
                    return json_encode(['status' => false, 'attempt_otp' => false, 'msg' => 'OTP verification failed for '.$request->mobile.', try another number']);
                }
            }
        }else{
            $this->sent_campaign_otp($request->mobile);
            return json_encode(['status' => true, 'attempt_otp' => true, 'attempts' => '1&sol;'.$num_allowed_otp]);
        }
    }

    public function verify_campaign_otp(Request $request){
        $status = 0;
        $recv_otp = str_replace('-','',$request->otp);
        Log::info('received otp. '.$recv_otp);
        $otp_t_data = new OtpTData;
        $result = $otp_t_data->where('mobile', $request->mobile)->first();
        $sent_otp = $result->sent_otp;
        $attempts = json_decode($result->attempts, true);
        if($attempts['current'] < $attempts['limit']){
            if ($sent_otp && $recv_otp == $sent_otp) {
                $status = 1; 
            }

            $attempts['current'] += 1;
            $otp_t_data->where('mobile', $request->mobile)->update( array('attempts'=>json_encode($attempts)) );

            $this->storeOtpValues($recv_otp, $sent_otp, $status, $request->mobile);
            $msg = (!$status) ? 'Incorrect OTP' : 'Verification successfull';
            $attempts['current'] = ($attempts['current'] == $attempts['limit']) ? $attempts['limit'] : $attempts['current'];
            return json_encode(['status' => $status, 'attempt_otp' => true, 'msg' => $msg, 'attempts' => $attempts['current'].'&sol;'.$attempts['limit']]);
        }
        return json_encode(['status' => false, 'attempt_otp' => false, 'msg' => 'OTP verification failed']);   
    }


    private function sent_campaign_otp($mobile_num){
        $sms = new SmsHelper;
        $car_config = new CarConfig;
        $otp_t_data = new OtpTData;
        $num_allowed_otp = '5';
        $otp_length = '4';

            $output = $sms->genrateOtp($mobile_num, $otp_length);
            $otp = session('otp');
            $this->storeOtpValues(0, $otp, 0, $mobile_num);
            $result = $otp_t_data->where('mobile', $mobile_num)->first();
            $attempts = array('limit' => $num_allowed_otp, 'current'=> 1);
            $otp_t_data->where('mobile', $mobile_num)->update( array('attempts'=>json_encode($attempts)) );
            return json_encode(['status' => true, 'attempts' => $attempts['current'].'&sol;'.$num_allowed_otp]);
    }

    private function storeOtpValues($recv_otp, $sent_otp, $status, $mobile) {
        $otp = new OtpTData;
        $query = $otp->updateOrCreate([OtpTData::MAPPER['MOBILE'] => $mobile],[OtpTData::MAPPER['SENT_OTP'] => $sent_otp,
            OtpTData::MAPPER['RECIVE_OTP'] => $recv_otp,
            OtpTData::MAPPER['STATUS'] => $status,
            OtpTData::MAPPER['MOBILE'] => $mobile]);
        return ($query) ? $otp->otp_id : 0;
    }
  
    public function save_campaign_proposaldata(Request $request){
        $data = $request->all();
        $bl = new HealthPolicyBe;
        return $bl->save_campaign_data($data);
    }

    public function close_proposal_page(Request $request){
        $this->SetCampaignSessions($request['trans_code'], 'quote');
        return json_encode(['status' => true]);
    }

    private function SetCampaignSessions($trans_code, $pointer){
        $usr_tbl = new HealthUserData;
        $column = array('campaign_customer_pointer' => $pointer);
        $check_values = array('trans_code' => $trans_code);
        $usr_tbl->set_by_usrdata($trans_code, $column);

        session(['trans_code' => $trans_code,  'pointer' => $pointer]);
    }

    public function getPremiumStatus(Request $request) {
        $trans_code = $request->trans_code;
        $product_id = $request->product_id;
        $insurance_id = $request->insurer_id;
        $price = $request->final_premium;
        $this->setProductId($product_id);
        $html = view('health/status/no_change_premium', ['price' => $price, 'insurer_id' => $insurance_id])->render();
        return response()->json(['html' => $html]);
    }


    public function getReConfirmStatus() {
        $html = view('health/status/reconfirm_status')->render();
        return response()->json(['html'=>$html]);   
    }

    public function get_AreaCode(Request $request) {
        $pincode = $request->input('pincode');
        $url = 'http://api.brokeredge.in/rest/master/getCityForPincode/'.$pincode.'';
        $client = new Client();
        try{
          $res = $client->request('POST', $url, ['body' => json_encode(['authentication' => ['accesskey' => 'TTIBI','secretkey' => 'TTIBI'] ]) ]);
        }catch(\Exception $e){
           Log::info($e->getMessage());         
        }
        $response = $res->getBody();
        return $response;
    }


    public function select_AreaCode($pincode) {
        $url = 'http://api.brokeredge.in/rest/master/getCityForPincode/'.$pincode.'';
        $client = new Client();
        try{
          $res = $client->request('POST', $url, ['body' => json_encode(['authentication' => ['accesskey' => 'TTIBI','secretkey' => 'TTIBI'] ]) ]);
        }catch(\Exception $e){
           Log::info($e->getMessage());         
        }
        $response = json_decode($res->getBody(), true);
        return $response;
    }

    public function getPremiumMissmatchStatus(Request $request) {
        $trans_code = $request->trans_code;
        $product_id = $request->product_id;
        $this->setProductId($product_id);
        $insurance_id = $request->insurer_id;
        $html = view('health/status/premium_missmatch',
            ['price' => $request->price,
                'passed_price' => $request->passed_price,
                'insurer_id' => $insurance_id])
            ->render();   

        return response()->json(['html' => $html]);
    }

    public function getBadResponseStatus() {
        $html = view('health/status/badresponse')->render();
        return response()->json(['html' => $html]);
    }

    public function get_city_list(Request $request) {
        $city_list = new HealthCity();
        $city = $city_list->get_city($request['state_id'],$request['insurer_name']);
        echo json_encode($city);
    }

    public function getCovers($user,$productId) {
        $h_helper = new HealthHelper();
        $addons = ($user['cover_id'] && $user['cover_id'] != "")?
              explode("|",$user['cover_id']) : [];
        $quotes = $h_helper->getSessionValue("reformated_quote", $user['trans_code'])[$productId];
        $prmbrkup = isset($quotes['premiumbreakup']['base']) ? $quotes['premiumbreakup']['base'] : $quotes['premiumBreakup']['base'];
        $basic_covers = array_keys($prmbrkup);
        $total_covers_ids = array_merge($basic_covers,$addons);
        $covers = [];
        foreach ($total_covers_ids as $value){
            $cover['name'] =  isset($quotes['covers'][$value]['coverId'])?
                    $quotes['covers'][$value]['coverId'] : "";
            $cover['si'] =  isset($quotes['covers'][$value]['seperateSi'])?
                    $quotes['covers'][$value]['seperateSi'] : "";
            $covers[] = $cover;
        }
        $h_helper->addDataToFile(null,['proposal_cover'=>$covers]);
        return $covers;
    }

    
    public function getMismatchStatus(Request $request){
        $html = view('health/status/premium_mismatch', compact('request'))->render();
        return response()->json(['html'=>$html]);   
    }

    public function setProductId($product_id) {
        session(['product_id' => $product_id]);
    }

    public function badResponse() {
        $h_helper = new HealthHelper();
        $session_id =   $h_helper->getSuid();
        $proposal_form_data = $h_helper->getSessionValue(Health_Constants::PROPOSAL_FORM_DATA,$session_id);
        $company_name = $proposal_form_data['insurerName'];        
        $this->email = new EmailSender;
        if (!empty($proposal_form_data)) {
            $name = $proposal_form_data['firstname'][0].' '.$proposal_form_data['lastname'][0];
            $mobile = $proposal_form_data['mobile'];
            $client_email = $proposal_form_data['email'];
            $subject = 'Health Insurance Enquiry from '.$company_name;
            $content_internal = view('health.templates.proposal_error.internal_email', ['data_value' => $proposal_form_data]);
            $content_external = view('health.templates.proposal_error.external_email',['name'=>$name,'company_name'=>$company_name]);
            $mail_data = array('subject'=>$subject,'content_external'=>$content_external,'content_internal'=>$content_internal,'proposal_form_data' => $proposal_form_data, 'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'mobile'=>$mobile);
            if($this->email->proposalErrMail($mail_data)){
                return view('api-bad-response');
            } else {

            }
        }
        return view('api-bad-response');
    }

// OTP Implementation

    public function genrateOtp(Request $request) {
        $sms = new SmsHelper;
        session(['mobile' =>$request->mobile]);
        if(session('otp_record'.$request->mobile)){
            $count = session('otp_record'.$request->mobile)['count'] + 1;
            session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
                         'count'=>$count]]);
        }else{
            session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
                         'count'=>1]]);
        }
        $carconfig = new CarConfig();
        $num_allowed_otp = $carconfig->getValue('MAX_NUM_OTP')->first()->config_value;
        //get old Otp Id
        $result = OtpTData::where('mobile', $request->mobile)->first();
        if (is_object($result) && $result->status) {
            session(['UIDNo' => $result->otp_id]);
            return array('otp' => $result->otp_id,'status'=>$result->status); // status added by vivek at 15-May-2017

        }else if(session('otp_record'.$request->mobile)['count'] > $num_allowed_otp){
            return json_encode(['overLimit'=>1,'count'=>session('otp_record'.$request->mobile)['count'],'max'=>$num_allowed_otp]);
        }else {
            $output = $sms->genrateOtp($request->mobile, Health_Constants::OTP_LENGTH);
            return $output;
        }
    }

    public function verifyOtp(Request $request) {
        $status = 0;
        $sent_otp = session('otp');
        $recv_otp = $request->code;
        if ($sent_otp && $recv_otp == $sent_otp) {
            $status = 1; }
        session(['UIDNo' => $this->storeOtpVlaues($recv_otp, $sent_otp, $status, session('mobile'))]);
        return json_encode(['status' => $status]);
    }

    public function storeOtpVlaues($recv_otp, $sent_otp, $status, $mobile) {
        $otp = new OtpTData;
        $query = $otp->updateOrCreate([OtpTData::MAPPER['MOBILE'] => $mobile],[OtpTData::MAPPER['SENT_OTP'] => $sent_otp,
            OtpTData::MAPPER['RECIVE_OTP'] => $recv_otp,
            OtpTData::MAPPER['STATUS'] => $status,
            OtpTData::MAPPER['MOBILE'] => $mobile]);
        return ($query) ? $otp->otp_id : 0;
    }


// Check RSGI Policy is Straight Through / Non-Straight Through process
    public function check_policy(Request $request){
        $rsgi_be = new RSGIBe();
        $data  = $rsgi_be->check_rsgi_policy_type($request['trans_code']);
        
        if(isset($data)){
            $data['insurer_id'] = 'rsgi';
            if(isset($request['ped_check']) && $request['ped_check'] != null){
                $data['ped_check']  = true;
                $data['ped_msg']        = 'Pre-existing disease is disclosed';
            }
            if(!empty($data['bmi']) && $data['bmi'][0]['insurerId'] == 'rsgi'){ 
                $data['bmi_check']  = true;
                $data['member']     = $data['bmi'];
                $data['bmi_msg']    = Health_Constants::BMI_MSG;
            }
            if(isset($data['memage']) && $data['memage'] != null ){
                $data['age_check']  = true;
                $data['age_msg'] = 'Insured member age is '.$data['memage'].' years.';
            }
            if(isset($data['si']) && $data['si'] != null ){
                $data['si_check']  = true;
                $data['si_msg'] = 'Sum Insured is '.$data['si'].' INR.';
            }
            $html = view('health/status/age_status', compact('data'))->render();
            return response()->json(['html' => $html]);
        }
        return response()->json(['status' => false]);
    }

// Check HDFC Policy is Straight Through / Non-Straight Through process
    public function hdfc_check_policy(Request $request){
        $hdfc_be = new HDFCBe();
        $data  = $hdfc_be->check_hdfc_policy_type($request['trans_code']);
        if(isset($data)){
            $data['insurer_id'] = 'hdfc';
            if(isset($request['ped_check']) && $request['ped_check'] != null){
                $data['ped_check']  = true;
                $data['ped_msg']    = 'Pre-existing disease is disclosed';
            }
            if(!empty($data['bmi']) && $data['bmi'][0]['insurerId'] == 'hdfc'){ 
                $data['bmi_check']  = true;
                $data['member']     = $data['bmi'];
                $data['bmi_msg']    = Health_Constants::BMI_MSG;
            }
            if(isset($data['memage']) && $data['memage'] != null ){
                $data['age_check']  = true;
                $data['age_msg'] = 'Insured member age is '.$data['memage'].' years.';
            }
            if(isset($data['si']) && $data['si'] != null ){
                $data['si_check']  = true;
                $data['si_msg'] = 'Sum Insured is '.$data['si'].' INR.';
            }
            $html = view('health/status/age_status', compact('data'))->render();
            return response()->json(['html' => $html]);
        }
        return response()->json(['status' => false]);
    }

    // Check Star Policy is Straight Through / Non-Straight Through process
    public function star_check_policy(Request $request){
        $star_be = new StarBe();
        $data  = $star_be->check_star_policy_type($request->input('trans_code'));
        if(isset($data)){
            $data['insurer_id'] = 'star';
            if(isset($data['memage']) && $data['memage'] != null ){
                $data['age_check']  = true;
                $data['age_msg'] = 'Insured member age is '.$data['memage'].' years.';
            }
            if(!empty($data['illness']) && $data['illness'] == 'true' ){
                $data['illness']  = 'true';
                $data['illness_msg'] = 'Insured members disease declared';
            }
            $html = view('health/status/age_status', compact('data'))->render();
            return response()->json(['html' => $html]);
        }
        return response()->json(['status' => false]);
    }


    // Check Reliance Policy is Straight Through 
    public function reliance_check_policy(Request $request){
        $reliance_be = new RelianceBe();
        $data  = $reliance_be->check_reliance_policy_type($request->input('trans_code'));
        if(isset($data)){
            $data['insurer_id'] = 'reliance';
            if(isset($data['memage']) && $data['memage'] != null ){
                $data['age_check']  = true;
                $data['age_msg'] = 'Insured member age is '.max($data['memage']).' years.';
            }
            if(!empty($data['illness']) && $data['illness'] == 'true' ){
                $data['illness']  = 'true';
                $data['illness_msg'] = 'Insured members disease declared';
            }
            $html = view('health/status/age_status', compact('data'))->render();
            return response()->json(['html' => $html]);
        }
        return response()->json(['status' => false]);
    }


    public function religare_ppc_case(Request $request){
        $bl   = new ReligareBe; 
        $data = $bl->parse_ppc_case($request->all());
        $html = view('health/status/age_status', compact('data'))->render();
        return response()->json(['html' => $html]);
    }

    public function getAgeStatus(Request $request){
        $data  = $request->all();
        // Age check
        if(isset($data['age']) && $data['age'] != null ){
            $ppc_msg = 'Insured member age is '.$data['age'].' years.';
        } else {
            $ppc_msg = Health_Constants::PPC_MSG;
        }
        if(isset($data['si'])){
            $ppc_msg = 'Sum Insured is '.$data['si'].' INR.';
        }
        $data['age_msg']  = '';
        $data['si_msg']  = '';
        $data['age_check'] = true;
        if($data['type'] === '1' && $data['product_type'] === 'S' && $data['age'] != null)
          $data['age_msg'] = str_replace('{AGE}', $data['age'] , Health_Constants::PPC_S_TOPUP_MSG);
        else if($data['type'] === '1' && $data['product_type'] === 'S' && $data['si'] != null)
          $data['si_msg'] = str_replace('{SI}', $data['si'] , Health_Constants::RSGI_PPC_S_TOPUP_MSG);
        else if($data['type'] === '1')  
          $data['age_msg'] = $ppc_msg; 
        else if($data['type'] === '3')  
          $data['bmi_msg'] = Health_Constants::BMI_MSG; 
        $html = view('health/status/age_status', compact('data'))->render();
        return response()->json(['html'=>$html]); 
    }

    public function store_payment_status(Request $request){
        $user_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $input['payment_date'] = $curr_date;
        $input['payment_status'] = 'TS16';
        $input['trans_status'] = 'TS16';
        $input['payment_ref_number'] = $request->input('payment_ref_num');
        $user_db->set_by_usrdata($request->input('hl_trans_code'), $input); 
    }
}
