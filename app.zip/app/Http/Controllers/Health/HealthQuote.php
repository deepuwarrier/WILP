<?php
namespace App\Http\Controllers\Health;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthQuoteResponse;
use App\Models\Health\HealthCovers;
use App\Models\Health\HealthBenifit;
use App\Models\Health\HealthSumInsured;
use App\Models\Health\HealthDeductables;
use App\Helpers\Health\QuoteHelper;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\Star\StarQuoteHelper;
use App\Helpers\Health\RSGI\RSGIQuoteHelper;
use App\Helpers\Health\HDFC\HDFCQuoteHelper;
use App\Helpers\Health\Reliance\RelianceQuoteHelper;
use App\Helpers\Health\Religare\ReligareQuotes;
use App\Be\Health\HealthQuoteBe;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\StarBe;
use App\Be\Health\RSGIBe;
use App\Be\Health\HDFCBe;
use App\Be\Health\ReligareBe;
use App\Be\Health\RelianceBe;
use Input;
use Log;
use Validator;

use App\Models\InstaInsurers;


class HealthQuote extends Controller {
    
    public function __construct() {
    }

    public function index_quotes(Request $request, $trans_code) {
        $usertdata = new HealthUserData();
        $attributes = $usertdata->getUserTData($trans_code);
        $si_list = new HealthSumInsured();
        $attributes['sum_insured_list'] = $si_list->get_suminsured_amount();
        $deductible_list = new HealthDeductables();
        $attributes['deductible_list'] = $deductible_list->get_deductible_list();
        return view('health.quote.health-quote', compact('attributes'));
    }

    public function get_quotes(Request $request, $trans_code) {
        $data = $request->input();
        $usertdata = new HealthUserData();
        $h_helper = new HealthHelper();
        $h_lib = new HealthLib();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();

        if(isset($data['update_cust_choice']) && $data['update_cust_choice'] == '1'){
            
            $this->updateQuotesChoices($data, $trans_code);
            $userdata = $usertdata->getUserTData($trans_code);
            $usrcovers = explode('|', $userdata['cover_id']);
            $a = in_array('AMBUL', $usrcovers);
            foreach($usrcovers as $key => $val){
                if($a === true && $val != "AMBUL"){
                    unset($usrcovers[$key]);
                }
            } 
            if(isset($data['deductibles'])){ $deductible = $data['deductibles'];}
            if(isset($data['deductables'])){ $deductible = $data['deductables'];}
            $input['deductables'] = ($data['product_type'] == 'S') ? $deductible : null ;
            $input['sum_insured'] = isset($data['sum_insured']) ? $data['sum_insured'] : $data['suminsured'];
            $input['rsgi_hosp_cash'] = 'off';
            $input['cover_id'] = implode('|', $usrcovers);
            $input['quote_update_date'] = $curr_date;
            $input['quote_status'] = 'TS11';
            $input['trans_status'] = 'TS11';
            $check_values = array('trans_code'=>$userdata['trans_code']);
            $usertdata->update_data($input, $check_values);
            $attributes = $usertdata->getUserTData($trans_code);
            HealthQuoteResponse::truncate();
        } else{ 
            $userdetails = $h_lib->getUserdata($data);
            $userdetails['quote_create_date'] = $curr_date;
            $userdata = $this->storeUserData($userdetails);
            $attributes = $userdata['attributes']; 
            $h_helper->addDataToFile(null,['userdata'=>$userdata]);
        }
            $si_list = new HealthSumInsured();
            $attributes['sum_insured_list'] = $si_list->get_suminsured_amount();
            $deductible_list = new HealthDeductables();
            $attributes['deductible_list'] = $deductible_list->get_deductible_list();

        return view('health.quote.health-quote', compact('attributes'));
    }


    /*  Updated code with array to object */

     // Load Star Health Quote
    public function load_star_quote(Request $request){
        $usertdata = new HealthUserData();
        $q_helper = new StarQuoteHelper();
        $star_be = new StarBe();
        $hqbe = new HealthQuoteBe;
        $data = $usertdata->get_by_usrdata($request->input('trans_code'));
        $quote_req_data = $star_be->set_quote_request($data);
        $response = $q_helper->get_quote($quote_req_data);
        $products = $hqbe->get_grp_product($data->product_type,'star');
        $products = $this->get_unavilable_product($products,$response);
        if(!empty($response)){
            $this->store_quote_resp($response,$data['id']);
        }
        $si_list = new HealthSumInsured();
        $data['sum_insured_list'] = $si_list->get_suminsured_amount();
        $deductible_list = new HealthDeductables();
        $data['deductible_list'] = $deductible_list->get_deductible_list();
        return view('health/quote/quote_box',compact('response','data','products'))->render();
    }

    //Load Royal Sundaram Quote
    public function load_rsgi_quote(Request $request) { 
        $usertdata = new HealthUserData();
        $q_helper = new RSGIQuoteHelper();
        $rsgi_be = new RSGIBe();
        $hqbe = new HealthQuoteBe;
        $data = $usertdata->get_by_usrdata($request->input('trans_code'));
        $quote_req_data = $rsgi_be->set_quote_request($data);
        $response = $q_helper->get_quote($quote_req_data);
        $products = $hqbe->get_grp_product($data->product_type,'rsgi');
        $products = $this->get_unavilable_product($products,$response);
        if(!empty($response)){
            $this->store_quote_resp($response,$data['id']);
        }
        $si_list = new HealthSumInsured();
        $data['sum_insured_list'] = $si_list->get_suminsured_amount();
        $deductible_list = new HealthDeductables();
        $data['deductible_list'] = $deductible_list->get_deductible_list();
        return view('health/quote/quote_box',compact('response','data','products'))->render();
    }

     public function update_rsgi_quote($trans_code) { 
        $usertdata = new HealthUserData();
        $q_helper = new RSGIQuoteHelper();
        $rsgi_be = new RSGIBe();
        $hqbe = new HealthQuoteBe;
        $data = $usertdata->get_by_usrdata($trans_code);
        $quote_req_data = $rsgi_be->set_quote_request($data);
        $response = $q_helper->get_quote($quote_req_data);
        $products = $hqbe->get_grp_product($data->product_type,'rsgi');
        $products = $this->get_unavilable_product($products,$response);
        if(!empty($response)){
            $this->store_quote_resp($response,$data['id']);
        }
        $si_list = new HealthSumInsured();
        $data['sum_insured'] = $si_list->get_suminsured_amount();
        $deductible_list = new HealthDeductables();
        $data['deductible_list'] = $deductible_list->get_deductible_list();
        return $trans_code;
    }

    private function get_unavilable_product($products,$response,$table = false){
        $available_product = [];

	if(!empty($response))
	        foreach ($response as $key => $value)
	        if(!empty($value)){
	            if($value->get_insurer_name() == "hdfc")
	                unset($products[substr($value->get_product_id(),0,3)]);
	            else
	                unset($products[$value->get_product_id()]);
		}
        if(!array_key_exists('HSS',$products) && array_key_exists('HS1',$products))
            unset($products['HS1']);

        else if(!array_key_exists('HS1',$products) && array_key_exists('HSS',$products))
            unset($products['HSS']);

        
        if(!array_key_exists('HSG',$products) && array_key_exists('HG1',$products))
            unset($products['HG1']);
        else if(!array_key_exists('HG1',$products) && array_key_exists('HSG',$products))
            unset($products['HSG']);

        if(array_key_exists('HSG',$products) && array_key_exists('HG1',$products) )
            unset($products['HG1']);

        if(array_key_exists('HSS',$products) && array_key_exists('HS1',$products) )
            unset($products['HS1']);

        return $products;
    }

    // Load HDFC Quote
    public function load_hdfc_quote(Request $request) { 
        $usertdata = new HealthUserData();
        $q_helper = new HDFCQuoteHelper();
        $quote_resp = new HealthQuoteResponse();
        $hqbe = new HealthQuoteBe;
        $hdfc_be = new HDFCBe();


        /* Health super-topup campaign code*/
        if( isset($request['deductible']) || isset($request['tenure']) || isset($request['sum_insured']) ){
            if(isset($request['sum_insured']))
                $values['sum_insured'] = $request['sum_insured'];

            if(isset($request['deductible']))
                $values['deductables'] = $request['deductible'];

            if(isset($request['tenure']))
                $values['tenure'] = $request['tenure'];

            $usertdata->set_by_usrdata($request['trans_code'], $values);
        }
        /* Health super-topup campaign code endse*/

        $data = $usertdata->get_by_usrdata($request->input('trans_code'));
        $quote_req_data = $hdfc_be->set_quote_request($data);
        $response = $q_helper->get_quote($quote_req_data);
        $products = $hqbe->get_grp_product($data->product_type,'hdfc');
        $products = $this->get_unavilable_product($products,$response);
        if(!empty($response)){
            HealthQuoteResponse::where('health_user_id', $data['id'])->delete();
            $this->store_quote_resp($response, $data['id']);
        }
        $si_list = new HealthSumInsured();
        $data['sum_insured_list'] = $si_list->get_suminsured_amount();
        $deductible_list = new HealthDeductables();
        $data['deductible_list'] = $deductible_list->get_deductible_list();

        /* Health super-topup campaign code*/
        if(isset($request['call_type']) && $request['call_type'] == 'campaign'){
 
            if($response){ 
                $mem_list = explode('|', $data['members_list']);
                $age_list = explode('|', $data['age_list']);
                $response = $hqbe->format_campagin_quote_response($response[0], $request->input('trans_code'));
                $members_covered = view('health/campaign/members_covered', ['members' => $mem_list, 'age' => $response['formatted_agelist'], 'member_image_array' => $response['member_image_array']])->render();
                return array('status' => true,
                             'quote_box' => view('health/campaign/hdfc/quote_box', ['data' => $response])->render(),
                             'members_covered' => $members_covered,
                             'premium' => '&#8377;'.$response['premium']
                            );
            }

            return array('status' => false);
        }    
        /* Health super-topup campaign code endse*/

        return view('health/quote/quote_box',compact('response','data','products'))->render();
    }

    // Load Reliance Quote
    public function load_reliance_quote(Request $request) { 

        $usertdata = new HealthUserData();
        $q_helper = new RelianceQuoteHelper();
        $reliance_be = new RelianceBe();
        // $hqbe = new HealthQuoteBe;
        $data = $usertdata->get_by_usrdata($request->input('trans_code'));
        $quote_req_data = $reliance_be->set_quote_request($data);
        $response = $q_helper->get_quote($quote_req_data);
        if(!empty($response)){
            $this->store_quote_resp($response,$data['id']);
        }
        return view('health/quote/quote_box',compact('response','data'))->render();
    }


    private function store_quote_resp($response,$user_id){
        $quote_resp = new HealthQuoteResponse();
        foreach($response as $resp){
            if(!empty($resp)){
            if($resp->get_insurer_name() == 'star'){
                $star_be = new StarBe();
                $value['star_suminsured_id'] = $resp->get_sumInsuredId();
                $value['star_scheme_id']  = $resp->get_schemeId();
                $value['covers'] = $star_be->cover_list($resp->get_product_id());
            }
            if($resp->get_insurer_name() == 'rsgi'){
                $rsgi_be = new RSGIBe();
                $value['rsgi_quote_id'] = $resp->get_rsgi_QuoteId();
                $value['covers'] = $rsgi_be->cover_list($resp->get_product_id());
            }
            if($resp->get_insurer_name() == 'hdfc'){
                $hdfc_be = new HDFCBe();
                $value['covers'] = $hdfc_be->cover_list($resp->get_product_id());
            }
            if($resp->get_insurer_name() == 'reliance'){
                $reliance_be = new RelianceBe();
                $value['covers'] = $reliance_be->cover_list($resp->get_product_id());
            }
            $value['session_id'] = $resp->get_trans_code();
            $value['trans_code'] = $resp->get_trans_code();
            $value['productId'] = $resp->get_product_id();
            $value['insurerId'] = $resp->get_insurer_name();
            $value['planSI']    = $resp->get_sum_insured();
            $value['health_user_id'] = $user_id;
            $value['productType'] = $resp->get_product_type();
            $value['productName'] = $resp->get_product_name();
            $value['product_planname'] = '';
            $value['insurerName'] = $resp->get_insurer_name();
            $value['netPremium'] = $resp->get_premium();
            $value['serviceTax'] = $resp->get_serviceTax();
            $value['cgst'] = $resp->get_serviceTax()/2 ;
            $value['sgst'] = $resp->get_serviceTax()/2;
            $value['totalPremium'] = $resp->get_totalPremium();
            $quote_resp->update_or_create(['productId' => $resp->get_product_id()], $value);
        }
        }
    }

    public function load_proposal_page(Request $request){
        $usr_db = new HealthUserData();
        $data = $request->all();
        $insta_insurers = new InstaInsurers();
        $insurer = $insta_insurers->insurer_details($data['insurer_code']);
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $usr_dt_store = array(
            'productId' => $data['product_id'],
            'productName' => $data['product_name'],
            'plan_code'   => (!empty($data['plan_code'])) ? $data['plan_code'] : $data['product_plan'],
            'insurerId'   =>   $insurer['insurer_code'],
            'insurerName' => $data['insurer_name'],
            'sum_insured' => $data['sum_insured'],
            'deductables' => $data['deductible_amount'],
            'sum_insuredid' => $data['sum_insuredid'],
            'scheme_id' => $data['scheme_id'],
            'plan_id' => $data['plan_id'],
            'basePremium' => $data['premium'],
            'serviceTax' => $data['serviceTax'],
            'cgst' => $data['serviceTax']/2,
            'sgst' => $data['serviceTax']/2,
            'totalPremium' => $data['total_premium'],
            'agree_med_chkup' => 0,
            'rsgi_quote_id' => $data['rsgi_quote_id'],
            'quote_update_date' => $curr_date,
            'quote_status' => 'TS12',
            'proposal_date' => $curr_date,
            'proposal_status' => 'TS13',
            'trans_status' => 'TS13'
        );
        $usr_db->set_by_usrdata($data['trans_code'], $usr_dt_store);
        return redirect('/health-insurance/'.$insurer['insurer_url'].'/'. $data['trans_code']);
    }

/*    Ends Updated code with array to object*/

    //Load Religare Quote
    public function load_religare_quote(Request $request){
        $bl       = new ReligareBe;
        $helper   = new ReligareQuotes;
        $usertdata = new HealthUserData();
        $hqbe = new HealthQuoteBe;
        $data     = $usertdata->getUserTData($request->input('trans_code') );
        // temp code for tenure
        if($data['tenure'] == '1'){
            $rel_flag = $bl->is_religare_type($data);
        if($rel_flag){
            $quote_response = $helper->get_quotes($data);
            $response = $bl->parse_quote_response($quote_response, $data);
            $products = $hqbe->get_grp_product($data['product_type'],'religare');
            $products = $this->get_unavilable_product($products,$response);
            return view('health/quote/quote_box',compact('response','data','products'))->render();
            } 
        }  
    }

    public function filter_covers(Request $request) { 
        $usertdata = new HealthUserData();
        $h_covers = new HealthCovers();
        $quote_resp_modl = new HealthQuoteResponse();
        $trans_code = $request->input('trans_code');
        $data['response'] = $quote_resp_modl->getresponse($trans_code);
        $data['h_covers'] = $h_covers->getCovers();
        $attributes = $usertdata->getUserTData($trans_code);
        return view('health/quote/health_covers',compact('data','attributes'))->render();
    }

    public function filter_quote(Request $request) {
        $flag = 1;
        $val = $request->input();
        $usertdata = new HealthUserData();
        $h_helper = new HealthHelper();
        $quote_resp = new HealthQuoteResponse();
        $quote_be = new HealthQuoteBe();
        
        $check_values = array('health_user_id'=>$val['id']);
        $health_response = $quote_resp->get_filter_data($check_values);
        $product_type = 'S';
        if(!empty($health_response->toArray())){
            $h_userdata = $usertdata->getUserTData($val['trans_code']);
            $product_type = $h_userdata['product_type'];
            $deductables = $h_userdata['deductables']; // For Super Topup
            $trans_code = $val['trans_code'];
            $checks = explode('|', $val['chks']);
            // remove extra empty value
            if(end($checks) == ''){ unset($checks[count($checks) - 1]); }
            $empty_filter = 0;
            if(empty($checks))
                $empty_filter = 1;
                $filter_data = [];

            if ($health_response) {
                foreach ($health_response as $value) {
                    if(!empty($value->covers)){
                        $covers = json_decode($value->covers);
                        $coverId = [];
                        if(!empty($covers)){
                            foreach ($covers as $cover) {
                                // covers filter
                                $coverId[] = $cover->coverId;
                                $coverLimits = $cover->coverLimits;
                                // room rent filter
                                foreach ($coverLimits as $room_rent) {
                                    $coverId[] = $room_rent->limitValue; 
                                }
                            } 
                        }
                        if($empty_filter){ 
                            $filter_data[] = $value; 
                        }else{
                            $matchedElement = array_intersect($coverId, $checks);
                            if(empty(array_diff($checks, $matchedElement)) and count($checks) == count($matchedElement))
                                $filter_data[] = $value; 
                        } 
                    } 
                } 
            } 
            // store selected covers to health_t_usrdata
            $trans_code = $val['trans_code'];
            $input['cover_id'] = implode('|',$checks);
            // Storing HOC value for royal sundaram 
            if (in_array("HOC", $checks)){
                $input['rsgi_hosp_cash'] = 'on';
            }else{
                $input['rsgi_hosp_cash'] = 'off';
            }

            $condition_values = array('trans_code' => $trans_code);
            $usertdata->update_data($input,$condition_values);
            $rsgi_trans_code = $this->update_rsgi_quote($trans_code);
            $chk_val = array('trans_code'=> $rsgi_trans_code);
            $health_updated_response = $quote_resp->get_filter_data($chk_val);
            $checks = explode('|', $val['chks']);

            if(end($checks) == ''){
                unset($checks[count($checks) - 1]);
            }
            $empty_filter = 0;
            if(empty($checks))
                $empty_filter = 1;
                $filter_up_data = [];

            if (isset($health_updated_response)) {
                foreach ($health_updated_response as $value) {
                    if(!empty($value->covers)){
                        $covers = json_decode($value->covers);
                        $coverId = [];
                        if(!empty($covers)){
                            foreach ($covers as $cover) {
                                $coverId[] = $cover->coverId;
                                $coverLimits = $cover->coverLimits;
                                foreach ($coverLimits as $room_rent) {
                                    $coverId[] = $room_rent->limitValue; 
                                }
                            } 
                        }
                        if($empty_filter){ 
                            $filter_up_data[] = $value; 
                        }else{
                            $matchedElement = array_intersect($coverId, $checks);
                            if (empty(array_diff($checks, $matchedElement)) and count($checks) == count($matchedElement))
                                $filter_up_data[] = $value; 
                        } 
                    } 
                }
            }

             // Ends Storing 
            if (!empty($filter_up_data) ) { 
                $filter_response = $filter_up_data; 
                $data = $val; 
            } elseif (!empty($filter_data)) { 
                $filter_response = $filter_data; 
                $data = $val;
            } else { 
                $filter_response = ''; 
                $data = $h_userdata;
                $flag = 0; 
            }

            // For Super Topup
            $data['deductables'] = $deductables; 
            $spr_response = array();
            if($val['product_type'] === 'S'){
                for($i=0; $i<sizeof($filter_response);$i++){
                    $arr =(is_array($filter_response[$i]))?$filter_response[$i] : $filter_response[$i]->toArray();
                    if(substr($arr['productId'], 0, 3 ) === 'HST'){
                        $spr_response[] = $arr; 
                    }
                }
                $filter_response = $spr_response;
                $flag = (!empty($spr_response)) ? '1' : '0';
            }
            if(!empty($filter_response)){ 
                foreach($filter_response as $resp){
                    $response[] = $quote_be->set_filter_quote_resp($resp);
                }

            $products = $quote_be->get_products($product_type);
            $products = $this->get_unavilable_product($products,$response);
            return view('health/quote/quote_box', compact('response', 'data', 'flag','products'))->render();
            } else{  $flag = 0; }
        }

        $flag = 0;
        $response = '';
        $products = $quote_be->get_products($product_type);
        $products = $this->get_unavilable_product($products,$response);
        return view('health/quote/quote_box',compact('response', 'data', 'flag','products'))->render();
    }

    public function storeUserData($data) {
        $h_helper = new HealthHelper();
        $usertdata = new HealthUserData();
        $policy_be = new HealthPolicyBe();
        $policy_date = $policy_be->get_policy_date($data['tenure']);
        $input['quote_create_date'] = $data['quote_create_date'];
        $input['quote_status'] = 'TS10';
        $input['trans_status'] = 'TS10';
        $input['plan_type'] = $data['productType'];
        $input['age_list'] = $data['agelist'];
        $input['dob_list'] = $data['doblist']['doblist'];
        $input['members_list'] = $data['memberslist'];
        $input['gender'] = $data['genderlist']['genders'];
        $input['title'] = $data['genderlist']['title'];
        $input['adult'] = $data['doblist']['adult'];
        $input['children'] = $data['doblist']['children'];
        $input['tenure'] = $data['tenure'];
        $input['policy_start_date'] = date("j-M-Y", strtotime($policy_date['p_start']));
        $input['policy_exp_date'] = date("j-M-Y", strtotime($policy_date['p_ends']));
        $input['sum_insured'] = $data['suminsured'];
        $input['pincode'] = $data['pincode'];
        $input['cover_id'] = 'AMBUL';
        $input['product_type'] = 'B';
        $input['rsgi_hosp_cash'] = 'off';
        $input['session_id'] = $data['trans_code'];
        $input['trans_code'] = $data['trans_code'];
        $input['user_code'] = session("user_agent") != true ? session("user_code") : null;
        $input['agent_code'] = session("user_role") == '_AGENT' ? session("user_code") : null;
        return $usertdata->update_or_create(['trans_code'=>$data['trans_code']],$input);
    }

    public function store_user_transaction_data(Request $request) {
        $quote_resp_modl = new HealthQuoteResponse();
        $usertdata = new HealthUserData();
        $userdata = $quote_resp_modl->getdata($request->input('trans_code'),$request->input('product_id'));
        $userdata['basePremium'] = $userdata['netPremium'];
        $userdata['sum_insured'] = $userdata['planSI'];
        $usertdata->update_or_create(['trans_code'=>$request->input('trans_code')],$userdata);
    }

    private function updateQuotesChoices($data, $trans_code) {
        $usertdata = new HealthUserData();
        $policy_be = new HealthPolicyBe();
        $policy_date = $policy_be->get_policy_date($data['tenure']);
        $input['plan_type']  = $data['plan_type'];
        $input['deductables'] = isset($data['deductables'])? $data['deductables'] : null;
        $input['sum_insured'] = isset($data['suminsured']) ? $data['suminsured'] : '';
        $input['product_type'] = isset($data['product_type'])?$data['product_type'] :'B';
        $input['tenure'] = $data['tenure'];
        $input['policy_start_date'] = date("j-M-Y", strtotime($policy_date['p_start']));
        $input['policy_exp_date'] = date("j-M-Y", strtotime($policy_date['p_ends']));
        $check_values = array('trans_code'=> $trans_code);
        $usertdata->update_data($input, $check_values);
        return $input;
    }

    private function get_cover_plan($pro_id, $SI) { 
        try{
            $quote_be = new HealthQuoteBe();
            $h_benifit = new HealthBenifit();
            $features = $quote_be->get_benifit_plans($pro_id, $SI);
            $benifit = $h_benifit->get_benifit($features)->toArray();
            return $benifit;
        }catch(\Exception $e){} 
    }

    public function get_package_info(Request $request) {
        $usertdata = new HealthUserData();
        $res = $request->all();
        $trans_code = $request['trans_code'];
        $data   = $usertdata->getUserTData($trans_code);
        $age_list = explode('|', $data['age_list']);
        $elder    = max($age_list);
        $reqdata = $usertdata->get_deductables($trans_code);
        $res['deductables'] = $reqdata['deductables'];
        $res['product_type'] = $reqdata['product_type'];
        $res['age']          = $elder;
        $data['benifit_plan'] = $this->get_cover_plan($res['product_id'],$res['suminsured']);
        return view('health.partials.package_info', compact('data','res'));
    }

    public function get_policy_breakup(Request $request) {
        $usertdata = new HealthUserData();
        $quote_resp = new HealthQuoteResponse();
        $res = $request->all();
        $trans_code = $request['trans_code'];
        $reqdata = $usertdata->get_deductables($trans_code);
        $data    = $usertdata->getUserTData($trans_code);
        $res['deductables'] = $reqdata['deductables'];
        $res['product_type'] = $reqdata['product_type'];
        $age_list = explode('|', $data['age_list']);
        $elder    = max($age_list);
        $res['age'] = $elder;
        return view('health.partials.policy_breakup', compact('res'));
    }

    public function load_no_response(){
        $response = null;
        return view('health/quote/quote_box', compact('response','data'))->render();
    }
}
