<?php
namespace App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Constants\Health_Constants;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Http\Controllers\Controller;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\HDFC\HDFCPolicyHelper;
use App\Models\Health\data\PolicyPageData;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthRelationship;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthPED;
use App\Models\Health\HealthDeductables;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\HDFCBe;
use App\Http\Controllers\EmailSender;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;
use App\Models\InstaInsurers;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;

class HDFC extends Controller {
  
    public function __construct() {
        $this->email = new EmailSender;
    }

    public function load_policy_page($hl_trans_code)
    {
        $policy_page_data = new PolicyPageData();
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($hl_trans_code);
        
        $insr_column = "hdfc_code";
        // session(['hl_trans_code' => $hl_trans_code]);
        $usr_db = new HealthUserData();
        $usr_data = $usr_db->get_by_usrdata($hl_trans_code);
        // Nominee list
        $nomrel_db = new NomiRelationship();
        $policy_page_data->set_nominee_rel_list($nomrel_db->nominee_rel_list($insr_column) );
        // Relation members list
        $rel_db = new HealthRelationship();
        $policy_page_data->set_relation_list($rel_db->get_relationship_ids($insr_column));
        // State List
        $state_db = new HealthState();
        $policy_page_data->set_state($state_db->get_state($insr_column));
        // PED list
        $ped_db = new HealthPED();
        $policy_page_data->set_ped_list($ped_db->get_ped_list($insr_column, 'ped'));
        // Deductible amount list
        $deductible_db = new HealthDeductables();
        $policy_page_data->set_deductibles_list($deductible_db->get_deductible_amount($insr_column));
        $policy_be = new HealthPolicyBe();
        $quote_resp =  $policy_be->parse_proposal_data($usr_data);
        $dob_list =    $policy_be->set_dob_list($quote_resp);
       
        $hdfc_be = new HDFCBe();
        $details = $hdfc_be->set_proposal_details($usr_data);
        if(!empty($usr_data['state'])){
            $citylist = new HealthCity();
            $details['city_list'] = $citylist->get_city( $usr_data['state'], 'hdfc');
        }
        $insta_insurer = new InstaInsurers();
        $insurer_details = $insta_insurer->insurer_details($usr_data['insurerId']);
        return view('health/policy/hdfc_proposal_home', [ 
                'hl_trans_code' => $hl_trans_code,
                'base_data' => $policy_page_data,
                'quote' => $quote_resp,
                'data' => $details,
                'doblist' =>$dob_list,
                'insurer_details' => $insurer_details
        ]);
    }

   public static function store_proposal_data(Request $request){
        $h_lib = new HealthLib();
        $user_db = new HealthUserData();
        $data = $request->all();
        $user_data = $user_db->get_by_usrdata($data['trans_code']);
        $hl_trans_code = $data['trans_code'];
        // Identifies the data from which TAB, Eg: Insured, Communication
        $section     = $data['id'];
        // Unsetting the extra values
        unset($data['id']);
        unset($data['_token']);
        // Insured section
        if($section == 'insured'){
            $dob = array();
            // Re-formating d-m-Y to Y-m-d
            if (isset($data['dob_list'])) { 
                foreach ($data['dob_list'] as $dob) {
                    $doblist[] = date('Y-m-d', strtotime($dob));
                }
            }
        $gender_list = explode('|', $user_data['gender']);
        $replacements = array(0 => $data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        $data['dob_list']  = implode('|', $doblist);
        $data['age_list']  = $user_data['age_list'];
        $data['gender'] = implode("|",$gender);
        $data['firstname'] = implode('|', $data['firstname']);
        $data['lastname']  = implode('|', $data['lastname']);
        $data['height_feet']  = implode('|', $data['height_feet']);
        $data['height_inches']  = implode('|', $data['height_inches']);
        $data['weight']  = implode('|', $data['weight']);
        }
        // Health History Section 
        if($section == 'healthhistory'){
            unset($data['trans_code']);
            $pedlist = json_encode($data);
            unset($data);
            $data['ped_list'] = $pedlist;
        }
        try {
            $health_transaction = $user_db->set_by_usrdata(array('trans_code' =>$hl_trans_code),$data);
        } catch (Exception $e) {
            Log::info('HEALTH_HDFC_SAVE_PROPOSAL'. print_r($e->getMessage(), true));
        return 0;
        } 
    }

    public function submit_proposal(Request $request){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $hdfc_be = new HDFCBe();
        $curr_date = $insta_lib->today_date_dMY();
        $input['proposal_date'] = $curr_date;
        $input['proposal_status'] = 'TS14';
        $input['trans_status'] = 'TS14';
        $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 

        // $validation_arr = $this->validate_data($usr_db->get_by_usrdata($request->input('hl_trans_code')));

        // if($validation_arr["verror"]){ 
        //     return json_encode(["status" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ]);
        // }


        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($request->input('hl_trans_code'));

        
        $hdfc_helper = new HDFCPolicyHelper();
        if(!empty($request->input('new_premium'))){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS20';
            $input['trans_status'] = 'TS20';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            $this->update_response($request->input());
        }
        $proposal_req_data = $hdfc_be->set_proposal_data($request->all());
        $proposal_response = $hdfc_helper->get_proposal_response($proposal_req_data);
        $response = json_decode($proposal_response);

        $input['rsgi_refr_status'] = (isset($response->status) && $response->status === "false" && $response->message === "Customer-aceptance") ? 'NONSTP' : "" ;
        $input['agree_med_chkup'] = ($request->input('agree_med_chkup')  == 1) ? 1 : 0;
        
        //Checking Geo Restrictions
        $geo_restric_rsp = $hdfc_be->check_geo_restrictions($proposal_req_data->get_hl_trans_code());
        if(!$geo_restric_rsp['status'])
            return json_encode(["status" => "gerror", "g_txt"=> $geo_restric_rsp['msg']]);
            
        $usr_db->set_by_usrdata($proposal_req_data->get_hl_trans_code(), $input); 
        $hdfcusr_data = $usr_db->get_by_usrdata($proposal_req_data->get_hl_trans_code());
        // If Policy  refer to medical evaluation need customer confirmation
        if($hdfcusr_data['rsgi_refr_status'] == 'NONSTP' && $hdfcusr_data['agree_med_chkup'] != 1){
            $data['policytype'] = 'NONSTP';
            return $data;  
        }
        // if premiuem mismatch 
        if(isset($response->premiumPayable) && $response->premiumPayable != $hdfcusr_data['totalPremium']  ){
            $data = [
                'error' => "premium mismatch",
                'premiumPayable' => $response->premiumPayable,
                'premiumPassed' => round($hdfcusr_data['totalPremium']) 
            ];
            return $data; 
        } else{
            if($response->status == 'true' || $response->status == '1'){
                 $input['proposal_date'] = $curr_date;
                 $input['proposal_status'] = 'TS15';
                 $input['trans_status'] = 'TS15';
                 $input['proposal_ref_number'] = '';
                 $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 
            }else{
                 $input['proposal_date'] = $curr_date;
                 $input['proposal_status'] = 'TS01';
                 $input['trans_status'] = 'TS01';
                  $input['proposal_ref_number'] = '';
                 $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
                 // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
            }
            return $proposal_response;
        }
        return json_encode(['status' => 'offline','message' => Health_Constants::HEALTH_PROPOSAL_ERROR_MSG]);
    }

    private function validate_data($usr_data){
        $first_name_list = explode('|', $usr_data->firstname);
        $sur_name_list = explode('|', $usr_data->lastname);
        $height_feet_list   =   explode('|',$usr_data->height_feet);
        $height_inches_list   =   explode('|',$usr_data->height_inches);
        $weight_list   =   explode('|',$usr_data->weight);
        foreach ($first_name_list as $key => $value) {
            $customer_list_name[] = $value.' '.$sur_name_list[$key];
        }

        $ped_list = json_decode($usr_data->ped_list);
        

        $customer_dob_list = explode('|', $usr_data->dob_list);
        // $pedlifestyle_list = json_decode($usr_data->ped_lifestyle, true);
        // dd($pedlifestyle_list);
        /*
            {"ped":{"illness":"1"},"pedname":{"disease_member_1":"sdfsdfsd","disease_member_2":"sdfsdfsdf"}}
        */

        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->mobile,
                            'customer_name' => $customer_list_name,
                            'pc_customer_dob' => $customer_dob_list,
                            'customer_aadharno' => $usr_data->aadhaar_num,
                            'customer_email' => $usr_data->email,
                            'customer_add1' => $usr_data->house_num,
                            'customer_add2' => $usr_data->street,
                            'customer_add3' => $usr_data->locality,
                            'customer_pincode' => $usr_data->cust_pincode,
                            'nominee_name' => $usr_data->nominee_name,
                            'number'    =>  [
                                                $usr_data->nominee_age,
                                                $height_feet_list,
                                                $height_inches_list,
                                            ],
                            'empty' => [
                                            // $pedlifestyle_list,
                                            $weight_list,
                                        ]
                        ];
        if($ped_list->ped->illness == 1){
            foreach ($ped_list->pedname as $key => $value) {
                if($value != null){
                    $pedname_list[] =  $value;
                    break;
                } else {
                    $pedname_list = null;
                }
            }
            $required_array['alpha_with_space_comma'] = $pedname_list;
        }
        return $valid_lib->proposalSubmit($required_array);
    }

    public function update_pay_mode(Request $request){
        $hdfc_be = new HDFCBe;
        return $hdfc_be->update_paymode($request->all());
    }

    // New function for handle campaign pg response
    public function handle_campaign_policy_return($response, $trans_code){
        $hdfc_be = new HDFCBe;
        return $hdfc_be->parse_campaign_pg_response($response, $trans_code);
    }   


    public function policy_return_page(Request $request){
        // $trans_code =  session('hl_trans_code');
        $data = $request->all();
        Log::info("Health HDFC Payment Response : " . print_r($data, true));
        $usertdata = new HealthUserData();
        $payment_parse_be = new PaymentParseBE;
        $trans_code = $payment_parse_be->getPaymentIdentifier($data['PolicyNo']);

        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();

        // Added by Sreehari R : 12/02/2019 (dd/mm/yyyy)
        // Since the exsiting code here is not properly handling the return response
        // I am writing an new function to handle supertopup campaign return response
        if($data!=null && isset($data['ProposalNo']) ){
            $column = array('trans_code', 'campaign_initial_inputs');
            $check_values = array('campaign_txn_number' => $data['ProposalNo']);
            $response = $usertdata->get_data($column, $check_values);
            if($response != null && $response[0]['campaign_initial_inputs'] !=null){
                $trans_code = $response[0]['trans_code'];
                $response = $this->handle_campaign_policy_return($data, $trans_code);
                $response = json_decode($response, true);
                return view('health.campaign.return_page', compact('response'));
            }
            
        }

        // **************** Campaign code ends *************************************
        
        Log::info('Health HDFC Basic Plan Payment response - '.$trans_code.'', $data);
        $healthtpolicy = new HealthTPolicy();
        $table = ['trans_code' => $trans_code, Health_Constants::HEALTH_T_PROPOSALLOG['PAYMENT_RESP_LOG'] => json_encode($data) ];
        if(isset($data['PolicyNo']) && $data['PolicyNo'] != "0"){
            $table[Health_Constants::HEALTH_T_PROPOSALLOG['POLICY_NU']] = $data['PolicyNo'];
            $table[Health_Constants::HEALTH_T_PROPOSALLOG['PAYMENT_STATUS']] = $data['Msg'];
            $table['payment_status'] = 'TS17';
            $table['trans_status'] = 'TS17';
           
            $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
           
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);

            $table['policy_status'] = 'TS19';
            $table['payment_ref_number'] = '';
            $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
           
            // Mail config
            $email_engine =  new EmailEngine; 
            //$email_engine->send_email($trans_code);
           
        }else{
            $table[Health_Constants::HEALTH_T_PROPOSALLOG['TRANSACTION_ID']]=$data['ProposalNo'];
            $table[Health_Constants::HEALTH_T_PROPOSALLOG['PAYMENT_STATUS']] = $data['Msg'];
            $table['payment_status'] = 'TS02';
            $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);

            $table['trans_status'] = 'TS03';
            $table['policy_status'] = 'TS03';
            $table['payment_ref_number'] = $data['ProposalNo'];
            $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
            // Mail config
            $email_engine =  new EmailEngine; 
            //$email_engine->send_email($trans_code);
        }
        $table['policy_date'] = $curr_date;
        $table['payment_date'] = $curr_date;
        $table['payment_desc'] = $data['Msg'];
        $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
        
        // end store transaction detail
        $status = (isset($data['PolicyNo']) && $data['PolicyNo'] != "0") ? 1 : 0;
        
        if($status == 1){
             $input['trans_code'] = $trans_code.'_DONE';
             $usertdata->set_by_usrdata(array($trans_code), $input);
             $usr_data = $usertdata->getUserTData($trans_code.'_DONE');
            
            // Policy Counter Service
            $policy_service = new PolicyCounterService();
            $req_arr = array(
                        "module_name"=> "HL",
                        "insurer_code"=> "HDFC",
                        "agent_code"=> (empty($usr_data['agent_code'])) ? '' : $usr_data['agent_code'],
                        "policy_date"=> $curr_date,
                        "policy_type"=> ($usr_data['product_type'] == 'B') ? 'C' : 'STP',
                        "policy_nature"=> "New",
                        "policy_number"=> $data['PolicyNo'],
                        "od_premium"=> $usr_data['basePremium'],
                        "tp_premium"=> 0,
                        "total_premium"=> $usr_data['basePremium'],
                        "tax"=> round($usr_data['serviceTax']),
                        "final_premium"=> $usr_data['totalPremium']
            );
            $response_status = $policy_service->service_handler($req_arr);
            Log::info('Policy Counter Status '.$usr_data['trans_code'].':', array($response_status));
            // Ends Policy Counter Service
            $policy_transaction = $healthtpolicy->set_policy_details($usr_data);
        }

        $msg = 0;
        if(($data['PolicyNo'] == null || $data['PolicyNo'] == '0') && $data['Msg'] == 'Successfull') {
            $msg = 'Thank you. We have accepted your initial payment.';
        }
        $data_main = ['status' => $status, 'msg' => $msg, 'logo' => 'hdfc', 'udata' => $data];
        try {
            $proposal_form_data = session('proposal_form_data');
           if (!empty($proposal_form_data)) {
            $company_name = "HDFC ERGO";
            $proposal_form_data['insurerName'] = "HDFC ERGO";
            $name = $proposal_form_data['firstname']['0']. ' ' .$proposal_form_data['lastname']['0'];
            $client_email = $proposal_form_data['email'];
            $mobile = $proposal_form_data['mobile'];
            $proposal_request_url = '';
            $proposal_form_result = '';
                if ($status) { 
                    $subject = 'Health insurance purchased for '.$company_name;
                    $subject_success = "Congrats you have successfully puchased health insurance from ".$company_name;
                    $view_email_internal = view('health.templates.payment_success.internal_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'client_email'=>$client_email,'name'=>$name, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name]);
                    $view_email_external = view('health.templates.payment_success.external_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'client_email'=>$client_email,'name'=>$name, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name]);
                    $mail_data = array('proposal_form_data' => $proposal_form_data,'name'=>$name,'subject'=>$subject,'subject_success'=>$subject_success, 'client_email'=>$client_email, 'company_name' => $company_name, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
                    $status = $this->email->proposalSuccMail($mail_data);
                } else {
                    if(isset($msg) && $msg != '0'){
                    $subject = 'Initial payment accepted for Health insurance - '.$company_name;
                    $subject_failure = "Thank you, We have accepted your initial payment. We will assess the same as per our underwriting guidelines and will keep you informed for purchasing health insurance from ".$company_name;
                    }
                    else{
                    $subject = 'Payment failed for Health insurance - '.$company_name;
                    $subject_failure = "Sorry, there has been some issue while purchasing health insurance from ".$company_name;
                    }
                    $view_email_internal = view('health.templates.payment_failed.internal_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'client_email'=>$client_email,'name'=>$name, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name]);
                    $view_email_external = view('health.templates.payment_failed.external_email', ['data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'client_email'=>$client_email,'name'=>$name, 'proposal_form_result' => $proposal_form_result,'company_name'=>$company_name,'name'=>$name]);
                    $mail_data = array('proposal_form_data' => $proposal_form_data,'name'=>$name,'subject'=>$subject,'subject_failure'=>$subject_failure, 'client_email'=>$client_email, 'company_name' => $company_name, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
                    $status = $this->email->proposalFailMail($mail_data);
                }
            }
        } catch (Excaption $e) {
        } finally {
            return view('health.return_page.hdfc', $data_main);
        }
    }


    public function offline_policy() {
        $h_helper = new HealthHelper();
        $userdata = new HealthUserData();
        $msg = request()->msg;
        if($msg!= null){
            if($msg === 'HL202'){
                $msg = Health_Constants::HL202;
            }else{
                return \Redirect::to('health-insurance');
            }
        }
        $data_main = ['status' => 0, 'logo' => 'hdfc', 'msg' => $msg];
        return view('health.return_page.offline_policy_page', compact('data_main'));
    }

    private function update_response($resp_data){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $updated_data = [
            'proposal_date' => $curr_date, 
            'proposal_status' => 'TS21',
            'trans_status' => 'TS21',
            'totalPremium' => $resp_data['new_total_premium'],
            'basePremium' => $resp_data['new_premium'],
            'serviceTax' => $resp_data['new_service_tax'],
            'cgst' => $resp_data['new_service_tax']/2,
            'sgst' => $resp_data['new_service_tax']/2
        ];
        $usr_db->set_by_usrdata($resp_data['hl_trans_code'], $updated_data);        
    }
}
