<?php
namespace App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Constants\Health_Constants;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Http\Controllers\Controller;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\RSGI\RSGIPolicyHelper;
use App\Models\Health\data\PolicyPageData;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthRelationship;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthPED;
use App\Models\Health\HealthDeductables;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\RSGIBe;
use App\Http\Controllers\EmailSender;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;
use App\Models\InstaInsurers;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;

class RSGI extends Controller {
  
    public function __construct() {
        $this->email = new EmailSender;
    }

    public function load_policy_page($hl_trans_code)
    {
        $policy_page_data = new PolicyPageData();
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($hl_trans_code);
        $insr_column = "rsgi_code";
        // session(['hl_trans_code' => $hl_trans_code]);
        $usr_db = new HealthUserData();
        $usr_data = $usr_db->get_by_usrdata($hl_trans_code);
        // Occupation list
        $occ_db = new HealthOccupation();
        $policy_page_data->set_occupation_list($occ_db->occupation_list($insr_column)); 
        // Nominee list
        $nomrel_db = new NomiRelationship();
        $policy_page_data->set_nominee_rel_list($nomrel_db->nominee_rel_list($insr_column) );
        // Relation members list
        $rel_db = new HealthRelationship();
        $policy_page_data->set_relation_list($rel_db->get_relationship_ids($insr_column));
        // State List
        $state_db = new HealthState();
        $policy_page_data->set_state($state_db->get_state($insr_column));
        // PED list
        $ped_db = new HealthPED();
        $policy_page_data->set_ped_list($ped_db->get_ped_list($insr_column, 'ped'));
        $policy_page_data->set_ped_lifestyle_questions($ped_db->get_ped_list($insr_column, 'lifestyle'));
        // Deductible amount list
        $deductible_db = new HealthDeductables();
        $policy_page_data->set_deductibles_list($deductible_db->get_deductible_amount($insr_column));
        $policy_be = new HealthPolicyBe();
        $quote_resp =  $policy_be->parse_proposal_data($usr_data);
        $dob_list = $policy_be->set_dob_list($quote_resp);

        $rsgi_be = new RSGIBe();
        $details = $rsgi_be->set_proposal_details($usr_data);
        if(!empty($usr_data['state'])){
            $citylist = new HealthCity();
            $details['city_list'] = $citylist->get_city( $usr_data['state'], 'rsgi');
        }
        $insta_insurer = new InstaInsurers();
        $insurer_details = $insta_insurer->insurer_details($usr_data['insurerId']);
        return view('health/policy/rsgi_proposal_home', [ 
                'hl_trans_code' => $hl_trans_code,
                'base_data' => $policy_page_data,
                'quote' => $quote_resp,
                'data' => $details,
                'doblist' =>$dob_list,
                'insurer_details' => $insurer_details
        ]);
    }

    public function store_proposal_data(Request $request){
        $h_lib = new HealthLib();
        $usertdata = new HealthUserData();
        $rsgi_be = new RSGIBe();
        $values = $request->all();
        if(isset($values['id']))
            $field = $this->getFieldMap(strtoupper($values['id']));
        else 
            $field = $this->getFieldMap();
        $user_data = $usertdata->get_by_usrdata($values['trans_code']);
        if(isset($field['ped_list'])){
            $pedList = [];
        foreach ($values['ped'] as $key => $value) {
            $pedList[$key] = $value; }
            if(isset($values['question_info']) && !empty($values['question_info'])){
                foreach ($values['question_info'] as $key => $kvalue) {
                $pedList[$key] = $kvalue; }
            }
            $table[$field['ped_list']] = json_encode($pedList); }
        $occu = $rsgi_be->get_member_occupation_details($values);
        foreach($occu as $value){
            $occupation[] = $value['0'];
            $designation[] = $value['1'];
            $business[] = $value['2']; }
        if(isset($occupation) && isset($field['occupation'])) {
            $table['occupation'] = implode("|", $occupation); }
        if(isset($designation) && isset($field['designation'])) {
            $table['designation'] = implode("|", $designation); }
        if(isset($business) && isset($field['business'])){
            $table['business'] = implode("|", $business); }
        // map and genrate a array table columna name and value
        foreach ($field as $key => $value)
            if (isset($values[$value]))
                $table[$key] = (is_array($values[$value])) ? implode("|", $values[$value]) : $values[$value];
            // if dob_list is set than
            if (isset($table['dob_list'])) {
                $dob_list = explode("|", $table['dob_list']);
                foreach ($dob_list as $dob) {
                    $dob1 = strtr($dob, '/', '-');
                    $dob_lists[] = date('Y-m-d', strtotime($dob1)); }
                $table['dob_list'] = implode("|", $dob_lists);
                $table['age_list'] = $user_data['age_list'];
            }
        StoreData:
        $table['trans_code'] = $values['trans_code'];
        try {
            $health_transaction = $usertdata->update_or_create(array('trans_code' => $table['trans_code']), $table);
            return $health_transaction->id;
        } catch (Exception $e) {
            echo $e->getMessage();
        die; }
        return 0;
    }

    private function getFieldMap($map_for = null){
        $table = Health_Constants::HEALTH_T;
        $fields = ['INSURED' => [
          $table['AGE_LIST'] => 'age_list',
          $table['DOB_LIST'] => 'dob_list',
          $table['FIRSTNAME'] => 'firstname',
          $table['LASTNAME'] => 'lastname',
          $table['HEIGHT_FEET'] => 'height_feet',
          $table['HEIGHT_INCHES'] => 'height_inches',
          $table['WEIGHT'] => 'weight',
          $table['OCCUPATION'] => 'occupation',
          $table['DESIGNATION'] => 'designation',
          $table['BUSINESS'] => 'business',
          $table['MARITAL'] => 'marital_status',
          $table['EDUCATION'] => 'education',
          $table['PAN_NUMBER'] => 'pan_number',
          $table['AADHAAR_NUMBER'] => 'aadhaar_num',
        ],            
        'COMMUNICATION' => [
          $table['HOUSE_NUM'] => 'house_num',
          $table['STREET'] => 'street',
          $table['LOCALITY'] => 'locality',
          $table['STATE'] => 'state',
          $table['CITY'] => 'city',
          $table['PINCODE'] => 'cust_pincode',                
          $table['EMAIL'] => 'email',
          $table['MOBILE'] => 'mobile',
        ],
        'NOMINEE_DETAILS'=>[
          $table['NOMINEE_NAME'] => 'nominee_name',
          $table['NOMINEE_DOB'] => 'nominee_dob',
          $table['NOMINEE_RELATION'] => 'nominee_relation',
          
        ],
        'HEALTHHISTORY'=>[
          $table['PED_LIST'] => 'ped_list',
        ], ];
        return  ($map_for)?
        $fields[$map_for]
        :
        array_merge($fields['INSURED'],
        $fields['COMMUNICATION'],
        $fields['NOMINEE_DETAILS'],
        $fields['HEALTHHISTORY']);
    }


     public function submit_proposal(Request $request){ 
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $input['proposal_date'] = $curr_date;
        $input['proposal_status'] = 'TS14';
        $input['trans_status'] = 'TS14';
        $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);  

        $validation_arr = $this->validate_data($usr_db->get_by_usrdata($request->input('hl_trans_code')));
        if($validation_arr["verror"]){ 
            return json_encode(["status" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ]);
        }

        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($request->input('hl_trans_code'));

        $rsgi_be = new RSGIBe();
        if(!empty($request->input('new_premium'))){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS20';
            $input['trans_status'] = 'TS20';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            $this->update_response($request->input());
        }
        $rsgi_helper = new RSGIPolicyHelper();
        $proposal_req_data = $rsgi_be->set_proposal_data($request->all());
        $proposal_response = $rsgi_helper->get_proposal_response($proposal_req_data);

        if(isset($proposal_response) && !empty($proposal_response->get_error_message())){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS01';
            $input['trans_status'] = 'TS01';
            $input['proposal_ref_number'] = $request->input('rsgi_quote_id');
            $input['proposal_desc'] = $proposal_response->get_error_message();
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            $data['errormsg'] = $proposal_response->get_error_message();
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            return $data;
        }
        $input['rsgi_refr_status'] = $proposal_response->get_referenceId();
        $input['agree_med_chkup'] = ($request->input('agree_med_chkup')  == 1) ? 1 : 0;
        $usr_db->set_by_usrdata($proposal_req_data->get_hl_trans_code(), $input); 
        $rsgiusr_data = $usr_db->get_by_usrdata($proposal_req_data->get_hl_trans_code());

        // If Policy  refer to medical evaluation need customer confirmation
        if($rsgiusr_data['rsgi_refr_status'] == 'NONSTP' && $rsgiusr_data['agree_med_chkup'] != 1){
            $data['policytype'] = 'NONSTP';
            return $data;  
        }
        // if premiuem mismatch is minor than don't ask to user
        if($rsgiusr_data['totalPremium'] != $proposal_response->get_final_totalPremium()){
            $data = [
                'error' => "Premium mismatch",
                'finalPremium' => $proposal_response->get_final_totalPremium(),
                'premiumpassed' => round($rsgiusr_data['totalPremium']) 
            ];
            return $data; 
        }
        if(!empty($proposal_response->get_final_totalPremium())){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS15';
            $input['trans_status'] = 'TS15';
            $input['proposal_ref_number'] = $rsgiusr_data['rsgi_quote_id'];
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);  
            $payment_req = $this->payment_req_data($proposal_response, $proposal_req_data);
            return $payment_req;
        }
        return json_encode(['status' => 'offline','message' => Health_Constants::HEALTH_PROPOSAL_ERROR_MSG]);
    }

    private function validate_data($usr_data){
        $first_name_list = explode('|', $usr_data->firstname);
        $sur_name_list = explode('|', $usr_data->lastname);
        $height_feet_list   =   explode('|',$usr_data->height_feet);
        $height_inches_list   =   explode('|',$usr_data->height_inches);
        $weight_list   =   explode('|',$usr_data->weight);
        foreach ($first_name_list as $key => $value) {
            $customer_list_name[] = $value.' '.$sur_name_list[$key];
        }

        $ped_list = json_decode($usr_data->ped_list);
        

        $customer_dob_list = explode('|', $usr_data->dob_list);
        $pedlifestyle_list = json_decode($usr_data->ped_lifestyle, true);

        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->mobile,
                            'customer_name' => $customer_list_name,
                            'pc_customer_dob' => $customer_dob_list,
                            'customer_aadharno' => $usr_data->aadhaar_num,
                            'customer_email' => $usr_data->email,
                            'customer_add1' => $usr_data->house_num,
                            'customer_add2' => $usr_data->street,
                            'customer_add3' => $usr_data->locality,
                            'customer_pincode' => $usr_data->cust_pincode,
                            'nominee_name' => $usr_data->nominee_name,
                            'number'    =>  [
                                                //$usr_data->nominee_age,
                                                $height_feet_list,
                                                $height_inches_list,
                                            ],
                            'empty' => [
                                            // $pedlifestyle_list,
                                            $weight_list,
                                        ]
                        ];
        if(($ped_list->consulted_doctor != 'No') || ($ped_list->undergone_investigation != 'No') || ($ped_list->taken_medical_treatment != 'No') || ($ped_list->consuming_tablets != 'No') || ($ped_list->medical_conditions != 'No') || ($ped_list->undergone_a_surgery != 'No')){

            for($r=1; $r <= 6; $r++){
                if(isset($ped_list->{'nameOfIllness_'.$r}) && $ped_list->{'nameOfIllness_'.$r} !== null) {
                    $required_array['alpha_with_space_comma'] = $ped_list->{'nameOfIllness_'.$r};
                }
                if(isset($ped_list->{'monthOfDiagnosis_'.$r}) && $ped_list->{'monthOfDiagnosis_'.$r} != null) {
                    $required_array['number'][] = $ped_list->{'monthOfDiagnosis_'.$r};
                }

                if(isset($ped_list->{'yearOfDiagnosis_'.$r}) && $ped_list->{'yearOfDiagnosis_'.$r} != null) {
                    $required_array['number'][] = $ped_list->{'yearOfDiagnosis_'.$r};
                }

                if(isset($ped_list->{'medicationDetail_'.$r}) && $ped_list->{'medicationDetail_'.$r} != null) {
                    $required_array['empty'][] = $ped_list->{'medicationDetail_'.$r};
                }

                if(isset($ped_list->{'treatmentOutCome_'.$r}) && $ped_list->{'treatmentOutCome_'.$r} != null) {
                    $required_array['empty'][] = $ped_list->{'treatmentOutCome_'.$r};
                }

           }
        }
        return $valid_lib->proposalSubmit($required_array);
    }


    private function payment_req_data($proposal_response,$proposal_req){
        $payment_parse_be = new PaymentParseBE;
        $payment_req = [
            'reqType' => 'JSON',
            'process' => 'paymentOption',
            'apikey' => Health_Constants::RSGI_APIKEY,
            'agentId' => Health_Constants::RSGI_AgentID,
            'premium' => $proposal_response->get_final_totalPremium(),
            'quoteId' => $proposal_req->get_rsgi_quote_id(),
            'strFirstName' => $proposal_req->get_firstname()[0],
            'strEmail' => $proposal_req->get_email(),
            'returnUrl' => url('/')."/health-insurance/rsgi/payment/status",
            'paymentURL' => Health_Constants::RSGI_PAYMENT_URL,
            'paymentType' => 'billDesk'
        ];
        $payment_parse_be->setPaymentIdentifier($proposal_req->get_hl_trans_code(),$proposal_req->get_rsgi_quote_id());
        Log::info('Health RSGI Payment request - '.$proposal_req->get_hl_trans_code().'',$payment_req);
        return $payment_req;
    }

    public function policy_return_page(Request $request){
        // $trans_code =  session('hl_trans_code');
        $usertdata = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();

        $data = $request->all();

        $payment_parse_be = new PaymentParseBE;
        $trans_code = $payment_parse_be->getPaymentIdentifier($data['quoteId']);
        
        Log::info('Health RSGI Payment response - '.$trans_code.'', $data);
        $healthtpolicy = new HealthTPolicy();
        if(!empty($data)){
        if(isset($data['policyNO']) && $data['policyNO'] != null) {
          $table['policy_num'] = $data['policyNO'];
          $table['payment_status'] = $data['status'];
          $table['payment_status'] = 'TS17';
          $table['trans_status'] = 'TS17';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
         
          $table['policy_status'] = 'TS19';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);

        } else{
          $msg = explode('|', $data['BDresmsg']) ;
          $table['reference_num'] = $msg['2'];
          $table['payment_status'] = $msg['24'];
          $table['payment_ref_number'] = $msg['2'];
          $table['payment_status'] = 'TS02';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
          
          $table['trans_status'] = 'TS03';
          $table['policy_status'] = 'TS03';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
        }
        $table['policy_date'] = $curr_date;
        $table['payment_date'] = $curr_date;
        $table['payment_desc'] = $data['status'];
        $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
      }
      if(isset($data['policyNO']) && $data['policyNO'] != null){
             $input['trans_code'] = $trans_code.'_DONE';
             $usertdata->set_by_usrdata(array($trans_code), $input);
             $usr_data = $usertdata->getUserTData($trans_code.'_DONE');
         // Policy Counter Service
            $policy_service = new PolicyCounterService();
            $req_arr = array(
                        "module_name"=> "HL",
                        "insurer_code"=> "RSGI",
                        "agent_code"=> (empty($usr_data['agent_code'])) ? '' : $usr_data['agent_code'],
                        "policy_date"=> $curr_date,
                        "policy_type"=> ($usr_data['product_type'] == 'B') ? 'C' : 'STP',
                        "policy_nature"=> "New",
                        "policy_number"=> $data['policyNO'],
                        "od_premium"=> $usr_data['basePremium'],
                        "tp_premium"=> 0,
                        "total_premium"=> $usr_data['basePremium'],
                        "tax"=> round($usr_data['serviceTax']),
                        "final_premium"=> $usr_data['totalPremium']
            );
            $response_status = $policy_service->service_handler($req_arr);
            Log::info('Policy Counter Status '.$usr_data['trans_code'].':', array($response_status));
            // Ends Policy Counter Service
        $policy_transaction = $healthtpolicy->set_policy_details($usr_data);
      }
        $status = (isset($data['policyNO']) && $data['policyNO'] != "null") ? 1 : 0;
        $data_main=['status' => $status,'logo' => 'rsgi','udata' => $data];
        try {
            if(!empty(session('proposal_form_data'))){ 
                $proposal_form_data = session('proposal_form_data');
                $company_name = 'RoyalSundaram';
                $name = $proposal_form_data['firstname']['0']. ' ' .$proposal_form_data['lastname']['0'];
                $client_email = $proposal_form_data['email'];
                $proposal_request_url = '';
                $proposal_form_result = '';
            if ($status) { 
              $subject = 'Health insurance purchased for '.$company_name;
              $subject_success = "Congrats you have successfully puchased Health insurance from ".$company_name;
              $view_email_internal = view('health.templates.payment_success.internal_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $view_email_external = view('health.templates.payment_success.external_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $mail_data = array('proposal_form_data' => $proposal_form_data,'subject_success'=>$subject_success,'subject'=>$subject, 'company_name' => $company_name,'name'=>$name,  'content_external' => $view_email_external,'client_email'=>$client_email, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
              $status = $this->email->proposalSuccMail($mail_data);
            } else { 
              $subject = 'Payment failed for Health insurance - '.$company_name;
              $subject_failure = "Sorry, there has been some issue while purchasing health insurance from ".$company_name;
              $view_email_internal = view('health.templates.payment_failed.internal_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $view_email_external = view('health.templates.payment_failed.external_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $mail_data = array('proposal_form_data' => $proposal_form_data,'subject_failure'=>$subject_failure,'subject'=>$subject, 'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal);
              $status = $this->email->proposalFailMail($mail_data);
            } } else { }
            } catch (\Exception $e) {
                Log::info($e->getMessage());
            } finally {
        return view('health.return_page.rsgi', $data_main); }
    }


    // route method for Offline policy having Pre existing illness
    public function offline_policy(Request $request) {
        $this->email_sender = new EmailSender;
        $data = $request->all();
        $data_main = ['status' => 0, 'logo' => 'rsgi', 'udata' => $data];
        return view('health.return_page.offline_policy_page', $data_main);
    }

    private function update_response($resp_data){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $updated_data = [
            'proposal_date' => $curr_date, 
            'proposal_status' => 'TS21',
            'trans_status' => 'TS21',
            'totalPremium' => $resp_data['new_total_premium'],
            'basePremium' => $resp_data['new_premium'],
            'serviceTax' => $resp_data['new_service_tax'],
            'cgst' => $resp_data['new_service_tax']/2,
            'sgst' => $resp_data['new_service_tax']/2
        ];
        $usr_db->set_by_usrdata($resp_data['hl_trans_code'], $updated_data);        
    }
}
