<?php
namespace App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Constants\Health_Constants;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\Reliance\ReliancePolicyHelper;
use App\Models\Health\data\PolicyPageData;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthRelationship;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\Health\HealthState;
use App\Models\Health\HealthCity;
use App\Models\Health\HealthPincode;
use App\Models\Health\HealthPED;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\RelianceBe;
use App\Http\Controllers\EmailSender;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;
use App\Models\InstaInsurers;

class Reliance extends Controller {
  
    public function __construct() {
    }

    public function load_policy_page($hl_trans_code) {
        $policy_page_data = new PolicyPageData();
        $insr_column = "reliance_code";
        session(['hl_trans_code' => $hl_trans_code]);
        
        $usr_db = new HealthUserData();
        $usr_data = $usr_db->get_by_usrdata($hl_trans_code);
        // Occupation list
        $occ_db = new HealthOccupation();
        $policy_page_data->set_occupation_list($occ_db->occupation_list($insr_column)); 
        // Nominee list
        $nomrel_db = new NomiRelationship();
        $policy_page_data->set_nominee_rel_list($nomrel_db->nominee_rel_list($insr_column) );
        // Relation members list
        $rel_db = new HealthRelationship();
        $policy_page_data->set_relation_list($rel_db->get_relationship_ids($insr_column));
        // State List
        $state_db = new HealthState();
        $policy_page_data->set_state($state_db->get_state($insr_column));
        // PED list
        $ped_db = new HealthPED();
        $policy_page_data->set_ped_list($ped_db->get_ped_list($insr_column, 'ped'));
        $policy_be = new HealthPolicyBe();
        $quote_resp =  $policy_be->parse_proposal_data($usr_data);
        $dob_list = $policy_be->set_dob_list($quote_resp);
        $reliance_be = new RelianceBe();
        $details = $reliance_be->set_proposal_details($usr_data);
        
        if(!empty($usr_data['state'])){
            $citylist = new HealthCity();
            $details['city_list'] = $citylist->get_city( $usr_data['state'], 'reliance');
        }
        $insta_insurer = new InstaInsurers();
        $insurer_details = $insta_insurer->insurer_details($usr_data['insurerId']);
        return view('health/policy/reliance_proposal_home', [ 
                'hl_trans_code' => $hl_trans_code,
                'base_data' => $policy_page_data,
                'quote' => $quote_resp,
                'data' => $details,
                'doblist' =>$dob_list,
                'insurer_details' => $insurer_details
        ]);
    }

    public static function store_proposal_data(Request $request){
        $user_db = new HealthUserData();
        $data = $request->all();
        $user_data = $user_db->get_by_usrdata($data['trans_code']);
        $hl_trans_code = $data['trans_code'];
        // Identifies the data from which TAB, Eg: Insured, Communication
        $section     = $data['id'];
        // Unsetting the extra values
        unset($data['id']);
        unset($data['_token']);
        // Insured section
        if($section == 'insured'){
            $dob = array();
            // Re-formating d-m-Y to Y-m-d
            if (isset($data['dob_list'])) { 
                foreach ($data['dob_list'] as $dob) {
                    $doblist[] = date('Y-m-d', strtotime($dob));
                }
            }
        $gender_list = explode('|', $user_data['gender']);
        $replacements = array(0 => $data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        foreach($gender as $gen){
            $title[] = ($gen == 'F') ? 'Ms': 'Mr';
        }
        $data['dob_list']  = implode('|', $doblist);
        $data['age_list']  = $user_data['age_list'];
        $data['gender'] = implode("|",$gender);
        $data['title'] = implode("|",$title);
        $data['firstname'] = implode('|', $data['firstname']);
        $data['lastname']  = implode('|', $data['lastname']);
        $data['marital_status']  = implode('|',$data['marital_status']);
        $data['occupation'] = (!empty($data['occupation'])) ? implode('|', $data['occupation']) : '';
        }
        // Nominee Details
        
        // Health History Section 
        if($section == 'healthhistory'){
            $reliance_be = new RelianceBe();
            unset($data['trans_code']);
            $pedlist = json_encode($data['ped']);
            unset($data);
            $data['ped_list'] = $pedlist;
        }
        try {
            $health_transaction = $user_db->set_by_usrdata(array('trans_code' =>$hl_trans_code),$data);
        } catch (Exception $e) {
            Log::info('HEALTH_RELIANCE_SAVE_PROPOSAL'. print_r($e->getMessage(), true));
        return 0;
        } 
    }

    public function get_state_city_list(Request $request){
        $pincode_db = new HealthPincode();
        $pincode_list = $pincode_db->get_data_by_pincode($request->input('city_code'));
        echo $pincode_list; 
    }


    public function submit_proposal(Request $request){ 
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $input['proposal_date'] = $curr_date;
        $input['proposal_status'] = 'TS14';
        $input['trans_status'] = 'TS14';
        $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);  
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($request->input('hl_trans_code')); 

        $reliance_helper = new ReliancePolicyHelper();
        $reliance_be = new RelianceBe();
        if(!empty($request->input('new_premium'))){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS20';
            $input['trans_status'] = 'TS20';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            $this->update_response($request->input());
        }
        $proposal_req_data = $reliance_be->set_proposal_data($request->all());
        //Critical illness confirmed online policy not allowed
        $check_policy_status = $reliance_be->check_reliance_policy_status($proposal_req_data);
        if(!empty($check_policy_status->get_ped_status()) ){
            $input['policy_date'] = $curr_date;
            $input['policy_status'] = 'TS22';
            $input['trans_status'] = 'TS22';
            $input['policy_desc'] = 'Pre-existing disease is disclosed. Online policy not allowed';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 
            $message = $check_policy_status->get_ped_status();
            return json_encode(['status' => 'offline', 'message' => $message]);
        }
        // PPC case above 45 years
        $policy_ppc_case = $reliance_be->check_ppc_case($proposal_req_data);
        if(isset($policy_ppc_case) && ($policy_ppc_case == true || $policy_ppc_case == 1)  && $proposal_req_data->get_agree_medical_checkup() == 0 ){
            return json_encode(['status' => 'ppc_case']);
        }
        $trans_data = $usr_db->get_by_usrdata($proposal_req_data->get_hl_trans_code());
        $proposal_response = $reliance_helper->get_proposal_response($proposal_req_data);
        if(!empty($proposal_response)){
            if(!empty($proposal_response->get_error_message())){
                $data = $proposal_response->get_error_message();
                return json_encode(['Error' =>'Error','errormsg' => $data]);
            }
            // if premiuem mismatch is minor than don't ask to user
            if($trans_data['totalPremium'] != $proposal_response->get_final_totalPremium()){
                $data = [
                'error' => "Premium mismatch",
                'finalPremium' => $proposal_response->get_final_totalPremium(),
                'premiumpassed' => $proposal_req_data->get_final_totalPremium()
                ];
                return $data; 
            }
            if(!empty($proposal_response->get_final_totalPremium())){
                $input['proposal_date'] = $curr_date;
                $input['proposal_status'] = 'TS15';
                 $input['trans_status'] = 'TS15';
                $input['proposal_ref_number'] = $proposal_response->get_referenceId();
                $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);  
                $payment_req = $this->payment_req_data($proposal_response, $proposal_req_data);
                return $payment_req;
            }else{
                 $input['proposal_date'] = $curr_date;
                 $input['proposal_status'] = 'TS01';
                 $input['trans_status'] = 'TS01';
                 $input['proposal_ref_number'] = '';
                 $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
                 // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
                return false;
            }
        }
        return json_encode(['status' =>'offline','message'=> Health_Constants::HEALTH_PROPOSAL_ERROR_MSG]);
    }

    private function payment_req_data($proposal_response,$proposal_req){
        $payment_req = ['ProposalNo'=>$proposal_response->get_referenceId(),
                'UserID'=>Health_Constants::RELIANCE_USER_ID,
                'PaymentType'=>1,
                'ProposalAmount'=>$proposal_response->get_final_totalPremium(),
                'Responseurl'=> url('/')."/health-insurance/reliance/payment/status"
        ];
         Log::info('Health Reliance Payment request - '.$proposal_req->get_hl_trans_code().'',$payment_req);

        return ['fields'=> $payment_req,
                'payment_url'=>Health_Constants::RELIANCE_PAYMENT_URL];
    }


    public function policy_return_page(Request $request){
        $trans_code =  session('hl_trans_code');
        $usertdata = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();

        $payment_response = explode('|', $request->input('Output'));
        Log::info('Health Reliance Payment response - '.$trans_code.'', $payment_response);
       
        $healthtpolicy = new HealthTPolicy();
        if($payment_response[0] == 1 && $payment_response[1] != null) {
          $table['policy_num'] = $payment_response[1];
          $table['payment_status'] = $payment_response[6];
          $table['payment_status'] = 'TS17';
          $table['trans_status'] = 'TS17';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);

          $table['policy_status'] = 'TS19';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
        } else{
          $msg = !empty($payment_response[7]) ? $payment_response[7] : 'Error Occurred';
          $table['reference_num'] =  (!empty($payment_response[2])) ? $payment_response[2] : $payment_response[2] = 'Error Occured' ;
          $table['payment_status'] = !empty($payment_response[6]) ? $payment_response[6] :  $payment_response[6]= 'Failure' ;
          $table['payment_status'] = 'TS02';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
          $table['trans_status'] = 'TS03';
          $table['policy_status'] = 'TS03';
          $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
          // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($trans_code);
        }
        $table['policy_date'] = $curr_date;
        $table['payment_date'] = $curr_date;
        $table['payment_ref_number'] = !empty($payment_response[5]) ? $payment_response[5]: 'Error Occured' ;
        $table['payment_desc'] =  !empty($payment_response[6]) ? $payment_response[6] :  $payment_response[6]='Failure' ;
        $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $table);
        
        if($payment_response[0] == 1 && $payment_response[1] != null) {
             $input['trans_code'] = $trans_code.'_DONE';
             $usertdata->set_by_usrdata(array($trans_code), $input);
             $usr_data = $usertdata->getUserTData($trans_code.'_DONE');
            // Policy Counter Service
            $policy_service = new PolicyCounterService();
            $req_arr = array(
                        "module_name"=> "HL",
                        "insurer_code"=> "RELIANCE",
                        "agent_code"=> (empty($usr_data['agent_code'])) ? '' : $usr_data['agent_code'],
                        "policy_date"=> $curr_date,
                        "policy_type"=> ($usr_data['product_type'] == 'B') ? 'C' : 'STP',
                        "policy_nature"=> "New",
                        "policy_number"=> $payment_response[1],
                        "od_premium"=> $usr_data['basePremium'],
                        "tp_premium"=> 0,
                        "total_premium"=> $usr_data['basePremium'],
                        "tax"=> round($usr_data['serviceTax']),
                        "final_premium"=> $usr_data['totalPremium']
            );
            $response_status = $policy_service->service_handler($req_arr);
            Log::info('Policy Counter Status '.$usr_data['trans_code'].':', array($response_status));
            // Ends Policy Counter Service
            $policy_transaction = $healthtpolicy->set_policy_details($usr_data);
            $payment_response['download_link'] = Health_Constants::RELIANCE_POLICY_SCHEDULE_URL."?PolicyNo=".$payment_response[1]."&ProductCode=".Health_Constants::RELIANCE_PRODUCT_CODE."";
        }
        $status = ($payment_response[0] == 1 && $payment_response[1] != null) ? 1 : 0;
        $data_main=['status' => $status, 'logo' => 'reliance', 'udata' => $payment_response];
        
        try {
            if(!empty(session('proposal_form_data'))){ 
                $proposal_form_data = session('proposal_form_data');
                $company_name = 'Reliance';
                $name = $proposal_form_data['firstname']['0']. ' ' .$proposal_form_data['lastname']['0'];
                $client_email = $proposal_form_data['email'];
                $proposal_request_url = '';
                $proposal_form_result = '';
            if ($status) { 
              $subject = 'Health insurance purchased for '.$company_name;
              $subject_success = "Congrats you have successfully puchased Health insurance from ".$company_name;
              $view_email_internal = view('health.templates.payment_success.internal_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $view_email_external = view('health.templates.payment_success.external_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $mail_data = array('proposal_form_data' => $proposal_form_data,'subject_success'=>$subject_success,'subject'=>$subject, 'company_name' => $company_name,'name'=>$name,  'content_external' => $view_email_external,'client_email'=>$client_email, 'content_internal' => $view_email_internal,'company_name'=>$company_name);
              $status = $this->email->proposalSuccMail($mail_data);
            } else { 
              $subject = 'Payment failed for Health insurance - '.$company_name;
              $subject_failure = "Sorry, there has been some issue while purchasing health insurance from ".$company_name;
              $view_email_internal = view('health.templates.payment_failed.internal_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $view_email_external = view('health.templates.payment_failed.external_email', ['company_name'=>$company_name,'name'=>$name, 'client_email'=>$client_email,'data_value' => $data_main, 'proposal_form_data' => $proposal_form_data, 'proposal_request_url' => $proposal_request_url, 'proposal_form_result' => $proposal_form_result]);
              $mail_data = array('proposal_form_data' => $proposal_form_data,'subject_failure'=>$subject_failure,'subject'=>$subject, 'company_name' => $company_name,'name'=>$name, 'client_email'=>$client_email, 'content_external' => $view_email_external, 'content_internal' => $view_email_internal);
              $status = $this->email->proposalFailMail($mail_data);
            } } else { }
            } catch (\Exception $e) {
                Log::info($e->getMessage());
            } finally {
        return view('health.return_page.reliance', $data_main); }
    }


    public function offline_policy(Request $request){
        $data_main['msg'] = ($request->input('msg')) ? $request->input('msg') : null; 
        return view('health.return_page.offline_policy_page', compact('data_main'));
    }


    private function update_response($resp_data){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $updated_data = [
            'proposal_date' => $curr_date, 
            'proposal_status' => 'TS21',
            'trans_status' => 'TS21',
            'totalPremium' => $resp_data['new_total_premium'],
            'basePremium' => $resp_data['new_premium'],
            'serviceTax' => $resp_data['new_service_tax'],
            'cgst' => $resp_data['new_service_tax']/2,
            'sgst' => $resp_data['new_service_tax']/2
        ];
        $usr_db->set_by_usrdata($resp_data['hl_trans_code'], $updated_data);        
    }
}
