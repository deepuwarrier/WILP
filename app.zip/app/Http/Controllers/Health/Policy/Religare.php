<?php
namespace App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Be\Health\HealthPolicyBe;
use App\Constants\Health_Constants;
use App\Http\Controllers\EmailSender;
use Illuminate\Support\Facades\Session;
use App\Helpers\Health\Religare\ReligareProposal;
use App\Be\Health\ReligareBe;
// EXTRA IMPORTS STARTS
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthQuoteResponse;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Helpers\Health\Policy\ReligareHelper;
use App\Helpers\Health\HealthHelper;
// EXTRA IMPORTS ENDS
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Log;
use App\Helpers\Email\EmailEngine;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;

class Religare extends Controller{

  public function __construct(){
    $this->email = new EmailSender; 
  }

  public function load_policy_page($trans_code){
    // session(['hel_suid' => $trans_code]);
    $payment_parse_be = new PaymentParseBE;
    $payment_parse_be->setPaymentIdentifier($trans_code);
    $bl = new ReligareBe;
    $data = $bl->get_proposal_inputs($trans_code);
    if(isset($data['religare_prd'])){
      session(['religare_prd' => true]);
      return view('health.policy.religare_prd', compact('data'));
    }
    session(['religare_prd' => false]);
    return view('health.policy.religare_proposal_home', compact('data'));
  }

  public function submit_proposal(Request $request){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $input['proposal_date'] = $curr_date;
        $input['proposal_status'] = 'TS14';
        $input['trans_status'] = 'TS14';
        $usr_db->set_by_usrdata($request['trans_code'], $input); 
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($request['trans_code']);
        
        $validation_arr = $this->validate_data($usr_db->get_by_usrdata($request['trans_code']));
        if($validation_arr["verror"]){ 
            return json_encode(["status" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ]);
        }

        $rel_proposal = new ReligareProposal;
        $response     =  $rel_proposal->get_policy($request['trans_code']);
        return json_encode($response);   
  }

   private function validate_data($usr_data){
        $first_name_list = explode('|', $usr_data->firstname);
        $sur_name_list = explode('|', $usr_data->lastname);
        $height_feet_list   =   explode('|',$usr_data->height_feet);
        $height_inches_list   =   explode('|',$usr_data->height_inches);
        $weight_list   =   explode('|',$usr_data->weight);
        foreach ($first_name_list as $key => $value) {
            $customer_list_name[] = $value.' '.$sur_name_list[$key];
        }

        $ped_list = json_decode($usr_data->ped_list);
        if(!empty($ped_list)) {
          foreach ($ped_list->ped_list as $key => $value) {
            $required_array['number'][$key] = [$ped_list->ped_since_year->$key,$ped_list->ped_since_month->$key];
          }
        }
        $customer_dob_list = explode('|', $usr_data->dob_list);
        $pedlifestyle_list = json_decode($usr_data->ped_lifestyle, true);

        $valid_lib = new ValidatorLib;
        $required_array = [
                            'mobile' => $usr_data->mobile,
                            'customer_name' => $customer_list_name,
                            'pc_customer_dob' => $customer_dob_list,
                            'customer_aadharno' => $usr_data->aadhaar_num,
                            'customer_email' => $usr_data->email,
                            'customer_add1' => $usr_data->house_num,
                            'customer_add2' => $usr_data->street,
                            'customer_add3' => $usr_data->locality,
                            'customer_pincode' => $usr_data->cust_pincode,
                            'nominee_name' => $usr_data->nominee_name,
                            'number'    =>  [
                                                $usr_data->nominee_age,
                                                // $height_feet_list,
                                                // $height_inches_list,
                                            ],
                        ];
        return $valid_lib->proposalSubmit($required_array);
    }


  public function setProposalData(Request $request){
    $bl = new ReligareBe;
    if(session('religare_prd')){
      return $bl->set_proposal_data_prd($request->all());
    }
    return $bl->set_proposal_data($request->all());    
  }

  public function payment_response(Request $request,$trans_code){
    $pg_response = $request->all();
    Log::info('HEALTH_RELIGARE_PG_RESPONSE '. print_r($pg_response, true));
    $bl   = new ReligareBe;
    $data = json_decode($bl->parse_pg_response($pg_response,$trans_code), true);
    if(isset($data['redirect'])){
      return Redirect::to('health-insurance');
    }
    return view('health.return_page.religare', compact('data'));
  }

  public function get_policy_pdf(Request $request){
    $policy_number = $request['p'];
    $helper = new ReligareProposal;
    $policy_pdf =  $helper->get_policy_pdf($policy_number);
    if(!$policy_pdf){
      echo 'Statement Not Generated For Given Policy number';
      dd();
    }

    return Response::make(base64_decode($policy_pdf), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'inline; filename="health_policy_'.$policy_number.'.pdf"']);
  }

  public function offlinePolicy() {
    $this->email_sender = new EmailSender;
    $data_main = ['status' => 0, 'logo' => 'religare'];
    return view('health.return_page.offline_policy_page', $data_main);
  }

}
