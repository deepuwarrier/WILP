<?php
namespace App\Http\Controllers\Health\Policy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Constants\Health_Constants;
use App\Http\Controllers\Controller;
use App\Helpers\Health\HealthHelper;
use App\Helpers\Health\Star\StarPolicyHelper;
use App\Libraries\HealthLib;
use App\Libraries\InstaLib;
use App\Models\Health\data\PolicyPageData;
use App\Models\Health\HealthUserData;
use App\Models\Health\HealthTPolicy;
use App\Models\Health\HealthRelationship;
use App\Models\Health\NomiRelationship;
use App\Models\Health\HealthOccupation;
use App\Models\Health\HealthPED;
use App\Be\Health\HealthPolicyBe;
use App\Be\Health\StarBe;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;
use App\Models\InstaInsurers;


class Star extends Controller {
  
    public function __construct() {
    }

    public function load_policy_page($hl_trans_code)
    {
        $policy_page_data = new PolicyPageData();
        $insr_column = "star_code";
        session(['hl_trans_code' => $hl_trans_code]);
        $usr_db = new HealthUserData();
        $usr_data = $usr_db->get_by_usrdata($hl_trans_code);
        // Occupation list
        $occ_db = new HealthOccupation();
        $occ_column = ($usr_data['productId'] == 'REDCARPET') ? $insr_column.'_red': $insr_column;
        $policy_page_data->set_occupation_list($occ_db->occupation_list($occ_column)); 
        // Nominee list
        $nomrel_db = new NomiRelationship();
        $policy_page_data->set_nominee_rel_list($nomrel_db->nominee_rel_list($insr_column) );
        // Relation members list
        $rel_db = new HealthRelationship();
        $rel_column = $this->get_company_column($usr_data['productId']);
        $policy_page_data->set_relation_list($rel_db->get_relationship_ids($rel_column));
        // PED list
        $ped_db = new HealthPED();
        $policy_page_data->set_ped_list($ped_db->get_ped_list($insr_column, 'ped'));
        $policy_be = new HealthPolicyBe();
        $quote_resp =  $policy_be->parse_proposal_data($usr_data);
        $star_be = new StarBe();
        $dob_list = $star_be->set_dob_list($quote_resp);
        $details = $star_be->set_proposal_details($usr_data);
        $insta_insurer = new InstaInsurers();
        $insurer_details = $insta_insurer->insurer_details($usr_data['insurerId']);
        return view('health/policy/star_proposal_home', [ 
                'hl_trans_code' => $hl_trans_code,
                'base_data' => $policy_page_data,
                'quote' => $quote_resp,
                'data' => $details,
                'doblist' =>$dob_list,
                'insurer_details' => $insurer_details
        ]);
    }

    public function state_city(Request $request){
        $star_be  = new StarBe();
        $response = $star_be->getStarStateCity($request->all());
        echo $response;
    }

    public function area_city(Request $request){
        $star_be  = new StarBe();
        $response = $star_be->getStarAreaCity($request->all());
        echo $response;
    }

    public static function store_proposal_data(Request $request){
        $h_lib = new HealthLib();
        $user_db = new HealthUserData();
        $data = $request->all();
        $user_data = $user_db->get_by_usrdata($data['trans_code']);
        $hl_trans_code = $data['trans_code'];
        // Identifies the data from which TAB, Eg: Insured, Communication
        $section     = $data['id'];
        // Unsetting the extra values
        unset($data['id']);
        unset($data['_token']);
        // Insured section
        if($section == 'insured'){
            $dob = array();
            // Re-formating d-m-Y to Y-m-d
            if (isset($data['dob_list'])) { 
                foreach ($data['dob_list'] as $dob) {
                    $doblist[] = date('Y-m-d', strtotime($dob));
                }
            }
        $gender_list = explode('|', $user_data['gender']);
        $replacements = array(0 => $data['gender']['1']);
        $gender = array_replace($gender_list, $replacements);
        $data['dob_list']  = implode('|', $doblist);
        $data['age_list']  = $user_data['age_list'];
        $data['gender'] = implode("|",$gender);
        $data['firstname'] = implode('|', $data['firstname']);
        $data['lastname']  = implode('|', $data['lastname']);
        $data['height_feet']  = implode('|', $data['height_feet']);
        $data['height_inches']  = implode('|', $data['height_inches']);
        $data['weight']  = implode('|', $data['weight']);
        $data['occupation']  = (!empty($data['occupation'])) ? implode('|', $data['occupation']) : '';
        }
        // Nominee Details
        if($section == 'nominee_details'){
            $data['star_add_on'] = (!empty($data['star_add_on'])) ? 1 : 0;
        }
        // Health History Section 
        if($section == 'healthhistory'){
            $star_be = new StarBe();
            unset($data['trans_code']);
            $pedlist = json_encode($data);
            unset($data);
            $data['ped_list'] = $pedlist;
        }
        try {
            $health_transaction = $user_db->set_by_usrdata(array('trans_code' =>$hl_trans_code),$data);
        } catch (Exception $e) {
            Log::info('HEALTH_STAR_SAVE_PROPOSAL'. print_r($e->getMessage(), true));
        return 0;
        } 
    }

    public function submit_proposal(Request $request){ 
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $input['proposal_date'] = $curr_date;
        $input['proposal_status'] = 'TS14';
        $input['trans_status'] = 'TS14';
        $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 
        // Mail config
        $email_engine =  new EmailEngine; 
        $email_engine->send_email($request->input('hl_trans_code'));
        $star_be = new StarBe();
        if(!empty($request->input('new_premium'))){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS20';
            $input['trans_status'] = 'TS20';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            $this->update_response($request->input());
        }
        $proposal_req_data = $star_be->set_proposal_data($request->all());
        $input['star_persaonal_accedent'] = (!empty($proposal_req_data->get_personal_accident()) && $proposal_req_data->get_personal_accident() == 'true') ? 'true' : 'false'; 
        $input['star_add_on'] = ($proposal_req_data->get_star_hosp_cash() == 1) ? 1: 0;
        $input['agree_med_chkup'] = ($request->input('agree_med_chkup')  == 1) ? 1 : 0;
        $usr_db->set_by_usrdata($proposal_req_data->get_hl_trans_code(), $input); 
        
        //Critical illness confirmed & BMI calculation online policy not allowed
        $star_helper = new StarPolicyHelper();
        $check_policy_status = $star_be->check_star_policy_status($proposal_req_data);
        
        if(!empty($check_policy_status->get_bmi_status()) || !empty($check_policy_status->get_ped_status()) ){
            $bmi = !empty($check_policy_status->get_bmi_status()) ? $check_policy_status->get_bmi_status() : '';
            $critical_illness = !empty($check_policy_status->get_ped_status()) ? $check_policy_status->get_ped_status(): '';
            $message = $bmi.' '.$critical_illness;

            $input['policy_date'] = $curr_date;
            $input['policy_status'] = 'TS22';
            $input['trans_status'] = 'TS22';
            $input['policy_desc'] = $message;
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 

            return json_encode(['status' => 'offline', 'message' => $message]);
        }
        // PPC case above 50 years
        $policy_ppc_case = $star_be->check_ppc_case($proposal_req_data);
        if(isset($policy_ppc_case) && ($policy_ppc_case == true || $policy_ppc_case == 1)  && $proposal_req_data->get_agree_medical_checkup() == 0 ){
            return json_encode(['status' => 'ppc_case']);
        }
        $proposal_response = $star_helper->get_proposal_response($proposal_req_data);
        if(isset($proposal_response) && !empty($proposal_response->get_referenceId())){
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS15';
            $input['trans_status'] = 'TS15';
            $input['proposal_ref_number'] = $proposal_response->get_referenceId();
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input); 
            $payment_req = $this->payment_req_data($proposal_response, $proposal_req_data);
            return $payment_req;
        }
        else{
            $input['proposal_date'] = $curr_date;
            $input['proposal_status'] = 'TS01';
            $input['trans_status'] = 'TS01';
            $input['proposal_ref_number'] = '';
            $usr_db->set_by_usrdata($request->input('hl_trans_code'), $input);
            // Mail config
            $email_engine =  new EmailEngine; 
            $email_engine->send_email($request->input('hl_trans_code'));
            return false;
        }
        return json_encode(['status' => 'offline','message' => Health_Constants::HEALTH_PROPOSAL_ERROR_MSG]);
    }

    public function policy_return_page(Request $request){
        $trans_code =  session('hl_trans_code');
        $usertdata = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
    	$data = $request->all();
        Log::info('Health Star Payment Response - '.$trans_code.'', $data);
        try{
            if(isset($data['purchaseToken'])){
                // Get policy purchase status
                $star_helper = new StarPolicyHelper();
                $purchase_status = $star_helper->policy_purchase_status_api($data['purchaseToken']);
                if($purchase_status->status == "SUCCESS"){
                    $purchase_status->download_link = $star_helper->policy_schedule_api($purchase_status->referenceId);
                }
            }
            $data = $purchase_status;
            $status = (isset($purchase_status->status) && $purchase_status->status == 'SUCCESS') ? 1: 0;
            $data_main = ['status' => $status, 'logo' => 'star', 'udata' => $data];
            if($status == 1){
                $healthtpolicy = new HealthTPolicy();
            	$input['reference_num'] = $purchase_status->referenceId;
            	$input['payment_status'] = $purchase_status->status;
            	$input['payment_response_log'] = json_encode($purchase_status);
                $input['payment_status'] = $purchase_status->status;
                $input['payment_status'] = 'TS17';
                $input['trans_status'] = 'TS17';
                $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $input);
                // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
                $input['policy_status'] = 'TS19';
                $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $input);
                // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
                $input['payment_date'] = $curr_date;
                $input['policy_date'] = $curr_date;
                $input['payment_ref_number'] = '';
                $input['payment_desc'] = $purchase_status->status;
                $usertdata->set_by_usrdata(array('trans_code' => $trans_code), $input);
                
                $input['trans_code'] = $trans_code.'_DONE';
                $usertdata->set_by_usrdata(array($trans_code), $input);
                $usr_data = $usertdata->get_by_usrdata($trans_code.'_DONE');
                $healthtpolicy->set_policy_details($usr_data['attributes']);
                // Policy Counter Service
                $policy_service = new PolicyCounterService();
                $req_arr = array(
                        "module_name"=> "HL",
                        "insurer_code"=> "STAR",
                        "agent_code"=> (empty($usr_data['agent_code'])) ? '' : $usr_data['agent_code'],
                        "policy_date"=> $curr_date,
                        "policy_type"=> ($usr_data['product_type'] == 'B') ? 'C' : 'STP',
                        "policy_nature"=> "New",
                        "policy_number"=> $purchase_status->referenceId,
                        "od_premium"=> $usr_data['basePremium'],
                        "tp_premium"=> 0,
                        "total_premium"=> $usr_data['basePremium'],
                        "tax"=> round($usr_data['serviceTax']),
                        "final_premium"=> $usr_data['totalPremium']
                );
                $response_status = $policy_service->service_handler($req_arr);
                Log::info('Policy Counter Status '.$usr_data['trans_code'].':',array($response_status));
                // Ends Policy Counter Service
            }else{
                $input['payment_status'] = 'TS02';
                $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $input);
                // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
                $input['trans_status'] = 'TS03';
                $input['policy_status'] = 'TS03';
                $health_transaction = $usertdata->update_or_create(array('trans_code' => $trans_code), $input);
                // Mail config
                $email_engine =  new EmailEngine; 
                $email_engine->send_email($request->input('hl_trans_code'));
                $input['policy_date'] = $curr_date;
                $input['payment_date'] = $curr_date;
                $input['payment_ref_number'] = '';
                $input['payment_desc'] = '';
                $usertdata->set_by_usrdata(array('trans_code' => $trans_code), $input);
            }
         }catch(\Exception $e){
            Log::error($e);
        }finally {
            return view('health.return_page.star_health', $data_main);
        }
    }


    public function offline_policy(Request $request){
        $data_main['msg'] = ($request->input('msg')) ? $request->input('msg') : null; 
        return view('health.return_page.offline_policy_page', compact('data_main'));
    }

    private function payment_req_data($proposal_response,$proposal_req){
        $usr_db = new HealthUserData();
        $quote_data = $usr_db->get_by_usrdata($proposal_response->get_hl_trans_code());
        if($quote_data['totalPremium'] == $proposal_response->get_final_totalPremium()){
            $redirect_token = $this->get_redirect_token($proposal_response->get_referenceId());
            $pg_req = [
                'premium' => $proposal_response->get_final_premium(),
                'serviceTax' => $proposal_response->get_final_serviceTax(),
                'totalPremium' => $proposal_response->get_final_totalPremium(),
                'product_id' => $proposal_response->get_product_id(),
                'insurer_id' => $proposal_response->get_insurer_name(),
                'pg_url' => Health_Constants::STAR_PG_URL.'/'.$redirect_token->redirectToken
            ];
            Log::info('Health Star Payment request - '.$proposal_response->get_hl_trans_code().'', $pg_req);
            return $pg_req;
        }else{  
            $pg_req = [
                'error' => "Premium mismatch",
                'PremiumPayable' => $proposal_response->get_final_totalPremium(),
                'PremiumPassed' => $quote_data['totalPremium'],
                'product_id' => $proposal_response->get_product_id(),
                'insurer_id' => $proposal_response->get_insurer_name(),
                'serviceTax' => $proposal_response->get_final_serviceTax(),
                'basePremium' => $proposal_response->get_final_premium()
            ];
            return $pg_req;
        }
    }

    private function get_redirect_token($proposal_ref_id){
        try{
            $star_helper = new StarPolicyHelper();
            $redirect_token = $star_helper->policy_token_api($proposal_ref_id);
            return $redirect_token;
        }catch(\Exception $e){
            Log::error($e);
        }
    }
	
    private function update_response($resp_data){
        $usr_db = new HealthUserData();
        $insta_lib = new InstaLib();
        $curr_date = $insta_lib->today_date_dMY();
        $updated_data = [
            'proposal_date' => $curr_date, 
            'proposal_status' => 'TS21',
            'trans_status' => 'TS21',
            'totalPremium' => $resp_data['new_total_premium'],
            'basePremium' => $resp_data['new_premium'],
            'serviceTax' => $resp_data['new_service_tax'],
            'cgst' => $resp_data['new_service_tax']/2,
            'sgst' => $resp_data['new_service_tax']/2
        ];
        $usr_db->set_by_usrdata($resp_data['hl_trans_code'], $updated_data);        
    }

    private function get_company_column($productId){
        if($productId == "DIABETESIND" || $productId == "DIABETESFMLY"){ 
            return 'star_code_diabetic'; }
        elseif($productId == "REDCARPET"){  
            return 'star_code_red'; }
        else{ return 'star_code'; }
    }
}
