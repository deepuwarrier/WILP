<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FaqModel;
use App\Models\TeamModel;
use App\Models\PortalPages;
use App\Constants\Common_Constants;
use App\Models\Customers\CustomerDetails;
use App\Models\Admin\InstaProduct;
use App\Models\Admin\InstaCategory;
use App\Helpers\Car\CarHelper;

class InstaHome extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 */
	public function __construct()
	{
	}

	/**
	 * Show the application dashboard.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
// 		return view('instahome');
		$portalPgs = new PortalPages();
		return view('instahome', ['MTxt' => $portalPgs->getMeta(Common_Constants::HOME)]);
	}
	
	public function getFaqs(){
		$faqmobj = new FaqModel();
		return view('faq', ['faqlist' => $faqmobj->getFaqList()]);
	}
	
	public function getTeam(){
		$teamobj = new TeamModel();
		return view('team', ['teamlist' => $teamobj->getTeamList()]);
	}
	
	public function getBlog(){
		return view('bloghome');
	}
	
	public function get_car_ins_stories_section(){
		return view('car/layouts/c_car_ins_stories');
	}
	public function get_car_getquote_section(){
		return view('car/layouts/c_car_getquote');
	}
	public function get_car_terms_section(){
		return view('car/layouts/c_car_terms');
	}
	public function get_car_mustread_section(){
		return view('car/layouts/c_car_mustread');
	}

	public function getCarInsuranceOffer(){
		return view('pages.car_insurance_offer');
	}

	public function setCarInsuranceOfferCustomer(Request $request){
		$offer_customer_register = CustomerDetails::insuranceOfferRegisterUser($request);
		///dd($offer_customer_register);
		switch ($offer_customer_register) {
            case '0':
                return array(
                        'error'     => 'true',
                        'user_status'     => $offer_customer_register,
                        'message'   => Common_Constants::REGISTRATION_FAILUER_MESSAGE
                    );
                break;
            default:
                return array(
                        'error'     => 'false',
                        'user_status'     => $offer_customer_register,
                        'message'   => Common_Constants::OFFER_SUCCESS_MESSAGE
                    );
                break;
        }
	}	

	public function insta_product($category_url, $product_url)
	{ 
		$category = InstaCategory::getInstaCategory($category_url);
		$category_list = $category->toArray();
		$insta_products = InstaProduct::getInstaProduct($product_url,$category_list['category_code']);
		$products = $insta_products->toArray();
		
		if(!empty($products) && $products != []){
			return view('pages/insta_product',compact('insta_products'));
		} else {
		    return redirect($category_url);
		}
		

	}


	// Common method for response from last decimal for BAGI

	public function commonBagiPaymentResponse(Request $request){
		// bagi.payment_response

		if($request->productID == 'MTR'){
			return \Redirect::route('bagi.payment_response', $request->all());
		} else {
			//Helth
		}
		
	}

	// Redirect to Car or Health Payment Response for Bajaj 
	public function commonBajajPaymentResponse(Request $request){
		$car_helper = new CarHelper;
		if($car_helper->suidExit())
			return redirect()->action('Car\Policy\Bajajallianz@returnPage',$request->all());
		else
			return redirect()->action('Health\Policy\BajajAllianz@returnPage',$request->all());
	}

	// Redirect to Car or Health Payment Response for Unishompo
	public function commonShompoPaymentResponse(Request $request){
		$car_helper = new CarHelper;
		if($car_helper->suidExit())
			return redirect()->action('Car\Policy\UniSompo@returnPage',$request->all());
		else
			return redirect()->action('Health\Policy\UniversalSompo@returnPage',$request->all());
	}


	// Set Mode into UAT
	public function uatindex($uat_mode = null){
		if($uat_mode == 'uat'){
			session(['uat_mode' => 'true']);
			return $this->index();
		} else {
			session(['uat_mode' => 'false']);
			return $this->index();
		}
	}
}

