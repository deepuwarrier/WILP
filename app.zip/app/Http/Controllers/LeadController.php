<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Leadmaster;
use App\Constants\Common_Constants; 
use App\Helpers\LeadHelper;
use Log; 

class LeadController extends Controller
{
	public function index_agent($agent_id,Request $request)
    {
        return view('pages.survey', ['agent_id' => $agent_id]);
    }
    public function index_no_agent(Request $request){
        return view('pages.survey', ['agent_id' => 0]);
    }
    public function save_survey($agent_id,Request $request){
       $table = LeadHelper::setTable($agent_id, $request->all());
       Leadmaster::set_survey($table);
       if(!$agent_id)
       return redirect()->route('vew_helath_survey_no_agent');
   	   else
   	   return redirect()->route('vew_helath_survey', $agent_id);	
    }
    
}


