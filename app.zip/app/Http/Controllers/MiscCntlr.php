<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


class MiscCntlr extends Controller {

    
    public function redirect_policy_entry(Request $request) {  
    	return view("ttibigmc", [
    			"emp_data" => null,
    			"msg_txt" => ""
    	]);
    }
    
    
    
    } // class
