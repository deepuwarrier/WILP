<?php
namespace App\Http\Controllers\Reports;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Car AS M;
use App\Constants\Common_Constants;
use Excel;

class Export extends Controller
{
    public static function cartisanReport()
    {
    	$payment_success = M \ CarTData::getAffiliateData('cartisan');
    	$paymentsArray[] = ['Date', 'Landing Page','Quote','Proposal','Payment Success','Premium'];
    	foreach ($payment_success as $payment) {
	        $paymentsArray[] = $payment;
	    }
		$data = $payment_success;
		ob_end_clean();
		ob_start();
	 	Excel::create('InstaInsure Traffic Report For Cartisan', function($excel) use ($paymentsArray) {

	        // Set the spreadsheet title, creator, and description
	        // $excel->setTitle('Payments');
	        // $excel->setCreator('Laravel')->setCompany('WJ Gilmore, LLC');
	        // $excel->setDescription('payments file');

	        // Build the spreadsheet, passing in the payments array

	        $excel->sheet('Reports', function($sheet) use ($paymentsArray) {
	        	
	        	$sheet->mergeCells('A1:F1');
	        	$sheet->row(1,['Cartisan Traffic Report']);
	        	$sheet->cells('A1', function($cells) {
	        		$cells->setFontColor('#ffffff');
	        		$cells->setBackground('#ed7d31');
				    $cells->setAlignment('center');

				});
				$sheet->cells('A3:F3',function($cells){
					$cells->setFontColor('#ffffff');
					$cells->setBackground('#0070c0');
					$cells->setAlignment('center');
				});
				$sheet->setColumnFormat(array('F'=>'0'));
	            $sheet->fromArray($paymentsArray, null, 'A3', false, false);
	        });

	    })->export('xlsx');
    }

    public static function agentReport(){
    	$cartdata = new M \ CarTData();
    	$user_code = !empty(session('user_code'))?session('user_code'):NULL;
    	$agent_data = $cartdata->getAgentData($user_code);
    	array_unshift($agent_data['till_date'],'YTD');
    	//$paymentsArray[] = ['Date','Quote','Proposal','Policy','Premium'];
    	// foreach ($agent_data as $payment) {
	    //     $paymentsArray[] = $payment;
	    // }
		// dd($agent_data);
		ob_end_clean();
		ob_start();
		//Vivek_Status-Report_26-Jul-2017.xlsx
		$agent_name = str_replace(' ','_',$agent_data['agent_details']['agent_name']);
		$current_date = date('d_M_Y');
		$file_name	=	$agent_name.'_Report_'.$current_date;
	 	Excel::create($file_name, function($excel) use ($agent_data) {

	        // Set the spreadsheet title, creator, and description
	        // $excel->setTitle('Payments');
	        // $excel->setCreator('Laravel')->setCompany('WJ Gilmore, LLC');
	        // $excel->setDescription('payments file');

	        // Build the spreadsheet, passing in the payments array

	        $excel->sheet('Daily Report', function($sheet) use ($agent_data) {
	        	
	        	$sheet->mergeCells('A1:E1');
	        	$sheet->row(1,['Daily Agent Report']);
	        	$sheet->cells('A1', function($cells) {
	        		$cells->setFontColor('#ffffff');
	        		$cells->setBackground('#ed7d31');
				    $cells->setAlignment('center');

				});
				$sheet->cells('A5:E5',function($cells){
					$cells->setFontColor('#ffffff');
					$cells->setBackground('#0070c0');
					$cells->setAlignment('center');
				});
				$sheet->cell('B3', function($cell) {
				    $cell->setValue('Agent name');
				    $cell->setFontWeight('bold');
				});

				$sheet->cell('C3', function($cell)  use ($agent_data) {
				    $cell->setValue($agent_data['agent_details']['agent_name']);
				    $cell->setFontWeight('bold');
				});
				$sheet->cell('D3', function($cell) {
				    $cell->setValue('Agent Code');
				    $cell->setFontWeight('bold');
				});
				$sheet->cell('E3', function($cell)  use ($agent_data) {
				    $cell->setValue($agent_data['agent_details']['agent_code']);
				    $cell->setFontWeight('bold');
				});

				$sheet->setColumnFormat(array('F'=>'0'));
				//$sheet->row(5,array_keys($agent_data['today']));
				$sheet->row(5,['Date','Quote','Proposal','Policy','Premium']);
				$sheet->row(7,$agent_data['today']);
				$sheet->row(9,$agent_data['till_date']);
	        });

	    })->export('xlsx');
    }
}

?>
