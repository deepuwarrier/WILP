<?php
namespace App\Http\Controllers\Services;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Service\PolicyCounterService;
use Illuminate\Support\Facades\Log;

class PolicyCounterCntlr extends Controller
{
	public function service ( Request $request){  
		try{
			$req_params = json_decode($request->input("str"), true);
			
// 	    	ignore_user_abort(true);	set_time_limit(0);
// 	    	ob_start();
// 	    	echo "true"; 
// 	    	header('Connection: close');	header('Content-Length: '.ob_get_length());
// 	    	ob_end_flush();	flush();
		
		$service_ob = new PolicyCounterService();
		 $service_ob->service_handler($req_params);
		}catch(\Exception $ex){ return "Error in Service.";}
		
	}	

}
