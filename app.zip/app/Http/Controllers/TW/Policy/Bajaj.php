<?php
namespace App\Http\Controllers\TW\Policy;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Constants\Tw_Constants;
use App\Be\Common\PaymentParseBE;
use App\Be\TW\TwPolicyBe;
use App\Models\TW\data\PolicyPageData;
use App\Models\TW\TwStates;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwPolicyData;
use App\Models\TW\TwCovers;
use App\Helpers\Email\EmailEngine;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\Bajaj\BajajProposalManager;
use App\Services\Client\PolicyCounterService;
use App\Libraries\TWLib;
use App\Libraries\InstaLib;
use Log;


class Bajaj extends Controller
{

	public function __construct()
	{
	}
	
	public function load_policy_page($tw_trans_code)
	{
		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($tw_trans_code);
		
		$insr_column = "bajaj_code";
		$usr_db = new TwUsrData();
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		if(!isset($usr_data)){
			return redirect(\URL::to('/two-wheeler-insurance'));
		}
		$d_preview = $usr_db->details_preview($tw_trans_code);
		$q_preview = $usr_db->quote_preview($tw_trans_code); 
		

		// $proposal_manager = new BajajProposalManager;
		// $proposal_manager->genProposalRequest($usr_data);

		$insta_lib = new InstaLib();
		$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
		$proposal_status['proposal_status'] = 'TS13';
		$proposal_status['trans_status'] = 'TS13';
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);

		$policy_page_data = new PolicyPageData();

		$state_db = new TwStates();
		$policy_page_data->_state_list($state_db->state_list());
		$policy_page_data->_rto_code($d_preview['rto_code']);

		$yom_list =  array ( $d_preview['yor'], $d_preview['yor']-1);
		$policy_page_data->_yom_list($yom_list);

		$preinsr_db = new TwPreInsurers();
		$policy_page_data->_pre_insurer_list( $preinsr_db->insr_preinsur_list( $insr_column) );

		$nomrel_db = new TwNomRel();
		$policy_page_data->_nom_rel_list( $nomrel_db->insr_nom_rel_list(Tw_Constants::HDFC_COLUMN_NAME) );

		$policy_be = new TwPolicyBe();
		$quote_resp=  $policy_be->parse_proposal_pipb($usr_data);
		$cover_db = new TwCovers();

		return view('tw/policy/bajajallianz/proposal_home', [ 
				'tw_trans_code' => $tw_trans_code,
				'd_preview' => $d_preview,
				'q_preview' => $q_preview,
				'base_data' => $policy_page_data,
				'quote' => $quote_resp,
				'cover_list' => $cover_db->_list()
		]);
	}

	public function submit_proposal (Request $request)  {
		$email_engine =  new EmailEngine;
		$proposal_ob =  new BajajProposalManager;
		$tw_trans_code = $request->input('tw_trans_code');
		$usr_db = new TwUsrData();
		$policy_be = new TwPolicyBe();
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		$proposal_resp = $proposal_ob->submit_policy($tw_trans_code,null);

		if ($proposal_resp != null ){
			$case_flag  = $proposal_resp["type"] ; 
			
			switch ($case_flag) {
				case "success":
					
					$usr_db->set_by_tc($tw_trans_code , array(
					Tw_Constants::FINAL_PREMIUM=> $usr_data->total_premium,
					Tw_Constants::PR_CUSTOMERID => $proposal_resp["pr_customerid"]
					));
					
					$nochange_data = array(
					"tw_trans_code"=>$tw_trans_code ,
					"final_premium" =>$usr_data->total_premium,
					"insurer_logo" => "bajaj_logo.png",
					"insurer_code" => 'bajaj'
					);
					return view('tw/policy/no_change_premium', [ 'nochange_data'=> $nochange_data 	]);
					break;
					
				case "premismatch":
					$revised_data = array(
					"tw_trans_code"=>$tw_trans_code,
					"revised_premium"=>$proposal_resp["revised_premium"],
					"previous_premium" =>$usr_data->total_premium,
					"insurer_logo" => "bajaj_logo.png",
					"insurer_code" => 'bajaj'
							);
					return view('tw/policy/premium_missmatch', [ 'revised_data'=> $revised_data ]);
					break;
				
				default:
						//this is proposal errors show error message 
					return response()->json( ["resp_flag" => "error_msg", "datav"=>$proposal_resp["error_message"] ] , 200);
			}
			
		}else {
			// go to proposal error page. 
		   return response()->json( ["resp_flag" => "error_page"] , 200);
		}

		return $proposal_resp;
	}

	public function submit_payment (Request $request) {
		$payment_parse_be = new PaymentParseBE;
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		$insta_lib = new InstaLib();
		$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
		$proposal_status['payment_status'] = 'TS16';
		$proposal_status['trans_status'] =  'TS16';
		// $proposal_status['pay_mode'] =  $request->input('tw_pay_mode');
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);
		
		$pay_form_data = array();
		$payment_parse_be->setPaymentIdentifier($tw_trans_code,$usr_data->pr_customerid);
		return ['payment_url'=>'http://webservicesdev.bajajallianz.com/Insurance/WS/new_cc_payment.jsp?requestId='.$usr_data->pr_customerid.'&Username=policy@instainsure.com&sourceName=WS_MOTOR'];	
	} // method end. 

	public function payment_status(Request $request){
		$email_engine =  new EmailEngine;
		Log::info( "TW BAJAJ Payment Response" . print_r($request->all(),true));
		
		$pay_resp = $request->all();

		$trans_status = 0 ;  // false.
		$usr_db = new TwUsrData(); 
		$twlib_db = new TwLib();
		$insta_lib = new InstaLib();

		$payment_parse_be = new PaymentParseBE;
		$tw_trans_code = $payment_parse_be->getPaymentIdentifier($pay_resp['requestID']);

		$policy_no = ""; 
		$proposal_no = "";
		$trans_msg = "";
		
		$usr_db = new TwUsrData();
		$usr_data = $usr_db->get_by_tc($tw_trans_code);

		if(isset($pay_resp['policyref']) && !is_null($pay_resp['policyref'])) {
			$trans_status = 1;
			$policy_no = $pay_resp['policyref'];
			$proposal_no = $pay_resp['requestID'];

			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['policy_date'] = $insta_lib->today_date_dMY();
			$proposal_status['policy_number'] = $policy_no;
			$proposal_status['payment_status'] = 'TS17';
			$proposal_status['trans_status'] =  'TS17';
			if(isset($usr_data->proposal_status) && $usr_data->proposal_status == 'TS20'){
				$proposal_status['proposal_status'] = 'TS21';
				$proposal_status['trans_status'] =  'TS21';
			}
			$proposal_status['policy_status'] = 'TS19';
			$proposal_status[Tw_Constants::TRANS_CODE] = $tw_trans_code ."_DONE";
			$proposal_status['trans_status'] = $proposal_status['policy_status'];
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code ."_DONE");
			$usr_data = $usr_db->get_by_sc($tw_trans_code);
			$insurer_data = new InsurerData;
			$request_array = array(
							"module_name"=> "TW",
							"insurer_code"=> $insurer_data->insurer_data("isu_desc",$usr_data->insurer_code),
							"agent_code"=> !empty($usr_data->agent_code)?$usr_data->agent_code:null,
							"policy_date"=> $usr_data->policy_date,
							"policy_type"=> $usr_data->policy_type,
							"policy_nature"=> "Rollover",
							"policy_number"=> $usr_data->policy_number,
							"od_premium"=> $usr_data->od_premium,
							"tp_premium"=> $usr_data->tp_premium,
							"total_premium"=> $usr_data->total_premium,
							"tax"=> $usr_data->total_tax,
							"final_premium"=> $usr_data->final_premium
							);
			$policy_counter = new PolicyCounterService;
			$result = $policy_counter->service_handler($request_array);
			\Log::info($usr_data->trans_code.' Policy Counter Status : '.$result);

		}else {
			$policy_no = "";
			$proposal_no = $usr_data->temp_col_1;
			// $trans_msg = $pay_resp_arr[6];

			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS02';
			$proposal_status['trans_status'] =  'TS02';
			// $proposal_status['payment_desc'] = $trans_msg;
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);

		}
		
		$usr_db->set_by_tc($tw_trans_code, array(
				Tw_Constants::TRANS_STATUS => $trans_status,
				Tw_Constants::PR_NUMBER=> $proposal_no,
				Tw_Constants::POLICY_NUMBER=> $policy_no,
		));

		
		if($policy_no != ''){
			$ssn_key =	$tw_trans_code ;
			$policy_db = new TwPolicyData();
			$policy_db->set_record($ssn_key);
		}

		$download_link = Tw_Constants::RELIANCE_PDF_URL."?PolicyNo=".$policy_no."&ProductCode=2312";
		$trans_resp = array (
				"trans_status" => $trans_status,
				"policy_number" => $policy_no,
				"trans_msg" => $trans_msg,
				"proposal_number" => $proposal_no,
				"insurer_logo" => "bajaj_logo.png",
				"download_link" => $download_link
		);
		return view('tw.policy.bajajallianz.payment_status', [ 'trans_resp' =>$trans_resp] );
	}
	
	
	public function index($snn_key)
	{
		$usr_db = new TwUsrData();
		$d_preview = $usr_db->details_preview($snn_key);
		$q_preview = $usr_db->quote_preview($snn_key); 
		
		
		return view('tw/policy/bajajallianz/bajajallianz' , [
				'd_preview' =>$d_preview,
				'q_preview' => $q_preview
		]);
	}
}

