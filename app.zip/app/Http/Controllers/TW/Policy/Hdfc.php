<?php
namespace App\Http\Controllers\TW\Policy;


use App\Be\TW\TwPolicyBe;
use App\Constants\Common_Constants;
use App\Constants\Tw_Constants;
use App\Helpers\TW\HDFC\HDFCPolicyManager;
use App\Helpers\TW\InsurerData;
use App\Http\Controllers\Controller;
use App\Models\TW\data\PolicyPageData;
use App\Models\TW\TwCovers;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwPolicyData;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwStates;
use App\Libraries\InstaLib;
use App\Services\Client\PolicyCounterService;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Helpers\Email\EmailEngine;
use App\Be\Common\PaymentParseBE;
use App\Libraries\ValidatorLib;
use App\Libraries\TwLib;


class Hdfc extends Controller
{

	public function __construct()
	{
	}
	
	public function load_policy_page($tw_trans_code)
	{
		$insr_column = "hdfc_code";
		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($tw_trans_code);

		// session(['tw_transcode' => $tw_trans_code]);
		
		$usr_db = new TwUsrData();
		$d_preview = $usr_db->details_preview($tw_trans_code);
		$q_preview = $usr_db->quote_preview($tw_trans_code); 
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		$insta_lib = new InstaLib();
		$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
		$proposal_status['proposal_status'] = 'TS13';
		$proposal_status['trans_status'] = 'TS13';
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);
		
		$policy_page_data = new PolicyPageData();
		
		if(($usr_data->pre_policy_status == 'E90P') || ($usr_data->pre_policy_status == 'E90')){
			$tw_lib = new TwLib();
			$date_today = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
			$term_start_date = $usr_data->term_start_date;
			$trm_st_date = $tw_lib->date_adjust_days( $date_today, 3);
			if($term_start_date != $trm_st_date){
				 return redirect('two-wheeler-insurance/quote/'.$tw_trans_code);
			}
		}
		
		
		$state_db = new TwStates();
		$policy_page_data->_state_list($state_db->state_list());
		$policy_page_data->_rto_code($d_preview['rto_code']);
		
		$yom_list =  array ( $d_preview['yor'], $d_preview['yor']-1);
		$policy_page_data->_yom_list($yom_list);
		
		$nomrel_db = new TwNomRel();
		$policy_page_data->_nom_rel_list( $nomrel_db->insr_nom_rel_list(Tw_Constants::HDFC_COLUMN_NAME) );
		
		$preinsr_db = new TwPreInsurers();
		$policy_page_data->_pre_insurer_list( $preinsr_db->insr_preinsur_list( $insr_column) );
		
		if( strpos($usr_data->addon_covers, "ZRDP") !== false ) {$policy_page_data->set_pre_zerodept("Y");}
		$policy_page_data->set_pre_policy_status($usr_data->pre_policy_status == "E90P" ? false : true);		
		
		$policy_be = new TwPolicyBe();
		$quote_resp=  $policy_be->parse_proposal_pipb($usr_data);
		$cover_db = new TwCovers();
		
		return view('tw/policy/hdfc/proposal_home', [ 
				'tw_trans_code' => $tw_trans_code,
				'd_preview' => $d_preview,
				'q_preview' => $q_preview,
				'base_data' => $policy_page_data,
				'quote' => $quote_resp,
				'cover_list' => $cover_db->_list()
		]);
		
	}
	
	public function submit_proposal (Request $request)  {
		$email_engine =  new EmailEngine;
		$proposal_ob = new HDFCPolicyManager();
		$tw_trans_code = $request->input('tw_trans_code');
		$usr_db = new TwUsrData();
		$policy_be =new TwPolicyBe();
		
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		if($usr_db->proposal_status != 'TS20'){
			$insta_lib = new InstaLib();
			$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
			$proposal_status['proposal_status'] = 'TS14';
			$proposal_status['trans_status'] = 'TS14';
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
		}

		$validation_arr = $this->validate_data($usr_data);
		
		if($validation_arr["verror"]){ 
			return response()->json( ["resp_flag" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
		} 

		// Proposal Submit Email Implementation
		$opted_covers = $policy_be->parse_covers( $usr_data->addon_covers != null ? $usr_data->addon_covers : "" );
		if(in_array("ZRDP", $opted_covers)){
			if( $usr_data->pre_zerodept == "N") {
				// go to proosal error page.
				return response()->json( ["resp_flag" => "error_page"] , 200);
			}
		}
		
		
		
		$proposal_resp = $proposal_ob->submit_policy( $tw_trans_code , null);
		
		
		if ($proposal_resp != null ){
			$case_flag  = $proposal_resp["type"] ; 
			
			switch ($case_flag) {
				case "success":
					
					$usr_db->set_by_tc($tw_trans_code , array(
					Tw_Constants::FINAL_PREMIUM=> $usr_data->total_premium,
					Tw_Constants::PR_CUSTOMERID => $proposal_resp["pr_customerid"]
					));
					
					$nochange_data = array(
					"tw_trans_code"=>$tw_trans_code ,
					"final_premium" =>$usr_data->total_premium,
					"insurer_logo" => "hdfcgi_logo.png",
					"insurer_code" => 'hdfc'
					);
					return view('tw/policy/no_change_premium', [ 'nochange_data'=> $nochange_data 	]);
					break;
					
				case "premismatch":
					$revised_data = array(
					"tw_trans_code"=>$tw_trans_code,
					"revised_premium"=>$proposal_resp["revised_premium"],
					"previous_premium" =>$usr_data->total_premium,
					"insurer_logo" => "hdfcgi_logo.png",
					"insurer_code" => 'hdfc'
							);
					return view('tw/policy/premium_missmatch', [ 'revised_data'=> $revised_data ]);
					break;
				
				default:
						//this is proposal errors show error message 
					return response()->json( ["resp_flag" => "error_msg", "datav"=>$proposal_resp["error_message"] ] , 200);
			}
			
		}else {
			// go to proposal error page. 
		   return response()->json( ["resp_flag" => "error_page"] , 200);
		}
		
		
	}// end of method

	private function validate_data($usr_data){
		$valid_lib = new ValidatorLib;
		$required_array = [
							'mobile' => $usr_data->proposer_mobile,
							'customer_name' => $usr_data->proposer_name,
							'customer_dob' => $usr_data->proposer_dob,
							'customer_aadharno' => $usr_data->proposer_aadharno,
							'customer_email' => $usr_data->proposer_email,
							'customer_add1' => $usr_data->proposer_addr1,
							'customer_add2' => $usr_data->proposer_addr2,
							'customer_add3' => $usr_data->proposer_addr3,
							'customer_pincode' => $usr_data->proposer_pincode,
							'tw_reg_no' => $usr_data->tw_reg_no,
							'tw_engine_no' => $usr_data->tw_engine_no,
							'tw_chasis_no' => $usr_data->tw_chassis_no,
							'color' => $usr_data->color,
							'nominee_name' => $usr_data->nomi_name
						];
		if($usr_data->pre_policy_status != 'E90P'){
			$required_array['tw_pre_policy'] = $usr_data->pre_policy_number;
		}
		return $valid_lib->proposalSubmit($required_array);
	}

// Re-entry to the system from PG with resonse and policy details.
public function payment_status (Request $request)  {  
	$email_engine =  new EmailEngine;
	Log::info($url = $request->fullUrl());
	Log::info('Payment Response = '.print_r($request->all()));
		$policy_no = $request->input("PolicyNo");
		$trans_msg = $request->input("Msg");
		$proposal_no = $request->input("ProposalNo");
		$trans_status = 0 ;  // false.
		$usr_db = new TwUsrData(); 
		$payment_parse_be = new PaymentParseBE;
		$tw_trans_code = $payment_parse_be->getPaymentIdentifier($proposal_no);
		// $tw_trans_code =	$this->get_suid();
	
		$usr_data = $usr_db->get_by_tc($tw_trans_code); 
		if( !($usr_data != null && $usr_data->final_premium != null && $usr_data->insurer_code != null)) {
		 $resp_str =  "<br><br> <div align='center'><h1>Your Browser Cleared the Transcation Data. <h1>";
		 $resp_str = $resp_str ."<h3>&nbsp;</h3>";
		 $resp_str = $resp_str ."<h2>Redirecting to Home.</h2></div>";
		 echo $resp_str;
		 sleep(5);
		 return redirect("/two-wheeler-insurance");
		}
		
		
		if ( $policy_no != null && $policy_no != 0 ){
			$trans_status = 1;
			
// 			$policy_db = new TwPolicyData();
			$insta_lib = new InstaLib();
			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['policy_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS17';
			$proposal_status['policy_status'] = 'TS19';
			$proposal_status['trans_status'] =  'TS19';
			$proposal_status[Tw_Constants::PR_NUMBER] =  $proposal_no;
			$proposal_status[Tw_Constants::POLICY_NUMBER] =  $policy_no;
			$proposal_status[Tw_Constants::TRANS_CODE] = $tw_trans_code ."_DONE";
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
			
			$usr_data= $usr_db->get_by_sc($tw_trans_code);		
			$insurer_data = new InsurerData;
			$request_array = array(
								"module_name"=> "TW",
								"insurer_code"=> $insurer_data->insurer_data("isu_desc",$usr_data->insurer_code),
								"agent_code"=> !empty($usr_data->agent_code)?$usr_data->agent_code:null,
								"policy_date"=> $usr_data->policy_date,
								"policy_type"=> $usr_data->policy_type,
								"policy_nature"=> "Rollover",
								"policy_number"=> $usr_data->policy_number,
								"od_premium"=> $usr_data->od_premium,
								"tp_premium"=> $usr_data->tp_premium,
								"total_premium"=> $usr_data->total_premium,
								"tax"=> $usr_data->total_tax,
								"final_premium"=> $usr_data->final_premium
								);
			$policy_counter = new PolicyCounterService;
			$result = $policy_counter->service_handler($request_array);
          	\Log::info($usr_data->trans_code.' Policy Counter Status : '.$result);
          	
          	$ssn_key =	$tw_trans_code ;
			$policy_db = new TwPolicyData();
			$policy_db->set_record($ssn_key);
			
// 			if( $usr_data != null && $usr_data->final_premium != null && $usr_data->insurer_code != null) {
// 				$policy_db->set_policy( $ssn_key, $usr_data);						// storing to policy table 
// 			}
			
		}else {
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::TRANS_STATUS => Common_Constants::TS_PAYMENT_FAIL,
					Tw_Constants::PR_NUMBER=> $proposal_no,
					Tw_Constants::POLICY_NUMBER=> $policy_no
			));  
			
			$insta_lib = new InstaLib();
			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['policy_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS02';
			$proposal_status['policy_status'] = 'TS19';
			$proposal_status['trans_status'] =  'TS02';
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
			$usr_data= $usr_db->get_by_tc($tw_trans_code);	
		}
		
		$trans_resp = array (
				"trans_status" => $trans_status,
				"policy_number" => $policy_no,
				"trans_msg" => $trans_msg,
				"proposal_number" => $proposal_no,
				"insurer_logo" => "hdfc_logo.png"
		);
		
		return view('tw.policy.hdfc.payment_status', [ 'trans_resp' =>$trans_resp] );
		
	} // end of method.
	
	public function submit_payment (Request $request) {
		$payment_parse_be = new PaymentParseBE;
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		$insta_lib = new InstaLib();
		$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
		$proposal_status['payment_status'] = 'TS16';
		$proposal_status['trans_status'] =  'TS16';
		$proposal_status['pay_mode'] =  $request->input('tw_pay_mode');
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);

		$pay_form_data = array();
		$payment_parse_be->setPaymentIdentifier($tw_trans_code,$usr_data->pr_customerid);
		$pay_form_data["CustomerId"] = $usr_data->pr_customerid;
		$pay_form_data["TxnAmount"] = $usr_data->final_premium;
		$pay_form_data["AdditionalInfo1"] = "NB";
		$pay_form_data["AdditionalInfo2"] = "TW";
		$pay_form_data["AdditionalInfo3"] = "1";
		$pay_form_data["hdnPayMode"] = $request->input('tw_pay_mode');
		$pay_form_data["UserName"] =  $usr_data->proposer_name;
		$pay_form_data["UserMailId"] =  $usr_data->proposer_email;
		$pay_form_data["ProductCd"] = "TW";
		$pay_form_data["ProducerCd"] = Tw_Constants::HDFC_PARTNER_CODE . "-" . $usr_data->pr_customerid;
 		$pay_form_data["payurl"] = "https://netinsure.hdfcergo.com/onlineproducts/twonline/TIM.aspx";
		
		
			return $pay_form_data;
	} // method end. 
	
	public function pm_submit_payment (Request $request) {
		$payment_parse_be = new PaymentParseBE;
		// 1. get new values. 
		$agreed_premium= $request->input('agreed_premium');
		// 2. update them to db .  - at present no update to db.
		
		$proposal_ob = new HDFCPolicyManager();
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');

		//3. submit proposal once again. and ensure premium is done.
		$proposal_resp = $proposal_ob->submit_policy( $tw_trans_code, $agreed_premium);
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		

		if ($proposal_resp != null && $proposal_resp["type"]  == "success"){   

			$insta_lib = new InstaLib();
			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS21';
			$proposal_status['trans_status'] =  'TS21';
			$proposal_status['payment_ref_number'] = $proposal_resp["pr_customerid"];
			$proposal_status['pay_mode'] =  $request->input('tw_pay_mode');
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);

		
			// if we have received. success with revised premium than return payment form.
			$pay_form_data = array();
			$payment_parse_be->setPaymentIdentifier($tw_trans_code,$proposal_resp["pr_customerid"]);
			$pay_form_data["CustomerId"] = "".$proposal_resp["pr_customerid"];
			$pay_form_data["TxnAmount"] = $agreed_premium ;
			$pay_form_data["AdditionalInfo1"] = "NB";
			$pay_form_data["AdditionalInfo2"] = "TW";
			$pay_form_data["AdditionalInfo3"] = "1";
			$pay_form_data["hdnPayMode"] = $request->input('tw_pay_mode');
			$pay_form_data["UserName"] =  $usr_data->proposer_name;
			$pay_form_data["UserMailId"] =  $usr_data->proposer_email;
			$pay_form_data["ProductCd"] = "TW";
			$pay_form_data["ProducerCd"] = Tw_Constants::HDFC_PARTNER_CODE . "-" . $proposal_resp["pr_customerid"];
			$pay_form_data["payurl"] = "https://netinsure.hdfcergo.com/onlineproducts/twonline/TIM.aspx";
			
			
			
			
			return $pay_form_data;
			
			
			
				} else if ($proposal_resp != null && $proposal_resp["type"]  == "error"){
			Log::info("TW - HDFC - Error while submiting payment",$proposal_resp);
			return response()->json( ["resp_flag" => "error_msg", "datav"=>$proposal_resp["error_message"] ] , 200);
			

		}
		
		
	} // method end. 
	
	private  function get_suid() {
		return (session()->has('tw_transcode')) ? session('tw_transcode') : session()->getId();
	}
	
	
}// end of class

