<?php
namespace App\Http\Controllers\TW\Policy;


use App\Be\TW\TwPolicyBe;
use App\Constants\Common_Constants;
use App\Constants\Tw_Constants;
use App\Helpers\TW\HDFC\HDFCPolicyManager;
use App\Http\Controllers\Controller;
use App\Models\TW\data\PolicyPageData;
use App\Models\TW\TwCovers;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwPolicyData;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwStates;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Helpers\Email\EmailFactory;
use App\Helpers\Email\EmailData;


class Hdfc extends Controller
{

	public function __construct()
	{
	}
	
	public function load_policy_page($tw_trans_code)
	{
		$insr_column = "hdfc_code";
		
		session(['tw_transcode' => $tw_trans_code]);
		
		$usr_db = new TwUsrData();
		$d_preview = $usr_db->details_preview($tw_trans_code);
		$q_preview = $usr_db->quote_preview($tw_trans_code); 
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		
		$policy_page_data = new PolicyPageData();
		
		$state_db = new TwStates();
		$policy_page_data->_state_list($state_db->state_list());
		$policy_page_data->_rto_code($d_preview['rto_code']);
		
		$yom_list =  array ( $d_preview['yor'], $d_preview['yor']-1);
		$policy_page_data->_yom_list($yom_list);
		
		$nomrel_db = new TwNomRel();
		$policy_page_data->_nom_rel_list( $nomrel_db->insr_nom_rel_list(Tw_Constants::HDFC_COLUMN_NAME) );
		
		$preinsr_db = new TwPreInsurers();
		$policy_page_data->_pre_insurer_list( $preinsr_db->insr_preinsur_list( $insr_column) );
		
		if( strpos($usr_data->addon_covers, "ZRDP") !== false ) {$policy_page_data->set_pre_zerodept("Y");}
		$policy_page_data->set_pre_policy_status($usr_data->pre_policy_status == "E90+" ? false : true);		
		
		$policy_be = new TwPolicyBe();
		$quote_resp=  $policy_be->parse_proposal_pipb($usr_data);
		$cover_db = new TwCovers();
		
		return view('tw/policy/hdfc/proposal_home', [ 
				'tw_trans_code' => $tw_trans_code,
				'd_preview' => $d_preview,
				'q_preview' => $q_preview,
				'base_data' => $policy_page_data,
				'quote' => $quote_resp,
				'cover_list' => $cover_db->_list()
		]);
		
	}
	
	public function submit_proposal (Request $request)  {
		
		$proposal_ob = new HDFCPolicyManager();
		$tw_trans_code = $request->input('tw_trans_code');
		$usr_db = new TwUsrData();
		$policy_be =new TwPolicyBe();
		
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		// Proposal Submit Email Implementation

		$efob = new EmailFactory();
		$email_data = new EmailData();
		$email_data->set_event_name("PROPOSALSUBMIT");
		$email_data->set_insurer("HDFC");
		$email_data->set_module_name("TW");
		$email_data->set_to_mail_id($usr_data->proposer_email);
		$email_data->set_content_arr($usr_data);
		$efob->execute_email($email_data);

		
		$opted_covers = $policy_be->parse_covers( $usr_data->addon_covers != null ? $usr_data->addon_covers : "" );
		if(in_array("ZRDP", $opted_covers)){
			if( $usr_data->pre_zerodept == "N") {
				// go to proosal error page.
				return response()->json( ["resp_flag" => "error_page"] , 200);
			}
		}
		
		
		
		$proposal_resp = $proposal_ob->submit_policy( $tw_trans_code , null);
		
		
		if ($proposal_resp != null ){
			$case_flag  = $proposal_resp["type"] ; 
			
			switch ($case_flag) {
				case "success":
					
					$usr_db->set_by_tc($tw_trans_code , array(
					Tw_Constants::FINAL_PREMIUM=> $usr_data->total_premium,
					Tw_Constants::PR_CUSTOMERID => $proposal_resp["pr_customerid"]
					));
					
					$nochange_data = array(
					"tw_trans_code"=>$tw_trans_code ,
					"final_premium" =>$usr_data->total_premium,
					"insurer_logo" => "hdfcgi_logo.png"
					);
					return view('tw/policy/no_change_premium', [ 'nochange_data'=> $nochange_data 	]);
					break;
					
				case "premismatch":
					$revised_data = array(
					"tw_trans_code"=>$tw_trans_code,
					"revised_premium"=>$proposal_resp["revised_premium"],
					"previous_premium" =>$usr_data->total_premium,
					"insurer_logo" => "hdfcgi_logo.png"
							);
					return view('tw/policy/premium_missmatch', [ 'revised_data'=> $revised_data ]);
					break;
				
				default:
						//this is proposal errors show error message 
					return response()->json( ["resp_flag" => "error_msg", "datav"=>$proposal_resp["error_message"] ] , 200);
			}
			
		}else {
			// go to proosal error page. 
                    // Proposal Error Email 
			$efob = new EmailFactory();
			$email_data = new EmailData();
			$email_data->set_event_name("PROPOSALERROR");
			$email_data->set_insurer("HDFC");
			$email_data->set_module_name("TW");
			$email_data->set_to_mail_id($usr_data->proposer_email);
			$email_data->set_content_arr($usr_data);
			$efob->execute_email($email_data);
			return response()->json( ["resp_flag" => "error_page"] , 200);
		}
		
		
	}// end of method


// Re-entry to the system from PG with resonse and policy details.
public function payment_status (Request $request)  {  
	
	Log::info($url = $request->fullUrl());
	
		$policy_no = $request->input("PolicyNo");
		$trans_msg = $request->input("Msg");
		$proposal_no = $request->input("ProposalNo");
		$trans_status = 0 ;  // false.
		$usr_db = new TwUsrData(); 
		$tw_trans_code=	$this->get_suid();
	
		$usr_data = $usr_db->get_by_tc($tw_trans_code); 
		if( !($usr_data != null && $usr_data->final_premium != null && $usr_data->insurer_code != null)) {
		 $resp_str =  "<br><br> <div align='center'><h1>Your Browser Cleared the Transcation Data. <h1>";
		 $resp_str = $resp_str ."<h3>&nbsp;</h3>";
		 $resp_str = $resp_str ."<h2>Redirecting to Home.</h2></div>";
		 echo $resp_str;
		 sleep(5);
		 return redirect("/two-wheeler-insurance");
		}
		
		
		if ( $policy_no != null && $policy_no != 0 ){
			$trans_status = 1;
			
// 			$policy_db = new TwPolicyData();
			
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::TRANS_STATUS => Common_Constants::TS_COMPLETED,
					Tw_Constants::PR_NUMBER=> $proposal_no,
					Tw_Constants::POLICY_NUMBER=> $policy_no
			));

                        // policy success email
			$efob = new EmailFactory();
			$email_data = new EmailData();
			$email_data->set_event_name("POLICYSUCCESS");
			$email_data->set_insurer("HDFC");
			$email_data->set_module_name("TW");
			$email_data->set_to_mail_id($usr_data->proposer_email);
			$email_data->set_content_arr($usr_data);
			$efob->execute_email($email_data);
			
// 			$policy_db = new TwPolicyData();
// 			$policy_db->set_record($ssn_key);
			
// 			if( $usr_data != null && $usr_data->final_premium != null && $usr_data->insurer_code != null) {
// 				$policy_db->set_policy( $ssn_key, $usr_data);						// storing to policy table 
// 			}
			
		}else {
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::TRANS_STATUS => Common_Constants::TS_PAYMENT_FAIL,
					Tw_Constants::PR_NUMBER=> $proposal_no,
					Tw_Constants::POLICY_NUMBER=> $policy_no
			));
			
		}
		
		$trans_resp = array (
				"trans_status" => $trans_status,
				"policy_number" => $policy_no,
				"trans_msg" => $trans_msg,
				"proposal_number" => $proposal_no,
				"insurer_logo" => "hdfcgi_logo.png"
		);
		
		return view('tw.policy.hdfc.payment_status', [ 'trans_resp' =>$trans_resp] );
		
	} // end of method.
	
	public function submit_payment (Request $request) {
		
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		$pay_form_data = array();
		
		$pay_form_data["CustomerId"] = $usr_data->pr_customerid;
		$pay_form_data["TxnAmount"] = $usr_data->final_premium;
		$pay_form_data["AdditionalInfo1"] = "NB";
		$pay_form_data["AdditionalInfo2"] = "TW";
		$pay_form_data["AdditionalInfo3"] = "1";
		$pay_form_data["hdnPayMode"] = "CC";
		$pay_form_data["UserName"] =  $usr_data->proposer_name;
		$pay_form_data["UserMailId"] =  $usr_data->proposer_email;
		$pay_form_data["ProductCd"] = "TW";
		$pay_form_data["ProducerCd"] = Tw_Constants::HDFC_PARTNER_CODE . "-" . $usr_data->pr_customerid;
//		$pay_form_data["payurl"] = "http://202.191.196.210/uat/onlineproducts/twOnlinetariff/TIM.aspx";
 		$pay_form_data["payurl"] = "https://netinsure.hdfcergo.com/onlineproducts/twonline/TIM.aspx";
		
		
			return $pay_form_data;
	} // method end. 
	
	public function pm_submit_payment (Request $request) {
		
		// 1. get new values. 
		$agreed_premium= $request->input('agreed_premium');
		// 2. update them to db .  - at present no update to db.
		
		$proposal_ob = new HDFCPolicyManager();
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');

		//3. submit proposal once again. and ensure premium is done.
		$proposal_resp = $proposal_ob->submit_policy( $tw_trans_code, $agreed_premium);
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		if ($proposal_resp != null && $proposal_resp["type"]  == "success"){   

		
			// if we have received. success with revised premium than return payment form.
			$pay_form_data = array();
			
			$pay_form_data["CustomerId"] = "".$proposal_resp["pr_customerid"];
			$pay_form_data["TxnAmount"] = $agreed_premium ;
			$pay_form_data["AdditionalInfo1"] = "NB";
			$pay_form_data["AdditionalInfo2"] = "TW";
			$pay_form_data["AdditionalInfo3"] = "1";
			$pay_form_data["hdnPayMode"] = "CC";
			$pay_form_data["UserName"] =  $usr_data->proposer_name;
			$pay_form_data["UserMailId"] =  $usr_data->proposer_email;
			$pay_form_data["ProductCd"] = "TW";
			$pay_form_data["ProducerCd"] = Tw_Constants::HDFC_PARTNER_CODE . "-" . $proposal_resp["pr_customerid"];
			// 		$pay_form_data["payurl"] = "http://202.191.196.210/uat/onlineproducts/twOnlinetariff/TIM.aspx";
			$pay_form_data["payurl"] = "https://netinsure.hdfcergo.com/onlineproducts/twonline/TIM.aspx";
			
			
			
			
			return $pay_form_data;
			
			
			
		} else {
			// on premium mismatch something else . go to error page. 
			Log::info("TW - HDFC - Premium Mismatch Response Returned Again");
		}
		
		
	} // method end. 
	
	private  function get_suid() {
		return (session()->has('tw_transcode')) ? session('tw_transcode') : session()->getId();
	}
	
	
}// end of class

