<?php
namespace App\Http\Controllers\TW\Policy;


use App\Constants\Tw_Constants;
use App\Constants\Common_Constants;
use App\Helpers\TW\RSGI\RSGI_Policy_Factory;
use App\Libraries\ValidatorLib;
use App\Http\Controllers\Controller;
use App\Libraries\TwLib;
use App\Models\TW\data\PolicyPageData;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwOccupation;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwStates;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\TW\TwPolicyData;
use App\Services\Client\PolicyCounterService;
use App\Helpers\TW\InsurerData;
use App\Models\TW\data\QuoteRespData;
use App\Models\TW\TwCovers;
use App\Be\TW\TwPolicyBe;
use App\Libraries\InstaLib;
use App\Be\TW\RsgiBe;
use App\Helpers\Email\EmailEngine;
use App\Be\Common\PaymentParseBE;

class RSGI extends Controller
{

	public function load_policy_page($tw_trans_code)
	{
		$insr_column = "rsgi_code";
		$payment_parse_be = new PaymentParseBE;
		$payment_parse_be->setPaymentIdentifier($tw_trans_code);
		$usr_db = new TwUsrData();
		$d_preview = $usr_db->details_preview($tw_trans_code);
		$q_preview = $usr_db->quote_preview($tw_trans_code); 
		$usr_data = $usr_db->get_by_tc($tw_trans_code);

		$insta_lib = new InstaLib();
		$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
		$proposal_status['proposal_status'] = 'TS13';
		$proposal_status['trans_status'] = 'TS13';
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);
		
		$policy_page_data = new PolicyPageData();   
		
		$occ_db = new TwOccupation();
		$policy_page_data->set_occupation_list( $occ_db->occupation_list() );
		
		$state_db = new TwStates();
		$policy_page_data->_state_list($state_db->state_list());
		$policy_page_data->_rto_code($d_preview['rto_code']);
		
		$yom_list =  array ( $d_preview['yor'], $d_preview['yor']-1);
		$policy_page_data->_yom_list($yom_list);
		
		$nomrel_db = new TwNomRel();
		$policy_page_data->_nom_rel_list( $nomrel_db->nom_rel_list() );
		
		$preinsr_db = new TwPreInsurers();
		$policy_page_data->_pre_insurer_list( $preinsr_db->insr_preinsur_list( $insr_column) );
		
		if( strpos($usr_data->addon_covers, "ZRDP") !== false ) {
			$policy_page_data->set_pre_zerodept("Y");
		}
		if( $usr_data->pre_claim_status == "Y" ) {
			$policy_page_data->set_pre_claim_status(true);
		}
		
		
		$policy_be = new TwPolicyBe();
		$quote_resp=  $policy_be->parse_proposal_pipb($usr_data);
		$cover_db = new TwCovers();
		
		return view('tw/policy/rsgi/proposal_home', [ 
				'tw_trans_code' => $tw_trans_code,
				'd_preview' => $d_preview,
				'q_preview' => $q_preview,
				'base_data' => $policy_page_data,
				'quote' => $quote_resp,
				'cover_list' => $cover_db->_list()
		]);
		
	}
	
	public function submit_proposal (Request $request)  {   
		
	$proposal_obj = new RSGI_Policy_Factory();
	$email_engine =  new EmailEngine;

	$tw_trans_code = $request->input('tw_trans_code');
		$usr_db = new TwUsrData();
		
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		if($usr_db->proposal_status != 'TS20'){
			$insta_lib = new InstaLib();
			$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
			$proposal_status['proposal_status'] = 'TS14';
			$proposal_status['trans_status'] = 'TS14';
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
		}

		//proposal validations 
		$validation_arr = $this->validate_data($usr_data);
		
		if($validation_arr["verror"]){ 
			return response()->json( ["resp_flag" => "verror", "verror_txt"=> $validation_arr["verror_txt"] ] , 200);
		}
		
		$proposal_erros = $this->proposal_errors($usr_data);
		if( $proposal_erros["status"] == true){
			// go to policy error page.
			return response()->json( ["resp_flag" => "error_page", "TRN" => $tw_trans_code, "MSG" => $proposal_erros["msg"]] , 200);
		}
		
		$q_update_resp = $proposal_obj->update_quote($usr_data, null);
		return $this->quote_update_resp_exe("1", $tw_trans_code, $usr_data, $q_update_resp);
			
		
	}// end of method

	private function validate_data($usr_data){
		$valid_lib = new ValidatorLib;
		$required_array = [
							'mobile' => $usr_data->proposer_mobile,
							'customer_name' => $usr_data->proposer_name,
							'customer_dob' => $usr_data->proposer_dob,
							'customer_aadharno' => $usr_data->proposer_aadharno,
							'customer_email' => $usr_data->proposer_email,
							'customer_add1' => $usr_data->regn_addr1,
							'customer_add2' => $usr_data->regn_addr2,
							'customer_add3' => $usr_data->regn_addr3,
							'customer_pincode' => $usr_data->regn_pincode,
							'tw_reg_no' => $usr_data->tw_reg_no,
							'tw_engine_no' => $usr_data->tw_engine_no,
							'tw_chasis_no' => $usr_data->tw_chassis_no,
							'color' => $usr_data->color,
							'tw_pre_policy' => $usr_data->pre_policy_number,
							'pre_insurer_addr' => $usr_data->pre_insurer_addr,
							'nominee_name' => $usr_data->nomi_name
						];
		if($usr_data->pre_claim_status == "Y"){
			$required_array['pre_claim_count'] = $usr_data->pre_claim_count;
			$required_array['pre_claim_amount'] = $usr_data->pre_claim_amount;
		}
		return $valid_lib->proposalSubmit($required_array);
	}

	private function quote_update_resp_exe( $type_flag, $tw_trans_code, $usr_data, $q_update_resp) {
	$usr_db = new TwUsrData();
	$insta_lib = new InstaLib();
	$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
	$case_flag  = $q_update_resp->get_pr_type() ;
	switch ($case_flag) {
		case "success":
			
			$usr_db->set_by_tc($tw_trans_code, array(
			Tw_Constants::FINAL_PREMIUM=> $usr_data->total_premium
			));
			if( $type_flag == "1") {  
				$nochange_data = array(
						"tw_trans_code"=>$tw_trans_code,
						"final_premium" =>$usr_data->total_premium,
						"insurer_logo" => "rsgi_logo.png"
				);
				$proposal_status['proposal_status'] =  'TS15';
				$proposal_status['trans_status'] =  'TS15';
				// $proposal_status['proposal_desc'] = $proposal_resp->WsMessage;
				$usr_db->set_by_tc($tw_trans_code, $proposal_status);

				$policy_factory = new RSGI_Policy_Factory();
				$policy_resp = $policy_factory->submit_proposal($usr_data->total_premium, $usr_data);
				if($policy_resp->Status->StatusCode == 'S-0005'){
					$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
					$proposal_status['proposal_status'] =  'TS19';
					$proposal_status['trans_status'] =  'TS19';
					$usr_db->set_by_tc($tw_trans_code, $proposal_status);
				}
				return view('tw/policy/no_change_premium', ['nochange_data'=> $nochange_data 	]);
			}else{
				return $this->proposal_n_payment( $tw_trans_code,  $q_update_resp);
			}
			break;
			
		case "premium_mismatch":
			$revised_data = array(
			"tw_trans_code"=>$tw_trans_code,
			"revised_premium"=> round ($q_update_resp->get_revisedpremium()),
			"previous_premium" =>$usr_data->total_premium,
			"insurer_logo" => "rsgi_logo.png"
					);
			return view('tw/policy/premium_missmatch', [ 'revised_data'=> $revised_data ]);
			break;
			
		default:
			//this is proposal errors show error message
			return response()->json( ["resp_flag" => "error_msg", "datav"=>$q_update_resp->get_errormsg() ] , 200);
	}
	
}
	
private function proposal_n_payment( $tw_trans_code,  $q_update_resp){
	//initiate propsoal & get repsonse:
	$factory_ob = new RSGI_Policy_Factory();
	$usr_db = new TwUsrData();
	$insta_lib = new InstaLib();
	$email_engine =  new EmailEngine;
	$usr_data = $usr_db->get_by_tc($tw_trans_code);
	$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
	$proposal_status['proposal_status'] =  'TS20';
	$proposal_status['trans_status'] =  'TS20';
	$usr_db->set_by_tc($tw_trans_code, $proposal_status);
	$email_engine->send_email($tw_trans_code);
	$proposal_resp = $factory_ob->submit_proposal( $tw_trans_code, $usr_data, $q_update_resp);
	if($proposal_resp->Status->StatusCode == 'S-0005'){
		$proposal_status['proposal_date'] = $insta_lib->today_date_dMY();
		$proposal_status['proposal_status'] =  'TS21';
		$proposal_status['trans_status'] =  'TS21';
		$usr_db->set_by_tc($tw_trans_code, $proposal_status);
	}
	return $this->payment_form_data($usr_data);
	
}	// end of method. 
	

private function payment_form_data ($usr_data) {
	$usr_db = new TwUsrData();
	$payment_parse_be = new PaymentParseBE;
	$tw_trans_code= $usr_data->trans_code;
	$usr_data = $usr_db->get_by_tc($tw_trans_code);
	
	$insta_lib = new InstaLib();
	$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
	$proposal_status['payment_status'] = 'TS16';
	$proposal_status['trans_status'] =  'TS16';
	$usr_db->set_by_tc($tw_trans_code, $proposal_status);

	//create payment object and redirect.
	$pay_form_data = array();
	
	$pay_form_data["reqType"] = "JSON";
	$pay_form_data["process"] = "paymentOption";
	$pay_form_data["apikey"] = "310ZQmv/bYJMYrWQ1iYa7s43084=";
	$pay_form_data["agentId"] = "BA503014";
	$pay_form_data["premium"] = $usr_data->final_premium .".0";
	$pay_form_data["quoteId"] =  $usr_data->temp_col_1;
	$pay_form_data["version_no"] =  "";
	$pay_form_data["strFirstName"] = explode(" ", $usr_data->proposer_name )[0]; 
	$pay_form_data["strEmail"] = $usr_data->proposer_email;
	$pay_form_data["isQuickRenew"] = "";
	$pay_form_data["crossSellProduct"] = "";
	$pay_form_data["crossSellQuoteid"] = "";
	$pay_form_data["returnUrl"] = url('/') ."/two-wheeler-insurance/rsgi/payment/status";
	$pay_form_data["vehicleSubLine"] = "TwoWheeler";
	$pay_form_data["elc_value"] = "";
	$pay_form_data["nonelc_value"] = "";
	$pay_form_data["paymentType"] = "billDesk";
	$pay_form_data["payurl"] = Tw_Constants::RSGI_PAYMENT_URL;
	$payment_parse_be->setPaymentIdentifier($tw_trans_code,$usr_data->temp_col_1);
	return $pay_form_data;
}


public function payment_status (Request $request)  {  
		$insta_lib = new InstaLib();
		$email_engine =  new EmailEngine;
		Log::info( "TW RSGI Payment Response" . print_r($request->all(),true));
		$pay_resp = $request->all();
		$pay_resp_arr = explode("|", $pay_resp['BDresmsg']);

		// $trans_status = 0 ;  // false.
		$usr_db = new TwUsrData(); 
		$twlib_db = new TwLib();

		$payment_parse_be = new PaymentParseBE;
		$tw_trans_code = $payment_parse_be->getPaymentIdentifier($pay_resp['quoteId']);
		
		// $tw_trans_code=	$this->get_suid();
		$policy_no = ""; 
		$proposal_no = "";
		$trans_msg = "";
		
		
		if(isset($pay_resp['policyNO'])) {
			// $trans_status = 1;
			$policy_no = $pay_resp['policyNO'];
			$proposal_no = $pay_resp_arr[2];

			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS17';
			$proposal_status['policy_status'] = 'TS19';
			$proposal_status[Tw_Constants::TRANS_CODE] = $tw_trans_code ."_DONE";
			$proposal_status['trans_status'] = $proposal_status['policy_status'];
			$proposal_status[Tw_Constants::PR_NUMBER] = $proposal_no;
			$proposal_status[Tw_Constants::POLICY_NUMBER] = $policy_no;

			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
			
			$usr_data = $usr_db->get_by_sc($tw_trans_code);
			$insurer_data = new InsurerData;
			$request_array = array(
								"module_name"=> "TW",
								"insurer_code"=> $insurer_data->insurer_data("isu_desc",$usr_data->insurer_code),
								"agent_code"=> !empty($usr_data->agent_code)?$usr_data->agent_code:null,
								"policy_date"=> $usr_data->policy_date,
								"policy_type"=> $usr_data->policy_type,
								"policy_nature"=> "Rollover",
								"policy_number"=> $usr_data->policy_number,
								"od_premium"=> $usr_data->od_premium,
								"tp_premium"=> $usr_data->tp_premium,
								"total_premium"=> $usr_data->total_premium,
								"tax"=> $usr_data->total_tax,
								"final_premium"=> $usr_data->final_premium
								);
			$policy_counter = new PolicyCounterService;
			$result = $policy_counter->service_handler($request_array);
			\Log::info($usr_data->trans_code.' Policy Counter Status : '.$result);

		}else {
			$policy_no = "";
			$proposal_no = $pay_resp_arr[2];
			$trans_msg = $pay_resp_arr[24];

			$proposal_status['payment_date'] = $insta_lib->today_date_dMY();
			$proposal_status['payment_status'] = 'TS02';
			$proposal_status['payment_desc'] = $trans_msg;
			$proposal_status['trans_status'] = $proposal_status['payment_status'];
			$usr_db->set_by_tc($tw_trans_code, $proposal_status);
			$email_engine->send_email($tw_trans_code);
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::TRANS_STATUS => Common_Constants::TS_PAYMENT_FAIL,
					Tw_Constants::PR_NUMBER=> $proposal_no,
					Tw_Constants::POLICY_NUMBER=> $policy_no
			));
		}
		

		if($policy_no != ''){
			$ssn_key =	$tw_trans_code ;
			$policy_db = new TwPolicyData();
			$policy_db->set_record($ssn_key);
		}
		
		$trans_resp = array (
				"trans_status" =>$proposal_status['trans_status'],
				"policy_number" => $policy_no,
				"trans_msg" => $trans_msg,
				"proposal_number" => $proposal_no,
				"insurer_logo" => "rsgi_logo.png"
		);
		
		return view('tw.policy.rsgi.payment_status', [ 'trans_resp' =>$trans_resp] );
		
	} // end of method.
	
	public function submit_payment (Request $request) {
		$tw_trans_code = $request->input("tw_trans_code");
		$usr_db = new TwUsrData();
		return $this->payment_form_data($usr_db->get_by_tc($tw_trans_code));
		
	}
	
	public function pm_submit_payment (Request $request) {
		
		// 1. get new values. 
		$agreed_premium= $request->input('agreed_premium');
		// 2. update them to db .  - at present no update to db.
		
		$proposal_ob = new RSGI_Policy_Factory();
		$usr_db = new TwUsrData();
		$tw_trans_code= $request->input('tw_trans_code');
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		//3. submit proposal once again. and ensure premium is done.
		$q_update_resp= $proposal_ob->update_quote($usr_data, $agreed_premium);
		
		return $this->quote_update_resp_exe("2", $tw_trans_code, $usr_data, $q_update_resp);
		
	} // method end. 
	
	private function proposal_errors($proposal_data) {
		$status = false; $msg = "";
		
		if($proposal_data->pre_policy_type != null && $proposal_data->pre_policy_type =="L"){
			$status = true;
			$msg = "Since your privious policy was Legal Liability type. You need offline assistance to issue this policy. ";
		}
		
		return array ( "status" => $status, "msg"=> $msg );
	}
	
	private  function get_suid() {
		return session('tw_transcode');
	}
	
	
}// end of class

