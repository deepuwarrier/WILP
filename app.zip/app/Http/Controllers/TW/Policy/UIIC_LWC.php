<?php
namespace App\Http\Controllers\TW\Policy;

use App\Http\Controllers\Controller;

use App\Constants\Common_Constants;
use App\Constants\Tw_Constants;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\UnitedIndia\UIICProposal;
use App\Libraries\TwLib;
use App\Models\TW\data\PolicyPageData;
use App\Models\TW\TwNomRel;
use App\Models\TW\TwPreInsurers;
use App\Models\TW\TwStates;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Be\TW\TwPolicyBe;
use App\Models\TW\TwCovers;
use App\Models\TW\TwPolicyData;
use App\Models\TW\data\PolicyPDFData;
use App\Helpers\Email\EmailFactory;
use App\Helpers\Email\EmailData;


class UIIC extends Controller
{

	public function __construct()
	{
	}
	
	public function load_policy_page($tw_trans_code)
	{
		
		$usr_db = new TwUsrData();
		$d_preview = $usr_db->details_preview($tw_trans_code);
		$q_preview = $usr_db->quote_preview($tw_trans_code); 
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		session(['tw_transcode' => $tw_trans_code]);
		
		$policy_page_data = new PolicyPageData();
		
		$state_db = new TwStates(); 
		$policy_page_data->_state_list($state_db->state_list_by_code($usr_data->state_code));
		$policy_page_data->_rto_code($d_preview['rto_code']);
		
		$yom_list =  array ( $d_preview['yor'], $d_preview['yor']-1);
		$policy_page_data->_yom_list($yom_list);
		
		$nomrel_db = new TwNomRel();
		$policy_page_data->_nom_rel_list( $nomrel_db->insr_nom_rel_list( Tw_Constants::UIIC_COLUMN_NAME) );
		
		$preinsr_db = new TwPreInsurers();
		$policy_page_data->_pre_insurer_list( $preinsr_db->insr_preinsur_list(Tw_Constants::UIIC_COLUMN_NAME) );
		
		$policy_be = new TwPolicyBe();
		$quote_resp=  $policy_be->parse_proposal_pipb($usr_data);
		$cover_db = new TwCovers();
		
		return view('tw/policy/unitedindia/proposal_home' , [
				'tw_trans_code' => $tw_trans_code,
				'd_preview' =>$d_preview,
				'q_preview' => $q_preview,
				'base_data' => $policy_page_data,
				'quote' => $quote_resp,
				'cover_list' => $cover_db->_list()
		]);
		
	}
	
	public function submit_proposal (Request $request)  {  

		// fetch details from db . pass to proposal validation
		$usr_db = new TwUsrData();
		$uiic_proposal = new UIICProposal();
		$tw_trans_code = $request->input('tw_trans_code');
		
		
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		$proposal_errors = $uiic_proposal->validate_proposal_submit( $usr_data);
		
// 		// Proposal Submit Email Implementation
 		$efob = new EmailFactory();
		$email_data = new EmailData();
		$email_data->set_event_name("PROPOSALSUBMIT");
		$email_data->set_insurer("UIIC");
		$email_data->set_module_name("TW");
		$email_data->set_to_mail_id($usr_data->proposer_email);
		$email_data->set_content_arr($usr_data);
		$efob->execute_email($email_data);

		
		
// 		if( $proposal_errors != null ) {
// 			//return with proposal errors
// 			return response()->json([
// 				 $proposal_errors
// 			], 404);
// // 			return response()->json($proposal_errors);
// 		}
		
		$premium_revised = 0;
		$premium_revised= $uiic_proposal->validate_premium_submit($usr_data);
		if( $premium_revised !=  $usr_data->total_premium) {
			//return with premium mismatch and confirmation request by user.
			$revised_data = array(
					"tw_trans_code"=>$tw_trans_code, 
					"revised_premium"=>$premium_revised, 
					"previous_premium" =>$usr_data->total_premium,
					"insurer_logo" => "uiicgi_logo.png"
			);
			return view('tw/policy/premium_missmatch', [ 'revised_data'=> $revised_data ]);
		} 
		
		// case where no change in premium propose for payment. than update final premium to usr_data
		
		$usr_db->set_by_tc($tw_trans_code, array(
				Tw_Constants::FINAL_PREMIUM=> $usr_data->total_premium
				));
		
		$nochange_data = array(
				"tw_trans_code"=>$tw_trans_code,
				"final_premium" =>$usr_data->total_premium,
				"insurer_logo" => "uiicgi_logo.png"
		);
		return view('tw/policy/no_change_premium', [ 'nochange_data'=> $nochange_data ]);
		
	}
	
	public function submit_payment(Request $request) {
		
		$usr_db = new TwUsrData();
		$uiic_proposal = new UIICProposal();
		$tw_lib = new TwLib();
		$tw_trans_code = $request->input('tw_trans_code');
		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		$premium_revised = 0;
		$premium_revised= $uiic_proposal->validate_premium_submit($usr_data);
		if( $premium_revised !=  $usr_data->total_premium) {
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::FINAL_PREMIUM=> $premium_revised
			));
		}
		
// Production
		$pay_req_url = "UIIINSTINS|". $tw_trans_code ."|NA|". $premium_revised .".00|NA|NA|NA|INR|NA|R|uiiinstins|NA|NA|F|TW|PRD|NA|NA|NA|NA|NA|https://www.instainsure.com/two-wheeler-insurance/uiic/payment/status";
//UAT
//        $pay_req_url = "UIIINSTINS|". $tw_lib->get_militime() ."|NA|1.00|NA|NA|NA|INR|NA|R|uiiinstins|NA|NA|F|TW|UAT|NA|NA|NA|NA|NA|https://www.instainsure.com/two-wheeler-insurance/uiic/payment/status";

		$pay_req_url_hs =  $pay_req_url."|".$this->payment_hash($pay_req_url);
		Log::info("TW UIIC Payment Request: " . $pay_req_url_hs);
		return response()->json($pay_req_url_hs);
		
	} 
	
	private function payment_hash($str){ 
		
	$hash_txt =  hash_hmac('sha256', $str, 'Sf5dEqfQPlEJ');  
	return strtoupper($hash_txt);
	
	}
	
	public function payment_response( Request $request) {
		
		Log::info("TW UIIC Payment Response : ". $request->input("msg"));
		$tw_lib = new TwLib();
		$usr_db = new TwUsrData();
		$tw_trans_code = $this->get_twtc();
		
		$pgresp_raw = $request->input("msg");
		$pgresp = $this->parse_pgresp( $pgresp_raw );
		
		if( $pgresp["AuthStatus"] == "0300" ) {
			// if success than prepare proposal request and send.
			
			$usr_db->set_by_tc($tw_trans_code,  array(
					"pg_refno" => $pgresp["TxnReferenceNo"],
					"trans_status" => Common_Constants::TS_PAYMENT_SUCCESS
			));
			
			$uiic_pro_ob = new UIICProposal();
			$uiic_policy_resp = $uiic_pro_ob->submit_policy( $tw_trans_code, $pgresp );

	Log::info("Post Payment Policy Response " . print_r($uiic_policy_resp, true));		
			if( $uiic_policy_resp !== null) {
				if( $uiic_policy_resp->Message == "APPROVED") {
					// payment sucess and got policy
					
					$usr_db->set_by_tc($tw_trans_code,  array(
							"policy_date" => $tw_lib->date_today("d-M-Y"),
							"policy_number" => $uiic_policy_resp->InsPolicyNo,
							"trans_status" => Common_Constants::TS_COMPLETED,
                                                        Tw_Constants::TRANS_CODE => $tw_trans_code ."_DONE"
					));
// 					$policy_db = new TwPolicyData();
// 					$policy_db->set_record($page_ssn_key);
			
		//	$usr_data= $usr_db->get_by_tc($tw_trans_code);			
			//Policy Successfull Email
 		/*	$efob = new EmailFactory();
 			$email_data = new EmailData();
 			$email_data->set_event_name("POLSU");
 			$email_data->set_insurer("UIIC");
 			$email_data->set_module_name("TW");
 			$email_data->set_to_mail_id($usr_data->proposer_email);
 			$email_data->set_content_arr($usr_data->toArray());
 			$efob->execute_email($email_data);
			*/		
					
					return view('tw.policy.unitedindia.payment_status', [ 'pay_status'=> 'Y', 'pay_resp' =>$uiic_policy_resp->InsPolicyNo] );
				}else {
					$usr_db->set_by_tc($tw_trans_code,  array(
							"trans_status" => Common_Constants::TS_PAYMENT_FAIL
					));
					
					$usr_data= $usr_db->get_by_tc($tw_trans_code);
					//Policy Failed Email
// 					$efob = new EmailFactory();
// 					$email_data = new EmailData();
// 					$email_data->set_event_name("POLFL");
// 					$email_data->set_insurer("UIIC");
// 					$email_data->set_module_name("TW");
// 					$email_data->set_to_mail_id($usr_data->proposer_email);
// 					$email_data->set_content_arr($usr_data->toArray());
// 					$efob->execute_email($email_data);
					
					//payment failed. 
					return view('tw.policy.unitedindia.payment_status', [ 'pay_status'=> 'N', 'pay_resp' =>$uiic_policy_resp] );
				}
			}else {
				
				return view('tw.policy.unitedindia.payment_status', [ 'pay_status'=> 'N', 'pay_resp' =>""] );
			}
		}else {
			$usr_data= $usr_db->get_by_tc($tw_trans_code);
			//Policy Failed Email
 			$efob = new EmailFactory();
 			$email_data = new EmailData();
 			$email_data->set_event_name("PYMTF");
 			$email_data->set_insurer("UIIC");
 			$email_data->set_module_name("TW");
 			$email_data->set_to_mail_id($usr_data->proposer_email);
 			$email_data->set_content_arr($usr_data->toArray());
 			$efob->execute_email($email_data);
			// if failed. than go to proposal error page. because payment itself didn't go through. 
			return view('tw.policy.proposal_error_page', [ 'msg'=> "Payment Cancelled by User.", 'TRN' => $pgresp["TxnReferenceNo"]] );
		}
		
	} // end of method
	

	private function parse_pgresp ( $pgstr ) {
		try {
		$pg_resp_arr = explode("|", $pgstr );   
		return array(
				"MerchantID" 			=> $pg_resp_arr[0],
				"CustomerID" 			=> $pg_resp_arr[1],
				"TxnReferenceNo" 	=> $pg_resp_arr[2],
				"BankReferenceNo" => $pg_resp_arr[3],
				"TxnAmount" 			=> $pg_resp_arr[4],
				"BankID" 					=> $pg_resp_arr[5],
				"BankMerchantID" 	=> $pg_resp_arr[6],
				"TxnType" 				=> $pg_resp_arr[7],
				"CurrencyName" 		=> $pg_resp_arr[8],
				"ItemCode" 			=> $pg_resp_arr[9],
				"SecurityType" 		=> $pg_resp_arr[10],
				"SecurityID" 			=> $pg_resp_arr[11],
				"SecurityPassword" 	=> $pg_resp_arr[12],
				"TxnDate" 				=> $pg_resp_arr[13],
				"AuthStatus" 			=> $pg_resp_arr[14],
				"SettlementType" 	=> $pg_resp_arr[15],
				"AdditionalInfo1" 	=> $pg_resp_arr[16],
				"AdditionalInfo2" 	=> $pg_resp_arr[17],
				"AdditionalInfo3" 	=> $pg_resp_arr[18],
				"AdditionalInf o4" 	=> $pg_resp_arr[19],
				"AdditionalInfo5" 	=> $pg_resp_arr[20],
				"AdditionalInfo6" 	=> $pg_resp_arr[21],
				"AdditionalInfo7" 	=> $pg_resp_arr[22],
				"ErrorStatus" 			=> $pg_resp_arr[23],
				"ErrorDescription" 	=> $pg_resp_arr[24],
				"CheckSum" 			=> $pg_resp_arr[25]
		);
		}catch (\Exception $ex){
			return null;
		}
		
	} // end of method

	public function uiic_policy_pdf (Request $request)  {  
		
		$policy_no = $request->input("p");
		
		$usr_db = new TwUsrData();
		$tw_lib = new TwLib();
		$usr_data = $usr_db->values_by_policyno($policy_no);
		
		if($usr_data == null) {
			return "<br> Policy Does Not Exists in Policy Database.";
		}
		$insur_db = new InsurerData();
		
		$usr_data["make_code"] = $insur_db->insr_make("make_name", $usr_data->make_code);
		$usr_data["model_code"] = $insur_db->model_data("model_name", $usr_data->model_code);
		$usr_data["proposer_city_code"] = $insur_db->insr_city("city_name", $usr_data["proposer_city_code"]);
		$usr_data["proposer_state_code"] = $insur_db->insr_state("state_name", $usr_data["proposer_state_code"] );
		$usr_data["final_premium_words"] = $tw_lib->spell_amount( $usr_data["final_premium"]);
		$usr_data["broker_code"] = "BRC0000702";
		$usr_data["rto_location"] = $insur_db->insr_rto("rto", $usr_data->rto_code);
		$usr_data["nomi_age"] = $usr_data->nomi_age; 
		$usr_data["nomi_relation"] =  $insur_db->nomrel_data("nomrel_name", $usr_data->nomi_rel_code);
		
		$cover_value_arr = explode("|", $usr_data->addon_premium);
		
		$usr_data["pa_premium"] = $cover_value_arr[0];
		$usr_data["zdrp_premium"] = $cover_value_arr[1];
	
	 // calculate display values :
		$display_od = $usr_data->od_premium;
		//$display_ncb = round(( $usr_data->od_premium * $usr_data->eli_ncb) / 100);
$display_ncb = $usr_data->ncb_disc_value;
		
		$usr_data["gross_od_value"] = ($display_od + $usr_data->zdrp_premium) - ( $display_ncb +$usr_data->od_disc_value );
		$usr_data["display_ncb"] = $display_ncb;
		$usr_data["papass_value"] = 0;
		$usr_data["gross_tp_value"] = $usr_data->tp_premium + $cover_value_arr[0];
		
		$vechicle_no = $usr_data->tw_reg_no;
 		//dd($usr_data);
	$xpdf = \PDF::loadView('tw.policy.unitedindia.policy_pdf', compact("usr_data"));
	return $xpdf->download("TW_UIIC_". $vechicle_no .".pdf");
		
         } // end
	
private  function get_twtc() {
	return (session()->has('tw_transcode')) ? session('tw_transcode') : session()->getId();
}



// this is offline payment form. not to use for application. will make independent call to pg. 
public function offline_uiic_payform(Request $request) {
	
	$tw_lib = new TwLib();
	//$tw_trans_code = $request->input('tw_trans_code');
	
	
	// Amount to be changed.
	$pay_req_url = "UIIINSTINS|". $tw_lib->get_militime() ."|NA|1798.00|NA|NA|NA|INR|NA|R|uiiinstins|NA|NA|F|TW|PRD|NA|NA|NA|NA|NA|https://www.instainsure.com/two-wheeler-insurance/uiic/payment/log";
	
	$pay_req_url_hs =  $pay_req_url."|".$this->payment_hash($pay_req_url);
	Log::info("TW UIIC Direct Payment Request: " . $pay_req_url_hs);
	return view('tw.policy.unitedindia.offline_uiic_payform', [ 'embstr'=> $pay_req_url_hs ] );
	
} 

public function offline_payment_log( Request $request) {
	
	Log::info("TW UIIC Direct Payment Response : ". $request->input("msg"));
	dd("Process Completed. ");
}

	
} // end of class

