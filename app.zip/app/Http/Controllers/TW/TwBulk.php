<?php
namespace App\Http\Controllers\TW;

use App\Helpers\TW\UnitedIndia\UIIC_Policy_Factory;
use App\Http\Controllers\Controller;
use App\Libraries\TwLib;
use App\Models\TW\BulkTW;
use App\Models\TW\TempTW;
use Illuminate\Http\Request;

class TwBulk extends Controller
{

public function  uiic_bulk_opr (Request $request){ 
		
$db_ob = new BulkTW();

// Start : Create and udpate XML in DB
// 	$list_data = $db_ob->get_list(); 
// 	foreach ($list_data as $data_itr) {  
// 		$xml_str = $this->data_to_xml_str($data_itr->toArray());   
// 		$db_ob->store_data($data_itr->insta_un, array("XML_STR" => $xml_str));
// 		sleep(1);
// 	}
// 	echo "XML data Update to DB completed. ";
// End : Create and Update XmL in DB

// Start : Policy Generation
// 		echo "<br> Policy Generation Begin .... ";
		
// 		$list_data2 = $db_ob->get_list();
// 		foreach ($list_data2 as $data_itr2) {
// 			echo "<br> Proposal Submit for ... " . $data_itr2->insta_un;
// 			$uiic_policy_resp = $this->call_submit_policy( $data_itr2->XML_STR) ; 
// 			sleep(30);
// 			if( $uiic_policy_resp !== null) {
// 				if( $uiic_policy_resp->Message == "APPROVED") {
					
// 					$db_ob->store_data($data_itr2->insta_un,  array(
// 							"api_status"=> "PASS",
// 							"policy_number"=> $uiic_policy_resp->InsPolicyNo
// 					));
// 				}
// 			}
// 		}
// 		echo "<br>  Policy Generation Completed !! ";
// End : Policy Generation. 

// Start : PDF Genration. 

// echo "<br> PDF Genration Started .......";
// $list_data3 = $db_ob->get_list();
// foreach ($list_data3 as $data_itr3) {
// 	$this->genrate_pdf($data_itr3); 
// 	$db_ob->store_data($data_itr3->insta_un,  array(
// 								"exe_flag"=> "N"
// 						));
// 	sleep(1);
// }
// echo "<br> PDF Generation Completed.";

} // end of function. 

private function genrate_pdf($udarr) {
	$usr_data= $this->policy_pdf_data($udarr); 
	$xpdf = \PDF::loadView('tw.policy.unitedindia.temp_policy_pdf', compact("usr_data"));
	 $xpdf->save("TW_UIIC_". $usr_data["vehicle_number"].".pdf");
}

private function data_to_xml_str ( $data_itr ) { 
	
	$exclude_arr = array("created_at", "updated_at", "insta_un", "api_status", "policy_number", "exe_flag", "city_name", "state_name", "XML_STR");
	
	$policy_req_str = "";
	foreach ($data_itr as $xml_key => $xml_value) {
		if(in_array( $xml_key , $exclude_arr, TRUE)){	continue; }
		$policy_req_str = $policy_req_str. "<". $xml_key .">". $xml_value ."</". $xml_key .">";
	}
	return "<ROOT><HEADER>". $policy_req_str . "</HEADER></ROOT>";
}	

private function call_submit_policy($policy_req_str) {
	\Log::info("TW UIIC Policy Request : ". $policy_req_str);
// 	$wsdlurl = "http://portal.uiic.in/uat/UGenericServiceUAT/UInstaService?wsdl";  // this is UAT
			$wsdlurl = "https://portal.uiic.in/uiic/UGenericService/UInstaService?wsdl";      // this is produciton.
	$api_resp = null;
	try {
		$client = new \SoapClient($wsdlurl) ;
		$params = array('application'=>'INSTAINS','userid'=> 'INSTAINS','password'=>'uiic', 'productCode'=>'3112','subproductCode'=> '3','proposalXml'=> $policy_req_str );
		$api_resp = $client->policyInfoOffXml($params);
		
	}catch (Exeception $ex) {	return null;}
	\Log::info("TW_UIIC_Policy_Response : ". print_r( $api_resp->return, true));
	
	if( $api_resp!== null ) {
		return simplexml_load_string($api_resp->return);
	}else {return null;}
	
}

private function policy_pdf_data($udarr) {
// 	dd($udarr);
	$tw_lib = new TwLib();
	
	$reg_number = $udarr->TXT_REGISTRATION_NUMBER_1."".$udarr->TXT_REGISTRATION_NUMBER_2."".$udarr->TXT_REGISTRATION_NUMBER_3."".$udarr->TXT_REGISTRATION_NUMBER_4;
	
	$ret_arr = array(
			"policy_number" => $udarr->policy_number ,
			"vehicle_number" => $reg_number ,
			"policy_start_date"	=> $this->format_std($udarr->DAT_DATE_OF_ISSUE_OF_POLICY),
			"policy_end_date"	=>   $this->format_std($udarr->DAT_DATE_OF_EXPIRY_OF_POLICY),
			"customer_name"	=> $udarr->TXT_NAME_OF_INSURED,
			"customer_addr"	=> $udarr->MEM_ADDRESS_OF_INSURED,
			"customer_city"	=> $udarr->city_name,
			"customer_state"	 => $udarr->state_name,
			"customer_pin"	=> $udarr->NUM_PIN_CODE,
			"customer_email"	=> $udarr->TXT_EMAIL_ADDRESS,
			"customer_phone"	=> $udarr->TXT_MOBILE,
			
			"nomi_name" =>$udarr->TXT_NAME_OF_NOMINEE,
			"nomi_age" => "",
			"nomi_rel" => $udarr->TXT_RELATION_WITH_NOMINEE,
			
			"idv_value"	=> $udarr->NUM_IEV_BASE_VALUE,
			"engine_number"	=> $udarr->TXT_ENGINE_NUMBER,
			"chasis_number"	=> $udarr->TXT_CHASSIS_NUMBER,
			"make_name"	=> $udarr->TXT_NAME_OF_MANUFACTURER,
			"model_name"	=> $udarr->TXT_OTHER_MAKE,
			"body_type" => $udarr->TXT_TYPE_BODY,
			"yom" => $udarr->NUM_YEAR_OF_MANUFACTURE,
			"tw_reg_date" => $udarr->DAT_DATE_OF_REGISTRATION,
			"cc_value" => $udarr->NUM_CUBIC_CAPACITY,
			"rto_loc" => $udarr->TXT_RTA_DESC,
			"premium_words" => $tw_lib->spell_amount(  $udarr->CUR_DEALER_GROSS_PREM ),
			
			"previous_policy_no" => $udarr->NUM_POLICY_NUMBER ,
			"od_value" => $udarr->BasicODPremium ,
			"od_disc_value" => $udarr->ODDiscount,
			
			"tp_value" =>$udarr->BasicTPPremium,
			
			"zero_dept_value" => $udarr->TotalAddOnPremium,
			"paod_value" => "0",
			"paupass_value" => $udarr->PassengerCoverPremium,
			"ncb_value" => $udarr->NOCLAIMBONUSDISCOUNT,
			
			"ncb_rate" => $udarr->CUR_BONUS_MALUS_PERCENT,
			
			"gross_od_value" => $udarr->CUR_DEALER_NET_OD_PREM,
			"gross_tp_value" => $udarr->CUR_DEALER_NET_TP_PREM,
			"gross_final_premium" => ($udarr->CUR_DEALER_NET_OD_PREM +  $udarr->CUR_DEALER_NET_TP_PREM),
			"gst_value" => $udarr->CUR_DEALER_SERVICE_TAX,
			"final_premium" => $udarr->CUR_DEALER_GROSS_PREM,
			
			"pg_ref_number" => $udarr->TXT_UTR_NUMBER,
			"policy_date" => $this->format_std($udarr->DAT_PROPOSAL_DATE),
	);
	
	return $ret_arr;
}	

/* ------------------------------------------------------------------------------------- */


private function uiic_bulkxxx(Request $request){
	
	$facob = new UIIC_Policy_Factory();
	$pno = $request->input("p"); 
	$model_db = new BulkTW();
	$udarr = $model_db->get_data($pno);
	
	$xml_data = $facob->prepare_request($udarr->toArray());
	
	// Print XML 
// 	dd( $xml_data);
	
	
	$usr_data= $this->policy_data($udarr);
	
	
	$xpdf = \PDF::loadView('tw.policy.unitedindia.temp_policy_pdf', compact("usr_data"));
	return $xpdf->stream("TW_UIIC_". $usr_data["policy_number"].".pdf");
	
}	

	


	
	function returnObjectToArray($data){
		if(is_object($data)){
			$data = get_object_vars($data);
		}
		
		if(is_array($data)){
			foreach ($data as $key => $value) {
				if($key == 'ResponseXML'){
					echo "<tr><td>".$key."</td><td>";
					
					$new_data = simplexml_load_string($value);
					$return_xml_to_array = xml2array($new_data);
					echo_array($return_xml_to_array);
				} else {
					echo "<tr><td>".$key."</td><td>".$value."</td></tr>";
				}
			}
		}
		echo "</pre>";
		
	}
	
	function xml2array($xml){
		$arr = array();
		foreach ($xml->children() as $r)
		{
			$t = array();
			if(count($r->children()) == 0)
			{
				$arr[$r->getName()] = strval($r);
			}
			else
			{
				$arr[$r->getName()][] = xml2array($r);
			}
		}
		return $arr;
	}
	
	function echo_array($new_data){
		if(is_object($new_data)){
			if(!is_array($new_data)){
				$new_rephare = ddObjectToArray($new_data);
			}
			echo_array($new_rephare);
		} else {
			foreach ($new_data as $key1 => $value2) {
				if(is_array($value2)){
					echo_array($value2);
				} else {
					echo "<tr><td>".$key1."</td><td>".$value2."</td></tr>";
				}
			}
		}
	
	
} // method end.


public function execute_dbstore(){
	
	$policy_factory = new UIIC_Policy_Factory();
	$policy_arr = $policy_factory->base_request_xmlarr(); 
	
// 	$pol_no = "37230031170160000007";
	
// 	$policy_arr["temp_tw_policy"] = $pol_no;
// 	$this->export_xls("$pol_no", $policy_arr);	
	
// 	dd($pol_no);

	$model_obj = new TempTW();	
	$model_obj->store_data($policy_no, $new_arr);



	dd("done" . time());
	// now populate policy data with user data.
	$populated_policy_arr = $this->populate_policy_request($policy_arr) ;
	
	$policy_req_xml_str = $policy_factory->prepare_request($populated_policy_arr);
	dd( $policy_req_xml_str);
}



	
	
	public function convert_number_to_words($number) {
		
		$hyphen      = '-';
		$conjunction = ' and ';
		$separator   = ', ';
		$negative = 'negative ';
		$decimal = ' point ';
		$dictionary = array (
				0 => 'Zero',
				1 => 'One',
				2 => 'Two',
				3 => 'Three',
				4 => 'Four',
				5 => 'Five',
				6 => 'Six',
				7 => 'Seven',
				8 => 'Eight',
				9 => 'Nine',
				10 => 'Ten',
				11 => 'Eleven',
				12 => 'Twelve',
				13 => 'Thirteen',
				14 => 'Fourteen',
				15 => 'Fifteen',
				16 => 'Sixteen',
				17 => 'Seventeen',
				18 => 'Eighteen',
				19 => 'Nineteen',
				20 => 'Twenty',
				30 => 'Thirty',
				40 => 'Fourty',
				50 => 'Fifty',
				60 => 'Sixty',
				70 => 'Seventy',
				80 => 'Eighty',
				90 => 'Ninety',
				100 => 'Hundred',
				1000                => 'Thousand',
				100000             => 'Lakh'
		);
		
		if (!is_numeric($number)) {
			return false;
		}
		
		if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
			// overflow
			trigger_error(
					'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
					E_USER_WARNING
					);
			return false;
		}
		
		if ($number < 0) {
			return $negative . $this->convert_number_to_words(abs($number));
		}
		
		$string = $fraction = null;
		
		if (strpos($number, '.') !== false) {
			list($number, $fraction) = explode('.', $number);
		}
		
		switch (true) {
			case $number < 21:
				$string = $dictionary[$number];
				break;
			case $number < 100:
				$tens   = ((int) ($number / 10)) * 10;
				$units  = $number % 10;
				$string = $dictionary[$tens];
				if ($units) {
					$string .= $hyphen . $dictionary[$units];
				}
				break;
			case $number < 1000:
				$hundreds  = $number / 100;
				$remainder = $number % 100;
				$string = $dictionary[$hundreds] . ' ' . $dictionary[100];
				if ($remainder) {
					$string .= $conjunction . $this->convert_number_to_words($remainder);
				}
				break;
			default:
				$baseUnit = pow(1000, floor(log($number, 1000)));
				$numBaseUnits = (int) ($number / $baseUnit);
				$remainder = $number % $baseUnit;
				$string = $this->convert_number_to_words($numBaseUnits) . ' ' . $dictionary[$baseUnit];
				if ($remainder) {
					$string .= $remainder < 100 ? $conjunction : $separator;
					$string .= $this->convert_number_to_words($remainder);
				}
				break;
		}
		
		if (null !== $fraction && is_numeric($fraction)) {
			$string .= $decimal;
			$words = array();
			foreach (str_split((string) $fraction) as $number) {
				$words[] = $dictionary[$number];
			}
			$string .= implode(' ', $words);
		}
		
		return $string;
	}


	
	
	
	
	
	
	
	
	private function format_std($dt) {    
		$dt2 = str_replace('/', '-', $dt);
		return date("d-M-Y", strtotime($dt2));
	}
	
} // end of class


