<?php
namespace App\Http\Controllers\TW;

use App\Be\TW\TwDetailsBe;
use App\Constants\Tw_Constants;
use App\Http\Controllers\Controller;
use App\Libraries\TwLib;
use App\Models\TW\TwMakes;
use App\Models\TW\TwModels;
use App\Models\TW\TwStates;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwVariant;
use Illuminate\Http\Request;
use App\Models\PortalPages;
use App\Constants\Common_Constants;
use App\Libraries\InstaLib;
use App\Models\TW\TwRTO;


class TwHome extends Controller
{

	private $data = ['make_code'=>'','model_code'=>'','variant_code'=>'','state_code'=>'','rto_code'=>'','yor'=>''];
	
	public function __construct()
	{
	}
	

// 	public function index_bkp( Request $request)
// 	{
// 		$mode = $request->input("mode");
// 		if($mode == "uat"){
// 			session(['mode' => "uat"]);
// 		}
// 		$portal_pages = new PortalPages();  
// 		return view('tw/tw-home', 
// 				[
// 						'MTxt' => $portal_pages->getMeta(Common_Constants::TWDETAILS),
// 						'twmks' => $this->get_tw_makelist(), 
// 						'yorlst'=>$this->get_tw_yorlist(),
// 						'stlst'=>$this->get_tw_statelist(),						
// 						'selected' => $this->getCurrentSessionValue(),					
// 						'mlist'=>$this->getModel($this->data['make_code']),						
// 						'data_list' => 	$this->getVariant($this->data['model_code'])					
// 				]);
// 	}
	
	public function index( Request $request)
	{
		$mode = $request->input("mode");
		if($mode == "uat"){
			session(['mode' => "uat"]);
		}
		
		$variant_db = new TwVariant();
		$vehicle_data = $variant_db->variant_list();
		
		$rto_db = new TwRTO();
		$rto_data = $rto_db->rto_list();
		
		$portal_pages = new PortalPages();
		return view('tw/tw-home',
				[
						'MTxt' => $portal_pages->getMeta(Common_Constants::TWDETAILS),
						'vehicle_list' => $vehicle_data,
						'rto_list'=> $rto_data,
						'yor_list'=>$this->get_tw_yorlist()
				]);
	}
	

	private function get_tw_makelist(){
		$twMakes = new TwMakes(); return $twMakes->getTwMakes();
	}
	
 
	
	/**
	* Function getting TW Models based on MakeId Passed to it
	* return list of TW Models 
	*/
	protected function getModel($mk_code = null){  			
		$tw_lib = new TwLib();
		$usrdb = new TwUsrData(); 
		$usrdb->setValues($tw_lib->session_key(),  array ( Tw_Constants::MAKE_CODE => $mk_code));
		$twModelOb = new TwModels();   
		$data = $twModelOb->getTwModels($mk_code); 
		return $data;
		
	 }
	 //load model view
	 public function model_list(Request $request){  
		$mk_code= $request->input('makeid');	 
		return view('tw/model-list',
 			[
					'selected' => $this->getCurrentSessionValue(),
 					'mlist' => $this->getModel($mk_code),					
 			]);
	 }
	 
	 protected function getVariant($model_code){  	
		$tw_lib = new TwLib();
		$usrdb = new TwUsrData();
		$usrdb->setValues($tw_lib->session_key(),  array ( Tw_Constants::MODEL_CODE => $model_code));
		$db = new TwVariant();
		return $db->variant($model_code);
	 }
	 
	 public function variant_list(Request $request) {
		$model_code= $request->input('model_id');		  
		return view('tw/variant-list',
				[		
					'selected' => $this->getCurrentSessionValue(),
					'data_list' => 	$this->getVariant($model_code)
				]);
	 }
	 
	 public function variant_store(Request $request) {
		$variant_code= $request->input('variant_id');
		$tw_lib = new TwLib();
		$usrdb = new TwUsrData();
		$vari_db = new TwVariant();
		$vari_data = $vari_db->variant_details($variant_code); 
		
		$data_inp_arr = array (
				Tw_Constants::VARIANT_CODE => $variant_code,
				Tw_Constants::VARIANT_PRICE => $vari_data->variant_price,
				Tw_Constants::VARIANT_BASE_PRICE=> $vari_data->variant_price,
				Tw_Constants::VARIANT_CC => $vari_data->variant_cc
		);
		

		$usrdb->setValues($tw_lib->session_key(), $data_inp_arr);
	 }//end
	 
	 public function state_store(Request $request) {
		$state_code= $request->input('state_id');
		$tw_lib = new TwLib();
		$usrdb = new TwUsrData();
		$usrdb->setValues($tw_lib->session_key(),  array ( Tw_Constants::STATE_CODE => $state_code));
		$state_db = new TwStates();
		return response()->json($state_db->state_to_rto($state_code));
	 }
	 
	 public function rto_store(Request $request) {
		$rto_code= $request->input('rto_code');
		$tw_lib = new TwLib();
		$rto_db = new TwRTO();
		$usrdb = new TwUsrData();
		
		$rto_data = $rto_db->rto_details($rto_code);
		
		$usrdb->setValues($tw_lib->session_key(),  array ( 
				Tw_Constants::RTO_CODE => $rto_code,
				"rto_city_code" => $rto_data->city_code_ref
		));
	 }
	 
// 	 public function yor_store(Request $request) {
// 		$tw_yor= $request->input('tw_yor');
// 		$tw_lib = new TwLib();
//  		$insta_lib = new InstaLib();
// 		
// 		$ssn_key = $tw_lib->session_key();
//  		$trans_code = $insta_lib->get_tw_tc();
// 		
		
// 		$usrdb = new TwUsrData();
// 		$tw_be = new TwDetailsBe();

// 		$usrdb->setValues(  $ssn_key,  array ( 
// 				Tw_Constants::SSN_KEY=>$trans_code , 
// 				Tw_Constants::YOR => $tw_yor, 
// 				Tw_Constants::YOM => $tw_be->calc_yom($tw_yor) ,
// 				Tw_Constants::TRANS_CODE => $trans_code,
// 				Tw_Constants::POLICY_TYPE=> "C",
// 				Tw_Constants::USER_CODE => session("user_agent") != true ? session("user_code") : null,
// 				Tw_Constants::AGENT_CODE => session("user_agent") == true ? session("user_code") : null
// 		));
		
// 		return response()->json($trans_code);
// 	 }
	 
	 public function details_store (Request $request) {
	 	$params= $request->all();
	 	
	 	if($this->validate_selectbox($params)){ 
	 		return redirect('/two-wheeler-insurance');
	 	}
	 	$tw_lib = new TwLib();
	 	$insta_lib = new InstaLib();

	 	$ssn_key = $tw_lib->session_key();
 		$trans_code = $insta_lib->get_tw_tc();
		
	 	$usrdb = new TwUsrData();
	 	
	 	$usrdb->set_transaction($trans_code);
	 	
	 	$tw_be = new TwDetailsBe();
	 	$storable_data = $tw_be->get_storable_details($params);
	 	$storable_data[Tw_Constants::USER_CODE] = session("user_agent") != true ? session("user_code") : null;
	 	$storable_data[Tw_Constants::AGENT_CODE] = session("user_role") == '_AGENT' ? session("user_code") : null;
	 	$storable_data['quote_create_date'] = 	$insta_lib->today_date_dMY();
	 	$storable_data['quote_status'] = 	'TS10';
	 	$storable_data['trans_status'] = 	'TS10';
	 	$usrdb->set_by_tc($trans_code, $storable_data);
	 	
	 	return redirect('/two-wheeler-insurance/quote/'. $trans_code);
	 }
	 
	 
	 private function validate_selectbox($params) {
	 	$is_error = false;
	 	foreach ($params as $key=>$value){
	 		if($value == "-1"){ $is_error = true; }
	 	}
	 	
	 	return $is_error;
	 }
	 
	 
	 private function get_tw_yorlist(){
		$yorlstobj =  new TwDetailsBe(); return $yorlstobj->getYorList();
	 }
	 
	/**
	 * @return unknown
	 */
	public function get_tw_statelist(){
		$stlsobj = new TwStates(); return $stlsobj->getTwStates();
	}
	
	public function getCurrentSessionValue(){		
		$this->setCurrentSessionValue();		
		return $this->data;		
	}		
	//get value for user from current session
	public function setCurrentSessionValue() {								
		$tw_lib = new TwLib();
		$page_ssn_key = $tw_lib->session_key();
		$usr_db = new TwUsrData();
		$usr_data = $usr_db->getValue($page_ssn_key);
			
		if( is_object($usr_data)) {
			foreach($this->data as $code=>$value) {
				$this->data[$code] = isset($usr_data->$code) ? $usr_data->$code : null;
			}
		}		
	}	
}

