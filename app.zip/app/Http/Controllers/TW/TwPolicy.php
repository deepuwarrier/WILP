<?php
namespace App\Http\Controllers\TW;

use App\Constants\Tw_Constants;
use App\Http\Controllers\Controller;
use App\Libraries\TwLib;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use App\Models\TW\TwCities;
use App\Models\TW\TwPincode;
use Illuminate\Support\Facades\Log;

class TwPolicy extends Controller
{

	public function __construct()
	{
	}

	
	public function store_proposal_data (Request $request) {  
		$usr_db = new TwUsrData();
		
		$obj_set_data = array(
				Tw_Constants::OWNER_TYPE => $request->input('owner_type'),
				Tw_Constants::PROPOSER_GENDER => $request->input('gender'),
				Tw_Constants::PROPOSER_DOB => $request->input('cus_dob'),
				Tw_Constants::PROPOSER_NAME => strtoupper($request->input('cust_name')),
				Tw_Constants::PROPOSER_EMAIL => strtoupper($request->input('email_id')),
				Tw_Constants::PROPOSER_MOBILE => $request->input('mobile_no'),
				Tw_Constants::PROPOSER_PANNO => strtoupper($request->input('pan_no')),
				Tw_Constants::PROPOSER_AADHARNO=> $request->input('aadhar_no'),
				Tw_Constants::PROPOSER_OCCUPATION=> $request->input('pro_occu'),
				Tw_Constants::PROPOSER_MARITIALSTATUS=> $request->input('pro_ms'),

				Tw_Constants::REGN_ADDR1 => strtoupper($request->input('regn_addr1')),
				Tw_Constants::REGN_ADDR2 => strtoupper($request->input('regn_addr2')),
				Tw_Constants::REGN_ADDR3 => strtoupper($request->input('regn_addr3')),
				Tw_Constants::REGN_STATE_CODE => strtoupper($request->input('regn_state')),
				Tw_Constants::REGN_CITY_CODE => $request->input('regn_city'),
				Tw_Constants::REGN_PINCODE => $request->input('regn_pincode'),
				Tw_Constants::SAME_COMM_ADDR=> $request->input('commu_addr_chkbx'),
				Tw_Constants::PROPOSER_ADDR1 => strtoupper($request->input('houseno')),
				Tw_Constants::PROPOSER_ADDR2 => strtoupper($request->input('street')),
				Tw_Constants::PROPOSER_ADDR3 => strtoupper($request->input('locality')),
				Tw_Constants::PROPOSER_STATE_CODE=> strtoupper($request->input('state')),
				Tw_Constants::PROPOSER_CITY_CODE=> $request->input('city'),
				Tw_Constants::PROPOSER_PINCODE => $request->input('pincode'),
				
				Tw_Constants::TW_REG_NO => strtoupper($request->input('twregno')),
				Tw_Constants::TW_ENGINE_NO => strtoupper($request->input('eng_no')),
				Tw_Constants::TW_CHASSIS_NO => strtoupper($request->input('chassis_no')),
				Tw_Constants::OWNER_CHANGED => strtoupper($request->input('owner_changed')),
				Tw_Constants::VOLUENTRY_DEDUCTABLES => strtoupper($request->input('voluentry_ded')),
				Tw_Constants::ELE_ACC => $request->input('electrical'),
				Tw_Constants::NON_ELE_ACC => $request->input('non_electrical'),
				Tw_Constants::YOM => $request->input('yom_selected'),
				Tw_Constants::COLOR => strtoupper($request->input('color')),
				Tw_Constants::IS_FINANCED=> strtoupper($request->input('is_financed')),
				Tw_Constants::TYPE_OF_FINANCE=> strtoupper($request->input('type_of_finance')),
				Tw_Constants::FINANCIER_NAME=> strtoupper($request->input('financier_name')),
				Tw_Constants::FINANCIER_ADDRESS=> strtoupper($request->input('financier_address')),
				
				Tw_Constants::PRE_INSURER_CODE=> $request->input('previnsurance'),
				Tw_Constants::PRE_INSURER_ADDR => strtoupper($request->input('pre_insurer_addr')),
				Tw_Constants::PRE_POLICY_NUMBER => strtoupper($request->input('policyno')),
				Tw_Constants::PRE_POLICY_TYPE=> strtoupper($request->input('pre_policy_type')),
				Tw_Constants::PRE_CLAIM_COUNT=> strtoupper($request->input('pre_claim_count')),
				Tw_Constants::PRE_CLAIM_AMOUNT=> strtoupper($request->input('pre_claim_amount')),
				Tw_Constants::NOMI_NAME => strtoupper($request->input('nomineeName')),
				Tw_Constants::NOMI_AGE=> $request->input('nomi_age'),
				Tw_Constants::NOMI_DOB=> $request->input('nomi_dob'),
				Tw_Constants::NOMI_REL_CODE=> $request->input('nomineeRel'),
				Tw_Constants::PRE_ZERODEPT=> $request->input('prevzerodep')
				);
		$usr_db->set_by_tc( $request->input('tw_trans_code'), $obj_set_data);
	}
	
	
	public function retrive_proposal_data( Request $request ) {
		$usr_db = new TwUsrData();
		$usr_data = $usr_db->get_by_tc( $request->input('tw_trans_code') );  
		return $usr_data;
	}
	
	public function city_by_state (Request $request) {
		 $state_code = 	$request->input('state_code');
		 $city_db = new TwCities();
		 return view('tw/policy/city_list', [
		 		'city_list'=> $city_db->city_by_state($state_code)
		 ]);
	} // end of method.

	public function pincode_by_city (Request $request) {
		 $city_code = 	$request->input('city_code');
		 $pincode_db = new TwPincode();
		 return view('tw/policy/pincode_list', [
		 		'pincode_list'=> $pincode_db->pincode_by_city($city_code)
		 ]);
	} // end of method.
	
} // end of class

