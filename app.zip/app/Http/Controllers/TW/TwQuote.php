<?php
namespace App\Http\Controllers\TW;

use App\Be\TW\BajajBe;
use App\Be\TW\FggiBe;
use App\Be\TW\HdfcBe;
use App\Be\TW\ITGIBe;
use App\Be\TW\UiicBe;
use App\Be\TW\RelianceBe;
use App\Be\TW\TwQuoteBe;
use App\Constants\Tw_Constants;
use App\Helpers\TW\Bajaj\BajajQuoteFactory;
use App\Helpers\TW\FGGI\FggiQuoteFactory;
use App\Helpers\TW\HDFC\HDFCQuoteManager;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\ITGI\ITGIQuoteFactory;
use App\Helpers\TW\MHDI\MHDI_Quote_Factory;
use App\Helpers\TW\Reliance\RelianceQuoteFactory;
use App\Helpers\TW\RSGI\RSGI_Quote_Factory;
use App\Helpers\TW\UnitedIndia\UIICQuoteManager;
use App\Http\Controllers\Controller;
use App\Libraries\TwLib;
use App\Libraries\InstaLib;
use App\Models\TW\data\QuoteReqData;
use App\Models\TW\TwCovers;
use App\Models\TW\TwInsurers;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;


class TwQuote extends Controller
{

	public function __construct()
	{
	}

	public function quote_page($trans_code)
	{  
		$usr_db = new TwUsrData();
		if( ! $usr_db->trans_exists($trans_code) ) { 	return redirect('/two-wheeler-insurance');		}
		
		$d_preview = $usr_db->details_preview($trans_code); 
		
		$quote_be = new TwQuoteBe();
		$cover_db = new TwCovers();
		$tw_lib = new TwLib();
		$cover_list = $cover_db->_list();

		$idv_values = $quote_be->idv_sec_values($trans_code); 
		
		$tw_age = $quote_be->tw_vechicle_age($idv_values->r_twrgdt(), $tw_lib->date_adjust_days($idv_values->r_pexdt(), 1));
		
		$calc_pdates = $this->calc_policy_dates( $idv_values->r_pexdt() , null );
		
// 		$revised_price = $this->adjust_price_to_idv (
// 				$idv_values->get_base_idv(),
// 				$idv_values->calc_idv(),
// 				$idv_values->get_variant_base_price()
// 				);
		$usr_db->set_by_tc($trans_code, array(
				Tw_Constants::PRE_POLICY_STATUS=> $idv_values->get_pre_policy_status(),
				Tw_Constants::POLICY_EXP_DATE => $calc_pdates["PED"] ,
				Tw_Constants::POLICY_START_DATE => $calc_pdates["PSD"] ,     //(-)364
				Tw_Constants::TERM_START_DATE => $calc_pdates["TSD"] ,
				Tw_Constants::TERM_END_DATE => $calc_pdates["TED"] ,             // 365
				Tw_Constants::TW_REG_DATE => $idv_values->r_twrgdt(),
				Tw_Constants::TW_AGE => $tw_age,
				Tw_Constants::PRE_CLAIM_STATUS => $idv_values->r_claims() ? "Y": "N",
				Tw_Constants::CURR_NCB => $idv_values->r_crr_ncb(),
				Tw_Constants::ELI_NCB => $idv_values->r_eli_ncb(),
				Tw_Constants::CALC_IDV => $idv_values->calc_idv(),
				Tw_Constants::BASE_IDV=> $idv_values->get_base_idv()
		));
	
		return view('tw/tw-quote', 
				[
						'tw_trans_code' =>$trans_code,
						'cover_list' =>$cover_list,
						'd_preview' =>$d_preview,
						'idv_details' => $idv_values
				]);
	}

	private function adjust_price_to_idv ($base_idv, $revised_div, $variant_price) {
	 $chagne_rate = 	($revised_div * 100) / $base_idv ; 
	 return 	round (($variant_price * $chagne_rate)  / 100);
		
	}
	
	public function update_idvsec_values(Request $request) { 
		
		$tw_trans_code= $request->input('tw_trans_code');
		$policy_expiry_date = $request->input('policy_expiry_date');
		$tw_registration_date  = $request->input('tw_registration_date');
		$claim_status  = $request->input('claim_status');
		$current_ncb  = $request->input('current_ncb');
		$eli_ncb  = $request->input('eli_ncb'); 
		$eli_ncb  = $request->input('eli_ncb'); 
		$expected_idv= $request->input('expected_idv');   
		$pre_policy_status = $request->input('pre_policy_status');   
		
		$quote_be = new TwQuoteBe();
		$tw_lib = new TwLib();
		$usr_db = new TwUsrData();
		$insta_lib = new InstaLib();

		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		
		$revised_price = $this->adjust_price_to_idv (
				$usr_data->base_idv,
				$expected_idv,
				$usr_data->variant_base_price
				);
		
		$tw_age = $quote_be->tw_vechicle_age( $tw_registration_date, $tw_lib->date_adjust_days($policy_expiry_date, 1));
		$revised_idv = $quote_be->tw_vechicle_idv_calc($tw_trans_code, $tw_registration_date, $policy_expiry_date);
		$revised_curr_ncb = $quote_be->tw_curr_ncb($tw_registration_date, $tw_lib->date_adjust_days($policy_expiry_date, 1));
		$revised_ele_ncb = $quote_be->tw_eli_ncb($revised_curr_ncb);

		$calc_pdates = $this->calc_policy_dates( $policy_expiry_date, $pre_policy_status);
		
		$insert_arr = array(
				Tw_Constants::PRE_POLICY_STATUS => $pre_policy_status,
				Tw_Constants::POLICY_EXP_DATE => $calc_pdates["PED"],
				Tw_Constants::POLICY_START_DATE => $calc_pdates["PSD"],
				Tw_Constants::TERM_START_DATE => $calc_pdates["TSD"],
				Tw_Constants::TERM_END_DATE => $calc_pdates["TED"],
				Tw_Constants::TW_REG_DATE => $tw_registration_date,
				Tw_Constants::TW_AGE => $tw_age,
				Tw_Constants::PRE_CLAIM_STATUS => $claim_status,
				Tw_Constants::CURR_NCB => $current_ncb,
				Tw_Constants::ELI_NCB => $eli_ncb,
				Tw_Constants::CALC_IDV => $expected_idv,
				Tw_Constants::VARIANT_PRICE=> $revised_price,
				'quote_update_date'=> $insta_lib->today_date_dMY(),
				'quote_status'=> 'TS11',
				'trans_status'=> 'TS11'
		); 
// 		if($usr_data->tw_age == $tw_age) {
// 			$insert_arr[Tw_Constants::BASE_IDV] =  $revised_idv;
// 		}
		$usr_db->set_by_tc($tw_trans_code, $insert_arr);
		
		return array (
				"revised_idv" => $expected_idv,
				"revised_curr_ncb" => $current_ncb
// 				"revised_ele_ncb" => $revised_ele_ncb 
		);
	}
	
	public function load_itgi_quote(Request $request) {
		
		// Object declaration.
		$itgi_be = new ITGIBe();
		$cover_db = new TwCovers();
		$quote_helper = new ITGIQuoteFactory();
		
		$req_params = $request->all();
		$quote_req_data = $itgi_be->populate_quote_data($req_params);
		if( ! $itgi_be->pre_quote_check($quote_req_data)){ return 0;}
		$itgi_quote_respose = $quote_helper->get_quote($quote_req_data);
		if($itgi_quote_respose== null ) {return 0;}
		$itgi_quote_respose->set_tw_trans_code($req_params["tw_trans_code"]);
		
		if( $itgi_quote_respose->addon_flag() && $itgi_quote_respose->final_premium() != null  ){
			$itgi_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			
			return view('tw/quote/quotebox', [
					'quote'=> $itgi_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	} // end of rsgi quote method	
	
	public function load_fggi_quote(Request $request) {
		
		// Object declaration.
		$fggi_be = new FggiBe();
		$cover_db = new TwCovers();
		$quote_helper = new FggiQuoteFactory();
		
		$req_params = $request->all();
		$quote_req_data = $fggi_be->populate_quote_data($req_params);
		if( ! $fggi_be->pre_quote_check($quote_req_data)){ return 0;}
		$fggi_quote_respose = $quote_helper->get_quote($quote_req_data);
		if($fggi_quote_respose== null ) {return 0;}
		$fggi_quote_respose->set_tw_trans_code($req_params["tw_trans_code"]);
		
		if( $fggi_quote_respose->addon_flag() && $fggi_quote_respose->final_premium() != null  ){
			$fggi_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			
			return view('tw/quote/quotebox', [
					'quote'=> $fggi_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	} // end of rsgi quote method	
	
	public function idv_view_values (Request $request) {

		$tw_quote_be = new TwQuoteBe();
		$req_params = $request->all(); 
		return response()->json($tw_quote_be->idv_view_values(
				$req_params["tw_trans_code"], $req_params["pre_policy_status"],
				$req_params["policy_expiry_date"], $req_params["tw_registration_date"],
				$req_params["claim_status"], $req_params["current_ncb"], 
				$req_params["expected_idv"]
				));
	}
	
	
	public function load_reliance_quote(Request $request) {
		try{
		// Object declaration.
		$tw_quote_be = new TwQuoteBe();
		$reliance_be = new RelianceBe();
		$cover_db = new TwCovers();
		$quote_helper = new RelianceQuoteFactory();
		
		$req_params = $request->all();
		$quote_req_data = $tw_quote_be->populate_quote_data($req_params);
		if( ! $reliance_be->pre_quote_check($quote_req_data)){ return 0;}
		if($quote_req_data->get_add_on_zrdp()){$quote_helper->get_coverage($quote_req_data); }
		$reliance_quote_respose = $quote_helper->get_quote($quote_req_data);
		if($reliance_quote_respose == null ) {return 0;}
		$reliance_quote_respose->set_tw_trans_code($req_params["tw_trans_code"]);
		
		if( $reliance_quote_respose->addon_flag() && $reliance_quote_respose->final_premium() != null  ){
			$reliance_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			
			return view('tw/quote/quotebox', [
					'quote'=> $reliance_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
		}catch(\Exception $ex) {
		    return 0;
		}
	} // end of bajaj quote method	
	
	
	public function load_bajaj_quote(Request $request) { 
		
		// Object declaration.
		$tw_quote_be = new TwQuoteBe();		
		$bajaj_be = new BajajBe();
		$cover_db = new TwCovers();
		$quote_helper = new BajajQuoteFactory(); 
		
		$req_params = $request->all();  
		$quote_req_data = $tw_quote_be->populate_quote_data($req_params); 
		if( ! $bajaj_be->pre_quote_check($quote_req_data)){ return 0;}
		$bajaj_quote_respose = $quote_helper->get_quote($quote_req_data);
		if($bajaj_quote_respose == null ) {return 0;}
		$bajaj_quote_respose->set_tw_trans_code($req_params["tw_trans_code"]);

		if( $bajaj_quote_respose->addon_flag() && $bajaj_quote_respose->final_premium() != null  ){
			$bajaj_quote_respose->gen_round_off();  
			$cover_list = $cover_db->_list();
			
			return view('tw/quote/quotebox', [
					'quote'=> $bajaj_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	} // end of bajaj quote method	
	
	

	public function load_mhdi_quote(Request $request) {
		
		//receive parameters
		$tw_trans_code= $request->input('tw_trans_code');
		$policy_expiry_date = $request->input('policy_expiry_date');
		$tw_registration_date  = $request->input('tw_registration_date');
		$claim_status  = $request->input('claim_status');
		$current_ncb  = $request->input('current_ncb');
		$eli_ncb  = $request->input('eli_ncb');
		$plan_duration= $request->input('plan_duration');
		$addon_selected  = $request->input('addon_selected');
		$pre_policy_status = $request->input('pre_policy_status');   
		
		if( $pre_policy_status !="NEX") {return 0;}
		
		//declare required objects
		$quote_req_data = new QuoteReqData();
		$cover_db = new TwCovers();
		$tw_lib = new TwLib();
		$mhdi_quote = new MHDI_Quote_Factory();
		$usr_db = new TwUsrData();
		
		$calc_pdates = $this->calc_policy_dates( $policy_expiry_date, null );
		
		// set values to request parametes
		$quote_req_data->set_tw_trans_code($tw_trans_code);
		$quote_req_data->set_prepolicy_end_date ( $calc_pdates["PED"] );
		$quote_req_data->set_prepolicy_start_date ( $calc_pdates["PSD"] );// -364
		$quote_req_data->set_policy_start_date ( $calc_pdates["TSD"] );
		$quote_req_data->set_policy_end_date ( $calc_pdates["TED"] );// 365
		$quote_req_data->set_registration_date($tw_registration_date);
		$quote_req_data->set_claim_status($claim_status );
		$quote_req_data->set_current_ncb( $claim_status == "N" ? $current_ncb : 0 );
		$quote_req_data->set_eligible_ncb($claim_status == "N" ? $eli_ncb : 0 );
		$quote_req_data->set_plan_duration($plan_duration);
		$quote_req_data->set_add_on_zrdp( $this->addon_req_parse($addon_selected,"ZRDP") );
		$quote_req_data->set_add_on_cnsm( $this->addon_req_parse($addon_selected,"CNSM"));
		$quote_req_data->set_add_on_ncbp( $this->addon_req_parse($addon_selected,"NCBP"));
		$quote_req_data->set_add_on_rsac( $this->addon_req_parse($addon_selected,"RSAC"));
		$quote_req_data->set_add_on_rtin( $this->addon_req_parse($addon_selected,"RTIN"));
		
		//colllect and set tw details page values specific to mhdi
		$usr_data = $usr_db->get_by_tc($quote_req_data->get_tw_trans_code());
	
		$quote_req_data->set_make_code($usr_data->make_code);
		$quote_req_data->set_variant_code($usr_data->variant_code );
		$quote_req_data->set_model_code($usr_data->model_code);
		$quote_req_data->set_rto_code( $usr_data->rto_code );
		$quote_req_data->set_yor($usr_data->yor);
		$quote_req_data->set_yom($usr_data->yom);
		$quote_req_data->set_desired_idv($usr_data->calc_idv);
		$quote_req_data->set_tw_cc($usr_data->variant_cc);
		$quote_req_data->set_tw_age($usr_data->tw_age);
		
		$rsgi_quote_respose = $mhdi_quote->get_quote($quote_req_data);
		
		if( $rsgi_quote_respose->addon_flag() && $rsgi_quote_respose->final_premium() != null  ){
			$rsgi_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			return view('tw/quote/quotebox', [
					'quote'=> $rsgi_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	} // end of mhdi quote method	
	
	public function load_rsgi_quote(Request $request) {
		
		//receive parameters
		$tw_trans_code= $request->input('tw_trans_code');
		$policy_expiry_date = $request->input('policy_expiry_date');
		$tw_registration_date  = $request->input('tw_registration_date');
		$claim_status  = $request->input('claim_status');
		$current_ncb  = $request->input('current_ncb');
		$eli_ncb  = $request->input('eli_ncb');
		$plan_duration= $request->input('plan_duration');
		$addon_selected  = $request->input('addon_selected');
		$pre_policy_status = $request->input('pre_policy_status');    
		
		if( $pre_policy_status !="NEX") {return 0;}
		
		//declare required objects
		$quote_req_data = new QuoteReqData();
		$cover_db = new TwCovers();
		$mstr_data = new InsurerData();
		$tw_lib = new TwLib();
		$rsgi_quote = new RSGI_Quote_Factory();
		$usr_db = new TwUsrData();
		
		if( ($tw_lib->date_difference( $tw_lib->date_today("d-M-Y"), $tw_registration_date)) > 9) {return 0;}
		
		
		$calc_pdates = $this->calc_policy_dates( $policy_expiry_date, null );
		
		// set values to request parametes
		$quote_req_data->set_tw_trans_code($tw_trans_code);
		$quote_req_data->set_prepolicy_end_date ( $calc_pdates["PED"] );
		$quote_req_data->set_prepolicy_start_date ( $calc_pdates["PSD"] );// -364
		$quote_req_data->set_policy_start_date ( $calc_pdates["TSD"] );
		$quote_req_data->set_policy_end_date ( $calc_pdates["TED"] );// 365
		$quote_req_data->set_registration_date($tw_registration_date);
		$quote_req_data->set_claim_status($claim_status );   
		$quote_req_data->set_current_ncb( $claim_status == "N" ? $current_ncb : 0 );
		$quote_req_data->set_eligible_ncb($claim_status == "N" ? $eli_ncb : 0 );
		$quote_req_data->set_plan_duration($plan_duration);
		$quote_req_data->set_add_on_zrdp( $this->addon_req_parse($addon_selected,"ZRDP") );
		$quote_req_data->set_add_on_cnsm( $this->addon_req_parse($addon_selected,"CNSM"));
		$quote_req_data->set_add_on_ncbp( $this->addon_req_parse($addon_selected,"NCBP"));
		$quote_req_data->set_add_on_rsac( $this->addon_req_parse($addon_selected,"RSAC"));
		$quote_req_data->set_add_on_rtin( $this->addon_req_parse($addon_selected,"RTIN"));
		
		//colllect and set tw details page values specific to rsgi
		$usr_data = $usr_db->get_by_tc($quote_req_data->get_tw_trans_code());
		
		$quote_req_data->set_make_code($usr_data->make_code);
		$quote_req_data->set_model_code($usr_data->model_code);
		$quote_req_data->set_variant_code($usr_data->variant_code );
		$quote_req_data->set_rto_code( $usr_data->rto_code );
		$quote_req_data->set_rto_city_name( $mstr_data->insr_city("rsgi_code", $usr_data->rto_city_code ));
		$quote_req_data->set_yor($usr_data->yor);
		$quote_req_data->set_yom($usr_data->yom);
		$quote_req_data->set_desired_idv($usr_data->calc_idv);
		$quote_req_data->set_tw_cc($usr_data->variant_cc);
		$quote_req_data->set_tw_age($usr_data->tw_age);
		
		$rsgi_quote_respose = $rsgi_quote->get_quote($quote_req_data); 
		
		if($rsgi_quote_respose == null ) {return 0;}
		
		$rsgi_quote_respose->set_tw_trans_code($tw_trans_code);
		
		if( $rsgi_quote_respose->addon_flag() && $rsgi_quote_respose->final_premium() != null  ){
			$rsgi_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			return view('tw/quote/quotebox', [
					'quote'=> $rsgi_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	} // end of rsgi quote method	
	
	public function load_hdfc_quote(Request $request) {  
		$req_params = $request->all();  

		//declare required objects
		$tw_quote_be = new TwQuoteBe();
		$hdfc_be = new HdfcBe();
		$cover_db = new TwCovers();
		$quote_helper = new HDFCQuoteManager();
		
		$quote_req_data = $tw_quote_be->populate_quote_data($req_params);
		if( $hdfc_be->pre_quote_check($quote_req_data)){ return 0;}
		$hdfc_quote_respose = $quote_helper->get_quote($quote_req_data);
		if($hdfc_quote_respose == null ) {return 0;}
		
		if( $quote_req_data->get_pre_policy_status() !="NEX") { 
			$hdfc_quote_respose->set_misc_text("Policy Starts From:" . $quote_req_data->get_policy_start_date() . " - ");
		}
		
		if( $hdfc_quote_respose->addon_flag() && $hdfc_quote_respose->final_premium() != null  ){
		$hdfc_quote_respose->gen_round_off();
		$cover_list = $cover_db->_list();  
		return view('tw/quote/quotebox', [
				'quote'=> $hdfc_quote_respose,
				'cover_list' =>$cover_list
		]);
		}
		return 0;
	} // end of hdfc quote method	
	
	public function load_uiic_quote(Request $request) {
		

		
		$tw_trans_code= $request->input('tw_trans_code');
		$policy_expiry_date = $request->input('policy_expiry_date');
		$tw_registration_date  = $request->input('tw_registration_date');
		$claim_status  = $request->input('claim_status');
		$current_ncb  = $request->input('current_ncb');
		$eli_ncb  = $request->input('eli_ncb'); 
		$plan_duration= $request->input('plan_duration'); 
		$addon_selected  = $request->input('addon_selected'); 
		$pre_policy_status = $request->input('pre_policy_status');   
		
		if( $pre_policy_status !="NEX") {return 0;}
		
		$quote_req_data = new QuoteReqData();
		$usr_db = new TwUsrData();
		$cover_db = new TwCovers();
		$tw_lib = new TwLib();
		$uiic_quote = new UIICQuoteManager();
				$uiic_be = new UiicBe;

		$usr_data = $usr_db->get_by_tc($tw_trans_code);
		$calc_pdates = $this->calc_policy_dates( $policy_expiry_date, null );
		
		$quote_req_data->set_tw_trans_code($tw_trans_code);
		$quote_req_data->set_prepolicy_end_date ( $calc_pdates["PED"] );
		$quote_req_data->set_prepolicy_start_date ( $calc_pdates["PSD"] );// - 364
		$quote_req_data->set_policy_start_date ( $calc_pdates["TSD"] );
		$quote_req_data->set_policy_end_date ( $calc_pdates["TED"] );// 365
		$quote_req_data->set_registration_date($tw_registration_date);
		$quote_req_data->set_claim_status($claim_status);
		$quote_req_data->set_current_ncb( $current_ncb);    
		$quote_req_data->set_eligible_ncb($eli_ncb);
		$quote_req_data->set_plan_duration($plan_duration);
		$quote_req_data->set_add_on_zrdp( $this->addon_req_parse($addon_selected,"ZRDP") );
		$quote_req_data->set_add_on_cnsm( $this->addon_req_parse($addon_selected,"CNSM"));
		$quote_req_data->set_add_on_ncbp( $this->addon_req_parse($addon_selected,"NCBP"));
		$quote_req_data->set_add_on_rsac( $this->addon_req_parse($addon_selected,"RSAC"));
		$quote_req_data->set_add_on_rtin( $this->addon_req_parse($addon_selected,"RTIN"));
		$quote_req_data->set_state_code($usr_data->state_code);
	
	    		$quote_req_data->set_rto_code( $usr_data->rto_code );

		if(!$uiic_be->pre_quote_check($quote_req_data))
			return 0;

	
	
		$uiic_quote_respose = $uiic_quote->get_quotes($quote_req_data);  
		$uiic_quote_respose->set_tw_trans_code($tw_trans_code);
		
		if( $uiic_quote_respose->addon_flag()){
			$uiic_quote_respose->gen_round_off();
			$cover_list = $cover_db->_list();
			return view('tw/quote/quotebox', [
					'quote'=> $uiic_quote_respose,
					'cover_list' =>$cover_list
			]);
		}
		return 0;
	}
	
	
	/** 
	 * This method will be called each time an addons is enabled or disabled by customer. 
	 * Based on that this functional will store updated values to db as string. separated by || symbol.
	 */
	public function store_addon_covers( Request $request) {
		$tw_trans_code = $request->input('tw_trans_code');
		$addon_selected  = $request->input('addon_selected'); 
		$usr_db = new TwUsrData();
		
		if( $addon_selected !== null) {
		$addon_str = "";  
		foreach ( $addon_selected as $addon) {
			$addon_str = $addon_str === "" ? $addon : $addon_str."||".$addon;
		}
		
		$usr_db->set_by_tc($tw_trans_code, array(
				Tw_Constants::ADDON_COVERS => $addon_str
		));
		}else {
			$usr_db->set_by_tc($tw_trans_code, array(
					Tw_Constants::ADDON_COVERS => $addon_selected
			));    
		}
	} // end of method. 
	
	/** 
	 * Based on user selected addon covers, parse true/false while passing request object further. 
	 */
	private function addon_req_parse($addon_arr, $addon_code){
		$respflag = false;
		if( ! $addon_arr == null) {
			if (in_array( $addon_code, $addon_arr)) {
				$respflag = true;
			}
		}
		return $respflag;
	}
	
	public function idv_claims_no(Request $request){
		$tw_trans_code= $request->input('tw_trans_code');
		$usr_db = new TwUsrData();
		return response()->json($usr_db->get_by_tc($tw_trans_code)->curr_ncb);
	}
	
	public function load_proposal_page( Request $request ){
		$tw_trans_code = $request->input('tw_trans_code');
		$quote_unique_id = $request->input('quote_unique_id');
		$insurer_code= $request->input('insurer_code');
		$opted_od = $request->input('opted_od');
		$opted_tp= $request->input('opted_tp');
		$opted_pa= $request->input('opted_pa');
		$opted_oddisc= $request->input('opted_oddisc');
		$opted_ncb= $request->input('opted_ncb');
		$opted_addon= $request->input('opted_addon');
		$opted_gst= $request->input('opted_gst');
		$opted_idv= $request->input('opted_idv');
		$opted_premium= $request->input('opted_premium');
		
		$gross_total_premium = $opted_od + $opted_tp + $opted_pa + $opted_addon - $opted_ncb - $opted_oddisc ;
		
		$usr_db = new TwUsrData();
		$insta_lib = new InstaLib();

		$usr_dt_store = array(
				Tw_Constants::INSURER_CODE => $insurer_code,
				Tw_Constants::OPT_IDV => $opted_idv,
				"od_premium" => $opted_od ,  										// this od is after od discount. 
				"tp_premium" => $opted_tp,
				"addon_premium" => $opted_pa ."|". $opted_addon,
				"od_disc_value" => $opted_oddisc,
				"ncb_disc_value" => $opted_ncb,
				"gross_total_premium" => $gross_total_premium, 
				"total_tax" => $opted_gst,
				Tw_Constants::TOTAL_PREMIUM => $opted_premium,
				"temp_col_1" => $quote_unique_id,
				'quote_update_date'=> $insta_lib->today_date_dMY(),
				'quote_status'=> 'TS12',
				'trans_status'=> 'TS12'
		);
		
		$data = $usr_db->get_by_tc($tw_trans_code);
		if($data->pre_policy_status == 'E90P'){
			$tw_lib = new TwLib();
			$date_today = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
			$plcy_exp_date = "";
			$trm_st_date = $tw_lib->date_adjust_days( $date_today, 3);
			$plcy_st_date = "";
			$trm_ed_date = $tw_lib->date_adjust_days ($tw_lib->dt_adj_yrs( $trm_st_date, +1 ), -1);
			$usr_dt_store['policy_start_date']	=	'';
			$usr_dt_store['policy_exp_date']	=	'';
			$usr_dt_store['term_start_date']	=	$trm_st_date;
			$usr_dt_store['term_end_date']	=	$trm_ed_date;
		}
		if($data->pre_policy_status == 'E90'){
			$tw_lib = new TwLib();
			$date_today = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
			$trm_st_date = $tw_lib->date_adjust_days( $date_today, 3);
			$trm_ed_date = $tw_lib->date_adjust_days ($tw_lib->dt_adj_yrs( $trm_st_date, +1 ), -1);
			$usr_dt_store['term_start_date']	=	$trm_st_date;
			$usr_dt_store['term_end_date']	=	$trm_ed_date;
		}
		unset($data);
		
		$usr_db->set_by_tc($tw_trans_code, $usr_dt_store);
		
		$insurer_db = new TwInsurers();
		$ins_data = $insurer_db->insurer_details($insurer_code);
		$insur_url = $ins_data->isu_url;
		
		if($ins_data->isu_code == "IITW001"){
			$bajaj_ext_url = "https://general.bajajallianz.com/MotorInsurance/onlineportal/motorNew/index.jsp?src=CBM_02642";
			return \Redirect::to($bajaj_ext_url);
		}
               
		return redirect('/two-wheeler-insurance/'.$insur_url.'/'. $tw_trans_code);
		
	}
	
	public function  pex_minmax_dates(Request $request) {
			$be_ob = new TwQuoteBe();
			return response()->json( $be_ob->pex_minmax_dates(null) );
	}
	

	private function calc_policy_dates( $policy_exp_date,  $pre_policy_status) {
		
		if($pre_policy_status == null) {$pre_policy_status = "NEX";}
		
		$tw_lib = new TwLib();
		$date_today = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
		
		$plcy_exp_date = "";
		$trm_st_date = "";
		$plcy_st_date = "";
		$trm_ed_date = "";
		
		switch ($pre_policy_status) {
			case "NEX":
				$plcy_exp_date = $policy_exp_date;
				$trm_st_date = $tw_lib->date_adjust_days( $plcy_exp_date, 1);
				$plcy_st_date = $tw_lib->dt_adj_yrs( $trm_st_date, -1 );
				$trm_ed_date = $tw_lib->dt_adj_yrs( $plcy_exp_date, +1 );
				break;
			case "E90":
				$plcy_exp_date = $policy_exp_date;
				$trm_st_date = $tw_lib->date_adjust_days( $date_today, 3);
				$plcy_st_date = $tw_lib->dt_adj_yrs( $plcy_exp_date, -1 );
				$trm_ed_date = $tw_lib->date_adjust_days ($tw_lib->dt_adj_yrs( $trm_st_date, +1 ), -1);
				break;
			case "E90P":
				$plcy_exp_date = "";
				$trm_st_date = $tw_lib->date_adjust_days( $date_today, 3);
				$plcy_st_date = "";
				$trm_ed_date = $tw_lib->date_adjust_days ($tw_lib->dt_adj_yrs( $trm_st_date, +1 ), -1);
				break;
		}
		
		
		return array (
				"PSD" => $plcy_st_date,
				"PED" => $plcy_exp_date,
				"TSD"  => $trm_st_date,
				"TED"	=> $trm_ed_date
		);    
	
	} // end of method

	public function get_idv_section (Request $request) {

		$tw_quote_be = new TwQuoteBe();
		$req_params = $request->all(); 
		return response()->json($tw_quote_be->get_idv_section($request));
	}
	
	
} // end of class

