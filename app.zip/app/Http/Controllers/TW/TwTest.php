<?php
namespace App\Http\Controllers\TW;

use App\Helpers\Email\EmailData;
use App\Helpers\Email\EmailFactory;
use App\Helpers\TW\Reliance\Reliance_Quote_Request;
use App\Helpers\TW\RSGI\RSGI_Quote_Request;
use App\Http\Controllers\Controller;
use App\Models\CarMMV_M;
use Excel;
use GuzzleHttp\Client;
use SoapClient;
use App\Constants\Travel_Constants;
use App\Helpers\Travel\Tata\TataProposal;

class TwTest extends Controller
{


public function execute(){
    
    dd("ss");
    //dd(session()->all());
    
}


public function execute_xxxxxed(){

$req_str = "<TINS_XML_DATA>
	<Header>
		<ErrorCode>0</ErrorCode>
		<ErrorMessage>OK</ErrorMessage>
		<Version>1.0</Version>
		<SourceId>LTA</SourceId>
		<MessageId>LTA420180416041518</MessageId>
	</Header>
	<Segment>
		<IgnoreFg></IgnoreFg>
		<ErrorCode>0</ErrorCode>
		<ErrorMessage></ErrorMessage>
		<TransactionType>NSell</TransactionType>
		<TransactionId>LTA420180416041518</TransactionId>
		<PolicyIn>
			<GDSCode>LTA</GDSCode>
			<AgencyPCC>050001</AgencyPCC>
			<AgencyCode>93122843</AgencyCode>
			<IATACntryCd>4</IATACntryCd>
			<GDSProductCode>020212</GDSProductCode>
			<InceptionDate>04/16/2018 15:18:52 PM</InceptionDate>
			<ExpirationDate>04/26/2018 11:59:59 PM</ExpirationDate>
			<Agent>G1blrtoyotaxml</Agent>
			<OriginatingCity>INDIA</OriginatingCity>
			<FurthestCity>JAPAN</FurthestCity>
			<UserId>5ad4718497a59</UserId>
			<TransactionApplDate>04/16/2018 15:18:52 PM</TransactionApplDate>
			<Destination>0</Destination>
			<TransactionEffDate>04/16/2018 15:18:52 PM</TransactionEffDate>
			<TransactionExpDate>04/26/2018 11:59:59 PM</TransactionExpDate>
			<UserCd>G1blrtoyotaxml</UserCd>
		</PolicyIn>
		<PolicyOut>
			<ProductDescription>Asia Guard</ProductDescription>
			<TotalPremium>833.00</TotalPremium>
			<TransactionPremAmt>833.00</TransactionPremAmt>
			<CommissionAmt>0.00</CommissionAmt>
			<TotalTaxAmt>127.00</TotalTaxAmt>
			<SurchrgAmt>0.00</SurchrgAmt>
			<SellDateTime>04/16/2018 03:48:55 AM</SellDateTime>
			<CurrencyCode>INR</CurrencyCode>
			<MerchantNo>0</MerchantNo>
			<EMURate></EMURate>
			<DiscountAmt>0.00</DiscountAmt>
			<SystemTimeZone>CST</SystemTimeZone>
			<Agency>
				<AgencyNm>Toyota Tsusho Insurance Broker India Pvt Ltd</AgencyNm>
			</Agency>
			<FeeAmt>0.00</FeeAmt>
			<NetPremiumAmt>833.00</NetPremiumAmt>
		</PolicyOut>
		<Insured>
			<TitleNm>Mr</TitleNm>
			<FirstNm>KALMEGH</FirstNm>
			<LastNm>SURENDRA</LastNm>
			<Relation>SELF</Relation>
			<BirthDt>02/04/1973</BirthDt>
			<InsuredIdNo>5ad4718497a59</InsuredIdNo>
			<PremiumAmt>706.00</PremiumAmt>
			<SurchgeAmt>0.00</SurchgeAmt>
			<GenderCd>0</GenderCd>
			<PlanCode>GOLD</PlanCode>
			<BenefitIn>
				<BenefitCd>01001</BenefitCd>
			</BenefitIn>
			<BenefitOut>
				<BenefitCd>01001</BenefitCd>
				<BenefitFlag>0</BenefitFlag>
				<BenefitDesc>Standard Package</BenefitDesc>
				<PremiumAmt>706.00</PremiumAmt>
				<TransactionPremAmt>706.00</TransactionPremAmt>
				<CommissionAmt>0.00</CommissionAmt>
				<SurchgeAmt>0.00</SurchgeAmt>
				<DiscountAmt>0.00</DiscountAmt>
				<TaxAmt>0.00</TaxAmt>
			</BenefitOut>
			<Address>
				<StreetLn1Nm>E505 CHAITRANGAN SOC,,SUKHSAGAR NAGAR, KATRAJ</StreetLn1Nm>
				<CityNm>PUNE</CityNm>
				<StateNm>MAHARASHTRA</StateNm>
				<ZipCd>411046</ZipCd>
				<HomePhoneNo>9764900097</HomePhoneNo>
				<CellPhoneNo>9764900097</CellPhoneNo>
				<EmailAddr>ARCHANA@TTIBI.CO.IN</EmailAddr>
				<CntryNm>INDIA</CntryNm>
			</Address>
			<IsInsuredFlag>1</IsInsuredFlag>
			<DiscountAmt>0.00</DiscountAmt>
			<CommissionAmt>0.00</CommissionAmt>
			<TransactionPremAmt>706.00</TransactionPremAmt>
			<TaxAmt>0.00</TaxAmt>
			<PlanDesc>Gold</PlanDesc>
		</Insured>
	</Segment>
</TINS_XML_DATA>
";



$helper   = new TataProposal;
          $schedule_response = $helper->schedule_policy($req_str);

dd($schedule_response);


}


public function execute_ssxxx(){     

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_PORT => "91",
  CURLOPT_URL => "http://rzonews.reliancegeneral.co.in:91/API/Service/PremiumCalulationForMotor",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "<PolicyDetails>\n\t<CoverDetails/>\n\t<TrailerDetails/>\n\t<ClientDetails>\n\t\t<ClientType>0</ClientType>\n\t\t<LastName>test</LastName>\n\t\t<MidName>test</MidName>\n\t\t<ForeName>test</ForeName>\n\t\t<OccupationID/>\n\t\t<DOB>1990-01-01</DOB>\n\t\t<Gender>Male</Gender>\n\t\t<PhoneNo/>\n\t\t<MobileNo/>\n\t\t<ClientAddress>\n\t\t\t<CommunicationAddress>\n\t\t\t\t<AddressType>0</AddressType>\n\t\t\t\t<Address1/>\n\t\t\t\t<Address2/>\n\t\t\t\t<Address3/>\n\t\t\t\t<CityID>0</CityID>\n\t\t\t\t<DistrictID/>\n\t\t\t\t<StateID>0</StateID>\n\t\t\t\t<Pincode/>\n\t\t\t\t<Country>1</Country>\n\t\t\t\t<NearestLandmark/>\n\t\t\t</CommunicationAddress>\n\t\t\t<PermanentAddress>\n\t\t\t\t<AddressType>0</AddressType>\n\t\t\t\t<Address1/>\n\t\t\t\t<Address2/>\n\t\t\t\t<Address3/>\n\t\t\t\t<CityID>0</CityID>\n\t\t\t\t<DistrictID/>\n\t\t\t\t<StateID>0</StateID>\n\t\t\t\t<Pincode/>\n\t\t\t\t<Country>1</Country>\n\t\t\t\t<NearestLandmark/>\n\t\t\t</PermanentAddress>\n\t\t\t<RegistrationAddress>\n\t\t\t\t<AddressType>0</AddressType>\n\t\t\t\t<Address1/>\n\t\t\t\t<Address2/>\n\t\t\t\t<Address3/>\n\t\t\t\t<CityID/>\n\t\t\t\t<DistrictID>302</DistrictID>\n\t\t\t\t<StateID>14</StateID>\n\t\t\t\t<Pincode/>\n\t\t\t\t<Country>1</Country>\n\t\t\t\t<NearestLandmark/>\n\t\t\t</RegistrationAddress>\n\t\t</ClientAddress>\n\t\t<EmailID/>\n\t\t<Salutation/>\n\t\t<MaritalStatus>1952</MaritalStatus>\n\t\t<Nationality>1949</Nationality>\n\t</ClientDetails>\n\t<Policy>\n\t\t<BusinessType>5</BusinessType>\n\t\t<Cover_From>2018-02-14</Cover_From>\n\t\t<Cover_To>2019-02-13</Cover_To>\n\t\t<Branch_Code>9202</Branch_Code>\n\t\t<AgentName>Direct</AgentName>\n\t\t<productcode>2312</productcode>\n\t\t<OtherSystemName>1</OtherSystemName>\n\t\t<isMotorQuote>false</isMotorQuote>\n\t\t<isMotorQuoteFlow>false</isMotorQuoteFlow>\n\t</Policy>\n\t<Risk>\n\t\t<VehicleMakeID>201</VehicleMakeID>\n\t\t<VehicleModelID>863</VehicleModelID>\n\t\t<Colour/>\n\t\t<BodyType/>\n\t\t<OtherColour/>\n\t\t<GrossVehicleWeight/>\n\t\t<CubicCapacity>149</CubicCapacity>\n\t\t<RTOLocationID>584</RTOLocationID>\n\t\t<ExShowroomPrice>0</ExShowroomPrice>\n\t\t<IDV>41145</IDV>\n\t\t<DateOfPurchase>2014-02-10</DateOfPurchase>\n\t\t<LicensedCarryingCapacity>2</LicensedCarryingCapacity>\n\t\t<NoOfWheels>2</NoOfWheels>\n\t\t<PurposeOfUsage/>\n\t\t<ManufactureMonth>01</ManufactureMonth>\n\t\t<ManufactureYear>2014</ManufactureYear>\n\t\t<EngineNo/>\n\t\t<Chassis/>\n\t\t<TrailerIDV/>\n\t\t<IsVehicleHypothicated>false</IsVehicleHypothicated>\n\t\t<FinanceType/>\n\t\t<FinancierName/>\n\t\t<FinancierAddress/>\n\t\t<FinancierCity/>\n\t\t<IsRegAddressSameasCommAddress>false</IsRegAddressSameasCommAddress>\n\t\t<IsRegAddressSameasPermanentAddress>false</IsRegAddressSameasPermanentAddress>\n\t\t<IsPermanentAddressSameasCommAddress>true</IsPermanentAddressSameasCommAddress>\n\t\t<SalesManagerCode>Direct</SalesManagerCode>\n\t\t<SalesManagerName>Direct</SalesManagerName>\n\t\t<VehicleVariant>150 DTSi</VehicleVariant>\n\t\t<StateOfRegistrationID>21</StateOfRegistrationID>\n\t\t<BodyIDV>0</BodyIDV>\n\t\t<ChassisIDV>0</ChassisIDV>\n\t\t<Rto_State_City>PUNE</Rto_State_City>\n\t\t<Rto_RegionCode>MAHARASHTRA</Rto_RegionCode>\n\t</Risk>\n\t<Vehicle>\n\t\t<Registration_Number>MH-12-AB-1234</Registration_Number>\n\t\t<RegistrationNumber_New>MH-12-AB-1234</RegistrationNumber_New>\n\t\t<Registration_date>2014-02-10</Registration_date>\n\t\t<RoadTypes>\n\t\t\t<RoadType>\n\t\t\t\t<RoadTypeID/>\n\t\t\t\t<TypeOfRoad/>\n\t\t\t</RoadType>\n\t\t</RoadTypes>\n\t\t<Permit>\n\t\t\t<PermitType>\n\t\t\t\t<TypeOfPermit/>\n\t\t\t</PermitType>\n\t\t</Permit>\n\t\t<SeatingCapacity>2</SeatingCapacity>\n\t\t<MiscTypeOfVehicle/>\n\t\t<TypeOfFuel>1</TypeOfFuel>\n\t\t<MiscTypeOfVehicleID/>\n\t\t<ISNewVehicle>false</ISNewVehicle>\n\t</Vehicle>\n\t<Cover>\n\t\t<PACoverToNamedPassengerSI>0</PACoverToNamedPassengerSI>\n\t\t<IsPAToUnnamedPassengerCovered>false</IsPAToUnnamedPassengerCovered>\n\t\t<NoOfUnnamedPassenegersCovered>2</NoOfUnnamedPassenegersCovered>\n\t\t<UnnamedPassengersSI>0</UnnamedPassengersSI>\n\t\t<IsRacingCovered>false</IsRacingCovered>\n\t\t<IsLossOfAccessoriesCovered>false</IsLossOfAccessoriesCovered>\n\t\t<IsVoluntaryDeductableOpted>false</IsVoluntaryDeductableOpted>\n\t\t<VoluntaryDeductableAmount>0</VoluntaryDeductableAmount>\n\t\t<IsElectricalItemFitted>false</IsElectricalItemFitted>\n\t\t<ElectricalItemsTotalSI>0</ElectricalItemsTotalSI>\n\t\t<IsNonElectricalItemFitted>false</IsNonElectricalItemFitted>\n\t\t<NonElectricalItemsTotalSI>0</NonElectricalItemsTotalSI>\n\t\t<IsGeographicalAreaExtended>false</IsGeographicalAreaExtended>\n\t\t<IsBiFuelKit>false</IsBiFuelKit>\n\t\t<BiFuelKitSi>0</BiFuelKitSi>\n\t\t<IsAutomobileAssociationMember>False</IsAutomobileAssociationMember>\n\t\t<IsVehicleMadeInIndia>false</IsVehicleMadeInIndia>\n\t\t<IsUsedForDrivingTuition>false</IsUsedForDrivingTuition>\n\t\t<IsInsuredAnIndividual>true</IsInsuredAnIndividual>\n\t\t<IsIndividualAlreadyInsured>false</IsIndividualAlreadyInsured>\n\t\t<IsPAToOwnerDriverCoverd>true</IsPAToOwnerDriverCoverd>\n\t\t<ISLegalLiabilityToDefenceOfficialDriverCovered>false</ISLegalLiabilityToDefenceOfficialDriverCovered>\n\t\t<IsLiabilityToPaidDriverCovered>False</IsLiabilityToPaidDriverCovered>\n\t\t<IsLiabilityToEmployeeCovered>false</IsLiabilityToEmployeeCovered>\n\t\t<IsPAToDriverCovered>False</IsPAToDriverCovered>\n\t\t<IsPAToPaidCleanerCovered>false</IsPAToPaidCleanerCovered>\n\t\t<IsAdditionalTowingCover>false</IsAdditionalTowingCover>\n\t\t<IsLegalLiabilityToCleanerCovered>false</IsLegalLiabilityToCleanerCovered>\n\t\t<IsLegalLiabilityToNonFarePayingPassengersCovered>false</IsLegalLiabilityToNonFarePayingPassengersCovered>\n\t\t<IsLegalLiabilityToCoolieCovered>false</IsLegalLiabilityToCoolieCovered>\n\t\t<IsCoveredForDamagedPortion>false</IsCoveredForDamagedPortion>\n\t\t<IsImportedVehicle>false</IsImportedVehicle>\n\t\t<IsFibreGlassFuelTankFitted>false</IsFibreGlassFuelTankFitted>\n\t\t<IsConfinedToOwnPremisesCovered>false</IsConfinedToOwnPremisesCovered>\n\t\t<IsAntiTheftDeviceFitted>False</IsAntiTheftDeviceFitted>\n\t\t<IsTPPDLiabilityRestricted>false</IsTPPDLiabilityRestricted>\n\t\t<IsTPPDCover>true</IsTPPDCover>\n\t\t<IsBasicODCoverage>true</IsBasicODCoverage>\n\t\t<IsBasicLiability>true</IsBasicLiability>\n\t\t<IsUseOfVehiclesConfined>false</IsUseOfVehiclesConfined>\n\t\t<IsTotalCover/>\n\t\t<IsRegistrationCover>false</IsRegistrationCover>\n\t\t<IsRoadTaxcover>false</IsRoadTaxcover>\n\t\t<IsInsurancePremium>false</IsInsurancePremium>\n\t\t<IsCoverageoFTyreBumps>false</IsCoverageoFTyreBumps>\n\t\t<IsImportedVehicleCover>false</IsImportedVehicleCover>\n\t\t<IsVehicleDesignedAsCV>false</IsVehicleDesignedAsCV>\n\t\t<IsWorkmenCompensationExcludingDriver>false</IsWorkmenCompensationExcludingDriver>\n\t\t<IsLiabilityForAccidentsInclude>false</IsLiabilityForAccidentsInclude>\n\t\t<IsLiabilityForAccidentsExclude>false</IsLiabilityForAccidentsExclude>\n\t\t<IsLiabilitytoCoolie>false</IsLiabilitytoCoolie>\n\t\t<IsLiabilitytoCleaner>false</IsLiabilitytoCleaner>\n\t\t<IsLiabilityToConductor>false</IsLiabilityToConductor>\n\t\t<IsPAToConductorCovered>false</IsPAToConductorCovered>\n\t\t<IsNFPPIncludingEmployees>false</IsNFPPIncludingEmployees>\n\t\t<IsNFPPExcludingEmployees>false</IsNFPPExcludingEmployees>\n\t\t<IsNCBRetention>false</IsNCBRetention>\n\t\t<IsHandicappedDiscount>false</IsHandicappedDiscount>\n\t\t<IsTrailerAttached>false</IsTrailerAttached>\n\t\t<cAdditionalCompulsoryExcess>0</cAdditionalCompulsoryExcess>\n\t\t<iNumberOfLegalLiabilityCoveredPaidDrivers>0</iNumberOfLegalLiabilityCoveredPaidDrivers>\n\t\t<NoOfLiabilityCoveredEmployees>0</NoOfLiabilityCoveredEmployees>\n\t\t<PAToDriverSI>0</PAToDriverSI>\n\t\t<PAToCleanerSI>0</PAToCleanerSI>\n\t\t<NumberOfPACoveredPaidDrivers>0</NumberOfPACoveredPaidDrivers>\n\t\t<NoOfPAtoPaidCleanerCovered>0</NoOfPAtoPaidCleanerCovered>\n\t\t<AdditionalTowingCharge>0</AdditionalTowingCharge>\n\t\t<NoOfLegalLiabilityCoveredCleaners>0</NoOfLegalLiabilityCoveredCleaners>\n\t\t<NoOfLegalLiabilityCoveredNonFarePayingPassengers>0</NoOfLegalLiabilityCoveredNonFarePayingPassengers>\n\t\t<NoOfLegalLiabilityCoveredCoolies>0</NoOfLegalLiabilityCoveredCoolies>\n\t\t<iNoOfLegalLiabilityCoveredPeopleOtherThanPaidDriver>0</iNoOfLegalLiabilityCoveredPeopleOtherThanPaidDriver>\n\t\t<ISLegalLiabilityToConductorCovered>false</ISLegalLiabilityToConductorCovered>\n\t\t<NoOfLegalLiabilityCoveredConductors>0</NoOfLegalLiabilityCoveredConductors>\n\t\t<PAToConductorSI>0</PAToConductorSI>\n\t\t<CompulsoryDeductible>0</CompulsoryDeductible>\n\t\t<PACoverToOwnerDriver>1</PACoverToOwnerDriver>\n\t\t<ElectricItems>\n\t\t\t<ElectricalItems>\n\t\t\t\t<ElectricalItemsID/>\n\t\t\t\t<PolicyId/>\n\t\t\t\t<SerialNo/>\n\t\t\t\t<MakeModel/>\n\t\t\t\t<ElectricPremium>0</ElectricPremium>\n\t\t\t\t<Description/>\n\t\t\t\t<ElectricalAccessorySlNo/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</ElectricalItems>\n\t\t</ElectricItems>\n\t\t<NonElectricItems>\n\t\t\t<NonElectricalItems>\n\t\t\t\t<NonElectricalItemsID/>\n\t\t\t\t<PolicyID/>\n\t\t\t\t<SerialNo/>\n\t\t\t\t<MakeModel/>\n\t\t\t\t<NonElectricPremium>0</NonElectricPremium>\n\t\t\t\t<Description/>\n\t\t\t\t<Category/>\n\t\t\t\t<NonElectricalAccessorySlNo/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</NonElectricalItems>\n\t\t</NonElectricItems>\n\t\t<BasicODCoverage>\n\t\t\t<BasicODCoverage>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</BasicODCoverage>\n\t\t</BasicODCoverage>\n\t\t<GeographicalExtension>\n\t\t\t<GeographicalExtension>\n\t\t\t\t<Countries/>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t</GeographicalExtension>\n\t\t</GeographicalExtension>\n\t\t<BifuelKit>\n\t\t\t<BifuelKit>\n\t\t\t\t<ISLpgCng>false</ISLpgCng>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</BifuelKit>\n\t\t</BifuelKit>\n\t\t<DrivingTuitionCoverage>\n\t\t\t<DrivingTuitionCoverage>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</DrivingTuitionCoverage>\n\t\t</DrivingTuitionCoverage>\n\t\t<FibreGlassFuelTank>\n\t\t\t<FibreGlassFuelTank>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</FibreGlassFuelTank>\n\t\t</FibreGlassFuelTank>\n\t\t<AdditionalTowingCoverage>\n\t\t\t<AdditionalTowingCoverage>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</AdditionalTowingCoverage>\n\t\t</AdditionalTowingCoverage>\n\t\t<VoluntaryDeductible>\n\t\t\t<VoluntaryDeductible>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</VoluntaryDeductible>\n\t\t</VoluntaryDeductible>\n\t\t<AntiTheftDeviceDiscount>\n\t\t\t<AntiTheftDeviceDiscount>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t\t<PackageName/>\n\t\t\t</AntiTheftDeviceDiscount>\n\t\t</AntiTheftDeviceDiscount>\n\t\t<SpeciallyDesignedforChallengedPerson>\n\t\t\t<SpeciallyDesignedforChallengedPerson>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</SpeciallyDesignedforChallengedPerson>\n\t\t</SpeciallyDesignedforChallengedPerson>\n\t\t<AutomobileAssociationMembershipDiscount>\n\t\t\t<AutomobileAssociationMembershipDiscount>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t\t<PackageName/>\n\t\t\t</AutomobileAssociationMembershipDiscount>\n\t\t</AutomobileAssociationMembershipDiscount>\n\t\t<UseOfVehiclesConfined>\n\t\t\t<UseOfVehiclesConfined>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</UseOfVehiclesConfined>\n\t\t</UseOfVehiclesConfined>\n\t\t<TotalCover>\n\t\t\t<TotalCover>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</TotalCover>\n\t\t</TotalCover>\n\t\t<HelmetCover/>\n\t\t<RegistrationCost>\n\t\t\t<RegistrationCost>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</RegistrationCost>\n\t\t</RegistrationCost>\n\t\t<RoadTax>\n\t\t\t<RoadTax>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t</RoadTax>\n\t\t</RoadTax>\n\t\t<InsurancePremium>\n\t\t\t<InsurancePremium>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</InsurancePremium>\n\t\t</InsurancePremium>\n\t\t<NilDepreciationCoverage>\n\t\t\t<NilDepreciationCoverage>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t\t<ApplicableRate>1</ApplicableRate>\n\t\t\t</NilDepreciationCoverage>\n\t\t</NilDepreciationCoverage>\n\t\t<BasicLiability>\n\t\t\t<BasicLiability>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t</BasicLiability>\n\t\t</BasicLiability>\n\t\t<TPPDCover>\n\t\t\t<TPPDCover>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t\t<SumInsured>720</SumInsured>\n\t\t\t\t<PackageName/>\n\t\t\t</TPPDCover>\n\t\t</TPPDCover>\n\t\t<PACoverToOwner>\n\t\t\t<PACoverToOwner>\n\t\t\t\t<IsChecked>true</IsChecked>\n\t\t\t\t<AppointeeName/>\n\t\t\t\t<NomineeName/>\n\t\t\t\t<NomineeDOB/>\n\t\t\t\t<NomineeRelationship/>\n\t\t\t\t<NomineeAddress/>\n\t\t\t\t<OtherRelation/>\n\t\t\t</PACoverToOwner>\n\t\t</PACoverToOwner>\n\t\t<PAToNamedPassenger>\n\t\t\t<PAToNamedPassenger>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<SumInsured/>\n\t\t\t\t<PassengerName/>\n\t\t\t\t<NomineeName/>\n\t\t\t\t<NomineeDOB/>\n\t\t\t\t<NomineeRelationship/>\n\t\t\t\t<NomineeAddress/>\n\t\t\t\t<OtherRelation/>\n\t\t\t\t<AppointeeName/>\n\t\t\t</PAToNamedPassenger>\n\t\t</PAToNamedPassenger>\n\t\t<PAToUnNamedPassenger>\n\t\t\t<PAToUnNamedPassenger>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t\t<PackageName/>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</PAToUnNamedPassenger>\n\t\t</PAToUnNamedPassenger>\n\t\t<PAToPaidDriver>\n\t\t\t<PAToPaidDriver>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</PAToPaidDriver>\n\t\t</PAToPaidDriver>\n\t\t<PAToPaidCleaner>\n\t\t\t<PAToPaidCleaner>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t\t<SumInsured>0</SumInsured>\n\t\t\t</PAToPaidCleaner>\n\t\t</PAToPaidCleaner>\n\t\t<LiabilityToPaidDriver>\n\t\t\t<LiabilityToPaidDriver>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</LiabilityToPaidDriver>\n\t\t</LiabilityToPaidDriver>\n\t\t<LiabilityToEmployee>\n\t\t\t<LiabilityToEmployee>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<PackageName/>\n\t\t\t\t<PolicyCoverID/>\n\t\t\t</LiabilityToEmployee>\n\t\t</LiabilityToEmployee>\n\t\t<NFPPIncludingEmployees>\n\t\t\t<NFPPIncludingEmployees>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</NFPPIncludingEmployees>\n\t\t</NFPPIncludingEmployees>\n\t\t<NFPPExcludingEmployees>\n\t\t\t<NFPPExcludingEmployees>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</NFPPExcludingEmployees>\n\t\t</NFPPExcludingEmployees>\n\t\t<WorkmenCompensationExcludingDriver>\n\t\t\t<WorkmenCompensationExcludingDriver>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</WorkmenCompensationExcludingDriver>\n\t\t</WorkmenCompensationExcludingDriver>\n\t\t<PAToConductor>\n\t\t\t<PAToConductor>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t\t<SumInsured/>\n\t\t\t</PAToConductor>\n\t\t</PAToConductor>\n\t\t<LiabilityToConductor>\n\t\t\t<LiabilityToConductor>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</LiabilityToConductor>\n\t\t</LiabilityToConductor>\n\t\t<LiabilitytoCoolie>\n\t\t\t<LiabilitytoCoolie>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems>0</NoOfItems>\n\t\t\t</LiabilitytoCoolie>\n\t\t</LiabilitytoCoolie>\n\t\t<LegalLiabilitytoCleaner/>\n\t\t<IndemnityToHirer>\n\t\t\t<IndemnityToHirer>\n\t\t\t\t<IsChecked>false</IsChecked>\n\t\t\t\t<NoOfItems/>\n\t\t\t</IndemnityToHirer>\n\t\t</IndemnityToHirer>\n\t\t<TrailerDetails>\n\t\t\t<TrailerInfo>\n\t\t\t\t<MakeandModel/>\n\t\t\t\t<IDV/>\n\t\t\t\t<Registration_No/>\n\t\t\t\t<ChassisNumber/>\n\t\t\t\t<ManufactureYear/>\n\t\t\t\t<SerialNumber/>\n\t\t\t</TrailerInfo>\n\t\t</TrailerDetails>\n\t\t<BifuelKitLiability/>\n\t\t<BifuelKitTP/>\n\t\t<HiredVehicleDrivenByHirer/>\n\t\t<ODDiscount/>\n\t\t<ODLoading/>\n\t\t<SecurePlus/>\n\t\t<SecurePremium/>\n\t\t<TrailerLiability/>\n\t\t<SideCar/>\n\t\t<SideCarDiscount/>\n\t\t<SideCarLiability/>\n\t\t<GeoExtension/>\n\t\t<CommercialVehicleUsedAsPrivate/>\n\t\t<CommercialVehicleUsedAsPrivateLiability/>\n\t\t<Imt23LampOrTyreTubeOrHeadlight/>\n\t\t<LegalLiabToFarePayingPassenger/>\n\t\t<LiabilityToPersonEmployedForLoadUnloading/>\n\t\t<DrivingTuitionLiabilityCoverage/>\n\t\t<IndemnityToHirerLiability/>\n\t\t<OverTurningCovered/>\n\t\t<ImportedVehicleCover/>\n\t\t<IMT32DefenceOfficialCoverage/>\n\t\t<RelaibilityTrialsAndRallies/>\n\t\t<LossOfAccessoriesCovered/>\n\t\t<IsSpeciallyDesignedForHandicapped>false</IsSpeciallyDesignedForHandicapped>\n\t\t<IsPAToNamedPassenger>false</IsPAToNamedPassenger>\n\t\t<IsOverTurningCovered>false</IsOverTurningCovered>\n\t\t<IsLLToPersonsEmployedInOperations_PaidDriverCovered>false</IsLLToPersonsEmployedInOperations_PaidDriverCovered>\n\t\t<NoOfLLToPersonsEmployedInOperations_PaidDriver>0</NoOfLLToPersonsEmployedInOperations_PaidDriver>\n\t\t<IsLLToPersonsEmployedInOperations_CleanerConductorCoolieCovered>false</IsLLToPersonsEmployedInOperations_CleanerConductorCoolieCovered>\n\t\t<NoOfLLToPersonsEmployedInOperations_CleanerConductorCoolie>0</NoOfLLToPersonsEmployedInOperations_CleanerConductorCoolie>\n\t\t<IsLLUnderWCActForCarriageOfMoreThanSixEmpCovered>false</IsLLUnderWCActForCarriageOfMoreThanSixEmpCovered>\n\t\t<NoOfLLUnderWCAct/>\n\t\t<IsLLToNFPPNotWorkmenUnderWCAct>false</IsLLToNFPPNotWorkmenUnderWCAct>\n\t\t<NoOfLLToNFPPNotWorkmenUnderWCAct>0</NoOfLLToNFPPNotWorkmenUnderWCAct>\n\t\t<IsIndemnityToHirerCovered>false</IsIndemnityToHirerCovered>\n\t\t<IsAccidentToPassengerCovered>false</IsAccidentToPassengerCovered>\n\t\t<NoOfAccidentToPassengerCovered>0</NoOfAccidentToPassengerCovered>\n\t\t<IsNilDepreciation>false</IsNilDepreciation>\n\t\t<IsDetariffRateForOverturning>false</IsDetariffRateForOverturning>\n\t\t<IsAddOnCoverforTowing>false</IsAddOnCoverforTowing>\n\t\t<AddOnCoverTowingCharge>0</AddOnCoverTowingCharge>\n\t\t<EMIprotectionCover/>\n\t</Cover>\n\t<PreviousInsuranceDetails>\n\t\t<PrevInsuranceID/>\n\t\t<IsNCBApplicable>true</IsNCBApplicable>\n\t\t<PrevYearInsurer>United Insurance company Ltd</PrevYearInsurer>\n\t\t<PrevYearPolicyNo/>\n\t\t<PrevYearInsurerAddress/>\n\t\t<PrevYearPolicyStartDate>2017-02-14</PrevYearPolicyStartDate>\n\t\t<MTAReason/>\n\t\t<PrevYearPolicyEndDate>2018-02-13</PrevYearPolicyEndDate>\n\t\t<IsInspectionDone>false</IsInspectionDone>\n\t\t<InspectionDate/>\n\t\t<Inspectionby/>\n\t\t<InspectorName/>\n\t\t<IsNCBEarnedAbroad>false</IsNCBEarnedAbroad>\n\t\t<ODLoading/>\n\t\t<IsClaimedLastYear>false</IsClaimedLastYear>\n\t\t<ODLoadingReason/>\n\t\t<PreRateCharged/>\n\t\t<PreSpecialTermsAndConditions/>\n\t\t<IsTrailerNCB>false</IsTrailerNCB>\n\t\t<InspectionID/>\n\t</PreviousInsuranceDetails>\n\t<ProductCode>2312</ProductCode>\n\t<UserID>100002</UserID>\n\t<NCBEligibility>\n\t\t<NCBEligibilityCriteria>2</NCBEligibilityCriteria>\n\t\t<NCBReservingLetter>wchkReservingLetter</NCBReservingLetter>\n\t\t<PreviousNCB>0</PreviousNCB>\n\t</NCBEligibility>\n\t<LstCoveragePremium/>\n\t<ValidateFlag>false</ValidateFlag>\n\t<SourceSystemID>100002</SourceSystemID>\n\t<AuthToken>Pass@123</AuthToken>\n\t<LstTaxComponentDetails/>\n</PolicyDetails>\n ",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/xml"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}

 }




	
	
	
	
	
} // end of class


