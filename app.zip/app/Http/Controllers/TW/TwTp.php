<?php
namespace App\Http\Controllers\TW;

use App\Be\TW\TwTpBe;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\UnitedIndia\TpPolicy;
use App\Http\Controllers\Controller;
use App\Libraries\InstaLib;
use App\Libraries\TwLib;
use App\Models\TW\TwCities;
use App\Models\TW\TwStates;
use App\Models\TW\TwUsrData;
use App\Models\TW\TwVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\TW\TwPreInsurers;
use App\Constants\Tw_Constants;
use App\Services\Client\PolicyCounterService;
use App\Helpers\Email\EmailEngine;

class TwTp extends Controller {

	private $insurer_column = "uiic_code";
	
    public function __construct() {
        $this->states = new TwStates();
        $this->tpVarient = new TwVariant();
    }

    public function load_tphome(Request $request) {  
    	$req_params = $request->all();
    	
    	if( $req_params == null ) {
    		$def_return = $this->get_def_data_list();
    		return redirect("two-wheeler-insurance/tp?" .$def_return );
    	}
    $tw_lib = new TwLib();
	$city_db = new TwCities();
    	$be_ob = new TwTpBe();
    	$preins_db = new TwPreInsurers();
    	$final_premium = $be_ob->calculate_tp_premium( $req_params );
    	
    	$vechicle_list = $this->tpVarient->variatn_list_by_cc($req_params["cc_value"]);
    	$preins_list = $preins_db->insr_preinsur_list($this->insurer_column); 
     $state_list = $this->states->state_list();
     $city_list = $city_db->city_by_state($req_params["statecode"]);
     $date_today = $tw_lib->date_today(Tw_Constants::DD_MMM_YYYY);
     $def_data = array(
     		"PEX_MIN" => $date_today,
     		"PEX_MAX" => $tw_lib->date_adjust_days($date_today, 15)
     );
     
        return view("tw/tphome", [
        		"vechicle_list"=>$vechicle_list, 
        		"state_list"=>$state_list ,
        		"city_list" =>$city_list,
        		"preins_list" =>$preins_list,
        		"data_list"=> $req_params,
        		"premium"=> $final_premium,
        		"def_data"=> $def_data
        ]);
    }
    
    public function submit_payment (Request $request){
    	$proposal_params = $request->all();      
    	$tp_be = new TwTpBe();
    	$usr_db = new TwUsrData();
    	$tw_lib = new TwLib();
    	$insta_lib = new InstaLib();
      $email_engine =  new EmailEngine;
      // submit hit payment 

    	$usr_trans_code = $insta_lib->get_tw_tc();
    	$proposal_store_data = $tp_be->parse_tp_proposal_data($usr_trans_code, $proposal_params);
    	
      // status log
      $proposal_store_data['proposal_date'] = 
      $proposal_store_data['quote_update_date'] = 
      $proposal_store_data['quote_create_date'] = $insta_lib->today_date_dMY();
      $proposal_store_data['quote_status'] = 'TS12';
      $proposal_store_data['proposal_status'] = 'TS14';
      $proposal_store_data['trans_status'] = 'TS14';
    	
      $usr_db->setValues($usr_trans_code, array("trans_code"=>$usr_trans_code));
    	$usr_db->set_by_tc($usr_trans_code, $proposal_store_data);
    	$email_engine->send_email($usr_trans_code);
    	session(['tw_uiic_tp' =>$usr_trans_code]);
    	
	
 	$bill_desk_pay_url = "https://pgi.billdesk.com/pgidsk/PGIMerchantPayment";	
	



 $pay_request_param = "UIIINSTINS|". $usr_trans_code ."|NA|". $proposal_params["final_premium"].".00|NA|NA|NA|INR|NA|R|uiiinstins|NA|NA|F|TW|PRD|NA|NA|NA|NA|NA|https://www.instainsure.com/two-wheeler-insurance/tp/uiic/payment/status";


   $pay_req_param_hs =  $pay_request_param."|".$this->payment_hash($pay_request_param);
   Log::info("TW UIIC Payment Request: " . $pay_req_param_hs);
   
   $ret_data = array(
   		"payurl"=>$bill_desk_pay_url,
   		"msg" => $pay_req_param_hs
   );
      // proposal success log
      $staus_log['proposal_status'] = 'TS15';
      $staus_log['trans_status'] = 'TS15';
      $usr_db->set_by_tc($usr_trans_code, $staus_log);
   return response()->json($ret_data);
 
    }
    
    
    
   
   // Getting payment response from PG
   public function payment_response (Request $request){
   
   	$payment_resp = $request->input("msg");
   	$insta_lib = new InstaLib();
    $usr_db = new TwUsrData();
    $data_trans_code = session('tw_uiic_tp') ;    
    $email_engine =  new EmailEngine;
      

    Log::info("TW_UIIC_TP_PAYMENT_RESPONSE ". $payment_resp );
   	$payment_resp_arr = $this->parse_pgresp($payment_resp);
   	
    $payment_ref_no = (array_key_exists('TxnReferenceNo',$payment_resp_arr))? $payment_resp_arr['TxnReferenceNo'] : NULL;
    $payment_msg = (array_key_exists('ErrorDescription',$payment_resp_arr))? $payment_resp_arr['ErrorDescription'] : NULL; 

   	if( $payment_resp_arr["AuthStatus"] != "0300" ){ 
   		   // Payment failure.  >> send him to payment failure page. 
        $status_log['payment_date'] = 
        $status_log['policy_date'] = $insta_lib->today_date_dMY();
        $status_log['payment_status'] = 'TS02';
        $status_log['policy_status'] = 'TS03';
        $status_log['payment_desc'] = $payment_msg;
        $status_log['payment_ref_number'] = $payment_ref_no;
        $status_log['trans_status'] =  'TS03';
        
        $usr_db->set_by_tc($data_trans_code, $status_log);
        $email_engine->send_email($data_trans_code);
   		return view('tw.policy.unitedindia.tp_policy_status', [ 'policy_status'=> 'E', 'policy_msg'=> "Payment Cancelled by User.", 'ref_no' => $payment_resp_arr["TxnReferenceNo"]] );
   	}

    // update status log
    $status_log['payment_date'] = 
    $status_log['policy_date'] = $insta_lib->today_date_dMY();
    $status_log['payment_status'] = 'TS17';
    $usr_db->set_by_tc($data_trans_code,$status_log);
    $email_engine->send_email($data_trans_code);
    
    $status_log['policy_status'] = 'TS18';
    $status_log['payment_ref_number'] = $payment_ref_no;
    $status_log['trans_status'] =  'TS18';
   	$usr_db->set_by_tc($data_trans_code,$status_log);

   	$proposal_usr_data = $usr_db->get_by_tc($data_trans_code);
   	
//    	Initiating policy submit 
   		$uiic_pro_ob = new TpPolicy();
   		$uiic_policy_resp = $uiic_pro_ob->submit_policy( $proposal_usr_data, $payment_resp_arr);
   		
   		if( $uiic_policy_resp === null) {
        $status_log['policy_status'] = 'TS03';
        $status_log['trans_status'] =  'TS03';
        $usr_db->set_by_tc($data_trans_code,$status_log);
        $email_engine->send_email($data_trans_code);
   			// policy response recieved null >> go to policy error section. 
   			return view('tw.policy.unitedindia.tp_policy_status', [ 'policy_status'=> 'E', 'policy_msg' =>"Error in Policy Number Generation. If Payment is deducted Dont worry we will send you policy copy."] );
   		}

   		if( $uiic_policy_resp->Message == "APPROVED") {
   				// payment sucess and got policy
        $status_log['policy_status'] = 'TS19';
        $status_log['trans_status'] =  'TS19';
        $usr_db->set_by_tc($data_trans_code,$status_log);
        $email_engine->send_email($data_trans_code);
   			$usr_db->set_by_tc($data_trans_code, array(
   					"pg_refno" => $payment_resp_arr["TxnReferenceNo"],
   					"policy_number" => $uiic_policy_resp->InsPolicyNo,
   					// "ssn_key" => $data_trans_code . "_DONE",
   					"trans_code" => $data_trans_code . "_DONE"
   			));
   			
        // call policy service counter
        try{
          $usr_data = $usr_db->get_by_sc($data_trans_code);      
          $request_array = array(
                    "module_name"=> "TW",
                    "insurer_code"=> $usr_data->insurer_code,
                    "agent_code"=> !empty($usr_data->agent_code)?$usr_data->agent_code:null,
                    "policy_date"=> $usr_data->policy_date,
                    "policy_type"=> $usr_data->policy_type,
                    "policy_nature"=> "Rollover",
                    "policy_number"=> $usr_data->policy_number,
                    "od_premium"=> $usr_data->od_premium,
                    "tp_premium"=> $usr_data->tp_premium,
                    "total_premium"=> $usr_data->total_premium,
                    "tax"=> $usr_data->total_tax,
                    "final_premium"=> $usr_data->final_premium
                    );
          $policy_counter = new PolicyCounterService;
          $result = $policy_counter->service_handler($request_array);
          \Log::info($usr_data->trans_code.' Policy Counter Status : '.$result);
        }catch(\Exception $e){
            
        } finally {
           return view('tw.policy.unitedindia.tp_policy_status', [ 'policy_status'=> 'Y', 'policy_number' =>$uiic_policy_resp->InsPolicyNo] );
        }	
   			}else {
          $status_log['policy_status'] = 'TS03';
          $status_log['trans_status'] =  'TS03';
          $status_log['policy_desc'] =   $uiic_policy_resp->Message;
        $usr_db->set_by_tc($data_trans_code,$status_log);

   				return view('tw.policy.unitedindia.tp_policy_status', [ 'pay_status'=> 'N', 'policy_msg' =>$uiic_policy_resp,'policy_status'=>'E'] );
   			}
   }// end of method. 
   
   
   public function uiictp_policy_pdf(Request $request)  {
   	
   	$policy_no = $request->input("p");  
   	
//    	$policy_db = new TwPolicyData();
	$usr_db = new TwUsrData();
   	$tw_lib = new TwLib();
   	$tpbe = new TwTpBe();
   	$usr_data = $usr_db->values_by_policyno($policy_no);

   	$insur_db = new InsurerData();
   	
   	$usr_data["make_code"] = $insur_db->insr_make("make_name", $usr_data->make_code);
   	$usr_data["model_code"] = $insur_db->model_data("model_name", $usr_data->model_code);
   	$usr_data["proposer_city_code"] = $insur_db->insr_city("city_name", $usr_data["regn_city_code"]);
   	$usr_data["proposer_state_code"] = $insur_db->insr_state("state_name", $usr_data["regn_state_code"] );
   	$usr_data["final_premium_words"] = $tw_lib->spell_amount( $usr_data["final_premium"]);
   	$usr_data["broker_code"] = "BRC0000702";
   	$usr_data["rto_location"] = $insur_db->insr_rto("rto", $usr_data->rto_code);
   	$usr_data["nomi_age"] = "-";
   	$usr_data["nomi_relation"] =  "-";
   	$usr_data["body_type"] =  $insur_db->insr_variant("body_type", $usr_data["variant_code"]);

   	$cover_name_arr = $this->cover_code_to_name(explode("|", $usr_data->addon_covers));
   	
   	$cover_value_arr = explode("|", $usr_data->addon_premium);
   	
   	$usr_data["cover_name_arr"] = $cover_name_arr;
   	$usr_data["cover_value_arr"] = $cover_value_arr;
   	
   	// calculate display values :
   	$display_od = $usr_data->od_premium;
   	$display_ncb = 0;
   	
   	$usr_data["display_od"] = $display_od;
   	$usr_data["display_ncb"] = $display_ncb;
   	
   	$xpdf = \PDF::loadView('tw.policy.unitedindia.policy_tp_pdf', compact("usr_data"));
   	return $xpdf->download("TW_UIIC_TP_". $usr_data->tw_reg_no.".pdf");
   }
   
   private function cover_code_to_name( $cover_value_arr ){ 
   	$ret_arr = array(); $idx = 0;
   	foreach ($cover_value_arr as $cover_code){ 
   		if($cover_code == "PA"){		$ret_arr[$idx] = "PA for Owner Driver";	} 
   		else if($cover_code == "PAPASS"){ 	$ret_arr[$idx] = "PA to Unnamed Passenger";		} 
   		$idx = $idx+1;
   	}
   	return $ret_arr;
   }
   
    public function get_cities(Request $request){
        if (isset($request->state) && $request->state != '') {
            $data = $this->cities->city_by_state($request->state);
            $html = '<option value="">Select City</option>';
            foreach ($data as $value) {
                $html .= '<option value="' . $value['city_code'] . '">' . $value['city_name'] . '</option>';
            }
            echo json_encode(array('result' => 'success', 'html' => $html));
            die;
        }
    }
    
    private function parse_pgresp ( $pgstr ) {
		try {
		$pg_resp_arr = explode("|", $pgstr );   
		return array(
				"MerchantID" 			=> $pg_resp_arr[0],
				"CustomerID" 			=> $pg_resp_arr[1],
				"TxnReferenceNo" 	=> $pg_resp_arr[2],
				"BankReferenceNo" => $pg_resp_arr[3],
				"TxnAmount" 			=> $pg_resp_arr[4],
				"BankID" 					=> $pg_resp_arr[5],
				"BankMerchantID" 	=> $pg_resp_arr[6],
				"TxnType" 				=> $pg_resp_arr[7],
				"CurrencyName" 		=> $pg_resp_arr[8],
				"ItemCode" 			=> $pg_resp_arr[9],
				"SecurityType" 		=> $pg_resp_arr[10],
				"SecurityID" 			=> $pg_resp_arr[11],
				"SecurityPassword" 	=> $pg_resp_arr[12],
				"TxnDate" 				=> $pg_resp_arr[13],
				"AuthStatus" 			=> $pg_resp_arr[14],
				"SettlementType" 	=> $pg_resp_arr[15],
				"AdditionalInfo1" 	=> $pg_resp_arr[16],
				"AdditionalInfo2" 	=> $pg_resp_arr[17],
				"AdditionalInfo3" 	=> $pg_resp_arr[18],
				"AdditionalInf o4" 	=> $pg_resp_arr[19],
				"AdditionalInfo5" 	=> $pg_resp_arr[20],
				"AdditionalInfo6" 	=> $pg_resp_arr[21],
				"AdditionalInfo7" 	=> $pg_resp_arr[22],
				"ErrorStatus" 			=> $pg_resp_arr[23],
				"ErrorDescription" 	=> $pg_resp_arr[24],
				"CheckSum" 			=> $pg_resp_arr[25]
		);
		}catch (\Exception $ex){
			return null;
		}
		
	} // end of method
	
	private function get_def_data_list() {
		return "cc_value=150&addon_pa_od=Y&addon_pa_pass=N&customer_type=I&customer_gender=Male&customer_name=&customer_dob=&customer_mobile=&customer_email=&customer_address=&statecode=&citycode=&customer_pincode=&customer_aadharno=&vechicle_code=&tw_regno=&reg_date=&engine_no=&chassis_no=&tw_color=&policy_start_date=&policy_end_date=&pre_insurer=&pre_policyno=&pre_pex_date=&organisation_name=&organisation_gstnno=";
	}	
	
	
	private function payment_hash($str){
		
		$hash_txt =  hash_hmac('sha256', $str, 'Sf5dEqfQPlEJ');
		return strtoupper($hash_txt);
		
	}
	
  

	public function calc_policy_dates(Request $request) {
		$pre_pex_date = $request->input("pre_pex_date");
		$tw_lib = new TwLib();
		$term_start_date = $tw_lib->date_adjust_days($pre_pex_date, 1);
		$term_end_date = $tw_lib->date_adjust_days($term_start_date, 364);
		$ret_data = array(
				"term_start_date" =>$term_start_date,
				"term_exp_date"  => $term_end_date,
		);
		return response()->json($ret_data);
	}
}
