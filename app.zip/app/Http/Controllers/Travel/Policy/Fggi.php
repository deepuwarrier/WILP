<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\Be\Travel\TravelProposalBe;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\FggiBe;
use App\Constants\Travel_Constants; 
use App\Constants\Common_Constants;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPolicy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Libraries\TravelLib;
use App\Helpers\Travel\Fggi\FggiPolicyFactory;
use Log; 

class Fggi extends Controller {

    public function load_policy_page(Request $request, $trans_code){
        $user_data = new TravelUsrData;
        $user_data = $user_data->get_all_data($trans_code);
        $quote_be =  new TravelQuoteBe;
        $benifit = $quote_be->genrate_benefit_data($user_data);
        $benifit['quote_id'] = $user_data['quote_id'];
        $fggi_be = new FggiBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form',$trans_code);
        $data  = $fggi_be->get_proposal_inputs($trans_code);
        return view('travel.policy.fggi',['data'=>$data,'benifit'=>$benifit]);
    }

    public function submit_proposal(Request $request){
        $policy_helper = new FggiPolicyFactory;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal',$request['trans_code']);
        $response   = $policy_helper->submit_policy($request['trans_code']);
        return $response;
    }

    public function set_proposal_data(Request $request){
        $fggi_be = new FggiBe;
        return $fggi_be->set_proposal_data($request->all()); 
    }

    public function payment_response(Request $request){
        $pg_response = $request->all();
        Log::info('TRAVEL_FGGI_PG_RESPONSE '. print_r($pg_response, true));
        $policy_helper = new FggiPolicyFactory;
        $usr_tbl       = new TravelUsrData;
        $fggi_be       = new FggiBe;
        $trans_code    = session('tr_suid');
        $proposal_be   = new TravelProposalBe;
        $data = json_decode($fggi_be->parse_pg_response($pg_response), true);
   
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }

        //Schedule Policy
        if($data['status']){
            try{
            $trans_code = $trans_code.'_DONE';
            $policy_req_data = $fggi_be->set_schedule_policy_request($trans_code, 
                                                       $data['pg_response']['PGID']); 
            Log::info('TRAVEL_FGGI_POLICY_SCHEDULE_REQUEST '. print_r($policy_req_data,true));
            $raw_policy_resp = $policy_helper->call_submit_proposal($policy_req_data);
            $policy_number   = $fggi_be->parse_schedule_policy_response($raw_policy_resp);
            if($policy_number){
                $data['pg_response']['policy_number'] = $policy_number;
                $columns = array('policy_num' => $policy_number);

                // Status updation
                $proposal_be->update_payment_status('policy_accepted');
                //End Status updation

                $usr_tbl->update_data($columns, $trans_code);

            }else{

                // Status updation
                $proposal_status['response_msg'] = json_encode($data); 
                $proposal_be->update_payment_status('policy_error',$proposal_status);
                //End Status updation

                $data['status'] = false;
            }
            }catch(\Exception $e){
                $data['status'] = false;
                Log::info('TRAVEL_FGGI_PG_RESPONSE_POLICY_SCHEDULE ERROR '. print_r($e->getMessage(), true));
            }
        } 

        return redirect()->route('travel_fggi_post_payment_status', $data);
    }

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.fggi', compact('data'));
    }
}   