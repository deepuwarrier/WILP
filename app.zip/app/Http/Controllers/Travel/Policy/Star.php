<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use App\Be\Travel\TravelProposalBe;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\StarBe;
use App\Constants\Travel_Constants; 
use App\Constants\Common_Constants;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPolicy;
use App\Http\Controllers\EmailSender;
use App\Helpers\Travel\Star\StarProposal;
use Illuminate\Http\Request;
use App\Libraries\TravelLib;
use Log; 

class Star extends Controller {

    public function load_policy_page($trans_code){
        $user_data = new TravelUsrData;
        $user_data = $user_data->get_all_data($trans_code);
        $quote_be =  new TravelQuoteBe;
        $benifit = $quote_be->genrate_benefit_data($user_data);
        $benifit['quote_id'] = $user_data['quote_id'];
        
        $star_be = new StarBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form',$trans_code,null);
        $data    = $star_be->get_proposal_inputs($trans_code);
        
        
        return view('travel.policy.star',['data'=>$data,'benifit'=>$benifit]);
    }


    public function submit_proposal(Request $request){
        $request = $request->all();
        $trans_code = $request['trans_code'];
        $helper   = new StarProposal;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal',$trans_code,null);
        $response = $helper->submit_proposal($request);
        return $response;
    }

    public function set_proposal_data(Request $request){
        $star_be = new StarBe;
        return $star_be->set_proposal_data($request->all()); 
    }

    public function get_state_city_list(Request $request){
        $helper = new StarProposal;
        $response = $helper->get_state_city_list($request->all());
        echo $response;
    }

    public function get_area_list(Request $request){
        $helper = new StarProposal;
        $response = $helper->get_area_list($request->all());
        echo $response;
    }

    public function get_travel_date(Request $request){
        $star_be = new StarBe;
        return response()->json($star_be->get_travel_start_date($request->all())); 
    }

    public function payment_response(Request $request){
        $pg_response = $request->all();
        $star_be = new StarBe;
        $trans_code = session('star_tr_suid');
        Log::info('TRAVEL_STAR_PG_RESPONSE :- '.$trans_code.' - '.  print_r($pg_response, true));
        $data = $star_be->parse_pg_response($pg_response,$trans_code);
        Log::info('TRAVEL_STAR_PARSED_PG_RESPONSE :- '.$trans_code.' - '.  print_r($data, true));
        session()->forget('star_tr_suid');
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }
        return redirect()->route('travel_star_post_payment_status', $data);
    }

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.star', compact('data'));
    }
       
}
