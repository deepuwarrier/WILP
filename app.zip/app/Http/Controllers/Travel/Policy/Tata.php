<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use App\Be\Travel\TravelProposalBe;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\TataBe;
use App\Libraries\TravelLib;
use App\Helpers\Travel\Tata\TataProposal;
use Illuminate\Http\Request;
use App\Be\Common\PaymentParseBE;
use Log; 
use App\Models\Travel\TravelUsrData;

class Tata extends Controller {

    public function load_policy_page(Request $request, $trans_code){
        $user_data = new TravelUsrData;
        $user_data = $user_data->get_all_data($trans_code);
        $quote_be =  new TravelQuoteBe;
        $benifit = $quote_be->genrate_benefit_data($user_data);
        $benifit['quote_id'] = $user_data['quote_id'];
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($trans_code);
        $tata_be = new TataBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form', $trans_code,null);
        $data    = $tata_be->get_proposal_inputs($trans_code);
        return view('travel.policy.tata',['data'=>$data,'benifit'=>$benifit]);
    }

    public function set_proposal_data(Request $request){
        $tata_be = new TataBe;
        return $tata_be->set_proposal_data($request->all()); 
    }

    public function submit_proposal(Request $request){
        $trans_code = $request->trans_code;
        $helper   = new TataProposal;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal', $trans_code,null);
        $response = $helper->submit_proposal($request->all());
        return $response;
    }

    public function get_user_agreement(Request $request){
        $tata_be = new TataBe;
        $data = $tata_be->get_user_agreement_data($request->all());
        $html = view('travel/partials/tata_user_agreement', compact('data'))->render();
        return response()->json(['html'=>$html]);   
    }

    public function payment_response(Request $request){
        $pg_response = $request->all();
        Log::info('TRAVEL_TATA_PG_RESPONSE '. print_r($pg_response, true));
        $tata_be = new TataBe;
        $data = json_decode($tata_be->parse_pg_response($pg_response), true);
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }
        return redirect()->route('travel_tata_post_payment_status', $data);
    }

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.tata', compact('data'));
    }
}
