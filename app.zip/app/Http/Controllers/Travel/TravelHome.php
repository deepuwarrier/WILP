<?php
namespace App\Http\Controllers\Travel;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelConfig;
use App\Be\Travel\TravelQuoteBe;
use App\Constants\Travel_Constants;
use App\Be\Travel\TravelHomeBe;
use App\Models\PortalPages;
use App\Constants\Common_Constants; 
use App\Libraries\InstaLib;
use Log; 

class TravelHome extends Controller
{
    public function index(Request $request)
    {
        $portalPgs   = new PortalPages();
        $insta_lib   = new InstaLib();
        $trans_code  = $insta_lib->get_travel_tc();
        return view('travel.travelhome', ['MTxt' => $portalPgs->getMeta(Common_Constants::TRAVELDETAILS), 'trans_code' => $trans_code]); // First page
    }

    public function load_travel_area(Request $request){
        $data = $request->all();
        if($data['trip_type'] == 'single_trip'){
            $html = view('travel/details/single_trip_area')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        if($data['trip_type'] == 'multi_trip'){
            $html = view('travel/details/multi_trip_area')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        if($data['trip_type'] == 'student_trip'){
            $html = view('travel/details/student_trip_area')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        
    }

    public function load_travel_duration(Request $request){
        $data = $request->all();
        if($data['trip_type'] == 'S'){
            $html = view('travel/details/single_trip_duration')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        if($data['trip_type'] == 'M'){
            $html = view('travel/details/multi_trip_duration')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        if($data['trip_type'] == 'ST'){
            $html = view('travel/details/student_trip_duration')->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
    }

    public function load_traveller_list(Request $request){
        $data = $request->all();
        $data['single-min-limit'] = Travel_Constants::$SINGLE_TRIP_MIN_AGE;
        $data['single-max-limit'] = Travel_Constants::$SINGLE_TRIP_MAX_AGE;
        $data['amt-min-limit'] = Travel_Constants::$AMT_MIN_AGE;
        $data['amt-max-limit'] = Travel_Constants::$AMT_MAX_AGE;
        $data['student-min-limit'] = Travel_Constants::$STUDENT_MIN_AGE;
        $data['student-max-limit'] = Travel_Constants::$STUDENT_MAX_AGE;
        $html = view('travel/details/traveller_list', compact('data'))->render();
            return json_encode(['status' => true,'html'=>$html]);
    }

    public function add_new_traveller(Request $request){
        $data = $request->all();
        $home_be = new TravelHomeBe;
        $data = $home_be->get_traveller_data($data);
        if(!$data){
            return json_encode(['status' => false]);
        }
        $id   = uniqid();
        $html = view('travel/details/add_new_traveller', compact('data','id'))->render();
            return json_encode(['status' => true,'html'=>$html]);
    }

    public function load_traveller_age_list(Request $request){ 
        $data = $request->all();
        $home_be = new TravelHomeBe;
        $data = $home_be->get_age_list($data);
        return json_encode(['status' => true,'html'=>$data]);
    }

    public function save_user_data(Request $request){ 
        $data = $request->all();
        $home_be = new TravelHomeBe;
        $status = $home_be->save_user_data($data);
        $fail_message = '<h5 class="category-social">'.Travel_Constants::$SERVER_CONNECTIVITY.'</h5>';
        $fail_message .= '<h6 class="category-social">'.Travel_Constants::$THREE_ATTEMPLTS_MSG.'</h6>'; 
        return json_encode(['status' => $status, 'msg' => $fail_message ]);
    }
}
