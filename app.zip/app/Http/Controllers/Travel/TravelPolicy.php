<?php
 
namespace App\Http\Controllers\Travel;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Libraries\TravelLib;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\TravelProposalBe;
use App\Models\Travel\TravelUsrData;
use App\Helpers\Travel\Tata\TataProposal;
use App\Helpers\Travel\Hdfc\HdfcProposal;
use App\Constants\Travel_Constants; 
use App\Constants\Common_Constants;
use App\Constants\Car_Constants;
use App\Helpers\EmailHelper;
use App\Http\Controllers\EmailSender;
use App\Helpers\SmsHelper;
use App\Models\Travel\OtpTData;
use App\Models\Car\CarConfig;

use Log; 
 
class TravelPolicy extends Controller
{
    public function __construct()
    {
        $this->email = new EmailSender;

    }

    public function get_city(Request $request){
        $bl  = new TravelProposalBe;
        $response = $bl->get_city($request->all());
        if($response){
            $html = view('travel/partials/proposal_city_list', compact('response'))->render();
            return json_encode(['status' => true,'html'=>$html]);
        }
        return json_encode(['status' => false]);
    }
    
    public function load_preview(Request $request){
        $bl  = new TravelProposalBe;
        $response = $bl->set_proposal_preview($request->all());
        $html = view('travel/partials/proposal_preview', compact('response'))->render();
        return $html;
    }
    
    public function get_trip_end_date(Request $request){
        $bl  = new TravelProposalBe;

        return $bl->get_trip_end_date($request->all());
    }
     
    public function get_confirm_box(){
        return view('travel/status/reconfirm_status')->render();
    }
    
    public function get_premium_mismatch_box(Request $request){
        $html = view('travel/status/premium_mismatch', compact('request'))->render();
        return response()->json(['html'=>$html]);   
    }

    public function get_no_premium_change_box(Request $request){
        $html = view('travel/status/no_change_premium', compact('request'))->render();
        return response()->json(['html'=>$html]);   
    }

    public function update_payment_status(Request $request){
        $proposal_be  = new TravelProposalBe;
        if(isset($request['category']) && $request['category']!= null){
            $proposal_be->update_payment_status($request['category'],$request['trans_code'],null);
        }
        return response()->json(['status'=>true]); 
    }

    public function genrateOtp(Request $request) {
        $sms = new SmsHelper;
        $car_config = new CarConfig;
        $otp_t_data = new OtpTData;
        session(['mobile' =>$request->mobile]);
        
        if(session('otp_record'.$request->mobile)){
            $count = session('otp_record'.$request->mobile)['count'] + 1;
            session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
                         'count'=>$count]]);
        }else{
            session(['otp_record'.$request->mobile=>['mobile'=>$request->mobile,
                         'count'=>1]]);
        }
        $num_allowed_otp = $car_config->getValue('MAX_NUM_OTP')->first()->config_value;
        //get old Otp Id
        $result = $otp_t_data->where('mobile', $request->mobile)->first();
        if (is_object($result) && $result->status) {
            session(['UIDNo' => $result->otp_id]);
            return array('otp' => $result->otp_id,'status'=>$result->status); // status added by vivek at 15-May-2017

        }else if(session('otp_record'.$request->mobile)['count'] > $num_allowed_otp){
            return json_encode(['overLimit'=>1,'count'=>session('otp_record'.$request->mobile)['count'],'max'=>$num_allowed_otp]);
        }else {
            $output = $sms->genrateOtp($request->mobile, Car_Constants::OTP_LENGTH);
            return $output;
        }
    }

    public function verifyOtp(Request $request) {
        $status = 0;
        $sent_otp = session('otp');
        $recv_otp = $request->code;
        if ($sent_otp && $recv_otp == $sent_otp) {
            $status = 1;
        }
        session(['UIDNo' => $this->storeOtpVlaues($recv_otp, $sent_otp, $status, session('mobile'))]);
        return json_encode(['status' => $status]);
    }

    public function storeOtpVlaues($recv_otp, $sent_otp, $status, $mobile) {
        $otp = new OtpTData;
        $query = $otp->updateOrCreate([OtpTData::MAPPER['MOBILE'] => $mobile],[OtpTData::MAPPER['SENT_OTP'] => $sent_otp,
            OtpTData::MAPPER['RECIVE_OTP'] => $recv_otp,
            OtpTData::MAPPER['STATUS'] => $status,
            OtpTData::MAPPER['MOBILE'] => $mobile]);
        return ($query) ? $otp->otp_id : 0;
    }

    public function offline_response(Request $request){
        $usr_tbl     = new TravelUsrData;
        $trans_code = session('tr_suid');
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_payment_status('policy_error',$trans_code);
        $proposal_be->update_proposal_status('proposal_error',$trans_code);
        $msg  = Travel_Constants::$PED_MESSAGE;
        session()->forget('tr_suid');
        return view('travel/status/offline_policy_page', compact('msg'));
    }

    public function bad_response(Request $request){
        $usr_tbl     = new TravelUsrData;
        $trans_code  = session('tr_suid');
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_payment_status('policy_error',$trans_code,null);
        $proposal_be->update_proposal_status('proposal_error',$trans_code,null);
        session()->forget('tr_suid');
        return view('api-bad-response');
        
    }
}
