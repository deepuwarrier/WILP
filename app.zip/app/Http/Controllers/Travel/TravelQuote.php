<?php

namespace App\Http\Controllers\Travel;
use App\Helpers\Travel\Bagi\Bagihelper; 
use App\Http\Controllers\Controller;
use App\Be\Travel\TravelQuoteBe;
use App\Models\Travel\TravelUsrData;
use App\Libraries\TravelLib;
use App\Constants\Travel_Constants;
use App\Helpers\Travel\Hdfc\HdfcQuotes;
use App\Helpers\Travel\Tata\TataQuotes;
use App\Helpers\Travel\Star\StarQuotes;
use App\Helpers\Travel\Fggi\FggiQuoteFactory;
use App\Helpers\Travel\Religare\ReligareQuotes;
use Illuminate\Support\Facades\Input;
use App\Models\Travel\TravelTataPremium;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Be\Travel\FggiBe;
use Log; 
use File;

class TravelQuote extends Controller
{  
   public function getquotes($trans_code, Request $input){ 
        $user_data = new TravelUsrData;
        $data = $user_data->update_data(['checks'=>null],$trans_code);

        $quote_be  = new TravelQuoteBe;
        $quote_be->update_quote_status('new_quote',$trans_code);
        $request        = $quote_be->get_quote_inputs($trans_code, $input->all());
        $cov_data       = view('travel/quote/quote_default_inclusions')->render();
        $selection_box  = view('travel/quote/quote_selection_box', compact('request'))->render();
        return view('travel.travelquote', ['trans_code'=>$trans_code,
                                           'cov_data'=>$cov_data ,
                                           'selection_box' => $selection_box,
                                           'request'=> $request]);
   }
    
   public function load_tata_quotes(Request $request){
        return null;
        $trans_code = $request->trans_code;
        $bl         = new TravelQuoteBe;
        $helper     = new TataQuotes;
        $inputs     = $bl->get_quote_inputs($trans_code);
        $response   = $helper->get_tata_quotes($inputs);
        $response   = $bl->filter_response($response,$trans_code);
        $view_data = '';
        try{        
            if($response == null)
                return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("tata")); 

            foreach ($response as $index => $item){
                if(!$item){
                   return null; 
                }
                $error = false;
                $benifit = $bl->get_benefit_data($trans_code,$item);
                $pb = $bl->get_breakup_data($item);
                $benifit['quote_id'] = $item['policyId'];
                $view_data .= view('travel/quote/quote_box',
                                  ['item'=>$item,
                                   'index'=>$index,
                                   'benifit'=>$benifit,
                                   'pb'=>$pb,
                                   'error'=>$error])->render();
            }  
            return $view_data;
        }catch(\Exception $e){
            Log::info('TRAVEL_TATA_QUOTE_RESPONSE catch -'.$trans_code.' - '. print_r($e->getMessage(),true));
            return null;
        }    
    }

    public function load_hdfc_quotes(Request $request){
        $trans_code = $request->trans_code;
        $bl         = new TravelQuoteBe;
        $helper     = new HdfcQuotes;
        $inputs     = $bl->get_quote_inputs($trans_code);
        $response   = $helper->get_hdfc_quotes($inputs);
        $response   = $bl->filter_response($response,$trans_code);
        $view_data = '';
        $product = "";
        try{
            if($response == null)
                return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("hdfc")); 
            
            foreach ($response as $index => $item){
                $error = false;
                $benifit = $bl->get_benefit_data($trans_code,$item);


                $pb = $bl->get_breakup_data($item);
                try{
                    $benifit['quote_id'] = $item['policyId'];
                    $view_data .= view('travel/quote/quote_box',
                                   ['item'=>$item,
                                    'index'=>$index,
                                    'pb'=>$pb,
                                    'benifit'=>$benifit, 
                                    'error'=>$error])->render();    
                }catch(Exception $e){
                    $view_data .= $e->getMessage();
                    return $view_data;
                }
            }       
            return $view_data;
         }catch(\Exception $e){
             Log::info('TRAVEL_HDFC_QUOTE_RESPONSE catch -'.$trans_code.' - '. print_r($e->getMessage(),true));
             return null;
         } 
    }

    public function load_star_quotes(Request $request){  
        $trans_code = $request->input('trans_code'); 
        $bl         = new TravelQuoteBe;
        
       
        
        
        $helper     = new StarQuotes;
        $inputs     = $bl->get_quote_inputs($trans_code);
        $response   = $helper->get_star_quotes($inputs);
        $response   = $bl->filter_response($response,$trans_code);
        $view_data  = '';
        try{
            if($response == null)
                return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("star")); 

            foreach ($response as $index => $item){
                $error = false;
                $benifit = $bl->get_benefit_data($trans_code,$item);
                $pb = $bl->get_breakup_data($item);
                $benifit['quote_id'] = $item['policyId'];
                $benifit['quote_id'] = $item['policyId'];
                $view_data .= view('travel/quote/quote_box',
                                   ['item'=>$item,
                                   'benifit'=>$benifit,
                                   'index'=>$index, 
                                   'pb'=>$pb,
                                   'error'=>$error])->render();
            }    

            return $view_data;
        }catch(\Exception $e){
            Log::info('TRAVEL_STAR_QUOTE_RESPONSE catch - '.$trans_code.' - '. print_r($e->getMessage(),true));
            return null;
        }     
    }

    public function load_religare_quotes(Request $request){
        $trans_code = $request->input('trans_code');
        $bl         = new TravelQuoteBe;
        $helper     = new ReligareQuotes;
        $inputs     = $bl->get_quote_inputs($trans_code);
        $response   = $helper->get_religare_quotes($inputs);
        $response   = $bl->filter_response($response,$trans_code);
        $view_data  = '';
        try{
            if($response == null)
                return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("religare")); 
            $result = '';
            foreach ($response as $index => $item){
                $error = false;
                $benifit = $bl->get_benefit_data($trans_code,$item);
                $pb = $bl->get_breakup_data($item);
                $benifit['quote_id'] = $item['policyId'];
                $result .= view('travel/quote/quote_box',
                                   ['item'=>$item, 
                                   'index'=>$index, 
                                   'benifit'=>$benifit,
                                   'pb'=>$pb,
                                   'error'=>$error])->render();
            }    
            return $result;
        }catch(\Exception $e){
            Log::info('TRAVEL_RELIGARE_QUOTE_RESPONSE catch - '.$trans_code.' - '. print_r($e->getMessage(),true));
            return null;
        }     
    }

    public function load_fggi_quotes(Request $request){
        $trans_code = $request->input('trans_code');
        $fggi_be    = new FggiBe;
        $bl         = new TravelQuoteBe;
        $quote_helper = new FggiQuoteFactory;
        $quote_req_data = $fggi_be->populate_quote_data($trans_code);
        $response = $quote_helper->get_quote($quote_req_data);
        $response   = $bl->filter_response($response,$trans_code);
        $view_data  = '';
        try{
            if($response == null)
                return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("fggi")); 

            foreach ($response as $index => $item){
                $error = false;
                $benifit = $bl->get_benefit_data($trans_code,$item);
                $pb = $bl->get_breakup_data($item);
                $benifit['quote_id'] = $item['policyId'];
                $view_data .= view('travel/quote/quote_box',
                                   ['item'=>$item, 
                                   'index'=>$index, 
                                   'benifit'=>$benifit,
                                   'pb'=>$pb,
                                   'error'=>$error])->render();
            }    
            return $view_data;
        }catch(\Exception $e){
            Log::info('TRAVEL_FGGI_QUOTE_RESPONSE catch - '.$trans_code.' - '. print_r($e->getMessage(),true));
            return null;
        }     

    }
    
    public function load_covers(Request $request){
        $bl = new TravelQuoteBe;
        $user_data = new TravelUsrData;
        $data = $user_data->get_data(['checks'],$request->input('trans_code'));
        
        if($data['checks'])
            return null;

        $checks = '';
        list($cmnCover, $otherCover)  =  $bl->get_cover_data($request->all());
        


        if(is_null($cmnCover) || is_null($otherCover))
            return NULL;

        $add_ons  = array(66,67,68,69,70,71);
        $common   = array_intersect($cmnCover,$add_ons);
        $cmnCover = array_diff($cmnCover,$add_ons);
        $otherCover = array_unique(array_merge($otherCover, $common));
        if($data['checks'])
            $cmnCover = explode(",",$data['checks']);

        $otherCover = array_diff($otherCover,$cmnCover);
        // dd($otherCover);
        return view('travel/partials/quote_coverages', ['common'=>$cmnCover, 'other'=>$otherCover]);
    }
    
    public function filter_quote(Request $request,$trans_code){
        $user_data = new TravelUsrData;
        $checks = (is_array($request['chks'])) ?    implode(',',$request['chks']) : rtrim($request['chks'],',');
        $data = $user_data->update_data(['checks'=>$checks],$trans_code);
        return '';
    }

    public function get_benefits(Request $request, $trans_code){
        $bl   = new TravelQuoteBe;
        $data = $bl->get_benefit_data($request->all(), $trans_code);
        return view('travel.quote.quote_benefit_info', compact('data')); 
    }

    public function get_breakup(Request $request, $trans_code){
        $bl   = new TravelQuoteBe;
        $data = $bl->get_breakup_data($request->all(), $trans_code);
        return view('travel.quote.quote_premium_breakup', compact('data'));
    }
    
    public function mapSumInsured(Request $request){
        $bl = new TravelQuoteBe;
        return trim($bl->getSumInsured($request['type'], $request['area'], $request['si'], $request['ctrl'], 'N'));
    }

    public function load_proposal_page(Request $request){
        $form_data = $request->all();
        $companyId = $form_data['companyId'];
        $proposal_url = $form_data['proposal_url'];
        $plan_code = $form_data['planCode'];
        $trans_code = $form_data['trans_code'];
        $policy_id = $form_data['policy_id'];
        $net_premium_amt = $form_data['net_premium_amt'];
        $tax_amt     = $form_data['tax_amt'];
        $quote_be   = new TravelQuoteBe;
        $quote_be->update_quote_status('select_policy',$trans_code);
        unset($form_data['proposal_url']);
        unset($form_data['companyId']);
        unset($form_data['_token']);
        unset($form_data['planCode']);
        unset($form_data['policy_id']);
        
        // save user data
        $user_data = new TravelUsrData;
        $data = $user_data->get_data(['misc_desc','name'],$trans_code);
        
        // relavent data save in user data
        if($data['misc_desc'] != ''){
            $misc_desc = json_decode($data['misc_desc'],true);
            $misc_desc[$plan_code] = $form_data;
            $data['misc_desc'] = json_encode($misc_desc);    
        }else{
            $data['misc_desc'] = json_encode([$plan_code => $form_data]);
        }
        $data['plan_code'] = $plan_code;
        $data['company_id'] = $companyId;
        $data[Travel_Constants::USR_T_LOG['QUOTE_ID']] = $policy_id;
        $data['premium'] = $net_premium_amt;
        $data['tax']     = $tax_amt;
        if($companyId != 'tata' && $data['name'])
            $data['name'] = str_replace("|"," ",$data['name']);
        $user_data->update_data($data,$trans_code);
        // end save user data
        return redirect($proposal_url);
    }
}
