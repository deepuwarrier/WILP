<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use App\Be\Travel\TravelProposalBe;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\HdfcBe;
use App\Constants\Travel_Constants; 
use App\Constants\Common_Constants;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPolicy;
use App\Libraries\TravelLib;
use App\Helpers\Travel\Hdfc\HdfcProposal;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use App\Be\Common\PaymentParseBE;
use Log; 

class Hdfc extends Controller {

    public function load_policy_page($trans_code){
        session(['tr_suid' => $trans_code]);
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($trans_code);
        
        $hdfc_be = new HdfcBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form');
        $data    = $hdfc_be->get_proposal_inputs($trans_code);
        return view('travel.policy.hdfc', compact('data'));
    }

    public function submit_proposal(Request $request){
        $helper  = new HdfcProposal;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal');
        $response = $helper->submit_proposal($request->all());
        return $response;
    }
    
    public function set_proposal_data(Request $request){
        $hdfc_be = new HdfcBe;
        return $hdfc_be->set_proposal_data($request->all()); 
    }

    public function update_paymode(Request $request){
        $hdfc_be = new HdfcBe;
        return $hdfc_be->update_paymode($request->all());
    }

    public function payment_response(Request $request){
        $pg_response = $request->all();
        Log::info('TRAVEL_HDFC_PG_RESPONSE '. print_r($pg_response, true));
        $hdfc_be   = new HdfcBe;
        $data = json_decode($hdfc_be->parse_pg_response($pg_response), true);
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }
        return redirect()->route('travel_hdfc_post_payment_status', $data);
    }

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.hdfc', compact('data'));
    }

}
