<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Be\Travel\ReligareBe;
use App\Be\Travel\TravelProposalBe;
use App\Helpers\Travel\Religare\ReligareProposal;
use App\Be\Common\PaymentParseBE;
use Log; 

class Religare extends Controller {

    public function load_policy_page($trans_code){
        // session(['tr_suid' => $trans_code]);
        $payment_parse_be = new PaymentParseBE;
        $payment_parse_be->setPaymentIdentifier($trans_code);
        $religare_be    = new ReligareBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form');
        $data  = $religare_be->get_proposal_inputs($trans_code);
        return view('travel.policy.religare', compact('data'));
    }

    public function submit_proposal(Request $request){
        $helper  = new ReligareProposal;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal');
        $response = $helper->submit_proposal($request->all());
        return $response;
    }
    

    public function set_proposal_data(Request $request){
        $religare_be = new ReligareBe;
        return $religare_be->set_proposal_data($request->all()); 
    }

    public function payment_response(Request $request,$trans_code){
        $pg_response = $request->all();
        Log::info('TRAVEL_RELIGARE_PG_RESPONSE '. print_r($pg_response, true));
        $religare_be   = new ReligareBe;
        $data = json_decode($religare_be->parse_pg_response($pg_response,$trans_code), true);
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }
        return redirect()->route('travel_religare_post_payment_status', $data);
    } 

    public function get_policy_pdf(Request $request){
        $policy_number = $request['p'];
        $helper = new ReligareProposal;
        $policy_pdf =  $helper->get_policy_pdf($policy_number);
        if(!$policy_pdf){
          echo 'Statement Not Generated For Given Policy number';
          dd();
        }
        return Response::make(base64_decode($policy_pdf), 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="travel_policy_'.$policy_number.'.pdf"']);
    } 

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.religare', compact('data'));
    }

}
