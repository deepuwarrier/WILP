<?php
namespace App\Http\Controllers\Travel\Policy;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\Be\Travel\TravelProposalBe;
use App\Be\Travel\TravelQuoteBe;
use App\Be\Travel\StarBe;
use App\Constants\Travel_Constants; 
use App\Constants\Common_Constants;
use App\Models\Travel\TravelUsrData;
use App\Models\Travel\TravelPolicy;
use App\Http\Controllers\EmailSender;
use App\Helpers\Travel\Star\StarProposal;
use Illuminate\Http\Request;
use App\Libraries\TravelLib;
use Log; 

class Star extends Controller {

    public function load_policy_page($trans_code){
        session(['tr_suid' => $trans_code]);
        $star_be = new StarBe;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('load_proposal_form');
        $data    = $star_be->get_proposal_inputs($trans_code);
        return view('travel.policy.star', compact('data'));
    }


    public function submit_proposal(Request $request){
        $helper   = new StarProposal;
        $proposal_be = new TravelProposalBe;
        $proposal_be->update_proposal_status('submit_proposal');
        $response = $helper->submit_proposal($request->all());
        return $response;
    }

    public function set_proposal_data(Request $request){
        $star_be = new StarBe;
        return $star_be->set_proposal_data($request->all()); 
    }

    public function get_state_city_list(Request $request){
        $helper = new StarProposal;
        $response = $helper->get_state_city_list($request->all());
        echo $response;
    }

    public function get_area_list(Request $request){
        $helper = new StarProposal;
        $response = $helper->get_area_list($request->all());
        echo $response;
    }

    public function payment_response(Request $request){
        $pg_response = $request->all();
        Log::info('TRAVEL_STAR_PG_RESPONSE '. print_r($pg_response, true));
        $star_be = new StarBe;
        $trans_code = session('tr_suid');
        $data = $star_be->parse_pg_response($pg_response);
        Log::info('TRAVEL_STAR_PARSED_PG_RESPONSE '. print_r($data, true));
        if(isset($data['redirect'])){
          return Redirect::to('travel-insurance');
        }
        return redirect()->route('travel_star_post_payment_status', $data);
    }

    public function post_payment_status(Request $request){
        $data = $request->all();
        return view('travel.return_page.star', compact('data'));
    }
       
}
