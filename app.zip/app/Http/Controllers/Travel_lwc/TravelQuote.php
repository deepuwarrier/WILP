<?php

namespace App\Http\Controllers\Travel;
use App\Helpers\Travel\Bagi\Bagihelper; 
use App\Http\Controllers\Controller;
use App\Be\Travel\TravelQuoteBe;
use App\Models\Travel\TravelUsrData;
use App\Libraries\TravelLib;
use App\Constants\Travel_Constants;
use App\Helpers\Travel\Hdfc\HdfcQuotes;
use App\Helpers\Travel\Tata\TataQuotes;
use App\Helpers\Travel\Star\StarQuotes;
use App\Helpers\Travel\Fggi\FggiQuoteFactory;
use App\Helpers\Travel\Religare\ReligareQuotes;
use Illuminate\Support\Facades\Input;
use App\Models\Travel\TravelTataPremium;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Be\Travel\FggiBe;
use Log; 
use File;

class TravelQuote extends Controller
{  
   public function getquotes($trans_code, Request $input){ 
        session(['tr_suid' => $trans_code]);
        $quote_be  = new TravelQuoteBe;
        $quote_be->update_quote_status('new_quote');
        $request        = $quote_be->get_quote_inputs(session('tr_suid'), $input->all());
        $cov_data       = view('travel/quote/quote_default_inclusions')->render();
        $selection_box  = view('travel/quote/quote_selection_box', compact('request'))->render();
        return view('travel.travelquote', ['trans_code'=>$trans_code,
                                           'cov_data'=>$cov_data ,
                                           'selection_box' => $selection_box,
                                           'request'=> $request]);
   }
    
   public function load_tata_quotes(){
        
       try{
       
       
        $bl         = new TravelQuoteBe;
        $helper     = new TataQuotes;
        $inputs     = $bl->get_quote_inputs(session('tr_suid'));
        $response   = $helper->get_tata_quotes($inputs);
        $view_data = '';
        
        if($response == null)
            return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("tata")); 

        foreach ($response as $index => $item){
            if(!$item){
               return null; 
            }
            $error = false;
            $view_data .= view('travel/quote/quote_box',
                              ['item'=>$item,
                               'index'=>$index,
                               'error'=>$error])->render();
        }  
        return $view_data;
       }catch(\Exception $ex) { Log::error($ex->getMessage()) ;   return null;}
    }

    public function load_hdfc_quotes(){
        
        
        
        $bl         = new TravelQuoteBe;
        
        
        // return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("hdfc")); 
        
        $helper     = new HdfcQuotes;
        $inputs     = $bl->get_quote_inputs(session('tr_suid'));
        $response   = $helper->get_hdfc_quotes($inputs);
        $view_data = '';
        $product = "";
        
        if($response == null)
            return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("hdfc")); 
        
        foreach ($response as $index => $item){
            $error = false;
            $view_data .= view('travel/quote/quote_box',
                               ['item'=>$item,
                                'index'=>$index, 
                                'error'=>$error])->render();
        }       
        return $view_data;
    }

    public function load_star_quotes(){   
        $bl         = new TravelQuoteBe;
        $helper     = new StarQuotes;
        $inputs     = $bl->get_quote_inputs(session('tr_suid'));
        $response   = $helper->get_star_quotes($inputs);
        $view_data  = '';
        
        if($response == null)
            return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("star")); 

        foreach ($response as $index => $item){
            $error = false;
            $view_data .= view('travel/quote/quote_box',
                               ['item'=>$item,
                               'index'=>$index, 
                               'error'=>$error])->render();
        }    

        return $view_data;
    }

    public function load_religare_quotes(){
        
        $bl         = new TravelQuoteBe;
        $helper     = new ReligareQuotes;
        $inputs     = $bl->get_quote_inputs(session('tr_suid'));
        
        return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("religare")); 
        
        $response   = $helper->get_religare_quotes($inputs);
        $view_data  = '';
        
        if($response == null)
            return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("religare")); 

        foreach ($response as $index => $item){
            $error = false;
            $view_data .= view('travel/quote/quote_box',
                               ['item'=>$item, 
                               'index'=>$index, 
                               'error'=>$error])->render();
        }    
        return $view_data;
    }

    public function load_fggi_quotes(){

        $fggi_be    = new FggiBe;
        $bl         = new TravelQuoteBe;
        $quote_helper = new FggiQuoteFactory;
        $quote_req_data = $fggi_be->populate_quote_data(session('tr_suid'));
        $response = $quote_helper->get_quote($quote_req_data);
        $view_data  = '';
        
        if($response == null)
            return $bl->getNoQuoteBoxView($bl->getCmpSingleProduct("fggi")); 

        foreach ($response as $index => $item){
            $error = false;
            $view_data .= view('travel/quote/quote_box',
                               ['item'=>$item, 
                               'index'=>$index, 
                               'error'=>$error])->render();
        }    
        return $view_data;
    }
    
    public function load_covers(Request $request){
        $bl = new TravelQuoteBe;
        $checks = '';
        list($cmnCover, $otherCover)  =  $bl->get_cover_data($request->all());
        $add_ons  = array(66,67,68,69,70,71);
        $common   = array_intersect($cmnCover,$add_ons);
        $cmnCover = array_diff($cmnCover,$add_ons);
        $otherCover = array_unique(array_merge($otherCover, $common));
        return view('travel/partials/quote_coverages', ['common'=>$cmnCover, 'other'=>$otherCover]);
    }
    
    public function filter_quote(Request $request, $trans_code){
        $bl           = new TravelQuoteBe;
        $view_data    = $bl->get_filter_data($request->all(), $trans_code);
        return $view_data;
    }

    public function get_benefits(Request $request, $trans_code){
        $bl   = new TravelQuoteBe;
        $data = $bl->get_benefit_data($request->all(), $trans_code);
        return view('travel.quote.quote_benefit_info', compact('data')); 
    }

    public function get_breakup(Request $request, $trans_code){
        $bl   = new TravelQuoteBe;
        $data = $bl->get_breakup_data($request->all(), $trans_code);
        return view('travel.quote.quote_premium_breakup', compact('data'));
    }

    public function save_policyid(Request $request, $trans_code){ 
        $quote_be   = new TravelQuoteBe;
        $quote_be->update_quote_status('select_policy');
        $quote_be->save_policyid($trans_code, $request['policy_id']);
    } 

    public function mapSumInsured(Request $request){
        $bl = new TravelQuoteBe;
        return trim($bl->getSumInsured($request['type'], $request['area'], $request['si'], $request['ctrl'], 'N'));
    }

    public function load_proposal_page(Request $request){
        $form_data = $request->all();
        $companyId = $form_data['companyId'];
        $trans_code = $form_data['trans_code'];
        $policy_id = $form_data['policy_id'];

        $user_data = new TravelUsrData;
        $data = $user_data->get_data(['name'],$trans_code);
        $data['quote_id'] = $policy_id;
        if($companyId != 'tata' && $data['name'])
            $data['name'] = str_replace("|"," ",$data['name']);
        
        $user_data->update_data($data,$trans_code);

        $quote_be   = new TravelQuoteBe;
        $quote_be->update_quote_status('select_policy');
        $quote_be->save_policyid($trans_code,$policy_id);

        return redirect($form_data['proposal_url']);
    }
}