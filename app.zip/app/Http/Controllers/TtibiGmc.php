<?php
namespace App\Http\Controllers;

use App\Be\TW\TwTpBe;
use App\Helpers\TW\InsurerData;
use App\Helpers\TW\UnitedIndia\TpPolicy;
use App\Http\Controllers\Controller;
use App\Libraries\InstaLib;
use App\Libraries\TwLib;
use App\Models\TtibiGmcM;
use App\Models\TW\TwUsrData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class TtibiGmc extends Controller {

    public function __construct() {
    }

    public function load_ttibigmc(Request $request) {  
    	return view("ttibigmc", [
    			"emp_data" => null,
    			"msg_txt" => ""
    	]);
    }
    
    public function search_ttibigmc (Request $request){
    	$sp = $request->all();   
    	$ttibigmc_db = new TtibiGmcM();
    	$emp_data = $ttibigmc_db->search_emp($sp["emp_code"]);
//     	$emp_dob = date('d/m/Y', strtotime( $sp["emp_dob"])); 
    	$resp_flag = false;
    	foreach ($emp_data as $data){
    		if($data->date_of_birth == $sp["emp_dob"]){ $resp_flag = true; }
    	}
    	
    	if($resp_flag){
    		return view("ttibigmc", [
    				"emp_data" => $emp_data,
    				"msg_txt" => ""
    		]);
    	}
    	return view("ttibigmc", [ 
    			"emp_data" => null,
    			"msg_txt" => "No Such Data Found!!"
    	]);
    }
    
    public function submit_ttibigmc (Request $request){
    	$params = $request->all();  
    	unset($params['_token']);
    	$update_arr = array();
    	$last_mem_id = "";
    	$mem_arr = null;
    	foreach ($params as $raw_data => $value){ 
    		
    		$key_arr = explode("||", $raw_data);
//     		if($key_arr[1] == "date_of_birth") {
//     			$value = date('d/m/Y', strtotime( $value ));
//     		}
    		$mem_arr[$key_arr[1]] = $value;
    		$update_arr[$key_arr[0]] = $mem_arr;
    	}
    	$ttibi_gmc_db = new TtibiGmcM();
    	foreach ($update_arr as $data_key => $data_value ){
    		$data_value["update_status"] ="1";
    		$ttibi_gmc_db->save_member($data_key,$data_value);
    	}
    	
    	return view("ttibigmc", [
    			"emp_data" => null,
    			"msg_txt" => "<h4>Your Details have been successfully updated. Thank you!</h4>"
    	]);
    	
    }
} // class
