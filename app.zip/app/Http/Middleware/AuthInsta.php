<?php

namespace App\Http\Middleware;

use Closure;
use App\Http\Controllers\Customers\Customers;

class AuthInsta
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       
    

 $login = new Customers();
        $user_status = $login->uatlogin($request);
        if (empty(session('uat_username')) || session('uat_username') != 'uat_testing' ) {
            return redirect('/uat-login');
        } else {
            return $next($request);
        }
        
    }
}
