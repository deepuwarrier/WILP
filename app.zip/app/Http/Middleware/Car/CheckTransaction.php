<?php

namespace App\Http\Middleware\Car;

use App\Helpers\Car\CarHelper;
use Response;
use Closure;

class CheckTransaction {

	/**
	 * Handle an incoming request.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \Closure  $next
	 * @return mixed
	 */
	public function handle($request, Closure $next) {
		$transaction_code = (isset($request->transcode)) ? $request->transcode : $request->trans_code;
		$transaction_code = $transaction_code.'_DONE';
		$car_helper = new CarHelper;
		//$car_helper->setSuid($transaction_code);
		if ($car_helper->checkTransaction($transaction_code)) {
			$request->session()->regenerate();
			if (!$request->ajax()) {
				return redirect('car-insurance');
			} else {
				// echo json_encode(array('redirect' => route('car_insurance')), true);
				$response = new Response;
				return $response->json(array(
                    'success' => true,
                    'redirect'   => route('car_insurance')
                ));
				die;
			}
		}
		return $next($request);
	}
}
