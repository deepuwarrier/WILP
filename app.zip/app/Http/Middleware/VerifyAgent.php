<?php
namespace App\Http\Middleware;

use Closure;

class VerifyAgent {
    public function handle($request, Closure $next)
    {
        if (!empty(session('user_role')) && (session('user_role') == "_AGENT") ) {
        		return $next($request);
        } else {
       	 	return redirect('/login');
        }
    }
}
