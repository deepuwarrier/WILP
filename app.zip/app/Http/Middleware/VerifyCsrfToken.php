<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as BaseVerifier;

class VerifyCsrfToken extends BaseVerifier
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'webd/buystatus/148',
        'health-insurance/religare/payment/status/*',
    	'travel-insurance/religare/payment/status/*',
        'car-insurance/carquote',
    	'car-insurance/rsgi/payment/status',
        'car-insurance/bajaj/payment/status',
        'car-insurance/uiic/payment/status',
        'car-insurance/hdfc/payment/status',
        'car-insurance/tata/payment/status',
	    'two-wheeler-insurance/uiic/payment/status',
    	'health-insurance/rsgi/payment/status',
	    'two-wheeler-insurance/rsgi/payment/status',
        'two-wheeler-insurance/bajaj/payment/status',
	    'two-wheeler-insurance/tp/uiic/payment/status',
    		'services/*'
	
    ];
}
