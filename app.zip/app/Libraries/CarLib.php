<?php

namespace App\Libraries;

use App\Helpers\Car\CarHelper;
use App\Models\Car as M;
use App\Models\Car\CarTData;

class CarLib {

	public function idvCalc() {
		// write your quote here
		return $val;
	}

	public function parseRegistrationNumber($str) {
		$reg_nu = $str;
		return (preg_match('/^[A-Z]*/i', $str, $matches) && $matches[0] != '') ? ($nu = substr($str, strlen($matches[0]))) ? $matches[0] . '-' . $nu : $reg_nu : $reg_nu;
	}

	public function parseDataInUpperCase($data,$not_to_parse = null) {
		$apiData = ['previnsurance', 'claim', 'statecode', 'citycode', 'marritial_status', 'title', 'custSubType', 'nationality', 'occupation', 'nomineeRel', 'qualification', 'experience', 'claimHistory', 'color', 'bodyType', 'garageType', 'dailyMillage', 'roadTypeCodes', 'preferredRepair', 'numberClaims', 'bank','id','session_id','_token','cmp_paid_up'];
		if(isset($not_to_parse) && is_array($not_to_parse)){
			$apiData  = array_merge($apiData,$not_to_parse);
		}

		foreach ($data as $key => $value) {
			if (!in_array($key, $apiData)) {
				if(isset($value) && $value != '')
					$data[$key] = strtoupper($value);
			}
		}
		return $data;
	}

	public function storeRequestId($result) {
		$car_helper = new CarHelper;
		$car_t_data = new CarTData;
		if (isset($result['data']['requestId'])) {
			$suid = $car_helper->getSuid();
			try {
				$car_transaction = $car_t_data->updateOrCreate(['trans_code' => $suid], ['request_id' => $result['data']['requestId']]);
			} catch (Exception $e) {
				return json_encode(array('f_error' => $e->getMessage()), true);
			}
		}
		return 1;
	}

	public function storeStatus($t_status,$trans_code = null) {
		$car_helper = new CarHelper;
		$car_t_data = new CarTData;
		try {
			$user_data = $car_t_data->find($trans_code);
			if($user_data){
				if($t_status == 1){
					$pos = substr_count($user_data->trans_code,"DONE");

					if(!$pos)
						$user_data->trans_code = $user_data->trans_code.'_DONE';
				}
				$user_data->save();
				return $user_data;
			}
		} catch (\Exception $e) {
			return json_encode(array('f_error' => $e->getMessage()), true);
		}
		return 0;
	}

	public function getFirstName($fullname) {
		return trim(substr($fullname, 0, stripos($fullname, " ")));
	}

	public function getLastName($fullname) {
		return trim(substr($fullname, stripos($fullname, " ")));
	}

	public function getCorrect($name) {
		$length = strlen($name);
		if ($length < 3) {
			for ($i = 0; $i < (3 - $length); $i++) {
				$name = " " . $name;
			}
		}
		return $name;
	}

	public function calculateOD($vehicle_cc,$rto_zone,$vehicleAge,$idv, $policy_type_selection=""){

		$car_od_rates = new M \CarOdRates;
		$vehicleAge =  $vehicleAge <= 5?5:($vehicleAge <= 10?10:50);
		$vehicle_cc =  $vehicle_cc <= 1000?1000:($vehicle_cc <= 1500?1500:150000);
		$percentage =  $car_od_rates->getOdPerValuePer($rto_zone,$vehicleAge,$vehicle_cc);
		if(!empty($policy_type_selection) && $policy_type_selection == '3'){
			if($rto_zone == 'A'){
			if($vehicle_cc <=1000)
				$percentage = 6.260;
			if($vehicle_cc <=1500)
				$percentage = 6.573;
			if($vehicle_cc > 1500)
				$percentage = 6.886;
		    }
		    if($rto_zone == 'B'){
			if($vehicle_cc <=1000)
				$percentage = 6.442;
			if($vehicle_cc <=1500)
				$percentage = 6.763;
			if($vehicle_cc > 1500)
				$percentage = 7.086;
		    }
		}
		return round((($idv*$percentage)/100));
	}

	public function spell_amount($number) {
		
		$hyphen      = '-';
		$conjunction = ' and ';
		$separator   = ', ';
		$negative = 'negative ';
		$decimal = ' point ';
		$dictionary = array (
				0 => 'Zero',
				1 => 'One',
				2 => 'Two',
				3 => 'Three',
				4 => 'Four',
				5 => 'Five',
				6 => 'Six',
				7 => 'Seven',
				8 => 'Eight',
				9 => 'Nine',
				10 => 'Ten',
				11 => 'Eleven',
				12 => 'Twelve',
				13 => 'Thirteen',
				14 => 'Fourteen',
				15 => 'Fifteen',
				16 => 'Sixteen',
				17 => 'Seventeen',
				18 => 'Eighteen',
				19 => 'Nineteen',
				20 => 'Twenty',
				30 => 'Thirty',
				40 => 'Fourty',
				50 => 'Fifty',
				60 => 'Sixty',
				70 => 'Seventy',
				80 => 'Eighty',
				90 => 'Ninety',
				100 => 'Hundred',
				1000                => 'Thousand',
				100000             => 'Lakh'
		);
		
		if (!is_numeric($number)) {
			return false;
		}
		
		if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
			// overflow
			trigger_error(
					'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
					E_USER_WARNING
					);
			return false;
		}
		
		if ($number < 0) {
			return $negative . $this->spell_amount(abs($number));
		}
		
		$string = $fraction = null;
		
		if (strpos($number, '.') !== false) {
			list($number, $fraction) = explode('.', $number);
		}
		
		switch (true) {
			case $number < 21:
				$string = $dictionary[$number];
				break;
			case $number < 100:
				$tens   = ((int) ($number / 10)) * 10;
				$units  = $number % 10;
				$string = $dictionary[$tens];
				if ($units) {
					$string .= $hyphen . $dictionary[$units];
				}
				break;
			case $number < 1000:
				$hundreds  = $number / 100;
				$remainder = $number % 100;
				$string = $dictionary[$hundreds] . ' ' . $dictionary[100];
				if ($remainder) {
					$string .= $conjunction . $this->spell_amount($remainder);
				}
				break;
			default:
				$baseUnit = pow(1000, floor(log($number, 1000)));
				$numBaseUnits = (int) ($number / $baseUnit);
				$remainder = $number % $baseUnit;
				$string = $this->spell_amount($numBaseUnits) . ' ' . $dictionary[$baseUnit];
				if ($remainder) {
					$string .= $remainder < 100 ? $conjunction : $separator;
					$string .= $this->spell_amount($remainder);
				}
				break;
		}
		
		if (null !== $fraction && is_numeric($fraction)) {
			$string .= $decimal;
			$words = array();
			foreach (str_split((string) $fraction) as $number) {
				$words[] = $dictionary[$number];
			}
			$string .= implode(' ', $words);
		}
		
		return $string;
	}

	public  function format_regno ( $reg_no ) {
		$arr_str = str_split($reg_no);
		$final_str = "";
		for($itr = 0; $itr< sizeof($arr_str ); $itr++) {
			if ($itr == 2 || $itr ==4 || $itr == 6) {
				$final_str = 	$final_str."-";
			}
			$final_str = $final_str . "". $arr_str[$itr] ;
		}
		return strtoupper ($final_str); 
	} 

}
