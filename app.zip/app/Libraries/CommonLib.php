<?php
namespace App\Libraries;
use Excel;
class CommonLib {
	
    public function export_xls($xlsname, $data, $hdr_arr = null ) {
		$data_set = array(
				"header_values" => $hdr_arr,
				"data_values" => $data
		);
		Excel::create( $xlsname, function($excel) use ($data_set) {
			$excel->sheet('Sheet1', function($sheet) use ($data_set) {
				$sheet->row(1,$data_set["header_values"]);
				$sheet->fromArray($data_set["data_values"], null, 'A2', false, false);
			});
				
		})->export('xlsx');
	}


} // end of class.

