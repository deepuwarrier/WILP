<?php
namespace App\Libraries;

use App\Models\Health\HealthRelationship;
use App\Constants\Health_Constants;
use App\Models\Health\HealthUserData;
use App\Helpers\Health\HealthHelper;
use DateTime;
use Log;

class HealthLib {

    public function get_readable_amount($amount){
        if($amount < 1000000){
            return substr($amount, 0, 1). ' lakhs';
        }

        if($amount < 10000000){
            return substr($amount, 0, 2). ' lakhs';
        }

        return 'ERR004';
        
    }

    public function format_number($num) {
    $explrestunits = "" ;
    if(strlen($num)>3) {
        $lastthree = substr($num, strlen($num)-3, strlen($num));
        $restunits = substr($num, 0, strlen($num)-3); // extracts the last three digits
        $restunits = (strlen($restunits)%2 == 1)?"0".$restunits:$restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
        $expunit = str_split($restunits, 2);
        for($i=0; $i<sizeof($expunit); $i++) {
            // creates each of the 2's group and adds a comma to the end
            if($i==0) {
                $explrestunits .= (int)$expunit[$i].","; // if is first value , convert into integer
            } else {
                $explrestunits .= $expunit[$i].",";
            }
        }
        $thecash = $explrestunits.$lastthree;
    } else {
        $thecash = $num;
    }
    return $thecash; // writes the final format where $currency is the currency symbol.
    }
     
    public function  get_tax_premium($premium){
        $a = (int)$premium / (1 + Health_Constants::GST);
        $tax = (int)$premium - $a;
        return round($tax);
    } 

    public function getUserdata($data) { 
        if(isset($data['product_type']))
            $req['selected_product'] = $data['product_type'];
        
        $req['productType'] = (count($data['agelist']) > 1 ) ? 'FF' : 'INDV' ;
        $req['doblist'] = $this->get_membersdob($data['agelist']);
        $req['agelist'] = implode("|", $data['agelist']);
        $req['memberslist'] = implode("|", $data['memberslist']);
        $req['genderlist'] = $this->get_genderlist($data['memberslist']);
        $req['suminsured'] = $data['sum_insured'];
        $req['tenure'] = '1';
        $req['pincode'] = $data['pincode'];
        $req['trans_code'] = $data['trans_code'];
        return $req; 
    }

    // Get #Age #no of adult & children based on DOB list
    public function get_membersdob($agelist) {
        $list = $agelist;
        $adult = $children = 0;
        for($i=3;$i<=11;$i++){
            $child_age[$i] = $i.'m';
        }   

        foreach($list as $age){
           if(in_array($age, $child_age)){
                $key = array_search($age, $child_age);
                $months = '-'.$key.' months';
                $effectiveDate = strtotime($months, strtotime(date("Y-m-d")));
                $birthdate = date("Y-m-d", $effectiveDate);
           }else{
                $birthdate = date("Y-m-d", strtotime($age. 'years ago'));
           }
           $dob[] = $birthdate;
            if($age >= 21){ $adult++; }
            if($age < 21){ $children++; }
        }
        $res['adult'] = $adult;
        $res['children'] = $children;
        $res['doblist'] = implode("|", $dob);
        return $res;
    }

    public function get_membersage($list) {
        foreach($list as $dob){
            $d = str_replace('/', '-', $dob);
            $brithdate =  date('Y-m-d', strtotime($d));
            $todate = date("Y-m-d");
            $bday = new DateTime($brithdate);
            $today = new DateTime($todate); 
            $diff = $today->diff($bday);
            $age = $diff->y;
            $agelist[] = $age; 
        }
        $res['agelist'] = implode("|", $agelist);
        return $res;
    }

    // Get #gender based on relationship list
    private function get_genderlist($memlist) {
        foreach ($memlist as $mem) {
            if($mem == 'SELF' || $mem == 'HUS' || $mem == 'FATH' || $mem == 'SONM' || $mem == 'BOTH' || $mem == 'FLAW' || $mem == 'MDTR' || $mem == 'GFAT') 
                { $gen = 'M'; $title ='MR';
            }
            if($mem == 'WIFE' || $mem == 'MOTH' || $mem == 'UDTR' || $mem == 'SIST' || $mem == 'MLAW' || $mem == 'MMBR' || $mem == 'GMOT') 
                { $gen = 'F'; $title = 'MS';
            }
            $memberlist[] = $gen; 
            $titlelist[] = $title; 
        }
        $res['genders'] = implode("|", $memberlist);
        $res['title'] = implode("|", $titlelist);
        return $res;
    }

    public function list_members($members){
        $flag_hus  = false; $flag_wife = false;
        $flag_son  = false; $flag_dau  = false;   
        $flag_bro  = false; $flag_sis  = false; 
        foreach ($members as $rel_mem) {
            if($rel_mem == 'HUS')  { $flag_hus  = true;  } 
            if($rel_mem == 'WIFE') { $flag_wife  = true; } 
            if($rel_mem == 'SONM') { $flag_son  = true;  }
            if($rel_mem == 'UDTR') { $flag_dau  = true;  } 
            if($rel_mem == 'BOTH') { $flag_bro = true;   } 
            if($rel_mem == 'SIST') { $flag_sis = true;   }   
        }
        if($flag_hus){
            if(!$flag_wife){ $members[] = 'WIFE'; } }   
        if($flag_wife){
            if(!$flag_hus){  $members[] = 'HUS'; }}
        // To retain SON in the list
        if($flag_son){
            foreach ($members as $rel_mem) {
                if(($key = array_search('SONM', $members)) !== false) {
                    unset($members[$key]); }
            }
        }
        // To retain Daughter in the list
        if($flag_dau){
            foreach ($members as $rel_mem) {
                if(($key = array_search('UDTR', $members)) !== false) {
                    unset($members[$key]); }
            }
        } 
        // To retain brother in the list
        if($flag_bro){
            foreach ($members as $rel_mem) {
                if(($key = array_search('BOTH', $members)) !== false) {
                    unset($members[$key]); }
            }
        }  
        // To retain sister in the list
        if($flag_sis){
            foreach ($members as $rel_mem) {
                if(($key = array_search('SIST', $members)) !== false) {
                    unset($members[$key]); }
            }
        }  
        $relmembers = HealthRelationship::select('rel_id','rel_name')->whereNotIn('rel_id', $members)->where('is_display', '1')->get();
        return $relmembers;
    } 

    public function list_rel_members($members) {
        return HealthRelationship::select('rel_id','rel_name')->whereNotIn('rel_id', ['SELF'])->where('is_display', '1')->get();
    }



    public function minus_year_from_date($date,$year){
        $date = strtotime("-".$year." year", strtotime($date));
        return  date("d-m-Y", $date);
    }
     public function add_days_with_date($date,$days){
        $date = strtotime("+".$days." days", strtotime($date));
        return  date("d-m-Y", $date);
    }
}
?>