<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarLib 
{
	
	public idvCalc(){
		// write your quote here
		return $val;
	}
	
}





