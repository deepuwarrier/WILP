<?php
namespace App\Libraries;

class InstaLib {
	
private function gen_trans_code ($modue_name){
	return $modue_name.(date("ymdHis")) . "". substr( microtime(), 4,4);
}
public function get_tw_tc() { return $this->gen_trans_code("TW");}
public function get_pc_tc() { return $this->gen_trans_code("PC");}
public function get_health_tc(){ return $this->gen_trans_code("HL");}
public function get_travel_tc() { return $this->gen_trans_code("TV");}


public function format_date_dMY($req_date) {
	return date('d-M-Y', strtotime( $req_date)); 
}
public function today_date_dMY(){ 	return date("d-M-Y");	}


} // end of class.

