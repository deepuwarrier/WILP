<?php 

namespace App\Libraries;
use Illuminate\Http\Request;
use App\Constants\Travel_Constants;
use App\Models\Travel\TravelCompanies;
use App\Models\Travel\TravelTataPremium;
use App\Models\Travel\TravelCoverageMap;
use App\Models\Travel\TravelCoverageMaster;
use App\Models\Travel\TravelUsrData;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;
use App\Helpers\Travel\Tata\TataQuotes;
use App\Helpers\Travel\Tata\TataProposal;
use App\Models\Travel\TravelPlan;
use Log;  

  class TravelLib {

    public function __construct(){
        date_default_timezone_set(Travel_Constants::$DEF_TIMEZONE); 
    }
    
    public function add_days_with_date($date,$days){
        $date = strtotime("+".$days." days", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function sub_days_with_date($date,$days){
        $date = strtotime("-".$days." days", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function minus_year_from_date($date,$year){
        $date = strtotime("-".$year." year", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function minus_days_from_date($date,$days){
        $date = strtotime("-".$days." days", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function minus_month_from_date($date,$month){
         Log::info($month);
        $month++;
        $date = strtotime("-".$month." month", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function add_year_to_date($date,$year){
        $date = strtotime("+".$year." year", strtotime($date));
        return  date("d-m-Y", $date);
    }

    public function calculateAge($date){
      $from = new \DateTime($date);
      $to   = new \DateTime('today');
      return $from->diff($to)->y;

    }

    public function  get_tax_premium($premium){
      $a = (int)$premium / (1 + Travel_Constants::$GST_CMN);
      $tax = (int)$premium - $a;
      return $tax;

    }

    public function get_string_between($string, $start, $end){
      $string = ' ' . $string;
      $ini = strpos($string, $start);
      if ($ini == 0) return '';
      $ini += strlen($start);
      $len = strpos($string, $end, $ini) - $ini;
      return substr($string, $ini, $len);
    }

    public function calculateYMD($date){
      $from = new \DateTime($date);
      $to   = new \DateTime('today');
      $age  = $from->diff($to)->y;
      if($age === 0){
        $age = $from->diff($to)->m;
        if($age === 0){
          $age = $from->diff($to)->d;
          return $age.'Days';
        }else {
          return $age.'M';
        }
      }

      return $age. 'Y';

    }
    public function map_student_duration($duration){
      switch($duration){
        case 'std_30' : return 30;
                        break;
        case 'std_60' : return 60;
                        break;
        case 'std_90' : return 90;
                        break;
        case 'std_120' : return 120;
                         break;
        case 'std_180' : return 180;
                         break;
        case 'std_270' : return 270;
                         break;
        case 'std_one' : return 364;
                         break;
        case 'std_456' : return 456;
                         break;
        case 'std_546' : return 546;
                         break;
        case 'std_636' : return 636;
                         break; 
        case 'std_two' : return 730;
                         break;                                                                                                                                                                  
      }
  }

  public function get_company_code($name){
        $cmp_tbl = new TravelCompanies;
        $column  = array('code');
        $check_values = array('name' => $name);
        $response = $cmp_tbl->get_data($column,$check_values); 
        return $response[0]['code'];
  } 
} // End of the class
