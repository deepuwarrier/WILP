<?php

namespace App\Libraries;

 class TwLib   
{
	public function session_key(){ return session()->getId();}
	
	public function update_session_key($skey) {
// 		session_id($skey); 						// not working
	}
	
	public function session_exists ($skey) { 
		if($skey == $this->sessioin_skey()) { return true;
		} else {	return false; 	}
	}
	
	public function date_today($dt_format) {
		return date($dt_format);
	}
	
	public function today_date(){
		$now = new \DateTime('now');
		return  $now->format('d/m/Y');
	}
	
	public function date_adjust_days( $pdate, $days) {
		return  date("d-M-Y", strtotime($pdate." ".$days." days"));
	}
	
	public function dt_adj_yrs ( $pdate, $years) {
		$dateadjusted = strtotime(date("d-M-Y", strtotime($pdate)) . " ". $years." year");
		return date('d-M-Y', $dateadjusted);
	}
	
	public function date_difference($date1, $date2) {
		$interval = date_diff(date_create($date1), date_create($date2));
		return $interval->y; 
	}
	
	public function date_isin_past ($date) { 
		$date_now = new \DateTime();
		if ($date_now > date_create($date)) {
			return true;
		}else{
			return false;
		}
	}
	
	public function date_dd_mm_yyyy($dt) { 	return date("d/m/Y", strtotime($dt));	
	}

	public  function get_fname($fullname) {
		return substr($fullname, 0, stripos($fullname, " "));
	}
	
	public  function get_lname($fullname) {
		return substr($fullname, stripos($fullname, " "));
	}
	
	
	public function manuf_date($yom) {
		return "01/01/".$yom;
	}

	public function get_militime () {
		return round(microtime(true) * 1000);
	}
	
	public function spell_amount($number) {
		
		$hyphen      = '-';
		$conjunction = ' and ';
		$separator   = ', ';
		$negative = 'negative ';
		$decimal = ' point ';
		$dictionary = array (
				0 => 'Zero',
				1 => 'One',
				2 => 'Two',
				3 => 'Three',
				4 => 'Four',
				5 => 'Five',
				6 => 'Six',
				7 => 'Seven',
				8 => 'Eight',
				9 => 'Nine',
				10 => 'Ten',
				11 => 'Eleven',
				12 => 'Twelve',
				13 => 'Thirteen',
				14 => 'Fourteen',
				15 => 'Fifteen',
				16 => 'Sixteen',
				17 => 'Seventeen',
				18 => 'Eighteen',
				19 => 'Nineteen',
				20 => 'Twenty',
				30 => 'Thirty',
				40 => 'Fourty',
				50 => 'Fifty',
				60 => 'Sixty',
				70 => 'Seventy',
				80 => 'Eighty',
				90 => 'Ninety',
				100 => 'Hundred',
				1000                => 'Thousand',
				100000             => 'Lakh'
		);
		
		if (!is_numeric($number)) {
			return false;
		}
		
		if (($number >= 0 && (int) $number < 0) || (int) $number < 0 - PHP_INT_MAX) {
			// overflow
			trigger_error(
					'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX,
					E_USER_WARNING
					);
			return false;
		}
		
		if ($number < 0) {
			return $negative . $this->spell_amount(abs($number));
		}
		
		$string = $fraction = null;
		
		if (strpos($number, '.') !== false) {
			list($number, $fraction) = explode('.', $number);
		}
		
		switch (true) {
			case $number < 21:
				$string = $dictionary[$number];
				break;
			case $number < 100:
				$tens   = ((int) ($number / 10)) * 10;
				$units  = $number % 10;
				$string = $dictionary[$tens];
				if ($units) {
					$string .= $hyphen . $dictionary[$units];
				}
				break;
			case $number < 1000:
				$hundreds  = $number / 100;
				$remainder = $number % 100;
				$string = $dictionary[$hundreds] . ' ' . $dictionary[100];
				if ($remainder) {
					$string .= $conjunction . $this->spell_amount($remainder);
				}
				break;
			default:
				$baseUnit = pow(1000, floor(log($number, 1000)));
				$numBaseUnits = (int) ($number / $baseUnit);
				$remainder = $number % $baseUnit;
				$string = $this->spell_amount($numBaseUnits) . ' ' . $dictionary[$baseUnit];
				if ($remainder) {
					$string .= $remainder < 100 ? $conjunction : $separator;
					$string .= $this->spell_amount($remainder);
				}
				break;
		}
		
		if (null !== $fraction && is_numeric($fraction)) {
			$string .= $decimal;
			$words = array();
			foreach (str_split((string) $fraction) as $number) {
				$words[] = $dictionary[$number];
			}
			$string .= implode(' ', $words);
		}
		
		return $string;
	}
	
	public function get_curr_year(){
		$now = new \DateTime('now');
		return $now->format('Y');
	}
	
	public function array_to_xml($value_arr,  $root_str) {
		$my_xml = new \SimpleXMLElement("<".$root_str."></".$root_str.">");
		$this->arr_to_xml($value_arr, $my_xml);
		$str_value =  $my_xml->asXML();
		return $str_value; 
	} 
	private function arr_to_xml($value_arr, $xml_ob) {
		foreach($value_arr as $key => $value) {
			if(is_array($value)) {
				if(!is_numeric($key)){
					$subnode = $xml_ob->addChild("$key");
					$this->arr_to_xml($value, $subnode);
				}
				else{
					$subnode = $xml_ob->addChild("");
					array_to_xml($value, $subnode);
				}
			}
			else {
				$xml_ob->addChild("$key","$value");
			}
		}
	}

	public function changeFormat($date,$format){
		$date = str_replace('/','-',$date);
		$date = strtotime($date);
		return date($format,$date);
	}
	
	
 } // end of method 




