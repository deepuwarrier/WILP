<?php

namespace App\Libraries;

/**
 *
 */
class ValidatorLib
{
	private $msg = '';

	private $preg_match_array = [
									'empty' =>  [
													'p_match' =>'/^.+$/',
													'p_msg' => 'Please enter valid value. Filed can not be empty.'
												],
									'mobile' => [
													'p_match' =>'/^[0-9]{10}$/',
													'p_msg' => 'Please enter valid Mobile number.'
												],
									'number' => [
													'p_match' =>'/^\d+$/',
													'p_msg' => 'Please enter valid Number.'
												],
									'customer_name' =>  [
															'p_match' => '/^([a-zA-Z]{0,14}).(\\s[a-zA-Z]{1,14}){1,5}$/',
															'p_msg' => 'Valid first name, last name required.'
														],
									'customer_panno' => [
															'p_match' => '/^[a-zA-Z0-9]{10}$/',
															'p_msg' => 'Valid PAN required.'
														],
									'customer_dob' => 	[
															'p_match' => '/^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$/',
															'p_msg' => 'Valid DOB required.'
														],
									'customer_aadharno' => [
															'p_match' => '/^[0-9]{4}[-][0-9]{4}[-][0-9]{4}$/',
															'p_msg' => 'Valid aadhar number required.'
														],
									'customer_email' => [
															'p_match' => '/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,10})$/',
															'p_msg' => 'Valid email required.'
														],
									'customer_add1' => 	[
															'p_match' => '/^[a-zA-Z0-9 \/]{2,15}$/',
															'p_msg' => 'Valid house address required.'
														],
									'customer_add2' => 	[
															'p_match' => '/^[a-zA-Z0-9 ]{5,40}$/',
															'p_msg' => 'Valid street address required.'
														],
									'customer_add3' => 	[
															'p_match' => '/^[a-zA-Z0-9 ]{5,40}$/',
															'p_msg' => 'Valid locality address required.'
														],
									'customer_pincode' => [
															'p_match' => '/^[0-9]{6}$/',
															'p_msg' => 'Valid locality address required.'
														],
									'tw_reg_no' => 		[
															'p_match' => '/^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$/',
															'p_msg' => 'Reg. number format is wrong.'
														],
									'tw_engine_no' => 	[
															'p_match' => '/^[a-zA-Z0-9]{8,30}$/',
															'p_msg' => 'Valid engine no. required.'
														],
									'tw_chasis_no' => 	[
															'p_match' => '/^[a-zA-Z0-9]{10,40}$/',
															'p_msg' => 'Valid chassis no. required.'
														],
									'color' => 			[
															'p_match' => '/^[a-zA-Z ]{3,15}$/',
															'p_msg' => 'Valid color required.'
														],
									'tw_pre_policy' => 	[
															'p_match' => '/^[a-zA-Z0-9 \/-]{8,30}$/',
															'p_msg' => 'Valid pre. policy number required.'
														],
									'nominee_name' => 	[
															'p_match' => '/^[a-zA-Z ]{4,30}$/',
															'p_msg' => 'Valid nominee name required.'
														],
									'pre_insurer_addr' =>
														[
															'p_match' => '/^[a-zA-Z0-9 \/]{8,30}$/',
															'p_msg' => 'Previous insurrer address min 8 max 30 char.'
														],
									'pre_claim_count' =>
														[
															'p_match' => '/^[1-9]{1}$/',
															'p_msg' => 'Min 1 max 9 claims allowed.'
														],
									'pre_claim_amount' =>
														[
															'p_match' => '/^[0-9]{2,7}$/',
															'p_msg' => 'Valid claim amount required.'
														],
									'pc_reg_no'		=> 	[
															'p_match' => '/^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$/',
															'p_msg' => 'Reg. number format is wrong.'														],
									'customer_gstin' => [
															'p_match' => '/^\\d{2}[a-zA-Z]{5}\\d{4}[a-zA-Z]{1}\\d[zZ]{1}[a-zA-Z\\d]{1}$/',
															'p_msg'	=> 'Valid GSTIN number.'
														],
									'pc_engine_no'	=> 	[
															'p_match' => '/^([\\da-zA-Z\][-]*)+$/',
															'p_msg'	=> 'Valid engine no. required.'
														],
									'pc_chasis_no'	=> 	[
															'p_match' => '/^([\\d]*[a-zA-Z]*)+$/',
															'p_msg'	=> 'Valid chassis no. required.'
														],
									'pc_pre_policy'	=> 	[
															'p_match' => '/^([\\da-zA-Z\][-]*)+$/',
															'p_msg'	=> 'Valid pre. policy number required.'
														],
									'pc_customer_aadharno'	=>
														[
															'p_match' => '/^[0-9]{12}$/',
															'p_msg'	=> 'Valid aadhar number required.'
														],
									'pc_customer_dob' =>
														[
															'p_match' => '/^[0-9]{4}\-[0-9]{1,2}\-[0-9]{1,2}$/',
															'p_msg' => 'Valid DOB required.'
														],
									'alpha_with_space_comma'	=>
														[
															'p_match' => '/^[a-zA-Z ,]{3,70}$/',
															'p_msg' => 'Field should contains alphabets with (,) comma separated.'
														]
								];

	public function proposalSubmit($validate_data){
		$err_txt = "";
		foreach ($validate_data as $key => $value) {
			$this->isValid($key,$value);
		}
		$ret_data = array("verror" => false, "verror_txt" => $this->msg );
		if(strlen($this->msg) != 0) {
			$ret_data["verror"] = true;
		}
		return $ret_data;
	}

	private function isValid($field,$field_value){
		if(is_array($field_value)){
			$this->checkArray($field,$field_value);
			// dd($msg);
		} else {
			$this->msg .=  ((isset($this->preg_match_array[$field]['p_match'])) && (!(preg_match($this->preg_match_array[$field]['p_match'], $field_value))))?$this->preg_match_array[$field]['p_msg'].' <br>':'';
		}
	}

	private function checkArray($field,$field_value){
		foreach ($field_value as $key => $value) {
			if(!is_array($value)){
				$this->isValid($field,$value);
				// $msg  .=  ((isset($this->preg_match_array[$field]['p_match'])) && (!(preg_match($this->preg_match_array[$field]['p_match'], $value))))? $key.' '.$field.' '.$this->preg_match_array[$field]['p_msg'].' <br>':'';
			} else {
				$this->checkArray($field,$value);
			}
		}
		// dd($msg);
		// return $msg;
	}
}


?>