<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;


class InstaCategory extends Model
{
    
    
    protected $table = 'insta_m_category';

    public $timestamps = false;

    protected $fillable =['id','category_name','category_code','category_url', 'is_display'];

   
    
    public static function getInstaCategory($category_url){
        return self::select('category_name','category_code','category_url', 'is_display')
        ->where('category_url', $category_url)
        ->where('is_display', '1')
        ->first();
    }

    
}