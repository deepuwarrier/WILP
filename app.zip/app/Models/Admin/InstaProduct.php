<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;


class InstaProduct extends Model
{
    
    
    protected $table = 'insta_m_products';

    public $timestamps = false;

    protected $fillable = ['id', 'product_code', 'product_name', 'unique_features' , 'product_url', 'inclusion', 'exclusion', 'company', 'price', 'emi_details', 'should_buy', 'should_not_buy', 'image', 'video', 'product_ctg_ref', 'is_display'];

   
    
    public static function getInstaProduct($product_url, $category_code){
        return self::select('product_code', 'product_name', 'unique_features' , 'product_url', 'inclusion', 'exclusion', 'company', 'price', 'emi_details', 'should_buy', 'should_not_buy', 'image', 'video', 'product_ctg_ref', 'is_display')
        ->where('product_url', $product_url)
        ->where('product_ctg_ref', $category_code)
        ->where('is_display', '1')
        ->get();
    }

    
}