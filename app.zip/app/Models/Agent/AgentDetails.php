<?php

namespace App\Models\Agent;

use Illuminate\Database\Eloquent\Model;
use App\Helpers\EmailHelper;
use App\Helpers\Car\CarHelper;
use App\Http\Controllers as C;
use App\Constants\Common_Constants;
use App\Models\EmailModel;
use Illuminate\Support\Facades\DB;
use Hash;

class AgentDetails extends Model
{
    protected $table = Common_Constants::INSTA_USERS_TABLE;

    protected $fillable = ['eamail','password'];

    public static function validateUserLogin($value)
    {
		//edited by shailesh
		if(is_array($value)){
			$agent_email = $value['agent_email'];
			$password = $value['password'];
		}else{
			$agent_email = $value->agent_email;
			$password = $value->password;
		}
		
		$use_details = Self::where ( 'email', $agent_email )->first (); 
		if ($use_details) {
			$hashedPassword = $use_details->password;
			if (Hash::check($password, $hashedPassword)) {
                session([
                		'user_code'=>$use_details->user_code,
                		'user_email'=>$use_details->email,
                		'username'=>$use_details->name
                ]);
                $agent_store = new C\Customers\Customers();
                // $agent_store->agentUserCode($use_details->user_code);
//                 $agent_store->storeUserCode($use_details->user_code);
                ($agent_store->getUserType($use_details->user_code) ==  Common_Constants::INSTA_USER_TYPE_AGENT) ? session(['user_agent'=>true]) : session()->forget('user_agent');
			    return '1'; // login success. 
			} else
			{
				return '0';     // login fail
			}
		} else {
			return '2';    // default. 
		}
    }

    public static function checkUser($id,$value){
        $user_id = Self::firstOrNew([$id => $value]);
        return $user_id;
    }

    public static function checkUserType($user_code){

        $user_type = Self::where(['user_code' => $user_code])->first();
        return $user_type;
    }

    public static function registerUser($value){
        $status = false;
        $name = $value->register_name;
    	$email = $value->register_email;
        $mobile_number = $value->register_mobile_number;
        $register_password = $value->register_password;
    	$events_id  = Common_Constants::REGISTRATION_EMAIL_EVENT_ID;
    	$password = Hash::make($register_password);
        $registered_email = Self::checkUser('email',$email)->email;
        $registered_mobile_number = Self::checkUser('mobile_number',$mobile_number)->mobile_number;
    	if(isset($registered_email)){
    		return '1';
    	} elseif(isset($registered_mobile_number)){
            return '2';
        } else {
			$email_helper = new EmailHelper;
            $email_model = new EmailModel;
	    	$from = Common_Constants::DEFAULT_FROM_EMAIL;
	    	$data_email = array('email'=>$email,'name'=>$name,'password' => 'which you have entered');
            $user_data = ['name'=>$name,'mobile_number'=>$mobile_number,'email'=>$email,'password'=>$password];
    		//$data = DB::table('insta_users')->insert($user_data);
            $data = DB::table(Common_Constants::INSTA_USERS_TABLE)->insertGetId($user_data);          
    		if($data){
                session(['user_id'=>$data,'user_email'=>$email,'username'=>$name]);
                // $previous_user_code = DB::table(Common_Constants::INSTA_USERS_TABLE)->select('user_code')->where('id','<',$data)->orderBy('id', 'desc')->limit(1)->first()->user_code;
                DB::table(Common_Constants::INSTA_USERS_TABLE)->where('id',$data)->update(['user_code'=>'U'.$data]);
                session(['user_code'=>'U'.$data]);
                $subject = 'New User Registered to Instainsure.com';
                $email_ids = $email_model->getEmailId($events_id);
                $registration_content_internal = view('layouts.registration_email_internal',['name'=>$name,'number'=>$mobile_number,'email'=>$email])->render();
                foreach ($email_ids as $key => $value) {
                    $to = $value->email;
                    if($status = $email_helper->instaMail($from,$name,$to,$subject,$registration_content_internal)){
                        $status = true;
                    }
                }
                if ($status === true) {
                    $subject = 'Thanks for registering with Instainsure.com';
                    $registration_content_external = view('layouts.registration_email',$data_email)->render();
                    $email_helper->instaMail($from, 'Instainsure.com', $email, $subject, $registration_content_external);
                }
    			return '3';
    		} else {
    			return '0';
    		}
    	}
    }

    public static function resetpassword($value){
        $email = $value->forgetPassword_email;
        $new_password = str_random(10);
        $user_detail = Self::firstOrNew(['email' => $email]);
        $id = $user_detail->email;
        
        
        if(!isset($id)){
            return '0';
        } else {
            $name = $user_detail->name;
            $email_helper = new EmailHelper;
            $subject = 'Password Reset Mail';
            $from = Common_Constants::DEFAULT_FROM_EMAIL;
            $to = $email; 
            $data = array('email'=>$email,'name'=>$name,'password' => $new_password);
            $content = view('layouts.forgot_password_email',$data)->render();
            $data = array('from'=>$from,'name'=>'','to'=>$to,'subject'=>$subject,'content'=>$content);
            $status = $email_helper->instaMail($from,'',$to,$subject,$content);
            $user_data = ['password'=>Hash::make($new_password)];
            $data = Self::where('email',$email)->update($user_data);
            if($data){
                return '1';
            } else {
                return '0';
            }
        }
    }

    public static function changePassword($value){
        $user_id = session('user_id');

        $old_password = $value->old_password;
        $new_password = $value->new_password;
        $confirm_password = $value->confirm_password;
        $user_password_details = Self::where('id', $user_id)->first();
            
        if($user_password_details){
            $hashedPassword = $user_password_details->password;
            if (Hash::check($old_password, $hashedPassword)) {
                if($new_password === $confirm_password){
                    Self::where('id', $user_id)->update(['password' => Hash::make($new_password)]);
                    return '1';
                } else {
                    return '2'; // New password and old password doesnot match
                }
                
            } else
            {
                return '0'; // Old password doesnot match
            }
        }
    }


    public static function insuranceOfferRegisterUser($value){
        $status = false;
        $email_model = new EmailModel;
        $source = Common_Constants::CAR_INSURANCE_OFFER_SOURCE;
        $email = $value->car_offer_email;
        $mobile_number = $value->car_offer_mobile;
        $offer_month = $value->car_offer_insu_exp_month;
        $register_password = $value->car_offer_email;
        $password = Hash::make($register_password);
		
        $registered_email = Self::checkUser('email',$email)->email;
		
        $registered_mobile_number = Self::checkUser('mobile_number',$mobile_number)->mobile_number;
        if(isset($registered_email)){
			//set session if user email exists
			 session(['user_id'=>$registered_email,'user_email'=>$email,'username'=>$email]);
            return '1';
        } elseif(isset($registered_mobile_number)){
			//set session if user mobile exists
			 session(['user_id'=>$registered_mobile_number,'user_email'=>$email,'username'=>$email]);
            return '2';
        } else {
            $email_helper = new EmailHelper;
            $subject = 'Registration Email';
            $from = Common_Constants::DEFAULT_FROM_EMAIL;
            $to = $email; 
            $data = array('offer_month'=>$offer_month,'email'=>$email,'name'=>'','source'=>$source,'mobile_number'=>$mobile_number,'password' => 'which you have entered');
            $content_internal = view('layouts.admin_registration_email',$data)->render();
            $content_external = view('layouts.car_offer_reg_email',$data)->render();
            $data = array('from'=>$from,'name'=>'','to'=>$to,'subject'=>$subject,'content'=>$content_internal);
            $user_data = ['mobile_number'=>$mobile_number,'email'=>$email,'password'=>$password,'source'=>'offer'];
            $data = Self::insertGetId($user_data);			
            if($data){					
				session(['user_id'=>$data,'user_email'=>$email,'username'=>$email]);
                $events_id = Common_Constants::CONTACT_US_EVENT_ID;
                $email_ids = $email_model->getEmailId($events_id);
                foreach ($email_ids as $key => $value) {
                    $to_internal = $value->email;
                    //$data['to'] = $to_internal;
                    if($email_helper->instaMail($from,'', $to_internal, $subject, $content_internal)){
                        $status = true;
                    } else {
                        dd('error ');
                    }
                }
                if ($status === true) {
                    $email_helper->instaMail($from,'',$to,$subject,$content_external);
                    return '3';
                }
            } else {
                return '0';
            }
        }
    }
}
