<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;

class InstaConfigM extends Model {

    protected $table = 'insta_c_config';

    public function config_by_name( $config_name ) {
    	return InstaConfigM::select('*')->where('config_name', $config_name)->first();
    }
    
    public function config_by_group( $config_group ) {
    	return InstaConfigM::select('*')->where('config_group', $config_group)->get();
    }
    
    
    

}
