<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;

class InstaCounterM extends Model {

    protected $table = 'insta_t_counter';

    public function get_cntr( ) {
    	return InstaCounterM::select('*')->first();
    }

    
    public function set_cntr($cntr_data){
    	InstaCounterM::where("cntr_key", "QUOTE_CNTR")->update($cntr_data);
    }
    
    
    

}
