<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;

class InstaPolicyM extends Model {

    protected $table = 'insta_t_policy';

    public function insert_record( $data ) {  
	    	try {
	    		InstaPolicyM::insert($data);
	    	} catch (Exception $e) {  \Log::error($e->getMessage());
	    	}
    }//
    
    public function between_dates($from_date, $to_date, $filter_param = null) { 
    	$query = InstaPolicyM::selectRaw("branch_code, module_name, insurer_code, agent_name, SUM(policy_count) as policy_count, SUM(brokerage_value) as brokerage_value, SUM(od_premium) as od_premium, SUM(tp_premium) as tp_premium ")
    ->whereBetween('policy_date', array($from_date, $to_date));
  
    
    foreach ($filter_param as $where_key => $where_value){
    		$query = $query->where($where_key,$where_value);
    }
    return $query->groupBy("branch_code", "module_name", "insurer_code", "agent_name" )->get();
    
    }//
    
    public function get_filter_list($column_name) {
    	return InstaPolicyM::select($column_name)->distinct()->get();
    }
    
    public function policy_count($from_date, $to_date,$filter_param,$filter){
        // dd($from_date, $to_date,$filter_param,$filter);
        $query = InstaPolicyM::selectRaw("SUM(policy_count) as policy_count");
        if(!is_null($filter)){
            $query->selectRaw($filter);
        }
        $query = $query->whereBetween('policy_date', array($from_date, $to_date));
        foreach ($filter_param as $where_key => $where_value){
            $query = $query->where($where_key,$where_value);
        }
        // $query->groupBy("branch_code");
        $query->groupBy($filter);
        // $query->groupBy("insurer_code");
        // $query->groupBy("agent_name");
        // dd($query->get()->toArray());
        return $query->get();
    }
} // end 
