<?php

namespace App\Models\Base;

use Illuminate\Database\Eloquent\Model;

/**
 * @author Vivek Shah
 *
 */
class InstaTransStatus extends Model {
	protected $table = 'insta_m_trans_status';

	/**
	 * @return unknown
	 */
	public static function getStatusName($status_code) {
		return !empty(Self::where('status_code',$status_code)->first())?Self::where('status_code',$status_code)->first()->toArray()['status_name']:'NA';
	}

}
