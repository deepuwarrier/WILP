<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;

Class InsurerMasterM extends Model{
	protected $table = 'insta_m_insurers';

	public function get_insurer_name($insurer_code){
		$data =  self::select('insurer_name')->where(['insurer_code'=>$insurer_code])->first();
		
		if($data)
			return $data->insurer_name;
		
		return '';
	}
}