<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;

class UserMasterM extends Model {

    protected $table = 'insta_m_users';

    public function emails_by_user_type($user_type_code){ 
    	return UserMasterM::select('name', 'email')->where('user_type', $user_type_code)->get();
    }
    
    public function user_details($user_code) {
    	return UserMasterM::select('*')->where('user_code', $user_code)->first();
    }
    
    public function user_by_email($user_email) {
    	return UserMasterM::select('*')->where('email', $user_email)->first();
    }

    public function user_by_phone($user_phone) {
    	return UserMasterM::select('*')->where('mobile_number', $user_phone)->first();
    }

    public function user_email($where){
        return UserMasterM::select('name', 'email')->where($where)->get();
    }

    public function get_admin_mails(){
        return $this->user_email(['user_type'=>1]);
    }

    public function get_agent_mails($agent_code = NULL){
        if(!$agent_code)
            return $this->user_email(['user_type'=>3]);
        return $this->user_email(['user_type'=>3,'user_code'=>$agent_code]);
    }
}
