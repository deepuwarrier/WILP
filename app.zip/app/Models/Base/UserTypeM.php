<?php
namespace App\Models\Base;
use Illuminate\Database\Eloquent\Model;
use App\Models\Base\UserMasterM;

class UserTypeM extends Model {

    protected $table = 'insta_m_usertype';

    public function get_user_type( $user_type_code ) {
    	return UserTypeM::select('*')->where('usertype_code', $user_type_code)->first();
    }

    public function mails(){
    	return $this->hasMany('App\Models\Base\UserMasterM', 'user_type', 'auto_id');
    }

    public function get_admin_email_list(){
    	return self::where(['usertype_code'=>'ADMIN'])->with('mails')->first();
    }

    public function get_agent_email_list($agnet_code = NULL){
    	if(!$agnet_code)
    		return self::where(['usertype_code'=>'AGENT'])->with('mails')->first();

    	return self::where(['usertype_code'=>'AGENT'])->whereHas('mails',function($query) use($agnet_code){
    		return $query->where(['user_code'=>$agnet_code]);
    	})->first();
    }
}
