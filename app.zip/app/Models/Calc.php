<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Calc extends Model {

    protected $table = 'calc_category';

    public function getCategories() {
        $query = DB::table('insta_calc_category')->where('is_display','=',1)->orderBy('display_order', 'ASC');
        return $query->get();
    }
    
    public function getProducts() {
        $query = DB::table('insta_calc_product')->where('is_display','=',1)->orderBy('display_order', 'ASC');
        return $query->get();
    }
    
    public function getCategoryProduct($product_id) {
       $users = DB::table('insta_calc_product')
            ->leftJoin('insta_calc_category', 'insta_calc_product.calc_category_id', '=', 'insta_calc_category.calc_category_id')
            ->where('insta_calc_product.calc_product_id', '=', $product_id)
            ->where('insta_calc_product.is_display', '=',1)
            ->first();
       return $users;
    }

}
