<?php
namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarConfig extends Model
{
    protected $table = 'car_m_config';

    public function getValue($key) {
		return Self::select('config_value')->where('config_name',"".$key)->get();
	}

	public function getKeyValueList(){
		return Self::select('config_name','config_value')->get();
	}
	
	public function getKeyList(){
		return Self::select('config_name')->get();
	}
}
