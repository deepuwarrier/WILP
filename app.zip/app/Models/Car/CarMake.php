<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;
use App\Constants\Car_Constants;

class CarMake extends Model
{
	protected $table = Car_Constants::CAR_MAKE_TABLE;
	
	
	public function getCarMakes(){
// 		return CarMake::select('make_id', 'make')->orderBy('make', 'ASC')->get(); // Added by vivek on 7 march for showing all make
		return CarMake::select('make_code', 'make_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}

	public function getMakeId($code,$ref_col){	
		$make = self::select($ref_col)
    			->where('make_code',$code)
    			->first();
    	if($make)
    		return $make->$ref_col;
    	return 0;
    }

    public function getCode($code,$ref_col){
    	$make = self::select($ref_col)
    			->where('make_code',$code)
    			->first();
    	if($make)
    		return $make->$ref_col;
    	return NULL;	
    }

}





