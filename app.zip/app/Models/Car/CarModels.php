<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;
use App\Constants\Car_Constants;

class CarModels extends Model
{
	protected $table = Car_Constants::CAR_MODEL_TABLE;
	
	
	public function getCarModels($make_code){
		// return CarModels::select('model_id', 'model')->where('make',$make_code)->orderBy('model', 'ASC')->get(); //By vivek
		return CarModels::select('model_code', 'model_name')->where('make_code_ref',$make_code)->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}

	public function getModelId($code,$ref_col){	
		$make = self::select($ref_col)
    			->where('model_code',$code)
    			->first();
    	if($make)
    		return $make->$ref_col;
    	return 0;
    }

    public function getCode($code,$ref_col){
    	$make = self::select($ref_col)
    			->where('model_code',$code)
    			->first();
    	if($make)
    		return $make->$ref_col;
    	return NULL;
    }
}





