<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarOdRates extends Model
{
    protected $table = 'car_m_odrates';

    public function getOdPerValuePer($zone,$age,$cc){

    	$data = Self::select('od_per')
    			->where('zone',$zone)
    			->where('age',$age)
    			->where('cc_till',$cc)
    			->first()
    			->od_per;
        return $data;
    }
}
