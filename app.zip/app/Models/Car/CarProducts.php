<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarProducts extends Model
{
    protected $table = "car_c_product";

    public function getProductIsDisplay(){
    	$data = Self::select('product_id','is_display','breaking_case')->get();
        $new_data = array();
        foreach ($data as $key => $value) {
            $new_data[$value->product_id] = $value->is_display;
            $new_data['breaking_case_'.$value->product_id] = $value->breaking_case;
        }
        return $new_data;
    }

    public function getInsurerList(){
    	$data = $this->select('product_id','product_name','product_img','insurer_id','is_display')->get();
        $new_data = array();
        foreach ($data as $key => $value) {

        	if(!empty($new_data)){
        		foreach ($new_data as $key1 => $value1) {
        			$new_data[$value->product_id] = ['product_id'=>$value->product_id,'product_img'=>$value->product_img,'insurerId'=> $value->insurer_id,'insurerName' => $value->product_name];    
        		}
        	} else {
        		$new_data[$value->product_id] = ['product_id'=>$value->product_id,'product_img'=>$value->product_img,'insurerId'=> $value->insurer_id,'insurerName' => $value->product_name];	
        	}
        }
        return $new_data;	
    }

    public function getTataProductId(){
        $data = $this->select('product_id')->where('insurer_id','like','tata_%')->get();
        $new_data = array();
        foreach ($data as $key => $value) {
            if(!empty($new_data)){
                foreach ($new_data as $key1 => $value1) {
                    $new_data[$value->product_id] = ['product_id'=>$value->product_id];    
                }
            } else {
                $new_data[$value->product_id] = ['product_id'=>$value->product_id];   
            }
        }
        return $new_data;
    }

    public function getTataProductDetails(){
        $data = $this->select('product_id','product_name','product_img','insurer_id')->where('insurer_id','like','tata_%')->get()->toArray();
        $formated_key = [];
        foreach ($data as $key => $value) {
            foreach ($value as $key1 => $value1) {
                $formated_key[$value['product_id']][$key1] = $value1;
            }
        }
        return $formated_key;
    }

    public function getCompDetails($product_id,$details = null){
        if(!$details)
            $details = ['product_id','product_name','product_img','insurer_id'];

        return $this->select($details)->where('product_id',$product_id)->first();
    }

    public function getCompProductDetails($product_id){
        $data = $this->select('product_id','product_name','product_img','insurer_id')->where('product_id',$product_id)->get()->toArray();
        $formated_key = [];
        foreach ($data as $key => $value) {
            foreach ($value as $key1 => $value1) {
                $formated_key[$value['product_id']][$key1] = $value1;
            }
        }
        return $formated_key;
    }
}
