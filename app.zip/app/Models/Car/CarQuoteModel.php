<?php

namespace App\Models\Car;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class CarQuoteModel extends Model
{
    function __construct() {
    	
    }

    function getValue($tablename,$field,$where_condition){
    	$query = DB::table($tablename);
		$query->where($field,$where_condition);
		return $query->first();
    }

    function getCoversValue(){
    	$query = DB::table('car_m_covers');
    	$query->select('cover_api_id','cover_name','cover_description');
	$query->where('is_display',1);
        $query->orderBy('cover_order', 'ASC');
	return $query->get();
    }

    function getCovers(){
        $query = DB::table('car_m_covers');
        $query->select('cover_api_id','cover_name','cover_description');
        $query->where('is_display',1);
            $query->orderBy('cover_order', 'ASC');
        return $query->get();
    }

}
