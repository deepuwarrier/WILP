<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarRsgiIDV extends Model
{
    protected $table = 'car_m_rsgi_idv';

    public function getIdvValue($code,$column_name) {
		return Self::select($column_name)->where('model_code',$code)->first();
	}

	public function getCarMakeNames($code){
		return CarMake::select('make_name')->where('model_code', $make_code)->first();
	}
}
