<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class CarRto extends Model
{
    protected $table = 'car_m_rto';
    public function get_rto($state_id){
    	return CarRto::select('rto_id', 'rto_code')->where('state',$state_id)->get();
    }

    public function get_rto_from_code($rto){
		$query = DB::table('car_m_rto');
		$query->where('rto_code',$rto);
		return $query->get();
	}

	public function getRtoZone($rto){
		$data =	Self::select('zone')
        		->where('rto_code',$rto)
        		->first()
        		->zone;
        return $data;
    }

    public function get_rsgi_city_from_rto_code($rto){
        $query = Self::select('rsgi_rto_city_name') 
                ->where('rto_code',$rto);
        return $query->first();
    }

    public static function getRTOData($rto,$field){
        $query = Self::select($field) 
                ->where('rto_code',$rto);
        return $query->first();
    }

    public function getRtoName($code) {
        return self::select('rto')->where(['rto_code'=>$code])->first()->rto;
    }
    
    public function getData($code,$field) {
        // if(is_array($field))
        //     $field = implode(',',$field);
        return self::select($field)->where(['rto_code'=>$code])->first();
    }

    public function rto_list() {
        return Self::select('*')->get();
    }
}
