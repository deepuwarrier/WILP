<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarState extends Model
{
    protected $table = 'car_m_state2';
    
    public function  get_state($all=0){
    	return CarState::select('state_id','state','state_code')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
    }

    public function get_rsgi_region($state_id)
    {
    	return Self::select('rsgi_region')
    					->where('code',$state_id)
    					->where('is_display', 1)
    					->first();
    }

    public function get_state_code($state_id,$ref_col){
        return Self::select($ref_col)
                        ->where('code',$state_id)
                        ->where('is_display', 1)
                        ->first()->$ref_col;
    }
}
