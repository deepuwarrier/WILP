<?php

namespace App\Models\Car;

use App\Models as M;
use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class CarTData extends Model {

    protected $table = 'car_t_userdata';
    // protected $primaryKey = 'session_id';
    protected $primaryKey = 'trans_code';
    public $timestamps = false;
    public $incrementing = false;
    protected $fillable = [
        'otp_id',
        'insurer_id',
        'product_id',
        'idv_opted',
        'request_id',
        'agent_code',
        't_status',
        'client_ip',
    ];

    public function __construct(array $attributes = []) {
        parent::__construct($attributes);
        // add filable field
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_PROPOSALLOG);
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_USERLOG);
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_QUOTELOG);
    }

    public function set_by_tc($trans_code, $data) {
        self::where('trans_code',$trans_code)->update($data);
    }

    public function get_by_tc($trans_code) {
        return self::all()->where('trans_code', $trans_code)->first();
    }
    
    public function get_by_sc($ssn_key) {
        return self::all()->where('session_id',$ssn_key)->first();
    }

	public function checkTransaction($transaction_code) {
		$car_helper = new CarHelper;
		// $suid = $car_helper->getSuid();
		return self::select('t_status')->where(['trans_code' => $transaction_code])->first();
	}

   /* public static function checkTransaction() {
        return self::select('t_status')->where(['session_id' => CarHelper::getSuid()])->first();
    }
*/
	public function setGstinAttribute($value) {
        $this->attributes['gstin'] = strtoupper($value);
    }

    public function setTransCodeAttribute($value) {
        $this->attributes['trans_code'] = strtoupper($value);
    }

    public function setSessionIdAttribute($value) {
        $this->attributes['session_id'] = strtoupper($value);
    } 

    public function setUsrFirstnameAttribute($value) {
        $this->attributes['usr_firstname'] = strtoupper($value);
    }

    public function setUsrLastnameAttribute($value) {
        $this->attributes['usr_lastname'] = strtoupper($value);
    }

    public function setUsrEmailAttribute($value) {
        $this->attributes['usr_email'] = strtoupper($value);
    }

    public function setUsrStreetAttribute($value) {
        $this->attributes['usr_street'] = strtoupper($value);
    }

    public function setUsrLocalityAttribute($value) {
        $this->attributes['usr_locality'] = strtoupper($value);
    }

    public function setUsrHousenoAttribute($value) {
        $this->attributes['usr_houseno'] = strtoupper($value);
    }

    public function setVehChassisnoAttribute($value) {
        $this->attributes['veh_chassisno'] = strtoupper($value);
    }

    public function setVehEngNoAttribute($value) {
        $this->attributes['veh_eng_no'] = strtoupper($value);
    }

    public function setNomineeNameAttribute($value) {
        $this->attributes['nominee_name'] = strtoupper($value);
    }

    public function setPremUsrStreetAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_street'] = strtoupper($value);
        else
            $this->attributes['prem_usr_street'] = $this->getAttribute('usr_street');
    }

    public function setPremUsrHousenoAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_houseno'] = strtoupper($value);
        else
            $this->attributes['prem_usr_houseno'] = $this->getAttribute('usr_houseno');
    }

    public function setPremUsrLocalityAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_locality'] = strtoupper($value);
        else
            $this->attributes['prem_usr_locality'] = $this->getAttribute('usr_locality');
    }

    public function setPremUsrPincodeAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_pincode'] = strtoupper($value);
        else
            $this->attributes['prem_usr_pincode'] = $this->getAttribute('usr_pincode');
    }

    public function setPremUsrStateCodeAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_state_code'] = strtoupper($value);
        else
            $this->attributes['prem_usr_state_code'] = $this->getAttribute('usr_state_code');
    }

    public function setPremUsrCityCodeAttribute($value) {
        if (!is_null($value))
            $this->attributes['prem_usr_city_code'] = strtoupper($value);
        else
            $this->attributes['prem_usr_city_code'] = $this->getAttribute('usr_city_code');
    }

    public function setUsrDobAttribute($value) {
        $car_helper = new CarHelper;
        if(isset($value))
            $this->attributes['usr_dob'] = $car_helper->changeFormat($value, 'Y-m-d');
        else 
            $this->attributes['usr_dob'] = NULL;
    }

    public function setPolicyStartDateAttribute($value) {
        $car_helper = new CarHelper;
        if(isset($value))
            $this->attributes['policy_start_date'] = $car_helper->changeFormat($value, 'Y-m-d');
        else
            $this->attributes['policy_start_date'] = NULL;

    }

    public function setPolicyExpiryDateAttribute($value) {
        $car_helper = new CarHelper;
        if(isset($value))
            $this->attributes['policy_expiry_date'] = $car_helper->changeFormat($value, 'Y-m-d');
        else 
            $this->attributes['policy_expiry_date'] = NULL;
    }

    public function setCarRegistrationDateAttribute($value) {
        $car_helper = new CarHelper;
        if(isset($value))
            $this->attributes['car_registration_date'] = $car_helper->changeFormat($value, 'Y-m-d');
        else
            $this->attributes['car_registration_date'] = NULL;
    }
    
    public function getPolicyStartDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->changeFormat($this->policy_start_date,$format);
    }
    
    public function getPolicyEndDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->manDate($this->policy_start_date,$format,["+1 year",'-1 day']);
    }
    
    public function getPrevPolicyStartDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->manDate($this->policy_expiry_date,$format,["-1 year",'+1 day']);
    }
    
    public function setVehRegNoAttribute($value) {
        if (!is_null($value))
            $this->attributes['veh_reg_no'] = strtoupper($value);
        else
            $this->attributes['veh_reg_no'] = $this->getAttribute('veh_reg_no');
    }

    public static function getAffiliateData($filter_data) {

        switch ($filter_data) {
            case 'cartisan':
                // $raw = Self::selectRaw("DATE(created_at) as Date, COUNT(car_make) as `Detail Page`, COUNT(idv_calculated) as `Quote Page`,COUNT(product_id) as `Proposal Page`,COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Payment Success`,SUM(CASE WHEN t_status = 1 THEN totalpremium ELSE 0 END) as 'Total Premium'")
                $raw = Self::selectRaw("DATE(created_at) as Date, COUNT(partner_code) as `Detail Page`, COUNT(idv_calculated) as `Quote Page`,COUNT(product_id) as `Proposal Page`,COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Payment Success`,SUM(CASE WHEN t_status = 1 THEN totalpremium ELSE 0 END) as 'Total Premium'")
                                ->where('partner_code', $filter_data)
                                ->groupBy('Date')
                                ->get()->toArray();
                // dd($raw);
                // $result = self::get($raw);	
                return $raw;
                break;

            default:
                return 'Invalid Affiliate Id';
                break;
        }
    }

	public function storeUserCode($user_code){
		$car_helper = new CarHelper;
        $session_id =   $car_helper->getsuid();
        Self::where('session_id', $session_id)->update(['user_code' => $user_code]);
    }

    public function agentUserCode($user_code,$trans_code){
        $car_helper = new CarHelper;
        return Self::where('trans_code', $trans_code)->update(['agent_code' => $user_code]);
    }


    public function getAgentData($filter_data){
    	$current_date = date('Y/m/d');
    	$month_first_date = date('Y/m/1');
    	$current_date_prospects =	Self::selectRaw("DATE(created_at) as Date, COUNT(idv_calculated) as `Quote Page`,COUNT(usr_email) as `Proposal Page`,COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Policy`,SUM(CASE WHEN t_status = 1 THEN totalpremium ELSE 0 END) as 'Total Premium'")
										->where('agent_code',$filter_data)
										->whereDate('created_at',$current_date)
										->groupBy('Date')
										->get()->toArray();
		$till_date_prospects	=	Self::selectRaw("COUNT(idv_calculated) as `Quote Page`,COUNT(usr_email) as `Proposal Page`,COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Policy`,SUM(CASE WHEN t_status = 1 THEN totalpremium ELSE 0 END) as 'Total Premium'")
										->where('agent_code',$filter_data)
										->whereDate('created_at','>=',$month_first_date)
										->whereDate('created_at','<=',$current_date)
										->get()->toArray();
    	$raw['agent_details'] = [
    							'agent_name' => session('username'),
    							'agent_code' => session('user_code'),
    							];
    							
		$raw['today'] = !empty($current_date_prospects)?$current_date_prospects[0]:[$current_date,0,0,0,0];
		$raw['till_date'] = !empty($till_date_prospects)?$till_date_prospects[0]:[0,0,0,0];
		// $result = self::get($raw);	
		return $raw;
	}

	public function getAgentDashboardData($filter_data){
		$current_date = date('Y/m/d');
    	$month_first_date = date('Y/m/1');
    	$current_date_prospects	=	Self::selectRaw("COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Policy`")
										->where('agent_code',$filter_data)
										->whereDate('created_at',$current_date)
										->get()->toArray();
		$till_date_prospects	=	Self::selectRaw("COUNT(CASE WHEN t_status = 1 THEN t_status ELSE NULL END) as `Policy`")
										->where('agent_code',$filter_data)
										->whereDate('created_at','>=',$month_first_date)
										->whereDate('created_at','<=',$current_date)
										->get()->toArray();
		$prospects_details		= 	Self::selectRaw('session_id ,CONCAT(make_name,\' \',model_name,\' \',variant_name) as `Lead`, created_at as `Date` , CASE WHEN `idv_calculated`  IS NOT NULL THEN \'Yes\' ELSE \'No\' END as `Quote Page`, CASE WHEN `usr_email`  IS NOT NULL THEN \'Yes\' ELSE \'No\' END as `Proposal`, CASE WHEN t_status = 1 THEN \'Yes\' ELSE \'No\' END as `Policy`, updated_at as `Last Activity`')
										->where('agent_code',$filter_data)
										->whereDate('created_at','>=',$month_first_date)
										->whereDate('created_at','<=',$current_date)
										->orderBy('created_at', 'desc')
										->paginate(15);
		$raw['today'] = !empty($current_date_prospects)?$current_date_prospects[0]:[0];
		$raw['till_date'] = !empty($till_date_prospects)?$till_date_prospects[0]:[0];
		$raw['prospects_details'] = !empty($prospects_details)?$prospects_details:[0];
		return $raw;
	}

	public function getSessionRowData($session_id){
		return Self::where('session_id',$session_id)->first()->toArray();
	}

	public function getTransRowData($trans_code){
		$data =  Self::where('trans_code',$trans_code)->first();
		if(!empty($data))
			return $data->toArray();
		else 
			return null;
	}

    public function get_trans_list($from_date, $to_date, $agent_code) {
        $data =  Self::whereRaw("STR_TO_DATE(`quote_create_date`,'%d-%b-%Y') between STR_TO_DATE('".$from_date."','%d-%b-%Y') and STR_TO_DATE('".$to_date."','%d-%b-%Y')");
        if(($agent_code != 'all') || ($agent_code == null)){
            $data->where('agent_code',$agent_code);
        }
        return $data->get();
    }
}
