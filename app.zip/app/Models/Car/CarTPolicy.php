<?php

namespace App\Models\Car;

use App\Constants\Car_Constants;
use App\Helpers\Car\CarHelper;
use Illuminate\Database\Eloquent\Model;

class CarTPolicy extends Model {

    protected $table = 'car_t_policy';
    // protected $primaryKey = 'session_id';
    protected $primaryKey = 'trans_code';
    public $timestamps = false;
    public $incrementing = false;
    protected $fillable = ['otp_id',
                        'insurer_id',
                        'product_id',
                        'request_id',
                        't_status'];

    public function __construct(array $attributes = []) {
        parent::__construct($attributes);
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_PROPOSALLOG_POLICY);
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_USERLOG);
        array_map(function($field) {
            $this->fillable[] = $field;
        }, Car_Constants::CAR_T_QUOTELOG);
    }

	public function checkTransaction() {
		return self::select('t_status')->where(['session_id' => CarHelper::getSuid()])->first();
	}
	
public function getPolicyStartDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->changeFormat($this->policy_start_date,$format);
    }
    
    public function getPolicyEndDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->manDate($this->policy_start_date,$format,["+1 year",'-1 day']);
    }
    
    public function getPrevPolicyStartDate($format = 'Y/m/d'){
        $car_helper = new CarHelper;
        return $car_helper->manDate($this->policy_expiry_date,$format,["-1 year",'+1 day']);
    }
}
