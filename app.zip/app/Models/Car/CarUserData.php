<?php

namespace App\\Models\Car;

use Illuminate\Database\Eloquent\Model;

class CarUserData extends Model
{
    //
}
