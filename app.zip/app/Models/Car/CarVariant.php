<?php

namespace App\Models\Car;

use App\Constants\Car_Constants;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class CarVariant extends Model
{
    protected	$table = Car_Constants::CAR_VARIANT_TABLE,
    			$model_table	=	Car_Constants::CAR_MODEL_TABLE,
    			$make_table 	=	Car_Constants::CAR_MAKE_TABLE;
    
    public function getWeightAttribute(){
        if(isset($this->attributes['weight']) && $this->attributes['weight'])
            return $this->attributes['weight'];
        else 
            return 1000;
    }

    public function get_variant($model_code){
    	// dd($model_code_ref);
    	return CarVariant::select('variant_code','variant_name','variant_price','fuel_type','variant_cc')
    			->where('model_code_ref',$model_code)
    			->where('is_display', 1)
    			->orderBy('variant_name', 'ASC')
    			->get();
    }

    public function get_variant_filter($make_code,$model_id,$variant,$variant_code=0){
		$query = DB::table($this->table);
		if($make_code>0){
			$query->where('make_code',$make_code);
		}
		if($model_id>0){
			$query->where('model_code',$model_id);
		}
		if($variant!=''){
			$query->where('variant_name',$variant);
		}		
		if(!is_numeric($variant_code)){
			$query->where('variant_code',$variant_code);
		}		
		return $query->get();
		
	}

	//Fetch the price based on the provided variant
	public function getPrice($variant_code){
		$query =  $this->get_variant_filter(0,0,'',$variant_code);
		return $query[0]->variant_price;
	}

	//Getting Car Details
	public function get_car_details($variant_code){
		$query = DB::table($this->table);
		$query->where('variant_code',$variant_code);
		$variant_detail = $query->first();
		$car_details = $this->variant_details($variant_detail->model_code_ref);
		$data['make_name'] = $car_details->make_name;
		$data['model_name'] = $car_details->model_name;
		$data['variant_name'] = $variant_detail->variant_name;
		$data['variant_code'] = $variant_code;
		// $data['vehicleId']= $variant_detail->v_id;
		// $data['vehicleId']= $variant_detail->v_id;
		$data['vehicle_cc']= $variant_detail->variant_cc;
		$data['fuel'] = $this->get_fuel_type($variant_detail->fuel_type);
		$data['seating_capacity'] = (isset($variant_detail->seat_capacity) && $variant_detail->seat_capacity)? $variant_detail->seat_capacity : 5;
		return $data;
	}

	private function variant_details($data){
		$query = DB::table($this->model_table)->join($this->make_table,$this->make_table.'.make_code','=',$this->model_table.'.make_code_ref');
		$query->select($this->make_table.'.make_name',$this->model_table.'.model_name');
		$query->where($this->model_table.'.model_code',$data);
		return $query->first();
	}

	private function get_fuel_type($data){
		switch ($data) {
			case 'C':
				return 'CNG';
				break;
			case 'D':
				return 'Diesel';
				break;
			case 'E':
				return 'Electric';
				break;
			case 'L':
				return 'LPG';
				break;
			default:
				return 'Petrol';
				break;
		}
		return $data;
	}

	private function get_cc($data){
		$cc = substr(explode(" ", explode("-",$data)[1])[1], 0, -2);
		return $cc;
	}

	public function getVehicleId($variant_code,$variant_ref_col){
		return CarVariant::select($variant_ref_col)
    			->where('variant_code',$variant_code)
    			->first();
	}

	public function getData($variant_code,$field){
		return CarVariant::select($field)
    			->where('variant_code',$variant_code)
    			->first();
	}
	
	public function fetchCC($variant_code){
		return CarVariant::select('variant_cc')
    			->where('variant_code',$variant_code)
    			->first();
	}

	public function fetchFuelType($variant_code){
		$variant_attr	=	CarVariant::select('fuel_type')
    						->where('variant_code',$variant_code)
    						->first()->fuel_type;
    	/*$attr = explode("-",$variant_attr);
		$ttt  = str_replace("(","",trim($attr[0]));
		$ttt  = str_replace(")","",$ttt);*/
		switch ($variant_attr) {
			case 'C':
				return 'CNG';
				break;
			case 'D':
				return 'Diesel';
				break;
			case 'E':
				return 'Electric';
				break;
			case 'L':
				return 'LPG';
				break;
			default:
				return 'Petrol';
				break;
		}
		return $ttt;
	}

	public function variant_list(){
		$ret_data =  Self::select('variant_code', 'vehicle_code_desc',  'vechicle_name_desc')->where('is_display', 1)->get();
		return $ret_data;
	}
}
