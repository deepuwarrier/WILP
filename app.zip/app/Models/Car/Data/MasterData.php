<?php
namespace App\Models\Car\Data;

use App\Models\Base\UserMasterM;
use App\Models\Car\CarMake;
use App\Models\Car\CarVariant;
use App\Models\Car\CarModels;
use App\Models\Car\CarRto;
use App\Models\Car\MasterCity;
use App\Models\Car\MasterPincode;
use App\Models\Car\MasterInsurer;
use App\Models\Car\MasterState;
use App\Models\Car\MasterNomineeRelationship;
use App\Models\Base\InsurerMasterM;


Class MasterData{
	public function getStateList($ref_col = null){
		$state = new MasterState;
		$state_list = $state->getStateList($ref_col);
		unset($state);
		return $state_list;
	}

	public function getMakeId($code,$ref_col){	
		$car_make = new CarMake();
		$response = $car_make->getMakeId($code,$ref_col);
		unset($car_make);
		return $response;
	}

	public function getModelId($code,$ref_col){	
		$car_model = new CarModels();
		$response = $car_model->getModelId($code,$ref_col);
		unset($car_model);
		return $response;
	}

	public function getVariantData($variant_code, $ref_col = null) {
		$car_variant = new CarVariant();

		$field = ['fuel_type', 'variant_code', 'variant_cc', 'seat_capacity', 'variant_name'];

		if ($ref_col) {
			$field[] = $ref_col;
		}

		$response = $car_variant->getData($variant_code, $field);
		unset($car_variant);
		return $response;
	}

	public function getRTOZone($rto){
		$car_rto = new CarRto;
		$response = $car_rto->getRtoZone($rto);
		unset($car_rto);
		return $response;
	}

	public function getRTOLocation($rto,$ref_col){
		$car_rto = new CarRto;
		$response = $car_rto->getData($rto,[$ref_col]);
		unset($car_rto);
		return $response;
	}

	public function getRtoData($rto,$field){
		$car_rto = new CarRto;
		$response = $car_rto->getData($rto,$field);
		unset($car_rto);
		return $response;	
	}

	public function getStateId($state_code,$ref_col){
		$state_db = new MasterState;
		$response = $state_db->getStateId($ref_col,$state_code);
		unset($state_db);
		return $response;
	}

	public function getCityId($city_code,$ref_col){
		$city_db = new MasterCity;
		$response = $city_db->getCityId($ref_col,$city_code);
		unset($city_db);
		return $response;
	}

	public function getDataByPincode($data,$pincode){
		$pincode_db = new MasterPincode();
		$response = $pincode_db->select($data)->where(['pincode'=>$pincode])->first();
		unset($pincode_db);
		return $response;
	}

	public function getDataByCityCode($data,$city_ref_code){
		$pincode_db = new MasterPincode();
		$response = $pincode_db->select($data)->where(['city_ref_code'=>$city_ref_code])->first();
		unset($pincode_db);
		return $response;
	}

	public function getPincodeList($city_code){
		if(!isset($city_code))
			return [];

		$pincode_db = new MasterPincode();
		$data = [''];
		$response = $pincode_db->select(['pincode'])->where(['city_ref_code'=>$city_code])->get();
		unset($pincode_db);
		
		return $response;	
	}

	public function user_data($column_name, $agent_code, $null_check = false) {
		$user_data = new UserMasterM();
		$ret_value = "";
		if($null_check){
			if($agent_code != null){
				$ret_value = $user_data->user_details($agent_code)->$column_name;
			}
		}else{
			$ret_value = $user_data->user_details($agent_code)->$column_name;
		}
		return $ret_value;
	} // end of function

	public function getInsurerName($code) {
		$insurer_db = new MasterInsurer;
		$name = $insurer_db->getName($code);
		unset($insurer_db);
		return $name;
	}

	public function getNomineeCode($ref_col,$code){
		$nomineedb = new MasterNomineeRelationship();
		$result = $nomineedb->getNomineerelationshipId($ref_col,$code);
		unset($nomineedb);
		return $result;
	}

	public function getInsurerCode($ref_col,$code) {
		$insurer_db = new MasterInsurer;
		$name = $insurer_db->getCode($ref_col,$code);
		unset($insurer_db);
		return $name;
	}

	public function getStateName($state_code) {
		$state_db = new MasterState;
		$response = $state_db->getStateName($state_code);
		unset($state_db);
		return $response;
	}

	public function getCityName($city_code) {
		$city_db = new MasterCity;
		$response = $city_db->getCityName($city_code);
		unset($city_db);
		return $response;
	}

	public function getCommonInsurerName($insurer_id) {
		$insurer_code = $this->get_insurer_code($insurer_id);
		
		if(!$insurer_code)
			return '';

		$insurer_db = new InsurerMasterM;
		$insurer_name = $insurer_db->get_insurer_name($insurer_code);
		unset($insurer_db);
		return $insurer_name;
	}

	private function get_insurer_code($insurer_id){
		$insurer_code = ['reliance'=>'RELIANCE',
						'rsgi'=>'RSGI',
						'tata_gold'=>'TATA',
						'hdfc'=>'HDFC',
						'uiic'=>'UIIC'];

		return (array_key_exists($insurer_id,$insurer_code))? $insurer_code[$insurer_id]
		 : NULL;
	}
}
