<?php

namespace App\Models\Car\Data;

class PolicyPDFData {

	
private $_broker_code = "";
private $_pre_policy_no = "";
private $_policy_number = "";
private $_policy_issue_date = "";
private $_reg_number = "";
private $_idv_value = "";
private $_total_idv_value = "";
private $_policy_start_date = "";
private $_policy_end_date = "";
private $_proposer_name = "";
private $_proposer_mobile = "";
private $_propoers_email = "";
private $_reg_addr = "";
private $_reg_city_name = "";
private $_reg_state_name = "";
private $_reg_pincode = "";
private $_nomine_name = "";
private $_nomine_age = "";
private $_nomine_relationship = "";
private $_engine_no = "";
private $_chassis_no = "";
private $_make_name = "";
private $_model_name = "";
private $_variant_cc = "";
private $_body_type = "";
private $_seating_capacity = 5;
private $_yom = "";
private $_reg_date = "";
private $_rto_code = "";
private $_rto_location = "";
private $_od_value = 0;
private $_tp_value = 0;
private $_gross_tp_value = 0;
private $_gross_od_value = 0;
private $_od_addon_status = false;
private $_tp_addon_status = true;
private $_od_disc_value = 0;
private $_eli_ncb_rate = 0;
private $_eli_ncb_value = 0;
private $_zerodept_status = false;
private $_zerodept_value = 0;
private $_rti_status = false;
private $_rti_value = 0;
private $_pa_to_od_status = true;
private $_pa_to_od_value = 0;
private $_pa_to_pass_status = false;
private $_pa_to_pass_value = 0;
private $_ll_to_pd_status = true;
private $_ll_to_pd_value = 0;
private $_gross_premium = 0;
private $_gst_value = 0;
private $_net_premium = 0;
private $_net_premium_words = "";
private $_pg_reference_no = "";
private $_payment_date = "";
private $_ea_value = "-";
private $_nea_value = "-";
private $_net_basic_od = 0;

  public function get_total_idv_value(){
    return $this->_total_idv_value;
  }

  public function set_total_idv_value($_total_idv_value){
    $this->_total_idv_value = $_total_idv_value;
  }

  public function get_net_basic_od(){
    return $this->_net_basic_od;
  }

  public function set_net_basic_od($_net_basic_od){
    $this->_net_basic_od = $_net_basic_od;
  }
  
  public function get_broker_code(){
    return $this->_broker_code;
  }

  public function set_broker_code($_broker_code){
    $this->_broker_code = $_broker_code;
  }

  public function get_pre_policy_no(){
    return $this->_pre_policy_no;
  }

  public function set_pre_policy_no($_pre_policy_no){
    $this->_pre_policy_no = $_pre_policy_no;
  }

  public function get_policy_number(){
    return $this->_policy_number;
  }

  public function set_policy_number($_policy_number){
    $this->_policy_number = $_policy_number;
  }

  public function get_policy_issue_date(){
    return $this->_policy_issue_date;
  }

  public function set_policy_issue_date($_policy_issue_date){
    $this->_policy_issue_date = $_policy_issue_date;
  }

  public function get_reg_number(){
    return $this->_reg_number;
  }

  public function set_reg_number($_reg_number){
    $this->_reg_number = $_reg_number;
  }

  public function get_idv_value(){
    return $this->_idv_value;
  }

  public function set_idv_value($_idv_value){
    $this->_idv_value = $_idv_value;
  }

  public function get_policy_start_date(){
    return $this->_policy_start_date;
  }

  public function set_policy_start_date($_policy_start_date){
    $this->_policy_start_date = $_policy_start_date;
  }

  public function get_policy_end_date(){
    return $this->_policy_end_date;
  }

  public function set_policy_end_date($_policy_end_date){
    $this->_policy_end_date = $_policy_end_date;
  }

  public function get_proposer_name(){
    return $this->_proposer_name;
  }

  public function set_proposer_name($_proposer_name){
    $this->_proposer_name = $_proposer_name;
  }

  public function get_proposer_mobile(){
  	return $this->_proposer_mobile;
  }

  public function set_proposer_mobile($_proposer_mobile){
  	$this->_proposer_mobile = $_proposer_mobile;
  }

  public function get_propoers_email(){
    return $this->_propoers_email;
  }

  public function set_propoers_email($_propoers_email){
    $this->_propoers_email = $_propoers_email;
  }

  public function get_reg_addr(){
    return $this->_reg_addr;
  }

  public function set_reg_addr($_reg_addr){
    $this->_reg_addr = $_reg_addr;
  }

  public function get_reg_city_name(){
  	return $this->_reg_city_name;
  }

  public function set_reg_city_name($_reg_city_name){
  	$this->_reg_city_name = $_reg_city_name;
  }

  public function get_reg_state_name(){
    return $this->_reg_state_name;
  }

  public function set_reg_state_name($_reg_state_name){
    $this->_reg_state_name = $_reg_state_name;
  }

  public function get_reg_pincode(){
    return $this->_reg_pincode;
  }

  public function set_reg_pincode($_reg_pincode){
    $this->_reg_pincode = $_reg_pincode;
  }

  public function get_nomine_name(){
    return $this->_nomine_name;
  }

  public function set_nomine_name($_nomine_name){
    $this->_nomine_name = $_nomine_name;
  }

  public function get_nomine_age(){
    return $this->_nomine_age;
  }

  public function set_nomine_age($_nomine_age){
    $this->_nomine_age = $_nomine_age;
  }

  public function get_nomine_relationship(){
    return $this->_nomine_relationship;
  }

  public function set_nomine_relationship($_nomine_relationship){
    $this->_nomine_relationship = $_nomine_relationship;
  }

  public function get_engine_no(){
    return $this->_engine_no;
  }

  public function set_engine_no($_engine_no){
    $this->_engine_no = $_engine_no;
  }

  public function get_chassis_no(){
    return $this->_chassis_no;
  }

  public function set_chassis_no($_chassis_no){
    $this->_chassis_no = $_chassis_no;
  }

  public function get_make_name(){
    return $this->_make_name;
  }

  public function set_make_name($_make_name){
    $this->_make_name = $_make_name;
  }

  public function get_model_name(){
    return $this->_model_name;
  }

  public function set_model_name($_model_name){
    $this->_model_name = $_model_name;
  }

  public function get_variant_cc(){
    return $this->_variant_cc;
  }

  public function set_variant_cc($_variant_cc){
    $this->_variant_cc = $_variant_cc;
  }

  public function get_body_type(){
    return $this->_body_type;
  }

  public function set_body_type($_body_type){
    $this->_body_type = $_body_type;
  }
  
  public function get_seating_capacity(){
    return $this->_seating_capacity;
  }

  public function set_seating_capacity($_seating_capacity){
    $this->_seating_capacity = $_seating_capacity;
  }
  
  public function get_yom(){
    return $this->_yom;
  }

  public function set_yom($_yom){
    $this->_yom = $_yom;
  }

  public function get_reg_date(){
    return $this->_reg_date;
  }

  public function set_reg_date($_reg_date){
    $this->_reg_date = $_reg_date;
  }

  public function get_rto_code(){
    return $this->_rto_code;
  }

  public function set_rto_code($_rto_code){
    $this->_rto_code = $_rto_code;
  }

  public function get_rto_location(){
    return $this->_rto_location;
  }

  public function set_rto_location($_rto_location){
    $this->_rto_location = $_rto_location;
  }

  public function get_od_value(){
    return $this->_od_value;
  }

  public function set_od_value($_od_value){
    $this->_od_value = $_od_value;
  }

  public function get_tp_value(){
    return $this->_tp_value;
  }

  public function set_tp_value($_tp_value){
    $this->_tp_value = $_tp_value;
  }

  public function get_gross_tp_value(){
    return $this->_gross_tp_value;
  }

  public function set_gross_tp_value($_gross_tp_value){
    $this->_gross_tp_value = $_gross_tp_value;
  }

  public function get_gross_od_value(){
    return $this->_gross_od_value;
  }

  public function set_gross_od_value($_gross_od_value){
    $this->_gross_od_value = $_gross_od_value;
  }

  public function get_od_disc_value(){
    return $this->_od_disc_value;
  }

  public function set_od_disc_value($_od_disc_value){
    $this->_od_disc_value = $_od_disc_value;
  }

  public function get_eli_ncb_rate(){
    return $this->_eli_ncb_rate;
  }

  public function set_eli_ncb_rate($_eli_ncb_rate){
    $this->_eli_ncb_rate = $_eli_ncb_rate;
  }

  public function get_eli_ncb_value(){
    return $this->_eli_ncb_value;
  }

  public function set_eli_ncb_value($_eli_ncb_value){
    $this->_eli_ncb_value = $_eli_ncb_value;
  }

  public function get_zerodept_status(){
    return $this->_zerodept_status;
  }

  public function set_zerodept_status($_zerodept_status){
    $this->_zerodept_status = $_zerodept_status;
  }

  public function get_zerodept_value(){
    return $this->_zerodept_value;
  }

  public function set_zerodept_value($_zerodept_value){
    $this->_zerodept_value = $_zerodept_value;
  }

  public function get_rti_status(){
    return $this->_rti_status;
  }

  public function set_rti_status($_rti_status){
    $this->_rti_status = $_rti_status;
  }

  public function get_rti_value(){
    return $this->_rti_value;
  }

  public function set_rti_value($_rti_value){
    $this->_rti_value = $_rti_value;
  }

  public function get_pa_to_od_status(){
    return $this->_pa_to_od_status;
  }

  public function set_pa_to_od_status($_pa_to_od_status){
    $this->_pa_to_od_status = $_pa_to_od_status;
  }

  public function get_pa_to_od_value(){
    return $this->_pa_to_od_value;
  }

  public function set_pa_to_od_value($_pa_to_od_value){
    $this->_pa_to_od_value = $_pa_to_od_value;
  }

  public function get_pa_to_pass_status(){
    return $this->_pa_to_pass_status;
  }

  public function set_pa_to_pass_status($_pa_to_pass_status){
    $this->_pa_to_pass_status = $_pa_to_pass_status;
  }

  public function get_pa_to_pass_value(){
    return $this->_pa_to_pass_value;
  }

  public function set_pa_to_pass_value($_pa_to_pass_value){
    $this->_pa_to_pass_value = $_pa_to_pass_value;
  }

  public function get_gross_premium(){
    return $this->_gross_premium;
  }

  public function set_gross_premium($_gross_premium){
    $this->_gross_premium = $_gross_premium;
  }

  public function get_gst_value(){
    return $this->_gst_value;
  }

  public function set_gst_value($_gst_value){
    $this->_gst_value = $_gst_value;
  }

  public function get_net_premium(){
    return $this->_net_premium;
  }

  public function set_net_premium($_net_premium){
    $this->_net_premium = $_net_premium;
  }

  public function get_net_premium_words(){
    return $this->_net_premium_words;
  }

  public function set_net_premium_words($_net_premium_words){
    $this->_net_premium_words = $_net_premium_words;
  }

  public function get_pg_reference_no(){
    return $this->_pg_reference_no;
  }

  public function set_pg_reference_no($_pg_reference_no){
    $this->_pg_reference_no = $_pg_reference_no;
  }

  public function get_payment_date(){
    return $this->_payment_date;
  }

  public function set_payment_date($_payment_date){
    $this->_payment_date = $_payment_date;
  }


  public function get_od_addon_status(){
    return $this->_od_addon_status;
  }

  public function set_od_addon_status($_od_addon_status){
    $this->_od_addon_status = $_od_addon_status;
  }

  public function get_tp_addon_status(){
    return $this->_tp_addon_status;
  }

  public function set_tp_addon_status($_tp_addon_status){
    $this->_tp_addon_status = $_tp_addon_status;
  }

  public function get_ll_to_pd_status(){
    return $this->_ll_to_pd_status;
  }

  public function set_ll_to_pd_status($_ll_to_pd_status){
    $this->_ll_to_pd_status = $_ll_to_pd_status;
  }

  public function get_ll_to_pd_value(){
    return $this->_ll_to_pd_value;
  }

  public function set_ll_to_pd_value($_ll_to_pd_value){
    $this->_ll_to_pd_value = $_ll_to_pd_value;
  }

  public function get_nea_value(){
      return $this->_nea_value;
  }

  public function get_ea_value(){
      return $this->_ea_value;
  }

  public function set_ea_value($_ea_value){
      $this->_ea_value = $_ea_value;
      return $this;
  }

  public function set_nea_value($_nea_value){
      $this->_nea_value = $_nea_value;
      return $this;
  }
}
