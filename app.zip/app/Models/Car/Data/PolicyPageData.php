<?php
namespace App\Models\Car\Data;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;

class PolicyPageData{
	private $trans_code;
    public $variant_code;
	public $product_id;
	public $insurer_id;
	public $totalpremium;
	public $netPremium;
	public $session_id;
	public $return_quote_url;
	public $policyStartDate;
	public $idv;
	public $policyExpiryDate;
	public $rto;
	public $price;
	public $claim;
    public $current_ncb;
    public $cmp_name;
    private $exp_status;
    private $min_year = NULL;
    private $state_list =  NULL;
    private $city_list =  NULL;
    private $elect_ass_list = NULL;
    private $non_elect_ass_list = NULL;
    private $perm_city_list =  NULL;
    private $financier_list = NULL;
    private $type_of_finance_list = NULL;
    private $manf_year_list = NULL;
    private $reg_add_is_same = 'Y';
    private $type_of_business = 'rollover';
    private $previousinsurer_text = NULL;
    private $previous_tab_text = NULL;
    private $relationship_list = NULL;    
    private $cover_list = [];
    private $insurer_list = [];
    private $pincode_list = [];
    private $perm_pincode_list = [];
    private $refrel_col = NULL;
    private $cmp_logo = null;



	public function __construct($user_data){
        $car_helper = new CarHelper;
        $this->setTransCode($user_data->trans_code);
        $this->setProductId($user_data->product_id);
		$this->setInsurerId($user_data->insurer_id);
        $this->setNetPremium($user_data->netPremium);
        $this->setCmpName($car_helper->getInsuranceCompanyName($this->getProductId()));
		$this->setExpStatus($user_data->policy_exp_status);
        $this->setVariantCode($user_data->car_variant);
		$this->setTotalpremium($user_data->totalpremium);
		$this->setSessionId($user_data->session_id);
        $this->setCurrentNcb($user_data->new_ncb);
		
        if($user_data->idv_opted)
			$this->setIdv($user_data->idv_opted);
		else 
			$this->setIdv($user_data->idv_calculated);

		$this->setClaim($user_data->claim);
		$this->setPrice($user_data->calculated_price);
		$this->setRto($user_data->car_rto);
        $this->setRegAddIsSame($user_data->reg_add_is_same);
        $this->setTypeOfBusiness($user_data->type_of_business);

        $covers = explode(',',$user_data->covers_selected);
        $this->setCoverList($covers);
	}

    public function is_zerodep_selected(){
        return false;
        return (in_array('ZERODEP',$this->getCoverList()));
    }

    public function is_elect_ass_exist(){
        return (isset($this->elect_ass_list) && !empty($this->elect_ass_list));
    }

    public function is_non_elect_ass_exist(){
        return (isset($this->non_elect_ass_list) && !empty($this->non_elect_ass_list));   
    }

    public function is_rollover(){
        return ($this->getTypeOfBusiness() == 'rollover');
    }

    public function required_on_rollover(){
        return ($this->getTypeOfBusiness() == 'rollover')? "required" : "";
    }

    public function getVariantCode()
    {
        return $this->variant_code;
    }

   
    public function setVariantCode($variant_code)
    {
        $this->variant_code = $variant_code;

        return $this;
    }

    public function getProductId()
    {
        return $this->product_id;
    }

    public function setProductId($product_id)
    {
        $this->product_id = $product_id;

        return $this;
    }

    public function getInsurerId()
    {
        return $this->insurer_id;
    }

    public function setInsurerId($insurer_id)
    {
        $this->insurer_id = $insurer_id;

        return $this;
    }

    public function getTotalpremium()
    {
        return $this->totalpremium;
    }

    public function setTotalpremium($totalpremium)
    {
        $this->totalpremium = $totalpremium;

        return $this;
    }

    public function getNetPremium()
    {
        return $this->netPremium;
    }

    public function setNetPremium($netPremium)
    {
        $this->netPremium = $netPremium;

        return $this;
    }

    public function getSessionId()
    {
        return $this->session_id;
    }

    public function setSessionId($session_id)
    {
        $this->session_id = $session_id;

        return $this;
    }

    public function getReturnQuoteUrl()
    {
        return $this->return_quote_url;
    }

    public function setReturnQuoteUrl($return_quote_url)
    {
        $this->return_quote_url = $return_quote_url;

        return $this;
    }

    public function getPolicyStartDate()
    {
        return $this->policyStartDate;
    }

    public function setPolicyStartDate($policyStartDate){
        $this->policyStartDate = $policyStartDate;
        return $this;
    }

    public function getIdv(){
        return $this->idv;
    }

    public function setIdv($idv){
        $this->idv = $idv;
        return $this;
    }

    public function getPolicyExpiryDate(){
        return $this->policyExpiryDate;
    }

    public function setPolicyExpiryDate($policyExpiryDate){
        $this->policyExpiryDate = $policyExpiryDate;
		return $this;
    }

    public function getRto(){
        return $this->rto;
    }

    public function setRto($rto){
        $this->rto = $rto;
        return $this;
    }

    public function getPrice(){
        return $this->price;
    }

    public function setPrice($price){
        $this->price = $price;
        return $this;
    }

    public function getClaim(){
        return $this->claim;
    }

    public function setClaim($claim){
        $this->claim = $claim;
        return $this;
    }

    
    public function getCurrentNcb()
    {
        return $this->current_ncb;
    }

    /**
     * @param mixed $current_ncb
     *
     * @return self
     */
    public function setCurrentNcb($current_ncb)
    {
        $this->current_ncb = $current_ncb;

        return $this;
    }

    
    public function getCmpName()
    {
        return $this->cmp_name;
    }

    /**
     * @param mixed $cmp_name
     *
     * @return self
     */
    public function setCmpName($cmp_name)
    {
        $this->cmp_name = $cmp_name;

        return $this;
    }

    
    public function getExpStatus()
    {
        return $this->exp_status;
    }

    /**
     * @param mixed $exp_status
     *
     * @return self
     */
    public function setExpStatus($exp_status)
    {
        $this->exp_status = $exp_status;

        return $this;
    }

    
    public function getMinYear()
    {
        return $this->min_year;
    }

    /**
     * @param mixed $min_year
     *
     * @return self
     */
    public function setMinYear($min_year)
    {
        $this->min_year = $min_year;

        return $this;
    }

    
    public function getState()
    {
        return $this->state;
    }

    /**
     * @param mixed $state
     *
     * @return self
     */
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    
    public function getStateList()
    {
        return $this->state_list;
    }

    /**
     * @param mixed $state_list
     *
     * @return self
     */
    public function setStateList($state_list)
    {
        $this->state_list = $state_list;

        return $this;
    }

    
    public function getCityList()
    {
        return $this->city_list;
    }

    /**
     * @param mixed $city_list
     *
     * @return self
     */
    public function setCityList($city_list)
    {
        $this->city_list = $city_list;
        return $this;
    }

    public function is_city_exist(){
        return ($this->city_list && !empty($this->city_list));
    }
    
    public function setInsurerList($insurer_list){
        if(isset($insurer_list))
            $this->insurer_list = $insurer_list; 
    }

    public function getInsurerList(){
        return $this->insurer_list;
    }

    public function getRegAddIsSame()
    {
        return $this->reg_add_is_same;
    }

    /**
     * @param mixed $reg_add_is_same
     *
     * @return self
     */
    public function setRegAddIsSame($reg_add_is_same)
    {
        if($reg_add_is_same)
            $this->reg_add_is_same = $reg_add_is_same;
        return $this;
    }


    public function reg_add_is_checked(){
        return ($this->reg_add_is_same == 'N') ? '': 'checked';
    }


    
    public function getPermCityList()
    {
        return $this->perm_city_list;
    }

    public function is_perm_city_exist(){
        return ($this->perm_city_list && !empty($this->perm_city_list));
    }

    /**
     * @param mixed $perm_city_list
     *
     * @return self
     */
    public function setPermCityList($perm_city_list)
    {
        $this->perm_city_list = $perm_city_list;

        return $this;
    }

    
    public function getTypeOfBusiness(){
        return strtolower($this->type_of_business);
    }

    /**
     * @param mixed $type_of_business
     *
     * @return self
     */
    public function setTypeOfBusiness($type_of_business)
    {
        $this->type_of_business = $type_of_business;

        return $this;
    }

    
    public function getElectAssList()
    {
        return $this->elect_ass_list;
    }

    /**
     * @param mixed $elect_ass_list
     *
     * @return self
     */
    public function setElectAssList($elect_ass_list)
    {
        $this->elect_ass_list = $elect_ass_list;

        return $this;
    }

    
    public function getNonElectAssList()
    {
        return $this->non_elect_ass_list;
    }

    /**
     * @param mixed $non_elect_ass_list
     *
     * @return self
     */
    public function setNonElectAssList($non_elect_ass_list)
    {
        $this->non_elect_ass_list = $non_elect_ass_list;

        return $this;
    }

    

    
    public function getFinancierList()
    {
        return $this->financier_list;
    }

    /**
     * @param mixed $financier_list
     *
     * @return self
     */
    public function setFinancierList($financier_list)
    {
        $this->financier_list = $financier_list;

        return $this;
    }

    
    public function getTypeOfFinanceList(){
        return $this->type_of_finance_list;
    }

    public function setTypeOfFinanceList($type_of_finance_list){
        $this->type_of_finance_list = $type_of_finance_list;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getManfYearList()
    {
        return $this->manf_year_list;
    }

    /**
     * @param mixed $manf_year_list
     *
     * @return self
     */
    public function setManfYearList($manf_year_list)
    {
        $this->manf_year_list = $manf_year_list;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPreviousinsurerText(){

        if(!isset($this->previousinsurer_text)){
            return ($this->is_rollover())? Car_Constants::PREV_TEXT_ROLLOVER : Car_Constants::PREV_TEXT_NEWBUSINESS;
        }
        return $this->previousinsurer_text;
    }

    public function getPreviousTabText(){
        if(!isset($this->previous_tab_text)){
            return ($this->is_rollover())? Car_Constants::PREV_TAB_TEXT_ROLLOVER : Car_Constants::PREV_TAB_TEXT_NEWBUSINESS;
        }
        return $this->previous_tab_text;
    }

    public function setPreviousTabText($previousinsurer_text)
    {
        $this->previous_tab_text = $previous_tab_text;

        return $this;
    }

    /**
     * @param mixed $previousinsurer_text
     *
     * @return self
     */
    public function setPreviousinsurerText($previousinsurer_text)
    {
        $this->previousinsurer_text = $previousinsurer_text;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRelationshipList()
    {
        return $this->relationship_list;
    }

    /**
     * @param mixed $relationship_list
     *
     * @return self
     */
    public function setRelationshipList($relationship_list)
    {
        $this->relationship_list = $relationship_list;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getCoverList()
    {
        return $this->cover_list;
    }

    /**
     * @param mixed $cover_list
     *
     * @return self
     */
    public function setCoverList($cover_list)
    {
        $this->cover_list = $cover_list;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRefrelCol()
    {
        return $this->refrel_col;
    }

    /**
     * @param mixed $refrel_col
     *
     * @return self
     */
    public function setRefrelCol($refrel_col)
    {
        $this->refrel_col = $refrel_col;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTransCode()
    {
        return $this->trans_code;
    }

    /**
     * @param mixed $trans_code
     *
     * @return self
     */
    public function setTransCode($trans_code)
    {
        $this->trans_code = $trans_code;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPincodeList()
    {
        return $this->pincode_list;
    }

    /**
     * @param mixed $pincode_list
     *
     * @return self
     */
    public function setPincodeList($pincode_list)
    {
        $this->pincode_list = $pincode_list;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPermPincodeList()
    {
        return $this->perm_pincode_list;
    }

    /**
     * @param mixed $perm_pincode_list
     *
     * @return self
     */
    public function setPermPincodeList($perm_pincode_list)
    {
        $this->perm_pincode_list = $perm_pincode_list;

        return $this;
    }
}

?>