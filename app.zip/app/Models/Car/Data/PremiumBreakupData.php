<?php
namespace App\Models\Car\Data;
use App\Helpers\Car\CarHelper;
use App\Constants\Car_Constants;

Class PremiumBreakupData{
	private $od_premium = 0;
	private $tp_premium = 0;
    // dicount
	private $od_discount = 0;
	private $ncb_discount = 0;
	
	private $pa_premium = 0;
	private $ll_premium = 0;

	// addons
    private $zerodep_premium = 0;
	private $ep_premium = 0;
	private $rti_premium = 0;
	private $papass_premium = 0;
	private $rsac_premium = 0;
    private $lpb_premium = 0;
    private $et_hotelexpenses = 0;
    private $cosumable_expenses = 0;
    private $keyreplace_premium = 0;
    private $repair_of_glass_premium = 0;
    private $ts_premium = 0;

    private $service_tax = 0;
    private $gross_premium = 0;
    private $total_premium = 0;

    public function getAttributes(){
        return get_object_vars($this);
    }

    public function getAddons(){
        $addon = [];
        foreach ($this->getAddonsAttributes() as $key => $value) {
            if($this->$key)
                $addon[$value] = $this->$key;
        }
        return $addon;
    }

    public function getAddonsAttributes(){
        return ['pa_premium'=>'pa',
                'll_premium'=>'ll',
                'zerodep_premium'=>'zerodep',
                'ep_premium'=>'ep',
                'rti_premium'=>'rti',
                'papass_premium'=>'papass',
                'rsac_premium'=>'rsac',
                'lpb_premium'=>'LPB',
                'et_hotelexpenses'=>'ET_HOTELEXPENSES',
                'cosumable_expenses'=>'COSUMABLE_EXPENSES',
                'keyreplace_premium'=>'KEYREPLACE',
                'repair_of_glass_premium'=>'REPAIR_OF_GLASS',
                'ts_premium'=>'TS',
            ];
    }

    public function setAttributes($data){
        foreach ($data as $key => $value)
            $this->$key = $value;
    }

    public function setAttributesUsingDb($user_data){
        
        if(isset($user_data['totalpremium']))
            $this->setTotalPremium($user_data['totalpremium']);

        if(isset($user_data['netPremium']))
            $this->setGrossPremium($user_data['netPremium']);

        if(isset($user_data['od_premium']))
            $this->setOdPremium($user_data['od_premium']);
        
        if(isset($user_data['tp_premium']))
            $this->setTpPremium($user_data['tp_premium']);
        
        if(isset($user_data['od_discount']))
            $this->setOdDiscount($user_data['od_discount']);
        
        if(isset($user_data['ncb_discount']))
            $this->setNcbDiscount($user_data['ncb_discount']);
        
        if(isset($user_data['tax']))
            $this->setServiceTax($user_data['tax']);

        if($user_data['addon_premium'] != ''){
            $addon = json_decode($user_data['addon_premium'],true);
            foreach ($this->getAddonsAttributes() as $key => $value) 
                if(array_key_exists($value,$addon))
                     $this->$key = $addon[$value];
        }
    }

    public function setDataUsingPB($data){

        $discounts = $addon = $basic = [];

        if(array_key_exists('addon',$data))
            $addon = $data['addon'];

        if(array_key_exists('basic',$data))
            $basic = $data['basic'];

        if(array_key_exists('discounts',$data))
            $discounts = $data['discounts'];

        if(array_key_exists('od_basic_price',$basic))
            $this->setOdPremium($basic['od_basic_price']['basic_premium']);

        if(array_key_exists('tp_basic_price',$basic))
            $this->setTpPremium($basic['tp_basic_price']['basic_premium']);

        if(isset($data['serviceTax']['basic_premium']))
            $this->setServiceTax($data['serviceTax']['basic_premium']);

        if(isset($data['netPremium']['basic_premium']))
            $this->setGrossPremium($data['netPremium']['basic_premium']);
        
        if(isset($data['totalpremium']['basic_premium']))
            $this->setTotalPremium($data['totalpremium']['basic_premium']);

        if(array_key_exists('pa_basic_price',$basic))
            $this->setPaPremium($basic['pa_basic_price']['basic_premium']);
        else if(array_key_exists('pa_addon_price',$addon))
            $this->setPaPremium($addon['pa_addon_price']['basic_premium']);

        if(array_key_exists('ll_basic_price',$basic))
            $this->setLlPremium($basic['ll_basic_price']['basic_premium']);
        else if(array_key_exists('ll_addon_price',$addon))
            $this->setLlPremium($addon['ll_addon_price']['basic_premium']);

        if(array_key_exists('rti_addon_price',$addon))
            $this->setRtiPremium($addon['rti_addon_price']['basic_premium']);

        if(array_key_exists('zerodep_addon_price',$addon))
            $this->setZerodepPremium($addon['zerodep_addon_price']['basic_premium']);

        if(array_key_exists('papass_addon_price',$addon))
            $this->setPapassPremium($addon['papass_addon_price']['basic_premium']);

        if(array_key_exists('ep_addon_price',$addon))
            $this->setEpPremium($addon['ep_addon_price']['basic_premium']);

        if(array_key_exists('rsac_addon_price',$addon))
            $this->setRsacPremium($addon['rsac_addon_price']['basic_premium']);

        if(array_key_exists('od_discount_price',$discounts))
            $this->setOdDiscount($discounts['od_discount_price']['basic_premium']);

        if(array_key_exists('ncbbenefit_discount_price',$discounts))
            $this->setNcbDiscount($discounts['ncbbenefit_discount_price']['basic_premium']); 
    }

    /**
     * @return mixed
     */
    public function getOdPremium()
    {
        return $this->od_premium;
    }

    /**
     * @param mixed $od_premium
     *
     * @return self
     */
    public function setOdPremium($od_premium)
    {
        $this->od_premium = round($od_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTpPremium()
    {
        return $this->tp_premium;
    }

    /**
     * @param mixed $tp_premium
     *
     * @return self
     */
    public function setTpPremium($tp_premium)
    {
        $this->tp_premium = round($tp_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getOdDiscount()
    {
        return $this->od_discount;
    }

    /**
     * @param mixed $od_discount
     *
     * @return self
     */
    public function setOdDiscount($od_discount)
    {
        $this->od_discount = round($od_discount);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getNcbDiscount()
    {
        return $this->ncb_discount;
    }

    /**
     * @param mixed $ncb_discount
     *
     * @return self
     */
    public function setNcbDiscount($ncb_discount)
    {
        $this->ncb_discount = round($ncb_discount);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPaPremium()
    {
        return $this->pa_premium;
    }

    /**
     * @param mixed $pa_premium
     *
     * @return self
     */
    public function setPaPremium($pa_premium)
    {
        $this->pa_premium = round($pa_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getLlPremium()
    {
        return $this->ll_premium;
    }

    /**
     * @param mixed $ll_premium
     *
     * @return self
     */
    public function setLlPremium($ll_premium)
    {
        $this->ll_premium = round($ll_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getZerodepPremium()
    {
        return $this->zerodep_premium;
    }

    /**
     * @param mixed $zerodep_premium
     *
     * @return self
     */
    public function setZerodepPremium($zerodep_premium)
    {
        $this->zerodep_premium = round($zerodep_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEpPremium()
    {
        return $this->ep_premium;
    }

    /**
     * @param mixed $ep_premium
     *
     * @return self
     */
    public function setEpPremium($ep_premium)
    {
        $this->ep_premium = round($ep_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRtiPremium()
    {
        return $this->rti_premium;
    }

    /**
     * @param mixed $rti_premium
     *
     * @return self
     */
    public function setRtiPremium($rti_premium)
    {
        $this->rti_premium = round($rti_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getPapassPremium()
    {
        return $this->papass_premium;
    }

    /**
     * @param mixed $papass_premium
     *
     * @return self
     */
    public function setPapassPremium($papass_premium)
    {
        $this->papass_premium = round($papass_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getRsacPremium()
    {
        return $this->rsac_premium;
    }

    /**
     * @param mixed $rsac_premium
     *
     * @return self
     */
    public function setRsacPremium($rsac_premium)
    {
        $this->rsac_premium = round($rsac_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getServiceTax()
    {
        return $this->service_tax;
    }

    /**
     * @param mixed $service_tax
     *
     * @return self
     */
    public function setServiceTax($service_tax)
    {
        $this->service_tax = round($service_tax);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getGrossPremium()
    {
        return $this->gross_premium;
    }

    /**
     * @param mixed $gross_premium
     *
     * @return self
     */
    public function setGrossPremium($gross_premium)
    {
        $this->gross_premium = round($gross_premium);

        return $this;
    }

    /**
     * @return mixed
     */
    public function getTotalPremium()
    {
        return $this->total_premium;
    }

 
    public function setTotalPremium($total_premium)
    {
        $this->total_premium = round($total_premium);

        return $this;
    }

    public function getLpbPremium()
    {
        return $this->lpb_premium;
    }

    public function setLpbPremium($lpb_premium)
    {
        $this->lpb_premium = round($lpb_premium);

        return $this;
    }

    public function getEtHotelexpenses()
    {
        return $this->et_hotelexpenses;
    }

    public function setEtHotelexpenses($et_hotelexpenses)
    {
        $this->et_hotelexpenses = round($et_hotelexpenses);

        return $this;
    }

    public function getCosumableExpenses()
    {
        return $this->cosumable_expenses;
    }

    public function setCosumableExpenses($cosumable_expenses)
    {
        $this->cosumable_expenses = round($cosumable_expenses);

        return $this;
    }

    public function getKeyreplacePremium()
    {
        return $this->keyreplace_premium;
    }

    public function setKeyreplacePremium($keyreplace_premium)
    {
        $this->keyreplace_premium = round($keyreplace_premium);

        return $this;
    }

    public function getRepairOfGlassPremium()
    {
        return $this->repair_of_glass_premium;
    }

    public function setRepairOfGlassPremium($repair_of_glass_premium)
    {
        $this->repair_of_glass_premium = "".round($repair_of_glass_premium);

        return $this;
    }

    public function getTsPremium()
    {
        return $this->ts_premium;
    }

    public function setTsPremium($ts_premium)
    {
        $this->ts_premium = round($ts_premium);

        return $this;
    }
}
