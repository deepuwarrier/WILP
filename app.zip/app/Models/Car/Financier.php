<?php
namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class Financier extends Model {
    protected $table = 'car_m_financier';
    protected $primary_key = 'auto_id';
    public $incrementing = false;
    
    public static function getFinancierId($policy,$code) {
        return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
    }
    
    public function getUIICFinancier(){
        return self::select ( 'financer_name as value','display_order')
            ->whereNotNull('uiic_code')->distinct()
            ->where(['is_display' => 1])
            ->orderBy('display_order', 'desc')
            ->get()->toArray();
    }
    
    public function getUIICData($code){
        return self::select(['financer_name','uiic_code','financier_branch','financier_addr'])
            ->where(['financier_code'=>$code])
            ->get()->first();
    }

     public function getUiicBranch($name){
       return self::select ( 'financier_branch as value','financier_code','display_order')
            ->whereNotNull('financier_branch')->distinct()
            ->where(['financer_name' => $name])
            ->orderBy('display_order', 'desc')
            ->get()->toArray();
   }
}