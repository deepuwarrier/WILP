<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterBreakinLocation extends Model {
	protected $table = 'car_m_breakin_location';
	public $incrementing = false;
	
	public function getBreakinlocationId($policy,$code) {
		return self::select($policy.'  as id')->where(['city_code'=>$code])->first()->id;
	}
}
