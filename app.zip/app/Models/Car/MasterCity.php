<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterCity extends Model {
	protected $table = 'car_m_city2';
	public $incrementing = false;
	
	public function getCity($policy, $state_code) {
		return self::select('code  as id', 'city_name as value')
			->where(['state_code' => $state_code,
				'is_display' => 1])
			->whereNotNull($policy)
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getCityName($code) {
		return self::select('city_name')->where(['code'=>$code])->first()->city_name;
	}

	public function getCityId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function retriveCity($policy = null, $state_code) {
		if(!$policy)
			$policy = 'code';
		
		return self::select('code  as id', 'city_name as value')
			->where(['state_code' => $state_code,
				'is_display' => 1])
			->whereNotNull($policy)
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getName($code) {
		return self::select('city_name')->where(['code'=>$code])->first()->city_name;
	}

}
