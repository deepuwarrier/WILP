<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterClaimHistory extends Model {
	protected $table = 'car_m_claimhistory';
	public $incrementing = false;
	public function getClaimhistory($policy) {
		return self::select('code  as id', 'claimhistory_name as value', 'code')
			->where(['is_display' => 1])
			->whereNotNull($policy)
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getClaimhistoryId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
