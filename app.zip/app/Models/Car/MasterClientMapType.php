<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterClientMapType extends Model {
	protected $table = 'car_m_clientmaptype';
	public $incrementing = false;
	public function getClientmaptype($policy) {
		return self::select('code  as id', 'clientmaptype_name as value', 'code')
			->where(['is_display' => 1])
			->whereNotNull($policy)
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getClientmaptypeId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
