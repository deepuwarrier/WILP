<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterColor extends Model {
	protected $table = 'car_m_color';
	public $incrementing = false;
	public function getColor($policy) {
		return self::select('code  as id', 'color_name as value')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getColorId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
