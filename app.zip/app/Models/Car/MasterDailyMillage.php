<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterDailyMillage extends Model {
	protected $table = 'car_m_dailymillage';
	public $incrementing = false;
	public function getDailymillage($policy) {
		return self::select('code  as id', 'dailymillage_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getDailymillageId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
