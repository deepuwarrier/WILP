<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterDriverExperience extends Model {
	protected $table = 'car_m_driverexperience';
	public $incrementing = false;
	public function getDriverexperience($policy) {
		return self::select('code  as id', 'driverexperience_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getDriverexperienceId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
