<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterDriverQualification extends Model {
	protected $table = 'car_m_driverqualification';
	public $incrementing = false;
	public function getDriverqualification($policy) {
		return self::select('code  as id', 'driverqualification_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getDriverqualificationId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
