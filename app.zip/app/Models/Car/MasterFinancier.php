<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterFinancier extends Model {
	protected $table = 'car_m_financier';
	protected $primary_key = 'auto_id';
	public $incrementing = false;
	public function getFinancier($policy) {
		return self::select('financier_code  as id', 'financer_name as value', 'financier_code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getFinancierId($policy,$code) {
		return self::select($policy.'  as id')->where(['financier_code'=>$code])->first()->id;
	}

	public function getFinancierList($policy){
		return self::select('financier_code  as id', 'financer_name as value', 'financier_code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();	
	}

	public function serachFinancier($policy,$term){
		return self::select('financier_code  as id', 'financer_name as text')
			->whereNotNull($policy)
			->where('financer_name','like','%'.$term.'%')
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();	
	}	
}
