<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterGender extends Model {
	protected $table = 'car_m_gender';
	public $incrementing = false;
	public function getGender($policy) {
		return self::select('code  as id', 'gender_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getGenderId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
