<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterInsurer extends Model {
	protected $table = 'car_m_insurer2';
	protected $fillable = ['bajaj','insurer_name','id','code'];
	public $incrementing = false;
	public $timestamps = false;

	public function getInsurer($policy) {
		try {
			return self::select('code  as id', 'insurer_name as value')
				->whereNotNull($policy)
				->where(['is_display' => 1])
				->orderBy('display_order', 'desc')
				->get()
				->toArray();
		} catch (Exception $e) {
			$e->getMessage();
		}

	}

	public function getInsurerId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function getName($code) {
		return self::select('insurer_name')->where(['code'=>$code])->first()->insurer_name;
	}

	public function getCode($policy,$code){
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;	
	}

	public function getInsurerList($policy) {
		try {
			return self::select('code  as id', 'insurer_name as value')
				->whereNotNull($policy)
				->where(['is_display' => 1])
				->orderBy('display_order', 'desc')
				->get()
				->toArray();
		} catch (Exception $e) {
			$e->getMessage();
		}

	}
}
