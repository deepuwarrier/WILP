<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterNationality extends Model {
	protected $table = 'car_m_nationality';
	public $incrementing = false;
	public function getNationality($policy) {
		return self::select('code  as id', 'nationality_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getNationalityId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
