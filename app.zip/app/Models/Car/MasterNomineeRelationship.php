<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterNomineeRelationship extends Model {
	protected $table = 'car_m_nomineerelationship';
	public $incrementing = false;
	public function getNomineerelationship($policy) {
		return self::select('code  as id', 'nomineerelationship_name as value')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getNomineerelationshipId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function getNomineeRelationshipName($code) {
		return self::select('nomineerelationship_name')->where(['code'=>$code])->first()->nomineerelationship_name;
	}

	public function getCode($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
        
    public function getName($code){
        return self::select('nomineerelationship_name')->where(['code'=>$code])->first()->nomineerelationship_name;
    }

    public function getNomineerelationshipList($policy) {
		return self::select('code  as id', 'nomineerelationship_name as value')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}
}
