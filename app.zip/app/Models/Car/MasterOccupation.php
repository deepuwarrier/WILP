<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterOccupation extends Model {
	protected $table = 'car_m_occupation';
	public $incrementing = false;
	public function getOccupation($policy) {
		return self::select('code  as id', 'occupation_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getOccupationId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
