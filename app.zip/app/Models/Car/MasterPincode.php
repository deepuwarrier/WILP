<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterPincode extends Model {
	protected $table = 'car_m_pincode';
	public $incrementing = false;
	public function getPincode($policy) {
		return self::where('pincode',$policy)
			// ->where(['is_display' => 1])
			// ->orderBy('display_order', 'desc')
			->first();
	}

	public function getOccupationId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function getDataByPincode($data,$pincode){
		return self::select($data)->where(['pincode'=>$pincode])->first();
	}
}
