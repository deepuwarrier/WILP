<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterRepair extends Model {
	protected $table = 'car_m_repair';
	public $incrementing = false;
	public function getRepair($policy) {
		return self::select('code  as id', 'repair_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getRepairId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
