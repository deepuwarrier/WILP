<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterRoadType extends Model {
	protected $table = 'car_m_roadtype';
	public $incrementing = false;
	public function getRoadtype($policy) {
		return self::select('code  as id', 'roadtype_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}

	public function getRoadtypeId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}
}
