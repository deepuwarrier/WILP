<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterState extends Model {
	protected $table = 'car_m_state2';
	public $incrementing = false;
	
	public function getState($policy) {
		return self::select('code  as id', 'state_name as value', 'code')
			->where(['is_display' => 1])
			->whereNotNull($policy)
			->orderBy('display_order', 'desc')
			->whereHas('city',function($query) use ($policy){
				return $query->whereNotNull($policy); 
			})
			->get()
			->toArray();
	}

	public function getStateName($code) {
		return self::select('state_name')->where(['code'=>$code])->first()->state_name;
	}

	public function getStateId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function getCity($policy, $policy_state_code) {
		try {
			return self::select('car_m_city2.' . $policy . ' as id', 'car_m_city2.city_name as value')->join('car_m_city2', "car_m_city2.state_code",
				"=", "car_m_state2.code")
				->where(['car_m_state2.' . $policy => $policy_state_code
					, 'car_m_city2.is_display' => 1])
				->whereNotNull('car_m_city2.' . $policy)
				->orderBy('car_m_city2.display_order', 'desc')
				->get()
				->toArray();

		} catch (Exception $e) {
			return dd(DB::getQueryLog());
		}
	}

	public function city(){
		return $this->hasMany('App\Models\Car\MasterCity','state_code','code');
	}

	public function  getCarState($all=0){
    	return self::select('code as state_id','state_name as state','state_code')
    		->where('is_display', 1)
    		->whereNotNull('state_code')
    		->orderBy('display_order', 'desc')
    		->get();
    }

    public function getGSTCode($code) {
		return self::select('gst_code')->where(['code'=>$code])->first()->gst_code;
	}

	public function getGSTCodeByState($code) {
		return self::select('gst_code')->where(['state_code'=>$code])->first()->gst_code;
	}

	public function getStateList($policy = null) {
		if(!$policy)
			$policy = 'code';

		return self::select('code  as id', 'state_name as value', 'code')
		->where(['is_display' => 1])
		->whereNotNull($policy)
		->orderBy('display_order', 'desc')
		->whereHas('city',function($query) use ($policy){
			return $query->whereNotNull($policy); 
		})
		->get()
		->toArray();
	}

	public static function getName($code) {
		return self::select('state_name')->where(['code'=>$code])->first()->state_name;
	}
}
