<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterTitle extends Model {
	protected $table = 'car_m_title';
	public $incrementing = false;
	public function getTitle($policy) {
		return self::select('code  as id', 'title_name as value', 'code')
			->whereNotNull($policy)
			->where(['is_display' => 1])
			->orderBy('display_order', 'desc')
			->get()
			->toArray();
	}
}
