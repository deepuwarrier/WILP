<?php

namespace App\Models\Car;

use Illuminate\Database\Eloquent\Model;

class MasterVehicleBody extends Model {
	protected $table = 'car_m_vehiclebody';
	public $incrementing = false;

	public function getVehiclebody($policy) {
		return self::select("code as id", 'vehiclebody_name as value')
			->whereNotNull($policy)
			->where(['is_display' => 1])->orderBy('display_order', 'desc')->get()->toArray();
	}

	public function getVehiclebodyId($policy,$code) {
		return self::select($policy.'  as id')->where(['code'=>$code])->first()->id;
	}

	public function getVehiclebodyName($code) {
		return self::select('vehiclebody_name')->where(['code'=>$code])->first()->vehiclebody_name;
	}

	public function getName($code){
		return self::select('vehiclebody_name')->where(['code'=>$code])->first()->vehiclebody_name;
	}
}
