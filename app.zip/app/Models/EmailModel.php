<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Constants\Common_Constants;

use Illuminate\Support\Facades\DB;

class EmailModel extends Model
{
    public function getContactUsEmailId(){
    	$status = 1;
        $events_id = Common_Constants::CONTACT_US_EVENT_ID;
    	$table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
    				->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
    				->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
    				->select('email')
    				->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
    				->get();
    	return $table;

    }
    
    public function getProposalErrEmailId(){
        $status = 1;
        $events_id = Common_Constants::PROPOSAL_ERROR_EVENT_ID;
        $table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
                    ->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
                    ->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
                    ->select('email')
                    ->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
                    ->get();
        return $table;

    }

    public function getProposalSuccEmailId(){
        $status = 1;
        $events_id = Common_Constants::PAYMENT_SUCCESS_EVENT_ID;
        $table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
                    ->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
                    ->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
                    ->select('email')
                    ->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
                    ->get();
        return $table;

    }

    public function getProposalFailEmailId(){
        $status = 1;
        $events_id = Common_Constants::PAYMENT_FAILED_EVENT_ID;
        $table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
                    ->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
                    ->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
                    ->select('email')
                    ->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
                    ->get();
        return $table;
    }

    public function getEmailId($events_id){
        $status =   1;
        $table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
                    ->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
                    ->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
                    ->select('email')
                    ->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
                    ->get();
        return $table;
    }

    public function getProposalFinishHitEmailId() {
        $status = 1;
        $events_id = Common_Constants::PROPOSAL_POLICY_FINISH_HIT_EVENT_ID;
        $table = DB::table(Common_Constants::INSTA_EMAIL_EVENTS_TABLE)
                    ->join(Common_Constants::INSTA_EMAIL_TRIGGER_TABLE, Common_Constants::INSTA_EMAIL_EVENTS_TABLE.'.id', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.events_id')
                    ->join(Common_Constants::INSTA_USERS_TABLE, Common_Constants::INSTA_USERS_TABLE.'.user_type', '=', Common_Constants::INSTA_EMAIL_TRIGGER_TABLE.'.user_type_id')
                    ->select('email')
                    ->where('email_trigger_id',$status)
                    ->where('events_id',$events_id)
                    ->get();
        return $table;

    }
}
