<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @author ravirao
 *
 */
class FaqModel extends Model {
	protected $table = 'insta_faq';

	/**
	 * @return unknown
	 */
	public function getFaqList() {
	return FaqModel::all();
	}
}