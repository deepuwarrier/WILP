<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class AppointeeRel extends Model
{
   protected $table = 'health_m_appointee_rel';
    public $timestamps = false;
    protected $fillable = ['insta_code','appointee_rel','religare_code','star_code','bagi_code','usgi_code','hdfc_code','bajaj_code','is_display'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

     public function getAppointeeRelationship($appointee){
        return self::select('appointee_rel', $appointee)
        ->where('is_display', '1')
        ->whereNotNull($appointee)
        ->get();
    }
}
