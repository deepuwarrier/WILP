<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthBenifit extends Model
{
    protected $table = 'health_m_benifit';
    
    public $timestamps = false;
    
    protected $fillable = ['benifit_code','feature_name','religare_1','religare_2','religare_3','star_mci_1','star_mci_2','star_mci_3','star_fho_1','star_fho_2','star_fho_3','star_comp_1','star_comp_2','star_comp_3','star_comp_4','star_comp_5','star_comp_6','hdfc_silver_1','hdfc_silver_2','hdfc_silver_3','hdfc_silver_regain_1', 'hdfc_silver_regain_2','hdfc_silver_regain_3','hdfc_gold_1','hdfc_gold_2','hdfc_gold_3','hdfc_gold_regain_1','hdfc_gold_regain_2','hdfc_gold_regain_3','hdfc_platinum_1','hdfc_platinum_2','hdfc_platinum_3','sompo_1','sompo_2','sompo_3','rsgi_classic','rsgi_supreme','rsgi_elite','reliance'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_benifit($features){
 		return self::select('feature_name', $features)
 		->where('is_display', '1')
 		->whereNotNull($features)
 		->get();
 	}	

}
