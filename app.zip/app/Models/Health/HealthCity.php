<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthCity extends Model
{
    protected $table = 'health_m_city';
    
    public function get_city($stateID,$insurer){
        $insurer_name = $insurer.'_code';
        return HealthCity::select('state_code', 'city_code', 'city_name', $insurer_name)
        ->where('state_code',$stateID)
        ->where('is_display', '1')
        ->orderBy($insurer_name, 'asc')
        ->whereNotNull($insurer_name)
        ->get();
    } 

    public function get_city_list($city, $insurer){
        return HealthCity::select('city_name', $insurer)
        ->where('city_name', $city)
        ->first();
    }

    public function get_city_campaign_list($city, $insurer){
        return HealthCity::select('city_name', $insurer)
        ->where('city_code', $city)
        ->first();
    }

    public function get_city_name($city_code, $insurer){
        return HealthCity::select('city_name', $insurer)
        ->where('city_code', $city_code)
        ->first();
    }

    public function city_details($city_code) {
        return HealthCity::select('*')->where('city_code', $city_code)->first();
    }
}
