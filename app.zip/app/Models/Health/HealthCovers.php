<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthCovers extends Model
{
    
    protected $table = 'health_m_covers';

    public $timestamps = true;

    protected $fillable = ['cover_id','cover_name','description','religare_super_saver','religare_elite','religare_elite_plus'];

    

    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->table;
    }

	public function getCovers(){
 		return self::select('id', 'cover_id', 'cover_name','description')
 		->where('is_display', '1')
 		->get();
 	}	 

}