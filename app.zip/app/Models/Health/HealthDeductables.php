<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthDeductables extends Model
{
    protected $table = 'health_m_deductables';
    
    public $timestamps = false;
    
    protected $fillable = ['deductable','hdfc_code','rsgi_code','religare_code','amhi_code'];


    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_deductible_list(){
         return HealthDeductables::select('deductable')->get()->toArray();
    }


    public function get_deductible_amount($insurer_code){
        return HealthDeductables::select('deductable')->whereNotNull($insurer_code)->get();
    }

    public function get_deductable_plans($deductable,$insurer_code){
 		$result = self::select($insurer_code)
        ->where('deductable',$deductable)
        ->first()->toArray();
        return $result;
 	}	

}
