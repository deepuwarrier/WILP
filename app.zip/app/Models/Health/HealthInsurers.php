<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthInsurers extends Model {
	protected $table = 'health_m_insurers';
	
	public function insurer_details ($insurer_code) {
		return HealthInsurers::select('*')->where('isu_code', $insurer_code)->first();
	}
	
	public function insurer_column ($insurer_code, $column_name) {
		return HealthInsurers::select($column_name)->where('isu_code', $insurer_code)->first();
	}
	
}