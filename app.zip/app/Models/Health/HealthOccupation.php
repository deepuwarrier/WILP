<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthOccupation extends Model
{
    protected $table = 'health_m_occupation';
    
    public $timestamps = false;
    
    protected $fillable = ['insta_code','occupation_name', 'rsgi_code', 'reliance_code','star_code','star_code_red', 'is_display'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function getOccupations($occupation){
 		return self::select('occupation_name', $occupation)
 		->where('is_display', '1')
 		->whereNotNull($occupation)
 		->orderBy('occupation_name', 'asc')
 		->get()->toArray();
 	}


    // Occupation list based on new flow
 	public function occupation_list($occupation){
 		return HealthOccupation::select('occupation_name', $occupation)
 		->where('is_display', '1')
 		->whereNotNull($occupation)
 		->orderBy('occupation_name', 'asc')
 		->get();
 	}	


}