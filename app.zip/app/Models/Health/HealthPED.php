<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthPED extends Model
{
    protected $table = 'health_m_ped';
    public $timestamps = false;

    protected $fillable = ['id','ped_code','name','hdfc_code','rsgi_code','religare_code','star_code','reliance_code','question_type'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_ped_list($insurer, $question_type){
    	return self::select('ped_code','name','short_code',$insurer)
    	->where('question_type', $question_type)
    	->whereNotNull($insurer)
    	->get()
    	->toArray();
    }
   
}
