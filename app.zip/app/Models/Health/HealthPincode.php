<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthPincode extends Model {
	protected $table = 'health_m_pincode';
	public $incrementing = false;

	public function get_data_by_pincode($city_code){
		return self::select('district_id','pincode')
		->where(['city_code'=>$city_code])
		->distinct()
		->get();
	}


	public function get_address_list($pincode){
		return self::select('district_id','pincode')
		->where(['pincode'=>$pincode])
		->first()->toArray();
	}

}
