<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthPlans extends Model
{
    
    
    protected $table = 'health_m_plan';

    protected $fillable = ['plan_id', 'product_code','product_name', 'plan_code','plan_si_code','plan_name','plan_min_age','plan_max_age','plan_insured_pattern','plan_si','plan_tenure','is_display'];

    
    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->table;
        
    }

    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false; 
    }


    public function get_plans($column, $check_values){
        return self::select($column)
        ->where($check_values)
        ->get()->toArray();
    }

}
