<?php 

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthQuoteResponse extends Model
{
    
    protected $table = 'health_t_quoteresponse';

    public $timestamps = true;

    protected $fillable = ['session_id','trans_code','planSI', 'productId','insurerId','health_user_id','rsgi_quote_id','productType','productName','product_planname','insurerName','covers','netPremium','serviceTax','cgst' ,'sgst','totalPremium','star_suminsured_id','star_scheme_id','plan_code'];


    public function getresponse($trans_code){
        return self::select('session_id','trans_code', 'planSI', 'productId','insurerId','health_user_id','rsgi_quote_id','productType','productName','product_planname','insurerName','covers','netPremium','serviceTax','cgst' ,'sgst','totalPremium','star_suminsured_id','star_scheme_id','plan_code')
            ->where(['trans_code'=>$trans_code])
            ->get();
    }

    public function getdata($trans_code, $productId){
        return self::select('session_id','trans_code', 'rsgi_quote_id', 'planSI','insurerId','productId','insurerName','productName','product_planname','productType','totalPremium','cgst','sgst','serviceTax','netPremium','star_suminsured_id','star_scheme_id', 'plan_code')
            ->where('trans_code', $trans_code)
            ->where('productId', $productId)
            ->first()->toArray();

    }

    public function get_RSGI_QuoteId($trans_code) {
        return self::select('rsgi_quote_id')
            ->where(['trans_code'=>$trans_code])
            ->whereNotNull('rsgi_quote_id')
            ->first()->toArray();
    }

    public function get_si($trans_code, $product){
        $res =  self::select('planSI')
            ->where(['trans_code'=>$trans_code])
            ->where(['productId'=>$product])
            ->get()->toArray();
        if(!empty($res)){
            return $res[0]['planSI'];
        }
        return null;    
    }

    public function update_or_create($check_values, $inputs){
        return self::updateOrCreate($check_values, $inputs);
    }

    public function get_filter_data($check_values){
        return self::where($check_values)
        ->get();
    }

    public function get_data($column, $check_values){
        return self::where($check_values)
        ->first($column)->toArray();
    }

    
}
