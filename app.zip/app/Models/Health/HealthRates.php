<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthRates extends Model
{
    protected $table = 'health_m_rate';

    protected $fillable = ['rate_id','product_code','product_name', 'plan_code','plan_name', 'base_premium'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result[0];
        else return false; 
    }

    public function getpremium($plancode, $planname, $plansi){
        $res = self::select('rate_id','product_code','product_name','plan_code','plan_name', 'base_premium')
        ->where('plan_code',$plancode)
        ->where('plan_name',$planname)
        ->get()->toArray();
        if(!empty($res)){
            $res[0]['planSI'] = $plansi;
        }
        return $res;
    }
    
}

