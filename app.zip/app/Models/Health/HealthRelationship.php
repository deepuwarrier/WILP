<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthRelationship extends Model {
    
    protected $table = 'health_m_relationship';

    public $timestamps = false;

    protected $fillable = ['rel_id', 'rel_name','hdfc_code','star_code_com','star_code_red_carp','star_code_fho','star_code_mci', 'rsgi_code', 'reliance_code', 'is_display'];
    
    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function getRelationship($for){
        return self::select($for,'rel_name')
        ->where('is_display', '1')
        ->whereNotNull($for)
        ->get()->toArray();
    }  
        /* For Updated code use */
    public function get_relationship_ids($column){
        return HealthRelationship::select($column,'rel_name')
        ->where('is_display', '1')
        ->whereNotNull($column)
        ->get();
    } 

}