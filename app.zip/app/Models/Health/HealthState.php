<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthState extends Model
{
    protected $table = 'health_m_state';
    
    public function get_state($insurer){
        //$insurer_name = $this->get_insurer_name($insurer);
        return HealthState::select('state_code', 'state_name', $insurer)
        ->where('is_display', '1')
        ->whereNotNull($insurer)
        ->get();
    } 

    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false; 
    }

    public function get_state_list($state, $insurer){
        return HealthState::select('state_code', 'state_name', $insurer)
        ->where('state_name', $state)
        ->first();
    }

    public function get_state_campaign_list($state, $insurer){
        return HealthState::select('state_code', 'state_name', $insurer)
        ->where('state_code', $state)
        ->first();
    }
    
    public function state_details($state_code) {
        return HealthState::select('*')->where('state_code', $state_code)->first();
    }

}
