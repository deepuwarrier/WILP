<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class HealthSumInsured extends Model
{
    protected $table = 'health_m_suminsured';
    
    public $timestamps = false;
    
    protected $fillable = ['suminsured','insta_si'];


    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_suminsured_amount(){
        return HealthSumInsured::select('insta_si')->get()->toArray();
    }

}
