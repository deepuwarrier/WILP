<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthTPolicy extends Model {
    
    protected $table = 'health_t_policy';

   

    protected $fillable = [ 'session_id','trans_code','rsgi_quote_id','insurerId','productId','insurerName','productName','product_planname','totalPremium','cgst','sgst','serviceTax','basePremium','plan_type','product_type','dob_list','age_list','members_list','gender','adult','children','tenure','policy_start_date','policy_exp_date','sum_insured','sum_insuredid','scheme_id','plan_id','deductables','cover_id','pincode','cust_pincode','title','houseno','firstname','lastname','height_feet','height_inches','weight','occupation','designation','business','marital_status','education','nominee_name','nominee_age','nominee_dob','nominee_relation','pan_number','aadhaar_num','ped_list','ped_lifestyle','ped_since_from','house_num','street','locality','state','city','cust_area','email','mobile','rsgi_hosp_cash','rsgi_top_up','rsgi_deductible_amount','rsgi_international_treatment','rsgi_refr_status','policy_date','policy_num','reference_num','payment_status','trans_status','pay_quote_id','payment_response_log','transaction_id','proposal_num','order_num','customer_id','user_code','agent_code','quote_response','partner_code','agree_med_chkup','pay_mode','add_on','star_add_on','star_persaonal_accedent','plan_code','quote_create_date','quote_status','proposal_date','proposal_status','payment_date','payment_ref_number','payment_desc','policy_status','campaign_initial_inputs','campaign_customer_pointer','campaign_txn_number'];

    public static $user_data = ['id','session_id','trans_code','rsgi_quote_id','insurerId','productId','insurerName','productName','product_planname','totalPremium','cgst','sgst','serviceTax','basePremium','plan_type','product_type','dob_list','age_list','members_list','gender','adult','children','tenure','policy_start_date','policy_exp_date','sum_insured','sum_insuredid','scheme_id','plan_id','deductables','cover_id','pincode','cust_pincode','title','houseno','firstname','lastname','height_feet','height_inches','weight','occupation','designation','business','marital_status','education','nominee_name','nominee_age','nominee_dob','nominee_relation','pan_number','aadhaar_num','ped_list','ped_lifestyle','ped_since_from','house_num','street','locality','state','city','cust_area','email','mobile','rsgi_hosp_cash','rsgi_top_up','rsgi_deductible_amount','rsgi_international_treatment','rsgi_refr_status','policy_date','policy_num','reference_num','payment_status','trans_status','pay_quote_id','payment_response_log','transaction_id','proposal_num','order_num','customer_id','user_code','agent_code','quote_response','partner_code','agree_med_chkup','pay_mode','add_on','star_add_on','star_persaonal_accedent','plan_code','quote_create_date','quote_status','proposal_date','proposal_status','payment_date','payment_ref_number','payment_desc','policy_status','campaign_initial_inputs','campaign_customer_pointer','campaign_txn_number'];
    
    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->table;
        
    }

    public function set_policy_details($usr_data){
    	$policy_data = self::create($usr_data);
    }
}

