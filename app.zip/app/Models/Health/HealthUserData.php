<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;


class HealthUserData extends Model {
    
    protected $table = 'health_t_usrdata';

    protected $fillable = [ 'session_id','trans_code','rsgi_quote_id','insurerId','productId','insurerName','productName','product_planname','totalPremium','cgst','sgst','serviceTax','basePremium','plan_type','product_type','dob_list','age_list','members_list','gender','adult','children','tenure','policy_start_date','policy_exp_date','sum_insured','deductables','cover_id','pincode','cust_pincode','title','houseno','firstname','lastname','height_feet','height_inches','weight','occupation','designation','business','marital_status','education','nominee_name','nominee_age','nominee_dob','nominee_relation','pan_number','aadhaar_num','ped_list','ped_lifestyle','ped_since_from','house_num','street','locality','state','city','cust_area','email','mobile','rsgi_hosp_cash','rsgi_top_up','rsgi_deductible_amount','rsgi_international_treatment','rsgi_refr_status','policy_date','policy_num','reference_num','payment_status','trans_status','pay_quote_id','payment_response_log','transaction_id','proposal_num','order_num','customer_id','user_code','agent_code','quote_response','partner_code','agree_med_chkup','pay_mode','add_on','star_add_on','star_persaonal_accedent','plan_code','quote_create_date','quote_status','proposal_date','proposal_status','payment_date','payment_ref_number','payment_desc','policy_status','campaign_initial_inputs','campaign_customer_pointer','campaign_txn_number'];

    public static $user_data = ['id','session_id','trans_code','rsgi_quote_id','insurerId','productId','insurerName','productName','product_planname','totalPremium','cgst','sgst','serviceTax','basePremium','plan_type','product_type','dob_list','age_list','members_list','gender','adult','children','tenure','policy_start_date','policy_exp_date','sum_insured','deductables','cover_id','pincode','cust_pincode','title','houseno','firstname','lastname','height_feet','height_inches','weight','occupation','designation','business','marital_status','education','nominee_name','nominee_age','nominee_dob','nominee_relation','pan_number','aadhaar_num','ped_list','ped_lifestyle','ped_since_from','house_num','street','locality','state','city','cust_area','email','mobile','rsgi_hosp_cash','rsgi_top_up','rsgi_deductible_amount','rsgi_international_treatment','rsgi_refr_status','policy_date','policy_num','reference_num','payment_status','trans_status','pay_quote_id','payment_response_log','transaction_id','proposal_num','order_num','customer_id','user_code','agent_code','quote_response','partner_code','agree_med_chkup','pay_mode','add_on','star_add_on', 'star_persaonal_accedent','plan_code','quote_create_date','quote_status','proposal_date','proposal_status','payment_date','payment_ref_number','payment_desc','policy_status','campaign_customer_pointer','campaign_txn_number'];
    

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column, $check_values){
        return self::where($check_values)
        ->get($column)->toArray();
    }

    public function update_data($column, $check_values){
        return self::where($check_values)
        ->update($column);
    }

    public function update_or_create($trans_code, $inputs){
        return self::updateOrCreate($trans_code, $inputs);
    }

    public function get_deductables($trans_code){
        return  self::select('deductables','product_type')
            ->where(['trans_code'=>$trans_code])
            ->get()->toArray()[0];
    }

    public function getUserTData($trans_code,$select = null){
        $select = ($select)? $select : SELF::$user_data;
        return self::select($select)
            ->where(['trans_code'=>$trans_code])
            ->first()->toArray();
    }  


    
/* Transcation code based new flow  */
    public function set_by_usrdata($trans_code, $data) {
         HealthUserData::where('trans_code', $trans_code)->update($data);
    }

    public function get_by_usrdata($trans_code) {
        return HealthUserData::all()->where('trans_code', $trans_code)->first();
    }

    public function get_trans_list($from_date, $to_date, $agent_code) {
        $data =  Self::whereRaw("STR_TO_DATE(`quote_create_date`,'%d-%b-%Y') between STR_TO_DATE('".$from_date."','%d-%b-%Y') and STR_TO_DATE('".$to_date."','%d-%b-%Y')");
        if(($agent_code != 'all') || ($agent_code == null)){
            $data->where('agent_code',$agent_code);
        }
        return $data->get();
    }

    public function get_by_tc($trans_code) {
        return self::all()->where('trans_code', $trans_code)->first();
    }
    
    public function get_by_sc($ssn_key) {
        return self::all()->where('session_id',$ssn_key)->first();
    }

}

