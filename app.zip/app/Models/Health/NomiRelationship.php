<?php

namespace App\Models\Health;

use Illuminate\Database\Eloquent\Model;

class NomiRelationship extends Model
{
    protected $table = 'health_m_nominee_rel';
    public $timestamps = false;
    protected $fillable = ['insta_code','nominee_rel','religare_code','reliance_code','star_code_mci','star_code_fho','star_code_com','star_code_red_carp','hdfc_code','is_display'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }


    public function getNomRelationship($nominee){
        return self::select('nominee_rel', $nominee)
        ->whereNotIn($nominee, ['','NULL'])
        ->where('is_display', '1')
        ->get()->toArray();
    }  

    /*  For updated code object formate */
    public function nominee_rel_list($nominee){
        return NomiRelationship::select('nominee_rel', $nominee)
        ->whereNotIn($nominee, ['','NULL'])
        ->where('is_display', '1')
        ->get();
    } 

}
