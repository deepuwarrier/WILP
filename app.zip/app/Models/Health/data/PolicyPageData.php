<?php

namespace App\Models\Health\data;

class PolicyPageData {
  private $_hl_trans_code = null;
  private $_tenure = 1;
  private $_plan_type = '';
  private $_policy_start = null;
  private $_policy_end = null; 
  private $_product_id = '';
  private $_product_plan = '';
  private $_insurer_name = '';
  private $_sum_insured = '';
  private $_sumInsuredId = '';
  private $_schemeId = '';
  private $_planId = '';
  private $_occupation_list = null;
  private $_nominee_rel_list = null;
  private $_relation_list = null;
  private $_ped_list = null;
  private $_ped_lifestyle_questions = null;
  private $_dob_list = null;
  private $_adult = null;
  private $_children = null;
  private $_age_list = null;
  private $_firstname = null;
  private $_lastname = null;
  private $_gender = '';
  private $_title = null;
  private $_pancard = null;
  private $_aadhaar = null;
  private $_feet = null;
  private $_inches = null;
  private $_weight = null;
  private $_member_occupation = null;
  private $_occupation_details = null;
  private $_email = null;
  private $_mobile = null;
  private $_houseno = null;
  private $_street = null;
  private $_locality = null;
  private $_cust_pincode = null;
  private $_state = null;
  private $_city = null;
  private $_district = null;
  private $_cust_area = null;
  private $_ped_details = null;
  private $_social_status = null;
  private $_below_poverty = 0;
  private $_unorganized_sector = 0;
  private $_handicaped = 0;
  private $_informal_sector = 0;
  private $_nominee_name = null;
  private $_nominee_age = null;
  private $_nominee_dob = null;
  private $_nominee_relation = null;
  private $_star_hosp_cash = 0;
  private $_rsgi_hosp_cash = 'off';
  private $_referenceId = null;
  private $_final_premium = null;
  private $_final_serviceTax = null;
  private $_final_totalPremium = null;
  private $_personal_accident = false;
  private $_relationId = '';
  private $_bmi_status = '';
  private $_ped_status = '';
  private $_agree_medical_checkup = null;
  private $_members_list = null;
  private $_deductibles_list = 0;
  private $_merital_status = null;
  private $_rsgi_quote_id = null;
  private $_education = null;
  private $_international_treatment = 'off';
  private $_deductible_amount = 0;
  private $_rsgi_top_up = 'off';
  private $_error_message = null;
  private $_product_type = '';
  private $_top_up = 'off';
  private $_nationality = '';
  private $_pincode_list = null;



  public function get_hl_trans_code(){
    return $this->_hl_trans_code;
  }

  public function set_hl_trans_code($_hl_trans_code){
    $this->_hl_trans_code = $_hl_trans_code;
  }

  public function get_tenure(){
    return $this->_tenure;
  }

  public function set_tenure($_tenure){
    $this->_tenure = $_tenure;
  }

  public function get_plan_type(){
    return $this->_plan_type;
  }

  public function set_plan_type($_plan_type){
    $this->_plan_type = $_plan_type;
  }

  public function get_policy_start(){
    return $this->_policy_start;
  }

  public function set_policy_start($_policy_start){
    $this->_policy_start = $_policy_start;
  }

  public function get_policy_end(){
    return $this->_policy_end;
  }

  public function set_policy_end($_policy_end){
    $this->_policy_end = $_policy_end;
  }

  public function get_product_id(){
    return $this->_product_id;
  }

  public function set_product_id($_product_id){
    $this->_product_id = $_product_id;
  }
  

  public function get_product_plan(){
    return $this->_product_plan;
  }

  public function set_product_plan($_product_plan){
    $this->_product_plan = $_product_plan;
  }

  public function get_sum_insured(){
    return $this->_sum_insured;
  }

  public function set_sum_insured($_sum_insured){
    $this->_sum_insured = $_sum_insured;
  }

  public function get_sumInsuredId(){
    return $this->_sumInsuredId;
  }

  public function set_sumInsuredId($_sumInsuredId){
    $this->_sumInsuredId = $_sumInsuredId;
  }

  public function get_schemeId(){
    return $this->_schemeId;
  }

  public function set_schemeId($_schemeId){
    $this->_schemeId = $_schemeId;
  }

  public function get_planId(){
    return $this->_planId;
  }

  public function set_planId($_planId){
    $this->_planId = $_planId;
  }


  public function get_occupation_list(){
    return $this->_occupation_list;
  }

  public function set_occupation_list($_occupation_list){
    $this->_occupation_list = $_occupation_list;
  }

  public function get_nominee_rel_list(){
    return $this->_nominee_rel_list;
  }

  public function set_nominee_rel_list($_nominee_rel_list){
    $this->_nominee_rel_list = $_nominee_rel_list;
  }

  public function get_relation_list(){
    return $this->_relation_list;
  }

  public function set_relation_list($_relation_list){
    $this->_relation_list = $_relation_list;
  }

  public function get_ped_list(){
    return $this->_ped_list;
  }

  public function set_ped_list($_ped_list){
    $this->_ped_list = $_ped_list;
  }
    
  public function get_ped_lifestyle_questions(){
    return $this->_ped_lifestyle_questions;
  }

  public function set_ped_lifestyle_questions($_ped_lifestyle_questions){
    $this->_ped_lifestyle_questions = $_ped_lifestyle_questions;
  }


  
  public function get_dob_list(){
    return $this->_dob_list;
  }

  public function set_dob_list($_dob_list){
    $this->_dob_list = $_dob_list;
  }

  public function get_age_list(){
    return $this->_age_list;
  }

  public function set_age_list($_age_list){
    $this->_age_list = $_age_list;
  }


  public function get_firstname(){
    return $this->_firstname;
  }

  public function set_firstname($_firstname){
    $this->_firstname = $_firstname;
  }

  public function get_lastname(){
    return $this->_lastname;
  }

  public function set_lastname($_lastname){
    $this->_lastname = $_lastname;
  }

  public function get_gender(){
    return $this->_gender;
  }

  public function set_gender($_gender){
    $this->_gender = $_gender;
  }


public function get_title(){
    return $this->_title;
  }

  public function set_title($_title){
    $this->_title = $_title;
  }

   public function get_pancard(){
    return $this->_pancard;
  }

  public function set_pancard($_pancard){
    $this->_pancard = $_pancard;
  }

  public function get_aadhaar(){
    return $this->_aadhaar;
  }

  public function set_aadhaar($_aadhaar){
    $this->_aadhaar = $_aadhaar;
  }

  public function get_feet(){
    return $this->_feet;
  }

  public function set_feet($_feet){
    $this->_feet = $_feet;
  }

  public function get_inches(){
    return $this->_inches;
  }

  public function set_inches($_inches){
    $this->_inches = $_inches;
  }
  public function get_weight(){
    return $this->_weight;
  }

  public function set_weight($_weight){
    $this->_weight = $_weight;
  }

  public function get_member_occupation(){
    return $this->_member_occupation;
  }

  public function set_member_occupation($_member_occupation){
    $this->_member_occupation = $_member_occupation;
  }

  public function get_occupation_details(){
    return $this->_occupation_details;
  }

  public function set_occupation_details($_occupation_details){
    $this->_occupation_details = $_occupation_details;
  }


  public function get_email(){
    return $this->_email;
  }

  public function set_email($_email){
    $this->_email = $_email;
  }

  public function get_mobile(){
    return $this->_mobile;
  }

  public function set_mobile($_mobile){
    $this->_mobile = $_mobile;
  }

  public function get_houseno(){
    return $this->_houseno;
  }

  public function set_houseno($_houseno){
    $this->_houseno = $_houseno;
  }

  public function get_street(){
    return $this->_street;
  }

  public function set_street($_street){
    $this->_street = $_street;
  }

   public function get_locality(){
    return $this->_locality;
  }

  public function set_locality($_locality){
    $this->_locality = $_locality;
  }

  public function get_cust_pincode(){
    return $this->_cust_pincode;
  }

  public function set_cust_pincode($_cust_pincode){
    $this->_cust_pincode = $_cust_pincode;
  }

  public function get_state(){
    return $this->_state;
  }

  public function set_state($_state){
    $this->_state = $_state;
  }
  public function get_city(){
    return $this->_city;
  }

  public function set_city($_city){
    $this->_city = $_city;
  }

  public function get_district(){
    return $this->_district;
  }

  public function set_district($_district){
    $this->_district = $_district;
  }
  

  public function get_cust_area(){
    return $this->_cust_area;
  }

  public function set_cust_area($_cust_area){
    $this->_cust_area = $_cust_area;
  }

  public function get_ped_details(){
    return $this->_ped_details;
  }

  public function set_ped_details($_ped_details){
    $this->_ped_details = $_ped_details;
  }

  public function get_social_status(){
    return $this->_social_status;
  }

  public function set_social_status($_social_status){
    $this->_social_status = $_social_status;
  }

  public function get_below_poverty(){
    return $this->_below_poverty;
  }

  public function set_below_poverty($_below_poverty){
    $this->_below_poverty = $_below_poverty;
  }

   public function get_unorganized_sector(){
    return $this->_unorganized_sector;
  }

  public function set_unorganized_sector($_unorganized_sector){
    $this->_unorganized_sector = $_unorganized_sector;
  }

  public function get_handicaped(){
    return $this->_handicaped;
  }

  public function set_handicaped($_handicaped){
    $this->_handicaped = $_handicaped;
  }

public function get_informal_sector(){
    return $this->_informal_sector;
  }

  public function set_informal_sector($_informal_sector){
    $this->_informal_sector = $_informal_sector;
  }

  public function get_nominee_name(){
    return $this->_nominee_name;
  }

  public function set_nominee_name($_nominee_name){
    $this->_nominee_name = $_nominee_name;
  }

  public function get_nominee_dob(){
    return $this->_nominee_dob;
  }

  public function set_nominee_dob($_nominee_dob){
    $this->_nominee_dob = $_nominee_dob;
  }



  public function get_nominee_age(){
    return $this->_nominee_age;
  }

  public function set_nominee_age($_nominee_age){
    $this->_nominee_age = $_nominee_age;
  }
  public function get_nominee_relation(){
    return $this->_nominee_relation;
  }

  public function set_nominee_relation($_nominee_relation){
    $this->_nominee_relation = $_nominee_relation;
  }

  public function get_star_hosp_cash(){
    return $this->_star_hosp_cash;
  }

  public function set_star_hosp_cash($_star_hosp_cash){
    $this->_star_hosp_cash = $_star_hosp_cash;
  }


  public function get_referenceId(){
    return $this->_referenceId;
  }

  public function set_referenceId($_referenceId){
    $this->_referenceId = $_referenceId;
  }


  public function get_error_message(){
    return $this->_error_message;
  }

  public function set_error_message($_error_message){
    $this->_error_message = $_error_message;
  }

  public function get_final_premium(){
    return $this->_final_premium;
  }

  public function set_final_premium($_final_premium){
    $this->_final_premium = $_final_premium;
  }

  public function get_final_serviceTax(){
    return $this->_final_serviceTax;
  }

  public function set_final_serviceTax($_final_serviceTax){
    $this->_final_serviceTax = $_final_serviceTax;
  }
  
  public function get_final_totalPremium(){
    return $this->_final_totalPremium;
  }

  public function set_final_totalPremium($_final_totalPremium){
    $this->_final_totalPremium = $_final_totalPremium;
  }

  public function get_personal_accident(){
    return $this->_personal_accident;

  }
  public function set_personal_accident($_personal_accident){
    $this->_personal_accident = $_personal_accident;
  }


  public function get_relationId(){
    return $this->_relationId;
  }

  public function set_relationId($_relationId){
    $this->_relationId = $_relationId;
  }

  public function get_insurer_name(){
    return $this->_insurer_name;
  }

  public function set_insurer_name($_insurer_name){
    $this->_insurer_name = $_insurer_name;
  }

  public function get_bmi_status(){
    return $this->_bmi_status;
  }

  public function set_bmi_status($_bmi_status){
    $this->_bmi_status = $_bmi_status;
  }

  public function get_ped_status(){
    return $this->_ped_status;
  }

  public function set_ped_status($_ped_status){
    $this->_ped_status = $_ped_status;
  }

  public function get_agree_medical_checkup(){
    return $this->_agree_medical_checkup;
  }

  public function set_agree_medical_checkup($_agree_medical_checkup){
    $this->_agree_medical_checkup = $_agree_medical_checkup;
  }

  public function get_rsgi_hosp_cash(){
    return $this->_rsgi_hosp_cash;
  }

  public function set_rsgi_hosp_cash($_rsgi_hosp_cash){
    $this->_rsgi_hosp_cash = $_rsgi_hosp_cash;
  }


  public function get_members_list(){
    return $this->_members_list;
  }

  public function set_members_list($_members_list){
    $this->_members_list = $_members_list;
  }




  public function get_adult(){
    return $this->_adult;
  }

  public function set_adult($_adult){
    $this->_adult = $_adult;
  }


  public function get_children(){
    return $this->_children;
  }

  public function set_children($_children){
    $this->_children = $_children;
  }

  public function get_deductibles_list(){
    return $this->_deductibles_list;
  }

  public function set_deductibles_list($_deductibles_list){
    $this->_deductibles_list = $_deductibles_list;
  }

  public function get_merital_status(){
    return $this->_merital_status;
  }

  public function set_merital_status($_merital_status){
    $this->_merital_status = $_merital_status;
  }

  public function get_rsgi_quote_id(){
    return $this->_rsgi_quote_id;
  }

  public function set_rsgi_quote_id($_rsgi_quote_id){
    $this->_rsgi_quote_id = $_rsgi_quote_id;
  }

  public function get_education(){
    return $this->_education;
  }

  public function set_education($_education){
    $this->_education = $_education;
  }

  public function get_international_treatment(){
    return $this->_international_treatment;
  }

  public function set_international_treatment($_international_treatment){
    $this->_international_treatment = $_international_treatment;
  }


   public function get_deductible_amount(){
    return $this->_deductible_amount;
  }

  public function set_deductible_amount($_deductible_amount){
    $this->_deductible_amount = $_deductible_amount;
  }

  public function get_rsgi_top_up(){
    return $this->_rsgi_top_up;
  }

  public function set_rsgi_top_up($_rsgi_top_up){
    $this->_rsgi_top_up = $_rsgi_top_up;
  }

  public function get_product_type(){
    return $this->_product_type;
  }

  public function set_product_type($_product_type){
    $this->_product_type = $_product_type;
  }


  public function get_top_up(){
    return $this->_top_up;
  }

  public function set_top_up($_top_up){
    $this->_top_up = $_top_up;
  }

  public function get_nationality(){
    return $this->_nationality;
  }

  public function set_nationality($_nationality){
    $this->_nationality = $_nationality;
  }

  public function get_pincode_list(){
    return $this->_pincode_list;
  }

  public function set_pincode_list($_pincode_list){
    $this->_pincode_list = $_pincode_list;
  }
}
