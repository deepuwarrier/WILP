<?php

namespace App\Models\Health\data;

class QuoteReqData {
	
    private $_trans_code = '';
    private $_pincode = '';
    private $_members_list = '';
    private $_dob_list = '';
    private $_age_list = '';
    private $_adult = 0;
    private $_children = 0;
    private $_tenure = '';
    private $_sum_insured = '';
    private $_star_plans = '';
    private $_plan_type = '';
    private $_product_type = '';
    private $_rsgi_plans = '';
    private $_coverage_type = '';
    private $_city = '';
    private $_firstname = '';
    private $_mobile = '';
    private $_email = '';
    private $_rsgi_hosp_cash = 'off';
    private $_super_topup_opted = 'off';
    private $_deductible_amount = '';
    private $_rsgi_international_treatment_opted = 'off';
    private $_reliance_plans = null;


    public function get_trans_code(){
        return $this->_trans_code;
    }

    public function set_trans_code($_trans_code){
        $this->_trans_code = $_trans_code;
    }

    public function get_pincode(){
        return $this->_pincode;
    }

    public function set_pincode($_pincode){
        $this->_pincode = $_pincode;
    }

    public function get_members_list(){
        return $this->_members_list;
    }

    public function set_members_list($_members_list){
        $this->_members_list = $_members_list;
    }

    public function get_dob_list(){
        return $this->_dob_list;
    }

    public function set_dob_list($_dob_list){
        $this->_dob_list = $_dob_list;
    }

    public function get_age_list(){
        return $this->_age_list;
    }

    public function set_age_list($_age_list){
        $this->_age_list = $_age_list;
    }

    public function get_adult(){
        return $this->_adult;
    }

    public function set_adult($_adult){
        $this->_adult = $_adult;
    }

    public function get_children(){
        return $this->_children;
    }

    public function set_children($_children){
        $this->_children = $_children;
    }

    public function get_tenure(){
        return $this->_tenure;
    }

    public function set_tenure($_tenure){
        $this->_tenure = $_tenure;
    }

    public function get_sum_insured(){
        return $this->_sum_insured;
    }

    public function set_sum_insured($_sum_insured){
        $this->_sum_insured = $_sum_insured;
    }

    public function get_star_plans(){
        return $this->_star_plans;
    }

    public function set_star_plans($_star_plans){
        $this->_star_plans = $_star_plans;
    }

    public function set_reliance_plans($_reliance_plans){
        $this->_reliance_plans = $_reliance_plans;
    }

    public function get_reliance_plans(){
        return $this->_reliance_plans;
    }

    public function get_plan_type(){
        return $this->_plan_type;
    }

    public function set_plan_type($_plan_type){
        $this->_plan_type = $_plan_type;
    }

    public function get_product_type(){
        return $this->_product_type;
    }

    public function set_product_type($_product_type){
        $this->_product_type = $_product_type;
    }


    public function get_rsgi_plans(){
        return $this->_rsgi_plans;
    }

    public function set_rsgi_plans($_rsgi_plans){
        $this->_rsgi_plans = $_rsgi_plans;
    }

    public function set_coverage_type($_coverage_type){
        $this->_coverage_type = $_coverage_type;
    }

    public function get_coverage_type(){
        return $this->_coverage_type;
    }

    public function set_city($_city){
        $this->_city = $_city;
    }

    public function get_city(){
        return $this->_city;
    }

    public function set_firstname($_firstname){
        $this->_firstname = $_firstname;
    }

    public function get_firstname(){
        return $this->_firstname;
    }

    public function set_mobile($_mobile){
        $this->_mobile = $_mobile;
    }

    public function get_mobile(){
        return $this->_mobile;
    }

    public function set_email($_email){
        $this->_email = $_email;
    }

    public function get_email(){
        return $this->_email;
    }

    public function set_rsgi_hosp_cash($_rsgi_hosp_cash){
        $this->_rsgi_hosp_cash = $_rsgi_hosp_cash;
    }

    public function get_rsgi_hosp_cash(){
        return $this->_rsgi_hosp_cash;
    }

    public function set_super_topup_opted($_super_topup_opted){
        $this->_super_topup_opted = $_super_topup_opted;
    }

    public function get_super_topup_opted(){
        return $this->_super_topup_opted;
    }

    public function set_deductible_amount($_deductible_amount){
        $this->_deductible_amount = $_deductible_amount;
    }

    public function get_deductible_amount(){
        return $this->_deductible_amount;
    }

    public function set_rsgi_international_treatment_opted($_rsgi_international_treatment_opted){
        $this->_rsgi_international_treatment_opted = $_rsgi_international_treatment_opted;
    }

    public function get_rsgi_international_treatment_opted(){
        return $this->_rsgi_international_treatment_opted;
    }
    
}
