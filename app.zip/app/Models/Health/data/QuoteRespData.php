<?php

namespace App\Models\Health\data;

class QuoteRespData {

    private $_trans_code = '';
    private $_product_id = '';
    private $_product_name = '';
    private $_product_plan = '';
    private $_insurer_name = '';
    private $_insurer_code = '';
    private $_sum_insured = '';
    private $_deductible_amount = '';
    private $_super_topup_opted = 'off';
    private $_sumInsuredId = '';
    private $_schemeId = '';
    private $_planId = '';
    private $_planCode ='';
	  private $_premium = '';
    private $_serviceTax = '';
    private $_sgst = '';
    private $_cgst = '';
    private $_totalPremium = '';
    private $_product_type = '';
    private $_policy_start = '';
    private $_policy_end = '';
    private $_plan_type = '';
    private $_dob_list = '';
    private $_age_list = '';
    private $_gender = '';
    private $_title = '';
    private $_members_list = '';
    private $_member_count = '';
    private $_insurer_age_list = '';
    private $_tenure = '';
    private $_rsgi_QuoteId = '';
    private $_rsgi_hosp_cash = 'off'; 
    private $_adult = null;
    private $_children = null;
    
    public function get_trans_code(){
        return $this->_trans_code;
    }

    public function set_trans_code($_trans_code){
        $this->_trans_code = $_trans_code;
    }

    public function get_product_id(){
        return $this->_product_id;
    }

    public function set_product_id($_product_id){
        $this->_product_id = $_product_id;
    }

    public function get_product_name(){
        return $this->_product_name;
    }

    public function set_product_name($_product_name){
        $this->_product_name = $_product_name;
    }

    public function get_product_plan(){
        return $this->_product_plan;
    }

    public function set_product_plan($_product_plan){
        $this->_product_plan = $_product_plan;
    }

    public function get_insurer_name(){
        return $this->_insurer_name;
    }

    public function set_insurer_name($_insurer_name){
        $this->_insurer_name = $_insurer_name;
    }

    public function get_insurer_code(){
        return $this->_insurer_code;
    }

    public function set_insurer_code($_insurer_code){
        $this->_insurer_code = $_insurer_code;
    }

    public function get_sumInsuredId(){
        return $this->_sumInsuredId;
    }

    public function set_sumInsuredId($_sumInsuredId){
        $this->_sumInsuredId = $_sumInsuredId;
    }


    public function get_sum_insured(){
        return $this->_sum_insured;
    }

    public function set_sum_insured($_sum_insured){
        $this->_sum_insured = $_sum_insured;
    }


    public function get_deductible_amount(){
        return $this->_deductible_amount;
    }

    public function set_deductible_amount($_deductible_amount){
        $this->_deductible_amount = $_deductible_amount;
    }


    public function get_super_topup_opted(){
        return $this->_super_topup_opted;
    }

    public function set_super_topup_opted($_super_topup_opted){
        $this->_super_topup_opted = $_super_topup_opted;
    }

    public function get_schemeId(){
        return $this->_schemeId;
    }

    public function set_schemeId($_schemeId){
        $this->_schemeId = $_schemeId;
    }

    public function get_planId(){
        return $this->_planId;
    }

    public function set_planId($_planId){
        $this->_planId = $_planId;
    }

    public function get_planCode(){
        return $this->_planCode;
    }

    public function set_planCode($_planCode){
        $this->_planCode = $_planCode;
    }

    public function get_premium(){
        return $this->_premium;
    }

    public function set_premium($_premium){
        $this->_premium = $_premium;
    }

    public function get_serviceTax(){
        return $this->_serviceTax;
    }

    public function set_serviceTax($_serviceTax){
        $this->_serviceTax = $_serviceTax;
    }

    public function get_cgst(){
        return $this->_cgst;
    }

    public function set_cgst($_cgst){
        $this->_cgst = $_cgst;
    }

    public function get_sgst(){
        return $this->_sgst;
    }

    public function set_sgst($_sgst){
        $this->_sgst = $_sgst;
    }


    public function get_totalPremium(){
        return $this->_totalPremium;
    }

    public function set_totalPremium($_totalPremium){
        $this->_totalPremium = $_totalPremium;
    }

    public function get_product_type(){
        return $this->_product_type;
    }

    public function set_product_type($_product_type){
        $this->_product_type = $_product_type;
    }

    public function get_policy_start(){
    return $this->_policy_start;
  }

  public function set_policy_start($_policy_start){
    $this->_policy_start = $_policy_start;
  }

  public function get_policy_end(){
    return $this->_policy_end;
  }

  public function set_policy_end($_policy_end){
    $this->_policy_end = $_policy_end;
  }

  public function get_plan_type(){
    return $this->_plan_type;
  }

  public function set_plan_type($_plan_type){
    $this->_plan_type = $_plan_type;
  }

  public function get_dob_list(){
    return $this->_dob_list;
  }

  public function set_dob_list($_dob_list){
    $this->_dob_list = $_dob_list;
  }

  public function get_age_list(){
    return $this->_age_list;
  }

  public function set_age_list($_age_list){
    $this->_age_list = $_age_list;
  }

  public function get_members_list(){
    return $this->_members_list;
  }

  public function set_members_list($_members_list){
    $this->_members_list = $_members_list;
  }

  public function get_member_count(){
    return $this->_member_count;
  }

  public function set_member_count($_member_count){
    $this->_member_count = $_member_count;
  }

  public function get_insurer_age_list(){
    return $this->_insurer_age_list;
  }

  public function set_insurer_age_list($_insurer_age_list){
    $this->_insurer_age_list = $_insurer_age_list;
  }

  public function get_tenure(){
    return $this->_tenure;
  }

  public function set_tenure($_tenure){
    $this->_tenure = $_tenure;
  }

  public function get_gender(){
    return $this->_gender;
  }

  public function set_gender($_gender){
    $this->_gender = $_gender;
  }

  public function get_title(){
    return $this->_title;
  }

  public function set_title($_title){
    $this->_title = $_title;
  }

  public function get_rsgi_QuoteId(){
    return $this->_rsgi_QuoteId;
  }

  public function set_rsgi_QuoteId($_rsgi_QuoteId){
    $this->_rsgi_QuoteId = $_rsgi_QuoteId;
  }


  public function set_rsgi_hosp_cash($_rsgi_hosp_cash){
    $this->_rsgi_hosp_cash  = $_rsgi_hosp_cash;
  }

  public function get_rsgi_hosp_cash(){
    return $this->_rsgi_hosp_cash; 
  }

  public function get_adult(){
    return $this->_adult;
  }

  public function set_adult($_adult){
    $this->_adult = $_adult;
  }


  public function get_children(){
    return $this->_children;
  }

  public function set_children($_children){
    $this->_children = $_children;
  }
  
}
?>
