<?php
namespace App\Models\Insta;
use Illuminate\Database\Eloquent\Model;

class EmailTriggerM extends Model {

    protected $table = 'insta_c_emailtrigger';

    public function get_email_matrix( $event_code ) {
    	return EmailTriggerM::select('*')->where('event_code', $event_code)->get();
    }

}
