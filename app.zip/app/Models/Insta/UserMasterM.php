<?php
namespace App\Models\Insta;
use Illuminate\Database\Eloquent\Model;

class UserMasterM extends Model {

    protected $table = 'insta_m_users';

    public function emails_by_user_type( $user_type_code ) { 
    	return UserMasterM::select('name', 'email')->where('user_type', $user_type_code)->get();
    }

}
