<?php
namespace App\Models\Insta;
use Illuminate\Database\Eloquent\Model;

class UserTypeM extends Model {

    protected $table = 'insta_m_usertype';

    public function get_user_type( $user_type_code ) {
    	return UserTypeM::select('*')->where('usertype_code', $user_type_code)->first();
    }

}
