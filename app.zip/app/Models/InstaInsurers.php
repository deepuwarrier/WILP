<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @author Vivek Shah
 *
 */
class InstaInsurers extends Model {
	protected $table = 'insta_m_insurers';

	public function insurer_details ($insurer_code) {
		return Self::select('*')->where('insurer_code', $insurer_code)->first();
	}
	
	public function insurer_column ($insurer_code, $column_name) {
		return Self::select($column_name)->where('insurer_code', $insurer_code)->first()->$column_name;
	}
}
