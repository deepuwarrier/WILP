<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @author Vivek Shah
 *
 */
class InstaUser extends Model {
	protected $table = 'insta_m_users';

	/**
	 * @return unknown
	 */
	public static function getUserName($code) {
		return !empty(Self::where('user_code',$code)->first())?Self::where('user_code',$code)->first()->toArray()['name']:'NA';
	}

	public static function getEmail($code) {
		return !empty(Self::where('user_code',$code)->first())?Self::where('user_code',$code)->first()->toArray()['email']:'NA';
	}

	public function get_filter_list($column_name,$filter=null) {
		$query = Self::select($column_name);
		if(isset($filter)){
			$query->where($filter);	
		}
		$query->distinct();
    	return $query->get();
    }
}
