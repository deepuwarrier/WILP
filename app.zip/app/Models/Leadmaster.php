<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leadmaster extends Model
{
    
    protected $table = 'insta_t_leadmaster';
    public static function set_survey($data){
        self::insert($data);
    }
}
