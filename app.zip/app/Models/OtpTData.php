<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Constants\Car_Constants;

class OtpTData extends Model
{
    protected $table = 'insta_t_otp';
    protected $primaryKey = 'otp_id';
    public $timestamps = false;
    const MAPPER = ['SENT_OTP'=>'sent_otp',
					'RECIVE_OTP'=>'recv_otp',
					'STATUS'=>'status',
					'MOBILE'=>'mobile'
					];
    protected $fillable = [ self::MAPPER['SENT_OTP'],
							self::MAPPER['RECIVE_OTP'],
							self::MAPPER['STATUS'],
							self::MAPPER['MOBILE']];

	

	public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
    }										
}
