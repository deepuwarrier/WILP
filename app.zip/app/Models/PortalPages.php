<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @author ravirao
 *
 */
class PortalPages extends Model {
	protected $table = 'portal_m_pages';

	
	public function getMeta($page_name){
		return PortalPages::select('page_mt_title','page_mt_kwds', 'page_mt_desc')->where('page_name',$page_name)->get()->first();
	}
		
}