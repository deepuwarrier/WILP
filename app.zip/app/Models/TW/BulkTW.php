<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;


class BulkTW extends Model {
	
	protected $table = 'temp_tw_bulkpolicy';
// 	public $timestamps = false;
	
	public function __construct()
	{
	}
	
	public function store_data($policyno, $data) {
		BulkTW::where("insta_un", $policyno)->update($data);
	}
	
	public function get_list() {
		return BulkTW::where("exe_flag", "Y")->get();
	}
	
	public function get_data($pno) {
		return BulkTW::select('*')->where('insta_un', $pno)->first();
	}
	
}