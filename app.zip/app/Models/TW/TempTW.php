<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;


class TempTW extends Model {
	
	protected $table = 'temp_tw_policy';
// 	public $timestamps = false;
	
	public function __construct()
	{
	}
	
	public function store_data($policyno, $data) {
		TempTW::where("policy_number", $policyno)->update($data);
	}
	
	public function get_data($pno) {
		return TempTW::select('*')->where('policy_number', $pno)->first();
	}
	
}