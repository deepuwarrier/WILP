<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwCities extends Model {
	protected $table = 'tw_m_city';

	public function city_by_state($state_code) {
		return TwCities::select('city_code', 'city_name')->where('state_ref_code', $state_code)->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function city_list() {
		return TwCities::select('*')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function city_details($city_code) {
		return TwCities::select('*')->where('city_code', $city_code)->first();
	}
	
}