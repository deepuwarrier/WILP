<?php

namespace app\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwConfig extends Model {
	protected $table = 'tw_c_config';


	public function getValue($key) {
		return TwConfig::select('config_value')->where('config_name', $key)->first();
	}
	
	public function getValueList($keylist){
		
// 		yet to implement logic
		
		return $valuelist;
	}
	
	public function getKeyValueList(){
		return TwConfig::select('config_name','config_value')->get();
	}
	
	public function getKeyList(){
		return TwConfig::select('config_name')->get();
	}
	
	
}