<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwCovers extends Model {
	protected $table = 'tw_m_covers';

	public function _list() {
		return TwCovers::select('*')->where('cover_display', 1)->orderBy('cover_order', 'desc')->get();
	}
}