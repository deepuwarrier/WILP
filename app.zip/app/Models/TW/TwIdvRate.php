<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwIdvRate extends Model {
	protected $table = 'tw_m_idvrate';

	public function idv_rate_std($age) {
		return TwIdvRate::select('std_rate')->where('age_start', '<' , $age)->where('age_end', '>=' , $age)->first();
	}
	
	public function idv_rate_uiic($age) {
		return  TwIdvRate::select('uiic_rate')->where('age_start', '<' , $age)->where('age_end', '>=' , $age)->first();
	}
	
	
}