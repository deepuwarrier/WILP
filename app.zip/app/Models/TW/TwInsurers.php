<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwInsurers extends Model {
	protected $table = 'tw_m_insurers';
	
	public function insurer_details ($insurer_code) {
		return TwInsurers::select('*')->where('isu_code', $insurer_code)->first();
	}
	
	public function insurer_column ($insurer_code, $column_name) {
		return TwInsurers::select($column_name)->where('isu_code', $insurer_code)->first();
	}
	
}