<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

/**
 * @author ravirao
 *
 */
class TwMakes extends Model {
	protected $table = 'tw_m_makes';

	/**
	 * @return unknown
	 */
	public function getTwMakes() {
	return TwMakes::select('make_id', 'make_code', 'make_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function make_details($make_code) {
		return TwMakes::select('*')->where('make_code', $make_code)->first();
	}
	
	
}