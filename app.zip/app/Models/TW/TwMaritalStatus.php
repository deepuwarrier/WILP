<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwMaritalStatus extends Model {
	protected $table = 'tw_m_maritalstatus';
	
	public function maritialstatus_list ($insr_column) {
		return Self::select('ms_code','ms_name')->where('is_display', 1)->orderBy('display_order', 'desc')->whereNotNull($insr_column)->get();
	}
	
	public function maritialstatus_details($ms_code) {
		return Self::select('*')->where('ms_code', $ms_code)->first();
	}
	
}