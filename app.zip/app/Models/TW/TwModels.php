<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwModels extends Model {
	protected $table = 'tw_m_models';

	public function getTwModels($makeCode) {
		return TwModels::select('model_code', 'model_name')->where('make_code_ref', $makeCode)->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function model_details($model_code) {
		return TwModels::select('*')->where('model_code', $model_code)->first();
	}
	
}