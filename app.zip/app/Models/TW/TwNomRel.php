<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwNomRel extends Model {
	protected $table = 'tw_m_nomrelation';
	
	public function nom_rel_list () {
		return TwNomRel::select('nomrel_code', 'nomrel_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function insr_nom_rel_list( $insr_column ) {
		return  TwNomRel::select('nomrel_code', 'nomrel_name')->where('is_display', 1)->where($insr_column, '<>', null)->orderBy('display_order', 'desc')->get();
	}
	
	
	public function nomrel_details($nomrel_code) {
		return TwNomRel::select('*')->where('nomrel_code', $nomrel_code)->first();
	}
	
}