<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwODRates extends Model {
	protected $table = 'tw_m_odrates';

	public function od_rates($age, $cc, $zone) {  
		return TwODRates::select('od_rate')
							->where('min_age', '<=' , $age)->where('max_age', '>' , $age)
							->where('min_cc', '<' , $cc)->where('max_cc', '>=' , $cc)
							->where('rto_zone', $zone)
							->first();
	}
	
}