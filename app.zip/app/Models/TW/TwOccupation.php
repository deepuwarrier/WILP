<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwOccupation extends Model {
	protected $table = 'tw_m_occupation';
	
	public function occupation_list () {
		return TwOccupation::select('occu_code', 'occu_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function occupation_details($occ_code) {
		return TwOccupation::select('*')->where('occu_code', $occ_code)->first();
	}
	
}