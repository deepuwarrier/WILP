<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwPincode extends Model {
	protected $table = 'tw_m_pincode';

	public function pincode_details($rto_code) {
		return Self::select('*')->where('pincode', $rto_code)->first();
	}
	
	public function pincode_by_city($city_code) {
		return Self::select('pincode')->where('city_ref_code', $city_code)->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	} 
	
	
}