<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;
use App\Constants\Tw_Constants;


class TwPolicyData extends Model {
	
	protected $table = 'tw_t_policy';
	protected $primaryKey = 'trans_code';
	protected $fillable = [Tw_Constants::SSN_KEY,Tw_Constants::TRANS_CODE,Tw_Constants::POLICY_TYPE,Tw_Constants::MAKE_CODE,Tw_Constants::MODEL_CODE,Tw_Constants::VARIANT_CODE,Tw_Constants::VARIANT_PRICE,Tw_Constants::VARIANT_BASE_PRICE,Tw_Constants::VARIANT_CC,Tw_Constants::STATE_CODE,Tw_Constants::RTO_CODE,Tw_Constants::RTO_CITY_CODE,Tw_Constants::YOR,Tw_Constants::YOM,Tw_Constants::PRE_POLICY_STATUS,Tw_Constants::POLICY_START_DATE,Tw_Constants::POLICY_EXP_DATE,Tw_Constants::TERM_START_DATE,Tw_Constants::TERM_END_DATE,Tw_Constants::TW_REG_DATE,Tw_Constants::TW_AGE,Tw_Constants::PRE_CLAIM_STATUS,Tw_Constants::CURR_NCB,Tw_Constants::ELI_NCB,Tw_Constants::BASE_IDV,Tw_Constants::CALC_IDV,Tw_Constants::OPT_IDV,Tw_Constants::TERM_DURATION,Tw_Constants::INSURER_CODE,Tw_Constants::ADDON_COVERS,Tw_Constants::TOTAL_PREMIUM,Tw_Constants::OWNER_TYPE,Tw_Constants::PROPOSER_GENDER,Tw_Constants::PROPOSER_DOB,Tw_Constants::PROPOSER_NAME,Tw_Constants::PROPOSER_EMAIL,Tw_Constants::PROPOSER_MOBILE,Tw_Constants::PROPOSER_AADHARNO,Tw_Constants::PROPOSER_PANNO,Tw_Constants::PROPOSER_OCCUPATION,Tw_Constants::PROPOSER_MARITIALSTATUS,Tw_Constants::REGN_ADDR1,Tw_Constants::REGN_ADDR2,Tw_Constants::REGN_ADDR3,Tw_Constants::REGN_STATE_CODE,Tw_Constants::REGN_CITY_CODE,Tw_Constants::REGN_PINCODE,Tw_Constants::SAME_COMM_ADDR,Tw_Constants::PROPOSER_ADDR1,Tw_Constants::PROPOSER_ADDR2,Tw_Constants::PROPOSER_ADDR3,Tw_Constants::PROPOSER_STATE_CODE,Tw_Constants::PROPOSER_CITY_CODE,Tw_Constants::PROPOSER_PINCODE,Tw_Constants::TW_REG_NO,Tw_Constants::TW_ENGINE_NO,Tw_Constants::TW_CHASSIS_NO,Tw_Constants::OWNER_CHANGED,Tw_Constants::VOLUENTRY_DEDUCTABLES,Tw_Constants::ELE_ACC,Tw_Constants::NON_ELE_ACC,Tw_Constants::COLOR,Tw_Constants::IS_FINANCED,Tw_Constants::TYPE_OF_FINANCE,Tw_Constants::FINANCIER_NAME,Tw_Constants::FINANCIER_ADDRESS,Tw_Constants::PRE_INSURER_CODE,Tw_Constants::PRE_INSURER_ADDR,Tw_Constants::PRE_POLICY_NUMBER,Tw_Constants::PRE_POLICY_TYPE,Tw_Constants::PRE_CLAIM_COUNT,Tw_Constants::PRE_CLAIM_AMOUNT,Tw_Constants::NOMI_NAME,Tw_Constants::NOMI_AGE,Tw_Constants::NOMI_DOB,Tw_Constants::NOMI_REL_CODE,Tw_Constants::PRE_ZERODEPT,Tw_Constants::OD_PREMIUM,Tw_Constants::TP_PREMIUM,Tw_Constants::ADDON_PREMIUM,Tw_Constants::OD_DISC_VALUE,Tw_Constants::NCB_DISC_VALUE,Tw_Constants::GROSS_TOTAL_PREMIUM,Tw_Constants::TOTAL_TAX,Tw_Constants::FINAL_PREMIUM,Tw_Constants::PR_CUSTOMERID,Tw_Constants::PR_NUMBER,Tw_Constants::TRANS_STATUS,Tw_Constants::POLICY_DATE,Tw_Constants::POLICY_NUMBER,Tw_Constants::USER_CODE,Tw_Constants::AGENT_CODE,Tw_Constants::PARTNER_CODE,Tw_Constants::TEMP_COL_1,Tw_Constants::TEMP_COL_2,Tw_Constants::TEMP_COL_3,Tw_Constants::TEMP_COL_4,Tw_Constants::TEMP_COL_5];

	public function __construct()
	{
	}
	

	public function get_policy($snn_key) {
		return Self::all()->where( Tw_Constants::SSN_KEY, $snn_key)->first();
	}
	
	public function values_by_policyno($policy_number) {
		return Self::all()->where( Tw_Constants::POLICY_NUMBER, $policy_number)->first();
	}
	
	public function set_record($trans_code) {  
		try {
			$existance_flag = Self::where(Tw_Constants::SSN_KEY, $trans_code)->first();
			if (is_null($existance_flag)) { 

				$data_set = $this->get_usrdata_records($trans_code); 

				try{
					self::insert($data_set->toArray()); 
				} catch(\Exception $e){
					\Log::info('Error updating Policy table : '.$trans_code.' :- '.$e->getMessage());
				}
			} else {
				// Already there. do nothing as of now.
			}
		} catch (\Exception $ex) {		}
	}// method end.
	
	private function get_usrdata_records ($trans_code) { 
		$usr_db = new TwUsrData();
		$query_data =  $usr_db->get_by_sc($trans_code);  
		return $query_data; 
	}
	

	
	
}