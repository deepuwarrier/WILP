<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwPreInsurers extends Model {
	protected $table = 'tw_m_preinsurers';
	
	public function pre_insurers_list () {
		return TwPreInsurers::select('preinsr_code', 'preinsr_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function insr_preinsur_list ( $insr_column ) { 
		return  TwPreInsurers::select('preinsr_code', 'preinsr_name')->where('is_display', 1)->where($insr_column, '<>', null)->orderBy('display_order', 'desc')->get();
	}
	
	public function preinsr_details($pinsr_code) {
		return TwPreInsurers::select('*')->where('preinsr_code', $pinsr_code)->first();
	}
	
}