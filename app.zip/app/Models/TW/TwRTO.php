<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwRTO extends Model {
	protected $table = 'tw_m_rto';

	public function rto_list() {
		return TwRTO::select('*')->get();
	}
	
	public function rto_details($rto_code) {
		return TwRTO::select('*')->where('rto_code', $rto_code)->first();
	}
	
	// temp method.. 
	public function store_rto($key, $data){
		TwRTO::where("rto_code", $key)->update($data);
	}	
	
	
}