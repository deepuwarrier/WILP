<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwStates extends Model {
	protected $table = 'tw_m_states';

	public function getTwStates() {
	return TwStates::select('state_code', 'state_name','rto_code')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function state_list () {
		return TwStates::select('state_code', 'state_name')->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	public function state_list_by_code ($state_code){
		return TwStates::select('state_code', 'state_name')->where('state_code', $state_code)->get();
	}
	
	public function state_to_rto($state_code) {
		return TwStates::select('rto_code')->where('state_code', $state_code)->first();
	}
	
	public function state_details($state_code) {
		return TwStates::select('*')->where('state_code', $state_code)->first();
	}
	
	
}