<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use App\Constants\Tw_Constants;


class TwUsrData extends Model {
	
	protected $table = 'tw_t_usrdata';
	protected $guarded = [];
// 	public $timestamps = false;
	
	public function __construct()
	{
	}
	
/* -----Session based methods for details page operations  --------------------- */	
	
	public function snn_exists($sn_key){
		$result = TwUsrData::select(Tw_Constants::SSN_KEY)->where(Tw_Constants::SSN_KEY, $sn_key)->get();
		if(count($result) > 0) {	return true;	}	else {	return false; }
	}

	public function getValue($sn_key) {
		return TwUsrData::all()->where( Tw_Constants::SSN_KEY, $sn_key)->first();
	}
	
	
	public function setTranscation($snnkey) {
		$data = array (	Tw_Constants::SSN_KEY=> $snnkey);
		return TwUsrData::insertGetId( $data );
	}
	
	public function setValues($snnkey, $data) {
		if($this->snn_exists($snnkey)) {
			TwUsrData::where(Tw_Constants::SSN_KEY, $snnkey)->update($data);
		}
		else  {
			$this->setTranscation($snnkey);
			TwUsrData::where(Tw_Constants::SSN_KEY, $snnkey)->update($data);
		}
	}
	
	public function quote_req_data($sn_key) {
		return  TwUsrData::select("make_code", "model_code", "variant_code", "state_code", "rto_code", "yor")->where(Tw_Constants::SSN_KEY, $sn_key)->first();
	}
	
	public function get_yor($sn_key) {
		return TwUsrData::select(Tw_Constants::YOR)->where(Tw_Constants::SSN_KEY, $sn_key)->first();
	}
	
	public function get_calc_idv($sn_key) {
		return TwUsrData::select(Tw_Constants::CALC_IDV)->where( Tw_Constants::SSN_KEY, $sn_key)->first();
	}

	

/* ----- Transcation code based methods for quote, proposal and payment --------------------- */	
	
	
	

	public function trans_exists($trans_code){
		$result = TwUsrData::select(Tw_Constants::TRANS_CODE)->where(Tw_Constants::TRANS_CODE, $trans_code)->get();
		if(count($result) > 0) {	return true;	}	else {	return false; }
	}

	public function values_by_policyno($policy_number) {
		return TwUsrData::all()->where( Tw_Constants::POLICY_NUMBER, $policy_number)->first();
	}
	
	public function get_by_tc($trans_code) {
		return TwUsrData::all()->where( Tw_Constants::TRANS_CODE, $trans_code)->first();
	}
	public function get_by_sc($ssn_key) {
		return TwUsrData::all()->where( Tw_Constants::SSN_KEY, $ssn_key)->first();
	}
	public function set_by_tc($trans_code, $data) {
		TwUsrData::where(Tw_Constants::TRANS_CODE, $trans_code)->update($data);
	}
	
	public function set_transaction($trans_code) {
		$data = array (	Tw_Constants::TRANS_CODE=> $trans_code, Tw_Constants::SSN_KEY => $trans_code);
		return TwUsrData::insertGetId( $data );
	}
	
	public function details_preview($trans_code) {
		$db_result =  TwUsrData::select("make_code", "model_code", "variant_code", "state_code", "rto_code", "yor")->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
		
		$make_db = new TwMakes();
		$model_db = new TwModels();
		$variant_db = new TwVariant();
		
		return  array(
				"make_name" => $make_db->make_details($db_result->make_code)->make_name,
				"model_name" => $model_db->model_details( $db_result->model_code)->model_name,
				"variant_name" => $variant_db->variant_details($db_result->variant_code)->variant_name,
				"rto_code" => $db_result->rto_code,
				"yor" => $db_result->yor
		);
	}
	
	public function quote_preview($trans_code) {
		$db_result =  TwUsrData::select("tw_reg_date", "term_start_date", "calc_idv",  "opt_idv","eli_ncb", "insurer_code", "total_premium")->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
		
		$insurer_code = $db_result->insurer_code;
		
		$insur_db = new TwInsurers();
		$insur_data = $insur_db->insurer_details($insurer_code);
		
		return  array(
				"reg_date" => $db_result->tw_reg_date,
				"term_start_date" => $db_result->term_start_date,
				"opt_idv" => $db_result->opt_idv,
				"eli_ncb" => $db_result->eli_ncb,
				"total_premium" => $db_result->total_premium,
				"insurer_name" => $insur_data->isu_name,
				"insurer_logo" => $insur_data->isu_logo
		);
	}
	
	
	public function get_yor_by_tc($trans_code) {
		return TwUsrData::select(Tw_Constants::YOR)->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
	}
	
	public function get_by_agent_code($agent_code) {
		return TwUsrData::select("*")
		->where("agent_code", $agent_code)
		->where("agent_code","!=", null)
		->where("variant_code","!=", null)
		->get();
	}
	
	public function get_all_between($from_date, $to_date) {
		return TwUsrData::select("*")
		->where("variant_code","!=", null)
		->get();
	}
	
	public function set_agent($trans_code, $agent_code) {
		TwUsrData::where(Tw_Constants::TRANS_CODE, $trans_code)
		->update(array("agent_code" => $agent_code));
	}

	public function get_trans_list($from_date, $to_date, $agent_code = null) {
		$data =  Self::whereRaw("STR_TO_DATE(`quote_create_date`,'%d-%b-%Y') between STR_TO_DATE('".$from_date."','%d-%b-%Y') and STR_TO_DATE('".$to_date."','%d-%b-%Y')");
		if(($agent_code != 'all') || ($agent_code == null)){
            $data->where('agent_code',$agent_code);
        }
		return $data->get();
	}

	
}
