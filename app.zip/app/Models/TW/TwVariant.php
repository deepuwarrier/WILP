<?php

namespace App\Models\TW;

use Illuminate\Database\Eloquent\Model;

class TwVariant extends Model {
	protected $table = 'tw_m_variants';

	public function variant($model_code) { 
		return TwVariant::select('variant_id', 'variant_code', 'variant_name')->where('model_ref_code', $model_code)->where('is_display', 1)->orderBy('display_order', 'desc')->get();
	}
	
	
	
	public function variant_details($variant_code) {
		return TwVariant::select('*')->where('variant_code', $variant_code)->first();
	}
	
	public function bajaj_code($ins_var_id) {
		return TwVariant::select('variant_code')->where('variant_id', $ins_var_id)->first();
	}
	
	public function variant_list(){
		$ret_data =  TwVariant::select('variant_code', 'vehicle_code_desc',  'vechicle_name_desc')
		->where('is_display', 1)->orderBy('display_order', 'desc')->get();
		return $ret_data;
	}
	
	public function variatn_list_by_cc($cc_value){
		$min_cc = 0;  $max_cc = 0;
		switch ($cc_value) {
			case 75: $min_cc = 0;  $max_cc = 75;break;
			case 150: $min_cc = 76;  $max_cc = 150;break;
			case 350: $min_cc = 151;  $max_cc = 350;break;
			case 351: $min_cc = 351;  $max_cc = 2000;break;
		}
		
		$ret_data =  TwVariant::select('variant_code', 'vehicle_code_desc',  'vechicle_name_desc')
		->where('variant_cc','>', $min_cc)->where('variant_cc','<=', $max_cc)
		->where('is_display', 1)->orderBy('display_order', 'desc')->get();
		return $ret_data;
	}
	
} // end of class. 