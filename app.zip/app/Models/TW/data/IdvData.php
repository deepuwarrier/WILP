<?php

namespace App\Models\TW\data;

class IdvData {
	public $snn_key ="";
	public $_trans_code = "";
	public $r_pexdt 			= "";
	public $r_pexdt_max 	= "";
	public $r_pexdt_min 	= "";
	public $_isvisible_pexdt = true;
	public $r_twrgdt			= "";
	public $r_twrgdt_max 	= "";
	public $r_twrgdt_min	= "";
	public $_isvisible_twregdt = true;
	public $r_claims			= false;
	public $_isvisible_claims = true;
	public $r_crr_ncb 		= 0;
	public $r_eli_ncb 		= 0;
	public $_isvisible_ncb = true;
	public $rec_idv 			= 0;
	public $calc_idv 			= 0;
	public $_isvisible_idv = true;
	public $_base_idv = 0;
	public $_base_idv_min = 0;
	public $_base_idv_max = 0;
	public $_variant_base_price = 0;
	public $_pre_policy_status = "";
	public $_isvisible_prepolicystatus = true;
	
	public function snn_key() 				{	return $this->snn_key;				}
	public function r_pexdt() 				{	return $this->r_pexdt;				}
	public function r_pexdt_max()		{	return $this->r_pexdt_max;		}
	public function r_pexdt_min() 		{	return $this->r_pexdt_min;		}
	public function r_twrgdt() 				{	return $this->r_twrgdt;				}
	public function r_twrgdt_max() 		{	return $this->r_twrgdt_max;		}
	public function r_twrgdt_min() 		{	return $this->r_twrgdt_min;		}
	public function r_claims () 				{	return $this->r_claims;				}
	public function r_crr_ncb() 			{	return $this->r_crr_ncb;			}
	public function r_eli_ncb () 			{	return $this->r_eli_ncb;			}
	public function rec_idv() 				{	return $this->rec_idv;				}
	public function calc_idv() 				{	return $this->calc_idv;				}
	
	
	public function _snn_key($snn_key) 					{	 $this->snn_key= $snn_key;					}
	public function _r_pexdt($r_pexdt) 					{	 $this->r_pexdt = $r_pexdt;					}
	public function _r_pexdt_max($r_pexdt_max) 	{	 $this->r_pexdt_max = $r_pexdt_max;	}
	public function _r_pexdt_min($r_pexdt_min) 	{	 $this->r_pexdt_min = $r_pexdt_min;		}
	public function _r_twrgdt($r_twrgdt) 					{	 $this->r_twrgdt = $r_twrgdt;						}
	public function _r_twrgdt_max($r_twrgdt_max) 	{	 $this->r_twrgdt_max = $r_twrgdt_max;		}
	public function _r_twrgdt_min($r_twrgdt_min)		{	 $this->r_twrgdt_min = $r_twrgdt_min;		}
	public function _r_claims ($r_claims) 					{	 $this->r_claims = $r_claims;					}
	public function _r_crr_ncb($r_crr_ncb)				{	 $this->r_crr_ncb= $r_crr_ncb;				}
	public function _r_eli_ncb ($r_eli_ncb) 				{	 $this->r_eli_ncb = 	$r_eli_ncb;				}
	public function _rec_idv($rec_idv) 						{ 	$this->rec_idv = $rec_idv;						}
	public function _calc_idv($calc_idv) 						{ 	$this->calc_idv= $calc_idv;						}
	
	
  public function get_base_idv_min(){
    return $this->_base_idv_min;
  }

  public function set_base_idv_min($_base_idv_min){
    $this->_base_idv_min = $_base_idv_min;
  }

  public function get_base_idv_max(){
    return $this->_base_idv_max;
  }

  public function set_base_idv_max($_base_idv_max){
    $this->_base_idv_max = $_base_idv_max;
  }


  public function get_base_idv(){
    return $this->_base_idv;
  }

  public function set_base_idv($_base_idv){
    $this->_base_idv = $_base_idv;
  }




  public function get_variant_base_price(){
    return $this->_variant_base_price;
  }

  public function set_variant_base_price($_variant_base_price){
    $this->_variant_base_price = $_variant_base_price;
  }


  public function get_trans_code(){
    return $this->_trans_code;
  }

  public function set_trans_code($_trans_code){
    $this->_trans_code = $_trans_code;
  }


  public function get_pre_policy_status(){
    return $this->_pre_policy_status;
  }

  public function set_pre_policy_status($_pre_policy_status){
    $this->_pre_policy_status = $_pre_policy_status;
  }


  public function get_isvisible_pexdt(){
    return $this->_isvisible_pexdt;
  }

  public function set_isvisible_pexdt($_isvisible_pexdt){
    $this->_isvisible_pexdt = $_isvisible_pexdt;
  }

  public function get_isvisible_twregdt(){
    return $this->_isvisible_twregdt;
  }

  public function set_isvisible_twregdt($_isvisible_twregdt){
    $this->_isvisible_twregdt = $_isvisible_twregdt;
  }

  public function get_isvisible_claims(){
    return $this->_isvisible_claims;
  }

  public function set_isvisible_claims($_isvisible_claims){
    $this->_isvisible_claims = $_isvisible_claims;
  }

  public function get_isvisible_ncb(){
    return $this->_isvisible_ncb;
  }

  public function set_isvisible_ncb($_isvisible_ncb){
    $this->_isvisible_ncb = $_isvisible_ncb;
  }

  public function get_isvisible_idv(){
    return $this->_isvisible_idv;
  }

  public function set_isvisible_idv($_isvisible_idv){
    $this->_isvisible_idv = $_isvisible_idv;
  }

  public function get_isvisible_prepolicystatus(){
    return $this->_isvisible_prepolicystatus;
  }

  public function set_isvisible_prepolicystatus($_isvisible_prepolicystatus){
    $this->_isvisible_prepolicystatus = $_isvisible_prepolicystatus;
  }

}
