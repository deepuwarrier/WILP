<?php
namespace App\Models\TW\data;

class PRData {

private $_pr_type;
private $_pr_customerid;
private $_errormsg;
private $_revisedpremium;
	
  public function get_pr_type(){
    return $this->_pr_type;
  }

  public function set_pr_type($_pr_type){
    $this->_pr_type = $_pr_type;
  }

  public function get_pr_customerid(){
    return $this->_pr_customerid;
  }

  public function set_pr_customerid($_pr_customerid){
    $this->_pr_customerid = $_pr_customerid;
  }

  public function get_errormsg(){
    return $this->_errormsg;
  }

  public function set_errormsg($_errormsg){
    $this->_errormsg = $_errormsg;
  }

  public function get_revisedpremium(){
    return $this->_revisedpremium;
  }

  public function set_revisedpremium($_revisedpremium){
    $this->_revisedpremium = $_revisedpremium;
  }

}
