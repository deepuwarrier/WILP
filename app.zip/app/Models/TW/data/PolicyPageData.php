<?php

namespace App\Models\TW\data;

class PolicyPageData {
	private $snn_key ="";
	private $state_list	= "";
	private $rto_code 	= "";
	private $yom_list 	= "";
	private $pre_insurer_list = "";
	private $nom_rel_list = "";
	private $_pre_zerodept = "N";
	private $_occupation_list = null;
	private $_maritialstatus_list = null;
	private $_pre_policy_status = true;
	private $_pre_claim_status = false;
	
	public function snn_key() 				{	return $this->snn_key;				}
	public function state_list() 				{	return $this->state_list;				}
	public function rto_code()				{	return $this->rto_code;				}
	public function yom_list() 				{	return $this->yom_list;				}
	public function pre_insurer_list() 	{	return $this->pre_insurer_list;	}
	public function nom_rel_list () 		{	return $this->nom_rel_list ;		}
		
	public function _snn_key($snn_key) 							{	 $this->snn_key= $snn_key;							}
	public function _state_list($state_list) 							{	 $this->state_list= $state_list;							}
	public function _rto_code($rto_code) 							{	 $this->rto_code= $rto_code;						}
	public function _yom_list($yom_list) 							{	 $this->yom_list= $yom_list;							}
	public function _pre_insurer_list($pre_insurer_list) 	{	 $this->pre_insurer_list= $pre_insurer_list;	}
	public function _nom_rel_list($nom_rel_list) 				{	 $this->nom_rel_list= $nom_rel_list;				}


  public function get_pre_zerodept(){
    return $this->_pre_zerodept;
  }

  public function set_pre_zerodept($_pre_zerodept){
    $this->_pre_zerodept = $_pre_zerodept;
  }


  public function get_occupation_list(){
    return $this->_occupation_list;
  }

  public function set_occupation_list($_occupation_list){
    $this->_occupation_list = $_occupation_list;
  }

  

  public function get_pre_policy_status(){
    return $this->_pre_policy_status;
  }

  public function set_pre_policy_status($_pre_policy_status){
    $this->_pre_policy_status = $_pre_policy_status;
  }


  public function get_pre_claim_status(){
    return $this->_pre_claim_status;
  }

  public function set_pre_claim_status($_pre_claim_status){
    $this->_pre_claim_status = $_pre_claim_status;
  }


	/**
	 * Gets the value of _maritialstatus_list.
	 *
	 * @return mixed
	 */
	public function get_maritialstatus_list()
	{
	    return $this->_maritialstatus_list;
	}

    /**
     * Sets the value of _maritialstatus_list.
     *
     * @param mixed $_maritialstatus_list the _maritialstatus_list
     *
     * @return self
     */
    public function set_maritialstatus_list($_maritialstatus_list)
    {
        $this->_maritialstatus_list = $_maritialstatus_list;

        return $this;
    }
}
