<?php

namespace App\Models\TW\data;

class QuoteReqData {
	
	private $_tw_trans_code = "";
	private $_pre_policy_status = "";
	private $_prepolicy_start_date = "";
	private $_prepolicy_end_date = "";
	private $_policy_start_date = "";
	private $_policy_end_date = "";
	private $_registration_date = "";
	private $_claim_status = false;
	private $_current_ncb = 0;
	private $_eligible_ncb = 0;
	private $_desired_idv = 0;
	private $_make_code = null;
	private $_model_code = null;
	private $_variant_code = null;
	private $_state_code = "";
	private $_rto_code = null;
	private $_rto_zone = null;
	private $_rto_city_name = "";
	private $_yor = null;
	private $_yom = null;
	private $_tw_age = 0;
	private $_tw_price = 0;
	private $_tw_cc = "";
	private $_plan_duration = 0;
	private $_add_on_zrdp = false;
	private $_add_on_cnsm = false;
	private $_add_on_ncbp = false;
	private $_add_on_rsac = false;
	private $_add_on_rtin = false;
	


  public function get_prepolicy_start_date(){
    return $this->_prepolicy_start_date;
  }

  public function set_prepolicy_start_date($_prepolicy_start_date){
    $this->_prepolicy_start_date = $_prepolicy_start_date;
  }

  public function get_prepolicy_end_date(){
    return $this->_prepolicy_end_date;
  }

  public function set_prepolicy_end_date($_prepolicy_end_date){
    $this->_prepolicy_end_date = $_prepolicy_end_date;
  }

  public function get_policy_start_date(){
    return $this->_policy_start_date;
  }

  public function set_policy_start_date($_policy_start_date){
    $this->_policy_start_date = $_policy_start_date;
  }

  public function get_policy_end_date(){
    return $this->_policy_end_date;
  }

  public function set_policy_end_date($_policy_end_date){
    $this->_policy_end_date = $_policy_end_date;
  }

  public function get_registration_date(){
    return $this->_registration_date;
  }

  public function set_registration_date($_registration_date){
    $this->_registration_date = $_registration_date;
  }

  public function get_claim_status(){
    return $this->_claim_status;
  }

  public function set_claim_status($_claim_status){
    $this->_claim_status = $_claim_status;
  }

  public function get_current_ncb(){
    return $this->_current_ncb;
  }

  public function set_current_ncb($_current_ncb){
    $this->_current_ncb = $_current_ncb;
  }

  public function get_eligible_ncb(){
    return $this->_eligible_ncb;
  }

  public function set_eligible_ncb($_eligible_ncb){
    $this->_eligible_ncb = $_eligible_ncb;
  }

  public function get_desired_idv(){
    return $this->_desired_idv;
  }

  public function set_desired_idv($_desired_idv){
    $this->_desired_idv = $_desired_idv;
  }

  public function get_make_code(){
    return $this->_make_code;
  }

  public function set_make_code($_make_code){
    $this->_make_code = $_make_code;
  }

  public function get_model_code(){
    return $this->_model_code;
  }

  public function set_model_code($_model_code){
    $this->_model_code = $_model_code;
  }

  public function get_variant_code(){
    return $this->_variant_code;
  }

  public function set_variant_code($_variant_code){
    $this->_variant_code = $_variant_code;
  }

  public function get_state_code(){
    return $this->_state_code;
  }

  public function set_state_code($_state_code){
    $this->_state_code = $_state_code;
  }

  public function get_rto_code(){
    return $this->_rto_code;
  }

  public function set_rto_code($_rto_code){
    $this->_rto_code = $_rto_code;
  }

  public function get_yor(){
    return $this->_yor;
  }

  public function set_yor($_yor){
    $this->_yor = $_yor;
  }

  public function get_yom(){
    return $this->_yom;
  }

  public function set_yom($_yom){
    $this->_yom = $_yom;
  }


  public function get_tw_price(){
    return $this->_tw_price;
  }

  public function set_tw_price($_tw_price){
    $this->_tw_price = $_tw_price;
  }


  public function get_add_on_zrdp(){
    return $this->_add_on_zrdp;
  }

  public function set_add_on_zrdp($_add_on_zrdp){
    $this->_add_on_zrdp = $_add_on_zrdp;
  }

  public function get_add_on_cnsm(){
    return $this->_add_on_cnsm;
  }

  public function set_add_on_cnsm($_add_on_cnsm){
    $this->_add_on_cnsm = $_add_on_cnsm;
  }

  public function get_add_on_ncbp(){
    return $this->_add_on_ncbp;
  }

  public function set_add_on_ncbp($_add_on_ncbp){
    $this->_add_on_ncbp = $_add_on_ncbp;
  }

  public function get_add_on_rsac(){
    return $this->_add_on_rsac;
  }

  public function set_add_on_rsac($_add_on_rsac){
    $this->_add_on_rsac = $_add_on_rsac;
  }


  public function get_plan_duration(){
    return $this->_plan_duration;
  }

  public function set_plan_duration($_plan_duration){
    $this->_plan_duration = $_plan_duration;
  }


  public function get_add_on_rtin(){
    return $this->_add_on_rtin;
  }

  public function set_add_on_rtin($_add_on_rtin){
    $this->_add_on_rtin = $_add_on_rtin;
  }


  public function get_tw_cc(){
    return $this->_tw_cc;
  }

  public function set_tw_cc($_tw_cc){
    $this->_tw_cc = $_tw_cc;
  }


  public function get_rto_zone(){
    return $this->_rto_zone;
  }

  public function set_rto_zone($_rto_zone){
    $this->_rto_zone = $_rto_zone;
  }

  public function get_tw_age(){
    return $this->_tw_age;
  }

  public function set_tw_age($_tw_age){
    $this->_tw_age = $_tw_age;
  }


  public function get_tw_trans_code(){
    return $this->_tw_trans_code;
  }

  public function set_tw_trans_code($_tw_trans_code){
    $this->_tw_trans_code = $_tw_trans_code;
  }


  public function get_rto_city_name(){
    return $this->_rto_city_name;
  }

  public function set_rto_city_name($_rto_city_name){
    $this->_rto_city_name = $_rto_city_name;
  }


  public function get_pre_policy_status(){
    return $this->_pre_policy_status;
  }

  public function set_pre_policy_status($_pre_policy_status){
    $this->_pre_policy_status = $_pre_policy_status;
  }

}
