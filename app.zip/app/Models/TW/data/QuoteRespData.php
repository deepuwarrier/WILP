<?php

namespace App\Models\TW\data;

class QuoteRespData  {
	private $_tw_trans_code = "";
	private $product_code = "";
	private $idv = 0;
	private $insurer_code = "";
	private $insurer_name = "";
	private $insurer_logo = "";
	private $od_value = 0;
	private $tp_value = 0;
	private $pa_value = 0;
	private $cmdisc_value = 0;
	private $ncb_perc = 0;
	private $ncb_value = 0;
	private $od_disc = 0;
	private $gross_premium = 0;
	private $service_tax = 0;
	private $final_premium = 0;
	private $proposal_url = "";
	private $addon_zrdp = 0;
	private $addon_cnsm = 0;
	private $addon_ncbp = 0;
	private $addon_rsac = 0;
	private $addon_rtin = 0;
	private $addon_flag = true;
	private $_quote_id = "";
	private $_misc_text = "";
	
	
	public function gen_round_off() {
		try {
			$this->_od_value(  round( $this->od_value(), 0 ) );
			$this->_tp_value( round( $this->tp_value(), 0) );
			$this->_pa_value( round ( $this->pa_value(), 0) );
			$this->_ncb_value( round ( $this->ncb_value(), 0 ) );
			$this->_od_disc( round( $this->od_disc(),0 ) );
			$this->_idv(round( $this->idv(),0 ));
			
			$this->_service_tax( round( $this->service_tax(),0 ) );
			$this->_final_premium( round( $this->final_premium() ) );
		}catch (\Exception $ee){}
	}//end of method.
	
	
	public function product_code(){return $this->product_code;}
	public function idv(){return $this->idv;}
	public function insurer_code() { return $this->insurer_code; }
	public function insurer_name() { return $this->insurer_name; }
	public function insurer_logo() { return $this->insurer_logo; }
	public function od_value() { return $this->od_value; }
	public function tp_value() { return $this->tp_value; }
	public function pa_value() { return $this->pa_value; }
	public function cmdisc_value() { return $this->cmdisc_value; }
	public function ncb_perc() { return $this->ncb_perc; }
	public function ncb_value() { return $this->ncb_value; }
	public function od_disc() { return $this->od_disc; }
	public function gross_premium() { return $this->gross_premium; }
	public function service_tax() { return $this->service_tax; }
	public function final_premium() { return $this->final_premium; }
	public function proposal_url() { return $this->proposal_url; }
	public function addon_zrdp() { return $this->addon_zrdp; }
	public function addon_cnsm() { return $this->addon_cnsm; }
	public function addon_ncbp() { return $this->addon_ncbp; }
	public function addon_rsac() { return $this->addon_rsac; }
	public function addon_rtin() { return $this->addon_rtin; }
	public function addon_flag() { return $this->addon_flag; }
	
	
	
	public function _product_code($product_code){return $this->product_code= $product_code; }
	public function _idv($idv){return $this->idv = $idv; }
	public function _insurer_code($insurer_code) { $this->insurer_code = $insurer_code; }
	public function _insurer_name($insurer_name) {  $this->insurer_name = $insurer_name; }
	public function _insurer_logo($insurer_logo) {  $this->insurer_logo = $insurer_logo; }
	public function _od_value($od_value) {  $this->od_value = $od_value; }
	public function _tp_value($tp_value) {  $this->tp_value = $tp_value; }
	public function _pa_value($pa_value) {  $this->pa_value = $pa_value; }
	public function _cmdisc_value($cmdisc_value) {  $this->cmdisc_value= $cmdisc_value; }
	public function _ncb_perc($ncb_perc) {  $this->ncb_perc = $ncb_perc; }
	public function _ncb_value($ncb_value) {  $this->ncb_value = $ncb_value; }
	public function _od_disc($od_disc) {  $this->od_disc= $od_disc; }
	public function _gross_premium($gross_premium) {  $this->gross_premium = $gross_premium; }
	public function _service_tax($service_tax) {  $this->service_tax = $service_tax; }
	public function _final_premium($final_premium) {  $this->final_premium = $final_premium; }
	public function _proposal_url($proposal_url) {  $this->proposal_url= $proposal_url; }
	public function _addon_zrdp($addon_zrdp) {  $this->addon_zrdp= $addon_zrdp; }
	public function _addon_cnsm($addon_cnsm) {  $this->addon_cnsm= $addon_cnsm; }
	public function _addon_ncbp($addon_ncbp) {  $this->addon_ncbp= $addon_ncbp; }
	public function _addon_rsac($addon_rsac) {  $this->addon_rsac= $addon_rsac; }
	public function _addon_rtin($addon_rtin) {  $this->addon_rtin= $addon_rtin; }
	public function _addon_flag($addon_flag) {  $this->addon_flag= $addon_flag; }
	

  public function get_quote_id(){
    return $this->_quote_id;
  }

  public function set_quote_id($_quote_id){
    $this->_quote_id = $_quote_id;
  }





  public function get_tw_trans_code(){
    return $this->_tw_trans_code;
  }

  public function set_tw_trans_code($_tw_trans_code){
    $this->_tw_trans_code = $_tw_trans_code;
  }


  public function get_misc_text(){
    return $this->_misc_text;
  }

  public function set_misc_text($_misc_text){
    $this->_misc_text = $_misc_text;
  }

}
