<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @author ravirao
 *
 */
class TeamModel extends Model {
	protected $table = 'insta_team';

	/**
	 * @return unknown
	 */
	public function getTeamList() {
	return TeamModel::all();
	}
}