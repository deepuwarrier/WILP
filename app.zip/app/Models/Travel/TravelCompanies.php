<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelCompanies extends Model
{
    protected $table = 'travel_m_companies';
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false; 
    }

    public function insurer_details ($insurer_code) {
        return TravelCompanies::select('*')->where('code', $insurer_code)->first();
    }
    
    public function insurer_column ($insurer_code, $column_name) {
        return TravelCompanies::select($column_name)->where('code', $insurer_code)->first();
    }
}
