<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelConfig extends Model
{
    protected $table = 'travel_c_config';
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column, $check_values){
    	$result = self::select('config_key', 'config_value')
      	->where($column, 'like', '%'.$check_values.'%')
        ->get()->toArray();
        if(!empty($result)){
            foreach($result as $item) {
                $arr[$item['config_key']] = $item['config_value'];
            }
            return $arr;
        }
        else return false;
    }
}
