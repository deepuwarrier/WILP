<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelCoverageMap extends Model
{
    protected $table = 'travel_m_benefit_map';
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false; 
    }

}
