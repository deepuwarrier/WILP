<?php
namespace App\Models\Travel;
use Illuminate\Database\Eloquent\Model;

class TravelPaymentMode extends Model{
	protected $table = 'travel_m_paymode';
    public $timestamps = false;
    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }

    public function get_data($column){
        $data = self::select($column)
        		->whereNotNull($column)
        		->get()
        		->toArray();
        if(empty($data)){
            return false;
        }else{
            return $data;
        }
    }
}