<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelPed extends Model
{
    protected $table = 'travel_m_ped';
    public $timestamps = false;
    
    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public function get_data($column, $check_values){
        $result = self::select($column)
        ->whereNotNull($check_values)
        ->whereNull('ped_group')
        ->whereNull('ped_catagory')
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }

    public function get_sub_ped_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->whereNotNull('ped_group')
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }

    public function get_value($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }
}
