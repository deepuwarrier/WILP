<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelState extends Model
{
    protected $table = 'travel_m_state'; 
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public function get_all_data($column, $check_values){
        $result = self::select($column)
        ->whereNotNull($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }
    
    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }

    public function state_details($state_code) {
        return TravelState::select('*')->where('state_code', $state_code)->first();
    }
}
