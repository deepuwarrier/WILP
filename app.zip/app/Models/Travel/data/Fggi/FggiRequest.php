<?php

namespace App\Models\Travel\data\Fggi;

class FggiRequest {

	private $Product = '';
    private $XML = '';

    public function get_product(){
        return $this->Product;
    }

    public function set_product($Product){
        $this->Product = $Product;
    }

    public function get_xml(){
        return $this->XML;
    }

    public function set_xml($XML){
        $this->XML = $XML;
    }
}    