<?php

namespace App\Models\Travel\data;

class QuoteReqData {
	
    private $_session_key = '';
    private $_trans_code  = '';
    private $_trip_type = '';
    private $_area = '';
    private $_duration = 0;
    private $_member_count = 0;
    private $_dob_list = '';
    private $_age_list = '';
    private $_relationship = 0;
    private $_gender = '';
    private $_amt_duration = '';
    private $_sum_insured = '';
    private $_student_duration = '';
    

    public function get_session_key(){
        return $this->_session_key;
    }

    public function set_session_key($_session_key){
        $this->_session_key = $_session_key;
    }

    public function get_trans_code(){
        return $this->_trans_code;
    }

    public function set_trans_code($_trans_code){
        $this->_trans_code = $_trans_code;
    }

    public function get_area(){
        return $this->_area;
    }

    public function set_area($_area){
        $this->_area = $_area;
    }

    public function get_duration(){
        return $this->_duration;
    }

    public function set_duration($_duration){
        $this->_duration = $_duration;
    }

    public function get_member_count(){
        return $this->_member_count;
    }

    public function set_member_count($_member_count){
        $this->_member_count = $_member_count;
    }

    public function get_dob_list(){
        return $this->_dob_list;
    }

    public function set_dob_list($_dob_list){
        $this->_dob_list = $_dob_list;
    }

    public function get_age_list(){
        return $this->_age_list;
    }

    public function set_age_list($_age_list){
        $this->_age_list = $_age_list;
    }

    public function get_relationship(){
        return $this->_relationship;
    }

    public function set_relationship($_relationship){
        $this->_relationship = $_relationship;
    }

    public function get_gender(){
        return $this->_gender;
    }

    public function set_gender($_gender){
        $this->_gender = $_gender;
    }

    public function get_amt_duration(){
        return $this->_amt_duration;
    }

    public function set_amt_duration($_amt_duration){
        $this->_amt_duration = $_amt_duration;
    }

    public function get_sum_insured(){
        return $this->_sum_insured;
    }

    public function set_sum_insured($_sum_insured){
        $this->_sum_insured = $_sum_insured;
    }

    public function get_student_duration(){
        return $this->_student_duration;
    }

    public function set_student_duration($_student_duration){
        $this->_student_duration = $_student_duration;
    }

    public function get_trip_type(){
        return $this->_trip_type;
    }

    public function set_trip_type($_trip_type){
        $this->_trip_type = $_trip_type;
    }
}