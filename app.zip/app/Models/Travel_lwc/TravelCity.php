<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelCity extends Model
{
    protected $table = 'travel_m_city'; 
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public function get_data($column, $check_values){
        $result = self::select($column,'city_name')
        ->where($check_values)
        ->whereNotNull($column)
        ->orderBy('city_name', 'asc')
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }

    public function city_details($city_code) {
        return TravelCity::select('*')->where('city_name', $city_code)->first();
    }
}
