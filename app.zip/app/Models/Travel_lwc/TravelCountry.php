<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelCountry extends Model
{
    protected $table = 'travel_m_country'; 
    public $timestamps = false;

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public function get_data($column, $check_values = null){
        if($check_values){
            $result = self::select($column)
            ->whereNotNull($check_values)
            ->get()->toArray();
            if(!empty($result)) return $result;
            else return false;
        }
        
        $result = self::select($column)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }

    public function get_value($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;

    }

    public function get_data_continent($column, $check_values){
        $result = self::select($column)
        ->whereIn('fggi_continent',$check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }
}
