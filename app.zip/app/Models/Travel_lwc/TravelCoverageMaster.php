<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelCoverageMaster extends Model
{
    protected $table = 'travel_m_benefit_master';
    public $timestamps = false;

    public static function getTitle($id){
 		$title = self::select('benefit_title')->where('benefit_code', $id)->get()->toArray();
 		return $title[0]['benefit_title'];
 	}

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public function get_data($column, $check_values){
        $result = self::select($column)
        ->where($check_values)
        ->get()->toArray();
        if(!empty($result)) return $result;
        else return false;
    }
}
