<?php

namespace App\Models\Travel;
use Illuminate\Database\Eloquent\Model;

class TravelPolicy extends Model
{
    protected $table = 'travel_t_policy';
    protected $primaryKey = 'session_id';
    public $timestamps = false;

    protected $fillable = [ 'session_id','triptype','area','duration','amt_duration','std_duration','travelcount','dob','relationship','sum_insured','session_id','email','mobile','house_name','street','state','city','pincode','startdate','checks','cust_dob','age_list','title', 'gender','aadhaar_num','nomineename','nomineerel','passport','name', 'trip_start_date','trip_end_date', 'purpose', 'ped','company_id','company_column','plan_code','guardian_name', 'guardian_relationship', 'guardian_dob','guardian_passport', 'sponser_name', 'sponser_dob', 'sponser_relationship', 'university_name','program_name','program_duration','university_address','university_country','university_state','university_city','occupation','visa_type','marital_status','pg_refno','proposal_request','visiting_country','add_on','cust_area','city_list','area_list','passport_expiry','temp_col_1','agent_code','user_code','trans_code','quote_create_date','quote_update_date','quote_status','quote_desc','proposal_date','proposal_status','proposal_ref_number','proposal_desc','payment_date','payment_status','payment_ref_number','payment_desc','policy_date','policy_status','policy_desc','physician_name','physician_number'];
}
