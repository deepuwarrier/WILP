<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelTataPremium extends Model
{
    protected $table = 'travel_t_tatapremiumbreakup'; 
    public $timestamps = false;

    public static function update_premium($id, $premium, $tax){
 		self::where('breakup_key', $id)->update(['breakup_totalpremium' => $premium, 'breakup_tax' => $tax]);
 	}

    public static function update_addon($policyid, $id, $val){
    	self::where('breakup_key', $policyid)->update(['addon_id' => $id, 'addon_value' => $val]);
    }

    public static function getData($policyid){
    	$data =  self::where('breakup_key', $policyid)->get()->toArray();
    	return $data[0];
    }

    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->table;
    }
}
