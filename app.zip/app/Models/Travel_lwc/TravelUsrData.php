<?php

namespace App\Models\Travel;

use Illuminate\Database\Eloquent\Model;

class TravelUsrData extends Model
{
    protected $table = 'travel_t_usrdata';
    public $timestamps = false;
    protected $primaryKey = 'auto_id';
    protected $fillable = [ 'session_id','triptype','area','duration','amt_duration','std_duration','travelcount','dob','relationship','sum_insured','session_id','email','mobile','house_name','street','state','city','pincode','startdate','checks','cust_dob','age_list','title', 'gender','aadhaar_num','nomineename','nomineerel','passport','name', 'trip_start_date', 'trip_end_date', 'purpose', 'ped','company_id','company_column','plan_code','guardian_name', 'guardian_relationship', 'guardian_dob','guardian_passport', 'sponser_name', 'sponser_dob', 'sponser_relationship', 'university_name','program_name','program_duration','university_address','university_country','university_state','university_city', 'occupation','visa_type', 'marital_status','pg_refno','proposal_request','visiting_country','add_on','cust_area','city_list','area_list','passport_expiry','temp_col_1','agent_code','user_code','trans_code', 'quote_create_date','quote_update_date','quote_status','quote_desc','proposal_date','proposal_status','proposal_ref_number','proposal_desc','payment_date','payment_status','payment_ref_number','payment_desc','policy_date','policy_status','policy_desc','physician_name','physician_number'];

    public function __construct(array $attributes = []){
        parent::__construct($attributes);
        $this->table;
    }
    
    public static function get_data($columns, $trans_code){
        $data = self::select($columns)
        ->where('trans_code', $trans_code)
        ->get()->toArray();
        return $data[0];
    }
    
    public static function set_data($columns, $check_value){
        self::updateOrCreate($check_value, $columns);
    }
    
    public function update_data($columns, $trans_code){
        self::where('trans_code', $trans_code)->update($columns);
    }
    
    public function get_all_data($trans_code){
        $data = self::where('trans_code', $trans_code)
        ->get()->toArray();
        return $data[0];
    }

    public function get_trans_list($from_date, $to_date, $agent_code) {
                $data =  Self::whereRaw("STR_TO_DATE(`quote_create_date`,'%d-%b-%Y') between STR_TO_DATE('".$from_date."','%d-%b-%Y') and STR_TO_DATE('".$to_date."','%d-%b-%Y')");

        if(($agent_code != 'all') || ($agent_code == null)){
            $data->where('agent_code',$agent_code);
        }
        return $data->get();
    }
    
    
    public function get_by_tc($trans_code) {
        return self::all()->where('trans_code', $trans_code)->first();
    }
    
    public function get_by_sc($ssn_key) {
        return self::all()->where('session_id',$ssn_key)->first();
    }
}
