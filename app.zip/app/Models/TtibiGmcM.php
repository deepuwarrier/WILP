<?php

namespace App\Models;

use App\Constants\Tw_Constants;
use Illuminate\Database\Eloquent\Model;


class TtibiGmcM extends Model {
	
	protected $table = 'ttibi_gmc_master';
	
	public function __construct()
	{
	}
	

		public function search_emp($emp_code) {
			return TtibiGmcM::select("*")
			->where( "employee_code", $emp_code)
// 			->where( "date_of_birth", $emp_dob)
// 			->where("date_of_birth", "like", $emp_dob)
			->get();
		}
		
		

		public function save_member($member_id, $data) {
			TtibiGmcM::where("auto_id", $member_id)->update($data);
		}
	
	

	public function trans_exists($trans_code){
		$result = TtibiGmcM::select(Tw_Constants::TRANS_CODE)->where(Tw_Constants::TRANS_CODE, $trans_code)->get();
		if(count($result) > 0) {	return true;	}	else {	return false; }
	}

	public function values_by_policyno($policy_number) {
		return TtibiGmcM::all()->where( Tw_Constants::POLICY_NUMBER, $policy_number)->first();
	}
	
	public function get_by_tc($trans_code) {
		return TtibiGmcM::all()->where( Tw_Constants::TRANS_CODE, $trans_code)->first();
	}
	public function set_by_tc($trans_code, $data) {
		TtibiGmcM::where(Tw_Constants::TRANS_CODE, $trans_code)->update($data);
	}
	
	public function set_transaction($trans_code) {
		$data = array (	Tw_Constants::TRANS_CODE=> $trans_code, Tw_Constants::SSN_KEY => $trans_code);
		return TtibiGmcM::insertGetId( $data );
	}
	
	public function details_preview($trans_code) {
		$db_result =  TtibiGmcM::select("make_code", "model_code", "variant_code", "state_code", "rto_code", "yor")->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
		
		$make_db = new TwMakes();
		$model_db = new TwModels();
		$variant_db = new TwVariant();
		
		return  array(
				"make_name" => $make_db->make_details($db_result->make_code)->make_name,
				"model_name" => $model_db->model_details( $db_result->model_code)->model_name,
				"variant_name" => $variant_db->variant_details($db_result->variant_code)->variant_name,
				"rto_code" => $db_result->rto_code,
				"yor" => $db_result->yor
		);
	}
	
	public function quote_preview($trans_code) {
		$db_result =  TtibiGmcM::select("tw_reg_date", "term_start_date", "calc_idv",  "opt_idv","eli_ncb", "insurer_code", "total_premium")->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
		
		$insurer_code = $db_result->insurer_code;
		
		$insur_db = new TwInsurers();
		$insur_data = $insur_db->insurer_details($insurer_code);
		
		return  array(
				"reg_date" => $db_result->tw_reg_date,
				"term_start_date" => $db_result->term_start_date,
				"opt_idv" => $db_result->opt_idv,
				"eli_ncb" => $db_result->eli_ncb,
				"total_premium" => $db_result->total_premium,
				"insurer_name" => $insur_data->isu_name,
				"insurer_logo" => $insur_data->isu_logo
		);
	}
	
	
	public function get_yor_by_tc($trans_code) {
		return TtibiGmcM::select(Tw_Constants::YOR)->where(Tw_Constants::TRANS_CODE, $trans_code)->first();
	}
	
	public function get_by_agent_code($agent_code) {
		return TtibiGmcM::select("*")
		->where("agent_code", $agent_code)
		->where("agent_code","!=", null)
		->where("variant_code","!=", null)
		->get();
	}
	
	public function get_all_between($from_date, $to_date) {
		return TtibiGmcM::select("*")
		->where("variant_code","!=", null)
		->get();
	}
	
	public function set_agent($trans_code, $agent_code) {
		TtibiGmcM::where(Tw_Constants::TRANS_CODE, $trans_code)
		->update(array("agent_code" => $agent_code));
	}

	
}