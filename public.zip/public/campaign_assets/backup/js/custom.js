//Details section

//Details section ends

//Quote section
$(document).ready(function(){
  $('.toggle-btn').click(function(){
    $(this).toggleClass('toggles');
  })
})
//Quote section ends