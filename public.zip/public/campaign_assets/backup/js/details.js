service_request = { "_token": $('#_token').val(), "sum_insured" : "2000000", "deductible" : "500000" };
save_data_request = { "_token": $('#_token').val() };
si_set_one = $('#si_five,#si_ten,#si_fifteen,#si_twenty');
si_set_two = $('#si_six,#si_eleven,#si_sixteen');
si_set_one_array = ['si_five','si_ten','si_fifteen','si_twenty'];
si_set_two_array = ['si_six','si_eleven','si_sixteen'];


$(document).ready(function(){ 
si_set_one.removeClass('campaign-off-display');
si_set_two.addClass('campaign-off-display');  
helper = {
    load_proposal: function(trans_code){
      $('.header').addClass('campaign-off-display');
      $('#intro').addClass('campaign-off-display');
      $('#customer_details_container').addClass('campaign-off-display');
      $('#quote_searching_container').addClass('campaign-off-display');
      $('#footer').addClass('campaign-off-display');
      service_request.trans_code = trans_code;
      service_url = $('#hdfc_proposal_url').val();
      $.ajax({
        type: 'GET',
        url: service_url,
        data: service_request,
        dataType: "json",
        success: function(data){
          if(data.status){
            $('#proposal_box_coverage').text(data.sum_insured);    
            $('#proposal_box_deductible').text(data.deductables);
            $('#proposal_box_tenure').text(data.tenure);
            $('#proposal_box_premium').text(data.premium);
            $('#proposal_container').removeClass('campaign-off-display');
            $('#footer').removeClass('campaign-off-display');
            self.scroll_to_container('#proposal_container');
            $('#insured_container').html('');
            $('#insured_container').append(data.insured_data);
            initInsuredFormValidation();
            self.initMask();
          }else{
            self.alert_box(data.error_title,data.error_msg,'info');
          }
            
        }
      }).fail(function (jqXHR, textStatus, errorThrown) {
          console.log('error');
      });
      
    },
	  load_hdfc: function(trans_code){
      $('.si--btn, .dd--btn, .tenure--btn').prop('disabled', true);
      service_request.trans_code = trans_code;
      service_request.call_type = 'campaign',
      service_url = $('#hdfc_quote_url').val();
      $.ajax({
        type: 'GET',
        url: service_url,
        data: service_request,
        dataType: "json",
        success: function(data){
          $('#quote_searching_container').addClass('campaign-off-display');
          $('#quote_container').removeClass('campaign-off-display');
          $('#buy_now_btn').html('BUY FOR ' + data.premium);
          setTimeout(function(){ 
            $('#quote_box_loader_container').hide();
            $('#quote_box_container').append(data.quote_box);
            $('#mem_covered_container').html('');
            $('#mem_covered_container').html(data.members_covered);
            $('.si--btn, .dd--btn, .tenure--btn').prop('disabled', false);
          }, 800);          
        }
      }).fail(function (jqXHR, textStatus, errorThrown) {
          console.log('error');
      }).always(function(jqXHR, textStatus) {
          
      });  
    },
    save_initial_inputs: function(){
    	$data = $('#initial_input_form').serialize();
    	$data_array = $('#initial_input_form').serializeArray();
    	if(self.validate_initial_inputs($data_array))
    		$('#initial_input_form').submit();
  	},
    save_proposal_data: function(form_id){
      var form_data = $(form_id).serializeArray();
      var trans_code = $('#trans_code').val();

      request_data = self.serilazeInnerArr(form_data);
      request_data.trans_code = trans_code;
      request_data.tab_id = 'insured';
      service_url = $('#save_proposal_url').val();

      console.log(request_data);
      $.ajax({
        type: 'GET',
        url: service_url,
        data: request_data,
        dataType: "json",
        success: function(data){
          if(data.status)
            console.log('saved');

          if(!data.status)
            console.log('error in saving data');    
        }
      }).fail(function (jqXHR, textStatus, errorThrown) {
          console.log('error');
      });

    },
    serilazeInnerArr: function(a){
      var b = {};
      $.each(a,function(c,d){         
        if(d.name.indexOf('[]') != -1){
           if(b[""+d.name] == 'undefined' || b[""+d.name] == undefined){
            b[""+d.name] = [];    
        }
        b[""+d.name][b[""+d.name].length] = d.value;
        }else{
            b[""+d.name] = d.value;
        }
                  
        });
      return b;
    },
  	validate_initial_inputs: function(data_array){
  		var self_flag = false; var empty_array_flag = false; var self_value = ''; var self_age = '';
  		var title = 'Invalid  inputs'; var text = ''; var type = 'info';
  		if(data_array == ''){
  			empty_array_flag = true;
  			text = 'Please make your selections ';
  		}
  		$.each(data_array, function( index, data ) {
  			if( data['name'] == 'self' ) {
  				self_flag = true;
  				self_value =  data['value'];
  			}
		});
		if(!empty_array_flag && !self_flag){
  	    	title = 'Which one is you?!!!';
			text = "Please select the 'this is me' button";
	    }

  		if(!empty_array_flag && self_flag){
  			self_flag = false;
  			$.each(data_array, function( index, data ) {
	  			if(self_value == 'female'){
	  				if(data['name'] == "female_age" ) {
	  					self_flag = true;
	  				}
	  			}
	  			if(self_value == 'male'){
	  				if(data['name'] == "male_age" ) {
	  					self_flag = true;
	  				}
	  			}
			});
			if(!self_flag){
				text = "Please select your age";
			}

	    }
  		if(text){
  			self.alert_box(title,text,type)
  			return false;
  		}
  		return true;
  	},
  	alert_box: function(title,text,type){
  		swal({ title: title, text:  text, icon:  type, buttons: false });
  	},
    si_btn_manager: function(deductible){
      sum_insured = $("#si_container .active").attr('id')
      if(deductible == '400000'){
        if(jQuery.inArray(sum_insured, si_set_one_array) !== -1){
          service_request.sum_insured = '1600000';
          $('.si--btn').removeClass('active');
          $('#si_sixteen').addClass('active');
        }
        si_set_one.addClass('campaign-off-display');
        si_set_two.removeClass('campaign-off-display');
      }
      if(deductible == '500000'){
        if(jQuery.inArray(sum_insured, si_set_two_array) !== -1){ 
          service_request.sum_insured = '2000000';
          $('.si--btn').removeClass('active')
          $('#si_twenty').addClass('active');
        }
        si_set_one.removeClass('campaign-off-display');
        si_set_two.addClass('campaign-off-display');
      } 
    },
  	clear_form: function(){
  		form = '#initial_input_form';
   	    $(form).find(':input').not(':button, :submit, :reset, :hidden, :checkbox, :radio, select').val('');
   	    $(form).find(':checkbox, :radio').prop('checked', false);
   	    $('select').prop('selectedIndex',0);
        $('#quote_searching_container').addClass('campaign-off-display');
        $('#quote_container').addClass('campaign-off-display');
        $('#proposal_container').addClass('campaign-off-display');
	},
	scroll_to_container: function(id){
  		$('html, body').animate({
           scrollTop: $(id).offset().top
    	}, 2000);
    	
	},
  initMask: function(){
    $('.datepicker').mask('00-00-0000');
    $('.aadhaar').mask('0000-0000-0000');
    $( ".datepicker" ).datepicker({ 
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true, 
    });
  },
  	init: function(){
		self = this;
		$("#get_plans").on("click",self.save_initial_inputs)
		$("#clear_initial_selection_btn").on("click", self.clear_form);	
	}
}
  helper.init();
});

//Get Started btn click
$('#get_started_btn').on("click",function(e) {
    $('#customer_details_container').removeClass('campaign-off-display');
    helper.scroll_to_container('#customer_details_container');
});

// Buy now btn click
$(document).on('click','#buy_now',function(){
   var trans_code = $('#trans_code').val();
   helper.load_proposal(trans_code);
});
// Sum Insured btn click
$('.si--btn').on("click",function(e) {
  $('.si--btn').removeClass('active')
  $(this).addClass('active')
  service_request.sum_insured = $(this).attr('value')
  //service_request.deductible = $("#deductible_container .active").attr('value')
  $('#quote_box_container').html('');
  $('#quote_box_loader_container').show();
  helper.load_hdfc(service_request.trans_code);  
});
// Deductible btn click
$('.dd--btn').on("click",function(e) {
  helper.si_btn_manager($(this).attr('value'));
  $('.dd--btn').removeClass('active');
  $(this).addClass('active');
  service_request.deductible = $(this).attr('value')
  //service_request.sum_insured = $("#si_container .active").attr('value')
  $('#quote_box_container').html('');
  $('#quote_box_loader_container').show();
  helper.load_hdfc(service_request.trans_code);
});

// Tenure btn click
$('.tenure--btn').on("click",function(e) {
  $('.tenure--btn').removeClass('active')
  $(this).addClass('active')
  service_request.tenure = $(this).attr('value');
  $('#quote_box_container').html('');
  $('#quote_box_loader_container').show();
  helper.load_hdfc(service_request.trans_code);
});

//PED Question
$('.ped_question').on("click",function(e) {
  $('.ped_question').removeClass('active');
  $(this).addClass('active');
  ped_ans = $(this).attr('value');
  if(ped_ans == 'yes'){
    $('#ped_container').removeClass('campaign-off-display');
  }
  if(ped_ans == 'no')
    $('#ped_container').addClass('campaign-off-display');
});


//Temp btn

$('.tmp_save').on("click",function(e) {
  var status = $('#insured_form').valid();
  console.log(status);
  if(status)
    helper.save_proposal_data('#insured_form');
});