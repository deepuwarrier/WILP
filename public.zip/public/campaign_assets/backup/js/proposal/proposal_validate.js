
function initInsuredFormValidation(){
var insured_form = $('#insured_form');
//Validation messages
var MSG_ALPHABETS_ONLY = 'Only alphabets are allowed';
var MSG_DATE = 'Please enter a valid date';

//Validation rules
var ALPHABETS_ONLY = "^[a-zA-Z]+$";
var ALPHABETS_ONLY_SPECIAL_COMBO_ONE = "^[a-zA-Z ]+$";
var DATE = "^(0[1-9]|1[012])[-/.](0[1-9]|[12][0-9]|3[01])[-/.](19|20)\\d\\d$";

insured_form.validate({
    errorClass: "error-class",
    errorPlacement: function(error, element) {
             if (element.attr("name") == "nominee_relation" ){
                 error.insertAfter("."+element.attr("id")+"-error");
             }
             else{
                error.insertAfter(element);
            }    
    },
    rules: {
    	"firstname[]": {
	        required: true,
	        maxlength: 45,
            regex: {
                reg: ALPHABETS_ONLY,
                msg: MSG_ALPHABETS_ONLY
            },
	    },
        "lastname[]": {
            required: true,
            maxlength: 45,
            regex: {
                reg: ALPHABETS_ONLY,
                msg: MSG_ALPHABETS_ONLY
            },
        },
        "mobile": {
            required: true,
            maxlength: 10,
            digits: true
        },
        "email": {
            required: true,
            email: true
        },
        "height_feet[]":{
            required: true,
            maxlength: 1,
            digits: true,
            minValue: 1,
            maxValue: 8
        },
        "height_inches[]":{
            required: true,
            maxlength: 2,
            digits: true
        },
        "weight[]":{
            required: true,
            maxlength: 3,
            digits: true,
            minValue: 1,
            maxValue: 125
        },
        "dob_list[]":{
            required: true
        },
        "aadhaar_num[]":{
            required: true,
            maxlength: 14,
            minlength: 14,
        },
        "nominee_name":{
            required: true,
            maxlength: 45,
            minlength: 3,
            regex: {
                reg: ALPHABETS_ONLY_SPECIAL_COMBO_ONE,
                msg: MSG_ALPHABETS_ONLY
            },
        },
        "nominee_relation":{
            required: true
        },
    },
    messages: {
    	"firstname[]": {
        	required: 'This field is required',
        	maxlength: "Maximum 45 characters"
        },
        "lastname[]": {
            required: 'This field is required',
            maxlength: "Maximum 45 characters"
        },
        "mobile": {
            required: 'This field is required',
            maxlength: "Maximum 10 characters",
            digits: "Invalid mobile number"
        },
        "email": {
            required: 'This field is required',
            email: "Invalid Email ID"
        },
        "height_feet[]": {
            required: 'This field is required',
            maxlength: "Invalid measurement",
            minValue: "Invalid measurement",
            maxValue: "Invalid measurement",
            digits: "Invalid measurement"
        },
        "height_inches[]": {
            required: 'This field is required',
            maxlength: "Invalid measurement",
            digits: "Invalid measurement"
        },
        "weight[]": {
            required: 'This field is required',
            maxlength: "Invalid weight",
            minValue: "Minimum weight should be 1Kg",
            maxValue: "Maximum weight allowed is 125Kg",
            digits: "Invalid weight"
        },
        "dob_list[]": {
            required: 'This field is required'
        },
        "aadhaar_num[]": {
            required: 'This field is required',
            maxlength: "Invalid aadhaar",
            minlength: "Invalid aadhaar",
        },
        "nominee_name": {
            required: 'This field is required',
            maxlength: "maximum 45 characters",
            minlength: "Minimum 3 characters",
        },
        "nominee_relation": {
            required: 'This field is required'
        },

    },
    submitHandler: function(form) {
    	alert('Ya Ya Ya njan oorkkunnu!');
    }
});

$.validator.addMethod("regex"
    ,function(value, element, params ) {
        if(typeof params == 'object')
            regexp = params.reg;
        else
            regexp = params;
        var re = new RegExp(regexp);
        return this.optional(element) || re.test(value);
    },
    function(params, element) {
        if(typeof params.msg != 'undefined')
                    return params.msg;
        return 'Invalid Entry';
    }
);

$.validator.addMethod('minValue', function (value, el, param) {
    return value >= param;
});

$.validator.addMethod('maxValue', function (value, el, param) {
    return value <= param;
});


}
