$('#report_pass_verify_btn').on("click", function(e) {
    reportFormValidation();
    var status = $('#campaign-report-form').valid();
    if (status){
       var form_data = $('#campaign-report-form').serializeArray();	
       var request_data = serilazeInnerArr(form_data);
       var url =  $('#campaign-report-form').attr('action');
       $('body').loading({message: "Authenticating..."});
       post_data(url, 'post', request_data);
    }
});

function post_data(actionUrl, method, data) {
            var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
                }
            }
            $('body').append(mapForm);
            mapForm.submit();
}

function serilazeInnerArr(a) {
            var b = {};
            $.each(a, function(c, d) {
                if (d.name.indexOf('[]') != -1) {
                    if (b["" + d.name] == 'undefined' || b["" + d.name] == undefined) {
                        b["" + d.name] = [];
                    }
                    b["" + d.name][b["" + d.name].length] = d.value;
                } else {
                    b["" + d.name] = d.value;
                }

            });
            return b;
}

$('#from_date,#to_date').datepicker({
                        maxDate: new Date(),
                        dateFormat: 'dd-M-yy',
                        yearRange: "-0:+1"
                    })