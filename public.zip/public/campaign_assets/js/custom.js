//Details section

//Quote section
$(document).ready(function() {
    $('.tooltip').tooltipster();
    $('.toggle-btn').click(function() {
        $(this).toggleClass('toggles');
    })
})
//Quote section ends

$(document).ready(function() {
    $('body').loading('stop');
    $('body').show();
    $('#bmi_modal').on('hidden.bs.modal', function() {
        $('.modal-backdrop.show').css('opacity', '.5');
        $('.modal-backdrop').css('background', '#000000');
    });

    customerModalFormValidation();

    //covarage tabs
    var tabs = $(".tabs li a");
    tabs.click(function() {
        var content = this.hash.replace('/', '');
        tabs.removeClass("active");
        $(this).addClass("active");
        $("#content").find('div').hide();
        $(content).fadeIn(200);
    });
    
    //Transitions
    var element = '#left_img_03';
    trans.fadeIn(element, 3000);

    var element = '#left_img_02';
    trans.slideLeft(element,1500,'left');

});


$('#pg_modal').on('shown.bs.modal', function() {
    $('.modal-backdrop.show').css('opacity', '1');
    $('.modal-backdrop').css('background', '#ffffff');
});
$('#customer_details_form_submit_btn').on("click", function(e) {
	var form_id = "#customer_details_form";
    var status  = $(form_id).valid();
    if (status) {
        helper.save_cust_modal_data(form_id);
    }
});