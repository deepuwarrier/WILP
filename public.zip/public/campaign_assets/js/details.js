service_request = {
    "_token": $('#_token').val(),
    "sum_insured": "2000000",
    "deductible": "500000",
    "tenure": "1"
};
save_data_request = {
    "_token": $('#_token').val()
};
city_list_request = {
    "_token": $('#_token').val()
};
pg_service_request = {
    "_token": $('#_token').val(),
    "trans_code": $('#trans_code').val(),
    "customer_acceptance": 0
};
otp_status_request = {
    "trans_code": $('#trans_code').val(),
    "mobile": 0
};
otp_verify_request = {
    "mobile": 0,
    "code": 0
};

si_set_one = $('#si_five,#si_ten,#si_fifteen,#si_twenty');
si_set_two = $('#si_six,#si_eleven,#si_sixteen');
si_set_one_array = ['si_five', 'si_ten', 'si_fifteen', 'si_twenty'];
si_set_two_array = ['si_six', 'si_eleven', 'si_sixteen'];
payment_validation_flag = 0;

$(document).ready(function() {
    si_set_one.removeClass('campaign-off-display');
    si_set_two.addClass('campaign-off-display');
    helper = {
        load_proposal: function(trans_code) {
            $('.header').addClass('campaign-off-display');
            $('#intro').addClass('campaign-off-display');
            $('#customer_details_container').addClass('campaign-off-display');
            $('#quote_searching_container').addClass('campaign-off-display');
            $('#quote_container').addClass('campaign-off-display');
            $('#footer').addClass('campaign-off-display');
            service_request.trans_code = trans_code;
            service_url = $('#hdfc_proposal_url').val();
            $.ajax({
                type: 'GET',
                url: service_url,
                data: service_request,
                dataType: "json",
                success: function(data) {
                    if (data.status) {
                        $('#proposal_box_coverage').text(data.sum_insured);
                        $('#proposal_box_deductible').text(data.deductables);
                        $('#proposal_box_tenure').text(data.tenure);
                        $('#proposal_container').removeClass('campaign-off-display');
                        $('#footer').addClass('campaign-off-display');
                        self.scroll_to_container('#proposal_container');
                        $('#INSURED_MEMBERS').html('');
                        $('#INSURED_MEMBERS').append(data.insured_data);
                        $('#ADDRESS').html('');
                        $('#ADDRESS').append(data.address_data);
                        $('#MEDICAL_HISTORY').html('');
                        $('#MEDICAL_HISTORY').append(data.medical_history_data);
                        $('#PAYMENT').html('');
                        $('#PAYMENT').append(data.payment_data);
                        $('.box_premium').text(data.premium);
                        initInsuredFormValidation();
                        initAddressFormValidation();
                        initPEDFormValidation();
                        initPaymentFormValidation();
                        self.initMask();
                    } else {
                        self.alert_box(data.error_title, data.error_msg, 'info');
                    }

                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('error');
            });

        },
        load_hdfc: function(trans_code) {
            $('.si--btn, .dd--btn, .tenure--btn').prop('disabled', true);
            service_request.trans_code = trans_code;
            service_request.call_type = 'campaign',
                service_url = $('#hdfc_quote_url').val();
            $.ajax({
                type: 'GET',
                url: service_url,
                data: service_request,
                dataType: "json",
                success: function(data) {
                    $('#quote_searching_container').addClass('campaign-off-display');
                    $('#quote_container').removeClass('campaign-off-display');
                    $('#buy_now_btn').html('BUY FOR ' + data.premium);
                    setTimeout(function() {
                        $('#quote_box_loader_container').hide();
                        $('#quote_box_container').append(data.quote_box);
                        $('#mem_covered_container').html('');
                        $('#mem_covered_container').html(data.members_covered);
                        $('.si--btn, .dd--btn, .tenure--btn').prop('disabled', false);
                    }, 800);
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('error');
            }).always(function(jqXHR, textStatus) {

            });
        },
        check_ped_form: function(form_id) {
            // Checking checkbox
            $('#ped_common_error').show();
            $('#ped_common_error').html('');
            //$('.ped_text_error').html('');
            if ($("#MEDICAL_HISTORY_FORM input:checkbox:checked").length > 0){
                var error_flag = 1;

                // Removing textbox values of all uncheck fields
                $("#MEDICAL_HISTORY_FORM input:checkbox:not(:checked)").each(function(){
                    var textbox = $('#' + $(this).attr("id") + '_textfield');
                    var error_box = $('#' + $(this).attr("id") + '_textfield_error');
                    textbox.val('');
                    error_box.html('');
                });

                $("#MEDICAL_HISTORY_FORM input:checkbox:checked").each(function(){
                    var textbox = $('#' + $(this).attr("id") + '_textfield');
                    var error_box = $('#' + $(this).attr("id") + '_textfield_error');
                    if(textbox.val().length == 0){
                        error_box.html('This field is required');
                        error_flag = 0;
                    }else{
                        error_box.html('');
                    }
                });
                if(error_flag)
                    widget.widget_next();
            }else{
                self.auto_hide('ped_common_error', 3000);
                $('#ped_common_error').html('Please select the members');
            }
        },
        save_cust_modal_data: function(form_id) {
            var form_data = $(form_id).serializeArray();
            request_data = self.serilazeInnerArr(form_data);
            service_url = $(form_id).attr('data-url');
            $('#customer_details_form_submit_btn').text('Submitting...');
            $.ajax({
                type: 'GET',
                url: service_url,
                data: request_data,
                dataType: "json",
                success: function(data) {
                    if (data.status) {
                        $('#ini_Modal').modal('toggle');
                        $('#initial_input_form').submit();
                    }
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                $('#customer_details_form_submit_btn').text('Submit');
                console.log('error');
            });
        },
        save_initial_inputs: function() {
            $data = $('#initial_input_form').serialize();
            $data_array = $('#initial_input_form').serializeArray();
            var pointer = $('#page_pointer').val();
            var modal_trigger = $('#cust_modal_trigger').val();
            if (self.validate_initial_inputs($data_array)){
                if ( (modal_trigger == 1) && pointer == 'show') {
                    $('#ini_Modal').modal({
                        show: true,
                    });
                }else{
                    $('#initial_input_form').submit();
                }
                
            }
        },
        save_proposal_data: function(tab_id) {
            var status = $('#' + tab_id + 'FORM').valid();
            if (status) {
                var form_data = $('#' + tab_id + 'FORM').serializeArray();
                var trans_code = $('#trans_code').val();
                request_data = self.serilazeInnerArr(form_data);
                request_data.trans_code = trans_code;
                request_data.tab_id = tab_id;
                service_url = $('#save_proposal_url').val();
                $.ajax({
                    type: 'GET',
                    url: service_url,
                    data: request_data,
                    dataType: "json",
                    success: function(data) {
                        if (data.status) {
                            console.log('saved');
                            if (payment_validation_flag) {
                                self.collect_pg_request();
                            }
                        }

                        if (!data.status)
                            console.log('error in saving data');
                    }
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    console.log('error');
                });

            } // End status 

        },
        restict_user: function(msg) {
            self.alert_box('Sorry, Unable to proceed!', msg, 'info');
        },
        verify_otp: function() {
            var mobile_num = $('#mobile').val();
            var otp = $('#otp').val();
            service_url = $('#mobile').attr('verify-otp-url');
            otp_verify_request.mobile = mobile_num;
            otp_verify_request.otp = otp;
            var validator = $('#otp_form').validate();

            service_url
            $.ajax({
                type: 'GET',
                url: service_url,
                data: otp_verify_request,
                dataType: "json",
                success: function(data) {
                    $('#proposal_container').loading('stop');
                    if ((data.status == false) && (data.attempt_otp == true)) {
                        $('#otp_attempts_text').html(data.attempts);
                        validator.showErrors({
                            'otp': 'Incorrect OTP'
                        });
                    } else if (data.status == true) {
                        $('#otp_modal').modal('hide');
                        widget.widget_next();
                    } else {
                        $('#otp_modal').modal('hide');
                        helper.restict_user(data.msg);
                    }
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                return false;
                console.log('error');
            });
        },
        collect_pg_request: function() {
            service_url = $('#pg_service_url').val();
            $('.sticky_footer').addClass('campaign-off-display');
            $('#pg_modal').modal('show');
            $.ajax({
                type: 'POST',
                url: service_url,
                data: pg_service_request,
                dataType: "json",
                success: function(data) {
                    if (data.status == true) {
                        self.post_data(data.payUrl, 'post', data);
                    }else if(data.message == 'bmi_error'){
                        $('.sticky_footer').removeClass('campaign-off-display');
                        $('#pg_modal').modal('hide');
                        $('#bmi_modal_body').html(data.bmi_message);
                        $('#bmi_modal').modal('show');
                    }else {
                        self.alert_box('Server error', data.message, 'info')
                    }
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                //$('#payment_container').loading('stop');
                console.log('error');
            });
        },
        close_proposal_page: function(btn_id) {
            service_url = $(btn_id).attr('url');
            $.ajax({
                type: 'GET',
                url: service_url,
                data: {
                    " _token": $('#_token').val(),
                    'trans_code': $('#trans_code').val()
                },
                dataType: "json",
                success: function(data) {
                    location.reload();
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('error');
            });
        },
        post_data: function(actionUrl, method, data) {
            var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
                }
            }
            $('body').append(mapForm);
            mapForm.submit();
        },
        load_city: function(state_code, id) {
            $('#address_container').loading({
                message: 'Loading cities...'
            });
            service_url = $(id).attr('route');
            city_list_request.state_id = state_code;
            city_list_request.insurer_name = 'hdfc';
            $.ajax({
                type: 'POST',
                url: service_url,
                data: city_list_request,
                dataType: "json",
                success: function(data) {
                    $('#address_container').loading('stop');
                    $('#city').empty()
                    $('#city').append('<option hidden="" selected="" value="" disabled="">Select City</option>');
                    $.each(data, function(index, value) {
                        option = '<option value = "' + value.city_code + '">' + self.ucwords(value.city_name) + '</option>',
                            $('#city').append(option)
                    })
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                console.log('error');
            });

        },
        ucwords: function(text) {
            return (text.toLowerCase().replace(/^(.)|(\s|\-)(.)/g,
                function(c) {
                    return c.toUpperCase();
                }));
        },
        serilazeInnerArr: function(a) {
            var b = {};
            $.each(a, function(c, d) {
                if (d.name.indexOf('[]') != -1) {
                    if (b["" + d.name] == 'undefined' || b["" + d.name] == undefined) {
                        b["" + d.name] = [];
                    }
                    b["" + d.name][b["" + d.name].length] = d.value;
                } else {
                    b["" + d.name] = d.value;
                }

            });
            return b;
        },
        validate_initial_inputs: function(data_array) {
            var self_flag = false;
            var empty_array_flag = false;
            var self_value = '';
            var self_age = '';
            var title = 'Invalid  inputs';
            var text = '';
            var type = 'info';
            if (data_array == '') {
                empty_array_flag = true;
                text = 'Please make your selections ';
            }
            $.each(data_array, function(index, data) {
                if (data['name'] == 'self') {
                    self_flag = true;
                    self_value = data['value'];
                }
            });
            if (!empty_array_flag && !self_flag) {
                title = 'Which one is you?!!!';
                text = "Please select the 'this is me' button";
            }

            if (!empty_array_flag && self_flag) {
                self_flag = false;
                $.each(data_array, function(index, data) {
                    if (self_value == 'female') {
                        if (data['name'] == "female_age") {
                            self_flag = true;
                        }
                    }
                    if (self_value == 'male') {
                        if (data['name'] == "male_age") {
                            self_flag = true;
                        }
                    }
                });
                if (!self_flag) {
                    text = "Please select your age";
                }

            }
            if (text) {
                self.alert_box(title, text, type)
                return false;
            }
            return true;
        },
        alert_box: function(title, text, type) {
            swal({
                title: title,
                text: text,
                icon: type,
                buttons: false
            });
        },
        si_btn_manager: function(deductible) {
            sum_insured = $("#si_container .btn-active").attr('id')
            if (deductible == '400000') {
                if (jQuery.inArray(sum_insured, si_set_one_array) !== -1) {
                    service_request.sum_insured = '1600000';
                    $('.si--btn').removeClass('btn-active');
                    $('#si_sixteen').addClass('btn-active');
                }
                si_set_one.addClass('campaign-off-display');
                si_set_two.removeClass('campaign-off-display');
            }
            if (deductible == '500000') {
                if (jQuery.inArray(sum_insured, si_set_two_array) !== -1) {
                    service_request.sum_insured = '2000000';
                    $('.si--btn').removeClass('btn-active')
                    $('#si_twenty').addClass('btn-active');
                }
                si_set_one.removeClass('campaign-off-display');
                si_set_two.addClass('campaign-off-display');
            }
        },
        clear_form: function() {
            form = '#initial_input_form';
            $(form).find(':input').not(':button, :submit, :reset, :hidden, :checkbox, :radio, select').val('');
            $(form).find(':checkbox, :radio').prop('checked', false);
            $('select').prop('selectedIndex', 0);
            $('#quote_searching_container').addClass('campaign-off-display');
            $('#quote_container').addClass('campaign-off-display');
            $('#proposal_container').addClass('campaign-off-display');
        },
        scroll_to_container: function(id) {
            $('html, body').animate({
                scrollTop: $(id).offset().top
            }, 2000);

        },
        auto_hide: function(id, time) {
            setTimeout(function() {
              $('#'+id).fadeOut('fast');
            }, time); // <-- time in milliseconds
        },
        initMask: function() {
            $('.datepicker').mask('00-00-0000');
            $('.aadhaar').mask('0000-0000-0000');
            $('.otp').mask('0-0-0-0');
            $("#state").change(function() {
                self.load_city($(this).val(), '#state');
            });

            // Group dob_list in proposal page
            for(i=0; i<5; i++){ 
                if($('#dob_list'+i).length){ 
                    $('#dob_list'+i).datepicker({
                        dateFormat: 'dd-mm-yy',
                        minDate: $('#dob_list'+i).attr('min-date'),
                        maxDate: $('#dob_list'+i).attr('max-date'),
                        yearRange: "-90:+1"
                    })
                } 
            }
        },
        init: function() {
            self = this;
            $("#get_plans").on("click", self.save_initial_inputs);
            $("#clear_initial_selection_btn").on("click", self.clear_form);
        }
    }
    helper.init();
});
//Get Started btn click
$('#get_started_btn').on("click", function(e) {
    $('#customer_details_container').removeClass('campaign-off-display');
    helper.scroll_to_container('#customer_details_container');
});
// Buy now btn click
$(document).on('click', '#buy_now', function() {
    var trans_code = $('#trans_code').val();
    helper.load_proposal(trans_code);
});
// Sum Insured btn click
$('.si--btn').on("click", function(e) {
    $('.si--btn').removeClass('btn-active')
    $(this).addClass('btn-active')
    service_request.sum_insured = $(this).attr('value')
    //service_request.deductible = $("#deductible_container .active").attr('value')
    $('#quote_box_container').html('');
    $('#quote_box_loader_container').show();
    helper.load_hdfc(service_request.trans_code);
});
// Deductible btn click
$('.dd--btn').on("click", function(e) {
    helper.si_btn_manager($(this).attr('value'));
    $('.dd--btn').removeClass('btn-active');
    $(this).addClass('btn-active');
    service_request.deductible = $(this).attr('value')
    //service_request.sum_insured = $("#si_container .active").attr('value')
    $('#quote_box_container').html('');
    $('#quote_box_loader_container').show();
    helper.load_hdfc(service_request.trans_code);
});
// Tenure btn click
$('.tenure--btn').on("click", function(e) {
    $('.tenure--btn').removeClass('btn-active')
    $(this).addClass('btn-active')
    service_request.tenure = $(this).attr('value');
    $('#quote_box_container').html('');
    $('#quote_box_loader_container').show();
    helper.load_hdfc(service_request.trans_code);
});
//PED Question
$(document).on('click', '.ped_question', function() {
    $('.ped_question').removeClass('btn-active');
    $(this).addClass('btn-active');
    ped_ans = $(this).attr('value');
    if (ped_ans == 'yes') {
        $('#ped_qn').val('y');
        $('#ped_container').removeClass('campaign-off-display');
    }
    if (ped_ans == 'no') {
        $('#ped_qn').val('n');
        $('#ped_container').addClass('campaign-off-display');
    }
});
$('#close_proposal').on("click", function(e) {
    helper.close_proposal_page('#close_proposal');
});
$(document).on('click', '.payment_checkbox', function() {
    $('#payment_option').val($(this).val());
    $('.payment_checkbox').not(this).prop('checked', false);
});
$(document).on('click', '#make_payment_btn', function() {
    var status = $('#PAYMENT_FORM').valid();
    if (status) {
        payment_validation_flag = 1;
        helper.save_proposal_data('PAYMENT_');
    }
});
$(document).on('click', '#accept_medical_condition', function() {
    pg_service_request.customer_acceptance = 1;
    helper.collect_pg_request();
});
$('#opt_verification_btn').on("click", function(e) {
    otpFormValidation();
    var status = $('#otp_form').valid();
    if (status)
        helper.verify_otp();
});