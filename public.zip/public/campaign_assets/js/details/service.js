/*
  Details section service file
*/
$(document).ready(function(){ 
details_service = {
    save_initial_inputs: function(){
    	$data = $('#initial_input_form').serialize();
    	$data_array = $('#initial_input_form').serializeArray();
    	if(self.validate_initial_inputs($data_array))
    		$('#initial_input_form').submit();
  	},
  	validate_initial_inputs: function(data_array){
  		var self_flag = false; var empty_array_flag = false; var self_value = ''; var self_age = '';
  		var title = 'Invalid  inputs'; var text = ''; var type = 'info';
  		if(data_array == ''){
  			empty_array_flag = true;
  			text = 'Please make your selections ';
  		}

  		$.each(data_array, function( index, data ) {
  			if( data['name'] == 'self' ) {
  				self_flag = true;
  				self_value =  data['value'];
  			}
		});

		if(!empty_array_flag && !self_flag){
  	    	title = 'Which one is you?!!!';
			text = "Please select the 'this is me' button";
	    }

  		if(!empty_array_flag && self_flag){
  			self_flag = false;
  			$.each(data_array, function( index, data ) {
	  			if(self_value == 'female'){
	  				if(data['name'] == "female_age" ) {
	  					self_flag = true;
	  				}
	  			}
	  			if(self_value == 'male'){
	  				if(data['name'] == "male_age" ) {
	  					self_flag = true;
	  				}
	  			}
			});
			if(!self_flag){
				text = "Please select your age";
			}

	    }

  		if(text){
  			self.alert_box(title,text,type)
  			return false;
  		}

  		return true;
  		
  	},
  	alert_box: function(title,text,type){
  		swal({ title: title, text:  text, icon:  type, buttons: false });
  	},
  	clear_form: function(){
  		form = '#initial_input_form';
   	    $(form).find(':input').not(':button, :submit, :reset, :hidden, :checkbox, :radio, select').val('');
   	    $(form).find(':checkbox, :radio').prop('checked', false);
   	    $('select').prop('selectedIndex',0);
    	
	},
	scroll_to_container: function(id){
  		$('html, body').animate({
           scrollTop: $(id).offset().top
    	}, 2000);
    	
	},
  init: function(){
		self = this;
		$("#get_plans").on("click",self.save_initial_inputs)
		$("#clear_initial_selection_btn").on("click", self.clear_form);
		
	}
}
details_service.init();
});