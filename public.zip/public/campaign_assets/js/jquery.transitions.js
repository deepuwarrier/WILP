$(document).ready(function() {
	transitions = {
        fadeIn: function(element,delay) {
        	$(element).fadeIn(delay).removeClass('campaign-off-display');
        },
        slideLeft: function(element,delay,direction) {
        	$(element).show("slide", { direction: direction }, delay);
        },
        init: function() {
            trans = this;
        }
    }
    transitions.init();
});