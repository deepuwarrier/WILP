function reportFormValidation(){
    var report_form = $('#campaign-report-form');

    //REPORT form validation
    report_form.validate({
        errorClass: "error-class",
        errorPlacement: function(error, element) {
            error.insertAfter(element);   
        },
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
                  return;
                jQuery('html, body').animate({
                  scrollTop: jQuery(validator.errorList[0].element).offset().top-100
            }, 1000);  
        },
        rules: {
            "report_passcode": {
                required: true,
                maxlength: 10,
                minlength: 3,
            },
        },
        messages: {
            "report_passcode": {
                required: 'This field is required',
                maxlength: 'Maximum 10 characters',
                minlength: 'Invalid passcode'

            },
        },
        submitHandler: function(form) {
        }
    });
    //REPORT form validation
}

function otpFormValidation(){
    var otp_form = $('#otp_form');

    //Validation messages
    var MSG_DIGITS_ONLY = 'Only digits are allowed';

    //Validation rules
    var DIGITS_ONLY_SPECIAL_COMBO_ONE = "^[0-9-]+$";

    //OTP form validation
    otp_form.validate({
        errorClass: "error-class",
        errorPlacement: function(error, element) {
            error.insertAfter(element);   
        },
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
                  return;
                jQuery('html, body').animate({
                  scrollTop: jQuery(validator.errorList[0].element).offset().top-100
            }, 1000);  
        },
        rules: {
            "otp": {
                required: true,
                maxlength: 10,
                minlength: 7,
                regex: {
                    reg: DIGITS_ONLY_SPECIAL_COMBO_ONE,
                    msg: MSG_DIGITS_ONLY
                },
            },
        },
        messages: {
            "otp": {
                required: 'This field is required',
                maxlength: 'Maximum 10 characters',
                minlength: 'Invalid OTP',
                digits: 'Only digits are allowed'

            },
        },
        submitHandler: function(form) {
        }
    });
    //OTP form validation
}

function customerModalFormValidation(){
    var form = $('#customer_details_form');
    //Validation messages
    var MSG_ALPHABETS_ONLY = 'Only alphabets are allowed';

    //Validation rules
    var ALPHABETS_ONLY_SPECIAL_COMBO_ONE = "^[a-zA-Z]+$";

    //payment_form form validation
    form.validate({
        errorClass: "error-class",
        errorPlacement: function(error, element) {
            error.insertAfter(element);   
        },
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
                  return;
                jQuery('html, body').animate({
                  scrollTop: jQuery(validator.errorList[0].element).offset().top-100
            }, 1000);  
        },
        rules: {
            "customer_first_name": {
                required: true,
                maxlength: 30,
                regex: {
                    reg: ALPHABETS_ONLY_SPECIAL_COMBO_ONE,
                    msg: MSG_ALPHABETS_ONLY
                },
            },
            "customer_last_name": {
                required: true,
                maxlength: 30,
                regex: {
                    reg: ALPHABETS_ONLY_SPECIAL_COMBO_ONE,
                    msg: MSG_ALPHABETS_ONLY
                },
            },
            "customer_email": {
                required: true,
                email: true
            },
            "customer_mobile": {
                required: true,
                maxlength: 10,
                digits: true
            },
        },
        messages: {
            "customer_first_name": {
                required: 'This field is required',
                maxlength: 'Maximum 30 characters'
            },
            "customer_last_name": {
                required: 'This field is required',
                maxlength: 'Maximum 30 characters'
            },
            "customer_email": {
                required: 'This field is required',
                email: 'Invalid Email ID'
            },
            "customer_mobile": {
                required: 'This field is required',
                maxlength: "Maximum 10 characters",
                digits: "Invalid mobile number"

            },
        },
        submitHandler: function(form) {
        }
    });
    //payment_form form validation

    $.validator.addMethod("regex"
        ,function(value, element, params ) {
            if(typeof params == 'object')
                regexp = params.reg;
            else
                regexp = params;
            var re = new RegExp(regexp);
            return this.optional(element) || re.test(value);
        },
        function(params, element) {
            if(typeof params.msg != 'undefined')
                        return params.msg;
            return 'Invalid Entry';
        }
    );


}

function initPaymentFormValidation(){
    var payment_form = $('#PAYMENT_FORM');
    //payment_form form validation
    payment_form.validate({
        errorClass: "error-class",
        errorPlacement: function(error, element) {
            error.insertAfter(element);   
        },
        invalidHandler: function(form, validator) {
            if (!validator.numberOfInvalids())
                  return;
                jQuery('html, body').animate({
                  scrollTop: jQuery(validator.errorList[0].element).offset().top-100
            }, 1000);  
        },
        ignore: [],
        rules: {
            "payment_option": {
                required: true
            },
        },
        messages: {
            "payment_option": {
                required: 'Please select a payment option'
            },
        },
        submitHandler: function(form) {
        }
    });
    //payment_form form validation

}

function initPEDFormValidation(){
var ped_form = $('#MEDICAL_HISTORY_FORM');
//PED form validation
ped_form.validate({
    errorClass: "error-class",
    errorPlacement: function(error, element) {
             if (element.attr("name") == "disease_member_1" )
                error.insertAfter("."+element.attr("id")+"-errorr");
             else
                error.insertAfter(element);
    },
    invalidHandler: function(form, validator) {
        if (!validator.numberOfInvalids())
              return;
            jQuery('html, body').animate({
              scrollTop: jQuery(validator.errorList[0].element).offset().top-100
        }, 1000);  
    },
    ignore: [],
    rules: {
        "ped_qn": {
            required: true
        },
        "disease_member_0": {
            required: true
        },
    },
    messages: {
        "ped_qn": {
            required: 'Please answer this question to proceed'
        },
        "disease_member_0": {
            required: 'This field is required'
        },
    },
    submitHandler: function(form) {
    }
});
//PED form validation
}

function initAddressFormValidation(){
var address_form = $('#ADDRESS_FORM');

//Validation messages    
var MSG_PINCODE = 'Invalid pincode';
var MSG_STREET = 'Accepted special characters are , & ( ) - /';
var MSG_LOCALITY = 'Accepted special characters are , & ( ) - /';

//Validation rules
var PINCODE = "^[0-9]{6}$";
var STREET = "^([\\d]*[a-zA-Z /,&)(\]*)+$";
var LOCALITY = "^([\\d]*[a-zA-Z /,&)(\]*)+$"; 

//Address form validation
address_form.validate({
    errorClass: "error-class",
    errorPlacement: function(error, element) {
        error.insertAfter(element);   
    },
    invalidHandler: function(form, validator) {
        if (!validator.numberOfInvalids())
              return;
            jQuery('html, body').animate({
              scrollTop: jQuery(validator.errorList[0].element).offset().top-100
        }, 1000);  
    },
    rules: {
        "street": {
            required: true,
            maxlength: 50,
            regex: {
                reg: STREET,
                msg: MSG_STREET
            },
        },
        "locality": {
            maxlength: 50,
            regex: {
                reg: LOCALITY,
                msg: MSG_LOCALITY
            },
        },
        "pincode": {
            required: true,
            regex: {
                reg: PINCODE,
                msg: MSG_PINCODE
            },
        },
        "state": {
            required: true
        },
        "city": {
            required: true
        },
    },
    messages: {
        "city": {
            required: 'This field is required'
        },
        "state": {
            required: 'This field is required'
        },
        "pincode": {
            required: 'This field is required'
        },
        "locality": {
            required: 'This field is required',
            maxlength: 'Maximum 50 characters'
        },
        "street": {
            required: 'This field is required',
            maxlength: 'Maximum 50 characters'
        },
    },
    submitHandler: function(form) {
    }
});
//Address form validation

}



function initInsuredFormValidation(){
var insured_form = $('#INSURED_MEMBERS_FORM');

//Validation messages
var MSG_ALPHABETS_ONLY = 'Only alphabets are allowed';
var MSG_DATE = 'Please enter a valid date';

//Validation rules
var ALPHABETS_ONLY = "^[a-zA-Z]+$";
var ALPHABETS_ONLY_SPECIAL_COMBO_ONE = "^[a-zA-Z ]+$";
var DATE = "^(0[1-9]|1[012])[-/.](0[1-9]|[12][0-9]|3[01])[-/.](19|20)\\d\\d$";

//Insured form validation
insured_form.validate({
    errorClass: "error-class",
    errorPlacement: function(error, element) {
        error.insertAfter(element);   
    },
    invalidHandler: function(form, validator) {
        if (!validator.numberOfInvalids())
              return;
            jQuery('html, body').animate({
              scrollTop: jQuery(validator.errorList[0].element).offset().top-100
        }, 1000);  
    },
    rules: {
    	"firstname[]": {
	        required: true,
	        maxlength: 45,
            regex: {
                reg: ALPHABETS_ONLY,
                msg: MSG_ALPHABETS_ONLY
            },
	    },
        "lastname[]": {
            required: true,
            maxlength: 45,
            regex: {
                reg: ALPHABETS_ONLY,
                msg: MSG_ALPHABETS_ONLY
            },
        },
        "mobile": {
            required: true,
            maxlength: 10,
            digits: true
        },
        "email": {
            required: true,
            email: true
        },
        "height_feet[]":{
            required: true,
            maxlength: 1,
            digits: true,
            minValue: 1,
            maxValue: 8
        },
        "height_inches[]":{
            required: true,
            maxlength: 2,
            digits: true
        },
        "weight[]":{
            required: true,
            maxlength: 3,
            digits: true,
            minValue: 1,
            maxValue: 125
        },
        "dob_list[]":{
            required: true
        },
        "aadhaar_num[]":{
            required: true,
            maxlength: 14,
            minlength: 14,
        },
        "nominee_name":{
            required: true,
            maxlength: 45,
            minlength: 3,
            regex: {
                reg: ALPHABETS_ONLY_SPECIAL_COMBO_ONE,
                msg: MSG_ALPHABETS_ONLY
            },
        },
        "nominee_relation":{
            required: true
        },
    },
    messages: {
    	"firstname[]": {
        	required: 'This field is required',
        	maxlength: "Maximum 45 characters"
        },
        "lastname[]": {
            required: 'This field is required',
            maxlength: "Maximum 45 characters"
        },
        "mobile": {
            required: 'This field is required',
            maxlength: "Maximum 10 characters",
            digits: "Invalid mobile number"
        },
        "email": {
            required: 'This field is required',
            email: "Invalid Email ID"
        },
        "height_feet[]": {
            required: 'This field is required',
            maxlength: "Invalid measurement",
            minValue: "Invalid measurement",
            maxValue: "Invalid measurement",
            digits: "Invalid measurement"
        },
        "height_inches[]": {
            required: 'This field is required',
            maxlength: "Invalid measurement",
            digits: "Invalid measurement"
        },
        "weight[]": {
            required: 'This field is required',
            maxlength: "Invalid weight",
            minValue: "Minimum weight should be 1Kg",
            maxValue: "Maximum weight allowed is 125Kg",
            digits: "Invalid weight"
        },
        "dob_list[]": {
            required: 'This field is required'
        },
        "aadhaar_num[]": {
            required: 'This field is required',
            maxlength: "Invalid aadhaar",
            minlength: "Invalid aadhaar",
        },
        "nominee_name": {
            required: 'This field is required',
            maxlength: "maximum 45 characters",
            minlength: "Minimum 3 characters",
        },
        "nominee_relation": {
            required: 'This field is required'
        },

    },
    submitHandler: function(form) {
    }
});
//Insured form ends validation

$.validator.addMethod("regex"
    ,function(value, element, params ) {
        if(typeof params == 'object')
            regexp = params.reg;
        else
            regexp = params;
        var re = new RegExp(regexp);
        return this.optional(element) || re.test(value);
    },
    function(params, element) {
        if(typeof params.msg != 'undefined')
                    return params.msg;
        return 'Invalid Entry';
    }
);

$.validator.addMethod('minValue', function (value, el, param) {
    return value >= param;
});

$.validator.addMethod('maxValue', function (value, el, param) {
    return value <= param;
});


}
