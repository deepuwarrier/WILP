/*
  Quote service file
*/
service_request = { "_token": $('#_token').val() };
$(document).ready(function(){ 
quote_service = {
	load_hdfc: function(trans_code){
		service_request.trans_code = trans_code;
    service_request.call_type = 'campaign',
    service_url = $('#hdfc_quote_url').val();
    $.ajax({
      type: 'GET',
      url: service_url,
      data: service_request,
      dataType: "json",
      success: function(data){
        $('#quote_searching_container').addClass('campaign-off-display');
        $('#quote_container').removeClass('campaign-off-display');
        setTimeout(function(){ 
          $('#quote_box_loader').remove();
          $('#quote_box_container').append(data.quote_box);
        }, 800);
        //$('#quote_box_loader').remove();
        
      }
    }).fail(function (jqXHR, textStatus, errorThrown) {
         console.log('error');
    });
  },
  alert_box: function(title,text,type){
  		swal({ title: title, text:  text, icon:  type, buttons: false });
  },
  init: function(){
		self = this;
	}
}
quote_service.init();
});