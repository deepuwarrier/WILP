$(document).ready(function() {
    formWidget = {
        load_basic: function() {
            present_widget = $('.widget_parent div:first-child');
            next_widget = present_widget.next();
            widget_id = next_widget.attr('id');
            ul_id = present_widget.attr('id') + "_";
            $('#' + ul_id).parent('li').addClass('active').siblings().removeClass('active');
            button_name = widget_id.replace(/_/, " ");
            $('#proceed_next').html("PROCEED TO " + button_name);
            $('.sticky_footer').hide();
            $(window).scroll(function() {
                var top = $(window).scrollTop() / 2
                bottom = $('#widget_insurance').position().top + $('#widget_insurance').height();
                if (($(window).scrollTop() >= $('#widget_insurance').position().top - 400) && ($(window).scrollTop() <= bottom - 600))
                    $('.sticky_footer').show();
                else {
                    $('.sticky_footer').hide();
                }
            });
        },
        check_otp_status: function(mobile_num) {
            service_url = $('#mobile').attr('otp-status-url');
            otp_status_request.mobile = mobile_num;
            $.ajax({
                type: 'GET',
                url: service_url,
                data: otp_status_request,
                dataType: "json",
                success: function(data) {
                    $('#INSURED_MEMBERS_FORM').loading('stop');
                    if ((data.status == true) && (data.attempt_otp == true)) {
                        $('#otp_attempts_text').html(data.attempts);
                        widget.trigger_otp(mobile);
                    } else if ((data.status == true) && (data.attempt_otp == false)) {
                        widget.widget_next();
                    } else {
                        helper.restict_user(data.msg);
                    }
                }
            }).fail(function(jqXHR, textStatus, errorThrown) {
                return false;
                console.log('error');
            });
        },
        trigger_otp: function(mobile_num) {
            $('#otp_modal').modal('show');
        },
        widget_next: function() {
            $('.widget_ch').each(function() {
                if ($(this).is(':visible')) {
                    present_widget = $(this).next();
                    return false;
                }
            })
            present_widget.show().siblings().hide();
            ul_id = present_widget.attr('id') + "_";
            $('#' + ul_id).parent('li').addClass('active').siblings().removeClass('active');
            if (present_widget.next().attr('id')) {
                button_name = present_widget.next().attr('id');
                button_name = button_name.replace(/_/, " ");
                $('#proceed_next').html("PROCEED TO " + button_name);
                $('#back').css('visibility', 'visible')
            } else {
                $('#proceed_next').css('visibility', 'hidden')
            }
        },
        proceed_next: function() {
            var tab_id = $("#widget_ul li.active a").attr('id');
            var status = $('#' + tab_id + 'FORM').valid();
            if (status) {
                helper.save_proposal_data(tab_id);
                if (tab_id + 'FORM' == 'INSURED_MEMBERS_FORM') {
                    $('#INSURED_MEMBERS_FORM').loading({
                        message: 'Verifying mobile number'
                    });
                    var mobile = $('#mobile').val();
                    widget.check_otp_status(mobile)
                } else if (tab_id + 'FORM' == 'MEDICAL_HISTORY_FORM') {
                    var choice = $('#ped_qn').val();
                    if(choice == 'y'){
                        helper.check_ped_form();
                    }else{
                        widget.widget_next();
                    }
                }else {
                    widget.widget_next();
                }
            }
        },
        widget_back: function() {
            $('.widget_ch').each(function() {
                if ($(this).is(':visible')) {
                    present_widget = $(this).prev();

                    return false;
                }
            })
            present_widget.show().siblings().hide();
            ul_id = present_widget.attr('id') + "_";
            $('#' + ul_id).parent('li').addClass('active').siblings().removeClass('active');
            if (present_widget.prev().attr('id') == undefined) {

                $('#back').css('visibility', 'hidden')
            } else {

                $('#back').css('visibility', 'visible')
            }
            button_name = present_widget.next().attr('id');
            // button_name=(button_name);
            button_name = button_name.replace(/_/, " ");
            $('#proceed_next').html("PROCEED TO " + button_name);
            $('#proceed_next').css('visibility', 'visible')
        },
        init: function() {
            widget = this;
            widget.load_basic()
            $("#back").on("click", widget.widget_back)
            $("#proceed_next").on("click", widget.proceed_next)
        }
    }
    formWidget.init();
});