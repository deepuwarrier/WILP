$(document).ready(function() {
	$.ajax({
		url:'graph/bar_graph',
		type:'GET',
		success:function(data){
			var ctx = document.getElementById("curr_mon_data");
			var myPieChart = new Chart(ctx,{
			    type: 'bar',
			    data: {
			        labels: data.bar.labels,
			        datasets: [{
			        	label: '# of Policies',
			            data: data.bar.value,
				            backgroundColor: [
			            		'#d9ffb3',	
				                '#80D4FF',
				                '#CC99FF',
				                '#00e6ac',
				            ]
			        }],
			    },
			     options : {
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero: true,
                 userCallback: function(label, index, labels) {
                     // when the floored value is the same as the value we have a whole number
                     if (Math.floor(label) === label) {
                         return label;
                     }

                 },
             }
         }],
     },
 }
			});

			var ctx2 = document.getElementById("curr_mon_ins_share");
			var myPieChart = new Chart(ctx2,{
			    type: 'pie',
			    data: {
			       	labels: data.pie.labels,
			        datasets: [{
			            label: '# of Votes',
			            data: data.pie.value,
				            backgroundColor: [
				            	'#d9ffb3',	
				                '#80D4FF',
				                '#CC99FF',
				                 '#00e6ac',
				                 '#ffffb3',
				                 '#ffebcc',
				            ],
				            borderColor: [
				                '#FFFFFF'
				            ],
				            borderWidth: 1
			        }]
			    }
			});
		}
	});
});