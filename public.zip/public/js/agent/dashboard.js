
function load_active_leads()
	$.get("/tw/city_by_state", {  state_code : $( "#state" ).val() 	}, function(data, status) {   
	$("#city").html(data); 
//		common.loader_rem(); 
});


