function commaSeparateNumber(val){
    while (/(\d+)(\d{3})/.test(val.toString())){
      val = val.toString().replace(/(\d+)(\d{3})/, '$1'+','+'$2');
    }
    return val;
}


function loader_msg(a) {
            $("#overlay").html("<span class='msg'>" + a + "<span>"), $("#overlay").fadeIn(), $("#overlay").css("opacity", 1), $("#overlay").append('<div class="loader">Loading...</div>')
        }
function overlay_msg(a) {
            $("#overlay").html("<span class='msg'>" + a + "<span>"), $("#overlay").fadeIn(), $("#overlay").css("opacity", 1);
}
function loader_rem() {
            $("#overlay").empty(), $("#overlay").fadeOut();
        }
        
          $(function () {
        $('.modal').on('hidden.bs.modal', function () {
            $(this).find('form')[0].reset();
        });
        });

function insertDataQuery(_url, _postData, callbackFunction, type, preprocess)
{
       
    
    if (type == null)
    {
        type = "html";
    }
    if (preprocess == null)
    {

    }
    $.ajax({type: "POST", url: _url, data: _postData, beforeSend: preprocess, dataType: type,
        success: function (_returnData)
        {
            parseResult(callbackFunction, _returnData);
        },
        error: function (error)
        {

            console.log(error.responseText);
        },
        beforeSend: function () {

        },
        complete: function () {

        }
    });
}

function parseResult(callbackFunction, _returnData)
{
    callbackFunction(_returnData);
}


 $("#emailthis_form").validate({
        rules: {
            email: {
                required: true,
                email:true
            },
        },
        messages: {
            email: {
                required: "Please enter your E-mail Address",
                email: "Please enter your valid email Address",
            },
        },
        errorClass: "my-error-class"
    });


function send_email() {
   if($("#emailthis_form").valid()){
        loader_msg("Processing....");
        var data = $("#emailthis_form").serialize();
        var url = '/calc-send-email';
        var success = function (data) {
            if (data['result'] == 'success') {
                $("#emailthis_modal").modal('hide');
                loader_rem();
            } 
             $("#emailthis_modal").modal('hide');
            loader_rem();
        };
        insertDataQuery(url, data, success, 'json', null);
            
    }
}


function add_product() {
    var product_id = $("#product_id").val();
    var product_value = $("#product_value").val();
    var token = $('input[name="_token"]').val();
    if (product_id != '' && product_value != '') {
        var data = {product_id: product_id, product_value: product_value, _token: token};
        var url = '/calc-add-products';
        var success = function (data) {
            if (data['result'] == 'success') {
                $("#calc_list").html(data['html_view']);
                $("#budget_total_value").html(commaSeparateNumber(Math.ceil(data['total_value'])));
                $("#budget_insure_value").html(commaSeparateNumber(Math.ceil(data['insure_value'])));
                $("#product_id").val($("#product_id option:first").val());
                $("#product_value").val('');
            } 
        };
        insertDataQuery(url, data, success, 'json', null);
    }
}


function remove_product(id,value) {
    var product_id = id;
    var product_value = value;
    var token = $('input[name="_token"]').val();
    if (product_id != '' && product_value != '') {
        var data = {product_id: product_id, product_value: product_value, _token: token};
        var url = '/calc-remove-products';
        var success = function (data) {
            if (data['result'] == 'success') {
                $("#calc_list").html(data['html_view']);
                $("#budget_total_value").html(commaSeparateNumber(Math.ceil(data['total_value'])));
                $("#budget_insure_value").html(commaSeparateNumber(Math.ceil(data['insure_value'])));
            } 
        };
        insertDataQuery(url, data, success, 'json', null);
    }
}
