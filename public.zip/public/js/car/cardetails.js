$(document).ready(function() {
    CarDetail = {
        __proto__: common,
        template : {model:".tpl-model",variant:".tpl-variant"},
        self: this,
        rto_code: 0,
        make_selector: ".make",
        model_selector: ".model",
        fuel: ".fuel",
        state_code_container_selector: "#state_code_container",
        rto_num_container_selector: "#rto_num_container",
        model_container_sel: "#model-container",
        variant_container_sel: "#variant-container",
        active_make_selector: ".make.active",
        active_model_selector: ".model.active",
        active_state_selector: ".state.active",
        active_variant_selector: ".variant.active",
        active_year_selector: ".year.active",
        rto_input: "#rto_input",
        rto_obj: "",
        model_updated: 0,
        variant_updated: 0,
        clickRto: function() {
            console.log(self.rto_obj),
            self.rto_obj =  $.parseJSON(self.getCookie("rto_list")),
            console.log("Object of rto not set"),
            console.log(self.rto_obj),
            "" != $(".screen").text() ? (self.rto_code = $(".state.active").attr("data-state_code"), self.selected_rto = self.rto_code + $(".screen").text(), rto_array = self.selected_rto.match(/.{1,2}/g), 1 == rto_array[1].length && (self.selected_rto = rto_array[0] + 0 + rto_array[1]), self.validateRto(self.selected_rto) ? ($(self.rto_input).val(self.selected_rto), $(".wizard-card").bootstrapWizard("next")) : (self.showCommonMessage("Please Enter a Valid RTO Code. Eg: DL01"), $(".screen").text(""), $(".wizard-card").bootstrapWizard("previous"))) : (self.showCommonMessage("Please Enter Your RTO Code Eg: DL01"), $(".wizard-card").bootstrapWizard("previous")), $(document).scrollTop(0)
            self.ajaxPostRequest('/set-car-details',$('#car-detail').serialize()+"&_token=" + self.token.val(),function(){
                alert('success');
            })
        },
        clickYear: function() {
            msg = "", $.each($("#car-detail :input.required"), function(a, b) {
                "" == $(this).val() && (msg += "Select " + $(this).attr("name") + "<br/>")
            }), "" == msg ? (self.loader_msg(self.msg.fetch_quote), $("#car-detail").submit()) : self.showCommonMessage(msg)
        },
        clickModel: function() {
            self.variant_updated = 1,self.variant_container.empty(), self.model_code = $(this).attr("id"), $(self.fuel).removeClass("active"), 1 == self.model_updated && (self.model_updated = 0, self.moveWizardManually())
        },
        clickMake: function() {
            self.model_updated = 1, self.model_container.empty(), self.addLoader(self.model_container_sel), self.make = $(this).attr("id"), url = self.make_container.attr("data-url"), data = "_token=" + self.token.val() + "&make=" + self.make, self.ajaxPostRequest(url, data, self.updateModels),$(self.active_model_selector).removeClass("active"),$(self.active_state_selector).removeClass("active"),$(self.active_variant_selector).removeClass("active"),$(self.active_year_selector).removeClass("active"), $("#model_input").val(''),$("#fuel_input").val(''),$("#state_input").val(''),$("#rto_input").val(''),$("#year_input").val(''),$("#variant_input").val(''),$("#make_name").val(''),$("#model_name").val(''),$("#state_name").val(''),$("#variant_name").val('')
        },
        clickFuel: function() {
            self.fuel_type = $(this).val(), self.model_code = self.getModelId(), "" != self.model_code && "undefined" != typeof self.model_code ? (self.variant_container.empty(), self.addLoader(self.variant_container_sel), $("#fuel_input").val(self.fuel_type), "petrol" == self.fuel_type.toLowerCase() ? self.variant_type = "P" : "diesel" == self.fuel_type.toLowerCase() ? self.variant_type = "D" : self.variant_type = "CNG", url = self.variant_container.attr("data-url"), data = "_token=" + self.token.val() + "&variant_type=" + self.variant_type + "&model_code=" + self.model_code, self.ajaxPostRequest(url, data, self.updateVariant)) : (self.showCommonMessage("Please Select Your Model"), $(".wizard-card").bootstrapWizard("previous"), $(".wizard-card").bootstrapWizard("previous"))
        },
        clickVariant: function(){
             1 == self.variant_updated && (self.variant_updated = 0, self.moveWizardManually());
        },
        clickState: function() {
            state_id = $(this).attr("id"),
                    url = self.state_container.attr("data-url"),
                    data = "_token=" + self.token.val() + "&state_id=" + state_id, self.ajaxPostRequest(url, data, self.updateRto),
                    rto_code = $(this).attr("data-state_code"), 
                    self.rto_container.attr("id", rto_code), 
                    $(self.rto_num_container_selector).empty(),
                    $(self.rto_input).val(""),
                    $(self.state_code_container_selector).text(rto_code)
        },
        clickCarButton: function() {
            $(this).siblings().removeClass("active"), $(this).addClass("active"), self.setFormValue()
        },
        validateRto: function(a) {
            return self.status = !1, $.each(self.rto_obj, function(b, c) {
                c.rto_code == a && (self.status = !0)
            }), self.status
        },
        updateModels: function(a) {
        	str = $(self.template.model)[0].outerHTML
            self.model_container.trigger("update_container"), ccntidx = 0, $(a).each(function(a, b) {
                ccntidx += 1, 
                html = self.replaceTpl(str,{'{id}':b.model_code,'{val}':b.model_name}),
				9 == ccntidx && (html += "<hr>"),
                self.model_container.append(html)
            })
        },
        updateRto: function(a) {
            self.setCookie("rto_list",JSON.stringify(a),1);
            self.rto_obj = a
        },
        updateVariant: function(a) {
        	str = $(self.template.variant)[0].outerHTML
            return self.variant_container.trigger("update_container"), 0 == a.variants.length ? (self.showCommonMessage("Sorry, we did not find a variant for the selected FUEL TYPE, Try selecting a different fuel type."), $(".wizard-card").bootstrapWizard("previous"), !0) : void $(a.variants).each(function(a, b) {
                html = self.replaceTpl(str,{'{id}':b.variant_code,'{val}':b.variant_name}),
                self.variant_container.append(html)
            })
        },
        updateContainer: function() {
            $(this).empty()
        },
        getModelId: function() {
            return $(self.active_model_selector).attr("id")
        },
        resetFormValue:function(){
            $(self.active_model_selector).removeClass("active"),$(self.active_state_selector).removeClass("active"),$(self.active_variant_selector).removeClass("active"),$(self.active_year_selector).removeClass("active"),$("#model_input").val(''),$("#fuel_input").val(''),$("#state_input").val(''),$("#rto_input").val(''),$("#year_input").val(''),$("#variant_input").val(''),$("#model_name").val(''),$("#state_name").val(''),$("#variant_name").val(''),self.ajaxPostRequest('/set-car-details',$('#car-detail').serialize()+"&_token=" + self.token.val(),function(){$("#make_input").val(''),$("#make_name").val('');})
        }
        ,
        setFormValue: function() {
            make = $(self.active_make_selector).attr("id"),model_code = $(self.active_model_selector).attr("id"),state_id = $(self.active_state_selector).attr("id"),variant = $(self.active_variant_selector).attr("id"),year = $(self.active_year_selector).attr("id"), $("#make_input").val(make),$("#model_input").val(model_code),$("#state_input").val(state_id),$("#year_input").val(year),$("#variant_input").val(variant),$("#make_name").val($(self.active_make_selector).val()),$("#model_name").val($(self.active_model_selector).val()),$("#state_name").val($(self.active_state_selector).text()),$("#variant_name").val($(self.active_variant_selector).val()),self.ajaxPostRequest('/set-car-details',$('#car-detail').serialize()+"&_token=" + self.token.val(),function(){});
        },
        showCommonMessage: function(a) {
            swal(a)
        },
        ajaxPostRequest: function(a, b, c) {
            $.ajax({
                type: "POST",
                url: a,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a)
            })
        },
        moveWizardManually: function() {
            $(".wizard-card").bootstrapWizard("next")
        },
        addLoader: function(a) {
            self.loader(a)
        },
        init: function() {
            self = this, self.model_container = $("#model-container"), 
                    self.variant_container = $("#variant-container"),
                    self.state_container = $("#state-container"), 
                    self.make_container = $("#make-container"),
                    self.rto_container = $("#rto .tab-content"),
                    self.token = $("#_token"), $(document).on("click", ".year,.variant,.rto,.state,.model,.make,.fuel", this.clickCarButton),
                    $(document).on("click", ".year,.state", this.moveWizardManually),
                    $(document).on("click", ".rto-btn", this.clickRto),
                    $(document).on("click", ".year", this.clickYear),
                    $(document).on("click", "#make_tab", this.resetFormValue),
                    $(document).on("click", this.make_selector, this.clickMake),
                    $(document).on("click", this.model_selector, this.clickModel), 
                    $(document).on("click", this.fuel, this.clickFuel), 
                    $(document).on("click", ".state", this.clickState),
                    $(document).on("click", ".variant", this.clickVariant),
                    
                    $("" + self.model_container_sel + "," + self.variant_container_sel).on("update_container", self.updateContainer)
            
        }
    }, CarDetail.init(), demo.initMaterialWizard()
});
