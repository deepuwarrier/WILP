var hdfc_url = "/car-insurance/hdfc_quote";
var uiic_url = "/car-insurance/uiic_quote";
var rs_url = "/car-insurance/carrsgiquote";
var tata_url = "/car-insurance/tata_quote";
var bajaj_url = '/car-insurance/bajaj_quote';
var reliance_url = '/car-insurance/reliance_quote';
var total_a = 5;
var total_a_call = 0;
var policy_quote_cnt = "#reliance_quote_ctnr_box,#bajaj_quote_ctnr_box,#tata_quote_ctnr_box,#hdfc_quote_ctnr_box,#quote_ctnr_box,#hdfc_quote_ctnr_box,#rsgi_quote_ctnr_box,#uiic_quote_ctnr_box";

var uiic_ajax,
    hdfc_ajax,
    bajaj_ajax,
    rsgi_ajax,
    tata_ajax,
    reli_ajax;

$(window).bind('beforeunload',function(){
    console.log("window 2");
    abortQuoteAjax();
});

function abortQuoteAjax(){
    //tata_ajax.abort();  
    reli_ajax.abort();
    rsgi_ajax.abort();
    bajaj_ajax.abort();
    hdfc_ajax.abort();
    uiic_ajax.abort();
}

function callQuoteApi(){
    common.initQuote();
    load_uiic_quote(uiic_url);
    load_hdfc_quote(hdfc_url);
    rs_quotes(rs_url);
    //load_bajaj_quote(bajaj_url);
    load_reliance_quote(reliance_url);
    //tata_quotes(tata_url);  
}

function getTransCode(){
    return $('#trans_code').val();
}
$(document).ready(function($) {
    $(document).on('click','#yes_prevaddon',function(){
        common.overlay_rem();
        $('html,body').animate({scrollTop: $("#car_details").offset().top},'slow');
        confirmIDV()
    });
    $(document).on('click','#no_prevaddon',function(){
        common.overlay_rem();
    });

    $(document).on("click",'.save_premium_breakup',function(event){
        event.preventDefault();
        form_element = $(this).parents(".quote-box").find('form').html();
        genrate_pdf(form_element,'quote_premium_breakup');    
    }); 

    $(document).on("click",'.quote_package_info',function(event){
        event.preventDefault();
        form_element = $(this).parents(".quote-box").find('form').html();
        genrate_pdf(form_element,'quote_package_info');    
    });

    function genrate_pdf(form_element,$pdf_type){
        $("#save_pdf").html(form_element);
        $("#save_pdf").append("<input type='hidden' name='pdf_type' value='"+$pdf_type+"'>");
        $("#save_pdf").submit();
    }

    

    //updateQuoteURL'onChangeProposalSection','false')
    $(policy_quote_cnt).empty();
    common.loader_msg("Getting Quotes Please Wait....");
    setTimeout(function(){
        $('#btn_div_skip').remove();
        unfocusIdv();
        callQuoteApi();        
        sort_div()
    }, 500);

    $(document).on("click",".modal_details",function(){
        id = $(this).data('modal');
        $('#'+id).modal();
    });
});

$( document ).ajaxStop(function() {
  $('#update_idv').removeAttr('disabled');
  $('.modal_details').removeAttr('disabled');
});

function get_token(){
    return $("input[name=_token]").val();
}

function get_session(){
    return $("#session_id").val();
}

function add_simple_loader(selector){
    $(selector).append('<div class="loader blue">Loading...</div>')
}

function remove_simple_loader(selector){
    $(selector).html('');
}

function load_bajaj_quote(bajaj_url){
    total_a_call++;
    $("#bajaj_quote_ctnr_box").html('');
    token = get_token();
    var session_id =  get_session();
    add_simple_loader('#bajaj_loader');
    bajaj_ajax = $.ajax({ 
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: bajaj_url,
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize(),
        type: "POST",
        success: function(data) {
            data = $.trim(data);
            var response_value = $.trim(data.response_value);
            if((data.reload != 'true') && (data != '') ){
                if($('#error_message').length>0){
                    $('#error_message').html('');
                }
                $('#email_quotes_div').show();
                $("#bajaj_quote_ctnr_box").html(data);
                $("#error_message").html('');
                //$("#quote_ctnr_box").html('');
            }else{
                common.addNoQuotes('bajaj_logo.png','Bajaj Allianz GI');
            }
        } 
    }).always(function(){
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        remove_simple_loader('#bajaj_loader');
    });
}

function load_reliance_quote(reliance_url){
    total_a_call++;
    $("#reliance_quote_ctnr_box").html('');
    token = get_token();
    var session_id =  get_session();
    add_simple_loader('#reliance_loader');
    reli_ajax = $.ajax({ 
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: reliance_url,
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize(),
        type: "POST",
        success: function(data) {
            data = $.trim(data);
            var response_value = $.trim(data.response_value);
           if((data.reload != 'true') && (data != '') ){
                if($('#error_message').length>0){
                    $('#error_message').html('');
                }
                $('#email_quotes_div').show();
                $("#reliance_quote_ctnr_box").html(data);
                $("#error_message").html('');
                //$("#quote_ctnr_box").html('');
            }else{
                common.addNoQuotes('reliance_logo.png','Reliance GI');
            }
        } 
    }).always(function(){
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        remove_simple_loader('#reliance_loader');
    });
}

function load_hdfc_quote(hdfc_url){
    total_a_call++;
    $("#hdfc_quote_ctnr_box").html('');
    token = get_token();
    var session_id =  get_session();
    add_simple_loader('#hdfc_loader');
    hdfc_ajax = $.ajax({ 
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: hdfc_url,
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize(),
        type: "POST",
        success: function(data) {
            data = $.trim(data);
            var response_value = $.trim(data.response_value);
           if((data.reload != 'true') && (data != '') ){
                if($('#error_message').length>0){
                    $('#error_message').html('');
                }
                $('#email_quotes_div').show();
                $("#hdfc_quote_ctnr_box").html(data);
                $("#error_message").html('');
                //$("#quote_ctnr_box").html('');
            }else{
                common.addNoQuotes('hdfc_logo.png','HDFC ERGO GI');
            }
            //$('#btn_div_skip').remove();
            sort_div();
        } 
    }).always(function(){
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        remove_simple_loader('#hdfc_loader');
    });

}

function load_uiic_quote(uiic_url){
    total_a_call++;
    $("#uiic_quote_ctnr_box").html('');
    token = get_token();
    var session_id =  get_session();
    add_simple_loader('#uiic_loader');
     uiic_ajax = $.ajax({ 
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: uiic_url,
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize(),
        type: "POST",
        success: function(data) {
           if(data.reload != 'true' && data != ""){
                if($('#error_message').length>0){
                    $('#error_message').html('');
                }
                $(".last-decimal").remove();
                $("#uiic_quote_ctnr_box").html(data);
                $('#email_quotes_div').show();
                $("#error_message").html('');
                //$("#quote_ctnr_box").html('');
            }else{
                common.addNoQuotes('uiicgi_logo.png','United India Insurance GI');
            }
            display_no_quote_msg();
            //$('#btn_div_skip').remove();
                sort_div();
            } 

    }).always(function(){
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        remove_simple_loader('#uiic_loader');
    });

}

function tata_quotes(url){
    total_a_call++;
    $("#tata_loader").html('<div class="loader blue">Loading...</div>')
    var a = getchks();
    token = $("input[name=_token]").val();
    tata_ajax = $.ajax({
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: url,
        type: "POST",
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize()+'&chks='+a,
        success: function(t) {
            t = $.trim(t);
            if(t.url_reloaded == 'true'){ unsetChks();}
            if((t != "") && ($('#error_message').length>0 && t.error != 'true')){
                $('#email_quotes_div').show();
                $("#error_message").html('');
		//$("#quote_ctnr_box").html('');
                $("#tata_quote_ctnr_box").html(t);
            }else{
                common.addNoQuotes('tata_logo.png','TATA AIG GI');
            }
        }
    }).always(function() {
        display_no_quote_msg()
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        sort_div();
        $("#tata_loader").html('');
    })
}

function display_no_quote_msg(){

    if(total_a == total_a_call){
        total_a_call = 0;
        if(($('#uiic_quote_ctnr_box .customcard').length == 0) && ($('#rsgi_quote_ctnr_box .customcard').length == 0) && ($('#hdfc_quote_ctnr_box .customcard').length == 0) && ($('#tata_quote_ctnr_box .customcard').length == 0) && ($('#bajaj_quote_ctnr_box .customcard').length == 0) && ($('#reliance_quote_ctnr_box .customcard').length == 0)){
            $('#email_quotes_div').hide();
            $("#error_message").removeClass('hide');
            var new_error = '<h5 class="card-title price">Thank you for your patience, but we do not have a quote for the combination you have selected, please try another combination.</h5>';
            $("#error_message").html(new_error);
        }

    }
}

function load_last_decimal_api(){   
    total_a_call++;   
    token = $("input[name=_token]").val(); 
    //$("#quote_ctnr_box .customcard").append("<span class='last-decimal' style='background:rgba(0,0,0,0.5);position:absolute;left:0px;top:0px;width:100%;height:100%'></span>");
   $("#last_decimal_loader").html('<div class="loader blue">Loading...</div>')
    var session_id =  $("#session_id").val(); 
    var a = getchks();
    $.ajax({ 
        headers: {
            "X-CSRF-TOKEN": token
        },
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize()+'&chks='+a,
        url: "/car-insurance/api/lastdecimal",
        type: "POST",
        success: function(data) {
            data = $.trim(data);
            if((data.reload != 'true') && (data !='')){
                if($('#error_message').length>0){
                    $('#error_message').html('');
                }
                $(".last-decimal").remove();
                if(data.url_reloaded == 'true'){ unsetChks();}
                $('#email_quotes_div').show();
                $("#error_message").html('');
		//$("#quote_ctnr_box").html('');
                $("#last_decimal_quote_ctnr_box").html(data);
            }
        } 
    }).always(function() {
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        $("#last_decimal_loader").html('');
    })
}

function rs_quotes(url) {
    total_a_call++;
   $("#rs_loader").html('<div class="loader blue">Loading...</div>')
    var policy_expiry_date = $("#policy_expiry_date").val();
    var car_registration_date = $("#car_registration_date").val();
    var claim_status = $('#reg_summary input[type=radio]:checked').val();
    var current_ncb = $("#current_ncb").val();
    var eli_ncb = $("#new_ncb").val();    
    var session_id =  $("#session_id").val();
    var a = getchks();
    token = $("input[name=_token]").val();
    rsgi_ajax = $.ajax({
        headers: {
            "X-CSRF-TOKEN": token
        },
        url: url,
        type: "POST",
        data: $("#update_quote").find('input').filter('.ajaxRequiredData').serialize()+'&chks='+a,
        success: function(t) {
            t = $.trim(t);
            if(t.url_reloaded == 'true'){ unsetChks();}
            if($('#error_message').length>0 && t.error != 'true' && (t != '')){
                $('#email_quotes_div').show();
                $("#error_message").html('');
		//$("#quote_ctnr_box").html('');
                $("#rsgi_quote_ctnr_box").html(t);
            }else{
                common.addNoQuotes('rsgi_logo.png','Royal Sundaram GI');
            }
        }
    }).always(function() {
        if($('#btn_div_skip').length == 0)
            common.loader_rem();
        display_no_quote_msg();
        sort_div();
        $("#rs_loader").html('');
    })
}

function sort_div(){
    // var divList = $(".card.customcard");
    var divList = $(".quote-box");
    divList.sort(function(a, b){ 
        return $(a).data("listing-price")-$(b).data("listing-price")
    });
    $("#quote_ctnr_box").html(divList);
}

function update_quote_page_dates() {
    $.ajax({
        url: "/car-insurance/getquote/defaultvalue",
        dataType: "json",
        type: "GET",
        success: function(t) {
            var e = t.carregistration_diff,
                a = t.policyenddate_diff,
                n = t.policystartdate_diff;
            registration_date(t, e), p_expiry_date(t, a), p_start_date(t, n)
        }
    })
}

function car_registation_date_formate(t) {
    var e = new Date,
        a = (e.getDate(), e.getMonth(), e.setFullYear(parseInt(t)), new Date(e));
    return a
}

function registration_date(t, e) {
    var a = $("#car_registration_date").attr("data-minYear"),
        n = $("#car_registration_date").attr("data-maxYear");
    $("#car_registration_date").datepicker({
        dateFormat: "dd/mm/yy",
        changeMonth: !0,
        changeYear: !0,
        minDate: a,
        maxDate: n
    })
}

function p_expiry_date(t, e) {
    $("#policy_expiry_date").datepicker({
        dateFormat: "dd/mm/yy",
        changeMonth: !0,
        changeYear: !0,
        minDate: t.policy_exp_min_days,
        maxDate: t.policy_exp_max_days
    })
}

function p_start_date(t, e) {
    $("#policy_start_date").datepicker({
        dateFormat: "dd/mm/yy",
        changeMonth: !0,
        changeYear: !0,
        minDate: t.policy_start_min_days,
        maxDate: t.policy_start_max_days
    })
}

function getIdvFormValues() {
    policy_expiry_date = $obj_policy_expiry_date.val(), car_registration_date = $obj_car_registration_date.val(), claims_no = $obj_claims_no.val(), current_ncb = $obj_current_ncb.val(), qty = $obj_qty.val()
}

function onChangeFormValue() {
    $(back_to_quotes).remove()
    if(!$("#update_idv").length){
        $update_btn = '<button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_idv">Update Quotes<div class="ripple-container"></div></button>';
        $obj_idv_footer.append($update_btn);      
    }
    if($("#btn-idv-accurate").length){
        $("#btn-idv-accurate").remove();
    }
    $(selector_skip_btn).length < 1 && (focusIdv(), $obj_idv_footer.append(idv_skip_btn))
}

function unfocusIdv() {
    $("#overlay").fadeOut(), $obj_idv.css("z-index", "1029")
}

function focusIdv() {
    $("#overlay").fadeIn(), $obj_idv.css("z-index", "1032")
}

function confirmIDV() {
    focusIdv(),
    //$obj_idv.addClass("unclickable"), 
    //$obj_idv_footer.addClass("clickable"),
     idv_footer = $obj_idv_footer.html(), 
    $obj_idv_footer.empty(), 
    $obj_idv_footer.append(idv_footer_btn)
}


function getchks() {
    var t = "";
    return $(".filter_quote").each(function() {
        if (this.checked) {
            var e = $(this).val();
            "OD" != e && "TP" != e && (t += e + ",")
        }
    }), t = $.trim(t)
}
$(document).ready(function() {
    update_quote_page_dates(), getIdvFormValues(), altair_tour = {
        init: function() {
            var t = new EnjoyHint({}),
                e = [{
                    "next #car_details": 'Check the details of your car here.<br>Click "Next" to proceed.'
                }, {
                    "next #idv": "Select the Current Value of your Car here.",
                    showSkip: !1
                }, {
                    "next #reg_summary": "Enter some mandatory information<br>about your Car to get the<br> most accurate quote!",
                    showSkip: !1
                }, {
                    "next #covers_summary_details": "Customize your Insurance<br>product by selecting <br>additional covers",
                    showSkip: !1
                }, {
                    "key .insurance-list": "See the quotes from different<br> Insurance companies here.<br>",
                    skipButton: {
                        text: "Finish"
                    }
                }];
            t.set(e), t.run(), $("#carwizard").click(function() {
                t.run()
            })
        }
    }
}), msg = {
    update_quote: "Thank you for your patience! Please wait while we get the best quotes for you."
};
var value_diff_idv = 1;
$(".qtyplus").click(function(t) {
    t.preventDefault(), fieldName = $(this).attr("field");
    var e = parseInt($("input[name=" + fieldName + "]").val()),
        a = e * value_diff_idv / 100;
    isNaN(e) ? $("input[name=" + fieldName + "]").val(0) : $("input[name=" + fieldName + "]").val(Math.round(e + a))
}), 
$("#reset_idv").click(function(t) {
    var e = $("#ex_showroom_car_price").val(),
        a = $("#year").val(),
        n = car_registation_date_formate(a),
        o = $.datepicker.formatDate("yy/mm/dd", n),
        m = get_session();
    token = $("input[name=_token]").val(), $.ajax({
        url: "/car-insurance/getquote/reset_idv",
        headers: {
            "X-CSRF-TOKEN": token
        },
        data: {
            car_price: e,
            year: o,
            call: "ajax",
            trans_code:m,
        },
        dataType: "json",
        type: "POST",
        success: function(t) {
            var e = parseInt(t);
            $("#quantity").val(e)
        }
    })
}), 
$(".qtyminus").click(function(t) {
    t.preventDefault(), fieldName = $(this).attr("field");
    var e = parseInt($("input[name=" + fieldName + "]").val()),
        a = e * value_diff_idv / 100;
    !isNaN(e) && e > 0 ? $("input[name=" + fieldName + "]").val(Math.round(e - a)) : $("input[name=" + fieldName + "]").val(0)
}), 
$("#current_ncb").change(function(t) {
    $('#update_idv').attr('disabled','disabled');
    token = $("input[name=_token]").val();
    var e = $("#typeofbusines").val(),
        a = $("#current_ncb").val();
    $.ajax({
        url: "/car-insurance/getquote/check_ncb",
        headers: {
            "X-CSRF-TOKEN": token
        },
        data: {
            typeofbussiness: e,
            ncb: a,
            call: "ajax"
        },
        dataType: "json",
        type: "POST",
        success: function(t) {
            var e = parseInt(t);
            $("#new_ncb_span").html(e + "%"), $("#ncb").val(a), $("#new_ncb").val(e)
        }
    }).always(function(){
        $('#update_idv').removeAttr('disabled');
    })
}),url = window.location.href, 
$(".filter_quote").change(function(t) {
    
   abortQuoteAjax();
    $(policy_quote_cnt).empty();
    id = $(this).attr('id');
    common.loader_msg(common.msg.updated_quote), 
    token = $("input[name=_token]").val();
    trans_code = getTransCode();
    var e = getchks();
    
    // $("#quote_ctnr_box").html("Thank you for your patience! Please wait while we get the best quotes for you..."), 
    $.ajax({
        url: '/car-insurance/quote/'+trans_code+'/getfilterquote',
        headers: {
            "X-CSRF-TOKEN": token
        },
        type: "GET",
        data: {
            chks: e,
            trans_code:trans_code
        },
        success: function(t) {
            callQuoteApi();
        },
        complete: common.loader_rem
    }).always(function() {
        display_no_quote_msg()
        if($('#btn_div_skip').length == 0)
        common.loader_rem();
        sort_div();
    })
    
})


$('input[name ="expiry_status"]').change(function(){
    var k = $(this).val();
    isDisplayExpDays(k);    
});

$("#expiry_day").change(function(){
    var k = $(this).val();
    isPrevPolicyExpDateVisible(k);
})

function isPrevPolicyExpDateVisible(k){
    var new_min_date = new Date();
    var new_max_date = new Date();
    var daysdiff = 90;
    if (k == 1) {
        new_min_date.setTime(new_min_date.getTime() - daysdiff * 24 * 60 * 60 * 1000);
        new_max_date.setTime(new_min_date.getTime() + (daysdiff-1) * 24 * 60 * 60 * 1000);
        //var new_min_date  = today.getFullYear() + "/"+(today.getMonth()+1)+"/"+today.getDate();
        $("#policy_expiry_date").removeClass("unclickable");
        $(":radio[name='claim_status']").removeAttr('disabled');
        $("#current_ncb").val($('#ncb').val());
        $("#new_ncb_span").html($('#new_ncb').val()+'%');
        $('#policy_expiry_date').datepicker('change', 'minDate', new_min_date);
        $('#policy_expiry_date').datepicker('change', 'maxDate', new_max_date);
        $("#current_ncb").removeAttr("disabled");
        $("input[name ='claim_status']").removeAttr('disabled');

    } else if(k == 2) {
        $("#policy_expiry_date").addClass("unclickable");
        $(":radio[name='claim_status']").attr('disabled', true);
        $("#current_ncb").val("0");
        $("#new_ncb_span").html("0%");
        $("#current_ncb").attr("disabled", "disabled");
    } else {
        new_min_date.setTime(new_min_date.getTime());
        new_max_date.setTime(new_min_date.getTime() + (60) * 24 * 60 * 60 * 1000);
        $('#policy_expiry_date').datepicker('change', 'minDate', new_min_date);
        $('#policy_expiry_date').datepicker('change', 'maxDate', new_max_date);
        $("#policy_expiry_date").removeClass("unclickable");
        $("#current_ncb").removeClass("unclickable");
        $("input[name ='claim_status']").removeAttr('disabled');
    }
}

function isDisplayExpDays(k){
    $("#expiry_day").change();
    if(k == 'N'){
        $("#expiry_day").addClass("hidden");
        $("#policy_expiry_date").removeClass("unclickable");
    }else{
        $("#expiry_day").removeClass("hidden");
    }

}

$('input[name ="claim_status"]').change(function(t) {
    this.id, 
    cb = $(this);
    var e = $(this).val();
    "Y" === e ? ($("#current_ncb").val("0"), $("#new_ncb_span").html("0%"), $("#new_ncb_span").val("0"), $("#current_ncb").attr("disabled", "disabled"),$("#idv_claim").val("Y")): ($("#current_ncb").val($("#ncb").val()), $("#new_ncb_span").val($("#new_ncb").val()+ '%'), $("#new_ncb_span").html($("#new_ncb").val() + '%'), $("#idv_claim").val("N"), $("#current_ncb").removeAttr("disabled"))
}), 
$("#update_quote").submit(function(t) {
    $("#ncb").val(0), $("#new_ncb").val(0)
}), 
$btn_obj = null, 
$obj_idv = $("#idv"), 
$obj_idv_footer = $(".update_footer", $obj_idv), 
idv_footer = "", 
idv_accurate_btn = "#btn-idv-accurate", 
idv_edit_btn = "#btn-idv-edit", 
selector_policy_expiry_date = "#policy_expiry_date", 
selector_car_registration_date = "#car_registration_date", 
selector_claims_no = "#claim_status", 
selector_current_ncb = "#current_ncb", 
selector_qty = "#qty", 
$obj_form_idv = $("#update_quote"), 
$obj_policy_expiry_date = $("#policy_expiry_date"), 
$obj_car_registration_date = $("#car_registration_date"), 
$obj_claims_no = $("#claim_status"), 
$obj_current_ncb = $("#current_ncb"), 
$obj_qty = $("#qty"), 
selector_skip_btn = "#btn_div_skip", 
$obj_skip_btn = $("#btn_div_skip"), 
policy_expiry_date = "", 
car_registration_date = "", 
claims_no = "", 
current_ncb = "", 
qty = "", 
selector_buy_policy = "#buy_policy", 
back_to_quotes = '#back_to_quotes',
$ob_buy_policy = $(selector_buy_policy), 
selector_insurances = "#reliance_quote_ctnr_box,#bajaj_quote_ctnr_box,#tata_quote_ctnr_box,#quote_ctnr_box, #last_decimal_quote_ctnr_box, #hdfc_quote_ctnr_box, #uiic_quote_ctnr_box, #rsgi_quote_ctnr_box", 
$obj_insurances = $(selector_insurances), 
$obj_policy_expiry_date = $("#policy_expiry_date"), 
//<a class="btn btn-fill btn-primary clickable btn-xs boldtext hvr-grow" id="btn-idv-edit" style="margin-right:10px;margin-bottom: 20px;float: right;">Edit Info</a>&nbsp;&nbsp;
idv_footer_btn = '<a class="pull-left clickable btn-sm boldtext hvr-grow" id="back_to_quotes" style="cursor:pointer;margin:10px 0px 0px 0px;">Back to Quotes</a><a class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn-idv-accurate" style="margin-right:10px;margin-bottom: 20px;float: right;">Info is accurate</a>',
idv_skip_btn = '<button type="reset" value="Reset" class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn_div_skip" style="margin-right:10px;margin-bottom: 20px;float: right;">Ignore Changes</button>&nbsp;', 
$obj_insurances.on("click", selector_buy_policy, function(t) {
    $btn_obj = $(this);
    var insurer = $btn_obj.closest('form').find('#insurer_id').val();
    var product_id = $btn_obj.closest('form').find('#product_id').val();
    if(insurer == 'TATA'){
        var default_arr = ["zerodep_selected","ts_selected","ep_selected","rti_selected"];
        var array = getchks().split(',');
         array.splice(0,3);
        console.log(array);
        $.ajax({
            url:'/car-insurance/tata/check_tata_addon',
            data:{ 'insurer_id' : insurer ,
                    'product_id': product_id,
                    'trans_code': getTransCode(),
                    '_token' : get_token()
                },
            type: 'POST',
            success:function(e){
                if(e.hasOwnProperty('addon_excluded')){
                    $('html,body').animate({scrollTop: $("#car_details").offset().top},'slow');
                    confirmIDV()
                }
                else 
                    common.overlay_msg(e.html);
            }
        });
    } else {
        $('html,body').animate({scrollTop: $("#car_details").offset().top},'slow');
        confirmIDV()
    }
}), 
$obj_idv.on("click", idv_accurate_btn, function() {
    unfocusIdv(), common.loader_msg(common.msg.redirect_to_proposal), 
    //updateQuoteURL('onChangeProposalSection','true'),
    new_url_on_change = window.location.href,
    $btn_obj.closest("form").append('<input type="hidden" name="return_quote_url" value="'+new_url_on_change+'" />');
    $btn_obj.closest("form").submit();
    common.loader_rem()  
}), 
$obj_idv.on("click", idv_edit_btn, function() {
    unfocusIdv(), $obj_idv.removeClass("unclickable"), $obj_idv_footer.empty(), $obj_idv_footer.append(idv_footer)
}), 
$obj_idv.on("dp.change change paste keyup", "#policy_expiry_date,#quantity,#reset_idv,#car_registration_date,#reg_summary,#claim_status,#current_ncb,#qty,#claim_status,#expiry_day", onChangeFormValue), 
$obj_idv.on("click", ".qtyplus,.qtyminus", onChangeFormValue), 
$obj_idv.on("click", selector_skip_btn, function() {
    function changeUI(k){
        if (k == 1) {
            var new_min_date = new Date();
            var new_max_date = new Date();
            var daysdiff = 90;
            new_min_date.setTime(new_min_date.getTime() - daysdiff * 24 * 60 * 60 * 1000);
            new_max_date.setTime(new_min_date.getTime() + (daysdiff-1) * 24 * 60 * 60 * 1000);
            //var new_min_date  = today.getFullYear() + "/"+(today.getMonth()+1)+"/"+today.getDate();
            $("#policy_expiry_date").removeClass("unclickable");
            $('#policy_expiry_date').datepicker('change', 'minDate', new_min_date);
            $('#policy_expiry_date').datepicker('change', 'maxDate', new_max_date);
        } else if(k == 2) {
            $("#policy_expiry_date").addClass("unclickable");
            $(":radio[name='claim_status']").attr('disabled', true);
            $("#current_ncb").val("0");
            $("#new_ncb_span").html("0%");
            $("#new_ncb_span").val("0");
            $("#current_ncb").attr("disabled", "disabled");
        } else {
            $(":radio[name='claim_status']").removeAttr('disabled');
            $(":radio[name='claim_status']").removeClass('disabled');
            $("#policy_expiry_date").removeClass("unclickable");
            $("#current_ncb").removeAttr('disabled');
        }
        
        if(k == 'Y'){
                $("#expiry_day").addClass("hidden");
                $("#policy_expiry_date").removeClass("unclickable");
        }else{
                $("#expiry_day").removeClass("hidden");
        }
    };

    $obj_form_idv[0].reset(), $(this).remove(), unfocusIdv()
    // set old value
    url = '/car-insurance/get_idv_section';
    data = {};
    data.session_id = $('#session_id').val();
    data._token = $("input[name=_token]").val();
    common.ajaxGetRequest(url,data,function(a){
        $('#car_registration_date').val(a.car_reg_date);
        $('#policy_expiry_date').val(a.policy_exp_date);
        $('#policy_start_date').val(a.policy_start_date);
        $('#expiry_day').val(a.policy_exp_status);
        if(a.claim == 'Y'){
            $("#radio_4").removeAttr('checked');
            $("#radio_3").attr('checked', 'checked');
        }else{
            $("#radio_3").removeAttr('checked');
            $("#radio_4").attr('checked', 'checked');
        }
        $('#current_ncb').val(a.prev_ncb);
        $('#new_ncb_span').text(a.new_ncb+"%")
        $('#quantity').val(a.idv)
        changeUI(a.policy_exp_status);    
        if("Y" == a.claim){
            $("#current_ncb").attr("disabled","disabled");
        }else{
            $("#current_ncb").removeAttr("disabled");
        } 
    });
}),
$obj_idv.on("click", back_to_quotes, function() {
    $obj_form_idv[0].reset(), $(this).remove(), unfocusIdv(),$("#btn-idv-accurate").remove();
    $update_btn = '<button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_idv">Update Quotes<div class="ripple-container"></div></button>';
    $obj_idv_footer.append($update_btn);
}),

$(".update_footer").on("click", "#update_idv",function(t) {
    $('#update_idv').attr('disabled', 'disabled');
    var a = getchks();
    console.log(a);
    data = $("#update_quote").find('input,select:visible').filter('.ajaxRequiredData').serialize();
    data += "&chks="+encodeURIComponent(a)+"&_token="+get_token();
    
    
    url  = '/car-insurance/setDetail';
        
    console.log(data);    
    common.ajaxGetRequest(url,data,function(a){
        var qtyminus_value = $('.qtyminus').data('qtymin');
        var qtymax_value = $('.qtyplus').data('qtymax');
        var updated_idv = $('#quantity').val();
        if((updated_idv < qtyminus_value) ||  (updated_idv > qtymax_value)){
            common.alert('Sorry, current idv can not be provided. The minimum idv for this car is '+qtyminus_value+' and maxmium is '+qtymax_value+'.');
        } else {
             $(policy_quote_cnt).empty();
            $("#error_message").html('');
            //$("#quote_ctnr_box").html('');
            $('#btn_div_skip').remove();
            unfocusIdv();
            $('.insurance-list .customcard').remove();
            var policy_status = $('#expiry_day').val();
            common.loader("#rsqi_loader");
            callQuoteApi();      

        }    
    });
}),



function unsetChks(){
    var e = getchks();
    var array = e.split(',');
    $(".filter_quote").each(function() {
        if (this.checked) {
            var e = $(this).val();
            if("OD" != e && "TP" != e){
               $(this).trigger('click'); 
            }
        }
    });
}

$("#expiry_day").change(function(t) {
    token = $("input[name=_token]").val();
    var e = $("#expiry_day").val();
    $("#expiry_status").val(e);
    // $.ajax({
    //     url: "/car-insurance/getquote/update-policy-status",
    //     headers: {
    //         "X-CSRF-TOKEN": token
    //     },
    //     data: {
    //         policystatus: e,
    //     },
    //     dataType: "json",
    //     type: "POST",
    //     success: function(t) {
    //         // var e = parseInt(t);
    //         // $("#new_ncb_span").html(e + "%"), $("#ncb").val(a), $("#new_ncb").val(e)
    //     }
    // })
})

function updateLastDecimal(url){
    $("#last_decimal_loader").html('<div class="loader blue">Loading...</div>');
    //unfocusIdv(), 
    common.loader_msg(common.msg.updated_quote);
    var e = $("#update_quote").find('input').filter('.ajaxRequiredData').serialize()+'&ajaxupdate=true';
    token = $("input[name=_token]").val(), 
    $.ajax({
        headers: {
            "X-CSRF-TOKEN": token
        },
        type: "POST",
        dataType: "json",
        url: url,
        data: e,
        success: function(t) {
            t = $.trim(t);
            if(t != ''){
                $('#error_message').html('');
                common.redirectOnTransaction(t);
                $(".last-decimal").remove();
                $("#last_decimal_quote_ctnr_box").html(t), 
               // $('#btn_div_skip').remove(),
               // unfocusIdv(), 
                $("#last_decimal_loader").html(''),
                unsetChks();
            } else {
                $("#last_decimal_loader").html(''),
                 $('#email_quotes_div').hide();
                $("#error_message").removeClass('hide');
                var new_error = '<h5 class="card-title price">Thank you for your patience, but we do not have a quote for the combination you have selected, please try another combination.</h5>';
                $("#error_message").html(new_error);
            }
        },
    }).always(function(){
        
        sort_div();
    })
}
function updateQuoteURL(d,e){
    var chks_url_value = getUrlParameter(d);
    if(chks_url_value === undefined || chks_url_value === ''){
        url = window.location.href;
        new_url = url +'&'+d+'='+encodeURIComponent(e);
    } else {
        new_url = window.location.href.replace(d+"="+encodeURIComponent(chks_url_value), d+"="+encodeURIComponent(e));
    }
    window.history.pushState({"html":'response.html',"pageTitle":'response.pageTitle'},"", new_url);
}
function f(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};
