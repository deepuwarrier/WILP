function getForm(a, b, c) {
    common.overlay_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
       common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.proposalError();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.basePremium = Math.floor(b.data.premiumPayable / (parseInt($("#gst").val())+100) * 100) * 100), 
    policy.serviceTax = parseInt(b.data.premiumPayable) - parseInt(policy.basePremium), 
    policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(data) {
common.loader_rem();
common.loader_msg(common.msg['payment_redirect']);
if(data.payurl){
    window.location = data.payurl;
    common.loader_rem();
}
}
$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
                fullname: rules.fullname,
                aadharno: rules.aadhar,
                mobile: rules.mobile,
                cust_dob: rules.cust_dob,
                email: rules.email,
                pan: rules.pan,
                nomineeRel: rules.nomineeRel,
                nomineeAge: rules.nomineeAge,
                contactperson: rules.nomineeName,
                pincode: rules.pincode,
                houseno: rules.houseno,
                street: rules.street,
                locality: rules.locality,
                regno: rules.regno,
                engno: rules.engno,
                chassisno: rules.chassisno,
                color: rules.color,
                policyno: rules.policyno
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
