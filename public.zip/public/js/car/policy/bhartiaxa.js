function getForm(a, b, c) {
    common.overlay_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
       common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
         common.proposalError();
    });
}
function selectedPremium(new_premium,new_service_tax,product_id,insurer_id){
   data = purposalFormData();
   data = data+"&new_premium="+new_premium+"&new_service_tax="+new_service_tax;
   product_id = $("#product_id").val();
   insurer_id = $("#insurer_id").val();
   url = $("#buy_policy_form").attr("action");
   getForm(product_id,insurer_id,data);
}

// if premiumMismatch call this method use for recall api using new premium
function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = Math.floor(b.data.premiumPayable / (parseInt($("#gst").val())+100) * 100), policy.serviceTax = parseInt(b.data.premiumPayable) - parseInt(policy.basePremium), policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}


// after successfull geting response call this method in proposal 
// redirect to payment gateway
function payment(data) {
    common.loader_rem();
    common.overlay_msg(common.msg['payment_redirect']);
    if (data.payUrl) {
        var input_ele = "";
         $.each(data, function(index, val) {
            input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
        });
        input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='submit_bhartiaxa'/>";
        var pay_form = '<form id="payment" name="payment" method="POST" action="'+data.payUrl+'">';
        pay_form += input_ele;
        pay_form += "</form>";
        $("#pay_form").html(pay_form);
        $('#submit_bhartiaxa').click();
     } else {
        $("#pay_form").html(data.error);
    }   
}


// define rules for validation
$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            fullname: rules.fullname,
            aadharno: rules.aadhar,
            mobile: rules.mobile,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            contactperson: rules.nomineeName,
            pincode: rules.pincode,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            color: rules.color,
            policyno: rules.policyno,
            nomineeRel: rules.nomineeRel,
            nomineeAge: rules.nomineeAge,
            nomineeName: rules.nomineeName
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
