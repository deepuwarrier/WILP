function getForm(a, b, c) {
    common.loader_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
        common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.proposalError();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!",
            policy.text = a.html,
            policy.basePremium = b.data.PremiumPayable,
            policy.serviceTax = 0,
            policy.product_id = b.product_id,
            policy.insurer_id = b.insurer_id,
            common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(data) {
    common.loader_rem();
    common.loader_msg(common.msg['payment_redirect']);
    console.log(data);
    if (data.payUrl) {
        var input_ele = "";
         $.each(data, function(index, val) {
            input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
        });
        input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='submit_fgi'/>";
        var pay_form = '<form id="payment" name="payment" method="POST" action="'+data.payUrl+'">';
        pay_form += input_ele;
        pay_form += "</form>";
        $("#pay_form").html(pay_form);
        $('#submit_fgi').click();
     } else {
        $("#pay_form").html(data.error);
    }            
}


$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            fullname: rules.fullname,
            mobile: rules.mobile,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            aadharno: rules.aadhar,
            contactperson: rules.nomineeName,
            pincode: rules.pincode,
            driver_dob: rules.driver_dob,
            noOfAccidents: rules.noOfAccidents,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            currentMillage: rules.currentMillage,
            policyno: rules.policyno,
            policyOwner: rules.nomineeName,
            nomineeAge: rules.nomineeAge,
            nomineeName: rules.nomineeName
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
