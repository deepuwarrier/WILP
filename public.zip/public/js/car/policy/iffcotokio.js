function getForm(a, b, c) {
    common.loader_msg(common.msg.submit_form), $.ajax({method: "POST", url: url, data: c, dataType: "json"}).done(function (a) {
        common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.proposalError();
    });
}
function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data.basePremium, policy.serviceTax = b.data.serviceTax, policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}
function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(data) {

    common.loader_msg(common.msg['payment_redirect']);
    common.loader_rem();
    common.alert(common.msg['tech_issue']);
    console.log(data);
    $.ajax({
        url: data.url,
        crossOrigin: true,
        type: "POST",
      dataType: "jsonp",
        data: {
            UNIQUE_QUOTEID: data.UNIQUE_QUOTEID,
            XML_DATA: data.XML_DATA,
            RESPONSE_URL: data.RESPONSE_URL,
            PARTNER_CODE: data.PARTNER_CODE
        },
        dataType: "json"
    }).done(function (data) {
        console.debug(data);
    });
    common.proposalError();
    return true;
     var html = "";
    $("#pay_form").html(html);
    if (input_ele != "") {
       
        var input_ele = "";
        input_ele += '<input type="hidden" value="'+data.UNIQUE_QUOTEID+'" name="UNIQUE_QUOTEID"/>';
        input_ele += '<input type="hidden" value="'+data.XML_DATA+'" name="XML_DATA"/>';
        input_ele += '<input type="hidden" value="'+data.RESPONSE_URL+'" name="RESPONSE_URL"/>';
        input_ele += '<input type="hidden" value="'+data.PARTNER_CODE+'" name="PARTNER_CODE"/>';
        input_ele += '<input type="hidden" value="'+data.premiumPayable+'" name="premiumPayable"/>';
        input_ele += "<input type='Submit' style='display:none;' value ='Submit' id='itgi_submit'/>";
        var pay_form = '<form id="payment" name="payment" method="post" action="'+data.url+'">';
        pay_form += input_ele;
        pay_form += "</form>";
        $("#pay_form").html(pay_form);
        $('#itgi_submit').click();
    }
}

$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            fullname: rules.fullname,
            mobile: rules.mobile,
            aadharno: rules.aadhar,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            contactperson: rules.nomineeName,
            nomineeName: rules.nomineeName,
            nomineeRel: rules.nomineeRel,
            nomineeAge: rules.nomineeAge,
            pincode: rules.pincode,
            driver_dob: rules.driver_dob,
            noOfAccidents: rules.noOfAccidents,
            color: rules.color,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            color: rules.color,
            currentMillage: rules.currentMillage,
            policyno: rules.policyno
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
