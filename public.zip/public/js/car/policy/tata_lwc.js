function getForm(a, b, c) {
    if($('#zerodep_selected').length == "1" && $('#zerodep_selected').val() == "1"){
        if($( "input[name='prevzerodep']:checked").val() == 'Y'){
            if($('#ts_selected').length == "1" && $('#ts_selected').val() == "1"){
                if($( "input[name='prevts']:checked").val() == 'Y'){
                    if($('#ep_selected').length == "1" && $('#ep_selected').val() == "1"){
                        if($( "input[name='prevep']:checked").val() == 'Y'){
                            if($('#rti_selected').length == "1" && $('#rti_selected').val() == "1"){
                                if($( "input[name='prevrti']:checked").val() == 'Y'){
                                    callProposal(a,b,c);
                                }   else 
                                {
                                    callAddonStatus(a,b,c);
                                }
                            }
                        } else 
                        {
                            callAddonStatus(a,b,c);
                        }
                    }
                } else 
                {
                    callAddonStatus(a,b,c);
                }
            }
        } else 
        {
            callAddonStatus(a,b,c);
        }
    } else{
        callProposal(a,b,c);
    }
}

function callAddonStatus(a,b,c){
    url  = $('#addon_status_url').val();
    common.ajaxPostRequest(url,c,function(d){
        if(d.hasOwnProperty('addon_excluded'))
            callProposal(a,b,c);
        else 
            common.overlay_msg(d.html);
    });
}

$(document).on('click','#zerodep-excluding',function(){
    /*
    data = purposalFormData(),
    product_id = $("#package_addon_contain").val();//$("#product_id").val(),
    insurer_id = $("#package_addon_contain").val();//$("#insurer_id").val();
    callProposal(product_id, insurer_id, data);
    */
    return_url = $("#return_url").val();
    window.location.href = return_url;
});

$(document).on('click','#zerodep-including',function(){
    common.apiBadReponse();
});

function callProposal(a,b,c){
    common.loader_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
        if(a.proposal_error)
            common.proposalError();
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
       common.proposalError();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data.basePremium, policy.serviceTax = b.data.serviceTax, policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(data) {
    console.log(data);
    common.loader_rem();
    common.loader_msg(common.msg['payment_redirect']);
    if (data.url) {
       var input_ele = "";
            $.each(data.fields, function(index, val) {
                input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
            });
            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='tata_submit'/>";
            var pay_form = '<form id="payment" name="payment" method="GET" action="' + data.url+ '">';
            pay_form += input_ele;
            pay_form += "</form>";
            $("#pay_form").html(pay_form);
            $("#tata_submit").click();
    } else {
        $("#pay_form").html(data.error);
    }
}
// code by shailesh chauhan - 20/03/2016
  //fullname: rules.fullname,

$(document).ready(function () {
    hideOrShowPermAddress();
    $("#reg_add_is_same").click(function(){
        hideOrShowPermAddress();    
    });

    function hideOrShowPermAddress(){
        $(".info-label").hide();
        if($($("#reg_add_is_same")).is(':checked')){
            $(".perm").hide();
            $(".perm").addClass('hidden');
            $(".info-label").addClass('hidden');
        }else{
            $(".perm").show();
            $(".perm").removeClass('hidden');
            $(".info-label").removeClass('hidden');
        }
    }

    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            mobile: rules.mobile,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            aadharno: rules.aadhar,
            nomineeAge: rules.nomineeAge,
            contactperson: rules.nomineeName,
            fullname: rules.fullname,
            pincode: rules.pincode,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            color: rules.color,
            policyno: rules.policyno,
            nomineeName: rules.nomineeName
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});


$('#reg_add_is_same').click(function(event) {
    if($('#reg_add_is_same').is(':checked'))
        $('#reg_add_is_same').val('Y');
    else
        $('#reg_add_is_same').val('N');
});
