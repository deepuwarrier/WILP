function getForm(a, b, c) {
    callProposal(a,b,c);
}

$(document).on('click','#zerodep-excluding',function(){
    data = purposalFormData(),
    product_id = $("#product_id").val(),
    insurer_id = $("#insurer_id").val();
    callProposal(product_id, insurer_id, data);
});

$(document).on('click','#zerodep-including',function(){
    common.proposalError();
});

function callProposal(a,b,c){
    url = $("#buy_policy_form").attr("action");
    common.loader_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
        // if(a.proposal_error)
        //     common.proposalError();
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
       //common.proposalError();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data["Total Premium"], policy.serviceTax = b.data["Service Tax"], policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}


function payment(data) {
    console.log(data);
    common.loader_rem();
    common.loader_msg(common.msg['payment_redirect']);
    url = $('#init_payment').val();
    c = {
        _token:$("#_token").val(),
        trans_code:$("#trans_code").val()
    };
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
       if (data.payment_url) {
         window.location.assign(data.payment_url);
     } 
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.loader_rem()
    });
}

$(document).ready(function () {
    hideOrShowPermAddress();

    $("#reg_add_is_same").click(function(){
            hideOrShowPermAddress();    
        });

        function hideOrShowPermAddress(){
            $(".info-label").hide();
            if($($("#reg_add_is_same")).is(':checked')){
                $(".perm").hide();
                $(".perm").addClass('hidden');
                $(".info-label").addClass('hidden');
            }else{
                $(".perm").show();
                $(".perm").removeClass('hidden');
                $(".info-label").removeClass('hidden');
            }
        }


    if (typeof validate_lib != 'undefined') {
            form_field = {
                fullname: "fullname",
                mobile: "mobile",
                cust_dob: "cust_dob",
                email: "email",
                pan: "pan",
                aadharno: "aadhar",
                contactperson: "nomineeName",
                houseno: "houseno",
                street: "street",
                locality: "locality",
                pincode: "pincode",
                perm_houseno: "houseno",
                perm_street: "street",
                perm_locality: "locality",
                perm_pincode: "required",
                regno: "regno",
                engno: "engno",
                chassisno: "chassisno",
                color: "color",
                policyno: "policyno",
                nomineeAge: "nomineeAge",
                nomineeName: "nomineeName",
                companyname: "cmp_name",
                type_of_finance:"required",
                financierTitle:"required",
                financierName:"financierName",
                nomineeRel:"nomineeRel"
            };

        form_id = 'buy_policy_form';
        validate_lib.applyValidation(window['form_id'],window['form_field'])
    } else {
        console.error("import validator_lib.js for validation");
    }
});

$('#reg_add_is_same').click(function(event) {
    if($('#reg_add_is_same').is(':checked'))
        $('#reg_add_is_same').val('Y');
    else
        $('#reg_add_is_same').val('N');
});
