function getForm(a, b, c) {
    common.loader_msg(common.msg.submit_form), $.ajax({method: "POST", url: url, data: c, dataType: "json"}).done(function (a) {
       common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.proposalError();
    });
}
function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data.premiumPayable, policy.serviceTax = 0, policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}
function selectedPremium(a, b, c, d, e) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}


function payment(data) {
    common.loader_rem();
    common.loader_msg(common.msg['payment_redirect']);
    if (data.payUrl) {
        window.location = data.payUrl;
        common.loader_rem();
    }
}

$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            fullname: rules.fullname,
            mobile: rules.mobile,
            aadharno: rules.aadhar,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            contactperson: rules.nomineeName,
            pincode: rules.pincode,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisnom,
            color: rules.color,
            policyno: rules.policyno
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});