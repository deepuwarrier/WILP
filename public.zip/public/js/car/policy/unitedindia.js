function getForm(a, b, c) {
    common.loader_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
        common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
       common.proposalError();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data.basePremium, policy.serviceTax = b.data.serviceTax, policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(a) {
    common.loader_msg(common.msg.payment_redirect), a.payurl && (window.location = a.payurl);
    
}
// code by shailesh chauhan - 20/03/2016
  //fullname: rules.fullname,

$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            mobile: rules.mobile,
            cust_dob: rules.cust_dob,
            aadharno: rules.aadhar,
            email: rules.email,
            pan: rules.pan,
            nomineeRel: rules.nomineeRel,
            nomineeAge: rules.nomineeAge,
            contactperson: rules.nomineeName,
            fullname: rules.fullname,
            pincode: rules.pincode,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            color: rules.color,
            policyno: rules.policyno,
            nomineeName: rules.nomineeName
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
