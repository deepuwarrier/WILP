$(document).ready(function() {
    common = {
        scroll_speed: 1e3,
        self:this,
        msg: {
            submit_form: "Please Wait...",
            change_state: "Please Wait. Loading cities in your State...",
            payment_redirect: "Please wait while we redirect you to the payment gateway of the Insurance Company",
            fetch_quote: "Please wait while we fetch the best quotes for you...",
            updated_quote: "Please wait while we update your quotes.",
            redirect_to_proposal: "Please Wait...",
            verify_otp_not_gen: 'Please try again we not able sent verification number',
            enter_otp: 'Please Enter Verification Code',
            otp_length: 'Verification Code Should be 4 Numeric',
            unveryfied_user: 'Sorry! You are not verified user',
            gen_code: 'We Are Sending Verification Code..',
            user_verified: 'Thanks for mobile verification',
            not_server_res: 'Server is responding slow, Please Try again after 5 minute',
            tech_issue: 'Your request can not be processed due to some technical issue. Please contact administrator',
            term_agree: 'Please accept terms and conditions',
            transaction_done: "This Transaction has already done,we are redirect to you Home.",
            registration_succ_msg:"Please check your mail for registration details."
        },
        ajaxSyncPostRequest: function(a, b, c) {
            $.ajax({
                type: "POST",
                url: a,
                async: false,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a)
            })
        },
        ajaxPostRequest: function(a, b, c) {
            $.ajax({
                type: "POST",
                url: a,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a)
            })
        },
        ajaxPostRequestWithOption: function(a, b, c, d) {
            $.ajax({
                type: "POST",
                url: a,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a, d)
            })
        },
        ajaxPostRequestWithOverlay: function(a, b, c, d) {
            self.overlay_msg(d);
            $.ajax({
                type: "POST",
                url: a,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a)
            }).always(function() {
                self.overlay_rem()
            })
        },
        ajaxPostRequestWithLoader: function(a, b, c, d) {
            self.loader_msg(d);
            $.ajax({
                type: "POST",
                url: a,
                data: b,
                dataType: "json"
            }).done(function(a) {
                c(a)
            }).always(function() {
                self.loader_rem()
            })
        },
        loader: function(a) {
            $(a).html('<div class="loader blue">Loading...</div>')
        },
        overlay_msg: function(a) {
            $("#overlay").html("<span class='msg'>" + a + "<span>"), $("#overlay").fadeIn(), $("#overlay").css("opacity", 1)
        },
        loader_msg: function(a) {
            $("#overlay").html("<span class='msg'>" + a + "<span>"), $("#overlay").fadeIn(), $("#overlay").css("opacity", 1), $("#overlay").append('<div class="loader">Loading...</div>')
        },
        overlay_rem: function() {
            $("#overlay").empty(), $("#overlay").fadeOut()
        },
        loader_rem: function() {
            $("#overlay").empty(), $("#overlay").fadeOut()
        },
        scrollToTop: function(a) {
            $("html, body").animate({
                scrollTop: $(a).position().top
            }, self.scroll_speed)
        },
        scrollTop: function(a) {
            $("html, body").animate({
                scrollTop: 0
            }, self.scroll_speed)
        },
        replaceTpl: function(a,b){
        	$.each(b,function(c,d){
        		a = a.replace(c,d)
        	});
        	return a
        },
        alert: function(msg){
            if(msg)
                swal(msg)
        },
        serilazeArrToArr: function(a){
            var b = {};
            $.each(a,function(c,d){
              b[""+d.name] = d.value;
            });
            return b;
        },

        serilazeArrayToArray: function(a){
            var b = {};
            $.each(a,function(c,d){
              
              if(d.name.indexOf('[]') != -1){
                if(b[""+d.name] == 'undefined' || b[""+d.name] == undefined){
                    b[""+d.name] = [];    
                }
                b[""+d.name][b[""+d.name].length] = d.value;
              }else{
                b[""+d.name] = d.value;
              }
              
            });
            return b;
        },

        setCookie: function(name, value, days)
        {
          if (days)
          {
            var date = new Date();
            date.setTime(date.getTime()+days*24*60*60*1000); // ) removed
            var expires = "; expires=" + date.toGMTString(); // + added
          }
          else
            var expires = "";
          document.cookie = name+"=" + value+expires + ";path=/"; // + and " added
        },
        getCookie: function(name) {
            var cookieName = name + "="
            var docCookie = document.cookie
            var cookieStart
            var end
                if (docCookie.length>0) {
                    cookieStart = docCookie.indexOf(cookieName)
                if (cookieStart != -1) {
                    cookieStart = cookieStart + cookieName.length
                    end = docCookie.indexOf(";",cookieStart)
                if (end == -1) {
                    end = docCookie.length}
                    return unescape(docCookie.substring(cookieStart,end))
                }
            }
        return false
        },
        delCookie: function(name) {
            document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        },
        apiBadReponse: function (){
            window.location = $("#api_bad_response").val();
        },
        proposalError: function(){
            window.location = $("#proposal_error").val();
        },
        redirect: function($url,$msg){
           if($msg !== null){
                swal($msg).then(function(){
                    window.location = $url;        
                });
            }else{
                window.location = $url;    
            } 
        },
        redirectOnTransaction: function(a){
            if(typeof a.redirect != 'undefined' && a.redirect !== null){
                this.redirect(a.redirect,self.msg['transaction_done']);
            }
        },
        init: function(){
            self =  this;
        }

    }, $(document).on("click", ".scrolltop", function() {
        $(window).width() < 1070 && (selector = $(this).attr("data-focus"), "undefined" == selector ? common.scrollTop() : common.scrollToTop("#" + selector))
    });

    common.init();
});

// Send quotes through email

$('#email_quote_modal').on('submit','#email_quote_form', function(event) {
    var d = 'Please wait your request is under process';
    $("#overlay").html("<span class='msg'>" + d + "<span>"), $("#overlay").fadeIn(), $("#overlay").css({'opacity': 6,'z-index': '1095'});
    event.preventDefault();
    var url = this.action;
    var data = $('#email_quote_form').serialize();
    var return_function = function(e){
        $("#overlay").empty(), $("#overlay").fadeOut(),$("#overlay").css({'opacity': 1,'z-index': '1029'});
        if(e.error === 'false'){
            $('.input-group').hide();
            $('.modal-footer').hide();
            $('#quote_email_message').html('Email with quote details has been sent. Please check your mail.')
        } else {
            $('#quote_email_message').html('Sorry there has been some issues while sending mail. Please try again.')
        }
        return false;
    }
    self.ajaxPostRequestWithOverlay(url,data,return_function,'Please wait...');
    return false;
});
$("#email_quote_modal").on("hidden.bs.modal", function () {
    $('.input-group').show();
    $('.modal-footer').show();
    $('#quote_email_message').html('');
});
// Send quotes through email ends here

$('#login_registration_body').on('submit','#loginForm', function(event) {
    validate_form_data.login_form();
    if($('#loginForm').valid()){
        var form_data = $('#loginForm').serialize();
        url =  $('#loginForm').attr('action');
        var return_function = function(e){
            if(e.error === 'true'){
                if(e.user_status === '0'){
                    $('#password_error').html(e.message);
                    $('#email_error').html('');
                } else {
                    $('#password_error').html('');
                    $('#email_error').html(e.message);
                }
            } else {
                $('#password_error').html('');
                $('#user_section').removeClass('hide')
                $('#logout_div').removeClass('hide')
                $('#change_password').removeClass('hide');
                $('#login_div').addClass('hide');
                $('#login_modal').modal('hide');
                $('#user_name').html(e.username);
                if(e.isagent === 'true'){
                    $('#daily_report').removeClass('hide');
                    $('#refresh_div').removeClass('hide');
                    $('#agent_dashboard').removeClass('hide');
                }
                $.each($('#loginForm').serializeArray(), function(index, val) {
                    if(val.name != '_token'){$('#'+val.name).val('');}
                });
            }
            return false;
        }
        self.ajaxPostRequestWithOverlay(url,form_data,return_function,'Please wait your getting logged in');
        return false;
    }
    return false;
});

$('#login_registration_body').on('click','#register_modal', function(event) {
    $('#back_login').removeClass('hide')
    $('#regi_hide').removeClass('hide');
    $('#login_hide').addClass('hide');
    $('#forget_hide').addClass('hide');
});

$('#login_registration_body').on('click','#forgot_password', function(event) {
    $('#back_login').removeClass('hide');
    $('#regi_hide').addClass('hide');
    $('#login_hide').addClass('hide');
    $('#forget_hide').removeClass('hide');
});

$('#back_login').on('click', function(event) {
    $('#back_login').addClass('hide');
    $('#login_hide').removeClass('hide');
    $('#regi_hide').addClass('hide');
    $('#forget_hide').addClass('hide');
    
});

$("#login_modal").on("hidden.bs.modal", function () {
    $("#loginForm").validate().resetForm();
    $('#login_button').removeAttr('disabled', 'disabled');
    $("#registrationForm").validate().resetForm();
    $('#user_registration_form').removeAttr('disabled', 'disabled');
    $("#forget_password_form").validate().resetForm();
    $('#forgetPassword_button').removeAttr('disabled', 'disabled');
    $.each($('#loginForm').serializeArray(), function(index, val) {
        if(val.name != '_token'){$('#'+val.name).val('');}
    });
    $.each($('#registrationForm').serializeArray(), function(index, val) {
        if(val.name != '_token'){$('#'+val.name).val('');}
    });
    $.each($('#forget_password_form').serializeArray(), function(index, val) {
        if(val.name != '_token'){$('#'+val.name).val('');}
    });
    $('#password_error').html('');
    $('#email_error').html('');
    $('#forget_email_error').html('');
    $('#back_login').click();
});

$('#login_registration_body').on('submit','#forget_password_form', function(event) {
    var d = 'Please wait your request is under process';
    $("#overlay").html("<span class='msg'>" + d + "<span>"), $("#overlay").fadeIn(), $("#overlay").css({'opacity': 6,'z-index': '1095'});
    validate_form_data.forget_form();
    if($('#forget_password_form').valid()){
        $('#forgetPassword_button').attr('disabled', 'disabled');
        var form_data = $('#forget_password_form').serialize();
        url =  $('#forget_password_form').attr('action');
        var return_function = function(e){
            $("#overlay").empty(), $("#overlay").fadeOut(),$("#overlay").css({'opacity': 1,'z-index': '1029'});
            $('#forgetPassword_button').removeAttr('disabled', 'disabled');
            if(e.error === 'true'){
                if(e.user_status === '0'){
                    $('#forget_email_error').html(e.message);
                }
            } else {
                $('#forget_email_error').html('');
                swal({
                  text: "Email with new password has been sent to your mail. Please check your inbox.",
                  showCancelButton: false,
                  confirmButtonText: "OK",
                  closeOnConfirm: true
                });
                $('#forgetPassword_button').removeAttr('disabled')
                $('#forgetPassword_email').html(''),$('#back_login').click(),$('#login_modal').modal('hide');
            }
            return false;
        }
        self.ajaxPostRequestWithOverlay(url,form_data,return_function,'Please wait your password is getting reset');
        return false;
    }
    return false;
});

function getCsrfToken(){
    return $('meta[name="csrf-token"]').attr('content');
}

$('#login_registration_body').on('submit','#registrationForm', function(event) {
    validate_form_data.registration_form();
    if($('#registrationForm').valid()){
        $('#user_registration_form').attr('disabled', 'disabled');
        otp_common.otp_function_call = registerUser;
        otp_common.verifyMobileNumber('registerUser')
    }
    return false;
});


$(document).ready(function($) {
    jQuery.validator.addMethod("regex",
        function(value, element, regexp) {
            var re = new RegExp(regexp);
            return this.optional(element) || re.test(value);
        },"Please check your input.");
});


var validate_form_data = {
    login_form: function(){
        $('#loginForm').validate({
            rules:{
                'login_mobile_number':{
                    required:true,
                    number:true,
                    minlength:10,
                    maxlength:10,
                },
                'register_password':{
                    required: true,
                },
            },
            messages: {
                'login_mobile_number':{
                    required: "Please enter your mobile number",
                    number:"Please enter number in proper format",
                    minlength:'Please enter your ten digit mobile number',
                    maxlength:'Please enter your ten digit mobile number',
                }
            }
        })
    },
    forget_form:function(){
        $('#forget_password_form').validate({
            rules:{
                'forgetPassword_email':{
                    required:true,
                    email:true,
                }
            },
            messages:{
                'forgetPassword_email':{
                    required: "Please enter your E-mail Address",
                    email: "Please enter your valid email Address",
                }
            }
        })
    },
    registration_form: function(){
        $("#registrationForm").validate({
            rules: {
                'register_name':{
                    required:true,
                    regex: "^([a-zA-Z]*[ ]*)+$",
                },
                'register_mobile_number':{
                    required:true,
                    number:true,
                    minlength:10,
                    maxlength:10,
                },
                'register_password':{
                    required: true,
                },
                'register_email': {
                    required: true,
                    email:true,
                },
            },
            messages: {
                'register_email': {
                    required: "Please enter your E-mail Address",
                    email: "Please enter your valid email Address",
                },
                'register_name':{
                    regex:'Please enter your name without having special characters'
                },
                'register_mobile_number':{
                    required: "Please enter your mobile number",
                    number:"Please enter number in proper format",
                    minlength:'Please enter your ten digit mobile number',
                    maxlength:'Please enter your ten digit mobile number',
                }
            },
        });
    },
    car_insurance_offer:function(){
        $('#carInsuranceOfferForm').validate({
            rules:{
                'car_offer_mobile' : {
                    required:true,
                    number:true,
                    minlength:10,
                    maxlength:10,                    
                },
                'car_offer_email' : {
                    required: true,
                    email:true,
                },
                'car_offer_insu_exp_month' : {
                    required: true,
                }
            },
            messages:{
                'car_offer_mobile' : {
                    required: "Please enter your mobile number.",
                    number:"Please enter number in proper format.",
                    minlength:'Please enter your ten digit mobile number.',
                    maxlength:'Please enter your ten digit mobile number.',
                },
                'car_offer_email' : {
                    required: "Please enter your E-mail Address.",
                    email: "Please enter your valid email Address.",
                },
                'car_offer_insu_exp_month' : {
                    required: 'Please select your insurance expiry month.'
                }
            }
        });
    }
}

$('#logout_div').on('click', function(event) {
    var d = 'Please wait you are been logged out'
    var url = $('#logout').attr('data-url');
    var form_data = '_token='+$('input[name="_token"]').val();
    self.overlay_msg(d);
    $.ajax({
        url: url,
        type: 'POST',
        data: form_data,
    })
    .done(function() {
        $('#refresh_div').addClass('hide');
        $('#login_div').removeClass('hide');
        $('#logout_div').addClass('hide');
        $('#user_section').addClass('hide');
        $('#change_password').addClass('hide');
        $('#daily_report').addClass('hide');
        $('#agent_dashboard').addClass('hide');
    }).always(function() {
        self.overlay_rem()
    });
    /* Act on the event */
});

$('#change_password_button').on('click', function(event) {
    var empty_value = 'false';
    $.each($('#change_password_form').serializeArray(), function(index, val) {
        if(val.value === '' || typeof val.value === 'undefined'){
            $('#'+val.name+'_error').html('Please enter the above value.');
            empty_value = 'true';
            return false;
        } else {
            $('#'+val.name+'_error').html('');
        }
    });
    if(empty_value === 'false'){
        var form_data = $('#change_password_form').serialize()+'&_token='+$('meta[name="csrf-token"]').attr('content');
        url =  $('#change_password_form').attr('action');
        var return_function = function(e){
            if(e.error === 'true'){
                if(e.user_status === '0'){
                    $('#old_password_error').html(e.message);
                } else if(e.user_status === '2'){ 
                    $('#confirm_password_error').html(e.message);
                } else {
                    $('#registration_error').html('');
                }
            } else {
                $('form :input').val("");
                $('#change_password_modal').modal('hide');
            }
            return false;
        }
        self.ajaxPostRequestWithLoader(url,form_data,return_function,'Please wait...');
        return false;
    }
    /* Act on the event */
});

$('#carInsuranceOffer').on('click','#car_insurance_offer_button', function(event) {
    validate_form_data.car_insurance_offer();
    if($('#carInsuranceOfferForm').valid()){
        otp_common.verifyMobileNumber('registerUserOfferPage')
    }
});

var registerUserOfferPage = function(){
    var form_data = $('#carInsuranceOfferForm').serialize()
    var token = getCsrfToken();
    var data = form_data;
    var url =  $('#carInsuranceOfferForm').attr('action');
    var return_function = function(e){	
        if(e.error === 'true'){
            if(e.user_status === '0'){
                self.alert(e.message);
                $('#registration_error').html(e.message);
            } else {
                $('#registration_error').html('');
            }
        } else {		
            error_html = "A confirmation email has been sent to you. You can proceed to generate a quote now.";
            swal({
                title: "Congratulations!",
                text: error_html,
                type: "success",
                showCancelButton: false,
            }).then(function() {
		window.location = 'car-insurance';
            });
        }
        return false;
    }
    self.ajaxPostRequestWithLoader(url,data,return_function,'Please your request for registrion is under process');
    return false;
}

function registerUser(){
    var form_data = $('#registrationForm').serialize()
    var token = '_token='+$('meta[name="csrf-token"]').attr('content');
    var data = form_data;
    var url =  $('#registrationForm').attr('action');
    var return_function = function(e){
        //Overlay removed
        $("#overlay").empty(), $("#overlay").fadeOut(),$("#overlay").css({'opacity': 1,'z-index': '1029'});
        $('#user_registration_form').removeAttr('disabled', 'disabled');
        if(e.error === 'true'){
            if(e.user_status === '0'){
                self.alert(e.message);
                $('#registration_error').html(e.message);
            } else {
                $('#registration_error').html('');
            }
        } else {

            error_html = "Please check your mail for registration details.";
            swal({
                title: "Wow!",
                text: error_html,
                type: "info",
                showCancelButton: false,
            }).then(function() {
                location.reload();
                $('#back_login').click();
                $('#login_modal').modal('hide');
                $.each($('#registrationForm').serializeArray(), function(index, val) {
                    if(val.name != '_token'){
                        $('#'+val.name).val('');
                    }
                });
            });
        }
        return false;
    }
    self.ajaxPostRequestWithLoader(url,data,return_function,'Please wait your request for registration is under process');
    return false;
}

var otp_common = new (function ($) {    
	otp_function_call = null;
    policy_cmp_sel = '#policy_cmp',
    mobile = '',
    $token = getCsrfToken(),
    $otp_gen = $('#otp_gen'),
    $very_otp = $('#very_otp');
    verifycation_status = 0;
    verified_by_user = 0;
    verified_number = false;
    $obj_proposer = $("#proposer");
	
	//Run this function after ajax completed //call back
	runCompleteCallback = function(_function){
		window.otp_function_call = window[_function]();			
	};
    function genrateOtp_common() {
        b = {_token: getCsrfToken(), mobile: mobile}
        a = $('#otp_gen').val();
        common.ajaxPostRequest(a, b, function (data) {
            console.log('data = ');
            console.log(data);
            if (data) {
                if(typeof data.overLimit != undefined && data.overLimit){
                    console.log(data);
                    common.alert("You have exceed the verifiation limit");
                    $('#user_registration_form').removeAttr('disabled', 'disabled');
                    return false;
                }

                if (typeof data.status != undefined) {
                    //When mobile is verified                   
                    if(data.otp){
                        if (!data.status){
                            window.verified_number = checkVerificastionDisplay(mobile);							
                        } else {
                            var d = 'Please wait your request is under process';
                            $("#overlay").html("<span class='msg'>" + d + "<span>"), $("#overlay").fadeIn(), $("#overlay").css({'opacity': 6,'z-index': '1095'});
                            window.verifycation_status = 1;
                            runCompleteCallback(otp_function_call);//call callback function
                        }
                        
                    } else if(data.status) {
                        window.verified_number = checkVerificastionDisplay(mobile);
                    } else{
                        common.alert(common.verify_otp_not_gen);
                    }
                }
            }
            else{
                alert('Sorry');
            }
        });
        return window.verified_number;
    }

    function checkVerificastionDisplay(mobile){
        if(verificationDisplay_common(mobile)){
            return 1;
        } else {
            return 0;
        }
    }

    function verificationDisplay_common(mobile) {
        var status = 0;
        $('body').removeClass('modal-open');
        $('.modal').removeAttr('tabindex');
        swal({
            title: '<b>Enter Verification Code</b>',
            text: 'Please Check Your text message at the phone number ' + mobile,
            input: 'text',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: function (text) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        if (text == '') {
                            reject(common.msg['enter_otp']);
                        } else if (text.length != 4) {
                            reject(common.msg['otp_length']);
                        } else {
                            resolve()
                        }
                    }, 2000)
                })
            },
            allowOutsideClick: false
        }).then(function (text) {
            verifyCode_common(text);
            $('body').addClass('modal-open');
            $('.modal').attr('tabindex', '-1');
        },function(dismiss){
            $('#user_registration_form').removeAttr('disabled', 'disabled');
            $('body').addClass('modal-open');
            $('.modal').attr('tabindex', '-1');
        })
    }

    function verifyCode_common(code) {
        b = {_token: getCsrfToken(), code: code}
        a = $('#very_otp').val();
        common.ajaxPostRequest(a, b, function (data) {
            if (data) {
                if (typeof data.status != undefined) {
                    window.verifycation_status = data.status;
                    if (window.verifycation_status) {
                        swal({
                            text: common.msg['user_verified'],
                            showCancelButton: false,
                            confirmButtonText: 'OK',
                            showLoaderOnConfirm: true,
                            allowOutsideClick: false
                        }).then(function (text) {
                            var d = 'Please wait your request is under process';
                            $("#overlay").html("<span class='msg'>" + d + "<span>"), $("#overlay").fadeIn(), $("#overlay").css({'opacity': 6,'z-index': '1095'});
                            window.verified_by_user = 1;
                            runCompleteCallback(otp_function_call);
                        });
                    } else
                        common.alert(common.msg['unveryfied_user']);
                        window.verified_by_user = 0;
                }
            }
        });
        return window.verified_by_user;
    }
    
    return {
        self: this,
        verifycation_status: verifycation_status,
        verified: window.verified,

        verifyMobileNumber: function (val) {
            mobile = $('#register_mobile_number').val();
			//By Shailesh on Sat, May-20-2017
			//For car offer mobile no missing
			if (  'registerUserOfferPage' ==val && '' == mobile ) { 
				mobile = $('#car_offer_mobile').val();
			}
          window.otp_function_call = val;
            return genrateOtp_common();
        }
    }


})(jQuery);
