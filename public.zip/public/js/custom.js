	
$( function() {
    $( "#ddt" ).datepicker({dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true});
} );

$( function() {
	$( "#aj_jobduedt" ).datepicker({dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true});
} );

$("#del_job_btn").click(function(event) {
    if( confirm('Are you sure you want to delete !!!') )  {   
    	$('#ujform').attr('action', '/delete_job');
    	$('#ujform').submit();
} 	});

$("#cst_delete").click(function(event) {
    if( confirm('Are you sure you want to delete !!!') )  {   
    	$('#cst_form').attr('action', '/delete_customer');
    	$('#cst_form').submit();
} 	});



 $("#srchbtn").click(function() {  
	mob_s_param = $("#smn").val();
	jobsno_s_param = $("#sjsn").val();
	ddate_s_param = $("#ddt").val();
	
	$.post('/jobSearch', {
		_token : $("#_token").val(),
		mob_s_p : mob_s_param,
		jobsno_s_p : jobsno_s_param,
		ddate_s_p : ddate_s_param
	}, function(data, status) {
		$("#jobCcntDiv").html(data);
	});
	
});



$("#fetchCustomer").click(function() { 
	$("#cstname").val("");
	$("#cstemail").val("");
	$("#cstaddr").val("");
	
	$.post('/findCustomer', {
		 _token: $("#_token").val(),
	      mobNo:$("#cstphone").val()
		    },
 		    function(data, status) {
		$.each(data, function(i, val) {
			$("#custid").val(val.cstid);
			$("#cstname").val(val.cstname);
			$("#cstemail").val(val.cstemail);
			$("#cstaddr").val(val.cstaddr);
		});
	});
});

$("#m_add_product").click(function() {  $( "#m_add_product_box" ).dialog();	});
$("#m_add_brand").click(function() {  $( "#m_add_brand_box" ).dialog();	});
$("#m_add_model").click(function() {  $( "#m_add_model_box" ).dialog();	});
$("#m_add_jobstatus").click(function() {  $( "#m_add_jobstatus_box" ).dialog();	});
$("#m_add_jobtype").click(function() {  $( "#m_add_jobtype_box" ).dialog();	});
$("#m_add_jobloc").click(function() {  $( "#m_add_jobloc_box" ).dialog();	});
$("#m_add_techtn").click(function() {  $( "#m_add_techtn_box" ).dialog();	});


