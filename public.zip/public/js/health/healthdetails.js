// Validation for Members age 
function errorCheck() {
    var e = !1,
        t = !1,
        i = !1,
        a = !1,
        n = $("#age").val(),
        r = !1;
    return "" != n && 19 > n && (i = !0), 

    $(".age_list").each(function() {
        $(this).find("option:selected").text();
        (null == $(this).val() || "" == $(this).val()) && (e = !0)
    }), 

    $(".members").each(function() {
        var e = $(this).find("option:selected").text();

        if(($(this).val()== null) || ($(this).val()== '')){
           t = 1
        }
        if (null == $(this).val() && (t = !0), "FATHER" == $.trim(e) || "MOTHER" == $.trim(e)) {
            var i = $(this).parent().parent().find(".age_list").val();
            null != i && "" != i && (age = i, age < 19 && (swal($.trim(e) + " should be an Adult"), r = !0))
        }

        if ("WIFE" == $.trim(e)) {
            var n = $("#age").val();
            21 > n && (a = !0)
        }
    }), 1 == t ? (swal("Please Select a Relationship"), !1) : 1 == e ? (swal("Please select Age"), !1) : 1 != a ? 1 == r ? !1 : !0 : void swal("Kindly re-check Self/Spouse Age")
}


// Add members in details page
$(document).ready(function(){
    var addDiv = $('#placeDiv');
    var token  = '_token='+$('meta[name=csrf-token]').attr('content')+'&';
    var membercount = $('#memcount').val();

    if(typeof(membercount) !== 'undefined'){
        var ids = ods = membercount;
    } else{  
        var ids = 1;
        var ods = 0;
    } 

    $("input[type='button'][name='remove']").click(function() {
        ids--;
        ods--;
        $mem_id = $(this).attr('id');
        deletemember($mem_id);
    });
   
    $('#addmem').on('click', '#add-member', function(e) { 
       var counter = $('.datarepeaterbox').length;
        if(errorCheck()){
            ods++;
            e.preventDefault();
            var yearRange = "-90:+1";
            var inputData = token+'counter='+counter+'&'+$('#formuserdata').serialize();

            if (ids < 6) {
                common.loader_msg(common.msg['submit_form']);
                $.ajax({
                    url: APP_URL+'/health-insurance/home',
                    type: 'POST',
                    data: inputData,
                    success: function(html) {
                        common.overlay_rem();
                        values = $(html).appendTo(addDiv);

                        //To Remove member div
                        $('#del' + counter).on('click', function() {
                            ids--;
                            $(this).parent().parent().prev().remove();
                            $(this).parent().parent().parent().remove();
                            $(this).parent().parent().remove();
                        });

                        ids++;
                    }
                });
            } else {
                swal("Sorry You are Limited to add only 6 members !!");
            }
            }      

        });
    
});
    
    function deletemember(delid) {
        $('#'+delid).parent().parent().prev().remove();  
        $('#'+delid).parent().parent().parent().remove();
        $('#'+delid).parent().parent().remove();
    }
        
    

 // Rearrange age list based on changing self age
$("#placeDiv").on("change", "#age", function(e) {
    var age = $(this).find("option:selected").text(); 
    var member = $(this).parent().parent().parent().find("#mem_add").val();
    a = '<option value="">Select Age</option>';

    if('SELF' == $.trim(member)){
        $("#mem_add").each(function() {
            var e = $(this).find("option:selected").text();
            if("FATHER" == $.trim(e) || "MOTHER" == $.trim(e) ){
                r = parseInt(age) + 21;
                for (i = r; i <= 110; i++) a += '<option value="' + i + '">' + i + " Years</option>";
                $(this).parent().next().find("#age").empty(), 
                $(this).parent().next().find("#age").append(a),
                $(this).parent().parent().next().find('#age').empty(),
                $(this).parent().parent().next().find('#age').append(a)
            } 
                
            
            if("SON" == $.trim(e) || "DAUGHTER" == $.trim(e) ){
                e = '<option value="">Select Age</option>';
                     child = parseInt(age) - 19;
                     e += '<option value="' + 3 + 'm">' + " 1-3 "+ " Months</option>";
                    e += '<option value="' + 10 + 'm">' + "3-12 "+ " Months</option>";
                    limit = child;
                    if(child > 25) { limit = 25;}
                    for (i = 1; i <= limit; i++) e += '<option value="' + i + '">' + i + " Years</option>"
                    $(this).parent().next().find("#age").empty(), 
                    $(this).parent().next().find("#age").append(e)
                    $(this).parent().parent().next().find('#age').empty(),
                    $(this).parent().parent().next().find('#age').append(e)
                    
            } 


        });
    }
});



// Reset age list dropdown by changing members relationship
$("#placeDiv").on("change", "#mem_add", function(e) {
    var t = $(this).find("option:selected").text(); 
     membercount = $('#memcount').val(),
     a = '<option value="">Select Age</option>';
       if ("WIFE" == $.trim(t)) {
        for (i = 18; i <= 110; i++) a += '<option value="' + i + '">' + i + " Years</option>";
        $(this).parent().next().find("#age").empty(), 
        $(this).parent().next().find("#age").append(a),
        $(this).parent().parent().next().find('#age').empty(),
        $(this).parent().parent().next().find('#age').append(a)
    }
    if ("HUSBAND" == $.trim(t)) {
        for (i = 21; i <= 110; i++) a += '<option value="' + i + '">' + i + " Years</option>";
        $(this).parent().next().find("#age").empty(), 
        $(this).parent().next().find("#age").append(a),
        $(this).parent().parent().next().find('#age').empty(),
        $(this).parent().parent().next().find('#age').append(a)
    }
    if ("FATHER" == $.trim(t) || "MOTHER" == $.trim(t) || "FATHER IN LAW" == $.trim(t) || "MOTHER IN LAW" == $.trim(t) || "GRAND FATHER" == $.trim(t) || "GRAND MOTHER" == $.trim(t)) 
    {
        var n = $("#age").val(),
            r = parseInt(n) + 21;
        for (i = r; i <= 110; i++) a += '<option value="' + i + '">' + i + " Years</option>";
        $(this).parent().next().find("#age").empty(), 
        $(this).parent().next().find("#age").append(a),
        $(this).parent().parent().next().find('#age').empty(),
        $(this).parent().parent().next().find('#age').append(a)
    }

    if ("BROTHER" == $.trim(t) || "SISTER" == $.trim(t) || "BROTHER IN LAW" == $.trim(t) || "SISTER IN LAW" == $.trim(t)) 
    {
        var n = $("#age").val();
        for (i = 19; i <= 110; i++) a += '<option value="' + i + '">' + i + " Years</option>";
        $(this).parent().next().find("#age").empty(), 
        $(this).parent().next().find("#age").append(a),
        $(this).parent().parent().next().find('#age').empty(),
        $(this).parent().parent().next().find('#age').append(a)
    }


if(typeof(membercount) !== 'undefined'){
    if ("SON" == $.trim(t) || "DAUGHTER" == $.trim(t) || "SON IN LAW" == $.trim(t) || "DAUGHTER IN LAW" == $.trim(t)) {
        var r = 0,
            p = 0,
            o = 0,
            a = parseInt($("#age").val());
        if ($("#mem_add").each(function() {
                var e = $(this).find("option:selected").text();
                "HUSBAND" == $.trim(e) && (p = parseInt($(this).parent().next().find("#age").val()), isNaN(p) && (p = parseInt($(this).parent().parent().next().find("#age").val())), "" == n && (p = 0)), 
                "WIFE" == $.trim(e) && (o = parseInt($(this).parent().next().find("#age").val()), isNaN(o) && (o = parseInt($(this).parent().parent().next().find("#age").val())), "" == n && (o = 0))
            }), 
            0 == p && 0 == o ? r = a - 19 : o > 0 ? r = o > a ? a - 21 : o - 19 : p > 0 && (r = p > a ? a - 19 : p - 21), 
            "SON" == $.trim(t) || "DAUGHTER" == $.trim(t)) {
                 t += '<option value="' + 3 + 'm">' + " 1-3 "+ " Months</option>";
             t += '<option value="' + 10 + 'm">' + "3-12 "+ " Months</option>";
            
             $child_age = r;
             if(r > 25){$child_age =25; }
            for (i = 1; i <= $child_age; i++) t += '<option value="' + i + '">' + i + " Years</option>"
        } else
            for (i = 1; i <= $child_age; i++) t += '<option value="' + i + '">' + i + " Years</option>";
        0 == r && swal("Please re-check Self/Spouse Age"), $(this).parent().next().find("#age").empty(), $(this).parent().next().find("#age").append(t), $(this).parent().parent().next().find("#age").empty(), $(this).parent().parent().next().find("#age").append(t)
    }
}else{
    if ("SON" == $.trim(t) || "DAUGHTER" == $.trim(t) || "SON IN LAW" == $.trim(t) || "DAUGHTER IN LAW" == $.trim(t)  ) {
        var o = 0,
            l = 0,
            p = 0,
            n = parseInt($("#age").val());

        if ($("#mem_add").each(function() {
                var e = $(this).find("option:selected").text();
                "HUSBAND" == $.trim(e) && (l = $(this).parent().next().find("#age").find("option:selected").val(), console.log(l), "" == r && (l = 0)), 
                "WIFE" == $.trim(e) && (p = $(this).parent().next().find("#age").find("option:selected").val(), console.log(p), "" == r && (p = 0))
            }), 

            0 == l && 0 == p ? o = n - 19 : p > 0 ? o = p > n ? n - 21 : p - 19 : l > 0 && (o = l > n ? n - 19 : l - 21),
             "SON" == $.trim(t) || "DAUGHTER" == $.trim(t)) {
             a += '<option value="' + 3 + 'm">' + "1 - 3" + " Months</option>";
             a += '<option value="' + 10 + 'm">' + "3 - 12" + " Months</option>";
       
             $childage = o;
             if(o > 25){$childage =25; }
        for (i = 1; i <= $childage; i++) a += '<option value="' + i + '">' + i + " Years</option>"
    }else 

     for (i = 1; i <= $childage; i++) a += '<option value="' + i + '">' + i + " Years</option>";
        0 == o && swal("Please re-check Self/Spouse Age"), 
        $(this).parent().next().find("#age").empty(), 
        $(this).parent().next().find("#age").append(a),
        $(this).parent().parent().next().find('#age').empty(),
        $(this).parent().parent().next().find('#age').append(a)
    }  

}
});


   //Proceeding to Quotation page
    $(document).on('click','#submit-form',function(){ 
        if(errorCheck()){
            common.loader_msg(common.msg['fetch_quote']);
            $('#formuserdata').submit();
        }   
    });


