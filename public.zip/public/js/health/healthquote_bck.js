function filter_quote(){ 
  common.loader_msg("Getting Quotes Please Wait....");
  token = $('input[name=_token]').val();
  id = $('input[name=userid]').val();
  sum_insured = $('input[name=sum_insured]').val();
  plan_type = $('input[name=plan_type]').val();
  product_type =$("input[name='product_type']:checked").val();
  trans_code = $('#trans_code').val();

  var chks="";
  $('input[type=checkbox]').each(function(){
    if($(this).prop("checked") == true){
        var cd = $(this).val();
            chks += cd+"|";
    }
  });

  $("#quote_ctnr_box").html('Please wait while we fetch the best quotes for you...');
  chks= chks.slice(0, -1);
  chks=$.trim(chks); 
  id = $('input[name=userid]').val();
  plan_type = $('input[name=plan_type]').val();
  trans_code = $('#trans_code').val();
  $.ajax({
    url: APP_URL+'/health-insurance/get-filterquote',
    headers: {'X-CSRF-TOKEN': token},
    type:'POST',
    data: {'chks': chks, 'id': id, 'sum_insured': sum_insured,'plan_type': plan_type,'product_type': product_type, 'trans_code':trans_code },
    success:function(response){
            common.loader_rem();
            data =  $.trim(response);
            if (data === 'No Quotes generated for your Request') {
             // display_no_quote_msg();
            } 
            $("#quote_ctnr_box").html(data);
            common.loader_rem();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
    })

}


$(document).ready(function(){
    $('#choiceupdate').on('click',function(){  
        type = $("input[name='plan_type']:checked").val();  
         mem = $("input[name='temp_mem']").val();
          if(mem <= '1' && type == 'FF'){
            swal('Sorry Family floater should contains more than one person!!');
          }else{
           common.loader_msg(common.msg['updated_quote']);
            $('#choicedata').submit();
         }


    });

  // Quote update plan blocking screen
    plan_skip_btn = '<button type="reset" value="Reset" class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn_div_skip" style="margin-right: -56px; margin-top: -50px; margin-bottom: 14px;">Ignore Changes</button>&nbsp;';
    selector_skip_btn = "#btn_div_skip";
    idv_accurate_btn = "#btn-idv-accurate";
    $obj_id = $("#confirm_update");
    $btn_obj = null;
    $obj_form_idv = $("#choicedata");
    var $plan_change = "#basic, #super_top_up,.floater, .indiv, .tenure1, .tenure2, .tenure3";
    var $update = $($plan_change);
    var $si_change = ("#qtyminus, #qtyplus, #dedqtyminus, #dedqtyplus");
    var $siupdate = $($si_change);


    $update.change(function () { 
      onChangeFormValue();
    });

    $siupdate.click(function() {
      onChangeFormValue();
    });

    $obj_id.on("click", selector_skip_btn, function() {
      $obj_form_idv[0].reset(), $(this).remove(), unfocusIdv()
    });

});

  function onChangeFormValue() { 
    if(!$("#choiceupdate").length){
        $update_btn = '<button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_idv">Update Quotes<div class="ripple-container"></div></button>';
        $obj_id.append($update_btn);      
    }
    if($("#btn-idv-accurate").length){
        $("#btn-idv-accurate").remove();
    }
    $(selector_skip_btn).length < 1 && (focusIdv(), $obj_id.append(plan_skip_btn))
  }

  function unfocusIdv() {
    $("#overlay").fadeOut(), $obj_id.css("z-index", "1029")
  }
  function focusIdv() {
    $("#overlay").fadeIn(), $obj_id.css("z-index", "1032")
  }
// End of quote update block screes



  $('input:radio[name="product_type"]').change(
    function(){
      if ($(this).is(':checked') && $(this).val() == 'B') {
        $('#basic-container').show();
        $('#super-top').hide();
      }

      if ($(this).is(':checked') && $(this).val() == 'S') {
        $('#super-top').show();
        $('#basic-container').show();
       
      }
  });




// Basically first time when page referesh/reloads/loads
 function load_health_covers(){
  var trans_code =  $("#trans_code").val();
  
  $("#cover_box").html(""); 
  
  // Last Decimal quotes
  load_covers(trans_code);

  // common.loader_rem();
   setTimeout(function(){
    if(!$("#btn_div_skip").length){
        common.loader_rem();
    }
    }, 15000);
}

// Generate Last Decimal Quotes
function load_covers (trans_code) {
   $.ajax({
            url: APP_URL+'/health-insurance/load_health_covers',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            if (data != 0 ) {
               $("#cover_box").append(data);
            } 
          }
    });
 }


// Basically first time when page referesh/reloads/loads
 function load_health_quotes(){
  var trans_code = $('#trans_code').val();
  common.loader_msg("Getting Quotes Please Wait....");
  $("#quote_ctnr_box").html(""); 
  $("#covers_list").html(""); 
  
  // Last Decimal quotes
  last_decimal_quotes(trans_code);

  //Royal Sundaram Quotes
  rsgi_quotes(trans_code);

  // HDFC ERGO Quotes
  hdfc_quotes(trans_code);

  // Religare Quotes
  religare_quotes(trans_code);

  // Star Health Quotes
  star_quotes(trans_code);

  common.loader_rem();
   setTimeout(function(){
    if(!$("#btn_div_skip").length){
        common.loader_rem();
    }
    }, 15000);

}

// Generate Last Decimal Quotes
function last_decimal_quotes(trans_code) {
  $("#last_decimal_loader").append("<span id='ld_loader'></span>");
  common.loader("#ld_loader");
   $.ajax({
            url: APP_URL+'/health-insurance/load_last_decimal_quotes',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            common.loader_rem();
            data =  $.trim(data); 
            if (data === 'No Quotes generated for your Request') {
             // display_no_quote_msg();
            } 
            else{
              $("#last_decimal_loader").html(data);
            }

          common.loader_rem();
           $("#ld_loader").remove();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
        $("#ld_loader").html('');
    })
 }

// Generate Royal sundaram Quotes
function rsgi_quotes(trans_code) { 
  $("#rsgi_quote_ctnr_box").append("<span id='rsgi_loader'></span>");
  common.loader("#rsgi_loader");
   $.ajax({
            url: APP_URL+'/health-insurance/load_rsgi_quotes',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            common.loader_rem();
            data =  $.trim(data);
            if (data === 'No Quotes generated for your Request') {
               display_no_quote_msg('rsgi');
            }else{
             $("#rsgi_quote_ctnr_box").html(data);
            } 
           common.loader_rem();
           $("#rsgi_loader").remove();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
        $("#rsgi_loader").html('');
    })

}

// Generate Religare Quotes
function religare_quotes(trans_code) { 
  $("#religare_quote_ctnr_box").append("<span id='reli_loader'></span>");
  common.loader("#reli_loader");
   $.ajax({
            url: APP_URL+'/health-insurance/load_religare_quotes',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            common.loader_rem();
            data =  $.trim(data);
            if (data === 'No Quotes generated for your Request') {
             // display_no_quote_msg();
            }else{
              $("#religare_quote_ctnr_box").html(data);
            } 
          common.loader_rem();
           $('#reli_loader').remove();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
        $("#reli_loader").html('');
    })

}

// Generate HDFC ERGO Quotes
function hdfc_quotes(trans_code) { 
  $("#hdfc_quote_ctnr_box").append("<span id='hdfc_loader'></span>");
  common.loader("#hdfc_loader");
   $.ajax({
            url: APP_URL+'/health-insurance/load_hdfc_quotes',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            common.loader_rem();
            data =  $.trim(data);
            if (data === 'No Quotes generated for your Request') {
              display_no_quote_msg('hdfc');
            } 
            else{
              $("#hdfc_quote_ctnr_box").html(data);
            }
            common.loader_rem();
            $('#hdfc_loader').remove();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
        $("#hdfc_loader").html('');
    })

}


// Generate Star Health Quotes
function star_quotes(trans_code) { 
  $("#star_quote_ctnr_box").append("<span id='star_loader'></span>");
  common.loader("#star_loader");
   $.ajax({
            url: APP_URL+'/health-insurance/load_star_quotes',
            type: 'GET',
            data: {'trans_code' : trans_code},
            success: function(data, status) {   
            common.loader_rem();
            data =  $.trim(data); 
            if (data === 'No Quotes generated for your Request') {
              display_no_quote_msg('star');
            } 
            else{
              $("#star_quote_ctnr_box").html(data);
            }
            common.loader_rem();
             $("#star_loader").remove();
            $('#btn_div_skip').remove();
          }
    }).always(function() {
        common.loader_rem();
        sort_div();
        $("#star_loader").html('');
    })

}



function sort_div(){
    var divList = $(".customcard");
    divList.sort(function(a, b){ return $(a).data("listing-price")-$(b).data("listing-price")});
    $("#quote_ctnr_box").append(divList);
}


function display_no_quote_msg(data){
    if(data == ('rsgi' || 'hdfc' || 'star')){
    if ($('#quote_ctnr_box').is(':empty')){
     $("#quote_ctnr_box").html('<h4> Sorry!! Quotes are not available for this Combination. </h4>');
    }  
  }
}

