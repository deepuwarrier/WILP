function getForm(a, b, c) { 
    common.overlay_msg(common.msg.submit_form), 
    $.ajax({
        method: "POST", 
        url: url, 
        data: c, 
        dataType: "json"
    }).done(function (a) {
       if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        } else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
    // }).fail(function(){
    //    common.apiBadReponse();
    });
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}


function premiumMismatch(a, b) { 
    basePremium = Math.floor(b.data.premiumPayable  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.premiumPayable) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) { 
    data = purposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b, 
    c = $("#product_id").val(), 
    d = $("#insurer_id").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data)
}

function payment(a) {
    common.loader_rem();
    common.loader_msg(common.msg.payment_redirect); 
    if (a.payUrl) {
       var input_ele = "";
            $.each(a, function(index, val) {
                input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
            });
            input_ele += '<input type="hidden" name="proposalNum" value="'+ a.OrderNo+'" /> ';
            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='bhagi_submit'/>";
            var pay_form = '<form id="payment" name="PAYMENTFORM" method="POST" action="' + a.payUrl + '">';
            pay_form += input_ele;
            pay_form += "</form>";
            $("#pay_form").html(pay_form);
            $("#payment").submit();
      
    } else {
        $("#pay_form").html(data.error);
    }
}



$(document).ready(function() {  
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
                
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
     });
