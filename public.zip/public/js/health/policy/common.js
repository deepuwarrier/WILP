$(document).ready(function(){
    msg = {"submit_form":"Your Request is Processing..."};
    $health_form = $("#buy_policy_form");
    $city = $('#city');
    $token = $("input[name=_token]").val();
    premiumPayable = $("#totalPremium").val();

    //Aadhaar Number spacing after 4 digits
    $('#aadhaar').keyup(function() {
        var num = $(this).val().split("-").join(""); // remove hyphens
        if (num.length > 0) {
            num = num.match(new RegExp('.{1,4}', 'g')).join("-");
        }
        $(this).val(num);
    });

    // State Dropdown On change event
    $("#state").change(function () {  
        common.loader_msg(common.msg['submit_form']);
        var state_id = $(this).val();
        var insurer_name = $("#insurer_name").val();
        var url   = $('#healthstateurl').val(); 
        var app   = '';
        if(state_id){
                $.ajax({
                method: "POST",
                url: url,
                data: { '_token': $token, 'state_id' : state_id , 'insurer_name' : insurer_name},
                dataType : 'json',
                async: false
            }).done(function(result) {
                common.overlay_rem();
                $city.empty(), 
                result.length >= 1 && ($city.append('<option hidden="" value="" disabled="" selected="">Select City*</option>'), 
                $.each(result, function(index, value ) { 
                option = '<option class="city_option" value = "'+value.city_code+'">'+value.city_name.toUpperCase()+'</option>', 
                $city.append(option) }))
            });
        } else { $('#city').html('<option value="">Select state first</option>'); }
    });

});


function chechkpolicyType(a){
    if(a.policytype == "NONSTP"){
        var trans_code = $('#trans_code').val(); 
        return pstatus.policyCheckStatus({
            trans_code: trans_code
        });
    }
}

function check_star_ppc(a){ 
    if(a.status == "ppc_case"){
        var trans_code = $('#hl_trans_code').val(); 
        return pstatus.CheckStarStatus({
            trans_code: trans_code
        });
    }
}

function check_reliance_ppc(a){ 
    if(a.status == "ppc_case"){
        var trans_code = $('#hl_trans_code').val(); 
        return pstatus.CheckRelianceStatus({
            trans_code: trans_code
        });
    }
}

function chechk_hdfc_policy(a){
    if(a.policytype == "NONSTP"){
        var trans_code = $('#hl_trans_code').val(); 
        return pstatus.checkHDFCStatus({
            trans_code: trans_code
        });
    }
}


function chechkData(a) {  
    return a ? "undefined" != typeof a.error ? "premium mismatch" == a.error.toLowerCase() || "internal server error" == a.error.toLowerCase() ? (pstatus.premiumMissmatchStatus({
        data: a,
        product_id: product_id,
        insurer_id: insurer_id
    }), 

    checkPremiumMissmatchLog = 1, !1) : (er = a.error.split(";"), error = "", 
    $.each(er, function (a, b) {
        "" != b && (error += b + "<br/>")
    }), 
    swal("Errors :", error), !1) : 1 != checkPremiumMissmatchLog ? (pstatus.successPremiumStatus(), !0) : void payment(a) : (common.alert(common.msg.not_server_res), !1)
}


$(document).ready(function(){
    redirected_log = parseInt($('#redirected').val());
    policy = {
        __proto__: common,
        $token: $("#_token"),
        self: this,
    }, 
    pstatus = {
        __proto__: common,
        $token: $("#_token"),
         self: this,

         collectDataStatus: function () {
            url = $("#premiumreconfirm").val(), data = {
               _token: $("#_token").val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)
        },
         showOverlayHtml: function (a) {
            self.overlay_msg(a.html)
        },
        successPremiumStatus: function () {
            url = $("#premiumstatus").val(), 
            data = {
               _token: $("#_token").val(),
                product_id: $("#product_id").val(),
                insurer_id: $("#insurer_name").val(),
                session_id: $("#session_id").val(),
                trans_code: $("#trans_code").val(),
                final_premium: $("#totalPremium").val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)
        },
        premiumMissmatchStatus: function (a) {    
                if(a.data.totalPremium){
                    price = "undefined" == typeof a.data.totalPremium ?
                    a.data["Total Amount Payable"] : a.data.totalPremium;
                    if (price == "undefined" || typeof price == 'undefined')
                    price = a.data.totalPremium;
                }
                if(a.data.premiumPayable){
                    price = "undefined" == typeof a.data.premiumPayable ?
                    a.data["Total Amount Payable"] : a.data.premiumPayable;
                    if (price == "undefined" || typeof price == 'undefined')
                    price = a.data.premiumPayable;
                }
                if(a.data.PremiumPayable){
                    price = "undefined" == typeof a.data.PremiumPayable ?
                    a.data["Total Amount Payable"] : a.data.PremiumPayable;
                    if (price == "undefined" || typeof price == 'undefined')
                    price = a.data.PremiumPayable;
                }
                if(a.data.FinalPremium){
                    price = "undefined" == typeof a.data.FinalPremium ?
                    a.data["Total Amount Payable"] : a.data.FinalPremium;
                    if (price == "undefined" || typeof price == 'undefined')
                    price = a.data.FinalPremium;
                }
        // for royal sundaram
                if(a.data.finalPremium){
                    price = "undefined" == typeof a.data.finalPremium ?
                    a.data["Total Amount Payable"] : a.data.finalPremium;
                    if (price == "undefined" || typeof price == 'undefined')
                    price = a.data.finalPremium;

                }


            passed_price = (typeof a.data.PremiumPassed != 'undefined' && a.data.PremiumPassed)
            || (typeof a.data.Total_Premium_Passed != 'undefined' && a.data.Total_Premium_Passed)
            || (typeof a.data.PassedPremium != 'undefined' && a.data.PassedPremium)
            || (typeof a.data.premiumPassed != 'undefined' && a.data.premiumPassed)|| (typeof a.data.premiumpassed != 'undefined' && a.data.premiumpassed);

            passed_price = passed_price || premiumPayable;

            url = $("#premiummissmatch").val(), 
            data = {
               _token: $("#_token").val(),
                product_id: $("#product_id").val(),
                insurer_id: $("#insurer_name").val(),
                session_id: $("#session_id").val(),
                trans_code: $("#trans_code").val(),
                price: price,
                passed_price: $("#totalPremium").val()
            }, 
            self.ajaxPostRequestWithOption(url, data, premiumMismatch, a)
        },
 
        policyCheckStatus: function(a) { 
            var rsgi_ped = "#consulted_doctor_yes,#undergone_investigation_yes,#taken_medical_treatment_yes,#consuming_tablets_yes, #medical_conditions_yes, #undergone_a_surgery_yes";
            var $rsgiped = $(rsgi_ped);
            $ped_status = '';
            if($rsgiped.is(':checked')){ 
                $ped_status = '3';
            }
            url = $("#policy_check").val(), 
            data = {
               _token: $("#_token").val(),
                trans_code: $("#trans_code").val(), 
                ped_check: $ped_status, 
            }, 
            self.ajaxPostRequestWithOption(url, data, policyCheck, a)
        },

        checkHDFCStatus: function(a) { 
            var hdfc_ped = "#illness-yes";
            var $hdfcped = $(hdfc_ped);
            $ped_status = '';
            if($hdfcped.is(':checked')){ 
                $ped_status = '3';
            }
            url = $("#hdfc_policy_check").val(), 
            data = {
               _token: $("#_token").val(),
                trans_code: $("#trans_code").val(),
                ped_check: $ped_status, 
            }, 
            self.ajaxPostRequestWithOption(url, data, policyCheck, a)
        },

         CheckStarStatus: function(a) { 
           var url = $("#star_policy_check").val();
            data = {
               _token: $("#_token").val(),
                trans_code: $("#hl_trans_code").val(),
            }, 
            self.ajaxPostRequestWithOption(url, data, policyCheck, a)
        },
        
        CheckRelianceStatus: function(a) { 
           var url = $("#reliance_policy_check").val();
            data = {
               _token: $("#_token").val(),
                trans_code: $("#hl_trans_code").val(),
            }, 
            self.ajaxPostRequestWithOption(url, data, policyCheck, a)
        },

        religare_ppc_case: function(a) { 
            data = {
                _token: $("#_token").val(),
                session_id: $("#session_id").val(),
                trans_code: $("#trans_code").val(),
                data: a, 
            }, 
            self.ajaxPostRequestWithOption(a.ppc_data.url, data, policyCheck, a)
        },

         badResponseStatus: function () {
            url = $("#badresponse").val(), data = {
                 _token: $("#_token").val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)
        }
    },

    $(document).on("click", "#health-btn-pay", function () { 
        // check user has confirm 
        $obj = $("#disclaimer").closest("div");
        if($obj.hasClass("shake")){
            $obj.removeClass("shake").removeClass("animated");
        }
        if($("#disclaimer").prop('checked') == false){
            common.alert(common.msg.term_agree)
            $obj.closest("div").addClass("shake").addClass("animated");
            return true;
        }
        if(validateForm()){
            if($('#religare_age_check').length){
                checkAgeStatus(1);
            }
            else{
                collectDataStatus();
                data = proposalFormData();
                product_id = $("#product_id").val();
                insurer_id = $("#insurer_name").val();
                url = $("#buy_policy_form").attr("action"); 
                setTimeout(function () { 
                getForm(product_id, insurer_id, data);
                }, 5e3);
            }
            
            }
    }),

     demo.initMaterialWizard(),
    $(".btn-next").click(function(){ 
        showUserDetails(), showAddressDetails(), showPEDDetails(),showNomineeDetails() 
    }), 
    $(".change").click(function() { 
        ref = $(this).attr("data-href"), $(".wizard-navigation li a[href='" + ref + "']").click() 
    })

    type = $('input[name="type"]:checked').val();
        if(type == 'O')$('input[name="type"]:checked').change();
});


function collectDataStatus(){
            var a = $("#datastatus").val();
            $token = $("input[name=_token]").val()
            $.ajax({
                method:"POST",
                url:a,
                data:{'_token': $token },
                dataType:"json",async:!1}).done(function(a){
                overlay_msg(a.html)})
            }


function checkBmiStatus(){
            var a = $("#hdfc_bmi_check").attr('data-url');
            var session_key = $("#session_id").val();
            var trans_code = $("#trans_code").val(),
            $token = $("input[name=_token]").val();
            $.ajax({
                method:"POST",
                url:a,
                data:{'_token': $token, 'trans_code' : trans_code},
                dataType:"json",async:!1}).done(function(a){
                if(a.status)
                    overlay_msg(a.html) 
                else{
                    collectDataStatus();
                    data = proposalFormData();
                    product_id = $("#product_id").val();
                    insurer_id = $("#insurer_name").val();
                    url = $("#buy_policy_form").attr("action"); 
                    setTimeout(function () { 
                    getForm(product_id, insurer_id, data);
                    }, 5e3);
                }    
                })
            }

function checkAgeStatus(type){
            var a=$("#agestatus").val();  
            $token        = $("input[name=_token]").val()
            $product_type = $("input[name='product_type']").val();
            $age =  $('#memage').val();
            $si =  $('#si').val();
            $insurer_id   = $('#insurer_name').val();
            $session_key = $("#session_id").val();
            $trans_code = $("#trans_code").val();
            $.ajax({
                method:"POST",
                url:a,
                data:{'_token': $token, 'type' : type, 'insurer_id' : $insurer_id, 'product_type' : $product_type, 'age': $age, 'si': $si, 'trans_code':$trans_code},
                dataType:"json",async:!1}).done(function(a){
                overlay_msg(a.html) })
            }  


$(document).on("click", "#age_status_cancel", function () {
    var a = 'success';
    common.overlay_rem();
    staticpayment(a)
});

$(document).on("click", "#bmi_change_btn", function () {
    common.overlay_rem();
    $('#insured_btn').click();
});

$(document).on("click", "#age_status_proceed", function () {
    if(typeof religare_flag !== 'undefined'){
        religare_ppc_proceed();
        exit();
    }
    data = proposalFormData(), 
    data = data + "&agree_med_chkup=" + 1, 
    product_id = $("#product_id").val(),
    insurer_id = $("#insurer_name").val(),
    url = $("#buy_policy_form").attr("action"),
    getForm(product_id, insurer_id, data)
});

// helper function

function proposalFormData(){
    return city = $("#city option:selected:enabled").text(),
    state   = $("#state option:selected:enabled").text(),
    address = $("input[name='houseno']").val()+", "+
    $("input[name='street']").val() + ", "
    + $("input[name='locality']").val(), 
    data    = $("#buy_policy_form :input,#buy_policy_form select").serialize(),
    data += "&state=" + state +"&city=" + city + "&address="+address,
    data;
}

// validation function for proposal page
function validateForm(){
    $return_type = true;
    $input = $("select.required,input.required",$health_form);
    errors = "";
    var i = 1;
    $input.each(function(key,element){
            // if(element.value == '' || element.value == null || element.value == ' '){
            //         if($(element).closest(".hidden").length == 0){
            //             errors +=  element.getAttribute("data-name")+" is required \n <br/>";
            //             $return_type = false;
            //         }
            // } 

            //Code for validating first & last name of each members
            if($('#firstname'+i).val()){  
                   if (!$('#firstname'+i).val().match(/^[A-Z ]{3,70}$/i)) {
                        errors += "Person"+i+": First name can only contain minimum 3 letters\n <br/>";
                        $return_type = false;
                    }
            }
            if($('#lastname'+i).val()){  
                    if (!$('#lastname'+i).val().match("^[a-zA-Z ]+$")) {
                        errors += "Person"+i+": Last name can only contain a-z and A-Z \n <br/>";
                        $return_type = false;
                    }
            }
            i++;
    });

    if(errors != ""){
        title = 'Errors : ';
        sweetAlert(title,errors, "error");
    }
    return $return_type;
}

function sendOTP(e) {
    return policy_cmp_sel = "#policy_cmp", 
    $(policy_cmp_sel).length && "hdfc" == $(policy_cmp_sel).val() ? (validationTime = common.getCookie("hdfc"), 
        "undefined" != validationTime && validationTime > 2 ? (console.log(window.verifycation_status), 
            window.verifycation_status ? (console.log("call validate data1"), 
                validateProposal(e)) : (common.alert(common.msg.unveryfied_user), !1)) : (validateProposal(e) && otp.verifyMobileNumber(), !1)) : void 0
}

$(".wizard-card").bootstrapWizard({
    tabClass: "nav nav-pills",
    nextSelector: ".btn-next",
    previousSelector: ".btn-previous",
    onNext: function(t, e, a) {
        tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
        if(tab_text == "Review"){
            return true;
        }
        id = $(".tab-pane.active").attr("id");

       policy_cmp_sel = '#policy_cmp';
       check_v = window["'"+otp.getMobile()+"'"];
       return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                    (!check_v || check_v == 'undefined')    ?
                        (validateProposal(id)) ?
                            (otp.verifyMobileNumber(),false)
                        : false
                    : validateProposal(id)
                : validateProposal(id);

    },

    onTabShow: function(t, e, a) {
        var n = e.find("li").length,
            o = a + 1,
            i = e.closest(".wizard-card");
        o >= n ? ($(i).find(".btn-next").hide(), 
            $(i).find(".btn-finish").show()) : ($(i).find(".btn-next").show(), 
            $(i).find(".btn-finish").hide()), 
        button_text = e.find("li:nth-child(" + o + ") a").html(), setTimeout(function() {
            $(".moving-tab").text(button_text)
        }, 150);
        var r = $(".footer-checkbox");
        0 == !a ? $(r).css({
            opacity: "0",
            visibility: "hidden",
            position: "absolute"
        }) : $(r).css({
            opacity: "1",
            visibility: "visible"
        }), refreshAnimation(i, a)
    },

    onTabClick: function(t, e, a) {
        showUserDetails(), showAddressDetails(), showPEDDetails(),showNomineeDetails();
        tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
        if(tab_text == "Review"){
            return true;
        }
        id = $(".tab-pane.active").attr("id");

       policy_cmp_sel = '#policy_cmp';
       check_v = window["'"+otp.getMobile()+"'"];
       return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                    (!check_v || check_v == 'undefined')    ?
                        (validateProposal(id)) ?
                            (otp.verifyMobileNumber(),false)
                        : false
                    : validateProposal(id)
                : validateProposal(id);
    }
});


// otp implemention
var otp = new (function ($) {
    self = this;
            policy_cmp_sel = '#policy_cmp',
            mobile = '',
            $token = $("input[name=_token]").val(),
            $otp_gen = $('#health_otp_gen'),
            $very_otp = $('#health_very_otp');
            verifycation_status = 0;
            $obj_proposer = $("#insured");

    function genrateOtp() {
        b = {_token: $token, mobile: mobile}
        a = $otp_gen.val();
        console.log(a);
        common.ajaxPostRequestWithLoader(a, b, function (data) {
            
            console.log("Genrate Otp Data");
            console.log(data);
            if (data) {
                if(typeof data.overLimit != undefined && data.overLimit){
                    console.log(data);
                    common.alert("you are exceed the verifiation limit");
                    return false;
                }

                if (typeof data.status != undefined) {
                    //When mobile is verified                   
                    if(data.otp){                       
                            if (data.status) {
                                console.log("check what happen"+otp.getMobile());
                                window["'"+otp.getMobile()+"'"] = 1;
                                $(".wizard-card").bootstrapWizard("next");
                            }else{
                                verificationDisplay(mobile);
                            }
                    } else if (data.status){
                        verificationDisplay(mobile);
                    }
                    else{
                        common.alert(common.verify_otp_not_gen);
                        return false;
                    }
                }
            }
        }, common.msg['gen_code']);
    }


    function verificationDisplay(mobile) {
        var status = 0;
        swal({
            title: '<b>Enter Verification Code</b>',
            text: 'Please Check Your text message at the phone number ' + mobile,
            input: 'text',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: function (text) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        if (text == '') {
                            reject(common.msg['enter_otp']);
                        } else if (text.length != 4) {
                            reject(common.msg['otp_length']);
                        } else {
                            resolve()
                        }
                    }, 2000)
                })
            },
            allowOutsideClick: false
        }).then(function (text) {
            status = verifyCode(text);
        })
    }

    function verifyCode(code) {
        b = {_token: $token, code: code}
        a = $very_otp.val();
        var status = 0;
        common.ajaxPostRequest(a, b, function (data) {
            if (data) {
                if (typeof data.status != undefined) {
                    window[""+otp.getMobile()] = data.status;
                    if (window[""+otp.getMobile()]) {
                        common.setCookie('hdfc', 3, 1);
                        $(".wizard-card").bootstrapWizard("next");
                        common.alert(common.msg['user_verified']);
                    } else
                        common.alert(common.msg['unveryfied_user']);
                }
            }
        });

        if (window.verified == undefined) {
            window.verified = 1;
        } else {
            window.verified = window.verified + 1;
        }
        common.setCookie('hdfc', window.verified, 1);
    }
    return {
        self: this,
        verifycation_status: verifycation_status,
        verified: window.verified,
        getMobile: function(){
            return $('#mobile').val();
        },
        verifyMobileNumber: function () {
            console.log('verifyMobileNumber');
            mobile = this.getMobile();
            return genrateOtp();
        }
    }

})(jQuery);






sel_setdata = "#setdata";

function setData(fields) {
    url = $(sel_setdata).attr('data-url');
    fields.session_id = $("#session_id").val();
     fields.trans_code = $("#trans_code").val();

    common.ajaxPostRequest(url, fields, function () {});
}


function ajaxPostRequest(url,data,onSuccess){
    $.ajax({
        type:'POST',
        url: url,
        data: data,
        dataType: "json"
        }).done(function(data){
        onSuccess(data);
    });
}

$obj_insured          = $("#insured");
$obj_communication      = $("#communication");
$obj_healthhistory     = $('#healthhistory');
$obj_nominee_details   = $('#nominee_details');
$obj_proposer_prev      = $("#insured_preview");
$obj_communication_prev = $("#communication_preview");
$obj_health_ped_preview = $("#health_ped_preview");
$obj_nominee_details_preview  = $('#nominee_details_preview');


// show preview 
function showUserDetails(){ 
    $data = $(":input",$obj_insured),
    $obj_proposer_prev.empty(), 
    processDetailsForProposerShow($data,$obj_proposer_prev)
}

function showAddressDetails(){
    $data = $(":input",$obj_communication),
    $obj_communication_prev.empty(),
    processDetailsForShow($data,$obj_communication_prev)
}

 function showPEDDetails(){ 
    $data = $(":input",$obj_healthhistory ); 
    $obj_health_ped_preview.empty();
    processForProposerShow($data,$obj_health_ped_preview);}

function showNomineeDetails(){
    $data = $(":input",$obj_nominee_details),
    $obj_nominee_details_preview.empty(),
    processDetailsForShow($data,$obj_nominee_details_preview)
}


function processDetailsForShow(a, b) {
    $str = {}, 
    count = 1, 
    $.each(a, function(a, c) {
        if (0 == $(c).closest(".col-sm-4.hidden").length)
            if (type = $(c).attr("type"), 
                tagename = $(c).prop("tagName"), "INPUT" == tagename) 
                switch (type) {
                case "radio":
                    this.checked && (val = $(c).siblings("label").text(), 
                        name = $(c).attr("data-name"), 
                        "undefined" != typeof name && "undefined" != typeof val && ($str[count] = genrateDetailsView(b, name, val), 
                            count++)
                        );
                    break;
                case "text":
                    val = $(c).val(), 
                    name = $(c).attr("data-name"), 
                    "undefined" != name && "undefined" != val && ($str[count] = genrateDetailsView(b, name, val), 
                        count++)
            } else "SELECT" == tagename && (val = $("option:selected", c).text(), 
                name = $(c).attr("data-name"), 
                "undefined" != typeof name && "undefined" != typeof val && ($str[count] = genrateDetailsView(b, name, val), 
                count++))
    }), 
    lastobj = "", 
    preview_data = "", 
    tag = 0, 
    col = 0;
    c = "";
    $.each($str, function (a, b) {
        count--;
        col++;
        if(count == 1 || col == 2){
            preview_data += "<div class='col-sm-12'>"+c+b+"</div>";            
            col = 0;
            c = "";
        }else{
            c += b;
        }
    })
    b.append(preview_data)
}

// function for preview selected information
function processDetailsForProposerShow($data,$place){
    $str = {};
    count = 1;
    $.each($data,function(key,obj){
        if($(obj).closest(".col-sm-4.hidden").length == 0){
            type = $(obj).attr("type");
            tagename = $(obj).prop("tagName");
            if(tagename == "INPUT"){
            switch(type){
                // case "radio": if(this.checked){
                //     val =  $(obj).siblings("label").text();
                //     name = $(obj).attr('data-name');
                //     $str[count] = genrateDetailsView($place,name,val);
                // } break;
                case "text":    val = $(obj).val();
                    name = $(obj).attr('data-name');
                    $str[count] = genrateDetailsView($place,name,val);
                break;
            }
            }
            // else if(tagename == "SELECT"){
            //     val = $("option:selected",obj).text();
            //     name = $(obj).attr('data-name');
            //     $str[count] = genrateDetailsView($place,name,val);
            // }
        }
        count++;
    });
    lastobj = "";
    preview_data = "";
    tag = 0;
    var counter = 1;
    var preview_dataa = "";
    var obk = '';
    tag = 0, 
    col = 0;
    c = "";
    $.each($str, function (a, b) {
        count--;
        col++;
        if(count == 1 || col == 2){
            preview_dataa += "<div class='col-sm-12'>"+c+b+"</div>";            
            col = 0;
            c = "";
        }else{
            c += b;
        }
    })
    
    $place.append(preview_dataa);
}

// function for preview selected information
function processForProposerShow($data,$place){
    $str = {};
    count = 1;
    $.each($data,function(key,obj){
        if($(obj).closest(".col-sm-4.hidden").length == 0){
            type = $(obj).attr("type");
            catagory = $(obj).attr("data-type");// FOR PED
            tagename = $(obj).prop("tagName");
            if(tagename == "INPUT"){
            switch(type){
                case "radio": if(this.checked){
                    val =  $(obj).siblings("label").text();
                    name = $(obj).attr('data-name');
                    $str[count] = genrateDetailsView($place,name,val);
                } break;
                case "text":    val = $(obj).val();
                    name = $(obj).attr('data-name');
                    $str[count] = genrateDetailsView($place,name,val);
                break;
            }
            // FOR SHOWING PED 
            if(typeof catagory != "undefined" && catagory == 1){
                if(this.checked){
                  val  =  $(obj).siblings("label").text();
                  name = $(obj).attr('data-name');
                  $str[count] = genrateDetailsView($place,name,val);
                }else{
                  val  =  'NO';
                  name = $(obj).attr('data-name');
                  $str[count] = genrateDetailsView($place,name,val); 
                }
            }
            }
            // else if(tagename == "SELECT"){
            //     val = $("option:selected",obj).text();
            //     name = $(obj).attr('data-name');
            //     $str[count] = genrateDetailsView($place,name,val);
            // }
        }
        count++;
    });
    lastobj = "";
    preview_data = "";
    tag = 0;
    var counter = 1;
    var preview_dataa = "";
    var obk = '';
    col = 0;
    c = "";
    
    count = Object.keys($str).length;
    $.each($str, function (a, b) {
        count--;
        col++;
        if(count == 0 || col == 2){
            preview_dataa += "<div class='col-sm-12'>"+c+b+"</div>";            
            col = 0;
            c = "";
        }else{
            c += b;
        }
    })
    
    $place.append(preview_dataa);
}


var checkPremiumMissmatchLog = 0;
$obj_insured = $("#insured"), $obj_communication = $("#communication"),  
$obj_proposer_prev = $("#insured_preview"), $obj_communication_prev = $("#communication_preview"),
 $(document).on("click", ".modal_details", function (a) {
    var b = $(this).attr("data-modal"),
            c = $(this).attr("data-producid");
            d = $(this).attr("data-session_id"),
    showmodal(b, c, d)
}), 
 $(document).on("click", "#payment-submit", function () {
    payment(policy.proposal_return_data)
}), 
 $(document).on("click", "#re-submit", function () {
    selectedPremium(policy.basePremium, policy.serviceTax, policy.product_id, policy.insurer_id, policy.totalPremium)
}), 
 $(document).on("click", "#review-again", function () {
    checkPremiumMissmatchLog = 0, common.overlay_rem()
});


//Proposal Form input field Uppercase Letters
function genrateDetailsView(a, b, c){ 
    return "<div class='col-sm-3'>"
                +"<span class='info_text'>"
                + b
                +" :</span>"                    
            +"</div>"
            +"<div class='col-sm-3'>"
                +c.toUpperCase()
            +"</div>";
}
// overlay show with message
function overlay_msg(msg){$('#overlay').html("<span class='msg'>"+msg+"<span>");$('#overlay').fadeIn(); }

// Loader show with message
function loader_msg(msg){
    $('#overlay').html("<span class='msg'>"+msg+"<span>");
    $('#overlay').fadeIn();
    $('#overlay').css("opacity",1);
    $('#overlay').append('<div class="loader">Loading...</div>');
}

// remove overlay 
function overlay_rem(){ $('#overlay').empty(); $('#overlay').fadeOut(); }

function submitForm(){    
    loader_msg(msg['submit_form']);
    $.post( url, data, function(data) {
        overlay_rem(); 
        swal($.trim(data));             
    });
}

function refreshAnimation($wizard, index) {
        total_steps = $wizard.find('li').length;
        move_distance = $wizard.width() / total_steps;
        step_width = move_distance;
        move_distance *= index;
        $current = index + 1;
        if ($current == 1) {
            move_distance -= 8
        } else if ($current == total_steps) {
            move_distance += 8
        }
        $wizard.find('.moving-tab').css('width', step_width);
        $('.moving-tab').css({
            'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
            'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
        });
    }
    
    function store_payment_status($payment_ref_num) { 
        token = $('input[name=_token]').val(); 
        hl_trans_code = $("#trans_code").val();
        payment_ref = $payment_ref_num;
         $.ajax({
            url: APP_URL+'/health-insurance/store_payment_status',
            type: 'POST',
            data: {'_token' : token,'hl_trans_code' : hl_trans_code, 'payment_ref_num': payment_ref},
        });
    };

