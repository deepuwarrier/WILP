
if (typeof validate_lib != 'undefined') {
    form_field = {
        
        "dob_list[]":'cust_dob_dash_d_m_y',
        "firstname[]":'firstname',
        "lastname[]":'lastname',
        "aadhaar_num":"aadhar_no",
        "height_feet[]":"required",
        "height_inches[]":"required",
        "weight[]":"weight",
        "marital_status":"required",
        "education":"required",
        "occupation[]":"required",
        "designation1":"required",
        "email":"email",
        "mobile":"mobile",
        "house_num":"houseno",
        "street":"street",
        "locality":"locality",
        "state":"required",
        "city":"required",
        "cust_pincode":"pincode",
        "consulted_doctor_member[]":"required",

        // extrenal data
        "pedname[]":"required",

        "nominee_name":"fullname"
    };
    form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field);
} else {
    console.error("import validator_lib.js for validation");
}

function validateProposal(a) {
    form_id = 'buy_policy_form';
    is_validated = validate_lib.isValidate(form_id);

    if(!is_validated)
        return is_validated;

    id = $(".tab-pane.active").attr('id');
    field = $("#" + id + " :input:visible").serializeArray();
    fields = common.serilazeArrayToArray(field); 
    fields.id = id;
    fields._token = $('#_token').val();
    
    $return_type = !0, errors = "";
    var b = 1,
        c = $("#membercount").val();
    
    return "" != errors && (d = "", overlay_rem(), swal(errors)) ? '' :(setData(fields)), $return_type
}
