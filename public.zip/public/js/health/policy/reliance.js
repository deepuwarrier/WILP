// City Dropdown On change event
$("#city").change(function () { 
     common.loader_msg(common.msg['submit_form']);
        token = $("input[name=_token]").val(),
        city_code = $(this).val(),
        insurer_name = $("#insurer_name").val(),
        url = $("#state_city").val();
        $.ajax({
        method: "post",
        url: url,
        data: {'_token': $token, 'city_code' : city_code , 'insurer_name' : insurer_name},
        dataType: "json",
        async: !0
    }).done(function(data) {
        common.overlay_rem(), 
        $("#cust_pincode").empty(), 
        $("#cust_pincode").val(data.pincode), 

        pincode = '<option hidden="" selected="" disabled="" value="">Select Pincode*</option>', 
        $.each(data, function(e, t) { 
            pincode += '<option value = "' + t.pincode + '">' + t.pincode + "</option>"
        }), 
        $("#cust_pincode").empty(), 
        $("#cust_pincode").append(pincode)

      })
    }) ;

function load_dob_list(){
  count = $('#membercount').val(); 
  for(i=0; i<count; i++){  
    $('#dob_list'+i).datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      minDate: $('#dob_list'+i).attr('min-date'),
      maxDate: $('#dob_list'+i).attr('max-date'),
      yearRange: "-97:+1"})
   } 
}

function load_nominee_dob() {
    var start = new Date();
    start.setFullYear(start.getFullYear() - 99);
    var end = new Date();
    end.setDate(end.getDate() - 1);
    end.setFullYear(end.getFullYear() - 18);
    $('#nominee_dob').datepicker({
        dateFormat: 'dd/mm/yy',
        changeMonth: true,
        changeYear: true,
        minDate: start,
        maxDate: end,
        yearRange: start.getFullYear() + ':' + end.getFullYear()
    });
};

function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form),
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
   }).done(function (a) {  
        if(a['status'] == 'offline'){ 
            offlinePolicy(a.message)
        }else if(a['status'] == "ppc_case") {
            check_reliance_ppc(a)
        }else if(a['Error'] == "Error") {
            swal(a['errormsg'])
        }
        else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
     });
}

function offlinePolicy(message) { 
     window.location = $("#offline_policy").val() + '?msg='+message;
}

function policyCheck(a, b){
    policy.text = a.html, 
    common.overlay_msg(policy.text)
}

function premiumMismatch(a, b) {  
    basePremium = Math.floor(b.data.finalPremium  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.finalPremium) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.totalPremium = b.data.finalPremium,
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d, e) { 
    data = proposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b + "&new_total_premium=" + e, 
    c = $("#product_id").val(), 
    d = $("#insurer_id").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data)
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}

function payment(data) {
    common.loader_rem();
    common.loader_msg(common.msg.payment_redirect);
    store_payment_status(data.fields.ProposalNo);
    if (data.payment_url) {
       var input_ele = "";
            $.each(data.fields, function(index, val) {
                input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
            });
            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='reliance_submit'/>";
            var pay_form = '<form id="payment" name="payment" method="GET" action="'+data.payment_url+'">';
            pay_form += input_ele;
            pay_form += "</form>";

            $("#pay_form").html(pay_form);
            $("#reliance_submit").click();
    } else {
        $("#pay_form").html(data.error);
    }
}



// PED details

// Illness/Injury code = 2369

// consulted doctor question
  $("#2369_yes").on("click",function(){ 
        $("#2369").val(""),
        'Yes'==$(this).val()? $("#2369").show() : $("#2369").hide()
  });

  $("#2369_no").on("click", function(){
     $("#2369").val(""),
        'Yes' == $(this).val()? $("#2369").show() : $("#2369").hide()
});

// Diabelte code = 2370

$("#2370_yes").on("click",function(){ 
        $("#2370").val(""),
        'Yes'==$(this).val()? $("#2370").show() : $("#2370").hide()
  });

  $("#2370_no").on("click", function(){
     $("#2370").val(""),
        'Yes' == $(this).val()? $("#2370").show() : $("#2370").hide()
});


//Hypertension code = 2371  

$("#2371_yes").on("click",function(){ 
        $("#2371").val(""),
        'Yes'==$(this).val()? $("#2371").show() : $("#2371").hide()
  });

  $("#2371_no").on("click", function(){
     $("#2371").val(""),
        'Yes' == $(this).val()? $("#2371").show() : $("#2371").hide()
});

// Liver disease(s) code = 2377 
    
    $("#2377_yes").on("click",function(){ 
        $("#2377").val(""),
        'Yes'==$(this).val()? $("#2377").show() : $("#2377").hide()
  });

  $("#2377_no").on("click", function(){
     $("#2377").val(""),
        'Yes' == $(this).val()? $("#2377").show() : $("#2377").hide()
});

//Cancer/Tumor code = 2372
    
    $("#2372_yes").on("click",function(){ 
        $("#2372").val(""),
        'Yes'==$(this).val()? $("#2372").show() : $("#2372").hide()
  });

  $("#2372_no").on("click", function(){
     $("#2372").val(""),
        'Yes' == $(this).val()? $("#2372").show() : $("#2372").hide()
});

//Heart Disease(s) code = 2378 
    $("#2378_yes").on("click",function(){ 
        $("#2378").val(""),
        'Yes'==$(this).val()? $("#2378").show() : $("#2378").hide()
  });

  $("#2378_no").on("click", function(){
     $("#2378").val(""),
        'Yes' == $(this).val()? $("#2378").show() : $("#2378").hide()
});

//Arthritis/Joint pain code = 2379    
$("#2379_yes").on("click",function(){ 
        $("#2379").val(""),
        'Yes'==$(this).val()? $("#2379").show() : $("#2379").hide()
  });

  $("#2379_no").on("click", function(){
     $("#2379").val(""),
        'Yes' == $(this).val()? $("#2379").show() : $("#2379").hide()
});
//Kidney Disease(s) code = 2373  
    $("#2373_yes").on("click",function(){ 
        $("#2373").val(""),
        'Yes'==$(this).val()? $("#2373").show() : $("#2373").hide()
  });

  $("#2373_no").on("click", function(){
     $("#2373").val(""),
        'Yes' == $(this).val()? $("#2373").show() : $("#2373").hide()
});

//Paralysis/Stroke code = 2374   
    $("#2374_yes").on("click",function(){ 
        $("#2374").val(""),
        'Yes'==$(this).val()? $("#2374").show() : $("#2374").hide()
  });

  $("#2374_no").on("click", function(){
     $("#2374").val(""),
        'Yes' == $(this).val()? $("#2374").show() : $("#2374").hide()
});
//HIV/AIDS/STD code = 2376 
    $("#2376_yes").on("click",function(){ 
        $("#2376").val(""),
        'Yes'==$(this).val()? $("#2376").show() : $("#2376").hide()
  });

  $("#2376_no").on("click", function(){
     $("#2376").val(""),
        'Yes' == $(this).val()? $("#2376").show() : $("#2376").hide()
});
//Respiratory disorder(s) code = 2375    
  $("#2375_yes").on("click",function(){ 
        $("#2375").val(""),
        'Yes'==$(this).val()? $("#2375").show() : $("#2375").hide()
  });

  $("#2375_no").on("click", function(){
     $("#2375").val(""),
        'Yes' == $(this).val()? $("#2375").show() : $("#2375").hide()
});


$("#critical_illness_yes").on("click",function(){ 
        swal('Sorry, we cannot issue this policy online as there is a special underwriting approval required for pre-existing diseases.');
});



