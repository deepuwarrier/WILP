var api_response    = 0;
var token           = $('#_token').val();
var insurer_id      = $('#insurerId').val();
var session_id      = $('#session_id').val();
var religare_flag   = 0;

function load_dob_list(){
  count = $('#membercount').val();  
  for(i=0; i<count; i++){  
    $('#dob_list'+i).datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      minDate: $('#dob_list'+i).attr('min-date'),
      maxDate: $('#dob_list'+i).attr('max-date'),
      yearRange: "-90:+1"})
   } 
}

function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form),
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (data) {
        common.overlay_rem();
        api_response = data;
        if(data.status == 'verror'){ 
             swal(data.verror_txt);
        }else if(data.ppc_data.status == true){
            pstatus.religare_ppc_case(data);
        }else if(data.status){
            no_premium_change();
        }else if(data.status == false && data.mismatch == true){
            premium_mismatch();
        }else if(data.status == false && data.error == true){
            swal(data.message);
        }else{
            offline_policy();
        }

    }).always(function () {
        common.loader_rem();
    });
}

function policyCheck(a, b){
    policy.text = a.html, 
    common.overlay_msg(policy.text)
}

function religare_ppc_proceed(){
    if(api_response.status){
        no_premium_change();
    }else if(api_response.status == 0 && api_response.mismatch == 1){
        premium_mismatch();
    }else{
        offline_policy();
    }
}

function no_premium_change(){
    var url = $('#premiumstatus').val(); 
    $.post( 
        url,
        { '_token': token, 
          'final_premium' : api_response.premium, 
          'insurer_id' : insurer_id, 
          'product_id' : 123,
          'session_id' :session_id
        },
        function(data) {
            common.overlay_msg(data.html);
        }              
    );
}

function premium_mismatch(){
    var url = $('#premiummissmatch').val(); 
    $.post( 
        url,
        { '_token': token, 
          'final_premium' : api_response.premium, 
          'insurer_id' : insurer_id, 
          'product_id' : 123,
          'session_id' :session_id,
          'price' : api_response.actual_premium,
          'passed_price' : api_response.passed_premium
        },
        function(data) {
            common.overlay_msg(data.html);
        }              
    );
}

function payment(response) { 
    // Getting Configuration data from DB
    var data = {'proposalNum' : api_response.proposalno,'returnURL' : api_response.returnurl}; 
    // Redirecting to PG
    store_payment_status(api_response.proposalno);
    post_data(api_response.pgurl, 'post', data);
}

function selectedPremium(a, b, c, d) { 
    // Since existing flow is like this, I just added this function here
    payment('religare');
}

function post_data(actionUrl, method, data) {
    var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
        }
    }
    $('body').append(mapForm);
    mapForm.submit();
}

function offline_policy() {
    window.location = $("#offline_policy").val()
}

/* PED Questions*/
function set_member_name(qn){
    //Setting Name to Member
    if($('#firstname0').length){
        $member_1 = $('#firstname0').val().toUpperCase();
        var container_1 = '#'+qn+'_0_member';
        $(container_1).html($member_1);
    }
    if($('#firstname1').length){
        var container_2 = '#'+qn+'_1_member';
        $member_2 = $('#firstname1').val().toUpperCase();
        $(container_2).html($member_2);
    }
    if($('#firstname2').length){
        var container_3 = '#'+qn+'_2_member';
        $member_3 = $('#firstname2').val().toUpperCase();
        $(container_3).html($member_3);
    }
    if($('#firstname3').length){
        var container_4 = '#'+qn+'_3_member';
        $member_4 = $('#firstname3').val().toUpperCase();
        $(container_4).html($member_4);
    }
    if($('#firstname4').length){
        var container_5 = '#'+qn+'_4_member';
        $member_5 = $('#firstname4').val().toUpperCase();
        $(container_5).html($member_5);
    }
    if($('#firstname5').length){
        var container_6 = '#'+qn+'_5_member';
        $member_6 = $('#firstname5').val().toUpperCase();
        $(container_6).html($member_6);
    }
}

/* PED validations */
function validate_ped(){
    errors  = '';

    //Question 1
    var qn_state = $("#PEDdiabetesDetails-yes").is(':checked');
    if(qn_state){
        errors  = validate_members('PEDdiabetesDetails', '1');
    }

    //Question 2
    var qn_state = $("#PEDhyperTensionDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDhyperTensionDetails', '2');
    }

    //Question 3
    var qn_state = $("#PEDliverDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDliverDetails', '3');
    }

    //Question 4
    var qn_state = $("#PEDcancerDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDcancerDetails', '4');
    }

    //Question 5
    var qn_state = $("#PEDcardiacDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDcardiacDetails', '5');
    }

    //Question 6
    var qn_state = $("#PEDjointpainDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDjointpainDetails', '6');
    }

    //Question 7
    var qn_state = $("#PEDkidneyDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDkidneyDetails', '7');
    }

    //Question 8
    var qn_state = $("#PEDparalysisDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDparalysisDetails', '8');
    }

    //Question 9
    var qn_state = $("#PEDcongenitalDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDcongenitalDetails', '9');
    }

    //Question 10
    var qn_state = $("#PEDHivaidsDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDHivaidsDetails', '10');
    }

    //Question 11
    var qn_state = $("#yesNoExist-yes").is(':checked');
    if(qn_state){
        errors += validate_members('yesNoExist', '11');
    }

    //Question 12
    var qn_state = $("#HEDHealthHospitalized-yes").is(':checked');
    if(qn_state){
        errors += validate_members('HEDHealthHospitalized', '12');
    }

    //Question 13
    var qn_state = $("#HEDHealthClaim-yes").is(':checked');
    if(qn_state){
        errors += validate_members('HEDHealthClaim', '13');
    }

    //Question 14
    var qn_state = $("#HEDHealthDeclined-yes").is(':checked');
    if(qn_state){
        errors += validate_members('HEDHealthDeclined', '14');
    }

    //Question 15
    var qn_state = $("#HEDHealthCovered-yes").is(':checked');
    if(qn_state){
        errors += validate_members('HEDHealthCovered', '15');
    }

    //Question 16
    var qn_state = $("#PEDotherDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDotherDetails', '16');
    }

    //Question 17
    var qn_state = $("#PEDRespiratoryDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDRespiratoryDetails', '17');
    }

    //Question 18
    var qn_state = $("#PEDEndoDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDEndoDetails', '18');
    }

    //Question 19
    var qn_state = $("#PEDillnessDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDillnessDetails', '19');
    }

    //Question 20
    var qn_state = $("#PEDSurgeryDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDSurgeryDetails', '20');
    }

    //Question 21
    var qn_state = $("#PEDSmokeDetails-yes").is(':checked');
    if(qn_state){
        errors += validate_members('PEDSmokeDetails', '21');
    }

    return $.trim(errors);
}

function validate_members(type,no){
    member_flag   = true;
    required_flag = true;
    errors = '';
        // Member 1
        id = '#' + type + '_0_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_0_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_0_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_0_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }
        }

        // Member 2
        id = '#' + type + '_1_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_1_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_1_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_1_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }
        }

        // Member 3
        id = '#' + type + '_2_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_2_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_2_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_2_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }

        }

        // Member 4
        id = '#' + type + '_3_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_3_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_3_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_3_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }
        }

        // Member 5
        id = '#' + type + '_4_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_4_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_4_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_4_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }
        }

        // Member 6
        id = '#' + type + '_5_since_yes';
        member_state = $(id).is(':checked');
        if(member_state){
            member_flag  = false;
            id = '#' + type + '_5_since_month';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_5_since_year';
            val = $(id).val();
            if(val == null || val == ''){
                required_flag = false;
            }
            id = '#' + type + '_5_details';
            if($(id).length){
                val = $(id).val();
                if(val == null || val == ''){
                    required_flag = false;
                }

            }
        }

        if(member_flag){
            errors = "Please select a member for Question "+ no +" <br>";
        }
        if(!member_flag && !required_flag){
            errors = "Please fill the required details for Question "+ no +" <br>";
        }

        return errors;
}

// Question 1
$(document).on('click', '#PEDdiabetesDetails-yes', function(e) {
    var state = $("#PEDdiabetesDetails-yes").is(':checked');
    set_member_name('PEDdiabetesDetails');
    if(state){
        $("#PEDdiabetesDetails_q_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_q_container").fadeOut();
    }
});

// Member 1 click
$(document).on('click', '#PEDdiabetesDetails_0_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_0_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_0_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDdiabetesDetails_1_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_1_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_1_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDdiabetesDetails_2_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_2_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_2_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDdiabetesDetails_3_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_3_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_3_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDdiabetesDetails_4_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_4_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_4_since_year_container").fadeIn();
        
    }
    else{
         $("#PEDdiabetesDetails_4_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDdiabetesDetails_5_since_yes', function(e) {
    var state = $("#PEDdiabetesDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDdiabetesDetails_5_since_month_container").fadeIn();
        $("#PEDdiabetesDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDdiabetesDetails_5_since_month_container").fadeOut();
        $("#PEDdiabetesDetails_5_since_year_container").fadeOut();    
    }
});

// Question 2
$(document).on('click', '#PEDhyperTensionDetails-yes', function(e) {
    var state = $("#PEDhyperTensionDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDhyperTensionDetails');
    if(state)
        $("#PEDhyperTensionDetails_q_container").fadeIn();
    else
        $("#PEDhyperTensionDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDhyperTensionDetails_0_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_0_since_year_container").fadeIn();
        $("#PEDhyperTensionDetails_0_since_month_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_0_since_year_container").fadeOut();
        $("#PEDhyperTensionDetails_0_since_month_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDhyperTensionDetails_1_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_1_since_month_container").fadeIn();
        $("#PEDhyperTensionDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_1_since_month_container").fadeOut();
        $("#PEDhyperTensionDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDhyperTensionDetails_2_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_2_since_month_container").fadeIn();
        $("#PEDhyperTensionDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_2_since_month_container").fadeOut();
        $("#PEDhyperTensionDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDhyperTensionDetails_3_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_3_since_month_container").fadeIn();
        $("#PEDhyperTensionDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_3_since_month_container").fadeOut();
        $("#PEDhyperTensionDetails_3_since_year_container").fadeOut();

    }
});

// Member 5 click
$(document).on('click', '#PEDhyperTensionDetails_4_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_4_since_month_container").fadeIn();
        $("#PEDhyperTensionDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_4_since_month_container").fadeOut();
        $("#PEDhyperTensionDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDhyperTensionDetails_5_since_yes', function(e) {
    var state = $("#PEDhyperTensionDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDhyperTensionDetails_5_since_month_container").fadeIn();
        $("#PEDhyperTensionDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDhyperTensionDetails_5_since_month_container").fadeOut();
        $("#PEDhyperTensionDetails_5_since_year_container").fadeOut();
    }
});

// Question 3
$(document).on('click', '#PEDliverDetails-yes', function(e) {
    var state = $("#PEDliverDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDliverDetails');
    if(state)
        $("#PEDliverDetails_q_container").fadeIn();
    else
        $("#PEDliverDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDliverDetails_0_since_yes', function(e) {
    var state = $("#PEDliverDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_0_since_month_container").fadeIn();
        $("#PEDliverDetails_0_since_year_container").fadeIn();
    }
    else{
        $("#PEDliverDetails_0_since_month_container").fadeOut();
        $("#PEDliverDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDliverDetails_1_since_yes', function(e) {
    var state = $("#PEDliverDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_1_since_month_container").fadeIn();
        $("#PEDliverDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDliverDetails_1_since_month_container").fadeOut();
        $("#PEDliverDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDliverDetails_2_since_yes', function(e) {
    var state = $("#PEDliverDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_2_since_month_container").fadeIn();
        $("#PEDliverDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDliverDetails_2_since_month_container").fadeOut();
        $("#PEDliverDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDliverDetails_3_since_yes', function(e) {
    var state = $("#PEDliverDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_3_since_month_container").fadeIn();
        $("#PEDliverDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDliverDetails_3_since_month_container").fadeOut();
        $("#PEDliverDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDliverDetails_4_since_yes', function(e) {
    var state = $("#PEDliverDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_4_since_month_container").fadeIn();
        $("#PEDliverDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDliverDetails_4_since_month_container").fadeOut();
        $("#PEDliverDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDliverDetails_5_since_yes', function(e) {
    var state = $("#PEDliverDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDliverDetails_5_since_month_container").fadeIn();
        $("#PEDliverDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDliverDetails_5_since_month_container").fadeOut();
        $("#PEDliverDetails_5_since_year_container").fadeOut();
    }
});

// Question 4
$(document).on('click', '#PEDcancerDetails-yes', function(e) {
    var state = $("#PEDcancerDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDcancerDetails');
    if(state)
        $("#PEDcancerDetails_q_container").fadeIn();
    else
        $("#PEDcancerDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDcancerDetails_0_since_yes', function(e) {
    var state = $("#PEDcancerDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_0_since_month_container").fadeIn();
        $("#PEDcancerDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_0_since_month_container").fadeOut();
        $("#PEDcancerDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDcancerDetails_1_since_yes', function(e) {
    var state = $("#PEDcancerDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_1_since_month_container").fadeIn();
        $("#PEDcancerDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_1_since_month_container").fadeOut();
        $("#PEDcancerDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDcancerDetails_2_since_yes', function(e) {
    var state = $("#PEDcancerDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_2_since_month_container").fadeIn();
        $("#PEDcancerDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_2_since_month_container").fadeOut();
        $("#PEDcancerDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDcancerDetails_3_since_yes', function(e) {
    var state = $("#PEDcancerDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_3_since_month_container").fadeIn();
        $("#PEDcancerDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_3_since_month_container").fadeOut();
        $("#PEDcancerDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDcancerDetails_4_since_yes', function(e) {
    var state = $("#PEDcancerDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_4_since_month_container").fadeIn();
        $("#PEDcancerDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_4_since_month_container").fadeOut();
        $("#PEDcancerDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDcancerDetails_5_since_yes', function(e) {
    var state = $("#PEDcancerDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDcancerDetails_5_since_month_container").fadeIn();
        $("#PEDcancerDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcancerDetails_5_since_month_container").fadeOut();
        $("#PEDcancerDetails_5_since_year_container").fadeOut();
    }
});

// Question 5
$(document).on('click', '#PEDcardiacDetails-yes', function(e) {
    var state = $("#PEDcardiacDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDcardiacDetails');
    if(state)
        $("#PEDcardiacDetails_q_container").fadeIn();
    else
        $("#PEDcardiacDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDcardiacDetails_0_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_0_since_month_container").fadeIn();
        $("#PEDcardiacDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_0_since_month_container").fadeOut();
        $("#PEDcardiacDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDcardiacDetails_1_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_1_since_month_container").fadeIn();
        $("#PEDcardiacDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_1_since_month_container").fadeOut();
        $("#PEDcardiacDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDcardiacDetails_2_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_2_since_month_container").fadeIn();
        $("#PEDcardiacDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_2_since_month_container").fadeOut();
        $("#PEDcardiacDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDcardiacDetails_3_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_3_since_month_container").fadeIn();
        $("#PEDcardiacDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_3_since_month_container").fadeOut();
        $("#PEDcardiacDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDcardiacDetails_4_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_4_since_month_container").fadeIn();
        $("#PEDcardiacDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_4_since_month_container").fadeOut();
        $("#PEDcardiacDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDcardiacDetails_5_since_yes', function(e) {
    var state = $("#PEDcardiacDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDcardiacDetails_5_since_month_container").fadeIn();
        $("#PEDcardiacDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcardiacDetails_5_since_month_container").fadeOut();
        $("#PEDcardiacDetails_5_since_year_container").fadeOut();
    }
})

// Question 6
$(document).on('click', '#PEDjointpainDetails-yes', function(e) {
    var state = $("#PEDjointpainDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDjointpainDetails');
    if(state)
        $("#PEDjointpainDetails_q_container").fadeIn();
    else
        $("#PEDjointpainDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDjointpainDetails_0_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_0_since_month_container").fadeIn();
        $("#PEDjointpainDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_0_since_month_container").fadeOut();
        $("#PEDjointpainDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDjointpainDetails_1_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_1_since_month_container").fadeIn();
        $("#PEDjointpainDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_1_since_month_container").fadeOut();
        $("#PEDjointpainDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDjointpainDetails_2_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_2_since_month_container").fadeIn();
        $("#PEDjointpainDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_2_since_month_container").fadeOut();
        $("#PEDjointpainDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDjointpainDetails_3_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_3_since_month_container").fadeIn();
        $("#PEDjointpainDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_3_since_month_container").fadeOut();
        $("#PEDjointpainDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDjointpainDetails_4_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_4_since_month_container").fadeIn();
        $("#PEDjointpainDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_4_since_month_container").fadeOut();
        $("#PEDjointpainDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDjointpainDetails_5_since_yes', function(e) {
    var state = $("#PEDjointpainDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDjointpainDetails_5_since_month_container").fadeIn();
        $("#PEDjointpainDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDjointpainDetails_5_since_month_container").fadeOut();
        $("#PEDjointpainDetails_5_since_year_container").fadeOut();
    }
});

// Question 7
$(document).on('click', '#PEDkidneyDetails-yes', function(e) {
    var state = $("#PEDkidneyDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDkidneyDetails');
    if(state)
        $("#PEDkidneyDetails_q_container").fadeIn();
    else
        $("#PEDkidneyDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDkidneyDetails_0_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_0_since_month_container").fadeIn();
        $("#PEDkidneyDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDkidneyDetails_0_since_month_container").fadeOut();
        $("#PEDkidneyDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDkidneyDetails_1_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_1_since_month_container").fadeIn();
        $("#PEDkidneyDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDkidneyDetails_1_since_month_container").fadeOut();
        $("#PEDkidneyDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDkidneyDetails_2_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_2_since_month_container").fadeIn();
        $("#PEDkidneyDetails_2_since_year_container").fadeIn();
    }
    else{
        $("#PEDkidneyDetails_2_since_month_container").fadeOut();
        $("#PEDkidneyDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDkidneyDetails_3_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_3_since_month_container").fadeIn();
        $("#PEDkidneyDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDkidneyDetails_3_since_month_container").fadeOut();
        $("#PEDkidneyDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDkidneyDetails_4_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_4_since_month_container").fadeIn();
        $("#PEDkidneyDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDkidneyDetails_4_since_month_container").fadeOut();
        $("#PEDkidneyDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDkidneyDetails_5_since_yes', function(e) {
    var state = $("#PEDkidneyDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDkidneyDetails_5_since_month_container").fadeIn();
        $("#PEDkidneyDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDkidneyDetails_5_since_month_container").fadeOut();
        $("#PEDkidneyDetails_5_since_year_container").fadeOut();
    }
});

// Question 8
$(document).on('click', '#PEDparalysisDetails-yes', function(e) {
    var state = $("#PEDparalysisDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDparalysisDetails');
    if(state)
        $("#PEDparalysisDetails_q_container").fadeIn();
    else
        $("#PEDparalysisDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDparalysisDetails_0_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_0_since_month_container").fadeIn();
        $("#PEDparalysisDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_0_since_month_container").fadeOut();
        $("#PEDparalysisDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDparalysisDetails_1_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_1_since_month_container").fadeIn();
        $("#PEDparalysisDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_1_since_month_container").fadeOut();
        $("#PEDparalysisDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDparalysisDetails_2_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_2_since_month_container").fadeIn();
        $("#PEDparalysisDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_2_since_month_container").fadeOut();
        $("#PEDparalysisDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDparalysisDetails_3_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_3_since_month_container").fadeIn();
        $("#PEDparalysisDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_3_since_month_container").fadeOut();
        $("#PEDparalysisDetails_3_since_year_container").fadeOut();    
    }
});

// Member 5 click
$(document).on('click', '#PEDparalysisDetails_4_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_4_since_month_container").fadeIn();
        $("#PEDparalysisDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_4_since_month_container").fadeOut();
        $("#PEDparalysisDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDparalysisDetails_5_since_yes', function(e) {
    var state = $("#PEDparalysisDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDparalysisDetails_5_since_month_container").fadeIn();
        $("#PEDparalysisDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDparalysisDetails_5_since_month_container").fadeOut();
        $("#PEDparalysisDetails_5_since_year_container").fadeOut();
    }
});

// Question 9
$(document).on('click', '#PEDcongenitalDetails-yes', function(e) {
    var state = $("#PEDcongenitalDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDcongenitalDetails');
    if(state)
        $("#PEDcongenitalDetails_q_container").fadeIn();
    else
        $("#PEDcongenitalDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDcongenitalDetails_0_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_0_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_0_since_year_container").fadeIn();
    }
    else{
        $("#PEDcongenitalDetails_0_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDcongenitalDetails_1_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_1_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcongenitalDetails_1_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDcongenitalDetails_2_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_2_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcongenitalDetails_2_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDcongenitalDetails_3_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_3_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcongenitalDetails_3_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDcongenitalDetails_4_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_4_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcongenitalDetails_4_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDcongenitalDetails_5_since_yes', function(e) {
    var state = $("#PEDcongenitalDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDcongenitalDetails_5_since_month_container").fadeIn();
        $("#PEDcongenitalDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDcongenitalDetails_5_since_month_container").fadeOut();
        $("#PEDcongenitalDetails_5_since_year_container").fadeOut();
    }
});

// Question 10
$(document).on('click', '#PEDHivaidsDetails-yes', function(e) {
    var state = $("#PEDHivaidsDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDHivaidsDetails');
    if(state)
        $("#PEDHivaidsDetails_q_container").fadeIn();
    else
        $("#PEDHivaidsDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDHivaidsDetails_0_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_0_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_0_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDHivaidsDetails_1_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_1_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_1_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDHivaidsDetails_2_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_2_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_2_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDHivaidsDetails_3_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_3_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_3_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDHivaidsDetails_4_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_4_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_4_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDHivaidsDetails_5_since_yes', function(e) {
    var state = $("#PEDHivaidsDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDHivaidsDetails_5_since_month_container").fadeIn();
        $("#PEDHivaidsDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDHivaidsDetails_5_since_month_container").fadeOut();
        $("#PEDHivaidsDetails_5_since_year_container").fadeOut();
    }
});

// Question 11
$(document).on('click', '#yesNoExist-yes', function(e) {
    var state = $("#yesNoExist-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('yesNoExist');
    if(state)
        $("#yesNoExist_q_container").fadeIn();
    else
        $("#yesNoExist_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#yesNoExist_0_since_yes', function(e) {
    var state = $("#yesNoExist_0_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_0_since_month_container").fadeIn();
        $("#yesNoExist_0_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_0_since_month_container").fadeOut();
        $("#yesNoExist_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#yesNoExist_1_since_yes', function(e) {
    var state = $("#yesNoExist_1_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_1_since_month_container").fadeIn();
        $("#yesNoExist_1_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_1_since_month_container").fadeOut();
        $("#yesNoExist_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#yesNoExist_2_since_yes', function(e) {
    var state = $("#yesNoExist_2_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_2_since_month_container").fadeIn();
        $("#yesNoExist_2_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_2_since_month_container").fadeOut();
        $("#yesNoExist_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#yesNoExist_3_since_yes', function(e) {
    var state = $("#yesNoExist_3_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_3_since_month_container").fadeIn();
        $("#yesNoExist_3_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_3_since_month_container").fadeOut();
        $("#yesNoExist_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#yesNoExist_4_since_yes', function(e) {
    var state = $("#yesNoExist_4_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_4_since_month_container").fadeIn();
        $("#yesNoExist_4_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_4_since_month_container").fadeOut();
        $("#yesNoExist_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#yesNoExist_5_since_yes', function(e) {
    var state = $("#yesNoExist_5_since_yes").is(':checked');
    if(state){
        $("#yesNoExist_5_since_month_container").fadeIn();
        $("#yesNoExist_5_since_year_container").fadeIn();
        
    }
    else{
        $("#yesNoExist_5_since_month_container").fadeOut();
        $("#yesNoExist_5_since_year_container").fadeOut();
    }
});

// Question 12
$(document).on('click', '#HEDHealthHospitalized-yes', function(e) {
    var state = $("#HEDHealthHospitalized-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('HEDHealthHospitalized');
    if(state)
        $("#HEDHealthHospitalized_q_container").fadeIn();
    else
        $("#HEDHealthHospitalized_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#HEDHealthHospitalized_0_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_0_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_0_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_0_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_0_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#HEDHealthHospitalized_1_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_1_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_1_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_1_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_1_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#HEDHealthHospitalized_2_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_2_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_2_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_2_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_2_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#HEDHealthHospitalized_3_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_3_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_3_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_3_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_3_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#HEDHealthHospitalized_4_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_4_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_4_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_4_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_4_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#HEDHealthHospitalized_5_since_yes', function(e) {
    var state = $("#HEDHealthHospitalized_5_since_yes").is(':checked');
    if(state){
        $("#HEDHealthHospitalized_5_since_month_container").fadeIn();
        $("#HEDHealthHospitalized_5_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthHospitalized_5_since_month_container").fadeOut();
        $("#HEDHealthHospitalized_5_since_year_container").fadeOut();
    }
});

// Question 13
$(document).on('click', '#HEDHealthClaim-yes', function(e) {
    var state = $("#HEDHealthClaim-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('HEDHealthClaim');
    if(state)
        $("#HEDHealthClaim_q_container").fadeIn();
    else
        $("#HEDHealthClaim_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#HEDHealthClaim_0_since_yes', function(e) {
    var state = $("#HEDHealthClaim_0_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_0_since_month_container").fadeIn();
        $("#HEDHealthClaim_0_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_0_since_month_container").fadeOut();
        $("#HEDHealthClaim_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#HEDHealthClaim_1_since_yes', function(e) {
    var state = $("#HEDHealthClaim_1_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_1_since_month_container").fadeIn();
        $("#HEDHealthClaim_1_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_1_since_month_container").fadeOut();
        $("#HEDHealthClaim_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#HEDHealthClaim_2_since_yes', function(e) {
    var state = $("#HEDHealthClaim_2_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_2_since_month_container").fadeIn();
        $("#HEDHealthClaim_2_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_2_since_month_container").fadeOut();
        $("#HEDHealthClaim_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#HEDHealthClaim_3_since_yes', function(e) {
    var state = $("#HEDHealthClaim_3_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_3_since_month_container").fadeIn();
        $("#HEDHealthClaim_3_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_3_since_month_container").fadeOut();
        $("#HEDHealthClaim_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#HEDHealthClaim_4_since_yes', function(e) {
    var state = $("#HEDHealthClaim_4_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_4_since_month_container").fadeIn();
        $("#HEDHealthClaim_4_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_4_since_month_container").fadeOut();
        $("#HEDHealthClaim_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#HEDHealthClaim_5_since_yes', function(e) {
    var state = $("#HEDHealthClaim_5_since_yes").is(':checked');
    if(state){
        $("#HEDHealthClaim_5_since_month_container").fadeIn();
        $("#HEDHealthClaim_5_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthClaim_5_since_month_container").fadeOut();
        $("#HEDHealthClaim_5_since_year_container").fadeOut();
    }
});

// Question 14
$(document).on('click', '#HEDHealthDeclined-yes', function(e) {
    var state = $("#HEDHealthDeclined-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('HEDHealthDeclined');
    if(state)
        $("#HEDHealthDeclined_q_container").fadeIn();
    else
        $("#HEDHealthDeclined_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#HEDHealthDeclined_0_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_0_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_0_since_month_container").fadeIn();
        $("#HEDHealthDeclined_0_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthDeclined_0_since_month_container").fadeOut();
        $("#HEDHealthDeclined_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#HEDHealthDeclined_1_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_1_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_1_since_month_container").fadeIn();
        $("#HEDHealthDeclined_1_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthDeclined_1_since_month_container").fadeOut();
        $("#HEDHealthDeclined_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#HEDHealthDeclined_2_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_2_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_2_since_month_container").fadeIn();
        $("#HEDHealthDeclined_2_since_year_container").fadeIn();
    }
    else{
        $("#HEDHealthDeclined_2_since_month_container").fadeOut();
        $("#HEDHealthDeclined_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#HEDHealthDeclined_3_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_3_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_3_since_month_container").fadeIn();
        $("#HEDHealthDeclined_3_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthDeclined_3_since_month_container").fadeOut();
        $("#HEDHealthDeclined_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#HEDHealthDeclined_4_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_4_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_4_since_month_container").fadeIn();
        $("#HEDHealthDeclined_4_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthDeclined_4_since_month_container").fadeOut();
        $("#HEDHealthDeclined_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#HEDHealthDeclined_5_since_yes', function(e) {
    var state = $("#HEDHealthDeclined_5_since_yes").is(':checked');
    if(state){
        $("#HEDHealthDeclined_5_since_month_container").fadeIn();
        $("#HEDHealthDeclined_5_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthDeclined_5_since_month_container").fadeOut();
        $("#HEDHealthDeclined_5_since_year_container").fadeOut();
    }
});

// Question 15
$(document).on('click', '#HEDHealthCovered-yes', function(e) {
    var state = $("#HEDHealthCovered-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('HEDHealthCovered');
    if(state)
        $("#HEDHealthCovered_q_container").fadeIn();
    else
        $("#HEDHealthCovered_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#HEDHealthCovered_0_since_yes', function(e) {
    var state = $("#HEDHealthCovered_0_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_0_since_month_container").fadeIn();
        $("#HEDHealthCovered_0_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_0_since_month_container").fadeOut();
        $("#HEDHealthCovered_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#HEDHealthCovered_1_since_yes', function(e) {
    var state = $("#HEDHealthCovered_1_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_1_since_month_container").fadeIn();
        $("#HEDHealthCovered_1_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_1_since_month_container").fadeOut();
        $("#HEDHealthCovered_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#HEDHealthCovered_2_since_yes', function(e) {
    var state = $("#HEDHealthCovered_2_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_2_since_month_container").fadeIn();
        $("#HEDHealthCovered_2_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_2_since_month_container").fadeOut();
        $("#HEDHealthCovered_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#HEDHealthCovered_3_since_yes', function(e) {
    var state = $("#HEDHealthCovered_3_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_3_since_month_container").fadeIn();
        $("#HEDHealthCovered_3_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_3_since_month_container").fadeOut();
        $("#HEDHealthCovered_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#HEDHealthCovered_4_since_yes', function(e) {
    var state = $("#HEDHealthCovered_4_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_4_since_month_container").fadeIn();
        $("#HEDHealthCovered_4_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_4_since_month_container").fadeOut();
        $("#HEDHealthCovered_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#HEDHealthCovered_5_since_yes', function(e) {
    var state = $("#HEDHealthCovered_5_since_yes").is(':checked');
    if(state){
        $("#HEDHealthCovered_5_since_month_container").fadeIn();
        $("#HEDHealthCovered_5_since_year_container").fadeIn();
        
    }
    else{
        $("#HEDHealthCovered_5_since_month_container").fadeOut();
        $("#HEDHealthCovered_5_since_year_container").fadeOut();
    }
});


// Question 16
$(document).on('click', '#PEDotherDetails-yes', function(e) {
    var state = $("#PEDotherDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDotherDetails');
    if(state)
        $("#PEDotherDetails_q_container").fadeIn();
    else
        $("#PEDotherDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDotherDetails_0_since_yes', function(e) {
    var state = $("#PEDotherDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_0_since_month_container").fadeIn();
        $("#PEDotherDetails_0_since_year_container").fadeIn();
        $("#PEDotherDetails_0_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_0_since_month_container").fadeOut();
        $("#PEDotherDetails_0_since_year_container").fadeOut();
        $("#PEDotherDetails_0_details").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDotherDetails_1_since_yes', function(e) {
    var state = $("#PEDotherDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_1_since_month_container").fadeIn();
        $("#PEDotherDetails_1_since_year_container").fadeIn();
        $("#PEDotherDetails_1_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_1_since_month_container").fadeOut();
        $("#PEDotherDetails_1_since_year_container").fadeOut();
        $("#PEDotherDetails_1_details").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDotherDetails_2_since_yes', function(e) {
    var state = $("#PEDotherDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_2_since_month_container").fadeIn();
        $("#PEDotherDetails_2_since_year_container").fadeIn();
        $("#PEDotherDetails_2_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_2_since_month_container").fadeOut();
        $("#PEDotherDetails_2_since_year_container").fadeOut();
        $("#PEDotherDetails_2_details").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDotherDetails_3_since_yes', function(e) {
    var state = $("#PEDotherDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_3_since_month_container").fadeIn();
        $("#PEDotherDetails_3_since_year_container").fadeIn();
        $("#PEDotherDetails_3_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_3_since_month_container").fadeOut();
        $("#PEDotherDetails_3_since_year_container").fadeOut();
        $("#PEDotherDetails_3_details").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDotherDetails_4_since_yes', function(e) {
    var state = $("#PEDotherDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_4_since_month_container").fadeIn();
        $("#PEDotherDetails_4_since_year_container").fadeIn();
        $("#PEDotherDetails_4_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_4_since_month_container").fadeOut();
        $("#PEDotherDetails_4_since_year_container").fadeOut();
        $("#PEDotherDetails_4_details").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDotherDetails_5_since_yes', function(e) {
    var state = $("#PEDotherDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDotherDetails_5_since_month_container").fadeIn();
        $("#PEDotherDetails_5_since_year_container").fadeIn();
        $("#PEDotherDetails_5_details").fadeIn();
        
    }
    else{
        $("#PEDotherDetails_5_since_month_container").fadeOut();
        $("#PEDotherDetails_5_since_year_container").fadeOut();
        $("#PEDotherDetails_5_details").fadeOut();
    }
});


// Question 17
$(document).on('click', '#PEDRespiratoryDetails-yes', function(e) {
    var state = $("#PEDRespiratoryDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDRespiratoryDetails');
    if(state)
        $("#PEDRespiratoryDetails_q_container").fadeIn();
    else
        $("#PEDRespiratoryDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDRespiratoryDetails_0_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_0_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDRespiratoryDetails_0_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDRespiratoryDetails_1_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_1_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDRespiratoryDetails_1_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDRespiratoryDetails_2_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_2_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDRespiratoryDetails_2_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDRespiratoryDetails_3_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_3_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDRespiratoryDetails_3_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDRespiratoryDetails_4_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_4_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDRespiratoryDetails_4_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDRespiratoryDetails_5_since_yes', function(e) {
    var state = $("#PEDRespiratoryDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDRespiratoryDetails_5_since_month_container").fadeIn();
        $("#PEDRespiratoryDetails_5_since_year_container").fadeIn();
    }
    else{
        $("#PEDRespiratoryDetails_5_since_month_container").fadeOut();
        $("#PEDRespiratoryDetails_5_since_year_container").fadeOut();
    }
});

// Question 18
$(document).on('click', '#PEDEndoDetails-yes', function(e) {
    var state = $("#PEDEndoDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDEndoDetails');
    if(state)
        $("#PEDEndoDetails_q_container").fadeIn();
    else
        $("#PEDEndoDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDEndoDetails_0_since_yes', function(e) {
    var state = $("#PEDEndoDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_0_since_month_container").fadeIn();
        $("#PEDEndoDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDEndoDetails_0_since_month_container").fadeOut();
        $("#PEDEndoDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDEndoDetails_1_since_yes', function(e) {
    var state = $("#PEDEndoDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_1_since_month_container").fadeIn();
        $("#PEDEndoDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDEndoDetails_1_since_month_container").fadeOut();
        $("#PEDEndoDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDEndoDetails_2_since_yes', function(e) {
    var state = $("#PEDEndoDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_2_since_month_container").fadeIn();
        $("#PEDEndoDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDEndoDetails_2_since_month_container").fadeOut();
        $("#PEDEndoDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDEndoDetails_3_since_yes', function(e) {
    var state = $("#PEDEndoDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_3_since_month_container").fadeIn();
        $("#PEDEndoDetails_3_since_year_container").fadeIn();
    }
    else{
        $("#PEDEndoDetails_3_since_month_container").fadeOut();
        $("#PEDEndoDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDEndoDetails_4_since_yes', function(e) {
    var state = $("#PEDEndoDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_4_since_month_container").fadeIn();
        $("#PEDEndoDetails_4_since_year_container").fadeIn();
    }
    else{
        $("#PEDEndoDetails_4_since_month_container").fadeOut();
        $("#PEDEndoDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDEndoDetails_5_since_yes', function(e) {
    var state = $("#PEDEndoDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDEndoDetails_5_since_month_container").fadeIn();
        $("#PEDEndoDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDEndoDetails_5_since_month_container").fadeOut();
        $("#PEDEndoDetails_5_since_year_container").fadeOut();
    }
});

// Question 19
$(document).on('click', '#PEDillnessDetails-yes', function(e) {
    var state = $("#PEDillnessDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDillnessDetails');
    if(state)
        $("#PEDillnessDetails_q_container").fadeIn();
    else
        $("#PEDillnessDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDillnessDetails_0_since_yes', function(e) {
    var state = $("#PEDillnessDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_0_since_month_container").fadeIn();
        $("#PEDillnessDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDillnessDetails_0_since_month_container").fadeOut();
        $("#PEDillnessDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDillnessDetails_1_since_yes', function(e) {
    var state = $("#PEDillnessDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_1_since_month_container").fadeIn();
        $("#PEDillnessDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDillnessDetails_1_since_month_container").fadeOut();
        $("#PEDillnessDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDillnessDetails_2_since_yes', function(e) {
    var state = $("#PEDillnessDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_2_since_month_container").fadeIn();
        $("#PEDillnessDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDillnessDetails_2_since_month_container").fadeOut();
        $("#PEDillnessDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDillnessDetails_3_since_yes', function(e) {
    var state = $("#PEDillnessDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_3_since_month_container").fadeIn();
        $("#PEDillnessDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDillnessDetails_3_since_month_container").fadeOut();
        $("#PEDillnessDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDillnessDetails_4_since_yes', function(e) {
    var state = $("#PEDillnessDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_4_since_month_container").fadeIn();
        $("#PEDillnessDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDillnessDetails_4_since_month_container").fadeOut();
        $("#PEDillnessDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDillnessDetails_5_since_yes', function(e) {
    var state = $("#PEDillnessDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDillnessDetails_5_since_month_container").fadeIn();
        $("#PEDillnessDetails_5_since_year_container").fadeIn();
    }
    else{
        $("#PEDillnessDetails_5_since_month_container").fadeOut();
        $("#PEDillnessDetails_5_since_year_container").fadeOut();
    }
});

// Question 20
$(document).on('click', '#PEDSurgeryDetails-yes', function(e) {
    var state = $("#PEDSurgeryDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDSurgeryDetails');
    if(state)
        $("#PEDSurgeryDetails_q_container").fadeIn();
    else
        $("#PEDSurgeryDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDSurgeryDetails_0_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_0_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_0_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_0_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_0_since_year_container").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDSurgeryDetails_1_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_1_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_1_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_1_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_1_since_year_container").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDSurgeryDetails_2_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_2_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_2_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_2_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_2_since_year_container").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDSurgeryDetails_3_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_3_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_3_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_3_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_3_since_year_container").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDSurgeryDetails_4_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_4_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_4_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_4_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_4_since_year_container").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDSurgeryDetails_5_since_yes', function(e) {
    var state = $("#PEDSurgeryDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDSurgeryDetails_5_since_month_container").fadeIn();
        $("#PEDSurgeryDetails_5_since_year_container").fadeIn();
        
    }
    else{
        $("#PEDSurgeryDetails_5_since_month_container").fadeOut();
        $("#PEDSurgeryDetails_5_since_year_container").fadeOut();
    }
});

// Question 21
$(document).on('click', '#PEDSmokeDetails-yes', function(e) {
    var state = $("#PEDSmokeDetails-yes").is(':checked');
    var id = $(this).attr('id');
    set_member_name('PEDSmokeDetails');
    if(state)
        $("#PEDSmokeDetails_q_container").fadeIn();
    else
        $("#PEDSmokeDetails_q_container").fadeOut();
});

// Member 1 click
$(document).on('click', '#PEDSmokeDetails_0_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_0_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_0_since_month_container").fadeIn();
        $("#PEDSmokeDetails_0_since_year_container").fadeIn();
        $("#PEDSmokeDetails_0_details").fadeIn();

    }
    else{
        $("#PEDSmokeDetails_0_since_month_container").fadeOut();
        $("#PEDSmokeDetails_0_since_year_container").fadeOut();
        $("#PEDSmokeDetails_0_details").fadeOut();
    }
});

// Member 2 click
$(document).on('click', '#PEDSmokeDetails_1_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_1_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_1_since_month_container").fadeIn();
        $("#PEDSmokeDetails_1_since_year_container").fadeIn();
        $("#PEDSmokeDetails_1_details").fadeIn();
        
    }
    else{
        $("#PEDSmokeDetails_1_since_month_container").fadeOut();
        $("#PEDSmokeDetails_1_since_year_container").fadeOut();
        $("#PEDSmokeDetails_1_details").fadeOut();
    }
});

// Member 3 click
$(document).on('click', '#PEDSmokeDetails_2_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_2_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_2_since_month_container").fadeIn();
        $("#PEDSmokeDetails_2_since_year_container").fadeIn();
        $("#PEDSmokeDetails_2_details").fadeIn();
        
    }
    else{
        $("#PEDSmokeDetails_2_since_month_container").fadeOut();
        $("#PEDSmokeDetails_2_since_year_container").fadeOut();
        $("#PEDSmokeDetails_2_since").fadeOut();
    }
});

// Member 4 click
$(document).on('click', '#PEDSmokeDetails_3_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_3_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_3_since_month_container").fadeIn();
        $("#PEDSmokeDetails_3_since_year_container").fadeIn();
        $("#PEDSmokeDetails_3_details").fadeIn();
        
    }
    else{
        $("#PEDSmokeDetails_3_since_month_container").fadeOut();
        $("#PEDSmokeDetails_3_since_year_container").fadeOut();
        $("#PEDSmokeDetails_3_details").fadeOut();
    }
});

// Member 5 click
$(document).on('click', '#PEDSmokeDetails_4_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_4_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_4_since_month_container").fadeIn();
        $("#PEDSmokeDetails_4_since_year_container").fadeIn();
        $("#PEDSmokeDetails_4_details").fadeIn();
        
    }
    else{
        $("#PEDSmokeDetails_4_since_month_container").fadeOut();
        $("#PEDSmokeDetails_4_since_year_container").fadeOut();
        $("#PEDSmokeDetails_4_details").fadeOut();
    }
});

// Member 6 click
$(document).on('click', '#PEDSmokeDetails_5_since_yes', function(e) {
    var state = $("#PEDSmokeDetails_5_since_yes").is(':checked');
    if(state){
        $("#PEDSmokeDetails_5_since_month_container").fadeIn();
        $("#PEDSmokeDetails_5_since_year_container").fadeIn();
        $("#PEDSmokeDetails_5_details").fadeIn();
        
    }
    else{
        $("#PEDSmokeDetails_5_since_month_container").fadeOut();
        $("#PEDSmokeDetails_5_since_year_container").fadeOut();
        $("#PEDSmokeDetails_5_details").fadeOut();
    }
});

$(document).ready(function() {  
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
                
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
     }); 

   
