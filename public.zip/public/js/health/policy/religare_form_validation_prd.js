function validateProposal(a) {

    id = $(".tab-pane.active").attr('id');
    field = $("#" + id + " :input:visible").serializeArray();
    fields = common.serilazeArrayToArray(field); 
    fields.id = id;
    fields._token = $('#_token').val();
    $return_type = !0, errors = "";
    var b = 1,
        c = $("#membercount").val();
    if ("insured" === a) {
        var d = $("#firstname").val();
        for (null == d, j = 0; j < c; j++) {
            null == $.trim($("#firstname" + b).val()) || "" == $.trim($("#firstname" + b).val()) || " " == $.trim($("#firstname" + b).val()) ? (errors += 1 == c ? "First Name cannot be empty<br/>" : "Member " + b + ": Firstname cannot be empty<br/>", $return_type = !1) : $("#firstname" + b).val() && ($("#firstname" + b).val().match(/^[a-zA-Z ]{3,70}$/i) || (errors += 1 == c ? "First Name should only contain alphabets<br/>" : "Member " + b + ": First name should only contain min 3 alphabets<br/>", $return_type = !1)), 
            null == $.trim($("#lastname" + b).val()) || "" == $.trim($("#lastname" + b).val()) || " " == $.trim($("#lastname" + b).val()) ? (errors += 1 == c ? "Lastname field cannot be empty<br/>" : "Member " + b + ": Lastname cannot be empty<br/>", $return_type = !1) : $("#lastname" + b).val() && ($("#lastname" + b).val().match(/^[A-z ]+$/i) || (errors += 1 == c ? "Last Name should only contain alphabets<br/>" : "Member " + b + ": Last name should only contain alphabets<br/> ",$return_type = !1)), 
            b++
        }
        if($("#pan").length) {
            null == $("#pan").val() || "" == $("#pan").val() || " " == $("#pan").val() ? (errors += "PAN number should not be empty<br/>", $return_type = !1) : $("#pan").val().match(/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/) || (errors += "Invalid Pan number<br/>", $return_type = !1);
        }
        if($("#aadhaar").length) {
            null == $("#aadhaar").val() || "" == $("#aadhaar").val() || " " == $("#aadhaar").val() ? (errors += "Aadhaar number should not be empty<br/>", $return_type = !1) : $("#aadhaar").val().match(/^\d{4}\-\d{4}\-\d{4}$/) || (errors += "Invalid Aadhaar number<br/>", $return_type = !1);
        }
        return "" != errors && (d = "", overlay_rem(), swal(errors))? '' :(setData(fields)), $return_type
    }

    if ("communication" === a) {
        $return_type = !0, errors = "";
        var f = $("#user_email").val();
        "" == f || null == f || " " == f ?(errors+="Email ID should not be empty<br/>",$return_type=!1):f.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)||(errors+="Invalid Email ID<br/>",$return_type =! 1);
        var g = $("#mobile").val();
        "" == g || null == g || " " == g ? (errors += "Mobile number should not be empty<br/>", $return_type = !1) : g.match(/^[789]\d{9}$/i) || (errors += "Invalid Mobile number<br/>", $return_type = !1);
        var h = $("#houseno").val();
        "" == h || null == h || " " == h ? (errors += "House Name/ Number should not be empty<br/>", $return_type = !1) : h.match(/^[a-zA-Z0-9_./:;//\(), -\s#"]+$/i) ? h.match(/^[a-zA-Z0-9_./:;//\(), -\s#"]{1,35}$/i) || (errors += "House Name / Number should be with in 35 characters<br/>", $return_type = !1) : (errors += "Invalid House Name/ Number<br/>", $return_type = !1);
        
        var i = $("#street").val();
        "" == i || null == i || " " == i ? (errors += "Street Name should not be empty<br/>", $return_type = !1) : i.match(/^[a-zA-Z0-9_./:;//\(), -]+$/i) ? i.match(/^[a-zA-Z0-9_./:;//\(), -]{1,75}$/i) || (errors += "Street address should be with in 35 characters<br/>", $return_type = !1) : (errors += "Invalid Street Name<br/>", $return_type = !1);
        var j = $.trim($("#locality").val());
        "" == j || null == j || " " == j ? (errors += "Locality should not be empty<br/>", $return_type = !1) : j.match(/^[A-z ]+$/i) || (errors += "Invalid Locality Name<br/>", $return_type = !1);
        null == $("#state").val() && (errors += "Please select a State <br/>", $return_type = !1);
        null == $("#city").val() && (errors += "Please select a City <br/>", $return_type = !1);
        
        var m = $.trim($("#cust_pincode").val());
        return "" == m || null == m || " " == m ? (errors += "Pincode should not be empty<br/>", $return_type = !1) : m.match(/^[1-9][0-9]{5}$/i) || (errors += "Invalid Pincode<br/>", $return_type = !1), "" != errors && (d = "", overlay_rem(), swal(errors))? '' :(setData(fields)), $return_type
    }
     
    if ("healthhistory" === a) {
        $return_type = !0, errors = "";
         return "" != errors && (errors += " ", overlay_rem(), swal(errors))? '' :(setData(fields)), $return_type

    }

    if ("nominee_details" === a) {
        $return_type = !0, errors = "";

        var nn = $.trim($("#nomineename").val());
        "" == nn || null == nn || " " == nn ? (errors += "Nominee Name should not be empty<br/>", $return_type = !1) : nn.match(/^[A-z ]+$/i) || (errors += "Nominee name should only contains min 3 letters<br/>", $return_type = !1);
        var na = $("#nomineeage").val();
        "" == na || null == na || " " == na ? (errors += "Nominee Age should not be empty<br/>", $return_type = !1) : na.match(/^[0-9 ]+$/i) || (errors += "Nominee Age should only contains numbers<br/>", $return_type = !1);
        null == $("#nomineerel").val() && (errors += "Please select a Nominee Relationship <br/>", $return_type = !1);
       
        //  Nominee age is below 18 years appointee fields validation       
        var nominee_age = $("#nomineeage").val();

        if(nominee_age != "" && nominee_age <= 17){
        var an = $.trim($("#appointeename").val());
        "" == an || null == an || " " == an ? (errors += "Appointee Name should not be empty<br/>", $return_type = !1) : an.match(/^[A-z ]+$/i) || (errors += "Appointee name should only contains min 3 letters<br/>", $return_type = !1);
        var aa = $("#appointeeage").val();
        "" == aa || null == aa || " " == aa ? (errors += "Appointee Age should not be empty<br/>", $return_type = !1) : aa.match(/^[0-9 ]+$/i) || (errors += "Appointee Age should only contains numbers<br/>", $return_type = !1);
        null == $("#appointeerel").val() && (errors += "Please select a Appointee Relationship <br/>", $return_type = !1);
        }

        return "" != errors && (errors += "", overlay_rem(), swal(errors))? '' :(setData(fields)), $return_type

    }
   

}