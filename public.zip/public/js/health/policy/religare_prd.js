function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form),
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) { 
        if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        }
        // else if(a['status'] == 'elderage'){
        //         confirm(a['status']); } 
        else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
    // }).fail(function(){
    //    common.apiBadReponse();
    });
}


function staticpayment(a) {
    window.location = $("#offline_policy").val()
}


function premiumMismatch(a, b) { 
    basePremium = Math.floor(b.data.PremiumPayable  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.PremiumPayable) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) { 
    data = purposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b, 
    c = $("#product_id").val(), 
    d = $("#insurer_id").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data)
}

// function payment(a) {
//    common.loader_msg(common.msg.payment_redirect), 
//     a.online_purchase_link && (window.location = a.online_purchase_link)
// }

function payment(a) {
    common.loader_rem();
    common.loader_msg(common.msg.payment_redirect); 
    if (a.online_purchase_link) {
       var input_ele = "";
            $.each(a, function(index, val) {
                input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
            });
            input_ele += '<input type="hidden" name="proposalNum" value="'+ a.proposalNum+'" /> ';
            input_ele += '<input type="hidden" name="returnURL" value="'+a.returnURL+'" /> ';
            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='religare_submit'/>";
            var pay_form = '<form id="payment" name="PAYMENTFORM" method="POST" action="' + a.online_purchase_link + '">';
            pay_form += input_ele;
            pay_form += "</form>";
            $("#pay_form").html(pay_form);
            $("#payment").submit();
      
    } else {
        $("#pay_form").html(data.error);
    }
}
            

mem_count = $('#membercount').val();


// 1st Main question starts here

   $(".preexisting-illness").on("click",function(){ 
        $("#insuredmember").val(""),
        0==$(this).val()?$("#insuredmember").show():$("#insuredmember").hide()
    });


    // for(i=1; i <= mem_count; i++){
    //     $('#illness-member'+i).on('click',function () {
    //         $("#diabetesDetails"+i).toggle(this.checked);
    //     });
    // };


 // 1st Sub question starts  

    $('#illness-member1').on('click',function () {
        $("#diabetesDetails1").toggle(this.checked);
    });

    $('#illness-member2').on('click',function () {
        $("#diabetesDetails2").toggle(this.checked);
    });
    
    $('#illness-member3').on('click',function () {
        $("#diabetesDetails3").toggle(this.checked);
    });

    $('#illness-member4').on('click',function () {
        $("#diabetesDetails4").toggle(this.checked);
    });

    $('#illness-member5').on('click',function () {
        $("#diabetesDetails5").toggle(this.checked);
    });

    $('#illness-member6').on('click',function () {
        $("#diabetesDetails6").toggle(this.checked);
    });


 // 2nd Sub question starts   

    $('#hyperTension1').on('click',function () {
        $("#hyperTensionDetails1").toggle(this.checked);
    });

    $('#hyperTension2').on('click',function () {
        $("#hyperTensionDetails2").toggle(this.checked);
    });
    
    $('#hyperTension3').on('click',function () {
        $("#hyperTensionDetails3").toggle(this.checked);
    });

    $('#hyperTension4').on('click',function () {
        $("#hyperTensionDetails4").toggle(this.checked);
    });

    $('#hyperTension5').on('click',function () {
        $("#hyperTensionDetails5").toggle(this.checked);
    });

    $('#hyperTension6').on('click',function () {
        $("#hyperTensionDetails6").toggle(this.checked);
    });

 // 3rd Sub question starts   

    $('#liver1').on('click',function () {
        $("#liverDetails1").toggle(this.checked);
    });

    $('#liver2').on('click',function () {
        $("#liverDetails2").toggle(this.checked);
    });
    
    $('#liver3').on('click',function () {
        $("#liverDetails3").toggle(this.checked);
    });

    $('#liver4').on('click',function () {
        $("#liverDetails4").toggle(this.checked);
    });

    $('#liver5').on('click',function () {
        $("#liverDetails5").toggle(this.checked);
    });

    $('#liver6').on('click',function () {
        $("#liverDetails6").toggle(this.checked);
    });

// 4th sub question starts
    
    $('#cancer1').on('click',function () {
        $("#cancerDetails1").toggle(this.checked);
    });

    $('#cancer2').on('click',function () {
        $("#cancerDetails2").toggle(this.checked);
    });
    
    $('#cancer3').on('click',function () {
        $("#cancerDetails3").toggle(this.checked);
    });

    $('#cancer4').on('click',function () {
        $("#cancerDetails4").toggle(this.checked);
    });

    $('#cancer5').on('click',function () {
        $("#cancerDetails5").toggle(this.checked);
    });

    $('#cancer6').on('click',function () {
        $("#cancerDetails6").toggle(this.checked);
    });

// 5th sub question starts

    $('#cardiac1').on('click',function () {
        $("#cardiacDetails1").toggle(this.checked);
    });

    $('#cardiac2').on('click',function () {
        $("#cardiacDetails2").toggle(this.checked);
    });
    
    $('#cardiac3').on('click',function () {
        $("#cardiacDetails3").toggle(this.checked);
    });

    $('#cardiac4').on('click',function () {
        $("#cardiacDetails4").toggle(this.checked);
    });

    $('#cardiac5').on('click',function () {
        $("#cardiacDetails5").toggle(this.checked);
    });

    $('#cardiac6').on('click',function () {
        $("#cardiacDetails6").toggle(this.checked);
    });

// 6th sub question starts
    $('#jointpain1').on('click',function () {
        $("#jointpainDetails1").toggle(this.checked);
    });

    $('#jointpain2').on('click',function () {
        $("#jointpainDetails2").toggle(this.checked);
    });
    
    $('#jointpain3').on('click',function () {
        $("#jointpainDetails3").toggle(this.checked);
    });

    $('#jointpain4').on('click',function () {
        $("#jointpainDetails4").toggle(this.checked);
    });

    $('#jointpain5').on('click',function () {
        $("#jointpainDetails5").toggle(this.checked);
    });

    $('#jointpain6').on('click',function () {
        $("#jointpainDetails6").toggle(this.checked);
    });

// 7th sub question starts
    $('#kidney1').on('click',function () {
        $("#kidneyDetails1").toggle(this.checked);
    });

    $('#kidney2').on('click',function () {
        $("#kidneyDetails2").toggle(this.checked);
    });
    
    $('#kidney3').on('click',function () {
        $("#kidneyDetails3").toggle(this.checked);
    });

    $('#kidney4').on('click',function () {
        $("#kidneyDetails4").toggle(this.checked);
    });

    $('#kidney5').on('click',function () {
        $("#kidneyDetails5").toggle(this.checked);
    });

    $('#kidney6').on('click',function () {
        $("#kidneyDetails6").toggle(this.checked);
    });

// 8th sub question starts
    $('#paralysis1').on('click',function () {
        $("#paralysisDetails1").toggle(this.checked);
    });

    $('#paralysis2').on('click',function () {
        $("#paralysisDetails2").toggle(this.checked);
    });
    
    $('#paralysis3').on('click',function () {
        $("#paralysisDetails3").toggle(this.checked);
    });

    $('#paralysis4').on('click',function () {
        $("#paralysisDetails4").toggle(this.checked);
    });

    $('#paralysis5').on('click',function () {
        $("#paralysisDetails5").toggle(this.checked);
    });

    $('#paralysis6').on('click',function () {
        $("#paralysisDetails6").toggle(this.checked);
    });
//9th sub question starts
    $('#congenital1').on('click',function () {
        $("#congenitalDetails1").toggle(this.checked);
    });

    $('#congenital2').on('click',function () {
        $("#congenitalDetails2").toggle(this.checked);
    });
    
    $('#congenital3').on('click',function () {
        $("#congenitalDetails3").toggle(this.checked);
    });

    $('#congenital4').on('click',function () {
        $("#congenitalDetails4").toggle(this.checked);
    });

    $('#congenital5').on('click',function () {
        $("#congenitalDetails5").toggle(this.checked);
    });

    $('#congenital6').on('click',function () {
        $("#congenitalDetails6").toggle(this.checked);
    });

// 10th sub question starts
    $('#Hivaids1').on('click',function () {
        $("#HivaidsDetails1").toggle(this.checked);
    });

    $('#Hivaids2').on('click',function () {
        $("#HivaidsDetails2").toggle(this.checked);
    });
    
    $('#Hivaids3').on('click',function () {
        $("#HivaidsDetails3").toggle(this.checked);
    });

    $('#Hivaids4').on('click',function () {
        $("#HivaidsDetails4").toggle(this.checked);
    });

    $('#Hivaids5').on('click',function () {
        $("#HivaidsDetails5").toggle(this.checked);
    });

    $('#Hivaids6').on('click',function () {
        $("#HivaidsDetails6").toggle(this.checked);
    });


    $("#preexistingillness").on("click", function(){
         $(".illnessdetails").prop('checked', false);
         $("#diabetesDetails1").hide();
         $("#diabetesDetails2").hide();
         $("#diabetesDetails3").hide();
         $("#diabetesDetails4").hide();
         $("#diabetesDetails5").hide();
         $("#diabetesDetails6").hide();

         $(".hyperTension").prop('checked', false);
         $("#hyperTensionDetails1").hide();
         $("#hyperTensionDetails2").hide();
         $("#hyperTensionDetails3").hide();
         $("#hyperTensionDetails4").hide();
         $("#hyperTensionDetails5").hide();
         $("#hyperTensionDetails6").hide();

         $(".liver").prop('checked', false);
         $("#liverDetails1").hide();
         $("#liverDetails2").hide();
         $("#liverDetails3").hide();
         $("#liverDetails4").hide();
         $("#liverDetails5").hide();
         $("#liverDetails6").hide();

         $(".cancer").prop('checked', false);
         $("#cancerDetails1").hide();
         $("#cancerDetails2").hide();
         $("#cancerDetails3").hide();
         $("#cancerDetails4").hide();
         $("#cancerDetails5").hide();
         $("#cancerDetails6").hide();

         $(".cardiac").prop('checked', false);
         $("#cardiacDetails1").hide();
         $("#cardiacDetails2").hide();
         $("#cardiacDetails3").hide();
         $("#cardiacDetails4").hide();
         $("#cardiacDetails5").hide();
         $("#cardiacDetails6").hide();

         $(".jointpain").prop('checked', false);
         $("#jointpainDetails1").hide();
         $("#jointpainDetails2").hide();
         $("#jointpainDetails3").hide();
         $("#jointpainDetails4").hide();
         $("#jointpainDetails5").hide();
         $("#jointpainDetails6").hide();

         $(".kidney").prop('checked', false);
         $("#kidneyDetails1").hide();
         $("#kidneyDetails2").hide();
         $("#kidneyDetails3").hide();
         $("#kidneyDetails4").hide();
         $("#kidneyDetails5").hide();
         $("#kidneyDetails6").hide();

         $(".paralysis").prop('checked', false);
         $("#paralysisDetails1").hide();
         $("#paralysisDetails2").hide();
         $("#paralysisDetails3").hide();
         $("#paralysisDetails4").hide();
         $("#paralysisDetails5").hide();
         $("#paralysisDetails6").hide();

         $(".congenital").prop('checked', false);
         $("#congenitalDetails1").hide();
         $("#congenitalDetails2").hide();
         $("#congenitalDetails3").hide();
         $("#congenitalDetails4").hide();
         $("#congenitalDetails5").hide();
         $("#congenitalDetails6").hide();

         $(".Hivaids").prop('checked', false);
         $("#HivaidsDetails1").hide();
         $("#HivaidsDetails2").hide();
         $("#HivaidsDetails3").hide();
         $("#HivaidsDetails4").hide();
         $("#HivaidsDetails5").hide();
         $("#HivaidsDetails6").hide();
    });

// 3nd main question starts

    $(".HealthHospitalized").on("click",function(){ 
        $("#hospitalizedDetails").val(""),
        0==$(this).val()?$("#hospitalizedDetails").show():$("#hospitalizedDetails").hide()
    });

    $("#health_hospitalized").on("click", function(){
        $(".hospitalized").prop('checked', false);

    });


// 4th main question starts

    $(".HealthClaim").on("click",function(){ 
        $("#HEDHealthClaimDetails").val(""),
        0==$(this).val()?$("#HEDHealthClaimDetails").show():$("#HEDHealthClaimDetails").hide()
    });

    $("#healthclaim").on("click", function(){
        $(".healthclaim").prop('checked', false);

    });

// 5th main question starts

    $(".HealthDeclined").on("click",function(){ 
        $("#HEDHealthDeclineddetails").val(""),
        0==$(this).val()?$("#HEDHealthDeclineddetails").show():$("#HEDHealthDeclineddetails").hide()
    });

    $("#healthdecline").on("click", function(){
        $(".health_decline").prop('checked', false);

    });


// 6th main question starts

    $(".Healthcovered").on("click",function(){ 
        $("#HEDHealthCovereddetails").val(""),
        0==$(this).val()?$("#HEDHealthCovereddetails").show():$("#HEDHealthCovereddetails").hide()
    });

    $("#health_cover").on("click", function(){
        $(".healthcovered").prop('checked', false);

    });

// 7th main question starts

    $(".OtherDetails").on("click",function(){ 
        $("#PEDother_details").val(""),
        0==$(this).val()?$("#PEDother_details").show():$("#PEDother_details").hide()
    });

    $("#other_details").on("click", function(){
        $(".othersdetails").prop('checked', false);

    });

// 8th main question starts

    $(".Respiratory").on("click",function(){ 
        $("#Respiratory_details").val(""),
        0==$(this).val()?$("#Respiratory_details").show():$("#Respiratory_details").hide()
    });

    $("#Respiratorydetails").on("click", function(){
        $(".respiratory_details").prop('checked', false);

    });
//9th main question starts
    
    $(".EndoDetails").on("click",function(){ 
        $("#Endo_details").val(""),
        0==$(this).val()?$("#Endo_details").show():$("#Endo_details").hide()
    });

    $("#endodetails").on("click", function(){
        $(".pedendodetails").prop('checked', false);

    });
// 10th main question starts here

    $(".illnessDetails").on("click",function(){ 
        $("#PEDillness_details").val(""),
        0==$(this).val()?$("#PEDillness_details").show():$("#PEDillness_details").hide()
    });

    $("#illnessdetails").on("click", function(){
        $(".illdetails").prop('checked', false);

    });

// 11th main question starts 


    $(".SurgeryDetails").on("click",function(){ 
        $("#PEDSurgery_Details").val(""),
        0==$(this).val()?$("#PEDSurgery_Details").show():$("#PEDSurgery_Details").hide()
    });

    $("#surgerydetails").on("click", function(){
        $(".surgery_details").prop('checked', false);

    });

 // 12th main question starts    

 $(".SmokeDetails").on("click",function(){ 
        $("#Smoke_Details").val(""),
        0==$(this).val()?$("#Smoke_Details").show():$("#Smoke_Details").hide()
    });


     $('#smoke_details1').on('click',function () {
        $("#PedSmokeDetails1").toggle(this.checked);
    });

    $('#smoke_details2').on('click',function () {
        $("#PedSmokeDetails2").toggle(this.checked);
    });
    
    $('#smoke_details3').on('click',function () {
        $("#PedSmokeDetails3").toggle(this.checked);
    });

    $('#smoke_details4').on('click',function () {
        $("#PedSmokeDetails4").toggle(this.checked);
    });

    $('#smoke_details5').on('click',function () {
        $("#PedSmokeDetails5").toggle(this.checked);
    });

    $('#smoke_details6').on('click',function () {
        $("#PedSmokeDetails6").toggle(this.checked);
    });


    $("#smokedetails").on("click", function(){
         $(".smoke_details").prop('checked', false);
         $("#PedSmokeDetails1").hide();
         $("#PedSmokeDetails2").hide();
         $("#PedSmokeDetails3").hide();
         $("#PedSmokeDetails4").hide();
         $("#PedSmokeDetails5").hide();
         $("#PedSmokeDetails6").hide();

    });




  $(document).ready(function() {  
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
                
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
     }); 

   
