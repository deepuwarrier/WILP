
$('.question_list_no').on('change',function(event){
     var Self = false, wife = false, husb = false, son = false,  daughter= false ,father = false, mother = false;
     var member = [];
     $('.col-sm-4 .question_list').each(function(key,value){
        member = value;
     });

     if($(this).is(':checked')){
        $('.SELF').each(function(key,value){
             if($(value).is(':checked')){
                 Self = true;   
                 return false;
             }
        });
        $('.WIFE').each(function(key,value){
             if($(value).is(':checked')){
                 wife = true;   
                 return false;
             }
        });
        $('.HUSBAND').each(function(key,value){
             if($(value).is(':checked')){
                 husb = true;   
                 return false;
             }
        });
        $('.SON').each(function(key,value){
             if($(value).is(':checked')){
                 son = true;   
                 return false;
             }
        });
        $('.FATHER').each(function(key,value){
             if($(value).is(':checked')){
                 father = true;   
                 return false;
             }
        });
        $('.MOTHER').each(function(key,value){
             if($(value).is(':checked')){
                 mother = true;   
                 return false;
             }
        });
     }
     var self_data = '#'+$('.SELF').attr('data-queid');
     var wife_data = '#'+$('.WIFE').attr('data-queid');
     var husb_data = '#'+$('.HUSBAND').attr('data-queid');
     var son_data = '#'+$('.SON').attr('data-queid');
     var father_data = '#'+$('.FATHER').attr('data-queid');
     var mother_data = '#'+$('.MOTHER').attr('data-queid');
     if(Self){ $(self_data).show(); }else{ $(self_data).hide(); }
     if(wife){ $(wife_data).show(); }else{  $(wife_data).hide(); }
     if(husb){ $(husb_data).show();  }else{ $(husb_data).hide(); }
     if(son){ $(son_data).show(); }else{ $(son_data).hide(); }
     if(father){ $(father_data).show(); }else{ $(father_data).hide(); }
     if(mother){ $(mother_data).show(); }else{ $(mother_data).hide();  }
     event.stopPropagation();
});

function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form),
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
   }).done(function (a) {  
        if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        } else if(a['status'] == 'false') {
             staticpayment(a)
        }else if(a['policytype'] == "NONSTP") {
            chechkpolicyType(a)
        }else if(a['Error'] == "Error") {
            swal(a['errormsg'])
        }else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
     });
    //.fail(function(){
    //    common.apiBadReponse();
    // });
}

function policyCheck(a, b){
    policy.text = a.html, 
    common.overlay_msg(policy.text)
}

function premiumMismatch(a, b) { 
    basePremium = Math.floor(b.data.finalPremium  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.finalPremium) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) { 
    data = purposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b, 
    c = $("#product_id").val(), 
    d = $("#insurer_id").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data)
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}



function payment(a) { 
    common.loader_rem();
    common.loader_msg(common.msg.payment_redirect); 
    if (a.paymentType) {
       var input_ele = "";
            $.each(a, function(index, val) { 
                input_ele+='<input type="hidden" value="'+val+'" name="'+index+'"/>';     
            });
            input_ele += '<input type="hidden" name="reqType" id="reqType" value="'+ a.reqType+'">';
            input_ele += '<input type="hidden" name="process"  value="'+ a.process+'">';
            input_ele += '<input type="hidden" name="apikey" id="apikey" value="'+a.apikey+'">';
            input_ele += '<input type="hidden" name="agentId" id="agentId" value="'+a.agentId+'">';
            input_ele += '<input type="hidden" name="premium" value="'+a.premium+'">';
            input_ele += '<input type="hidden" name="quoteId" id="quoteId" value="'+a.quoteId+'">';
            input_ele += '<input type="hidden" name="strFirstName" id="strFirstName" value="'+a.strFirstName+'">';
            input_ele += '<input type="hidden" name="strEmail" id="strEmail" value="'+a.strEmail+'">';
            input_ele += '<input type="hidden" name="paymentType" value="'+a.paymentType+'"/>';
            input_ele += '<input type="hidden" name="returnUrl" id="returnUrl" value="'+a.returnUrl+'">';
            input_ele += '<input type="hidden" name="version_no" id="version_no" value="12345">';
            input_ele += '<input type="hidden" name="isQuickRenew" id="isQuickRenew" value="">';
            input_ele += '<input type="hidden" name="crossSellProduct" id="crossSellProduct" value="">';
            input_ele += '<input type="hidden" name="crossSellQuoteid" id="crossSellQuoteid" value="">';
            input_ele += '<input type="hidden" value="privatePassengerCar" name="vehicleSubLine" id="vehicleSubLine">';
            input_ele += '<input type="hidden" value="" name="elc_value" id="elc_value">';
            input_ele += '<input type="hidden" value="" name="nonelc_value" id="nonelc_value">';
            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='religare_submit'/>";
            var pay_form = '<form id="PostForm" name="PostForm" autocomplete="off" action="'+a.paymentURL+'" method="POST">';
            pay_form += input_ele;
            pay_form += "</form>";
            $("#pay_form").html(pay_form);
            $("#PostForm").submit();
      
    } else {
        $("#pay_form").html(data.error);
    }
}

// PED details

  // consulted doctor question
  $("#consulted-doctor-yes").on("click",function(){  
        $("#consulted-doctor").val(""),
        'Yes'==$(this).val()? $("#consulted-doctor").show() : $("#consulted-doctor").hide()
  });

$("#consulted-doctor-no").on("click", function(){
     $("#consulted-doctor_member1").prop('checked', false);
     $("#consulted-doctor_member2").prop('checked', false);
     $("#consulted-doctor_member3").prop('checked', false);
     $("#consulted-doctor_member4").prop('checked', false);
     $("#consulted-doctor_member5").prop('checked', false);
     $("#consulted-doctor_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#consulted-doctor").val(""),
        'Yes' == $(this).val()? $("#consulted-doctor").show() : $("#consulted-doctor").hide()
});


// Undergone investigation question
 $("#undergone-investigation-yes").on("click",function(){ 
        $("#undergone-investigation").val(""),
        'Yes'==$(this).val()? $("#undergone-investigation").show() : $("#undergone-investigation").hide()
  });
$("#undergone-investigation-no").on("click", function(){
     $("#undergone-investigation_member1").prop('checked', false);
     $("#undergone-investigation_member2").prop('checked', false);
     $("#undergone-investigation_member3").prop('checked', false);
     $("#undergone-investigation_member4").prop('checked', false);
     $("#undergone-investigation_member5").prop('checked', false);
     $("#undergone-investigation_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#undergone-investigation").val(""),
        'Yes'==$(this).val()? $("#undergone-investigation").show() : $("#undergone-investigation").hide()
});

// Treatment Question 
 $("#taken-medical-treatment-yes").on("click",function(){ 
        $("#taken-medical-treatment").val(""),
        'Yes'==$(this).val()? $("#taken-medical-treatment").show() : $("#taken-medical-treatment").hide()
  });
$("#taken-medical-treatment-no").on("click", function(){
     $("#taken-medical-treatment_member1").prop('checked', false);
     $("#taken-medical-treatment_member2").prop('checked', false);
     $("#taken-medical-treatment_member3").prop('checked', false);
     $("#taken-medical-treatment_member4").prop('checked', false);
     $("#taken-medical-treatment_member5").prop('checked', false);
     $("#taken-medical-treatment_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#taken-medical-treatment").val(""),
        'Yes'==$(this).val()? $("#taken-medical-treatment").show() : $("#taken-medical-treatment").hide()
});

// Consuming Tablets / Drugs question 

 $("#consuming-tablets-yes").on("click",function(){ 
        $("#consuming-tablets").val(""),
        'Yes'==$(this).val()? $("#consuming-tablets").show() : $("#consuming-tablets").hide()
  });
$("#consuming-tablets-no").on("click", function(){
     $("#consuming-tablets_member1").prop('checked', false);
     $("#consuming-tablets_member2").prop('checked', false);
     $("#consuming-tablets_member3").prop('checked', false);
     $("#consuming-tablets_member4").prop('checked', false);
     $("#consuming-tablets_member5").prop('checked', false);
     $("#consuming-tablets_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#consuming-tablets").val(""),
        'Yes'==$(this).val()? $("#consuming-tablets").show() : $("#consuming-tablets").hide()
});

// medical-conditions question 
 $("#medical-conditions-yes").on("click",function(){ 
        $("#medical-conditions").val(""),
        'Yes'==$(this).val()? $("#medical-conditions").show() : $("#medical-conditions").hide()
  });
$("#medical-conditions-no").on("click", function(){
     $("#medical-conditions_member1").prop('checked', false);
     $("#medical-conditions_member2").prop('checked', false);
     $("#medical-conditions_member3").prop('checked', false);
     $("#medical-conditions_member4").prop('checked', false);
     $("#medical-conditions_member5").prop('checked', false);
     $("#medical-conditions_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#medical-conditions").val(""),
        'Yes'==$(this).val()? $("#medical-conditions").show() : $("#medical-conditions").hide()
});

// medical-conditions question 
 $("#undergone-a-surgery-yes").on("click",function(){ 
        $("#undergone-a-surgery").val(""),
        'Yes'==$(this).val()? $("#undergone-a-surgery").show() : $("#undergone-a-surgery").hide()
  });
$("#undergone-a-surgery-no").on("click", function(){
     $("#undergone-a-surgery_member1").prop('checked', false);
     $("#undergone-a-surgery_member2").prop('checked', false);
     $("#undergone-a-surgery_member3").prop('checked', false);
     $("#undergone-a-surgery_member4").prop('checked', false);
     $("#undergone-a-surgery_member5").prop('checked', false);
     $("#undergone-a-surgery_member6").prop('checked', false);
     $('#nameOfIllness_1').val('');
     $("#nameOfIllness_2").val('');
     $("#nameOfIllness_3").val('');
     $("#nameOfIllness_4").val('');
     $("#nameOfIllness_5").val('');
     $("#nameOfIllness_6").val('');
     $("#undergone-a-surgery").val(""),
        'Yes'==$(this).val()? $("#undergone-a-surgery").show() : $("#undergone-a-surgery").hide()
});


var $mem1_check = "#consulted-doctor_member1,#undergone-investigation_member1,#taken-medical-treatment_member1,#consuming-tablets_member1,#medical-conditions_member1,#undergone-a-surgery_member1";
 var $mem1 = $($mem1_check);
    $mem1.click(function() {
    if($mem1.is(":unchecked")) {
        $('#nameOfIllness_1').val('');
    } 
});

var $mem2_check = "#consulted-doctor_member2,#undergone-investigation_member2,#taken-medical-treatment_member2,#consuming-tablets_member2,#medical-conditions_member2,#undergone-a-surgery_member2";
var $mem2 = $($mem2_check);
    $mem2.click(function() {
    if($mem2.is(":unchecked")) {
        $('#nameOfIllness_2').val('');
    } 
});

var $mem3_check = "#consulted-doctor_member3,#undergone-investigation_member3,#taken-medical-treatment_member3,#consuming-tablets_member3,#medical-conditions_member3,#undergone-a-surgery_member3";
var $mem3 = $($mem3_check);
    $mem3.click(function() {
    if($mem3.is(":unchecked")) {
        $('#nameOfIllness_3').val('');
    } 
});

var $mem4_check = "#consulted-doctor_member4,#undergone-investigation_member4,#taken-medical-treatment_member4,#consuming-tablets_member4,#medical-conditions_member4,#undergone-a-surgery_member4";
var $mem4 = $($mem4_check);
    $mem4.click(function() {
    if($mem4.is(":unchecked")) {
        $('#nameOfIllness_4').val('');
    } 
});

var $mem5_check = "#consulted-doctor_member5,#undergone-investigation_member5,#taken-medical-treatment_member5,#consuming-tablets_member5,#medical-conditions_member5,#undergone-a-surgery_member5";
var $mem5 = $($mem5_check);
    $mem5.click(function() {
    if($mem5.is(":unchecked")) {
        $('#nameOfIllness_5').val('');
    } 
});

var $mem6_check = "#consulted-doctor_member6,#undergone-investigation_member6,#taken-medical-treatment_member6,#consuming-tablets_member6,#medical-conditions_member6,#undergone-a-surgery_member6";
var $mem6 = $($mem6_check);
    $mem6.click(function() {
    if($mem6.is(":unchecked")) {
        $('#nameOfIllness_6').val('');
    } 
});


// Question info 
$("#ped_question1").hide();
 var member1_val = "#consulted-doctor_member1, #undergone-investigation_member1, #taken-medical-treatment_member1, #consuming-tablets_member1, #medical-conditions_member1, #undergone-a-surgery_member1";
 var $member1 = $(member1_val);
$member1.click(function() {
    if($member1.is(":checked")) {
        $("#ped_question1").show();
    } else {
        $("#ped_question1").hide();
    }
});

$("#ped_question2").hide();
 var member2_val = "#consulted-doctor_member2, #undergone-investigation_member2, #taken-medical-treatment_member2, #consuming-tablets_member2, #medical-conditions_member2, #undergone-a-surgery_member2";
 var $member2 = $(member2_val);
$member2.click(function() {
    if($member2.is(":checked")) {
        $("#ped_question2").show();
    } else {
        $("#ped_question2").hide();
    }
});
$("#ped_question3").hide();
 var member3_val = "#consulted-doctor_member3, #undergone-investigation_member3, #taken-medical-treatment_member3, #consuming-tablets_member3, #medical-conditions_member3, #undergone-a-surgery_member3";
 var $member3 = $(member3_val);
$member3.click(function() {
    if($member3.is(":checked")) {
        $("#ped_question3").show();
    } else {
        $("#ped_question3").hide();
    }
});
$("#ped_question4").hide();
 var member4_val = "#consulted-doctor_member4, #undergone-investigation_member4, #taken-medical-treatment_member4, #consuming-tablets_member4, #medical-conditions_member4, #undergone-a-surgery_member4";
 var $member4 = $(member4_val);
$member4.click(function() {
    if($member4.is(":checked")) {
        $("#ped_question4").show();
    } else {
        $("#ped_question4").hide();
    }
});
$("#ped_question5").hide();
 var member5_val = "#consulted-doctor_member5, #undergone-investigation_member5, #taken-medical-treatment_member5, #consuming-tablets_member5, #medical-conditions_member5, #undergone-a-surgery_member5";
 var $member5 = $(member5_val);
$member5.click(function() {
    if($member5.is(":checked")) {
        $("#ped_question5").show();
    } else {
        $("#ped_question5").hide();
    }
});
$("#ped_question6").hide();
 var member6_val = "#consulted-doctor_member6, #undergone-investigation_member6, #taken-medical-treatment_member6, #consuming-tablets_member6, #medical-conditions_member6, #undergone-a-surgery_member6";
 var $member6 = $(member6_val);
$member6.click(function() {
    if($member6.is(":checked")) {
        $("#ped_question6").show();
    } else {
        $("#ped_question6").hide();
    }
});

// Alcoho Details
$("#Alcohol-yes").on("click",function(){ 
        $("#lifestyle_alcohol").val(""),
        1==$(this).val()? $("#lifestyle_alcohol").show() : $("#lifestyle_alcohol").hide(), $("#alcohol_quantity1").hide(),$("#alcohol_quantity2").hide()
});

$("#Alcohol-no").on("click", function(){
     $("#alcohol_member1").prop('checked', false);
     $("#alcohol_member2").prop('checked', false);
     $("#alcohol_member3").prop('checked', false);
     $("#alcohol_member4").prop('checked', false);
     $("#alcohol_member5").prop('checked', false);
     $("#alcohol_member6").prop('checked', false);
     $('#alcohol_quantity_1').val('');
     $("#alcohol_quantity_2").val('');
     $("#alcohol_quantity_3").val('');
     $("#alcohol_quantity_4").val('');
     $("#alcohol_quantity_5").val('');
     $("#alcohol_quantity_6").val('');
     $("#alcohol-no-of-years_1").val('');
     $("#alcohol-no-of-years_2").val('');
     $("#alcohol-no-of-years_3").val('');
     $("#alcohol-no-of-years_4").val('');
     $("#alcohol-no-of-years_5").val('');
     $("#alcohol-no-of-years_6").val('');
     $("#lifestyle_alcohol").val(""),
        1==$(this).val()? $("#lifestyle_alcohol").show() : $("#lifestyle_alcohol").hide(), $("#alcohol_quantity1").hide(),$("#alcohol_quantity2").hide(),$("#alcohol_quantity3").hide(),$("#alcohol_quantity4").hide(),$("#alcohol_quantity5").hide(),$("#alcohol_quantity6").hide()
});

$("#alcohol_quantity1").hide();
$("#alcohol_member1").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity1").show();
    } else {
        $("#alcohol_quantity1").hide();
    }
});

$("#alcohol_quantity2").hide();
$("#alcohol_member2").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity2").show();
    } else {
        $("#alcohol_quantity2").hide();
    }
});

$("#alcohol_quantity3").hide();
$("#alcohol_member3").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity3").show();
    } else {
        $("#alcohol_quantity3").hide();
    }
});

$("#alcohol_quantity4").hide();
$("#alcohol_member4").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity4").show();
    } else {
        $("#alcohol_quantity4").hide();
    }
});

$("#alcohol_quantity5").hide();
$("#alcohol_member5").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity5").show();
    } else {
        $("#alcohol_quantity5").hide();
    }
});

$("#alcohol_quantity6").hide();
$("#alcohol_member6").click(function() {
    if($(this).is(":checked")) {
        $("#alcohol_quantity6").show();
    } else {
        $("#alcohol_quantity6").hide();
    }
});



// Smoke Details
$("#Smoke-yes").on("click",function(){ 
        $("#lifestyle_smoke").val(""),
        1==$(this).val()? $("#lifestyle_smoke").show() : $("#lifestyle_smoke").hide(), $("#smoke_quantity1").hide(),$("#smoke_quantity2").hide(),$("#smoke_quantity3").hide(),$("#smoke_quantity4").hide(),$("#smoke_quantity5").hide(),$("#smoke_quantity6").hide()
});

$("#Smoke-no").on("click", function(){
     $("#smoke_member1").prop('checked', false);
     $("#smoke_member2").prop('checked', false);
     $("#smoke_member3").prop('checked', false);
     $("#smoke_member4").prop('checked', false);
     $("#smoke_member5").prop('checked', false);
     $("#smoke_member6").prop('checked', false);
     $('#smoke_quantity_1').val('');
     $("#smoke_quantity_2").val('');
     $("#smoke_quantity_3").val('');
     $("#smoke_quantity_4").val('');
     $("#smoke_quantity_5").val('');
     $("#smoke_quantity_6").val('');
     $("#smoke-no-of-years_1").val('');
     $("#smoke-no-of-years_2").val('');
     $("#smoke-no-of-years_3").val('');
     $("#smoke-no-of-years_4").val('');
     $("#smoke-no-of-years_5").val('');
     $("#smoke-no-of-years_6").val('');
     $("#lifestyle_smoke").val(""),
        1==$(this).val()? $("#lifestyle_smoke").show() : $("#lifestyle_smoke").hide(), $("#smoke_quantity1").hide(),$("#smoke_quantity2").hide(),$("#smoke_quantity3").hide(),$("#smoke_quantity4").hide(),$("#smoke_quantity5").hide(),$("#smoke_quantity6").hide()
});

$("#smoke_quantity1").hide();
$("#smoke_member1").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity1").show();
    } else {
        $("#smoke_quantity1").hide();
    }
});

$("#smoke_quantity2").hide();
$("#smoke_member2").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity2").show();
    } else {
        $("#smoke_quantity2").hide();
    }
});

$("#smoke_quantity3").hide();
$("#smoke_member3").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity3").show();
    } else {
        $("#smoke_quantity3").hide();
    }
});


$("#smoke_quantity4").hide();
$("#smoke_member4").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity4").show();
    } else {
        $("#smoke_quantity4").hide();
    }
});

$("#smoke_quantity5").hide();
$("#smoke_member5").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity5").show();
    } else {
        $("#smoke_quantity5").hide();
    }
});

$("#smoke_quantity6").hide();
$("#smoke_member6").click(function() {
    if($(this).is(":checked")) {
        $("#smoke_quantity6").show();
    } else {
        $("#smoke_quantity6").hide();
    }
});

// Tobacco details

$("#Tobacco-yes").on("click",function(){ 
        $("#lifestyle_tobacco").val(""),
        1==$(this).val()? $("#lifestyle_tobacco").show() : $("#lifestyle_tobacco").hide(), $("#tobacco_quantity1").hide(),$("#tobacco_quantity2").hide(),$("#tobacco_quantity3").hide(),$("#tobacco_quantity4").hide(),$("#tobacco_quantity5").hide(),$("#tobacco_quantity6").hide()
});

$("#Tobacco-no").on("click", function(){
     $("#tobacco_member1").prop('checked', false);
     $("#tobacco_member2").prop('checked', false);
     $("#tobacco_member3").prop('checked', false);
     $("#tobacco_member4").prop('checked', false);
     $("#tobacco_member5").prop('checked', false);
     $("#tobacco_member6").prop('checked', false);
     $('#tobacco_quantity_1').val('');
     $("#tobacco_quantity_2").val('');
     $("#tobacco_quantity_3").val('');
     $("#tobacco_quantity_4").val('');
     $("#tobacco_quantity_5").val('');
     $("#tobacco_quantity_6").val('');
     $("#tobacco-no-of-years_1").val('');
     $("#tobacco-no-of-years_2").val('');
     $("#tobacco-no-of-years_3").val('');
     $("#tobacco-no-of-years_4").val('');
     $("#tobacco-no-of-years_5").val('');
     $("#tobacco-no-of-years_6").val('');
     $("#lifestyle_tobacco").val(""),
        1==$(this).val()? $("#lifestyle_tobacco").show() : $("#lifestyle_tobacco").hide(), $("#tobacco_quantity1").hide(),$("#tobacco_quantity2").hide(),$("#tobacco_quantity3").hide(),$("#tobacco_quantity4").hide(),$("#tobacco_quantity5").hide(),$("#tobacco_quantity6").hide()
});

$("#tobacco_quantity1").hide();
$("#tobacco_member1").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity1").show();
    } else {
        $("#tobacco_quantity1").hide();
    }
});

$("#tobacco_quantity2").hide();
$("#tobacco_member2").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity2").show();
    } else {
        $("#tobacco_quantity2").hide();
    }
});

$("#tobacco_quantity3").hide();
$("#tobacco_member3").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity3").show();
    } else {
        $("#tobacco_quantity3").hide();
    }
});

$("#tobacco_quantity4").hide();
$("#tobacco_member4").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity4").show();
    } else {
        $("#tobacco_quantity4").hide();
    }
});

$("#tobacco_quantity5").hide();
$("#tobacco_member5").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity5").show();
    } else {
        $("#tobacco_quantity5").hide();
    }
});

$("#tobacco_quantity6").hide();
$("#tobacco_member6").click(function() {
    if($(this).is(":checked")) {
        $("#tobacco_quantity6").show();
    } else {
        $("#tobacco_quantity6").hide();
    }
});

// Narcotics Details

$("#Narcotics-yes").on("click",function(){ 
        $("#lifestyle_narcotics").val(""),
        1==$(this).val()? $("#lifestyle_narcotics").show() : $("#lifestyle_narcotics").hide(), $("#narcotics_quantity1").hide(),$("#narcotics_quantity2").hide(),$("#narcotics_quantity3").hide(),$("#narcotics_quantity4").hide(),$("#narcotics_quantity5").hide(),$("#narcotics_quantity6").hide()
});

$("#Narcotics-no").on("click", function(){
     $("#narcotics_member1").prop('checked', false);
     $("#narcotics_member2").prop('checked', false);
     $("#narcotics_member3").prop('checked', false);
     $("#narcotics_member4").prop('checked', false);
     $("#narcotics_member5").prop('checked', false);
     $("#narcotics_member6").prop('checked', false);
     $('#narcotics_quantity_1').val('');
     $("#narcotics_quantity_2").val('');
     $("#narcotics_quantity_3").val('');
     $("#narcotics_quantity_4").val('');
     $("#narcotics_quantity_5").val('');
     $("#narcotics_quantity_6").val('');
     $("#narcotics-no-of-years_1").val('');
     $("#narcotics-no-of-years_2").val('');
     $("#narcotics-no-of-years_3").val('');
     $("#narcotics-no-of-years_4").val('');
     $("#narcotics-no-of-years_5").val('');
     $("#narcotics-no-of-years_6").val('');
     $("#lifestyle_narcotics").val(""),
        1==$(this).val()? $("#lifestyle_narcotics").show() : $("#lifestyle_narcotics").hide(), $("#narcotics_quantity1").hide(),$("#narcotics_quantity2").hide(),$("#narcotics_quantity3").hide(),$("#narcotics_quantity4").hide(),$("#narcotics_quantity5").hide(),$("#narcotics_quantity6").hide()
});

$("#narcotics_quantity1").hide();
$("#narcotics_member1").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity1").show();
    } else {
        $("#narcotics_quantity1").hide();
    }
});

$("#narcotics_quantity2").hide();
$("#narcotics_member2").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity2").show();
    } else {
        $("#narcotics_quantity2").hide();
    }
});

 $("#narcotics_quantity3").hide();
$("#narcotics_member3").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity3").show();
    } else {
        $("#narcotics_quantity3").hide();
    }
});

$("#narcotics_quantity4").hide();
$("#narcotics_member4").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity4").show();
    } else {
        $("#narcotics_quantity4").hide();
    }
});

$("#narcotics_quantity5").hide();
$("#narcotics_member5").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity5").show();
    } else {
        $("#narcotics_quantity5").hide();
    }
});

$("#narcotics_quantity6").hide();
$("#narcotics_member6").click(function() {
    if($(this).is(":checked")) {
        $("#narcotics_quantity6").show();
    } else {
        $("#narcotics_quantity6").hide();
    }
});
