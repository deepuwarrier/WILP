
if (typeof validate_lib != 'undefined') {
    form_field = {
        
        "dob_list[]":'cust_dob_dash_d_m_y',
        "firstname[]":'firstname',
        "lastname[]":'lastname',
        "aadhaar_num":"aadhar_no",
        "height_feet[]":"required",
        "height_inches[]":"required",
        "weight[]":"weight",
        "marital_status":"required",
        "education":"required",
        "occupation[]":"required",
        "designation1":"required",
        "email":"email",
        "mobile":"mobile",
        "house_num":"houseno",
        "street":"street",
        "locality":"locality",
        "state":"required",
        "city":"required",
        "cust_pincode":"pincode",
        "consulted_doctor_member[]":"required",

        // extrenal data
        "question_info[nameOfIllness_1]":"required",
        "question_info[monthOfDiagnosis_1]":"required",
        "question_info[yearOfDiagnosis_1]":"required",
        "question_info[medicationDetail_1]":"required",
        "question_info[treatmentOutCome_1]":"required",

        "question_info[nameOfIllness_2]":"required",
        "question_info[monthOfDiagnosis_2]":"required",
        "question_info[yearOfDiagnosis_2]":"required",
        "question_info[medicationDetail_2]":"required",
        "question_info[treatmentOutCome_2]":"required",
        
        "alcohol_member[]":"required",
        "alcohol_quantity[]":"required",
        "alcohol_no_of_years[]":"required",

        "smoke_member[]":"required",
        "smoke_quantity[]":"required",
        "smoke_no_of_years[]":"required",

        "tobacco_member[]":"required",
        "tobacco_quantity[]":"required",
        "tobacco_no_of_years[]":"required",


        'narcotics_member[]':'required',
        'narcotics_quantity[]':'required',
        'narcotics_no_of_years[]':'required',

        "nominee_name":"fullname"
    };
    frm_grp_class = ['consulted_doctor',
                    'undergone_investigation',
                    'consuming_tablets',
                    'medical_conditions',
                    'undergone_a_surgery',
                    'lifestyle_alcohol',
                    'lifestyle_smoke',
                    'lifestyle_narcotics',
                    'lifestyle_tobacco'];
    validate_lib.addFormGrpReq(frm_grp_class);

    form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field);



} else {
    console.error("import validator_lib.js for validation");
}

function validateProposal(a) {
    form_id = 'buy_policy_form';
    is_validated = validate_lib.isValidate(form_id);
    
    id = $(".tab-pane.active").attr('id');
    field = $("#" + id + " :input:visible").serializeArray();
    fields = common.serilazeArrayToArray(field); 
    fields.id = id;
    fields._token = $('#_token').val();
    $return_type = !0, errors = "";
    var b = 1,
        c = $("#membercount").val();

    if(!is_validated)
        return is_validated;

    return "" != errors && (errors += '',overlay_rem(), swal(errors))? "" :(setData(fields)), $return_type
}
