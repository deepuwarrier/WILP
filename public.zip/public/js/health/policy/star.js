// getting area code based on pincode
$(document).on("keyup", "#cust_pincode", function() { 
    var pincode= $("#cust_pincode").val(),
        token = $("input[name=_token]").val(),
        url = $("#state_city").val(),
        pincode = $.trim(pincode); 
        6 == pincode.length && (common.loader_msg(common.msg.submit_form),
        $.ajax({
        method: "post",
        url: url,
        data: {'_token': token, 'pincode': pincode },
        dataType: "json",
        async: !0
    }).done(function(data) {
        data.error ? (console.log(data), 
        common.overlay_rem(), 
        swal("Invalid Pincode"), 
        $("#state").val(""), 
        city = '<option hidden="" selected="" disabled="" value="">Select City*</option>', 
        $("#city").empty(), 
        $("#city").append(city), 
        area = '<option hidden="" selected="" disabled="" value="">Select Area*</option>', 
        $("#cust_area").empty(), 
        $("#cust_area").append(area)) : (console.log(data), 
        common.overlay_rem(), 
        $("#state").empty(), 
        $("#state").val(data.state_name.toUpperCase()), 
        city = '<option hidden="" selected="" disabled="" value="">Select City*</option>', 
        $.each(data.city, function(e, t) {
            city += '<option value = "' + t.city_id + '">' + t.city_name.toUpperCase() + "</option>"
        }), 
        $("#city").empty(), 
        $("#city").append(city), 
        area = '<option hidden="" selected="" disabled="" value="">Select Area*</option>', 
        $("#cust_area").empty(), 
        $("#cust_area").append(area))
    }))
}), 

$("#city").change(function() {
    common.loader_msg(common.msg.submit_form);
    var city = this.value,
        url = $("#area_city").val(),
        pincode = $("#cust_pincode").val(),
        token = $("input[name=_token]").val(),
        o = '<option hidden="" selected="" disabled="" value="">Select Area*</option>';
    $.ajax({
        method: "POST",
        url: url,
        data: { '_token': $token, city: city, pincode: pincode },
        dataType: "json",
        async: !0
    }).done(function(e) {
        $.each(e.area, function(e, t) {
            o += '<option value = "' + t.areaID + '">' + t.areaName.toUpperCase() + "</option>"
        }), $("#cust_area").empty(), $("#cust_area").append(o), common.overlay_rem()
    })
})


function load_dob_list(){
  count = $('#membercount').val(); 
  for(i=0; i<count; i++){  
    $('#dob_list'+i).datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      minDate: $('#dob_list'+i).attr('min-date'),
      maxDate: $('#dob_list'+i).attr('max-date'),
      yearRange: "-75:+1"})
   } 
}


function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form), 
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {  
        if(a['status'] == 'offline'){ 
            offlinePolicy(a.message)
        }else if(a['status'] == 'ppc_case'){
            check_star_ppc(a)
        }else{ 
        chechkData(a) && (policy.proposal_return_data = a)}
    }).always(function () {
        common.loader_rem()
    });
}

function premiumMismatch(a, b) 
{  
    policy.title = "Premium has changed!",
    policy.text = a.html,
    policy.totalPremium = b.data.PremiumPayable,
    policy.basePremium = b.data.basePremium,
    policy.serviceTax = b.data.serviceTax,
    policy.product_id = b.product_id,
    policy.insurer_id = b.insurer_id,
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d,e) 
{    
    data = proposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b + "&new_total_premium=" + e, 
    c = $("#product_id").val(), 
    d = $("#insurer_name").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data) 
    
}

function offlinePolicy(message) { 
     window.location = $("#offline_policy").val() + '?msg='+message;
}

function payment(a) 
{  
    var payment_ref_num = '';
    store_payment_status(payment_ref_num);
    common.loader_msg(common.msg.payment_redirect), 
    a.pg_url && (window.location = a.pg_url)
}


function policyCheck(a, b){
    policy.text = a.html, 
    common.overlay_msg(policy.text)
}

// Medical Illness Details
$('#illness_yes').click(function(){  
        $("#having_illness").val(""),
        1==$(this).val()?$("#having_illness").show():$("#having_illness").hide()
});

$("#illness_no").on("click", function(){
     $("#illness_member_1").val('');
     $("#illness_member_2").val('');
     $("#illness_member_3").val('');
     $("#illness_member_4").val('');
     $("#illness_member_5").val('');
     $("#illness_member_6").val('');
     $("#having_illness").val(""),
        1==$(this).val()? $("#having_illness").show() : $("#having_illness").hide()
});

// Medical Manual Labour Details
$('#engageManualLabour_yes').click(function(){  
        $("#ManualLabour").val(""),
        1==$(this).val()?$("#ManualLabour").show():$("#ManualLabour").hide()
});

$("#engageManualLabour_no").on("click", function(){
     $("#labour_member_1").val('');
     $("#labour_member_2").val('');
     $("#labour_member_3").val('');
     $("#labour_member_4").val('');
     $("#labour_member_5").val('');
     $("#labour_member_6").val('');
     $("#ManualLabour").val(""),
        1==$(this).val()? $("#ManualLabour").show() : $("#ManualLabour").hide()
});


// Medical Winter Sports Details
$('#engageWinterSports_yes').click(function(){  
        $("#WinterSports").val(""),
        1==$(this).val()?$("#WinterSports").show():$("#WinterSports").hide()
});

$("#engageWinterSports_no").on("click", function(){
     $("#sports_member_1").val('');
     $("#sports_member_2").val('');
     $("#sports_member_3").val('');
     $("#sports_member_4").val('');
     $("#sports_member_5").val('');
     $("#sports_member_6").val('');
     $("#WinterSports").val(""),
        1==$(this).val()? $("#WinterSports").show() : $("#WinterSports").hide()
});

// Insulin Problem
$('#insulinProblem_yes').click(function(){  
        $("#InsulinProblem").val(""),
        1==$(this).val()?$("#InsulinProblem").show():$("#InsulinProblem").hide()
});

$("#insulinProblem_no").on("click", function(){
     $("#insulin_member_1").val('');
     $("#insulin_member_2").val('');
     $("#insulin_member_3").val('');
     $("#insulin_member_4").val('');
     $("#insulin_member_5").val('');
     $("#insulin_member_6").val('');
     $("#InsulinProblem").val(""),
        1==$(this).val()? $("#InsulinProblem").show() : $("#InsulinProblem").hide()
});

// Socila status
$(".socialstatus").on("click",function(){ 
        $("#socialstatus_bpl").val(""),
        1==$(this).val()?$("#socialstatus_bpl").show():$("#socialstatus_bpl").hide()
    });
$("#socialstatuss").on("click", function(){
     $(".unorganized").prop('checked', false);
     $(".belowpoverty").prop('checked', false);
     $(".handicaped").prop('checked', false);
     $(".informalsector").prop('checked', false);
});




// function retrive_health_proposal_data() {  
//     url = APP_URL+'/health-insurance/retrive_health_proposal_data',
//     $.get(url, {    
//         hl_trans_code : $("#hl_trans_code").val()   
//     },  function(data, status) {  
//         //Insured Section      
//         $("#aadhaar").val( data['aadhaar'] ) ;
         
//         // Communication section 
//         $("#user_email").val( data['emial'] ) ;
//          $("#mobile").val( data['mobile'] ) ;
//          $("#houseno").val( data['houseno'] ) ;
//          $("#street").val( data['street'] ) ;
//          $("#locality").val( data['locality'] ) ;
//          $("#cust_pincode").val( data['cust_pincode'] ) ;
         
//          //Health history Section 

//          //Nominee details section
//          $("#nomineename").val( data['nominee_name'] ) ;
//          $("#nomineeage").val( data['nominee_age'] ) ; 
//     });
// }
