// getting area code based on pincode
 $(document).on("keyup", "#cust_pincode", function() {
    var pincode = $("#cust_pincode").val(), url = $('#areacodeurl').val(), token = $("input[name=_token]").val(),
        areacode = ''; pincode = $.trim(pincode), 6 == pincode.length && (common.loader_msg(common.msg['submit_form']), 
        $.ajax({
            method: "POST",
            url: url,
            data: {'_token': $token,'pincode' : pincode },
            dataType: "json",
            async: !0
        }).done(function(data) {
            data.error ? (console.log(data), common.overlay_rem(), swal("Invalid Pincode"), 
            areacode = '<option hidden="" selected="" disabled="" value="">Select Area*</option>', 
            $("#cust_area").empty(),$("#cust_area").append(areacode)) : (console.log(data), common.overlay_rem(), 
            $.each(data.result.city, function(key, value) {
                $.each(data.result.city[key], function(key, value){
                   if(key === 'area'){
                       $.each(value, function(key, value){
                         areacode += '<option value = "'+value.areaID+'">' + value.areaName.toUpperCase() + "</option>"
                       })
                   }
                  
                })
            }),
             
            $("#cust_area").empty(),$("#cust_area").append(areacode))
    }))
});



function getForm(a, b, c) { 
    common.loader_msg(common.msg.submit_form), 
    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) { 
         if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        } else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
    // }).fail(function(){
    //    common.apiBadReponse();
    });
}

function premiumMismatch(a, b) 
{ 
    policy.title = "Premium has changed!",
    policy.text = a.html,
    policy.basePremium = b.data.premium,
    policy.serviceTax = b.data.serviceTax,
    policy.product_id = b.product_id,
    policy.insurer_id = b.insurer_id,
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) 
{    
    data = purposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b, 
    c = $("#productId").val(), 
    d = $("#insurerId").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data) 
    
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}


function payment(a) 
{  
    common.loader_msg(common.msg.payment_redirect), 
    a.online_purchase_link && (window.location = a.online_purchase_link)
}


$(".socialstatus").on("click",function(){ 
        $("#socialstatus_bpl").val(""),
        1==$(this).val()?$("#socialstatus_bpl").show():$("#socialstatus_bpl").hide()
    });

$("#socialstatuss").on("click", function(){
     $(".unorganized").prop('checked', false);
     $(".belowpoverty").prop('checked', false);
     $(".handicaped").prop('checked', false);
     $(".informalsector").prop('checked', false);

});


$(document).ready(function() {  
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
     });
