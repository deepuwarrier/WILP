function getForm(a, b, c) { 
    common.overlay_msg(common.msg.submit_form), 
    $.ajax({
        method: "POST", 
        url: url, 
        data: c, 
        dataType: "json"
    }).done(function (a) {
        if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        } else{ 
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
    // }).fail(function(){
    //    common.apiBadReponse();
    });
}

function premiumMismatch(a, b) { 
    
    basePremium = Math.floor(b.data.FinalPremium  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.FinalPremium) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) 
{    
    data = purposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b, 
    c = $("#productId").val(), 
    d = $("#insurerId").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data) 
    
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}


function payment(a) 
{  
    common.loader_msg(common.msg.payment_redirect), 
    a.payUrl && (window.location = a.payUrl)
}


$(document).ready(function() {  
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
                
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
     });
