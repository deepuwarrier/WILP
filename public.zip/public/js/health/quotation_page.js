$(document).ready(function() {
    $(function(){
                $('a[id^="h_benefits"]').click(function(e) { 
                    common.loader_msg(common.msg['submit_form']);
                    e.preventDefault();
                    token = $("input[name=_token]").val();
                    total_premium = $(this).next().val();
                    servicetax = $(this).next().next().val();
                    suminsured = $(this).next().next().next().val();
                    img_url  = $(this).next().next().next().next().val();
                    product_id = $(this).next().next().next().next().next().val();
                    product_name = $(this).next().next().next().next().next().next().val();
                    url      = $('#h_benifitUrl').val();
                    trans_code = $('#trans_code').val();
                    $.post( 
                        url,
                        { '_token': token, 'trans_code' : trans_code , 'product_id' : product_id, 'total_premium' : total_premium, 'suminsured':suminsured, 'img_url':img_url, 'product_name':product_name, 'servicetax':servicetax},
                          function(data) {
                           common.loader_rem(); 
                           $('#BenefitModal').html(data);
                           $('#BenefitModal').modal('show');
                          }
                    );  
                    
                }); // End of click Function
    });

    $(function(){
                $('a[id^="h_breakup"]').click(function(e) {
                    common.loader_msg(common.msg['submit_form']);
                    e.preventDefault();
                    token = $("input[name=_token]").val();
                    total_premium = $(this).next().val();
                    servicetax = $(this).next().next().val();
                    suminsured = $(this).next().next().next().val();
                    img_url  = $(this).next().next().next().next().val();
                    product_id = $(this).next().next().next().next().next().val();
                    product_name = $(this).next().next().next().next().next().next().val();
                    basepremium = $(this).next().next().next().next().next().next().next().val();
                    url       = $('#h_breakupUrl').val();
                    trans_code = $('#trans_code').val();
                    $.post( 
                        url,
                        { '_token': token, 'trans_code' : trans_code, 'product_id' : product_id, 'product_name': product_name, 'total_premium':total_premium ,'suminsured' : suminsured, 'img_url' : img_url, 'servicetax':servicetax ,'basepremium':basepremium},
                          function(data) {
                           common.loader_rem(); 
                           $('#premiumBreakup').html(data);
                           $('#premiumBreakup').modal('show');

                          }
                    );  
                    
                }); // End of click Function
    });
});

//  store data to user transaction table
// function submitpolicy(product_id, insurer_name){
//   token = $('input[name=_token]').val(); 
//   trans_code = $("#trans_code").val();
//   productId = product_id;
//   proposal_url = APP_URL+'/health-insurance/'+insurer_name+'/'+trans_code+'';
//   $.ajax({
//             url: APP_URL+'/health-insurance/store_user_data',
//             type: 'POST',
//             data: {'_token' : token,'trans_code' : trans_code, 'product_id' : productId,'proposal_url': proposal_url},
//             success: function(data) {   
//             window.location.href = proposal_url;
//           }
//     });
// }


function noPremiumChangeStatus(){
      var e=$("#nopremchangestatus").val(),
      token = $("input[name=_token]").val();
      t=$("#prop_premium").val();
      $.post(
        e,
        { _token: token ,                              //_token:$("meta[name=csrf-token]").attr("content"),
        act_prem:t,companyId:companyId},
        function(e){
          overlay_msg(e.html)
        }
        )}





