$(document).ready(function(){
	$(document).on('click','#contact-form .btn',function(){
		var url = $('#contact-form').attr('action');
		var data = $('#contact-form').serialize();
		$(this).text('Please wait...').attr('disabled','disabled');
		$.ajax({
				type:'POST',
				url: url,
				data: data,				
				success:function(responce){
					$('#contact-form').trigger('reset');
					$('#contact-form .btn').text('Send Message').removeAttr('disabled');
					$('.smessage').text(responce);
				}				
		});
		
	});
});