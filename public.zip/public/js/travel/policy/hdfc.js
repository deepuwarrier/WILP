actual_premium  = 0;
passed_premium  = 0; 
api_response    = 0;
paymode         = 'cc';
paymode_flag    = false;
company_id      = $('#company_id').val();
trans_code      = $('#trans_code').val();
premium         = $('#actual_premium').val();
updated_premium = $("#updated_premium").val();

function submit_proposal_form(){  
    updated_premium  = $('#updated_premium').val();
    common.loader_msg('Please Wait...');
    $.getJSON(APP_URL + "/travel-insurance/hdfc/submit_proposal", {
      trans_code : trans_code,
      updated_premium : updated_premium
    }, function(data) { 
      common.overlay_rem();    
      handle_proposal_response(data);
      
  });
  
}

function handle_proposal_response(data){
    if(data.status){
        api_response = data;
        if(updated_premium == 0){
            no_premium_change();
        }else{
            common.loader_msg(common.msg['payment_redirect']);
            redirect_gateway();
        }
    }else if(data.status == false && data.mismatch == true){
        actual_premium = data.actual_premium; 
        passed_premium = data.passed_premium;
        premium_mismatch();
    }else if(data.status == false && data.ped == true){
        window.location= APP_URL + '/travel-insurance/hdfc/policy/status/offline';
    }else if(data.status == false && data.error == true){
        msg = data.message;
        swal(msg);        
    }else{
       window.location= APP_URL + '/travel-insurance/bad_response';
    } 
}

function no_premium_change(){
    $.getJSON(APP_URL + "/travel-insurance/no_premium_change", {
      trans_code  : trans_code,
      company_id  : company_id,
      premium     : premium
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

function premium_mismatch(){
    $.getJSON(APP_URL + "/travel-insurance/premium_mismatch", {
      trans_code  : trans_code,
      company_id  : company_id,
      actual_premium  : actual_premium,
      passed_premium  : passed_premium,
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

// If user click on review button
$(document).on("click", "#review-again", function() {
    common.overlay_rem();
});

// If user Agree for Updated Premium and Submit the form For Payment
$(document).on("click", "#re-submit", function() {
    $("#updated_premium").val(actual_premium);
    submit_proposal_form();
});

// If No Premium Mismatch, When User click on make payment button 
$(document).on("click", "#payment-submit", function() {
    common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});

// For Payment Mode selection by customer
$(document).on("change", "#paymode_cc", function() {
    if( $(this).is(":checked") ){
        paymode = $(this).val();
        paymode_flag = true;
    }
});

$(document).on("change", "#paymode_dd", function() {
    if( $(this).is(":checked") ){ 
        paymode = $(this).val();
        paymode_flag = true;
    }
});

function redirect_gateway(){
    // Redirecting to PG
    update_payment_mode();
    update_payment_status();
    post_data(api_response.pg_url, 'post', api_response.request);
}


function update_payment_mode(){
    paymode = (paymode_flag == false) ? 'cc' : paymode;
    api_response.request['hdnPayMode'] = paymode;
    paymode_flag = false;
    $.get(APP_URL + "/travel-insurance/hdfc/update_paymode", {
      trans_code  : trans_code,
      pay_mode    : paymode
    }, function(data) { 
    });
}
 
function post_data(actionUrl, method, data) {
    var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
        }
    }
    $('body').append(mapForm);
    mapForm.submit();
}


// PED Questions
$("#medical_history_yes").click( function(){
    if($(this).is(':checked')){
        $("#sub_ped_container").fadeIn();
    }else{
        $("#sub_ped_container").fadeOut();
        $("#medical_history_details").val('');
        $("#medical_history_details").fadeOut();
        $("#sub_ped_other").prop('checked', false);
    }
});

$("#medical_declined_yes").click( function(){
    $("#medical_declined_details").val('');
    ($(this).is(':checked')) ? $("#medical_declined_details").fadeIn() : $("#medical_declined_details").fadeOut();
});

$("#special_conditions_yes").click( function(){
    $("#special_conditions_details").val('');
    ($(this).is(':checked')) ? $("#special_conditions_details").fadeIn() : $("#special_conditions_details").fadeOut();
});
 

// Sub ped
$("#sub_ped_other").click( function(){
    sub_ped_status = get_sub_ped_status('');
    if(sub_ped_status == 'true'){
        $(this).prop('checked', false);
        swal('Please uncheck the selected diseases');
    }else{
        $("#medical_history_details").val('');
        ($(this).is(':checked')) ? $("#medical_history_details").fadeIn() : $("#medical_history_details").fadeOut();
    }
    
});

sub_ped_list = '#cancer,#diabetes,#thyroid,#arthritis,#bypass,#kidney,#gall_bladder,#fracture,#surgery,#disc,#gastric,#asthma,#cataract,#paralysis,#sclerosis,#parkinsons,#seizure,#epilepsy,#atrophy,#lymphoma';

$(sub_ped_list).click( function(){
    if($("#sub_ped_other").is(':checked')){
        $(this).prop('checked', false);
        swal("Please uncheck the  'Other diseases' checkbox");
    }
});

function get_sub_ped_status(other_ped){
    status = false;
    sub_ped_list = '#cancer,#diabetes,#thyroid,#arthritis,#bypass,#kidney,#gall_bladder,#fracture,#surgery,#disc,#gastric,#asthma,#cataract,#paralysis,#sclerosis,#parkinsons,#seizure,#epilepsy,#atrophy,#lymphoma'+other_ped;
    $sub_ped_list_status = $(sub_ped_list);
    if($sub_ped_list_status.is(':checked')){
        status = true;
    }
    return status;
}

/* PED validations */
function validate_ped(){
    errors  = '';
    // Medical History
        if ($("#medical_history_yes").is(':checked')) {   
          sub_ped_status = get_sub_ped_status(',#sub_ped_other');
          if(sub_ped_status == 'false'){
            errors += "Please fill the required details for Question 1 <br/>";
            $return_type = false;
          }
        }

        if ($("#sub_ped_other").is(':checked')) {   
          his_val = $('#medical_history_details').val();
          if(his_val == '' || his_val == ' ' || his_val == null){
            errors += "Please fill the required details for Question 1 <br/>";
            $return_type = false;
          }
        }
        
        // Medical Declined
        if ($("#medical_declined_yes").is(':checked')) {   
          his_val = $('#medical_declined_details').val();
          if(his_val == '' || his_val == ' ' || his_val == null){
            errors += "Please fill the required details for Question 2 <br/>";
            $return_type = false;
          }
        }
        
       // Special Conditions
        if ($("#special_conditions_yes").is(':checked')) {   
          his_val = $('#special_conditions_details').val();
          if(his_val == '' || his_val == ' ' || his_val == null){
            errors += "Please fill the required details for Question 3 <br/>";
            $return_type = false;
          }
        }
    return $.trim(errors);    
}    


$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        } else { 
            if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
            }
        }
    },
    onTabShow: function (tab, navigation, index) {
            id = $(".tab-pane.active").attr('id');
        var $total = navigation.find('li').length;
        var $current = index + 1;
        if(id = 'review'){
                load_preview();
        }
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        }
        if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
        }
    },

});

function sendOTP(e) {
    return policy_cmp_sel = "#policy_cmp", 
    $(policy_cmp_sel).length && "hdfc" == $(policy_cmp_sel).val() ? (validationTime = common.getCookie("hdfc"), 
        "undefined" != validationTime && validationTime > 2 ? (console.log(window.verifycation_status), 
            window.verifycation_status ? (console.log("call validate data1"), 
                validateProposal(e)) : (common.alert(common.msg.unveryfied_user), !1)) : (validateProposal(e) && otp.verifyMobileNumber(), !1)) : void 0
}

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}