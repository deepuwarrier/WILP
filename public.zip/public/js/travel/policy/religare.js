company_id      = $('#company_id').val();
trans_code      = $('#trans_code').val();
api_response    = 0;
function submit_proposal_form(){  
    updated_premium  = $('#updated_premium').val();
    common.loader_msg('Please Wait...');
    $.getJSON(APP_URL + "/travel-insurance/religare/submit_proposal", {
      trans_code : trans_code
    }, function(data) { 
      common.overlay_rem();    
      handle_proposal_response(data);
      
  });
  
}

function handle_proposal_response(data){
    api_response = data;
    if(data.status){
        no_premium_change(data.premium);
    }else if(data.status == false && data.mismatch == true){
        premium_mismatch(data.actual_premium, data.passed_premium);
    }else if(data.status == false && data.error == true){
        swal(data.message);        
    }else{
       window.location= APP_URL + '/travel-insurance/bad_response';
    } 
}

function no_premium_change(premium){
    $.getJSON(APP_URL + "/travel-insurance/no_premium_change", {
      trans_code  : trans_code,
      company_id  : company_id,
      premium     : premium
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
} 

function premium_mismatch(actual_premium, passed_premium){
    $.getJSON(APP_URL + "/travel-insurance/premium_mismatch", {
      trans_code : trans_code,
      company_id  : company_id,
      actual_premium  : actual_premium,
      passed_premium  : passed_premium,
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

$(document).on("click", "#review-again", function() {
    common.overlay_rem();
});

$(document).on("click", "#re-submit", function() {
    common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});
 
$(document).on("click", "#payment-submit", function() {
    common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});


function redirect_gateway(){
    data = api_response.request; 
    update_payment_status();
    post_data(api_response.pg_url, 'post', data);
}

function post_data(actionUrl, method, data) {
    var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
        }
    }
    $('body').append(mapForm);
    mapForm.submit();
}

function set_member_name(qn){
    //Setting Name to Member
    if($('#name0').length){
        $member_1 = $('#name0').val().toUpperCase();
        var container_1 = '#'+qn+'_0_member';
        $(container_1).html($member_1);
    }
    if($('#name1').length){
        var container_2 = '#'+qn+'_1_member';
        $member_2 = $('#name1').val().toUpperCase();
        $(container_2).html($member_2);
    }
    if($('#name2').length){
        var container_3 = '#'+qn+'_2_member';
        $member_3 = $('#name2').val().toUpperCase();
        $(container_3).html($member_3);
    }
    if($('#name3').length){
        var container_4 = '#'+qn+'_3_member';
        $member_4 = $('#name3').val().toUpperCase();
        $(container_4).html($member_4);
    }
    if($('#name4').length){
        var container_5 = '#'+qn+'_4_member';
        $member_5 = $('#name4').val().toUpperCase();
        $(container_5).html($member_5);
    }
    if($('#name5').length){
        var container_6 = '#'+qn+'_5_member';
        $member_6 = $('#name5').val().toUpperCase();
        $(container_6).html($member_6);
    }
}

$("#medical_history_yes").click( function(){
    if($(this).is(':checked')){
        $("#member_container_medical_history").fadeIn();
        set_member_name('medical_history');
    }else{
        $("#member_container_medical_history").fadeOut();
        // $("#sub_ped_container").fadeOut();
        // $("#medical_history_details").val('');
        // $("#medical_history_details").fadeOut();
        // $("#sub_ped_other").prop('checked', false);
    }
});

$("#previous_diag_yes").click( function(){
    if($(this).is(':checked')){
        set_member_name('previous_diag');
        $("#member_container_previous_diag").fadeIn();
    }else{
        $("#member_container_previous_diag").fadeOut();
    }
});

$("#previous_claim_yes").click( function(){
    if($(this).is(':checked')){
        set_member_name('previous_claim');
        $("#member_container_previous_claim").fadeIn();
    }else{
        $("#member_container_previous_claim").fadeOut();
    }
});

member_list  = '#medical_history_member_0_yes,#medical_history_member_1_yes,#medical_history_member_2_yes,#medical_history_member_3_yes,#medical_history_member_4_yes,#medical_history_member_5_yes';
member_list += ',#previous_diag_member_0_yes,#previous_diag_member_1_yes,#previous_diag_member_2_yes,#previous_diag_member_3_yes,#previous_diag_member_4_yes,#previous_diag_member_5_yes';
member_list += ',#previous_claim_member_0_yes,#previous_claim_member_1_yes,#previous_claim_member_2_yes,#previous_claim_member_3_yes,#previous_claim_member_4_yes,#previous_claim_member_5_yes';

$(member_list).click( function(){
    sub_ped_container = $(this).attr('sub-ped-container');
    if($(this).is(':checked')){
        $("#"+sub_ped_container).fadeIn();
    }else{
        $("#"+sub_ped_container).fadeOut();
    }
});

sub_ped_other = '#sub_ped_other_0_yes,#sub_ped_other_1_yes,#sub_ped_other_2_yes,#sub_ped_other_3_yes,#sub_ped_other_4_yes,#sub_ped_other_5_yes';

$(sub_ped_other).click( function(){
    other_container = $(this).attr('other-container');
    if($(this).is(':checked')){
        $("#"+other_container).fadeIn();
    }else{
        $("#"+other_container).fadeOut();
    }
});

qn1_members = '#medical_history_member_0_yes,#medical_history_member_1_yes,#medical_history_member_2_yes,#medical_history_member_3_yes,#medical_history_member_4_yes,#medical_history_member_5_yes';
qn2_members = '#previous_diag_member_0_yes,#previous_diag_member_1_yes,#previous_diag_member_2_yes,#previous_diag_member_3_yes,#previous_diag_member_4_yes,#previous_diag_member_5_yes';
qn3_members = '#previous_claim_member_0_yes,#previous_claim_member_1_yes,#previous_claim_member_2_yes,#previous_claim_member_3_yes,#previous_claim_member_4_yes,#previous_claim_member_5_yes';

function get_member_status(member_id){
    status = false;
    $member_status = $(member_id);
    if($member_status.is(':checked')){
        status = true;
    }
    return status;
}


function get_sub_ped_status(member_id){
    status = false;
    sub_ped =  '#liver_'+member_id+'_yes';
    sub_ped += ',#cancer_'+member_id+'_yes';
    sub_ped += ',#coronary_'+member_id+'_yes';
    sub_ped += ',#kidney_'+member_id+'_yes';
    sub_ped += ',#paralysis_'+member_id+'_yes';
    sub_ped += ',#sub_ped_other_'+member_id+'_yes';
    $member_status = $(sub_ped);
    if($member_status.is(':checked')){
        status = true;
    }
    return status;
}

sub_ped_other = '#sub_ped_other_0_yes,#sub_ped_other_1_yes,#sub_ped_other_2_yes,#sub_ped_other_3_yes,#sub_ped_other_4_yes,#sub_ped_other_5_yes';

function get_other_detail_status(quesion_id,member_id){
    status = true;
    value = $('#'+quesion_id+'_'+member_id+'_details').val();
    if(value == '' || value == ' ' || value == null){
        status = false;
    }
    return status;
}
 
/* PED validations */
function validate_ped(){
    errors  = '';
    if ($("#medical_history_yes").is(':checked')) {   
        member_status = get_member_status(qn1_members);
        if(member_status == 'false'){
        errors += "Please fill the required details for Question 1 <br/>";
        $return_type = false;
        }

        if(member_status == 'true'){
            status = false;
            if($('#medical_history_member_0_yes').length){
                if($('#medical_history_member_0_yes').is(':checked')){
                status = get_sub_ped_status(0);
                    if($('#sub_ped_other_0_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',0);
                    }
                }
            }
            if($('#medical_history_member_1_yes').length){
                if($('#medical_history_member_1_yes').is(':checked')){
                status = get_sub_ped_status(1);
                    if($('#sub_ped_other_1_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',1);
                    }
                }
            }
            if($('#medical_history_member_2_yes').length){
                if($('#medical_history_member_2_yes').is(':checked')){
                status = get_sub_ped_status(2);
                    if($('#sub_ped_other_2_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',2);
                    }
                }
            }
            if($('#medical_history_member_3_yes').length){
                if($('#medical_history_member_3_yes').is(':checked')){
                status = get_sub_ped_status(3);
                    if($('#sub_ped_other_3_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',3);
                    }
                }
            }
            if($('#medical_history_member_4_yes').length){
                if($('#medical_history_member_4_yes').is(':checked')){
                status = get_sub_ped_status(4);
                    if($('#sub_ped_other_4_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',4);
                    }
                }
            }
            if($('#medical_history_member_5_yes').length){
                if($('#medical_history_member_5_yes').is(':checked')){
                status = get_sub_ped_status(5);
                    if($('#sub_ped_other_5_yes').is(':checked')){
                    status = get_other_detail_status('medical_history',5);
                    }
                }
            }
            if(status == 'true'){
            }else{
                errors += "Please fill the required details for Question 1 <br/>";
                $return_type = false;
            }
        }
    }

    if ($("#previous_diag_yes").is(':checked')) {   
        member_status = get_member_status(qn2_members);
        if(member_status == 'false'){
        errors += "Please fill the required details for Question 2 <br/>";
        $return_type = false;
        }
        if(member_status == 'true'){
            status = false;
            if($('#previous_diag_member_0_yes').length){
                if($('#previous_diag_member_0_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',0);
                }
            }
            if($('#previous_diag_member_1_yes').length){
                if($('#previous_diag_member_1_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',1);
                }
            }
            if($('#previous_diag_member_2_yes').length){
                if($('#previous_diag_member_2_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',2);
                }
            }
            if($('#previous_diag_member_3_yes').length){
                if($('#previous_diag_member_3_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',3);
                }
            }
            if($('#previous_diag_member_4_yes').length){
                if($('#previous_diag_member_4_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',4);
                }
            }
            if($('#previous_diag_member_5_yes').length){
                if($('#previous_diag_member_5_yes').is(':checked')){
                    status = get_other_detail_status('previous_diag',5);
                }
            }
            if(status == 'true'){
            }else{
                errors += "Please fill the required details for Question 2 <br/>";
                $return_type = false;
            }
        }
    }

    if ($("#previous_claim_yes").is(':checked')) {   
        member_status = get_member_status(qn3_members);
        if(member_status == 'false'){
        errors += "Please fill the required details for Question 3 <br/>";
        $return_type = false;
        }
        if(member_status == 'true'){
            status = false;
            if($('#previous_claim_member_0_yes').length){
                if($('#previous_claim_member_0_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',0);
                }
            }
            if($('#previous_claim_member_1_yes').length){
                if($('#previous_claim_member_1_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',1);
                }
            }
            if($('#previous_claim_member_2_yes').length){
                if($('#previous_claim_member_2_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',2);
                }
            }
            if($('#previous_claim_member_3_yes').length){
                if($('#previous_claim_member_3_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',3);
                }
            }
            if($('#previous_claim_member_4_yes').length){
                if($('#previous_claim_member_4_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',4);
                }
            }
            if($('#previous_claim_member_5_yes').length){
                if($('#previous_claim_member_5_yes').is(':checked')){
                    status = get_other_detail_status('previous_claim',5);
                }
            }
            if(status == 'true'){
            }else{
                errors += "Please fill the required details for Question 3 <br/>";
                $return_type = false;
            }
        }
    }
    return $.trim(errors);
}


$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        } else { 
            if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
            }
        }
    },
    onTabShow: function (tab, navigation, index) {
            id = $(".tab-pane.active").attr('id');
        var $total = navigation.find('li').length;
        var $current = index + 1;
        if(id = 'review'){
                load_preview();
        }
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        }
        if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
        } 
    },

});

function sendOTP(e) {
    return policy_cmp_sel = "#policy_cmp", 
    $(policy_cmp_sel).length && "hdfc" == $(policy_cmp_sel).val() ? (validationTime = common.getCookie("hdfc"), 
        "undefined" != validationTime && validationTime > 2 ? (console.log(window.verifycation_status), 
            window.verifycation_status ? (console.log("call validate data1"), 
                validateProposal(e)) : (common.alert(common.msg.unveryfied_user), !1)) : (validateProposal(e) && otp.verifyMobileNumber(), !1)) : void 0
}

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}