trans_code     = $('#trans_code').val();
company_id      = $('#company_id').val();
api_response    = 0;
function submit_proposal_form(){  
    common.loader_msg('Please Wait...');
    $.getJSON(APP_URL + "/travel-insurance/star/submit_proposal", {
      trans_code : trans_code
    }, function(data) { 
      common.overlay_rem();    
      handle_proposal_response(data);
      
    });

}

$(document).ready(function(){
    $('#passport_expiry').change(function(){
        $.get(APP_URL + "/travel-insurance/star/get_travel_date", {
            passport_expiry_date : $('#passport_expiry').val()
        } ,function(data) {
            $('#trip_start_date').val(data.selected_date); 
            $('#trip_start_date').datepicker('change', 'minDate', data.min_date);
            $('#trip_start_date').datepicker('change', 'maxDate', data.max_date);
        });
    });
});

function handle_proposal_response(data){
    api_response = data;
    if(data.status){
        no_premium_change(data.pg_request.actual_premium);
    }else if(data.status == false && data.mismatch == true){
        premium_mismatch(data.pg_request.actual_premium, data.pg_request.passed_premium);
    }else if(data.status == false && data.error == true){
        window.location= APP_URL + '/travel-insurance/star/policy/status/offline';
    }else{
        window.location= APP_URL + '/travel-insurance/bad_response';
    }
}

function no_premium_change(premium){
    $.getJSON(APP_URL + "/travel-insurance/no_premium_change", {
      trans_code  : trans_code,
      company_id  : company_id,
      premium     : premium
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

function premium_mismatch(actual_premium, passed_premium){
    $.getJSON(APP_URL + "/travel-insurance/premium_mismatch", {
      trans_code : trans_code,
      company_id  : company_id,
      actual_premium  : actual_premium,
      passed_premium  : passed_premium,
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

// If user click on review button
$(document).on("click", "#review-again", function() {
    common.overlay_rem();
});

// If user Agree for Updated Premium and Submit the form For Payment
$(document).on("click", "#re-submit", function() {
    $("#updated_premium").val(actual_premium);
    redirect_gateway();
});

// If No Premium Mismatch, When User click on make payment button 
$(document).on("click", "#payment-submit", function() {
    common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});

function redirect_gateway(){
    // Redirecting to PG
    update_payment_status();
    window.location = api_response.pg_request.pg_url;
}
   
$(document).on("keyup", "#pincode", function() {
    pincode = $('#pincode').val();
    pincode     = $.trim(pincode);
    if(pincode.length == 6 ){
        common.loader_msg('Please Wait, state and city list is loading...');
        $.getJSON(APP_URL + "/travel-insurance/star/get_state_city_list", {
          trans_code : trans_code,
          pincode : pincode        
        }, function(result) { 
          common.overlay_rem(); 
          if(result.error){
            common.overlay_rem();
            swal('Invalid Pincode');
            $('#state').val('');
            city = '<option hidden="" selected="" disabled="" value="">Select City</option>';
            $('#city').empty(); 
            $('#city').append(city);
            area = '<option hidden="" selected="" disabled="" value="">Select Area</option>';
            $('#cust_area').empty(); 
            $('#cust_area').append(area);
          }else{
            common.overlay_rem();
            $('#state').val(result.state_name.toUpperCase());
            city = '<option hidden="" selected="" disabled="" value="">Select City</option>';
                $.each(result.city, function( index, value ) {
                  city += '<option value = "'+value.city_id+'">'+value.city_name.toUpperCase()+'</option>';
                });
            $('#city').empty(); 
            $('#city').append(city); 
            area = '<option hidden="" selected="" disabled="" value="">Select Area</option>';
            $('#cust_area').empty(); 
            $('#cust_area').append(area);
          }
        });

    }
});

$("#city").change(function () {
    city = this.value;
    pincode = $('#pincode').val();
    app   = '<option hidden="" selected="" disabled="" value="">Select Area</option>';
    common.loader_msg('Please Wait, area list is loading...');
    $.getJSON(APP_URL + "/travel-insurance/star/get_area_list", {
        trans_code : trans_code,
        city : city,
        pincode : pincode        
    }, function(result) { 
        common.overlay_rem(); 
        $.each(result.area, function( index, value ) {
              app += '<option value = "'+value.areaID+'">'+value.areaName.toUpperCase()+'</option>';
        });
        $('#cust_area').empty(); 
        $('#cust_area').append(app);  
    }); 
});

// PED Questions
$("#medical_history_yes").click( function(){
    if($(this).is(':checked')){
        $("#sub_ped_container").fadeIn();
    }else{
        $("#sub_ped_container").fadeOut();
        $("#medical_history_details").val('');
        $("#medical_history_details").fadeOut();
        $("#sub_ped_other").prop('checked', false);
    }
});

// Sub ped
$("#sub_ped_other").click( function(){
    $("#medical_history_details").val('');
    ($(this).is(':checked')) ? $("#medical_history_details").fadeIn() : $("#medical_history_details").fadeOut();

});

sub_ped_list = '#diabetes,#hypertension,#sinusitis,#tonsillitis,#cataract,#hypothyroidism,#lscs,#surgery,#hernia,#hydrocele,#piles,#fistula,#fissures,#bladder_stone,#renal_stone';



function get_sub_ped_status(other_ped){
    status = false;
    sub_ped_list = '#diabetes,#hypertension,#sinusitis,#tonsillitis,#cataract,#hypothyroidism,#lscs,#surgery,#hernia,#hydrocele,#piles,#fistula,#fissures,#bladder_stone,#renal_stone'+other_ped;
    $sub_ped_list_status = $(sub_ped_list);
    if($sub_ped_list_status.is(':checked')){
        status = true;
    }
    return status;
}


/* PED validations */
function validate_ped(){
    errors  = '';
    // Medical History
    if ($("#medical_history_yes").is(':checked')) {
        sub_ped_status = get_sub_ped_status(',#sub_ped_other');
        if(sub_ped_status == 'false'){
            errors += "Please fill the required details for Question 1 <br/>";
            $return_type = false;
        }
    }

    if ($("#sub_ped_other").is(':checked')) {
        his_val = $('#medical_history_details').val();
        if(his_val == '' || his_val == ' ' || his_val == null){
            errors += "Please fill the required details for Question 1 <br/>";
            $return_type = false;
        }
    }


    return $.trim(errors);
}


$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        } else { 
            if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
            }
        }
    },
    onTabShow: function (tab, navigation, index) {
            id = $(".tab-pane.active").attr('id');
        var $total = navigation.find('li').length;
        var $current = index + 1;
        if(id = 'review'){
                load_preview();
        }
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        }
        if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
        }
    },

});

function sendOTP(e) {
    return policy_cmp_sel = "#policy_cmp", 
    $(policy_cmp_sel).length && "hdfc" == $(policy_cmp_sel).val() ? (validationTime = common.getCookie("hdfc"), 
        "undefined" != validationTime && validationTime > 2 ? (console.log(window.verifycation_status), 
            window.verifycation_status ? (console.log("call validate data1"), 
                validateProposal(e)) : (common.alert(common.msg.unveryfied_user), !1)) : (validateProposal(e) && otp.verifyMobileNumber(), !1)) : void 0
}

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}
