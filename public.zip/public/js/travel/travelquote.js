var xhr = covers_xhr = null , $load_cover = 1;

$(document).ready(function() {
    si_value = $('#sum_insured_box').val();
    $(document).on("click",".benefits",function(){
        id = $(this).data('model');
        data = $('#'+id).html();
        $('#BenefitModal').html(data);
        $('#BenefitModal').modal('show');
    });

    $(document).on("click",".breakup",function(){
        id = $(this).data('model');
        data = $('#'+id).html();
        $('#BenefitModal').html(data);
        $('#BenefitModal').modal('show');
    });

    $(function() {
        // For Updating the Sum Insured Value in Quotation Page
        // This button will increment the value
        $('.upqtyplus').click(function(e) {
            // Stop acting like a button
            e.preventDefault();
            // Get its current value
            var currentVal = parseInt($('#sum_insured_box').val());
            var triptype = $('#tripcheck').val();
            var destination = $('#area').val();
            var url = $('#map_si_url').val();
            // If is not undefined
            if (!isNaN(currentVal)) {
                $.ajax({
                    url: url,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
                    },
                    type: 'POST',
                    data: {
                        'type': triptype,
                        'area': destination,
                        'si': currentVal,
                        'ctrl': 'up'
                    },
                    success: function(response) {
                        console.log($.trim(response));
                        $('#sum_insured_box').val($.trim(response));
                        upadte_skip_btn();
                    }
                });
            }
        });

        // This button will decrement the value till 25000
        $(".upqtyminus").click(function(e) {
            // Stop acting like a button
            e.preventDefault();
            // Get its current value
            var currentVal = parseInt($('#sum_insured_box').val());
            var triptype = $('#tripcheck').val();
            var destination = $('#area').val();
            var url = $('#map_si_url').val();
            // If it isn't undefined or its greater than 0
            if (!isNaN(currentVal) && currentVal > 0) {
                $.ajax({
                    url: url,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
                    },
                    type: 'POST',
                    data: {
                        'type': triptype,
                        'area': destination,
                        'si': currentVal,
                        'ctrl': 'down'
                    },
                    success: function(response) {
                        console.log($.trim(response));
                        $('#sum_insured_box').val($.trim(response));
                        upadte_skip_btn();
                    }
                });
            }
        });

        // To show Updating Message to user
        $(document).on('click', '#update-si-btn',function(e) {
            common.loader_msg(common.msg['updated_quote']);
            $('#update-si').submit();
        });
        
        function upadte_skip_btn(){
            new_value = $('#sum_insured_box').val();
            if(si_value != new_value){
                focusIdv();
                if($('#btn-idv-accurate').length == 1){
                    $('#back_to_quotes').remove();
                    $('#btn-idv-accurate').remove();
                    $('#idv_footer').append(update_btn);
                }
                if($('#btn_div_skip').length == 0)
                    $('#idv_footer').append(idv_skip_btn);
            }else{
                unfocusIdv();    
                $('#btn_div_skip').remove();
            }
            $('#btn_div_skip').length == 0
        }
        
        // To show Updating Message to user
        $(document).on('click', '.buy-btn', function(e) {
            $btn_obj = $(this), 
            confirmIDV();
        });

        $(document).on('click','#btn-idv-accurate',function(e){
            unfocusIdv(),
            common.loader_msg(common.msg['submit_form']);
            var id = $btn_obj.attr('data-item');
            $('#buy-policy-'+id).submit();
            common.loader_rem()  
        });

        $(document).on('click', '#back_to_quotes', function(e) {
            // $obj_form_idv[0].reset(), 
            $(this).remove(), 
            unfocusIdv(),
            $("#btn-idv-accurate").remove();     
            $('#idv_footer').append(update_btn);
        });

        $(document).on('click', '#btn_div_skip', function(e) {
            $('#sum_insured_box').val(si_value);
            $(this).remove();
            unfocusIdv();
        });
        
        
        idv_footer_btn = '<a class="pull-left clickable btn-sm boldtext hvr-grow" id="back_to_quotes" style="cursor:pointer;margin:10px 0px 0px 0px;">Back to Quotes</a><a class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn-idv-accurate" style="margin-right:10px;margin-bottom: 20px;float: right;">Info is accurate</a>';
        update_btn = '<button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update-si-btn">Update Quotes<div class="ripple-container"></div></button>';
        idv_skip_btn = '<button type="reset" value="Reset" class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn_div_skip" style="margin-right:10px;margin-bottom: 20px;float: right;">Ignore Changes</button>&nbsp;';

        function confirmIDV() {
            focusIdv(),
            idv_footer = $('#idv_footer').html(), 
            $('#idv_footer').empty(), 
            $('#idv_footer').append(idv_footer_btn)
        }

        function focusIdv() {
            $("#overlay").fadeIn(),
            $("#confirm_update").css("z-index", "1032")
        }

        function unfocusIdv() {
            $("#overlay").fadeOut(),
            $("#confirm_update").css("z-index", "1029")
        }

        // Loader show with message
        function loader_msg(msg) {
            //self.overlay_msg();
            $('#overlay').html("<span class='msg'>" + msg + "<span>");
            $('#overlay').fadeIn();
            $('#overlay').css("opacity", 1);
            $('#overlay').append('<div class="loader">Loading...</div>');
        }
    });

    $(document).on('click', '.filter_quote', function(e) {
        $load_cover = 0;
        common.initQuote();
        var chks = "";
        $(".filter_quote").each(function() {
            if (this.checked) {
                var cd = $(this).val();
                chks += cd + ",";
            }
        });
        
        $("#tata_quote_ctnr_box").html('');
        $("#star_quote_ctnr_box").html('');
        $("#religare_quote_ctnr_box").html('');
        $("#hdfc_quote_ctnr_box").html('');
        
        // load_quotes();
        $("#tata_quote_ctnr_box").append("<span id='tata_loader'></span>");
        common.loader("#tata_loader");
        chks = $.trim(chks);
        url = $('#filter_req').val();
        
        if( xhr != null ) {
            xhr.abort();
            xhr = null;
        }

        xhr = $.get(url,{
        	   chks : chks
        }, function(data, status) { 
            load_quotes();
        });
    }); // End of the filter_quote on click function 

});

function getTransCode(){
    return $('#trans_code').val();
}
// Loading the travel_quotes
function load_quotes(){
    common.initQuote();
    $('#quote_ctnr_box').empty();
    load_hdfc_quotes();
    //load_tata_quotes();
    load_star_quotes();
    load_religare_quotes();
    load_fggi_quotes();
} 

function load_tata_quotes(){
    $("#tata_quote_ctnr_box").append("<span id='tata_loader'></span>");
    common.loader("#tata_loader");
    $.ajax({
        url: APP_URL + "/travel-insurance/load_tata_quotes",
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: {'trans_code': getTransCode()},
        type: 'POST',
        success: function(data, status) {     
            common.loader_rem();
            $("#load_quote_box").html('');
            $("#tata_loader").remove();
            if(data!=null){
                $("#tata_quote_ctnr_box").html(data);
                if($load_cover)
                    load_covers('tata');
            }
            sort_div();
        }
    });
}

function load_fggi_quotes(){
    $("#fggi_quote_ctnr_box").append("<span id='fggi_loader'></span>");
    common.loader("#fggi_loader");
     $.ajax({
        url: APP_URL + "/travel-insurance/load_fggi_quotes",
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: {'trans_code': getTransCode()},
        type: 'POST',
        success: function(data, status) {     
            common.loader_rem();
            $("#load_quote_box").html('');
            $("#fggi_loader").remove();
            if(data!=null){
                $("#fggi_quote_ctnr_box").html(data);
                if($load_cover)
                load_covers('tata');
            }
            sort_div();
        }
    });
}

function load_hdfc_quotes(){
    $("#hdfc_quote_ctnr_box").append("<span id='hdfc_loader'></span>");
    common.loader("#hdfc_loader");
    $.ajax({
        url: APP_URL + "/travel-insurance/load_hdfc_quotes",
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: {'trans_code': getTransCode()},
        type: 'POST',
        success: function(data, status) {  
            common.loader_rem();
            $("#load_quote_box").html('');
            $("#hdfc_loader").remove();
            if(data!=null){
                $("#hdfc_quote_ctnr_box").html(data);
                if($load_cover)
                load_covers('hdfc');
            }
            sort_div();
        }
    });
}

function load_star_quotes(){
    $("#star_quote_ctnr_box").append("<span id='star_loader'></span>");
    common.loader("#star_loader");
    $.ajax({
        url: APP_URL + "/travel-insurance/load_star_quotes",
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: {'trans_code': getTransCode()},
        type: 'POST',
        success: function(data, status) {     
            common.loader_rem();
            $("#load_quote_box").html('');
            $("#star_loader").remove();
            if(data!=null){
                $("#star_quote_ctnr_box").html(data);
                if($load_cover)
                load_covers('star');
            }
            sort_div();
        }
    });
}

function load_religare_quotes(){
    $("#religare_quote_ctnr_box").append("<span id='religare_loader'></span>");
    common.loader("#religare_loader");
     $.ajax({
        url: APP_URL + "/travel-insurance/load_religare_quotes", 
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: {'trans_code': getTransCode()},
        type: 'POST',
        success: function(data, status) { 
            common.loader_rem();
            $("#load_quote_box").html('');
            $("#religare_loader").remove();
            if(data!=null){	
                $("#religare_quote_ctnr_box").append(data);
                if($load_cover)
                load_covers('religare');
            }

            sort_div();
        }
    });
}

function load_covers(company,plancode){
    plancodes = [];
    
    $('.plancode').each(function(k,v){
        plancodes[k] = $(this).val();
    });
    
    $("#cover_box").append("<span id='cover_loader'></span>");
    common.loader("#cover_loader");
    
    if( covers_xhr != null ) {
        covers_xhr.abort();
        covers_xhr = null;
    }

    covers_xhr = $.ajax({
        url: APP_URL + "/travel-insurance/load_covers", 
        headers: {
            'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
        },
        data: { trans_code: getTransCode(),
                company : company,
                plancodes : plancodes},
        type: 'POST',
        success: function(data, status) { 
            common.loader_rem();
            $("#cover_loader").remove();
            if(data!=0)
                $("#cover_box").html(data);
        }
    });
}

function sort_div(){
    //check_quote_reponse();
    var divList = $(".quote-box");
    divList.sort(function(a, b){ return $(a).data("listing-price")-$(b).data("listing-price")});
    $("#quote_ctnr_box").html(divList);

    var noQuotes = $(".no_quotes_box");
    noQuotes.each(function(key,value){
      $("#no_quotes").append(value);
    });

    if(noQuotes.length > 0){
      $("#no_quote_text").show();
      $("#no_quote_text").removeClass("hidden");
    }
}

function check_quote_reponse(){
    religare_quote = $("#religare_quote_ctnr_box").text().trim();
    tata_quote = $("#tata_quote_ctnr_box").text().trim();
    hdfc_quote = $("#hdfc_quote_ctnr_box").text().trim();
    star_quote = $("#star_quote_ctnr_box").text().trim();
    fggi_quote = $("#fggi_quote_ctnr_box").text().trim();
    
    if(hdfc_quote == '' && 
       religare_quote == '' && 
       tata_quote == '' && 
       star_quote == '' && 
       fggi_quote == ''){
       $("#load_quote_box").html('<h5 class="card-title price"> -- No Quotes generated for your Request -- </h5>');
    }
}

