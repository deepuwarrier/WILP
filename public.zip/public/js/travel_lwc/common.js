$(document).ready(function(){

common = {
		msg: {	"submit_form" : "Please Wait...",	
				"change_state": "Please wait city is loaded...",
				"payment_redirect" : "Please wait while we redirect you to the payment gateway of the Insurance Company",
				'fetch_quote' : 'Please wait while we fetch the best quotes for you...',
				'updated_quote' : 'Please wait while we update your quotes.'
		},

		//call ajax post request
		ajaxPostRequest: function(url,data,onSuccess){
			$.ajax({
		 			type:'POST',
		 			url: url,
		 			data: data,
		 			dataType: "json"
 			}).done(function(data){
 				onSuccess(data);
 			});
		},

		//call ajax post request
		ajaxPostRequestWithOption: function(url,data,onSuccess,opt){
			$.ajax({
		 			type:'POST',
		 			url: url,
		 			data: data,
		 			dataType: "json"
 			}).done(function(data){
 				onSuccess(data,opt);
 			});
 			
		},

		// call ajax post request with overlay
		ajaxPostRequestWithOverlay: function(url,data,onSuccess,msg){
			self.overlay_msg(msg);
			$.ajax({
		 			type:'POST',
		 			url: url,
		 			data: data,
		 			dataType: "json"
 			}).done(function(data){
 				onSuccess(data);
 			}).always(function(){
 				self.overlay_rem();
 			});
		},

		// call ajax post request with overlay
		ajaxPostRequestWithLoader: function(url,data,onSuccess,msg){
			self.loader_msg(msg);
			$.ajax({
		 			type:'POST',
		 			url: url,
		 			data: data,
		 			dataType: "json"
 			}).done(function(data){
 				onSuccess(data);
 			}).always(function(){
 				self.loader_rem();
 			});
		},

		// overlay show with message
		overlay_msg: function(msg){
			//self.loader_rem();
		  	$('#overlay').html("<span class='msg'>"+msg+"<span>");
		  	$('#overlay').fadeIn();
		  	$('#overlay').css("opacity",1);
		},

		loader_msg: function(msg){
			//self.overlay_msg();
		  	$('#overlay').html("<span class='msg'>"+msg+"<span>");
		  	$('#overlay').fadeIn();
		  	$('#overlay').css("opacity",1);
		  	$('#overlay').append('<div class="loader">Loading...</div>');
		},		

		// remove overlay 
		overlay_rem: function(){
			$('#overlay').empty();
			$('#overlay').fadeOut();
		},

		// remove overlay 
		loader_rem: function(){
			$('#overlay').empty();
			$('#overlay').fadeOut();
		}

	}

});