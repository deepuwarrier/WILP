//Aadhaar Number spacing after 4 digits
$('#aadhaar').keyup(function() {
        var num = $(this).val().split(" ").join(""); // remove hyphens
        var num = $(this).val().split("-").join(""); // remove hyphens
         if (num.length > 0) {
           num = num.match(new RegExp('.{1,4}', 'g')).join("-");
         }
         $(this).val(num);
});

function load_dob_list(){
	count = $('#travelcount').val();  
	  for(i=0; i<count; i++){  
	    $('#dob'+i).datepicker({
	      dateFormat: 'dd-mm-yy',
	      changeMonth: true,
	      changeYear: true,
	      minDate: $('#dob'+i).attr('min-date'),
	      maxDate: $('#dob'+i).attr('max-date'),
	      yearRange: "-90:+1"});
	  } 
  if($('#guardian_dob').length){
  $('#guardian_dob').datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        defaultDate: $('#guardian_dob').attr('min-date'),
        minDate: $('#guardian_dob').attr('min-date'),
        maxDate: $('#guardian_dob').attr('max-date'),
        yearRange: "-90:+1"});  
  }

  if($('#sponser_dob').length){
  $('#sponser_dob').datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        defaultDate: $('#sponser_dob').attr('min-date'),
        minDate: $('#sponser_dob').attr('min-date'),
        maxDate: $('#sponser_dob').attr('max-date'),
        yearRange: "-90:+1"});  
  }

  if($('#passport_expiry').length){
  $('#passport_expiry').datepicker({
        dateFormat: 'dd-mm-yy',
        changeMonth: true,
        changeYear: true,
        defaultDate: $('#passport_expiry').attr('min-date'),
        minDate: $('#passport_expiry').attr('min-date'),
        maxDate: $('#passport_expiry').attr('max-date')});  
  }
}

function load_trip_list(){
	$('#trip_start_date').datepicker({
		  onSelect: function(dateText) {
			  get_end_date($('#trip_start_date').val(), $('#trip_start_date').attr('max-duration'));
		  },
	      dateFormat: 'dd-mm-yy',
	      changeMonth: false,
	      changeYear: false,
	      minDate: $('#trip_start_date').attr('min-date'),
	      maxDate: $('#trip_start_date').attr('max-date'),
	      yearRange: "-90:+1"});
}

function get_end_date(date, duration){
	common.loader_msg('Getting Trip End date');
	$.get(APP_URL + "/travel-insurance/get_trip_end_date", {
  	  start_date : date,
  	  duration   : duration
    }, function(data, status) {
       common.overlay_rem();
       $('#trip_end_date').val($.trim(data))
    });
}

$(document).on("click","#travel-btn-pay",function(){
  if(check_terms()){
     continue_submission();
  }
});

function continue_submission(){
  collect_data_status();
  var delay = 3000;
  setTimeout(function() {
    submit_proposal_form();
  }, delay);
}

function check_terms(){
  $return_type = true;
  company_id   = $('#company_id').val();
  errors = "";
  if($('#fst_disclaimer').length){ 
    if($('#fst_disclaimer').prop('checked')){
      $return_type = true;
    }else {
      $return_type = false;
      errors += 'Please accept terms and conditions';
      $( "#travel_terms_box" ).effect( "shake", {times:3}, 1000 );
    }
  }

  if($return_type && company_id == 'tata'){
    $return_type = false;
    // in tata.js
    get_user_agreement();
  }
    
  if(errors != ""){
    title = 'Errors : ';
    common.overlay_rem(); 
    swal(errors);
  }

  return $return_type;
}

function update_payment_status(){
    action = 'proceed_payment';
    trans_code = $('#trans_code').val();
    $.get(APP_URL + "/travel-insurance/update_payment_status", {
      trans_code  : trans_code,
      category    : action
    }, function(data) { 
    });
}


// otp implemention
var otp = new (function ($) {
    self = this;
            policy_cmp_sel = '#policy_cmp',
            mobile = '',
            $token = $('#_token'),
            $otp_gen = $('#travel_otp_gen'),
            $very_otp = $('#travel_very_otp');
            verifycation_status = 0;
            $obj_proposer = $("#communication");

    function genrateOtp() {
        b = {_token: $token.val(), mobile: mobile}
        a = $otp_gen.val();
        console.log(b);
        console.log(a);
        common.ajaxPostRequestWithLoader(a, b, function (data) {
            
            console.log("Genrate Otp Data");
            console.log(data);
            if (data) {
                if(typeof data.overLimit != undefined && data.overLimit){
                    console.log(data);
                    common.alert("You exceeded the maximum varification limit");
                    return false;
                }

                if (typeof data.status != undefined) {
                    //When mobile is verified                   
                    if(data.otp){                       
                            if (data.status) {
                                console.log("check what happen"+otp.getMobile());
                                window["'"+otp.getMobile()+"'"] = 1;
                                $(".wizard-card").bootstrapWizard("next");
                            }else{
                                verificationDisplay(mobile);
                            }
                    } else if (data.status){
                        verificationDisplay(mobile);
                    }
                    else{
                        common.alert(common.verify_otp_not_gen);
                        return false;
                    }
                }
            }
        }, common.msg['gen_code']);
    }

    function verificationDisplay(mobile) {
        var status = 0;
        swal({
            title: '<b>Enter Verification Code</b>',
            text: 'Please Check Your text message at the phone number ' + mobile,
            input: 'text',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: function (text) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        if (text == '') {
                            reject(common.msg['enter_otp']);
                        } else if (text.length != 4) {
                            reject(common.msg['otp_length']);
                        } else {
                            resolve()
                        }
                    }, 2000)
                })
            },
            allowOutsideClick: false
        }).then(function (text) {
            status = verifyCode(text);
        })
    }

    function verifyCode(code) {
        b = {_token: $token.val(), code: code}
        a = $very_otp.val();
        var status = 0;
        common.ajaxPostRequest(a, b, function (data) {
            if (data) {
                if (typeof data.status != undefined) {
                    window[""+otp.getMobile()] = data.status;
                    if (window[""+otp.getMobile()]) {
                        common.setCookie('hdfc', 3, 1);
                        $(".wizard-card").bootstrapWizard("next");
                        common.alert(common.msg['user_verified']);
                    } else
                        common.alert('Sorry! OTP Varification failed');
                }
            }
        });

        if (window.verified == undefined) {
            window.verified = 1;
        } else {
            window.verified = window.verified + 1;
        }
        common.setCookie('hdfc', window.verified, 1);
    }
    return {
        self: this,
        verifycation_status: verifycation_status,
        verified: window.verified,
        getMobile: function(){
            return $('#mobile').val();
        },
        verifyMobileNumber: function () {
            console.log('verifyMobileNumber');
            mobile = this.getMobile();
            return genrateOtp();
        }
    }

})(jQuery);

// ajax call
function ajaxPostRequest(url,data,onSuccess){
    $.ajax({
            type:'POST',
            url: url,
            data: data,
            dataType: "json"
    }).done(function(data){
        onSuccess(data);
    });
}


//Premium Breakup
$(document).on("click","#breakup",function(e){
common.loader_msg(common.msg['submit_form']);
e.preventDefault();
plan_code = $(this).attr('plan-code'); 
policy_id = $(this).attr('quote-id');
url = $(this).attr('data-url');
$.get(
  url, {
      'code': plan_code,
      'policy_id': policy_id
  },
  function(data) {
    common.loader_rem();
    $('#premiumBreakup').html(data);
    $('#premiumBreakup').modal('show');
  }
  );      
                
}); 

// Package Benefits
$(document).on("click","#benefits",function(e){
  common.loader_msg(common.msg['submit_form']);
  e.preventDefault();
  plan_code = $(this).attr('plan-code'); 
  policy_id = $(this).attr('quote-id');
  url = $(this).attr('data-url');
  $.get(
  url, {
      'code': plan_code,
      'policy_id': policy_id
  },
  function(data) {
    common.loader_rem();
    $('#BenefitModal').html(data);
    $('#BenefitModal').modal('show');
  }
  );    
                
}); 

function collect_data_status(){
  $.get(APP_URL + "/travel-insurance/get_confirm_box", {
  }, function(data, status) {     
	  common.overlay_msg(data);
  });
}

function serilazeArrToArr(a){
  var b = {};
  $.each(a,function(c,d){
    b[""+d.name] = d.value;
  });
  return b;
}

 function serilazeInnerArr(a){
  var b = {};
  $.each(a,function(c,d){         
    if(d.name.indexOf('[]') != -1){
       if(b[""+d.name] == 'undefined' || b[""+d.name] == undefined){
        b[""+d.name] = [];    
    }
    b[""+d.name][b[""+d.name].length] = d.value;
    }else{
        b[""+d.name] = d.value;
    }
              
    });
    return b;
 }

 function set_proposal_data(fields) {
    url           = $('#set_data').val();
    id            = $(".tab-pane.active").attr('id');
    fields._token = $('#_token').val();
    fields.id     = id;
    fields.trans_code = $('#trans_code').val();
    fields.trip_end_date = $('#trip_end_date').val() || "";
    $.ajax({
    	   type: "GET",
    	   data: fields,
    	   url: url,
    	   success: function(data){}
    	});
 }
 
//State Dropdown On change event
 $("#state").change(function () {
 	common.loader_msg(common.msg['change_state']);
     state_id  = this.value;
     url       = $('#city').attr('data-url');
     app       = '<option hidden="" selected="" disabled="" value="">Select City</option>';
     company_column = $('#company_code').val();
     token     = $('#_token').val();
     $.ajax({
       method: "GET",
       url: url,
       data: { '_token': token , 
    	           'state_code' : state_id, 
    	           'company_column' : company_column 
    	   },
       dataType : 'json'
     }).done(function(data) {
     	common.overlay_rem();
        if(data.status){
        	   app += data.html;
        }else{
        	   swal('Unable to fetch City');
        }   
        $('#city').empty(); 
    	    $('#city').append(app); 
     }); 
 });
 
function load_preview(){
   $("#preview_box").append("<span id='preview_loader'></span>");
   common.loader("#preview_loader");
   trans_code = $('#trans_code').val();
   $.get(APP_URL + "/travel-insurance/load_preview", {
	  trans_code : trans_code
	}, function(data, status) {     
	  common.loader_rem();
	  $("#preview_box").html('');
	  $("#preview_loader").remove();
	  if(data!=null){
	    $("#preview_box").html(data);
	  }
   });
}

// Preview Buttons click
$(document).on("click", "#traveler_preview", function () {
    $('#travel_btn').click();
});

$(document).on("click", "#communication_preview", function () {
    $('#communication_btn').click();
});

$(document).on("click", "#travel_details_preview", function () {
    $('#travel_details_btn').click();
    $('#academic_btn').click();
});

$(document).on("click", "#medical_his_preview", function () {
    $('#medical_btn').click();
});

