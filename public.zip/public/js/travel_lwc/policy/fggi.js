actual_premium  = 0;
passed_premium  = 0;
api_response    = 0;

company_id      = $('#company_id').val();
trans_code      = $('#trans_code').val();

function submit_proposal_form(){  
    common.loader_msg('Please Wait...');  
    $.getJSON(APP_URL + "/travel-insurance/fggi/submit_proposal", {
	  trans_code : trans_code
	}, function(data) { 
      common.overlay_rem();    
	  handle_proposal_response(data);
      
  });
  
}

function handle_proposal_response(data){
    api_response = data;
    if(data.status){
        no_premium_change(data.premium);
    }else if(data.status == false && data.mismatch == true){
        premium_mismatch(data.actual_premium, data.passed_premium);
    }else if(data.status == false && data.error == false && data.ped == true){
        window.location= APP_URL + '/travel-insurance/fggi/policy/status/offline';
    }else if(data.status == false && data.error == true){
        swal(data.message);        
    }else{
        window.location= APP_URL + '/travel-insurance/bad_response';
    } 
}

function no_premium_change(premium){
    $.getJSON(APP_URL + "/travel-insurance/no_premium_change", {
      trans_code  : trans_code,
      company_id  : company_id,
      premium     : premium
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
} 

function premium_mismatch(actual_premium, passed_premium){
    $.getJSON(APP_URL + "/travel-insurance/premium_mismatch", {
      trans_code  : trans_code,
      company_id  : company_id,
      actual_premium  : actual_premium,
      passed_premium  : passed_premium,
    }, function(data) { 
       common.overlay_msg(data.html);   
    });
}

$(document).on("click", "#review-again", function() {
    common.overlay_rem();
});

$(document).on("click", "#re-submit", function() {
    common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});
 
$(document).on("click", "#payment-submit", function() {
	common.loader_msg(common.msg['payment_redirect']);
    redirect_gateway();
});


function redirect_gateway(){
	data = api_response.request; 
    update_payment_status();
    post_data(api_response.pg_url, 'post', data);
}

function post_data(actionUrl, method, data) {
    var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
        }
    }
    $('body').append(mapForm);
    mapForm.submit();
}


// PED Questions
$("#medical_history_yes").click( function(){
	$("#medical_history_details").val('');
    ($(this).is(':checked')) ? $("#medical_history_details").fadeIn() : $("#medical_history_details").fadeOut();
});

$("#medical_declined_yes").click( function(){
	$("#medical_declined_details").val('');
    ($(this).is(':checked')) ? $("#medical_declined_details").fadeIn() : $("#medical_declined_details").fadeOut();
});

$("#special_conditions_yes").click( function(){
	$("#special_conditions_details").val('');
    ($(this).is(':checked')) ? $("#special_conditions_details").fadeIn() : $("#special_conditions_details").fadeOut();
});
 
// PED Questions ends

$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        } else { 
            if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
            }
        }
    },
    onTabShow: function (tab, navigation, index) {
    	    id = $(".tab-pane.active").attr('id');
        var $total = navigation.find('li').length;
        var $current = index + 1;
        if(id = 'review'){
        		load_preview();
        }
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        id = $(".tab-pane.active").attr('id');
        var $valid = validateProposal(id);
        if (!$valid) {
            return !1
        }
        if(id === 'communication'){
                var n = validateProposal(id);
                policy_cmp_sel = '#policy_cmp';
                check_v = window["'"+otp.getMobile()+"'"];
                return (id == "communication" && $(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc')  ?
                            (!check_v || check_v == 'undefined')    ?
                                (validateProposal(id)) ?
                                    (otp.verifyMobileNumber(),false)
                                : false
                    : validateProposal(id)
                : validateProposal(id);
        } 
    },

});

function sendOTP(e) {
    return policy_cmp_sel = "#policy_cmp", 
    $(policy_cmp_sel).length && "hdfc" == $(policy_cmp_sel).val() ? (validationTime = common.getCookie("hdfc"), 
        "undefined" != validationTime && validationTime > 2 ? (console.log(window.verifycation_status), 
            window.verifycation_status ? (console.log("call validate data1"), 
                validateProposal(e)) : (common.alert(common.msg.unveryfied_user), !1)) : (validateProposal(e) && otp.verifyMobileNumber(), !1)) : void 0
}

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}