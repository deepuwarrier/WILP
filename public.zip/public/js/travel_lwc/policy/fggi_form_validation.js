if (typeof validate_lib != 'undefined') {
    form_field = {
        "name[]":"fullname",
        "aadhaar_num":"aadhar_no",
        "nomineename":"fullname",
        "nomineerel":"required",
        "passport[]":"passport",
        "dob_list[]":'cust_dob_dash_d_m_y',
        "email":"email",
        "mobile":"mobile",
        "house_name":"houseno",
        "street":"street",
        "state":"required",
        "city":"required",
        "pincode":"pincode",

        "trip_start_date":"tcust_dob",
    };
    form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field);
} else {
    console.error("import validator_lib.js for validation");
}

function validateProposal(id){
    form_id = 'buy_policy_form';
    is_validate = validate_lib.isValidate(form_id);
    field  = $("#" + id + " :input:visible").serializeArray();
    fields = serilazeInnerArr(field);
    if(is_validate)
        set_proposal_data(fields); 

    return is_validate;
}
