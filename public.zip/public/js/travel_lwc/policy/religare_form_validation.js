if (typeof validate_lib != 'undefined') {
    form_field = {
        "name[]":"fullname",
        "dob[]":"tcust_dob",
        "aadhaar_num":"aadhar_no",
        "nomineename":"fullname",
        "nomineerel":"required",
        "passport[]":"passport",
        
        "email":"email",
        "mobile":"mobile",
        "house_name":"houseno",
        "street":"street",
        "state":"required",
        "city":"required",
        "pincode":"pincode",

        "university_name":"university_name",
        "program_name":"required",
        "program_duration":"program_dur",
        "university_address":"uni_addr",
        "university_country":"str_sp",
        "university_state":"str_sp",
        "university_city":"str_sp",
        "sponser_name":"str_sp",
        "sponser_dob":"tcust_dob",

        "trip_start_date":"tcust_dob",
    };
    // dayanmic add form group validation
    req_frm_grp_class = ["medical_history","previous_diag","previous_claim"];
    length = $(".medical_history").length;
    while(length){
        length--;
        req_frm_grp_class.push("medical_history_"+length);
    }
    validate_lib.addFormGrpReq(req_frm_grp_class);

    form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field);
} else {
    console.error("import validator_lib.js for validation");
}

function validateProposal(id){
    form_id = 'buy_policy_form';
    is_validate = validate_lib.isValidate(form_id);
    field  = $("#" + id + " :input:visible").serializeArray();
    fields = serilazeInnerArr(field);
    if(is_validate)
        set_proposal_data(fields); 

    return is_validate;
}