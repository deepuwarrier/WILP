validater = function($){
	format = {
		string : {  pattern: "^[a-zA-Z]+$",
			flags: "i",
			message: "can only contain a-z and A-Z"
		},
		number : {
			pattern: "^\\d+$"
		},
		alphanumerical: {
			pattern: "^([\\d]*[a-zA-Z]*)+$"  
		},
		dateformat: {
			pattern: "^[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}$"
		},
		name: {
			pattern: "^([a-zA-Z]*[ ]*)+$"
		},
		fullname: {
			pattern: "^[a-zA-Z'.\\s]{1,50}"
		}
	};

	function data_validate(field,validation_rule){
		//console.log(JSON.stringify(validation_rule));
	    var fields = {};
	    $.each(field,function(key,value){
	          fields[""+value.name] = value.value;
	    });
	    //console.log(JSON.stringify(fields));
	    error = validate(fields,validation_rule);
	    return error;
	}

	rules = { name : { format: format.string }

	}	
	return{ check : data_validate,getRules : function(){ return rules }
	}

}(jQuery)
