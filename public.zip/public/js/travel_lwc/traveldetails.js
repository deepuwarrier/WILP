$(document).ready(function(){
    // active button selector
    active_type_selector = '.type.active';
    active_area_selector = '.area.active';
    active_duration_selector = '.duration.active';
    active_std_duration_selector = '.std_duration.active';
    trans_code = $('#trans_code').val();
          
  // When User selects Single Trip
  $(document).on('click','#single_trip',function(){
    $('#trip_type').val('S');
    $("#area_container").append("<span id='area_loader'></span>");
    common.loader("#area_loader");
    $.getJSON(APP_URL + "/travel-insurance/home/load_travel_area", {
        trans_code : trans_code,
        trip_type   : 'single_trip'
    }, function(data) {
         common.overlay_rem();
         $("#area_loader").remove();
         $("#area_container").html(data.html);
    });
    $('.wizard-card').bootstrapWizard('next');
  });

  // When User selects Annual Multi Trip
  $(document).on('click','#multi_trip',function(){
    $('#trip_type').val('M');
    $("#area_container").append("<span id='area_loader'></span>");
    common.loader("#area_loader");
    $.getJSON(APP_URL + "/travel-insurance/home/load_travel_area", {
        trans_code : trans_code,
        trip_type   : 'multi_trip'
    }, function(data) {
        common.overlay_rem();
        $("#area_loader").remove();
        $("#area_container").html(data.html);
    });
    $('.wizard-card').bootstrapWizard('next');
  });

  // When User selects Student Trip
  $(document).on('click','#student_trip',function(){
    $('#trip_type').val('ST');
    $("#area_container").append("<span id='area_loader'></span>");
    common.loader("#area_loader");
    $.getJSON(APP_URL + "/travel-insurance/home/load_travel_area", {
        trans_code : trans_code,
        trip_type   : 'student_trip'
    }, function(data) {
        common.overlay_rem();
        $("#area_loader").remove();
        $("#area_container").html(data.html);
    });
    $('.wizard-card').bootstrapWizard('next');
  });

  // When User clicks proceed duration
  $(document).on('click','#proceed_duration',function(){
    selected_duration = $('.screen').text();
    if(selected_duration == 0 || selected_duration == ''){
      swal('Please select a Travel duration & click on the Proceed Button');
    }else if(selected_duration > 180){
      swal('Maximum duration should be 180 days');
    }else{
      $('#trip_duration').val(selected_duration); 
      $('.wizard-card').bootstrapWizard('next');
      trip_type = $('#trip_type').val();
      $("#traveller_container").append("<span id='traveller_list_loader'></span>");
      common.loader("#traveller_list_loader");
      $.getJSON(APP_URL + "/travel-insurance/home/load_traveller_list", {
          trans_code : trans_code,
          trip_type   : trip_type
      }, function(data) {
           common.overlay_rem();
           $("#traveller_list_loader").remove();
           $("#traveller_container").html(data.html);
      });
    }
  });

  // When User clicks add traveller
  $(document).on('click','#add_traveller',function(){
    status = validate_age_relationship();
    if(status == 'true'){
    field  = $("#" + 'traveller_info_form' + " :input:visible").serializeArray();
    fields = serilazeInnerArr(field);
    common.loader_msg("Adding a new member to the list...");
    $.ajax({
         type: "GET",
         data: fields,
         url: APP_URL + "/travel-insurance/home/add_new_traveller",
         dataType: "json",
         success: function(data){
          common.overlay_rem();
          if(data.status == false){
            msg = 'You have reached the Limit </br>';
            msg += 'Maximum No. Travellers is limited to 6';
            swal(msg);
          }else{
             $("#member_container").append(data.html);
          }         
         }
      });
    }
    
  });

  $(document).on('click','#remove_traveller',function(){
    $(this).parent().parent().remove();
  });  

  $(document).on('change','.relationship',function(){
    common.loader_msg("Fetching Age List...");
    relationship = $(this).val();
    age_list_id = $(this).attr('age-id');
    $('#'+age_list_id).empty();
    field  = $("#" + 'traveller_info_form' + " :input:visible").serializeArray();
    fields = serilazeInnerArr(field);
    $.ajax({
         type: "GET",
         data: fields,
         url: APP_URL + "/travel-insurance/home/load_traveller_age_list",
         dataType: "json",
         success: function(data){
          common.overlay_rem();
          $('#'+age_list_id).empty();
          $('#'+age_list_id).append(data.html);
         }
    });

  });


  function validate_age_relationship(){
    status = true;
    error = '';
    $('.relationship').each(function(){
      if($(this).val() == null){
        error += 'Please select a relationship<br>';
        status = false;
      } 
    });

    $('.age').each(function(){
      if($(this).val() == null){
        error += 'Please select age<br>';
        status = false;
      } 
    });

    if(error != ''){
      swal(error);
    }
    return status;
  }

  area_list = '#world_wide,#world_wide_excl_usa,#world_wide_excl_usa_can,#asia,#africa,#europe,#schengen';

  // When User selects Area List
  $(document).on('click',area_list,function(){
    trip_type = $('#trip_type').val();
    area_id   = $(this).attr('info-id');
    $('#trip_area').val(area_id); 
    $("#duration_container").append("<span id='duration_loader'></span>");
    common.loader("#duration_loader");
    $.getJSON(APP_URL + "/travel-insurance/home/load_travel_duration", {
        trans_code : trans_code,
        trip_type   : trip_type
    }, function(data) {
         common.overlay_rem();
         $("#duration_loader").remove();
         $("#duration_container").html(data.html);
    });
    $('.wizard-card').bootstrapWizard('next');
  });

  amt_duration_list = '#30_days,#45_days,#60_days,#90_days';

  // When User selects Annual multitrip duration List
  $(document).on('click',amt_duration_list,function(){
    duration_id   = $(this).attr('info-id');
    $('#amt_duration').val(duration_id); 
    $('.wizard-card').bootstrapWizard('next');
    trip_type = $('#trip_type').val();
      $("#traveller_container").append("<span id='traveller_list_loader'></span>");
      common.loader("#traveller_list_loader");
      $.getJSON(APP_URL + "/travel-insurance/home/load_traveller_list", {
          trans_code : trans_code,
          trip_type   : trip_type
      }, function(data) {
           common.overlay_rem();
           $("#traveller_list_loader").remove();
           $("#traveller_container").html(data.html);
    });
  });

  std_duration_list = '#std_30,#std_60,#std_90,#std_120,#std_180,#std_270,#std_one,#std_456,#std_546,#std_636,#std_two';
  
  // When User selects Student  duration List
  $(document).on('click',std_duration_list,function(){
    duration_id   = $(this).attr('id');
    $('#std_duration').val(duration_id); 
    $('.wizard-card').bootstrapWizard('next');
    trip_type = $('#trip_type').val();
      $("#traveller_container").append("<span id='traveller_list_loader'></span>");
      common.loader("#traveller_list_loader");
      $.getJSON(APP_URL + "/travel-insurance/home/load_traveller_list", {
          trans_code : trans_code,
          trip_type   : trip_type
      }, function(data) {
           common.overlay_rem();
           $("#traveller_list_loader").remove();
           $("#traveller_container").html(data.html);
    });
  });
    
  function removeActive(){
    $("#1").removeClass("active");
    $("#2").removeClass("active");
    $("#3").removeClass("active");
    $("#4").removeClass("active");
  }

  // When User select a button, that button will set active
  $(document).on('click','.type,.area,.travelers,.duration,.std_duration',function(){
    $(this).siblings().removeClass("active");
    $(this).addClass("active");
  });

  function clickHandler(){
      $('.wizard-card').bootstrapWizard('next');
  }
  
  $(document).on('click','#generate_quote',function(){
    save_data();
  });
  
})

// SAVING USER INPUTS INTO DB
function save_data(){
  appended_relationships = '';
  $(".relationship").each(function(){
    appended_relationships += $.trim($(this).val()) + ',';
  });
  appended_relationships = appended_relationships.slice(0,-1);
  $("#relationship_list").val(appended_relationships);
  appended_age = '';
  $(".age").each(function(){
    appended_age += $.trim($(this).val()) + ',';
  });
  appended_age = appended_age.slice(0,-1);
  $("#age_list").val(appended_age);

  data = $('#detail_page_form').serialize();
  if(check_age() == 'true'){
    common.loader_msg(common.msg['fetch_quote']);
    $.ajax({
      url: APP_URL + "/travel-insurance/home/save_user_data",
      type: 'GET',
      data: data,
      dataType: "json",
      success: function(data){ 
        if(data.status){
         $('#generate_quote_form').submit();
        }else{ 
         common.overlay_rem();
         swal(data.msg);
        }
      }
    }); 
  }
}

function check_age(){
  status = true;
  error  = '';
  $('.age').each(function(){
    if($(this).val() == null){
        error += 'Please select age<br>';
        status = false;
    } 

    if(error != ''){
      swal(error);
    }
    
  });
  return status;
}


$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
      id = $(".tab-pane.active").attr('id');
      var $valid = validateInputs(id);
        if (!$valid) {
            return !1
        }
    },
    onTabShow: function (tab, navigation, index) {
        
        var $total = navigation.find('li').length;
        var $current = index + 1;
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
      id = $(".tab-pane.active").attr('id');
        var $valid = validateInputs(id);
        if (!$valid) {
            return !1
        }
        
    },

});

function validateInputs(id){
  $return_type = true;
    errors = '';
    var i  = 1;
    if(id === 'type'){
      type = $('#trip_type').val(); 
      if( type == '' || type == null){
        errors += "Please choose your Trip <br/>";
            $return_type = false;

      }
      if(errors != ""){
            swal(errors);
        }

        return $return_type;
    }
    if(id === 'area'){
      area = $('#trip_area').val(); 
      if( area == '' || area == null){
        errors += "Please choose Area of Travel<br/>";
            $return_type = false;

      }
      if(errors != ""){
            swal(errors);
        }

        return $return_type;
    }

    if(id === 'duration'){
      type = $('#trip_type').val(); 
      if(type == 'M'){
        trip = $('#amt_duration').val();
        if(trip == '' || trip == null){
          errors += "Please choose the Travel duration<br/>";
                $return_type = false;
        }
      }else if(type == 'ST'){
        trip = $('#std_duration').val();
        if(trip == '' || trip == null){
          errors += "Please choose the Travel duration<br/>";
                $return_type = false;
        }
      }else if(type == 'S'){
        trip_duration = $('#trip_duration').val();
        if(trip_duration == '' || trip_duration == 0){
          errors += "Please select a Travel duration & click on the Proceed Button<br/>";
          $return_type = false;
        }
        if(trip_duration > 180){
          errors += "Maximum duration should be 180 days<br/>";
          $return_type = false;
        }
      }
      if(errors != ""){
            swal(errors);
        }

        return $return_type;
    }

    if(id === 'travellers'){ 
      return true;
    }
}

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}



function serilazeInnerArr(a){
  var b = {};
  $.each(a,function(c,d){         
    if(d.name.indexOf('[]') != -1){
       if(b[""+d.name] == 'undefined' || b[""+d.name] == undefined){
        b[""+d.name] = [];    
    }
    b[""+d.name][b[""+d.name].length] = d.value;
    }else{
        b[""+d.name] = d.value;
    }
              
    });
    return b;
 }

 function serilazeArrToArr(a){
  var b = {};
  $.each(a,function(c,d){
    b[""+d.name] = d.value;
  });
  return b;
}



