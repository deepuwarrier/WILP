$("#cust_dob").datepicker({
dateFormat: "dd-M-yy",
changeMonth: !0,
changeYear: !0,
minDate: $("#cust_dob").attr("data-minYear"),
maxDate: $("#cust_dob").attr("data-maxYear"),
yearRange: "-90:+1"
});

$("#proposer_store").click(function() {    	store_proposal_data ();		});	
$("#address_store").click(function() {    	store_proposal_data ();		});	
$("#vehicle_store").click(function() {    		store_proposal_data ();		});	
$("#preinsurer_store").click(function() {    store_proposal_data ();	set_ppd(); 	});	
$("#review").click(function() {  set_ppd();	});	



function store_proposal_data () {   
	
	$.get("/tw/store_proposal_data", {
		tw_trans_code : $("#tw_trans_code").val(),
		owner_type : $("#Individual").val() || "I",
		gender : $("#val_radio_male").is(":checked") == true ? "M" : "F",
		cus_dob : $("#cust_dob").val() || "",
		cust_name : $("#cust_name").val() || "",
		email_id : $("#customer_email").val() || "",
		mobile_no : $("#mobile").val() || "",
		aadhar_no : $("#aadhar_no").val() || "" ,
		pan_no : $("#pan_no").val() || "" ,
		pro_occu : $("#rsgi_p_occuptn").val() || "",
		
		regn_addr1 : $("#houseno").val() || "",
		regn_addr2 : $("#street").val() || "",
		regn_addr3 : $("#locality").val() || "",
		regn_state : $("#state").val() || "",
		regn_city : $("#city").val() || "",
		regn_pincode : $("#pincode").val() || "",
		commu_addr_chkbx : $("#commu_addr_chkbx").val() || "",
		houseno : $("#comm_houseno").val() || "",
		street : $("#comm_street").val() || "",
		locality : $("#comm_locality").val() || "",
		state : $("#comm_state").val() || "",
		city : $("#comm_city").val() || "",
		pincode : $("#comm_pincode").val() || "",
		
		twregno : $("#tw_reg_no").val(),
		eng_no : $("#eng_no").val() || "",
		chassis_no : $("#chassis_no").val() || "",
		owner_changed : $("#rsgi_owner_change").val(),
		voluentry_ded : $("#rsgi_vol_deduct").val() || "0",
		yom_selected : $("#yom_selected").val() || "",
		color : $("#color").val() || "",
		is_financed : $("#rsgi_tw_finance").val() || "",
		type_of_finance : $("#rsgi_tw_finance_type").val() || "",
		financier_name : $("#rsgi_finance_name").val() || "",
		
		previnsurance : $("#previnsurance").val()  || "",
		pre_insurer_addr : $("#rsgi_preinsur_addr").val()  || "",
		pre_claim_count : $("#pre_claim_count").val()  || "0",
		pre_claim_amount : $("#pre_claim_amount").val()  || "0",
		policyno : $("#policyno").val() || "",
		pre_policy_type : $("#rsgi_pre_policy_type").val() || "",
		nomineeName : $("#nomineeName").val() || "",
		nomi_age : $("#nomi_age").val() || "",
		nomineeRel : $("#nomineeRel").val() || "",
		prevzerodep : $("input[name=prevzerodep]:checked").val()
	}, function(data, status) {		});
	
}


function retrive_proposal_data() {  
	$.get("/tw/retrive_proposal_data", { 
		tw_trans_code : $("#tw_trans_code").val()	
	},  function(data, status) {	  			
		 $("#Individual").val( data['owner_type'] ) ;
		 $("#gender_group input[type='radio']:checked").val( data['proposer_gender'] ) ;
		 $("#cust_dob").val( data['proposer_dob'] ) ;
		 $("#cust_name").val( data['proposer_name'] ) ;
		 $("#aadhar_no").val( data['proposer_aadharno'] ) ;
		 $("#pan_no").val( data['proposer_panno'] ) ;
		 $("#customer_email").val( data['proposer_email'] ) ;
		 $("#mobile").val( data['proposer_mobile'] ) ;
		 $("#rsgi_p_occuptn").val( data['proposer_occupation'] ) ;
		 $("#rsgi_p_occuptn").trigger('change');
		
		 $("#houseno").val( data['regn_addr1'] ) ;
		 $("#street").val( data['regn_addr2'] ) ;
		 $("#locality").val( data['regn_addr3'] ) ;
		 $("#state").val( data['regn_state_code'] ) ;	 $("#state").trigger('change');	
//		 load_onpage_cities( data['proposer_city_code'] );
//		 $("#city").val( data['proposer_city_ref'] ) ;
		 $("#pincode").val( data['regn_pincode'] ) ;
		 $("#commu_addr_chkbx").val( data['same_comm_addr'] ) ;
		 
		 if(data['same_comm_addr'] == "Y") {
			 $("#commu_addr_chkbx").prop('checked', true);
			 $("#commu_addr_box").hide();
		 }else{
			 $("#comm_houseno").val( data['proposer_addr1'] ) ;
			 $("#comm_street").val( data['proposer_addr2'] ) ;
			 $("#comm_locality").val( data['proposer_addr3'] ) ;
			 $("#comm_state").val( data['proposer_state_code'] ) ;   $("#comm_state").trigger('change');	
			 $("#comm_city").val( data['proposer_city_code'] ) ;
			 $("#comm_pincode").val( data['proposer_pincode'] ) ;
		 }
		
		 if(data['tw_reg_no'] == null || data['tw_reg_no'] == ""){
			 var rto_code_raw = data['rto_code'];
			 $("#tw_reg_no").val( rto_code_raw.slice(0, 2) + "-" + rto_code_raw.slice(2) +"-" ) ;
		 }else{ $("#tw_reg_no").val( data['tw_reg_no'] ) ;	}
		
		 $("#eng_no").val( data['tw_engine_no'] ) ;
		 $("#chassis_no").val( data['tw_chassis_no'] ) ;
//		 $("#rsgi_vol_deduct").val( data['voluentry_deductables'] ) ;
		 if( data['owner_changed'] != "" ) {
			 $("#rsgi_owner_change").val( data['owner_changed'] ) ; $("#rsgi_owner_change").trigger('change');
		 }
		
		 if( data['is_financed'] != "" ) {
			 $("#rsgi_tw_finance").val( data['is_financed'] ) ; $("#rsgi_tw_finance").trigger('change');
		 }

		 if( data['is_financed'] != "" ) {
			 $("#rsgi_tw_finance_type").val( data['type_of_finance'] ) ;
			 $("#rsgi_tw_finance_type").trigger('change');
		 }
		
		 $("#yom_selected").val( data['yom'] ) ;   $("#yom_selected").trigger('change');
		 $("#color").val( data['color'] ) ;
		
		 $("#previnsurance").val( data['pre_insurer_code'] ) ;
		 $("#previnsurance").trigger('change');
		 if( data['pre_policy_type'] != "" ){
		 $("#rsgi_pre_policy_type").val( data['pre_policy_type'] ) ; $("#rsgi_pre_policy_type").trigger('change');
	     }
		 $("#rsgi_preinsur_addr").val( data['pre_insurer_addr'] ) ;
		 $("#pre_claim_count").val( data['pre_claim_count'] ) ;
		 $("#pre_claim_amount").val( data['pre_claim_amount'] ) ;
		
		 $("#rsgi_finance_name").val( data['financier_name'] ) ;
		 $("#policyno").val( data['pre_policy_number'] ) ;
		 $("#nomineeName").val( data['nomi_name'] ) ;
		 $("#nomineeRel").val( data['nomi_rel_code'] ) ; $("#nomineeRel").trigger('change');
		 $("#nomi_age").val( data['nomi_age'] ) ;  $("#nomi_age").trigger('change');
		// $("#prevzerodep").val( data['prevzerodep'] ) ;
	});
}

function strt_proposal_data() {
	store_proposal_data(); 
//	retrive_proposal_data(); 
	set_ppd();
}


$("#rsgi_tw_finance").change(function() {
	if( $( "#rsgi_tw_finance" ).val() == "Y" ) { 	
		$("#rsgi_finance_name_box").removeClass("ihide");
		$("#rsgi_finance_type_box").removeClass("ihide");
	} else {  
		$("#rsgi_finance_name_box").addClass("ihide"); 
		$("#rsgi_finance_type_box").addClass("ihide"); 
	}
});




function set_ppd() {     
	
	$("#p_Individual").text( $("#Individual").attr('data-name') || "" );
	$("#p_gender_group").text(  $("#gender_group input[type='radio']:checked").attr('data-name') || "" );
	$("#p_cust_dob").text( $("#cust_dob").val() || "" );
	$("#p_cust_name").text( $("#cust_name").val() || "" );
	$("#p_customer_email").text( $("#customer_email").val() || "" );
	$("#p_mobile").text( $("#mobile").val() || "" );
	$("#p_aadhar_no").text( $("#aadhar_no").val() || "" );
	$("#p_pan_no").text( $("#pan_no").val() || "" );
	$("#p_rsgi_p_occuptn").text( $("#rsgi_p_occuptn option:selected").attr('data-name') || "" );
	
	$("#p_houseno").text( $("#houseno").val() || "" );
	$("#p_street").text( $("#street").val() || "" );
	$("#p_locality").text( $("#locality").val() || "" );
	$("#p_state").text( $('#state option:selected').attr('data-name')  || "" );
	$("#p_city").text( $('#city option:selected').attr('data-name') || "" ); 
	$("#p_pincode").text( $("#pincode").val() || "" ); 

	$("#p_reg_number").text( $("#tw_reg_no").val() ); 
	$("#p_eng_no").text( $("#eng_no").val() || "" );
	$("#p_chassis_no").text( $("#chassis_no").val() || "" );
	$("#p_rsgi_vol_deduct").text( $("#rsgi_vol_deduct").val() || "No" );
	$("#p_rsgi_owner_change").text($("#rsgi_owner_change").val() || "" );
	$("#p_rsgi_tw_finance").text($("#rsgi_tw_finance").val()  );
	$("#p_rsgi_finance_name").text($("#rsgi_finance_name").val() || "--" );
	$("#p_rsgi_finance_type").text($("#rsgi_tw_finance_type").val() || "--" );
	$("#p_yom_selected").text( $("#yom_selected").val() || "" );
	$("#p_color").text( $("#color").val() || "" );
	
	$("#p_previnsurance").text( $('#previnsurance option:selected').attr('data-name')   || "" ); 
	$("#p_policyno").text( $("#policyno").val() || "" );
	$("#p_rsgi_pre_policy_type").text( $("#rsgi_pre_policy_type").val() || "" );
	$("#p_pre_claim_count").text( $("#pre_claim_count").val() || "0" );
	$("#p_pre_claim_amount").text( $("#pre_claim_amount").val() || "0" );
	$("#p_nomineeName").text( $("#nomineeName").val() || "" );
	$("#p_nomineeRel").text(  $('#nomineeRel option:selected').attr('data-name') || "" );
	$("#p_nomi_age").text(  $("#nomi_age").val() || "" );
	$("#p_prevzerodep_selected").text(  $("input[name=prevzerodep]:checked").val()  );
}


$("#tw_rsgi_proposal_finish").click(function() {   
	if(  $("#disclaimer").is(':checked')){  
	
$.get("/tw/proposal_submit_overlay", { }, function(data, status) {	common.loader_msg(data);	});
		
		$.get("/tw/rsgi_proposal_submit", {
			tw_trans_code : $("#tw_trans_code").val()
			}, function(data, status) {	
				if( data["resp_flag"] == "verror" ){ 
				sweetAlert( data["verror_txt"] );
					common.loader_rem(); 
				} else if( data["resp_flag"] == "error_msg" ){ 
				sweetAlert( data["datav"][0] );
					common.loader_rem(); 
				} else if ( data["resp_flag"] == "error_page" ) { common.loader_rem();  
					 window.location = "/two-wheeler-insurance/rsgi/policy/status";
				} else{
					setTimeout(function(){ 
						common.loader_rem();  
						common.loader_msg(data); 
					}, 100);
				}
			});
	
	 } else { $( "#tnc_box" ).effect( "shake" );  }
	
});	





$("#overlay").on("click", "#review-again", function() {   	common.loader_rem();  	});

$("#overlay").on("click", "#payment_submit", function() { 

common.loader_msg("Redirecting to payment gateway.. Please wait ...");	 		  

	$.get("/tw/submit_rsgi_payment", { 
		tw_trans_code : $("#tw_trans_code").val()
	}, function(data, status) {	 
		common.loader_rem(); 
		redirect_to_payment( data );  
		
	});
});

function pm_submit_payment ( agreed_premium )  {
	$.get("/tw/pm_submit_rsgi_payment",  {
		tw_trans_code : $("#tw_trans_code").val(),
		agreed_premium : agreed_premium
	}, function(data, status) {	  
		common.loader_rem(); //common.loader_msg("Redirecting to payment gateway.. Please wait ..."); 
		redirect_to_payment( data );  
	});
}

function redirect_to_payment (data) {
	 var pay_form = '<form name="rsgi_payment_submit" autocomplete="off"  method="POST" action="'+ data.payurl +'">';
	 var input_ele = "";
		$.each(data, function(pfindex, pfpval) {
         input_ele+='<input type="hidden" value="'+pfpval+'" name="'+pfindex+'"/>';     
     });
	 pay_form += input_ele;
     pay_form += '<input type="Submit" value ="Submit" id="submit_rsgi_payment"/>';
     pay_form += '</form>';	 		
     $("body").append(pay_form);   
     $('#submit_rsgi_payment').click();
}

if (typeof validate_lib != 'undefined') {
	form_field = {
		mobile: "mobile",
		cust_name: "cust_name",
		cust_dob: "dob_dash_fmt",
		aadhar_no: "aadhar_no",
		customer_email: "email",
		pan_no:"pan",
		houseno: "houseno",
		street: "street",
		locality: "locality",
		pincode: "pincode",
		tw_reg_no:"tw_reg_no",
		eng_no: "tw_engno",
		chassis_no: "tw_chassisno",
		color: "color",
		policyno: "tw_policyno",
		nomineeName: "cust_name",
		pre_claim_count:"claim_count",
		pre_claim_amount: "claim_amount",
		statecode: "required",
		citycode: "required",
		nomi_age:"required",
		nomineeRel:"required",
		previnsurance:"required",
		rsgi_finance_name:"financierName",
		rsgi_preinsur_addr:"pre_addr"
	};
	form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field);
} else {
	console.error("import validator_lib.js for validation");
}

//bootstrap wizard
$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onNext: function (tab, navigation, index) {
        var $valid = $('.wizard-card form').valid();
        if (!$valid) {
            return !1
        }
        tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
        if(tab_text == "Review"){
            return true;
        }

        policy_cmp_sel = '#policy_cmp';
        // if user not veryfied
        check_v = window["'"+otp.getMobile()+"'"];
        if (!check_v || check_v == 'undefined'){   
        	  if ($('#buy_policy_form').valid()) { 
                  otp.verifyMobileNumber();
                  return false;
               }else{
                   return false;    
               }
        }
    },
    onTabShow: function (tab, navigation, index) {
        

        var $total = navigation.find('li').length;
        var $current = index + 1;
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        var $valid = $('.wizard-card form').valid();
        if (!$valid) {
          return !1
      }
        tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
        if(tab_text == "Review"){
            return true;
        }

        policy_cmp_sel = '#policy_cmp';
        // if user not veryfied
        check_v = window["'"+otp.getMobile()+"'"];
        if (!check_v || check_v == 'undefined'){
	        	if ($('#buy_policy_form').valid()) { 
	                otp.verifyMobileNumber();
	                return false;
	             }else{
	                 return false;    
	             }
        }
    },

});


// otp implemention
var otp = new (function ($) {
	self = this;
    policy_cmp_sel = '#policy_cmp',
            mobile = '',
            $token = $("input[name='_token']"),
            $otp_gen = $('#otp_gen'),
            $very_otp = $('#very_otp');
    verifycation_status = 0;
    $obj_proposer = $("#proposer");

    function genrateOtp() {

        b = {_token: this.$token.val(), mobile: mobile}
        a = $otp_gen.val();
        console.log(a);
        common.ajaxPostRequestWithLoader(a, b, function (data) {
            
            console.log("Genrate Otp Data");
            console.log(data);
            if (data) {
                if(typeof data.overLimit != undefined && data.overLimit){
                    console.log(data);
                    common.alert("you are exceed the verifiation limit");
                    return false;
                }

                if (typeof data.status != undefined) {
					//When mobile is verified					
					if(data.otp){						
							if (data.status) {
                                window["'"+otp.getMobile()+"'"] = 1;
                                $(".wizard-card").bootstrapWizard("next");
							}else{
                                verificationDisplay(mobile);
                            }
					} else if (data.status){
                        verificationDisplay(mobile);
                    }
                    else{
                        common.alert(common.verify_otp_not_gen);
                        return false;
                    }
                }
            }
        }, common.msg['gen_code']);
    }

    function verificationDisplay(mobile) {
        var status = 0;
        swal({
            title: '<b>Enter Verification Code</b>',
            text: 'Please Check Your text message at the phone number ' + mobile,
            input: 'text',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: function (text) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        if (text == '') {
                            reject(common.msg['enter_otp']);
                        } else if (text.length != 4) {
                            reject(common.msg['otp_length']);
                        } else {
                            resolve()
                        }
                    }, 2000)
                })
            },
            allowOutsideClick: false
        }).then(function (text) {
            status = verifyCode(text);
        })
    }

    function verifyCode(code) {
        b = {_token: this.$token.val(), code: code}
        a = $very_otp.val();
        var status = 0;
        common.ajaxPostRequest(a, b, function (data) {
            if (data) {
                if (typeof data.status != undefined) {
                    window[""+otp.getMobile()] = data.status;
                    if (window[""+otp.getMobile()]) {
                        common.setCookie('hdfc', 3, 1);
                        $(".wizard-card").bootstrapWizard("next");
                        common.alert(common.msg['user_verified']);
                    } else
                        common.alert(common.msg['unveryfied_user']);
                }
            }
        });

        if (window.verified == undefined) {
            window.verified = 1;
        } else {
            window.verified = window.verified + 1;
        }

        common.setCookie('hdfc', window.verified, 1);
    }
	
	

    return {
        self: this,
        verifycation_status: verifycation_status,
        verified: window.verified,
        getMobile: function(){
            return $('#mobile').val();
        },
        verifyMobileNumber: function () {
            console.log('verifyMobileNumber');
            mobile = this.getMobile();
			return genrateOtp();
        }
    }


})(jQuery);

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}
