$(document).on("click","#make", function (event) {	
	var mkid =  event.target.id;
	$("#hdn_make").val(mkid); 	
	$.get("/tw/model_list",
		    {	makeid:mkid   },
		    function(data, status){
				jQuery('#make').find('.btn-blue').removeClass('btn-blue').addClass('btn-white');
		    	$("#"+mkid).removeClass("btn-white").addClass("btn-blue");
		    	$("#modelccnt").html(data);
				$("#hdn_model").val('');//reset model
	});
});



$("#model").click(function(event) {     
	var model_id = event.target.id;
	$("#hdn_model").val(model_id);	
	$.get("/tw/variant_list", {
		model_id : model_id
	}, function(data, status) {
		jQuery('#model').find('.btn-blue').removeClass('btn-blue').addClass('btn-white');
		$("#"+model_id).removeClass("btn-white").addClass("btn-blue");
		$("#vari_tab").click(); $("#variantccnt").html(data);
		$("#hdn_variant").val('');//reset variant
	});
});	

$("#variant").click(function(event) {
	var variant_id = event.target.id;	
	$("#hdn_variant").val(variant_id);	
	$.get("/tw/variant_store", {
		variant_id : variant_id
	}, function(data, status) {
		jQuery('#variant').find('.btn-blue').removeClass('btn-blue').addClass('btn-white');
		$("#rtos_tab").click(); 
		$("#"+variant_id).removeClass("btn-white").addClass("btn-blue");
	});
});

$( "#rtostate" ).click(function(event) {
	var state_id = event.target.id;
	 $("#hdn_state").val(state_id) ;
	
	$.get("/tw/state_store", {
		state_id : state_id
	}, function(data, status) {   
		jQuery('#rtostate').find('.btn-blue').removeClass('btn-blue').addClass('btn-white');
		$("#"+state_id).removeClass("btn-white").addClass("btn-blue");
		$("#rto_code_txt").html(data.rto_code);
	});
});

$(document).on('click','#rtocodes .rtotable .btn-white',function(e){
	
	var rto_no = $("#rto_code_val").text();  
	var vadil = rto_no.match(/.{1,2}/g);
	if(vadil.length > 1){
		$("#rto_code_val").text(vadil[0]);  
		alert('You can not select more that two code');
	}else{
		
	}
});
$( "#rto_code_pad" ).click(function(event) {
	var state_code = $("#rto_code_txt").text();
	var rto_no = $("#rto_code_val").text();  
	
	if(rto_no == "" || rto_no == "0" || rto_no =="00" || rto_no == " ") {
		$("#hdn_rtocode").val("");
	} else{
		var rto_code = state_code.concat( ('0' + rto_no).slice(-2) );
		$("#hdn_rtocode").val(rto_code) ;
		$.get("/tw/rto_store", {
			rto_code : rto_code  
		}, function(data, status) {  
			$("#rto_code_val").text(rto_code.substring(2)) ;
		});
	}
	
});

$( "#yor" ).click(function(event) {
	var tw_yor = event.target.id;
	
	 $("#hdn_yor").val(tw_yor) ;
	 // validate tw details 
	 var valtxt = "";
	 var valstatus = true;
	 if ( $("#hdn_make").val() =="") { valtxt= valtxt + "Please select make. \n" ;  valstatus = false;}
	 if ( $("#hdn_model").val() =="") { valtxt= valtxt + "Please select model. \n" ;  valstatus = false;}
	 if ( $("#hdn_variant").val() =="") { valtxt= valtxt + "Please select variant. \n" ;  valstatus = false;}
	 if ( $("#hdn_state").val() =="") { valtxt= valtxt + "Please select state. \n" ;  valstatus = false;}
	 if ( $("#hdn_rtocode").val() =="") { valtxt= valtxt + "Please select rtocode. \n" ;  valstatus = false;
	 }else if ($("#hdn_rtocode").val().length < 4 ){
		 valtxt= valtxt + "Please select rtocode. \n" ;  valstatus = false;  	}
	 if ( $("#hdn_yor").val() =="") { valtxt= valtxt + "Please select yor. \n" ;  valstatus = false;}

	 
	if (valstatus) {
		$.get("/tw/yor_store", {
			tw_yor : tw_yor
		}, function(data, status) {  
			window.location.href = "/two-wheeler-insurance/quote/"+data;
		});
	}else {
		sweetAlert(valtxt);
	}
	
});

