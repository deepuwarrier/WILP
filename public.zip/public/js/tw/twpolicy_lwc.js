$("#goto_proposer").click(function() {  	$("#proposer_tab").click();		});
$("#goto_commu").click(function() {  	$("#commu_tab").click();		});
$("#goto_vehicle").click(function() {  	$("#vehicle_tab").click();		});
$("#goto_preinsr").click(function() {  	$("#preinsr_tab").click();		});



$("#state").change(function() {
//	common.loader_msg("Getting Cities. Please Wait....");
	$.get("/tw/city_by_state", {  state_code : $( "#state" ).val() 	}, function(data, status) {   
		$("#city").html(data);
		common.loader_rem(); 
});
});

$("#comm_state").change(function() {
//	common.loader_msg("Getting Cities. Please Wait....");
	$.get("/tw/city_by_state", {  state_code : $( "#comm_state" ).val() 	}, function(data, status) {   
		$("#comm_city").html(data);
		common.loader_rem(); 
});
});


function load_onpage_cities(city_id_ref) { 
	$.get("/tw/city_by_state", {  state_code : $( "#state" ).val() 	}, function(data, status) {   
		$("#city").html(data);
		$("#city").val( city_id_ref ) ;
});
}

$("#commu_addr_chkbx").change(function() {
	if(  $("#commu_addr_chkbx").is(':checked')){  
			$("#commu_addr_chkbx").attr('value', 'Y');
			$("#commu_addr_box").attr('style', 'display:none');
			oper_commu_addr("Y");
		} else { 
			$("#commu_addr_box").attr('style', '');
			$("#commu_addr_chkbx").attr('value', 'N');
			oper_commu_addr("N");
		}
});

function oper_commu_addr( addr_flag ){
	if( addr_flag == "Y" ){   
	// doing nothing as of now. 
	}else {
		$("#comm_houseno").val( "" ) ;
		$("#comm_street").val( "" ) ;
		$("#comm_locality").val( "" ) ;
		$("#comm_state").val( "" ) ;		
		$("#comm_city").val( "" ) ;
		$("#comm_pincode").val( "" ) ;
	} // end of method.

	
}





