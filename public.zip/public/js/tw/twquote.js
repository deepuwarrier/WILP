$("#policy_expiry_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: !0,
	minDate: $("#policy_expiry_date").attr("data-minDate"),
	maxDate: $("#policy_expiry_date").attr("data-maxDate")
	});
$("#car_registration_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: 0,
	minDate: $("#car_registration_date").attr("data-minYear"),
	maxDate: $("#car_registration_date").attr("data-maxYear")
	});

$( document ).ajaxStop(function() {
  $('#update_btn_idvsec').removeAttr('disabled');
});

$('#accordion2 input').click(function(){   
		update_tw_quotes();
		store_addon_covers();
}) 


$("#policy_expiry_date").change(function(){    
	idv_view_values();
}) 

 function idv_view_values() {
	
	 $.get("/tw/idv_view_values", {
		 tw_trans_code : $("#tw_trans_code").val(),
			 policy_expiry_date :  $("#policy_expiry_date").val(),
			 tw_registration_date : $("#car_registration_date").val(), 
			 claim_status : $('#reg_summary input[type=radio]:checked').val(),
			 current_ncb : $("#current_ncb").val(),
			 eli_ncb : $("#eli_ncb_span").html().split('%')[0],
			 plan_duration:1,
			 expected_idv:$("#expected_idv").val(),
			 pre_policy_status:$("#pre_policy_status").val()
		}, function(data, status) {   	 
			$("#pre_policy_status").val(data["_pre_policy_status"]);  
			$("#policy_expiry_date").val( data["r_pexdt"] );
			$("#policy_expiry_date").datepicker('change', 'minDate', data["r_pexdt_min"]);
			$("#policy_expiry_date").datepicker('change', 'maxDate', data["r_pexdt_max"]);
		    $("#car_registration_date").val(data["r_twrgdt"]);
		    $('#car_registration_date').datepicker('change', 'minDate', data["r_twrgdt_min"]);
		    $('#car_registration_date').datepicker('change', 'maxDate', data["r_twrgdt_max"]);
		   if(data["r_claims"]){
			   $("#radio_3").prop('checked', true);   
		   }else{
			   $("#radio_4").prop('checked', true);
		   }
		   $("#current_ncb").val(data["r_crr_ncb"]);
		   $('#eli_ncb_span').html(data["r_eli_ncb"] + "%");
		   $("#expected_idv").val(data["calc_idv"]);
		   $("#expected_idv").attr("data-minLimit", data["_base_idv_min"]);
		   $("#policy_expiry_date").attr("data-maxLimit", data["_base_idv_max"]);
		  
		   if(data["_isvisible_pexdt"]){ 
			   $("#policy_expiry_date").attr('disabled',false);   $("#policy_expiry_date").css("opacity", 1);
		   }else{
			   $("#policy_expiry_date").attr('disabled',true);    $("#policy_expiry_date").css("opacity", 0.2);     
		   }
		   if(data["_isvisible_claims"]){
			   $("#radio_3, #radio_4").attr('disabled',false);  $("#radio_3, #radio_4").css("opacity", 1);    
		   }else{
			   $("#radio_3, #radio_4").attr('disabled',true);  $("#radio_3, #radio_4").css("opacity", 0.2);    
		   }
		   if(data["_isvisible_ncb"]){
			   $("#current_ncb, #eli_ncb_span").attr('disabled',false);  $("#current_ncb, #eli_ncb_span").css("opacity", 1);    
		   }else{
			   $("#current_ncb, #eli_ncb_span").attr('disabled',true);  $("#current_ncb, #eli_ncb_span").css("opacity", 0.2);    
		   }
		}); 
	 
 } // end of function.


$("#pre_policy_status").change(function() {     idv_view_values();		});
$("#current_ncb").change(function() {  	idv_view_values();		});
$("#radio_3").click(function() {  				idv_view_values();		});
$("#radio_4").click(function() {    				idv_view_values();		});

$("#idv").on("click","#update_btn_idvsec",function() {    
	$('#update_btn_idvsec').attr('disabled','disabled');
	if(validate_idv_section()) {  return false;}
	
	quote.unfocusIdv();
	common.loader_msg(common.msg.updated_quote);
	update_tw_quotes();
	$('#btn_div_skip').remove();
});


function validate_idv_section (){
	var policy_expiry_date = $("#policy_expiry_date").val();
	var tw_reg_date = $("#car_registration_date").val();
	var min_base_idv = $("#expected_idv").attr("data-minLimit");
	var max_base_idv = $("#expected_idv").attr("data-maxLimit");
	var exptd_idv = $("#expected_idv").val();
	
	var is_error = false;
	var error_msg = "";
	
	if(! policy_expiry_date.match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { 	is_error = true;	  error_msg = error_msg +"Policy Expire Date Format is Wrong <br>";  }
	if(! tw_reg_date.match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { 	is_error = true;	  error_msg = error_msg + "Registration Date Formate is Wrong <br>";  }
	if(  (exptd_idv.match('^[0-9]{2,7}$') == null) || (parseInt(exptd_idv, 10) < parseInt(min_base_idv, 10)) || (parseInt(exptd_idv, 10) > parseInt(max_base_idv, 10))  ) {
		is_error=  true;	
		error_msg = error_msg + "IDV is Invalid / Out of range. Please try between "+ min_base_idv + " to " + max_base_idv;
		 $('#update_btn_idvsec').removeAttr('disabled');
	}
	
	if(is_error){sweetAlert(error_msg);}
	return is_error;
} 

// Basically first time when page referesh/reloads/loads
 function load_tw_quotes(){
	var tw_trans_code =  $("#tw_trans_code").val();
	var policy_expiry_date = $("#policy_expiry_date").val();
	var tw_registration_date = $("#car_registration_date").val();
	var claim_status = $('#reg_summary input[type=radio]:checked').val();
	var current_ncb = $("#current_ncb").val();
	var eli_ncb = $("#eli_ncb_span").html().split('%')[0];
//	var plan_duration = $('#plan_duration input[type=radio]:checked').val();  
	var plan_duration = 1;  
	var addon_selected = quote_addons_selected();
	var pre_policy_status = $("#pre_policy_status").val();
	
	common.loader_msg("Getting Quotes Please Wait....");

	$("#quote_ctnr_box").html(""); 
	
//	uiic_quotes (tw_trans_code, pre_policy_status,policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
	hdfc_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
	rsgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
//	mhdi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
//	bajaj_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
	reliance_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
//	itgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
//	fggi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected);
	
	common.loader_rem();
	 setTimeout(function(){
	 	if(!$("#btn_div_skip").length){
	  		common.loader_rem();
	 	}
	  }, 15000);
}

 function update_tw_quotes() {
 	 common.initQuote();
	 var tw_trans_code =  $("#tw_trans_code").val();
		var policy_expiry_date = $("#policy_expiry_date").val();
		var tw_registration_date = $("#car_registration_date").val();
		var claim_status = $('#reg_summary input[type=radio]:checked').val();
		var current_ncb = $("#current_ncb").val();
		var expected_idv = $("#expected_idv").val();
		var eli_ncb = $("#eli_ncb_span").html().split('%')[0];
//		var plan_duration = $('#plan_duration input[type=radio]:checked').val();   
		var plan_duration = 1;   
		// getting addons
		var addon_selected = quote_addons_selected();
		var pre_policy_status = $("#pre_policy_status").val();
		
		common.loader_msg("Updating Quotes Please Wait....");
		
		update_idvsec_values (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, expected_idv);
		$("#quote_ctnr_box").html(""); 
		setTimeout(function(){ 
//		uiic_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
			hdfc_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
			rsgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
//			mhdi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
//			bajaj_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
		reliance_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
//			itgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
//			fggi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv);
			}, 500);
		setTimeout(function(){ common.loader_rem(); }, 15000);
 }
 
 function update_idvsec_values (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, expected_idv) { 

	 $.get("/tw/update_idvsec_values", {
		 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 expected_idv:expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {   	 
//			$("#quantity").val(data.revised_idv);   
			//$("#current_ncb").val( data.revised_curr_ncb ).change();
		});
	 }
 
 function mhdi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='mhdi_loader'></span>");common.loader("#mhdi_loader")
		 $.get("/tw/load_mhdi_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {     
				common.loader_rem();
				 $("#mhdi_loader").remove();
				 $("#quote_IITW005").remove();
				 if (data != 0 ) {
						$("#quote_ctnr_box").append(data);
					} quote_box_finalize();
		});
	 }
 
 
 function rsgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='rsgi_loader'></span>");common.loader("#rsgi_loader")
		 $.get("/tw/load_rsgi_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {     
			common.loader_rem();
			$("#rsgi_loader").remove();
			$("#quote_IITW004").remove();
			if (data != 0 ) {
				$("#quote_ctnr_box").append(data);
			} else
				common.addNoQuotes('rsgi_logo.png','Royal Sundaram GI');
			 quote_box_finalize();
		});
	 }
 
 
 function hdfc_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='hdfc_loader'></span>");common.loader("#hdfc_loader")
	
		 $.get("/tw/load_hdfc_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected, 
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {     
			common.loader_rem();
			$("#hdfc_loader").remove();
			$("#quote_IITW003").remove();
			if (data != 0 ) {
				$("#quote_ctnr_box").append(data);
			}else
				common.addNoQuotes('hdfc_logo.png','HDFC ERGO GI');
			quote_box_finalize();
		});
	 }
 
 
 function uiic_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv ) {

	 $.get("/tw/load_uiic_quotes",  {
		 tw_trans_code : tw_trans_code,
		 policy_expiry_date : policy_expiry_date,
		 tw_registration_date : tw_registration_date, 
		 claim_status : claim_status,
		 current_ncb : current_ncb,
		 eli_ncb : eli_ncb,
		 plan_duration: plan_duration,
		 addon_selected: addon_selected, 
		 expected_idv: expected_idv,
		 pre_policy_status: pre_policy_status
	}, function(data, status) {   
		common.loader_rem();
		 $("#quote_IITW002").remove();
		if (data != 0 ) {
			$("#quote_ctnr_box").append(data);
		}else
			common.addNoQuotes('uiicgi_logo.png','United India Insurance GI');

		 quote_box_finalize();
	});  
 }
 
 function reliance_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='reliance_loader'></span>");common.loader("#reliance_loader");
	 
		 $.get("/tw/load_reliance_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {      
				common.loader_rem();
				$("#reliance_loader").remove();
				if (data != 0 ) {
					$("#quote_ctnr_box").append(data);
				}else
					common.addNoQuotes('reliance_logo.png','Reliance GI');
				 quote_box_finalize();
		});
	 }
 
 
 function bajaj_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='bajaj_loader'></span>");common.loader("#bajaj_loader");
	 
//	 setTimeout(function(){  $("#bajaj_loader").remove();  }, 10000);
	 
		 $.get("/tw/load_bajaj_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {      
				common.loader_rem();
				 $("#bajaj_loader").remove();
				 $("#quote_IITW001").remove(); 
				 if (data != 0 ) {
						$("#quote_ctnr_box").append(data);
					} quote_box_finalize();
		});
	 }
 
 function itgi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='itgi_loader'></span>");common.loader("#itgi_loader")
		 $.get("/tw/load_itgi_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {      
				common.loader_rem();
				 $("#itgi_loader").remove();
				 $("#quote_IITW006").remove(); 
				 if (data != 0 ) {
						$("#quote_ctnr_box").append(data);
					} quote_box_finalize();
		});
	 }
 
 function fggi_quotes (tw_trans_code, pre_policy_status, policy_expiry_date, tw_registration_date, claim_status, current_ncb, eli_ncb, plan_duration, addon_selected, expected_idv) {
	 $("#quote_ctnr_box").append("<span id='fggi_loader'></span>");common.loader("#fggi_loader")
		 $.get("/tw/load_fggi_quotes", {
			 tw_trans_code : tw_trans_code,
			 policy_expiry_date : policy_expiry_date,
			 tw_registration_date : tw_registration_date, 
			 claim_status : claim_status,
			 current_ncb : current_ncb,
			 eli_ncb : eli_ncb,
			 plan_duration:plan_duration,
			 addon_selected: addon_selected,
			 expected_idv: expected_idv,
			 pre_policy_status:pre_policy_status
		}, function(data, status) {      
				common.loader_rem();
				 $("#fggi_loader").remove();
				 $("#quote_IITW007").remove(); 
				 if (data != 0 ) {
						$("#quote_ctnr_box").append(data);
					} quote_box_finalize();
		});
	 }

 function quote_addons_selected(){
		var addons_selected = [];
		$('#accordion2 input:checked').each(function() {
			addons_selected.push($(this).attr('value'));
		});
		return addons_selected;
 }
 
function store_addon_covers() {   
	 $.get("/tw/store_addon_covers", {
		 tw_trans_code :  $("#tw_trans_code").val(),
		 addon_selected : quote_addons_selected()
	}, function(data, status) {	});
} 

function quote_box_finalize() {
	return 1;
}


$(document).ready(function(){
	var value_diff_idv = 1;
	$(".qtyplus").click(function(t) {
	    t.preventDefault(), fieldName = $(this).attr("field");
	    var e = parseInt($("input[name=" + fieldName + "]").val()),
	        a = e * value_diff_idv / 100;
	    isNaN(e) ? $("input[name=" + fieldName + "]").val(0) : $("input[name=" + fieldName + "]").val(Math.round(e + a))
	});
	$(".qtyminus").click(function(t) {
    	t.preventDefault(), fieldName = $(this).attr("field");
    	var e = parseInt($("input[name=" + fieldName + "]").val()),
        a = e * value_diff_idv / 100;
        !isNaN(e) && e > 0 ? $("input[name=" + fieldName + "]").val(Math.round(e - a)) : $("input[name=" + fieldName + "]").val(0)
	});

	quote = {
		self:  this,
		back_to_quotes: '#back_to_quotes',
		$obj_idv : $("#idv"),
		selector_buy_policy : "#buy_policy",
		selector_skip_btn : "#btn_div_skip",
		$obj_form_idv : $("#update_quote"), 
		selector_update_btn_idvsec : "#update_btn_idvsec",
		sel_btn_idvaccurate : "#btn-idv-accurate",
		idv_skip_btn : '<button type="reset" value="Reset" class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn_div_skip" style="margin-right:10px;margin-bottom: 20px;float: right;">Ignore Changes</button>&nbsp;',
		update_btn : '<button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_btn_idvsec">Update Quotes<div class="ripple-container"></div></button>',
		// accurate_btn : '<a class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn-idv-accurate" style="margin-right:10px;margin-bottom: 20px;float: right;">Info is accurate</a>',
		accurate_btn : '<a class="pull-left clickable btn-sm boldtext hvr-grow" id="back_to_quotes" style="cursor:pointer;margin:10px 0px 0px 0px;">Back to Quotes</a><a class="btn btn-fill btn-success clickable btn-sm boldtext hvr-grow" id="btn-idv-accurate" style="margin-right:10px;margin-bottom: 20px;float: right;">Info is accurate</a>',
		selector_insurances : ".insurance-list", 
		// functions 
		init: function(){
			console.info("Quote Intilization");
			self = this;
			self.registerObj();
			self.registerEvent();
		},
		registerEvent: function(){
			console.info("Register Event");
			self.$obj_idv.on("dp.change change paste keyup", "#pre_policy_status,#policy_expiry_date,#quantity,#reset_idv,#car_registration_date,#reg_summary,#claim_status,#current_ncb,#qty",self.onChangeFormValue), 
			self.$obj_idv.on("click", ".qtyplus,.qtyminus", self.onChangeFormValue);
			self.$obj_idv.on("click",self.selector_skip_btn,self.onClickSkipBtn);
			self.$obj_insurances.on("click",self.selector_buy_policy,self.onClickBuyBtn);
			self.$obj_idv.on("click",self.sel_btn_idvaccurate,self.onClickAccurateInfo);
			self.$obj_idv.on("click",self.back_to_quotes,self.onClickBackToQuote);
		},
		registerObj: function(){
			console.info("Register Object");
			self.$ob_buy_policy = $(self.selector_buy_policy);
			self.obj_update_btn_idvsec = $(self.selector_update_btn_idvsec);
			self.$obj_btn_idvaccurate = $(self.sel_btn_idvaccurate);
			self.$obj_idv_footer = $(".update_footer",self.$obj_idv);
			self.overlay = $("#overlay");
			self.$obj_insurances = $(self.selector_insurances)
		},
		// On Idv Value Change
		onChangeFormValue: function(){
			(!$(self.selector_update_btn_idvsec).length && self.$obj_idv_footer.append(self.update_btn)),      
		    ($(self.sel_btn_idvaccurate).length && $(self.sel_btn_idvaccurate).remove()),
		    ($(self.back_to_quotes).length && $(self.back_to_quotes).remove());
		    $(self.selector_skip_btn).length < 1 && (self.focusIdv(),self.$obj_idv_footer.append(self.idv_skip_btn))
		},
		unfocusIdv: function () {
	    	self.overlay.fadeOut(), self.$obj_idv.css("z-index", "1029")
		},
		focusIdv: function () {
	    	self.overlay.fadeIn(), self.$obj_idv.css("z-index", "1032")
		},
		// On Click Event Fire
		onClickSkipBtn: function(){
			self.$obj_form_idv[0].reset(),self.setOldIdvValues(), $(this).remove(), self.unfocusIdv()
		},
		onClickBuyBtn: function(){
			self.$btn_obj = $(this), self.confirmIDV();
		},
		onClickAccurateInfo: function(){
			self.unfocusIdv(), 
			common.loader_msg(common.msg.redirect_to_proposal), 
		    //updateQuoteURL('onChangeProposalSection','true'),
		    //new_url_on_change = window.location.href,
		    //$btn_obj.closest("form").append('<input type="hidden" name="return_quote_url" value="'+new_url_on_change+'" />');
		    self.$btn_obj.closest("form").submit()
		},
		setOldIdvValues: function(){
			// set old value
		    url = '/tw/get_idv_section';
		    data = {};
		    data.tw_trans_code = $('#tw_trans_code').val();
		    data._token = $("input[name=_token]").val();
		    common.ajaxGetRequest(url,data,function(a){
		    	self.updateUI(a);
		    });
		},
		updateUI:function(data){
			$("#pre_policy_status").val(data["_pre_policy_status"]);  
			$("#policy_expiry_date").datepicker('change', 'minDate', data["r_pexdt_min"]);
			$("#policy_expiry_date").datepicker('change', 'maxDate', data["r_pexdt_max"]);
			$("#policy_expiry_date").val( data["r_pexdt"] );
		    $("#car_registration_date").val(data["r_twrgdt"]);
		    $('#car_registration_date').datepicker('change', 'minDate', data["r_twrgdt_min"]);
		    $('#car_registration_date').datepicker('change', 'maxDate', data["r_twrgdt_max"]);
			   if(data["r_claims"]){
				   $("#radio_3").prop('checked', true);   
			   }else{
				   $("#radio_4").prop('checked', true);
			   }
			   $("#current_ncb").val(data["r_crr_ncb"]);
			   $('#eli_ncb_span').html(data["r_eli_ncb"] + "%");
			   $("#expected_idv").val(data["calc_idv"]);
			   $("#expected_idv").attr("data-minLimit", data["_base_idv_min"]);
			   $("#policy_expiry_date").attr("data-maxLimit", data["_base_idv_max"]);
			  
			   if(data["_isvisible_pexdt"]){ 
				   $("#policy_expiry_date").attr('disabled',false);   $("#policy_expiry_date").css("opacity", 1);
			   }else{
				   $("#policy_expiry_date").attr('disabled',true);    $("#policy_expiry_date").css("opacity", 0.2);     
			   }
			   if(data["_isvisible_claims"]){
				   $("#radio_3, #radio_4").attr('disabled',false);  $("#radio_3, #radio_4").css("opacity", 1);    
			   }else{
				   $("#radio_3, #radio_4").attr('disabled',true);  $("#radio_3, #radio_4").css("opacity", 0.2);    
			   }
			   if(data["_isvisible_ncb"]){
				   $("#current_ncb, #eli_ncb_span").attr('disabled',false);  $("#current_ncb, #eli_ncb_span").css("opacity", 1);    
			   }else{
				   $("#current_ncb, #eli_ncb_span").attr('disabled',true);  $("#current_ncb, #eli_ncb_span").css("opacity", 0.2);    
			   }
		},
		changeUI : function(k){
			if (k == 'E90') {
	            var new_min_date = new Date();
	            var new_max_date = new Date();
	            var daysdiff = 90;
	            new_min_date.setTime(new_min_date.getTime() - daysdiff * 24 * 60 * 60 * 1000);
	            new_max_date.setTime(new_min_date.getTime() + (daysdiff-1) * 24 * 60 * 60 * 1000);
	            //var new_min_date  = today.getFullYear() + "/"+(today.getMonth()+1)+"/"+today.getDate();
	            $("#policy_expiry_date").removeClass("unclickable");
	            $('#policy_expiry_date').datepicker('change', 'minDate', new_min_date);
	            $('#policy_expiry_date').datepicker('change', 'maxDate', new_max_date);
	        } else if(k == 'E90P') {
	            $("#policy_expiry_date").addClass("unclickable");
	            $(":radio[name='claim_status']").attr('disabled', true);
	            $("#current_ncb").val("0");
	            $("#eli_ncb_span").html("0%");
	            $("#eli_ncb_span").val("0");
	            $("#current_ncb").attr("disabled", "disabled");
	        } else {
	            $(":radio[name='claim_status']").removeAttr('disabled');
	            $(":radio[name='claim_status']").removeClass('disabled');
	            $("#policy_expiry_date").removeClass("unclickable");
	            $("#current_ncb").removeAttr('disabled');
	        }
	        
	        if(k == 'Y'){
	                $("#expiry_day").addClass("hidden");
	                $("#policy_expiry_date").removeClass("unclickable");
	        }else{
	                $("#expiry_day").removeClass("hidden");
	        }
		},
		onClickBackToQuote: function() {
    		self.onClickSkipBtn.call(this);
    		$(".update_footer").html(self.update_btn);

		},
		confirmIDV: function(){
	    	self.focusIdv(),
	     	self.idv_footer = self.$obj_idv_footer.html(), 
	    	self.$obj_idv_footer.empty(), 
	    	self.$obj_idv_footer.append(self.accurate_btn)
		}
	}

quote.init();
})
