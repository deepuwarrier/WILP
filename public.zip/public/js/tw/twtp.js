$("#customer_dob").datepicker({
dateFormat: "dd-M-yy",
changeMonth: !0,
changeYear: !0,
minDate: "01-Jan-1950",
maxDate: "31-Dec-1999",
yearRange: "-90:+1"
});

$("#reg_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: !0,
	minDate: "01-Jan-1990",
	maxDate: "30-Sep-2017",
	yearRange: "-90:+1"
});

$("#pre_pex_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: !0,
	minDate: $("#pre_pex_date").attr("data-pexMin"),
	maxDate: $("#pre_pex_date").attr("data-pexMax"),
	yearRange: "-90:+1"
});


$("#pre_pex_date").change(function(){
	common.loader_msg("Calculating Policy Expiry Date.. Please wait ...");
	 $.get("/twtp/get_policy_dates", {
		 pre_pex_date : $("#pre_pex_date").val()
		}, function(data, status) {	 
			$("#policy_start_date").val( data["term_start_date"] );
			$("#policy_end_date").val( data["term_exp_date"] );
			common.loader_rem();
		});
});


$("#cc_value_group input[type='radio']").click(function(){
	$("#tp_policy_form").submit();	
});

$("#addon_pa_pass,#addon_pa_od,#statecode,#customer_type").change(function(){
	$("#tp_policy_form").submit();	
});


function is_validate_tp_form(){
	var ret_val = false;
	if($('#customer_type').val() == "I"){
		// validatons for individual customer
		if(!$('#customer_name').val().match('^[a-zA-Z]{3,18}[ ][a-zA-Z]{3,18}$')) { $($("#customer_name").closest('div')).addClass('has-error');	ret_val = true;	}
		if(!$('#customer_dob').val().match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { $($("#customer_dob").closest('div')).addClass('has-error');	ret_val = true;	}
		if(!$('#customer_aadharno').val().match('^[0-9]{12}$')) { $($("#customer_aadharno").closest('div')).addClass('has-error');	ret_val = true;	}
	}else {
		if(!$('#organisation_name').val().match('^[a-zA-Z ]{8,30}$')) { $($("#organisation_name").closest('div')).addClass('has-error');	ret_val = true;	}
		if(!$('#organisation_gstnno').val().match('^[a-zA-Z0-9]{14}$')) { $($("#organisation_gstnno").closest('div')).addClass('has-error');	ret_val = true;	}
	}
	
	if(!$('#customer_mobile').val().match('^[0-9]{10}$')) { $($("#customer_mobile").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#customer_email').val().match('[a-zA-Z0-9\@\.]')) { $($("#customer_email").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#customer_address').val().match('^[a-zA-Z0-9 ]{15,50}$')) { $($("#customer_address").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#customer_pincode').val().match('^[0-9]{6}$')) { $($("#customer_pincode").closest('div')).addClass('has-error');	ret_val = true;	}
	
	if(!$('#tw_regno').val().match('^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$')) { $($("#tw_regno").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#reg_date').val().match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { $($("#reg_date").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#engine_no').val().match('^[a-zA-Z0-9]{8,40}$')) { $($("#engine_no").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#chassis_no').val().match('^[a-zA-Z0-9]{8,40}$')) { $($("#chassis_no").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#pre_policyno').val().match('^[a-zA-Z0-9/]{8,20}$')) { $($("#pre_policyno").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#tw_color').val().match('^[a-zA-Z0-9 ]{3,18}$')) { $($("#tw_color").closest('div')).addClass('has-error');	ret_val = true;	}
	if(!$('#pre_pex_date').val().match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { $($("#pre_pex_date").closest('div')).addClass('has-error');	ret_val = true;	}
//	if(!$('#policy_end_date').val().match('^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$')) { $($("#policy_end_date").closest('div')).addClass('has-error');	ret_val = true;	}
	if($('#vechicle_code').val() == '-1'){ $($("#vechicle_code").closest('div')).addClass('has-error');	ret_val = true;	}
	if($('#statecode').val() == '-1'){ $($("#statecode").closest('div')).addClass('has-error');	ret_val = true;	}
	if($('#citycode').val() == '-1'){ $($("#citycode").closest('div')).addClass('has-error');	ret_val = true;	}
	if($('#pre_insurer').val() == '-1'){ $($("#pre_insurer").closest('div')).addClass('has-error');	ret_val = true;	}
	return ret_val;
}


$("#submit_buynow").click(function(){   
	if( is_validate_tp_form() ) {		return false;  }
	
	common.loader_msg("Redirecting to payment gateway.. Please wait ...");
	
   $.get("/twtp/submitproposal", {
	    final_premium : $("#final_premium").html(),
	    basic_tp_premium : $("#basic_tp_premium").val(),
	    addon_premium : $("#addon_premium").val(),
	    total_gst : $("#total_gst").val(),
	    cc_value : $("#cc_value_group input[type='radio']:checked").val(),
		addon_pa_od : $("#addon_pa_od").val() ,
		addon_pa_pass : $("#addon_pa_pass").val() ,
		customer_type : $("#customer_type").val() ,
		customer_gender : $("#customer_gender").val() ,
		customer_name : $("#customer_name").val() || "",
		organisation_name : $("#organisation_name").val() || "",
		customer_dob : $("#customer_dob").val() || "",
		customer_mobile : $("#customer_mobile").val() || "",
		customer_email : $("#customer_email").val() || "",
		customer_address : $("#customer_address").val() || "",
		statecode : $("#statecode").val() || "",
		citycode : $("#citycode").val() || "",
		customer_pincode : $("#customer_pincode").val() || "",
		customer_aadharno : $("#customer_aadharno").val() || "",
		organisation_gstnno : $("#organisation_gstnno").val() || "",
		vechicle_code : $("#vechicle_code").val() || "",
		tw_regno : $("#tw_regno").val() || "",
		reg_date : $("#reg_date").val() || "",
		engine_no : $("#engine_no").val() || "",
		chassis_no : $("#chassis_no").val() || "",
		tw_color : $("#tw_color").val() || "",
		pre_insurer : $("#pre_insurer").val() || "",
		pre_policyno : $("#pre_policyno").val() || "",
		pre_pex_date : $("#pre_pex_date").val() || "",
		policy_start_date : $("#policy_start_date").val() || "",
		policy_end_date : $("#policy_end_date").val() || ""
	}, function(data, status) { 	 
		redirect_to_payment( data );  
	});
});



function redirect_to_payment (data) {
	var pay_form = '<form id="payment" name="uiic_payment" method="POST" action="'+ data.payurl +'">';
    pay_form += "<input  class='hidden' type='hidden' name='msg' value ='"+data.msg+"'/>";
    pay_form += "<input  class='hidden' type='Submit' value ='Submit' id='submit_uiic_payment'/>";
    pay_form += "</form>";	 		
    $("body").append(pay_form);  
    $('#submit_uiic_payment').click();
	
}

$('#tw_regno').keyup(function()
		{
		if(this.value.length <9){
		    this.value = this.value.replace(/([a-zA-Z0-9]{2})$/g,'$1-');
		   }
});



