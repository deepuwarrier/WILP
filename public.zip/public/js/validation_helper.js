validater = function($){
	format = {
		string : {  pattern: "^[a-zA-Z]+$",
			flags: "i",
			message: "can only contain a-z and A-Z"
		},
		number : {
			pattern: "^\\d+$"
		},
		alphanumerical: {
			pattern: "^([\\d]*[a-zA-Z]*)+$"  
		},
		alphanumericalwithslash: {
			pattern: "^([\\d]*[a-zA-Z/\]*)+$"  
		},
		alpha_slash_dash: {
			pattern: "^([\\da-zA-Z/\][-]*)+$" , 
			message: "Only alphanumeric,slash(/) and dash(-) will be allowed"
		},
		alpha: {
			pattern: "^([\\dA-Za-z\\s])+$",
			message: "Special characters like /,-. Are not allowed, Please Enter alphanumeric value provide space in case of special characters. "
		},
		dateformat: {
			pattern: "^[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}$"
		},
		name: {
			pattern: "^([a-zA-Z]*[ ]*)+$"
		},
		fullname: {
			pattern: "^(([a-zA-Z]{0,14}).(\\s[a-zA-Z]{3,14}){1,2})|([a-zA-Z]{2,14}).(\\s[a-zA-Z]{0,14}){1,2}$",//"^([a-zA-Z]{0,14}).(\\s[a-zA-Z]{2,14}){1,2}$", //"^[a-zA-Z'.\\s]{1,50}",
			message: "Please Enter Valid Firstname and Lastname"
		},
		dateformatydd_mmm_yy: {
			pattern: "^[0-9]{1,2}-[a-zA-Z-z]*-[0-9]{4}$"
		}
		,
		regno: {
			pattern: "^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$"
		},
		pincode: {
			pattern: "^[1-9][0-9]{5}$"
		},
		gstin: {
			pattern: "^\\d{2}[a-zA-Z]{5}\\d{4}[a-zA-Z]{1}\\d[zZ]{1}[a-zA-Z\\d]{1}$"
		}
	};

	function data_validate(field,validation_rule){
		//console.log(JSON.stringify(validation_rule));
	    var fields = {};
	    $.each(field,function(key,value){
	          fields[""+value.name] = value.value;
	    });
	 	error = validate(fields,validation_rule,{fullMessages: false});	
		

	    return error;
	}

	rules = {	firstname: { format: format.string },
				lastname: { format: format.string},
				mobile:   { format: format.number,length: {is: 10}},
				aadhar:   { format: format.number,length: {is: 12},
				},
				cust_dob: { format: format.dateformat},
				tw_cust_dob: { format: format.dateformatydd_mmm_yy},
				email: { email: true},
				pan: { format: format.alphanumerical},
				financierName: {format: format.name},
				nomineeRel : {format: format.name},
				nomineeAge : {format: format.number,length: {maximum:3}},
				pincode: {format:format.pincode,length: {is: 6} },
				regno: {format: format.regno},
				engno: {format: format.alphanumerical,length: {maximum:30,minimum: 6}},
				chassisno: {format: format.alphanumerical,length: {maximum:30,minimum: 6}},
				color: {format:format.name},
				policyno: {format: format.alpha_slash_dash},
				driver_dob: { format: format.dateformat},
	    		noOfAccidents: { format: format.number},
	    		currentMillage: {format:format.number},
	    		nomineeName: {format:format.fullname},
	    		amount : {format:format.number},
	    		gstin: { format: format.gstin,length: {is:15}},
	    		fullname: { format: format.fullname,
					length: {minimum: 2,
							tooShort: ": Please Enter Last Name",
							tokenizer: function(value) {
		        						return value.split(/\s+/g);
		      					}
      						},
      					}
      					,
      			houseno: {format: format.alpha,length: {maximum:30,tooLong: " is too long (maximum is 30 characters)"}},
      			street: {format: format.alpha,length: {maximum:60}},
      			locality: {format: format.alpha,length: {maximum:60}},
      			rsgi_no_age : {  
             numericality: {
               onlyInteger: true,
               greaterThan: 17,
               lessThanOrEqualTo: 115,               
             }
           
        }

	}	


	return{ check : data_validate,
			getRules : function(){ return rules 
			},
			name: {
				firstname: 'Firstname',
				lastname: 'Lastname',
				mobile:  'Mobile',
				aadharno:  'Aadhar Number', 
				cust_dob: 'Date of birth',
				tw_cust_dob: 'Date of birth',
				email: 'Email ID',
				pan: 'PAN Number',
				financierName: 'Financier Name',
				nomineeRel : 'Nominee Relation',
				nomineeAge : 'Nominee Age',
				pincode: 'Pincode',
				regno: 'Registration Number',
				tw_reg_no:  'Registration Number',
				engno: 'Engine Number',
				chassisno: 'Chassis Number',
				color: 'Color',
				policyno: 'Policy Number',
				driver_dob: 'Driver Date Of Birth',
				noOfAccidents: 'Number Of Accidents',
				currentMillage: 'Current Millage',
				nomineeName: 'Nominee Name',
				amount : 'Amount',
				gstin: 'gstin',
				fullname: 'Fullname',
				houseno: 'House/Apartment Number',
				street: 'Street',
				locality: 'Locality',
				rsgi_no_age : 'Age',
				contactperson: 'Contact Person',
				perm_pincode: 'Pincode',
                perm_houseno: 'House/Apartment Number',
                perm_street: 'Street',
                perm_locality: 'Locality',
			}
	}

}(jQuery)
