
// pass all data when user clicked on "finish" 
function purposalFormData() {
    return city = $("#city option:selected:enabled").text(), 
    state = $("#state option:selected:enabled").text(), 
    address = $("input[name='houseno']").val() + ", " + 
    $("input[name='street']").val() + ", " 
    + $("input[name='locality']").val(), 
    data = $("#buy_policy_form :input,#buy_policy_form select").serialize(),
     data += "&state=" + state + "&city=" + city + "&address=" + address, 
     data
}


// on change of stateupdate city
function updateCity(a) {
    $city.empty(), a.length >= 1 && ($city.append('<option hidden="" value="" disabled="" selected="">Select City</option>'), $.each(a, function (a, b) {
        option = '<option class="city_option" value="' + b.id + '">' + b.value + "</option>", $city.append(option)
    }))
}

function updatePermCity(a) {
    $perm_city.empty(), a.length >= 1 && ($perm_city.append('<option hidden="" value="" disabled="" selected="">Select City</option>'), $.each(a, function (a, b) {
        option = '<option class="city_option" value="' + b.id + '">' + b.value + "</option>", $perm_city.append(option)
    }))
}

function chechkData(a) {
    return a ? "undefined" != typeof a.error ? "premium mismatch" == a.error.toLowerCase() || "internal server error" == a.error.toLowerCase() || "premium has changed" == a.error.toLowerCase() ? (pstatus.premiumMissmatchStatus({
        data: a,
        product_id: product_id,
        insurer_id: insurer_id
    }), checkPremiumMissmatchLog = 1, !1) : (er = a.error.split(";"), error = "", $.each(er, function (a, b) {
        "" != b && (error += b + "<br/>")
    }), swal("Errors :", error), !1) : 1 != checkPremiumMissmatchLog ? (pstatus.successPremiumStatus(), !0) : void payment(a) : (common.apiBadReponse(),!1)
}


function validateForm() {
   field = $("#buy_policy_form .col-sm-4:not('.hidden') :input:not('.hidden')").serializeArray();
   if(typeof window['define_rules'] == 'object'){
        error = validater.check(field,window['define_rules']);
    }

    // check the error is arrived or not
    if (typeof error != 'undefined') {
        var error_html = '';
        $.each(error, function (index, value) {
            name = validater.name[index];
            $('#' + index).addClass('error').parent('div').addClass('has-error');
            error_html += name+' '+value + "<br/>";
        });
        common.alert(error_html);
        return false;
    } else {
        return true;
    }
}
review = {
    showUserDetails: function(){
        $data = $(":input", $obj_proposer), $obj_proposer_prev.empty(), this.processDetailsForShow($data, $obj_proposer_prev)      
    },
    showAddressDetails: function(){
        $data = $(":input", $obj_communication), $obj_communication_prev.empty(), this.processDetailsForShow($data, $obj_communication_prev)    
    },
    showVehicleDetails: function(){
        $data = $(":input", $obj_vehicle), $obj_vehicle_prev.empty(), this.processDetailsForShow($data, $obj_vehicle_prev)    
    },
    showPrevInsuranceDetails: function(){
        $data = $(":input", $obj_previousinsurer), $obj_previousinsurer_prev.empty(), this.processDetailsForShow($data, $obj_previousinsurer_prev)    
    },
    processDetailsForShow: function(a, b) {
    if($($("#reg_add_is_same")).is(':checked')){
            $(".perm").hide();
            $(".perm").addClass('hidden');
            $(".info-label").addClass('hidden');
        }else{
            $(".perm").show();
            $(".perm").removeClass('hidden');
            $(".info-label").removeClass('hidden');
     }
    $str = {}, count = 1, $.each(a, function (a, c) {
        if (0 == $(c).closest(".col-sm-4.hidden").length)
            if (type = $(c).attr("type"), tagename = $(c).prop("tagName"), "INPUT" == tagename)
                switch (type) {
                    case "radio":
                        this.checked && (val = $(c).siblings("label").text(), name = $(c).attr("data-name"), "undefined" != typeof name && "undefined" != typeof val && ($str[count] = genrateDetailsView(b, name, val), count++));
                        break;
                    case "text":
                        val = $(c).val(), name = $(c).attr("data-name"), "Registration Number" == name && (val =  $(c).val()), "undefined" != name && "undefined" != val && ($str[count] = genrateDetailsView(b, name, val), count++)
                }
            else
                 "SELECT" == tagename 
                    && (val = $("option:enabled:selected", c).text(),
    val = ((val != '' && val || redirected_log &&

     getDisplayValue(c)
        
      || "Nil")),
        name = $(c).attr("data-name"), 
        "undefined" != typeof name  &&
        ($str[count] = genrateDetailsView(b, name, val), count++))
    }), lastobj = "", preview_data = "", tag = 0, 
    
    tag = 0;
    col = 0;
    c = "";
    $.each($str, function (a, b) {
        count--;
        col++;
        if(count == 1 || col == 2){
            preview_data += "<div class='col-sm-12'>"+c+b+"</div>";            
            col = 0;
            c = "";
        }else{
            c += b;
        }
        console.log(count);
        console.log(col);
    })

     b.append(preview_data)
}

}
function getDisplayValue(c){
   
    value = $("input[name='master_"+$(c).attr('name')+"']").val();
    if(undefined != value || 'undefined' != value){
        if("yom_selected" == c.name){
            return value;
        }
        if("statecode" == c.name){
            console.log(c.name);
            console.log($("#master_state").length);
            $("#master_state").length && $("#master_state").val($("select[name='"+c.name+"'] option[value='"+$("input[name='master_"+c.name+"']").val()+"']").text());
        }

        if("citycode" == c.name){
            stateid = $("input[name='master_statecode']").val();
            data = {    stateid:stateid ,
            insurerId:  policy.$insurerId.val(),
            master: "City",
            _token: policy.$token.val()
            };
            url = policy.$state.attr("data-url");
            var cityname = "";
            common.ajaxSyncPostRequest(url, data,function(data){
                console.log(data);
                $.each(data,function(key,obj){
                    if(obj.id == value){
                        cityname = obj.value;
                    }
                });
            });
            ($("#master_city").length) && $("#master_city").val(cityname);
            return cityname;
        }

        return $("select[name='"+c.name+"'] option[value='"+$("input[name='master_"+c.name+"']").val()+"']").text();    
    }
    return true;
}

function genrateDetailsView(a, b, c) {
    (c == "") && (c = "Nil");
    return "<div class='col-sm-3'>"
                +"<span class='info_text'>"
                    +b.charAt(0).toUpperCase() 
                    +b.slice(1) 
                +" :</span>"
                
            +"</div>"
            +"<div class='col-sm-3'>"
            +c.toUpperCase()
            +"</div>";
}


$(document).ready(function () {
    redirected_log = parseInt($('#redirected').val());
    common.delCookie('hdfc');
    policy = {
        __proto__: common,
        dateFormat: "dd/mm/yy",
        $insurerId: $("#insurer_id"),
        insurerId: 0,
        $token: $("#_token"),
        self: this,

        changeState: function () {
            insurerId = self.$insurerId.val(), "139" === insurerId && (insurerId = "125"), data = {
                stateid: self.$state.val(),
                insurerId: insurerId,
                refrel_col: $('#refrel_col').val(),
                master: "City",
                _token: self.$token.val()
            }, url = self.$state.attr("data-url"), self.ajaxPostRequestWithLoader(url, data, updateCity, self.msg.change_state)
        },
        changePermState: function () {
            insurerId = self.$insurerId.val(),
             "139" === insurerId && (insurerId = "125"),
            data = {
                stateid: self.$perm_state.val(),
                insurerId: insurerId,
                refrel_col: $('#refrel_col').val(),
                master: "City",
                _token: self.$token.val()
            }, 
            url = self.$perm_state.attr("data-url"), 
            self.ajaxPostRequestWithLoader(url, data, updatePermCity, self.msg.change_state)
        },
        setDatePicker: function () {
            var a = "-90:+1",
                 b = "7/11/1990";
            
            cust_max_date = $("#cust_dob").attr("data-minyear");
            driver_max_date = $("#driver_dob").attr("data-minyear");

            $("#cust_dob").attr("data-minyear"), 
            $("#driver_dob").attr("data-minyear");
            $("#cust_dob").datepicker({
                dateFormat: self.dateFormat,
                changeMonth: !0,
                changeYear: !0,
                yearRange: a,
                defaultDate: b,
                maxDate: cust_max_date
            }), $("#driver_dob").datepicker({
                dateFormat: self.dateFormat,
                changeMonth: !0,
                changeYear: !0,
                yearRange: a,
                defaultDate: b,
                maxDate: driver_max_date
            })
        },
        init: function () {
            self = this, self.initSelector(), 
            self.setDatePicker(),
            self.$state.change(self.changeState)
            self.$perm_state.change(self.changePermState)
        },
        initSelector: function () {
            self.$state = $("#state");
            self.$perm_state = $("#perm_state");
        }
    }, policy.init(), $insurerId = $("#insurer_id")
    , $perm_city = $("#perm_city"), $city = $("#city"), $city_option = $(".city_option"), $token = $("#_token"), $car_form = $("#buy_policy_form"), $business_type = $("#policy_type"), $obj_proposer = $("#proposer"), $obj_communication = $("#communication"), $obj_previousinsurer = $("#previousinsurer"), $obj_vehicle = $("#vehicle"), pstatus = {
        __proto__: common,
        $token: $("#_token"),
        collectDataStatus: function () {
            if($("#exp_status").length > 0 && $("#exp_status").val() > 0){
                return false;
            };
            url = $("#premiumreconfirm").val(), data = {
                _token: self.$token.val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)

        },
        showOverlayHtml: function (a) {
            self.overlay_msg(a.html)
        },
        successPremiumStatus: function () {
            if($("#exp_status").length > 0 && $("#exp_status").val() > 0){
                return false;
            };
            url = $("#premiumstatus").val(), data = {
                _token: self.$token.val(),
                product_id: $("#product_id").val(),
                trans_code:$("#trans_code").val(),
                session_id: $("#session_id").val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)
        },
        inscpectionStatus: function () {
            url = $("#inspection_status").val(), data = {
                _token: self.$token.val(),
                product_id: $("#product_id").val(),
                trans_code:$("#trans_code").val(),
                session_id: $("#session_id").val()
            }, 
            self.ajaxSyncPostRequest(url, data, this.showOverlayHtml)
        },
        premiumMissmatchStatus: function (a) {
            url = $("#premiummissmatch").val(),
                    price = "undefined" == typeof a.data.premiumPayable ?
                    a.data["Total Amount Payable"] : a.data.premiumPayable;
            if (price == "undefined" || typeof price == 'undefined')
                price = a.data.PremiumPayable;

            passed_price = (typeof a.data.PremiumPassed != 'undefined' && a.data.PremiumPassed)
            || (typeof a.data.Total_Premium_Passed != 'undefined' && a.data.Total_Premium_Passed)
            || (typeof a.data.passedPremium != 'undefined' && a.data.passedPremium)
            || (typeof a.data.premiumPassed != 'undefined' && a.data.premiumPassed);

            passed_price = passed_price || $(passed_payment).text();
            data = {
                _token: self.$token.val(),
                session_id:$("#session_id").val(),
                trans_code:$("#trans_code").val(),
                product_id: $("#product_id").val(),
                price: price,
                passed_price: passed_price
            }, self.ajaxPostRequestWithOption(url, data, premiumMismatch, a)
        },
        badResponseStatus: function () {
            url = $("#badresponse").val(), data = {
                _token: self.$token.val()
            }, self.ajaxPostRequest(url, data, this.showOverlayHtml)
        }
    }, $(document).on("click", "#car-btn-pay", function () {
        // check user has confirm 
        $obj = $("#disclaimer").closest("div");
        if($obj.hasClass("shake")){
            $obj.removeClass("shake").removeClass("animated");
        }
        
        if($("#disclaimer").prop('checked') == false){
            common.alert(common.msg.term_agree)
            $obj.closest("div").addClass("shake").addClass("animated");
            return true;
        }

        if(!validateForm())
            return false;

         pstatus.collectDataStatus(),(data = purposalFormData(),
        product_id = $("#product_id").val(),
        insurer_id = $("#insurer_id").val(),
        "139" === insurer_id && (product_id = "125MO01PC1", insurer_id = "125"),
        url = $("#buy_policy_form").attr("action"), 
        
       (($("#exp_status").length > 0) ?
                (exp_status = $("#exp_status").val(),
                (exp_status != 0) ?
                   pstatus.inscpectionStatus()
                :
                    setTimeout(function () {
                         getForm(product_id, insurer_id, data);
                    }, 5e3)
                )
        : (setTimeout(function () {
                getForm(product_id, insurer_id, data);
            }, 5e3)
            )
        )
    )}), $(document).on("change", "input[name='type']", function () {
        "O" == $(this).val() ? ($(".individual").addClass("hidden"), $(".organization").removeClass("hidden")) : ($(".individual").removeClass("hidden"), $(".organization").addClass("hidden"))
    }), $(document).on("change", "input[name='vehicle_financed']", function () {
        "Y" == $(this).val() ? $(".is_v_financed").removeClass("hidden") :  $(".is_v_financed").addClass("hidden")
    }), demo.initMaterialWizard(),
    $(".btn-next").click(function () {
        review.showUserDetails(), review.showAddressDetails(), review.showVehicleDetails(), review.showPrevInsuranceDetails()
    }), $(".change").click(function () {
        ref = $(this).attr("data-href"),
         $(".wizard-navigation li a[href='" + ref + "']").click()
    })

    type = $('input[name="type"]:checked').val();
    if (type == 'O')
        $('input[name="type"]:checked').change();
});
var checkPremiumMissmatchLog = 0;
$obj_proposer = $("#proposer"), $obj_communication = $("#communication"), $obj_previousinsurer = $("#previousinsurer"), $obj_vehicle = $("#vehicle"), $obj_proposer_prev = $("#proposer_preview"), $obj_communication_prev = $("#communication_preview"), $obj_previousinsurer_prev = $("#previousinsurer_preview"), $obj_vehicle_prev = $("#vehicle_preview"), $(document).on("click", ".modal_details", function (a) {
    var b = $(this).attr("data-modal"),
            c = $(this).attr("data-producid");
            d = $(this).attr("data-trans_code"),
    $("#"+b).modal();
}), $(document).on("click", "#payment-submit", function () {
    payment(policy.proposal_return_data)
}), $(document).on("click", "#re-submit", function () {
    selectedPremium(policy.basePremium, policy.serviceTax, policy.product_id, policy.insurer_id)
}), $(document).on("click", "#review-again", function () {
    checkPremiumMissmatchLog = 0, common.overlay_rem()
}),
$(document).on("click", "#inspection-submit", function () {
    data = purposalFormData(),
    product_id = $("#product_id").val(),
    insurer_id = $("#insurer_id").val(),getForm(product_id, insurer_id, data);
});


$('#buy_policy_form #reg-no').keyup(function(){
    if(this.value.length <11){
        this.value = this.value.replace(/([a-zA-Z0-9]{2})$/g,'$1-');
       }
});


$('.wizard-card').bootstrapWizard({
    'tabClass': 'nav nav-pills',
    'nextSelector': '.btn-next',
    'previousSelector': '.btn-previous',
    onPrevious: function (tab, navigation, index) {


    },
    onNext: function (tab, navigation, index) {
        var $valid = $('.wizard-card form').valid();
        if (!$valid) {
            $validator.focusInvalid();
            return !1
        }
        tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
        
        if(tab_text == "Review"){
            return true;
        }

        if(tab_text != "Proposer"){
            return validateData();
        }

        policy_cmp_sel = '#policy_cmp';
        if ($(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc' || $(policy_cmp_sel).val() == 'rsgi' || $(policy_cmp_sel).val() == 'itgi') {
            // if user not veryfied
            check_v = window["'"+otp.getMobile()+"'"];
            if (!check_v || check_v == 'undefined'){
                if (validateData()) {
                   otp.verifyMobileNumber();
                   return false;
                }else
                    return false;    
            }else
                return validateData();
        }else
            return validateData();
    },
    onTabShow: function (tab, navigation, index) {
        

        var $total = navigation.find('li').length;
        var $current = index + 1;
        var $wizard = navigation.closest('.wizard-card');
        if ($current >= $total) {
            $($wizard).find('.btn-next').hide();
            $($wizard).find('.btn-finish').show()
        } else {
            $($wizard).find('.btn-next').show();
            $($wizard).find('.btn-finish').hide()
        }
        button_text = navigation.find('li:nth-child(' + $current + ') a').html();
        setTimeout(function () {
            $('.moving-tab').text(button_text)
        }, 150);
        var checkbox = $('.footer-checkbox');
        if (!index == 0) {
            $(checkbox).css({
                'opacity': '0',
                'visibility': 'hidden',
                'position': 'absolute'
            })
        } else {
            $(checkbox).css({
                'opacity': '1',
                'visibility': 'visible'
            })
        }
        refreshAnimation($wizard, index)
    },
    onTabClick: function (tab, navigation, index) {
        review.showUserDetails(), review.showAddressDetails(), review.showVehicleDetails(), review.showPrevInsuranceDetails();
        var $valid = $('.wizard-card form').valid();
        if (!$valid) {
            return !1
        } else {
            tab_text = $('#wizardProfile .nav.nav-pills li.active a').text();
            if(tab_text == "Review")
                return true;
            if(tab_text != "Proposer")
                return validateData();
            if ($(policy_cmp_sel).length && $(policy_cmp_sel).val() == 'hdfc' || $(policy_cmp_sel).val() == 'rsgi' || $(policy_cmp_sel).val() == 'itgi') {
                // if user not veryfied
                check_v = window["'"+otp.getMobile()+"'"];
                if (!check_v || check_v == 'undefined'){
                    if (validateData()) {
                        otp.verifyMobileNumber();
                        return false;
                    }else
                        return false;    
                }else
                    return validateData();
            } else
                return validateData();
        }
    },

});

var $validator = $('.wizard-card form').validate({
    rules: {
        firstname: {
            required: !0,
            minlength: 3
        },
        lastname: {
            required: !0,
            minlength: 3
        },
        email: {
            required: !0,
            minlength: 3,
        }
    },
    errorPlacement: function (error, element) {
        $(element).parent('div').addClass('has-error')
    }
});


// on click of next validate data and stored data in db
function validateData() {
    id = $(".tab-pane.active").attr('id');
    field = $("#" + id + " :input:visible").serializeArray();
    if(typeof window['define_rules'] == 'object'){
        error = validater.check(field,window['define_rules']);
    }    
    //if got error
    if (typeof error != 'undefined') {
        var error_html = '';
        $.each(error, function (index, value) {
            name = validater.name[index];
            $('#' + index).addClass('error').parent('div').addClass('has-error');
            error_html += name+' '+value + "<br/>";
        });
        common.alert(error_html);
        return false;
    } else {
        fields = common.serilazeArrToArr($("#" + id + " :input:visible").serializeArray());
        fields.id = id;
	fields.reg_add_is_same = $("#reg_add_is_same").val();
        fields.session_id = $("#session_id").val();
    	fields.trans_code = $("#trans_code").val();
        fields._token = $('#_token').val();
        setData(fields);
        return true;
    }
}

sel_setdata = "#setdata";

// setProposalData on click of next stored data in db
function setData(fields) {
    console.log(fields);
    url = $(sel_setdata).attr('data-url');
    common.ajaxPostRequest(url, fields, function (data) {
        common.redirectOnTransaction(data);        
    });
}



var otp = new (function ($) {
    policy_cmp_sel = '#policy_cmp',
            mobile = '',
            $token = $("#_token"),
            $otp_gen = $('#otp_gen'),
            $very_otp = $('#very_otp');
    verifycation_status = 0;
    $obj_proposer = $("#proposer");

    function genrateOtp() {
        console.log(mobile)
        b = {_token: self.$token.val(), mobile: mobile}
        a = $otp_gen.val();
        console.log(a);
        common.ajaxPostRequestWithLoader(a, b, function (data) {
            
            console.log("Genrate Otp Data");
            console.log(data);
            if (data) {
                if(typeof data.overLimit != undefined && data.overLimit){
                    console.log(data);
                    // common.alert(common.msg['unveryfied_user']);
                    common.alert("you are exceed the verifiation limit");
                    return false;
                }

                if (typeof data.status != undefined) {
					//When mobile is verified					
					if(data.otp){						
							if (data.status) {
                                console.log("check what happen"+otp.getMobile());
                                window["'"+otp.getMobile()+"'"] = 1;
                                $(".wizard-card").bootstrapWizard("next");
							}else{
                                verificationDisplay(mobile);
                            }
					} else if (data.status){
                        verificationDisplay(mobile);
                    }
                    else{
                        common.alert(common.verify_otp_not_gen);
                        return false;
                    }
                }
            }
        }, common.msg['gen_code']);
    }

    function verificationDisplay(mobile) {
        var status = 0;
        swal({
            title: '<b>Enter Verification Code</b>',
            text: 'Please Check Your text message at the phone number ' + mobile,
            input: 'text',
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            preConfirm: function (text) {
                return new Promise(function (resolve, reject) {
                    setTimeout(function () {
                        if (text == '') {
                            reject(common.msg['enter_otp']);
                        } else if (text.length != 4) {
                            reject(common.msg['otp_length']);
                        } else {
                            resolve()
                        }
                    }, 2000)
                })
            },
            allowOutsideClick: false
        }).then(function (text) {
            status = verifyCode(text);
        })
    }

    function verifyCode(code) {
        b = {_token: self.$token.val(), code: code}
        a = $very_otp.val();
        var status = 0;
        common.ajaxPostRequest(a, b, function (data) {
            if (data) {
                if (typeof data.status != undefined) {
                    window[""+otp.getMobile()] = data.status;
                    if (window[""+otp.getMobile()]) {
                        common.setCookie('hdfc', 3, 1);
                        $(".wizard-card").bootstrapWizard("next");
                        common.alert(common.msg['user_verified']);
                    } else
                        common.alert(common.msg['unveryfied_user']);
                }
            }
        });

        if (window.verified == undefined) {
            window.verified = 1;
        } else {
            window.verified = window.verified + 1;
        }

        common.setCookie('hdfc', window.verified, 1);
    }
	
	

    return {
        self: this,
        verifycation_status: verifycation_status,
        verified: window.verified,
        getMobile: function(){
            return $('#mobile').val();
        },
        verifyMobileNumber: function () {
            console.log('verifyMobileNumber');
            mobile = this.getMobile();
			return genrateOtp();
        }
    }


})(jQuery);

function refreshAnimation($wizard, index) {
    total_steps = $wizard.find('li').length;
    move_distance = $wizard.width() / total_steps;
    step_width = move_distance;
    move_distance *= index;
    $current = index + 1;
    if ($current == 1) {
        move_distance -= 8
    } else if ($current == total_steps) {
        move_distance += 8
    }
    $wizard.find('.moving-tab').css('width', step_width);
    $('.moving-tab').css({
        'transform': 'translate3d(' + move_distance + 'px, 0, 0)',
        'transition': 'all 0.5s cubic-bezier(0.29, 1.42, 0.79, 1)'
    })
}



$(document).ready(function(){
    if(redirected_log){
        review.showPrevInsuranceDetails()
        ,review.showVehicleDetails()
        ,review.showAddressDetails()
        ,review.showUserDetails();    
    }
    // if city is not selected unset state 
    if($("#city").val() == ''){
        $("#state").val("");
    }

    $(document).on("click",'.save_premium_breakup',function(event){
        event.preventDefault();
        genrate_pdf('quote_premium_breakup');    
    }); 

    $(document).on("click",'.quote_package_info',function(event){
        event.preventDefault();
        genrate_pdf('quote_package_info');    
    });

    function genrate_pdf($pdf_type){
        $("#save_pdf").html('<input type="hidden" name="trans_code" value="'+$("#trans_code").val()+'">')
        $("#save_pdf").append("<input type='hidden' name='pdf_type' value='"+$pdf_type+"'>");
        $("#save_pdf").submit();
    }
    
});
