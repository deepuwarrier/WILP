	// define validation rules
	$(document).ready(function () {
		var ncb = 0;
		hideOrShowPermAddress();

		$("input:radio[name='ownership_change']").change(function(){
		    if($(this).val() == 'Y'){
		    	ncb = $("#ncb").text();
		    	$("#ncb").text('0%');
		    	common.alert("Your NCB will be zero and you premium rate will be increased");
		    }else{
		    	$("#ncb").text($('#actual_ncb').val()+'%');
		    }
		});
				
		$("#reg_add_is_same").click(function(){
			hideOrShowPermAddress();	
		});

		function hideOrShowPermAddress(){
			$(".info-label").hide();
			if($($("#reg_add_is_same")).is(':checked')){
				$(".perm").hide();
				$(".perm").addClass('hidden');
				$(".info-label").addClass('hidden');
			}else{
				$(".perm").show();
				$(".perm").removeClass('hidden');
				$(".info-label").removeClass('hidden');
			}
		}

	    var rs_proposal_reurn_data;
	    if (typeof validater != 'undefined') {
	        rules = validater.getRules();
	        define_rules = {
				fullname: rules.fullname
				,mobile: rules.mobile
				,aadharno: rules.aadhar
				,cust_dob: rules.cust_dob
				,email: rules.email
				,pan: rules.pan
				,contactperson: rules.nomineeName
				,pincode: rules.pincode
				,houseno: rules.houseno
				,street: rules.street
				,locality: rules.locality
				,perm_pincode: rules.pincode
				,perm_houseno: rules.houseno
				,perm_street: rules.street
				,perm_locality: rules.locality
				,regno: rules.regno
				,engno: rules.engno
				,chassisno: rules.chassisno
				,color: rules.color
				,financierName: rules.financierName
				,policyno: rules.policyno
				,claimAmountReceived: rules.amount
				,nomineeAge: rules.rsgi_no_age
				,nomineeName: rules.nomineeName
				,nomineeRel: rules.color
	        }
	    } else {
	        console.error("insert validator_helper.js for validation");
	    }
	});

	// payment related function
	function getForm(a, b, c) {

	    common.loader_msg(common.msg.submit_form), $.ajax({method: "POST", url: url, data: c, dataType: "json"}).done(function (a) {
	       window['rs_proposal_reurn_data'] = a;
	       common.redirectOnTransaction(a);
	        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
	    }).always(function () {
	        common.loader_rem()
	    }).fail(function(){
	    	common.loader_msg(common.msg.submit_form)
	        common.proposalError();
	    });
	}

	// on premiim missmatch
	function premiumMismatch(a, b) {
	    policy.title = "Premium has changed!", policy.text = a.html, policy.basePremium = b.data.premiumPayable, policy.serviceTax = 0, policy.product_id = b.product_id, policy.insurer_id = b.insurer_id, common.overlay_msg(policy.text)
	}

	function selectedPremium(a, b, c, d, e) {
	    //data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
	    
	    payment(window['rs_proposal_reurn_data']);
	}

	// on proposal success redirect to payment gateway
	function payment(data) {
		console.log(data);
	    common.loader_rem();
	    common.loader_msg(common.msg['payment_redirect']);
	    url = $('#init_payment').val();
	    c = {
	        _token:$("#_token").val(),
	        trans_code:$("#trans_code").val()
	    };
	    $.ajax({
	        method: "POST",
	        url: url,
	        data: c,
	        dataType: "json"
    	}).done(function (a) {
		    if (data.field) {
		    	input_ele = '';
		        $.each(data.field, function(index, val) {
	                input_ele += '<input type="hidden" value="'+val+'" name="'+index+'"/>';     
	            });
	            input_ele += "<input  class='hidden' type='Submit' value ='Submit' id='rs_submit'/>";
	            var pay_form = '<form id="payment" name="payment" method="POST" action="' + data.url + '">';
	            pay_form += input_ele;
	            pay_form += "</form>";
	            $("#pay_form").html(pay_form);
	            $('#payment').submit();
		    }
		}).always(function () {
	        common.loader_rem()
	    }).fail(function(){
	        common.loader_rem()
	    });
	}

	$('#reg_add_is_same').click(function(event) {
		if($('#reg_add_is_same').is(':checked')){
			$('#reg_add_is_same').val('Y');
		} else {
			$('#reg_add_is_same').val('N');
		}
	});
	
