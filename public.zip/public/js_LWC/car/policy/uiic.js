function getForm(a, b, c) {
    common.loader_msg(common.msg.submit_form), $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (a) {
    	//redirect_to_payment(a);
        common.redirectOnTransaction(a);
        (a.redirect == null) && chechkData(a) && (policy.proposal_return_data = a)
    }).always(function () {
        common.loader_rem()
    }).fail(function(){
       //common.apiBadReponse();
    });
}

function premiumMismatch(a, b) {
    policy.title = "Premium has changed!",
    policy.text = a.html, 
    policy.basePremium = b.data.basePremium, 
    policy.serviceTax = b.data.serviceTax, 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d) {
    data = purposalFormData(), data = data + "&new_premium=" + a + "&new_service_tax=" + b, c = $("#product_id").val(), d = $("#insurer_id").val(), url = $("#buy_policy_form").attr("action"), getForm(c, d, data)
}

function payment(a) {
    url = $('#init_payment').val();
    c = {
        _token:$("#_token").val(),
        trans_code:$("#trans_code").val()
    };

    $.ajax({
        method: "POST",
        url: url,
        data: c,
        dataType: "json"
    }).done(function (b) {
        action =' https://pgi.billdesk.com/pgidsk/PGIMerchantPayment';
        //action ='https://sandbox.instainsure.com/PG/BillDeskPG.php';
        //action = '/car-insurance/uiic/payment/status';
        var pay_form = '<form id="payment" name="uiic_payment" method="GET" action="'+action+'">';
        pay_form += "<input  class='hidden' type='hidden' name='msg' value ='"+a.msg+"'/>";
        pay_form += "<input  class='hidden' type='Submit' value ='Submit' id='submit_uiic_payment'/>";
        pay_form += "</form>";          
        $("body").append(pay_form);
        $('#payment').submit();
     }).always(function () {
        common.loader_rem()
    }).fail(function(){
        common.loader_rem()
    });
}


$(document).ready(function () {
    if (typeof validater != 'undefined') {
        rules = validater.getRules();
        define_rules = {
            mobile: rules.mobile,
            cust_dob: rules.cust_dob,
            email: rules.email,
            pan: rules.pan,
            gstin: rules.gstin,
            nomineeAge: rules.nomineeAge,
            contactperson: rules.nomineeName,
            aadharno: rules.aadhar,
            fullname: rules.fullname,
            gstin: rules.gstin,
            pincode: rules.pincode,
            houseno: rules.houseno,
            street: rules.street,
            locality: rules.locality,
            regno: rules.regno,
            engno: rules.engno,
            chassisno: rules.chassisno,
            color: rules.color,
            policyno: rules.policyno,
            nomineeName: rules.nomineeName    
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }

     $('#financiername').change(function (){
           var financiername = $(this).val();
           var url = $(this).data('url');
           $.ajax({
                url: url,
                data: { 'financiername' : financiername ,'_token' : $("#_token").val()},
                type: "post",
                cache: false,
                success: function (savingStatus) {
                    $('#financierCode').html(savingStatus);  
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    $('#lblCommentsNotification').text("Error encountered while saving the comments.");
                }
            });
        });
    });
