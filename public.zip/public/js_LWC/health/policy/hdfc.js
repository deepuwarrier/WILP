paymode         = 'CC';
paymode_flag    = false;
trans_code      = $('#hl_trans_code').val();
$token = $("input[name=_token]").val();

function getForm(a, b, c) 
{ 
    common.overlay_msg(common.msg.submit_form), 
    $.ajax({
        method: "POST", url: url, data: c, dataType: "json"
    }).done(function (a) {

        if(a['status'] == 'verror'){ 
             swal(a['verror_txt']);
        }else if(a['status'] == 'success' || a['status'] == 'null' || a['status'] == ''){ 
             staticpayment(a)
        }else if(a['status'] == 'false' && typeof(a['message']) != "undefined" ){
            swal(a['message']);
        }else if(a['policytype'] == "NONSTP") {
            chechk_hdfc_policy(a)
        }
        else if(a['status'] == 'false') {
             staticpayment(a)
        }else if(a['error'] == 'age_over') {
            offline_policy(a)
        } else{
        chechkData(a) && (policy.proposal_return_data = a)
    }
    }).always(function () {
        common.loader_rem()
    });
}


function load_dob_list(){
  count = $('#membercount').val(); 
  for(i=0; i<count; i++){  
    $('#dob_list'+i).datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      minDate: $('#dob_list'+i).attr('min-date'),
      maxDate: $('#dob_list'+i).attr('max-date'),
      yearRange: "-90:+1"})
   } 
}


function policyCheck(a, b){
    policy.text = a.html, 
    common.overlay_msg(policy.text)
}


function premiumMismatch(a, b) {  

    basePremium = Math.floor(b.data.premiumPayable  / (parseInt(18)+100) * 100), 
    serviceTax = parseInt(b.data.premiumPayable) - parseInt(basePremium),
    policy.title = "Premium has changed!", 
    policy.text = a.html, 
    policy.totalPremium = b.data.premiumPayable,
    policy.basePremium = Math.round(basePremium), 
    policy.serviceTax = Math.round(serviceTax), 
    policy.product_id = b.product_id, 
    policy.insurer_id = b.insurer_id, 
    common.overlay_msg(policy.text)
}

function selectedPremium(a, b, c, d, e) { 
    data = proposalFormData(), 
    data = data + "&new_premium=" + a + "&new_service_tax=" + b + "&new_total_premium=" + e, 
    c = $("#product_id").val(), 
    d = $("#insurer_id").val(), 
    url = $("#buy_policy_form").attr("action"), 
    getForm(c, d, data)
}

function staticpayment(a) {
    window.location = $("#offline_policy").val()
}

function offline_policy(a) {
    window.location = $("#offline_policy").val() + '?msg='+a.msg_id;
}

// For Payment Mode selection by customer
$(document).on("change", "#paymode_cc", function() {
    if( $(this).is(":checked") ){
        paymode = $(this).val();
        paymode_flag = true;
    }
});

$(document).on("change", "#paymode_dd", function() {
    if( $(this).is(":checked") ){ 
        paymode = $(this).val();
        paymode_flag = true;
    }
});

function payment(response) { 
    update_payment_mode();
    response.hdnPayMode = paymode;
    var data = {'CustomerId' : response.CustomerId,'UserName' : response.UserName , 'hdnPayMode' : response.hdnPayMode, 'ProducerCd' : response.ProducerCd, 'ProductCd' : response.ProductCd, 'AdditionalInfo1' : response.AdditionalInfo1,'AdditionalInfo2' : response.AdditionalInfo2, 'AdditionalInfo3' : response.AdditionalInfo3,'UserMailId' : response.UserMailId ,'TxnAmount' : response.TxnAmount}; 
    // Redirecting to PG
    var payment_ref_num = '';
    store_payment_status(payment_ref_num);
    postData(response.payUrl, 'post', data);
}


function update_payment_mode(){
    paymode = (paymode_flag == false) ? 'CC' : paymode;
    data['hdnPayMode'] = paymode;
    paymode_flag = false;
    url = APP_URL + "/health-insurance/hdfc/update_paymode";
    $.ajax({
        method: "POST", 
        url: url, 
         data: { '_token': $token, 'trans_code' : trans_code , 'pay_mode' : paymode},
        dataType: "json"
    }).done(function (data) { 
    });
}

function postData(actionUrl, method, data) {
    var mapForm = $('<form id="mapform" action="' + actionUrl + '" method="' + method.toLowerCase() + '"></form>');
    for (var key in data) {
        if (data.hasOwnProperty(key)) {
            mapForm.append('<input type="hidden" name="' + key + '" id="' + key + '" value="' + data[key] + '" />');
        }
    }
    $('body').append(mapForm);
    mapForm.submit();
}

// Medical Details
$('#illness-yes').click(function(){  
        $("#having_illness").val(""),
        1==$(this).val()?$("#having_illness").show():$("#having_illness").hide()
});

$("#illness-no").on("click", function(){
     $("#disease_member_1").val('');
     $("#disease_member_2").val('');
     $("#disease_member_3").val('');
     $("#disease_member_4").val('');
     $("#having_illness").val(""),
        1==$(this).val()? $("#having_illness").show() : $("#having_illness").hide()
});

$(document).ready(function() { 
    if (typeof validater != 'undefined') { 
        rules = validater.getRules();
        define_rules = {
           insured : {
                firstname: rules.firstname,
                lastname: rules.lastname
               // pan: rules.pan
                
            },
            communication: {
                pincode: rules.pincode,
                email: rules.email,
                mobile: rules.mobile
            }
        }
    } else {
        console.error("insert validator_helper.js for validation");
    }
});
