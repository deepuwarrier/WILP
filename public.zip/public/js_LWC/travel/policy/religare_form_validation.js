function validateProposal(id){
    $return_type = true;
    errors = '';
    var i  = 1;
    field  = $("#" + id + " :input:visible").serializeArray();
    fields = serilazeInnerArr(field);
    var travelcount = $('#travelcount').val();
    if(id === 'travel'){

        // Guardian Name
        if($('#guardian_container').is(':visible')){
            if($('#guardian_name').val() == null || $('#guardian_name').val() == '' || $('#guardian_name').val() == ' '){
            errors += 'Guardian name cannot be empty<br/>';
            $return_type = false;
            }else if(!$('#guardian_name').val().match(/^[A-z ]+$/i)) {
                errors += 'Guardian name should only contain alphabets<br/>';
                $return_type = false;

            }else if($('#guardian_name').val()){ 
                if (!$('#guardian_name').val().match(/^[a-z\.]+ [a-z]+/i)) {
                    errors += 'Guardian Last name is required<br/>';
                    $return_type = false;
                }
            }
        }         

        // Guardian Relationship
        if($('#guardian_container').is(':visible')){
            var rel = $('#guardian_relationship').val();
                if(rel== null){
                    errors += 'Please select Guardian relationship <br/>';
                    $return_type = false;
            }
        }

        //Adhaar Number
        if($("#aadhaar").length) {
            if($('#aadhaar').val() == null || $('#aadhaar').val() == '' || $('#aadhaar').val() == ' ' ){
                errors += 'Aadhaar number should not be empty<br/>';
                $return_type = false;
            }else if($('#aadhaar').val()){
                if (!$('#aadhaar').val().match(/^\d{4}\-\d{4}\-\d{4}$/)) {
                    errors += 'Invalid Aadhaar number<br/>';
                    $return_type = false;
                }
            }
        } 

        // Guardian DOB
        if($('#guardian_container').is(':visible')){
            var hname = $('#guardian_dob').val();
            if(hname == '' || hname == null || hname == ' '){
                errors += "Please select Guardian DOB<br/>";
                $return_type = false;
            }
        }

        // Guardian Passport number
        if($('#guardian_container').is(':visible')){
            if($('#guardian_passport').val() == null || $('#guardian_passport').val() == '' || $('#guardian_passport').val() == ' ' ){
                errors += 'Guardian Passport cannot be empty<br/>';
                $return_type = false;
            }else if($('#guardian_passport').val()){
                    if (!$('#guardian_passport').val().match(/^[a-zA-Z0-9-]+$/)) {
                        errors += 'Invalid Guardian Passport No.<br/>';
                        $return_type = false;
                    }
            }
            
        }    

        // Nominee Name
        if($('#nominee_container').is(':visible')){
            if($('#nomineename').val() == null || $('#nomineename').val() == '' || $('#nomineename').val() == ' ' ){
                errors += 'Nominee name cannot be empty<br/>';
                $return_type = false;
            }else if($('#nomineename').val()){
                if (!$('#nomineename').val().match(/^[A-z ]+$/i)) {
                    errors += 'Nominee name should only contain alphabets<br/>';
                    $return_type = false;
                }
            }
        }    

        //Checking Nominee Relationship
        if($('#nominee_container').is(':visible')){
            var rel = $('#nomineerel').val();
                if(rel== null){
                    errors += 'Please select nominee relationship <br/>';
                    $return_type = false;
            }
        }    

        // Start Date
        if($('#std_policy_key').length){
            var str = $('#startdate').val();
            if(str == '' || str == null || str == ' '){
                errors += "Please select policy Start date<br/>";
                $return_type = false;
            }  
        }

        for(j=0; j<travelcount; j++){
            //Checking Relationship
            var rel_count = j + 1;
            if(i != 1 && $('#relationship'+rel_count).length){
                var rel = $('#relationship'+rel_count).val();
                if(rel== null){
                    errors += 'Please select a relationship for Traveller '+i+'<br/>';
                    $return_type = false;
                }
            }
            // Cheking Name
            if($('#name'+j).val() == null || $('#name'+j).val() == '' || $('#name'+j).val() == ' '){
                errors += (travelcount == 1)? 'Name cannot be empty<br/>' : "Traveller "+j+" name cannot be empty<br/>";
                $return_type = false;
            }else if(!$('#name'+j).val().match(/^[A-z ]+$/i)) {
                errors += (travelcount == 1)? 'Name should only contain alphabets<br/>' : "Traveller "+j+" name should only contain alphabets<br/>";
                $return_type = false;

            }else if($('#name'+j).val()){ //Code for checking the last name of each traveller
                if ($('#name'+j).val().match(/^[a-z\.]+ [a-z]+ [a-z]+ [a-z]/i)) {
                    errors += (travelcount == 1)? 'Invalid Name <br/>' : "Invalid Name for "+$('#name'+j).val()+"<br/>";
                    $return_type = false;
                }

                if (!$('#name'+j).val().match(/^[a-z\.]+ [a-z]+/i)) {
                    errors += (travelcount == 1)? 'Last Name is required<br/>' : "Last Name is required for "+$('#name'+j).val()+"<br/>";
                    $return_type = false;
                } 

                if (!$('#name'+j).val().match(/^[a-z\.]{3,30}[ ][a-z]+/i)) {
                    errors += (travelcount == 1)? 'First Name should contain Min 3 and Max 30 characters <br/>' : "First Name should contain Min 3 and Max 30 characters for "+$('#name'+j).val()+"<br/>";
                    $return_type = false;
                }

                if (!$('#name'+j).val().match(/^[a-z\.]{3,30}[ ][a-z]{3,30}/i)) {
                    errors += (travelcount == 1)? 'Last Name should contain Min 3 and Max 30 characters <br/>' : "First Name should contain Min 3 and Max 30 characters for "+$('#name'+j).val()+"<br/>";
                    $return_type = false;
                } 
            }

            // Passport number validation
            if($('#passport'+j).val() == null || $('#passport'+j).val() == '' || $('#passport'+j).val() == ' ' ){
                errors += (travelcount == 1)? 'Passport field cannot be empty<br/>' : "Traveller "+i+" passport field cannot be empty<br/>";
                $return_type = false;
            }else if($('#passport'+j).val()){
                if (!$('#passport'+j).val().match(/^[a-zA-Z][0-9-]+$/)) {
                    errors += (travelcount == 1)? 'Invalid Passport No.<br/>' : 'Traveller '+i+" invalid Passport No.<br/>";
                    $return_type = false;
                }else if(!$('#passport'+j).val().match(/^[a-zA-Z][0-9-]{6,8}/i)){
                    errors += (travelcount == 1)? 'Passport No. should contain Min 6 and Max 8 characters<br/>' : 'Passport No. should contain Min 6 and Max 8 characters for Traveller'+i+"<br/>";
                    $return_type = false;
                }
            }          
         

            i++;
        }
        if(errors != ""){
            title = 'Errors : ';
            common.overlay_rem(); 
            swal(errors);
        }else {
            set_proposal_data(fields);
        }

        return $return_type;
    }

    if(id === 'communication'){
        $return_type = true;
        errors = '';
        field  = $("#" + id + " :input:visible").serializeArray();
        fields = serilazeArrToArr($("#" + id + " :input:visible").serializeArray());
        //Email ID validation
        var email = $('#email').val();
        if(email == '' || email == null || email == ' '){
            errors += "Email ID should not be empty<br/>";
            $return_type = false;
        }else if(!email.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
            errors += "Invalid Email ID<br/>";
            $return_type = false;
        }
        //Mobile Number validation
        var mob = $('#mobile').val();
        if(mob == '' || mob == null || mob == ' '){
            errors += "Mobile number should not be empty<br/>";
            $return_type = false;
        }else if(!mob.match(/^[789]\d{9}$/i)){
            errors += "Invalid Mobile number<br/>";
            $return_type = false;
        }

        // House Name / Number 
        var hname = $('#house_name').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "House Name/ Number should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9_./:;//\(), -]+$/i)){ 
            errors += "Invalid Street Name<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9_./:;//\(), -]{1,35}$/i)){
            errors += "House Name / Number should be with in 35 characters<br/>";
            $return_type = false;
        }
        // Street 
        var street = $('#street').val();
        if(street == '' || street == null || street == ' '){
            errors += "Street Name should not be empty<br/>";
            $return_type = false;
        }else if(!street.match(/^[a-zA-Z0-9_./:;//\(), -]+$/i)){ 
            errors += "Invalid Street Name<br/>";
            $return_type = false;
        }else if(!street.match(/^[a-zA-Z0-9_./:;//\(), -]{1,35}$/i)){
            errors += "Street address should be with in 35 characters<br/>";
            $return_type = false;
        }
        //State
        var state = $('#state').val();
        if(state == null){
            errors += "Please select a State <br/>";
            $return_type = false;
        }
        //City
        var city = $('#city').val();
        if(city == null){
            errors += "Please select a City <br/>";
            $return_type = false;
        }   
        // Pincode 
        var pin = $('#pincode').val();
        if(pin == '' || pin == null || pin == ' '){
            errors += "Pincode should not be empty<br/>";
            $return_type = false;
        }else if(!pin.match(/^[1-9][0-9]{5}$/i)){ 
            errors += "Invalid Pincode<br/>";
            $return_type = false;
        }

        if(errors != ""){
            title = 'Errors : ';
            common.overlay_rem(); 
            swal(errors);
        }else {
            set_proposal_data(fields); // In travel/policy/common.js
        }

        return $return_type;

    }

    if(id === 'travel_details'){
        $return_type = true;
        errors = '';
        // Start Date
        var str = $('#trip_start_date').val();
        if(str == '' || str == null || str == ' '){
            errors += "Please select a start date<br/>";
            $return_type = false;
        }
        //Purpose of visit
        if($('#purpose').length){
            var purpose = $('#purpose').val();
            if(purpose == null){
                errors += "Please select Purpose of Visit<br/>";
                $return_type = false;
            }
        }
        if(errors != ""){
            title = 'Errors : ';
            common.overlay_rem(); 
            swal(errors);
        }else {
            set_proposal_data(fields);
        }
        return $return_type;

    }
    
    if(id === 'academic_details'){
        // University Name 
        var hname = $('#university_name').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "University Name should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9.&'[\](\), -]+$/i)){ 
            errors += "Invalid University Name<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9.&'[\](\), -]{1,35}$/i)){
            errors += "University Name should be with in 35 characters<br/>";
            $return_type = false;
        }

        // Program Name
        var hname = $('#program_name').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Program Name should not be empty<br/>";
            $return_type = false;
        }

        // Program Duration
        var hname = $('#program_duration').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Program Duration should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[0-9 ]+ [a-zA-Z]+$/i)){ 
            errors += "Invalid Program Duration<br/>";
            $return_type = false;
        }

        // University Address
        var hname = $('#university_address').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "University Address should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9_./\\:#(\), -]+$/i)){ 
            errors += "Invalid University Address<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z0-9_./\\:#(\), -]{1,35}$/i)){
            errors += "University Address should be with in 35 characters<br/>";
            $return_type = false;
        }

        // Country
        var hname = $('#university_country').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Country should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z ]+$/i)){ 
            errors += "Invalid Country<br/>";
            $return_type = false;
        }

        //State
        var hname = $('#university_state').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "State should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z ]+$/i)){ 
            errors += "Invalid State<br/>";
            $return_type = false;
        }

        //City
        var hname = $('#university_city').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "City should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z ]+$/i)){ 
            errors += "Invalid City<br/>";
            $return_type = false;
        }

        // Sponser Name
        var hname = $('#sponser_name').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Sponser Name should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z ]+$/i)){ 
            errors += "Invalid Sponser Name<br/>";
            $return_type = false;
        }
        
        // Sponser DOB
        var hname = $('#sponser_dob').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Please select Sponser DOB<br/>";
            $return_type = false;
        }

        // Sponser Relationship
        var hname = $('#sponser_relationship').val();
        if(hname == '' || hname == null || hname == ' '){
            errors += "Sponser Relationship should not be empty<br/>";
            $return_type = false;
        }else if(!hname.match(/^[a-zA-Z ]+$/i)){ 
            errors += "Invalid Sponser Relationship<br/>";
            $return_type = false;
        }

        if(errors != ""){
            title = 'Errors : ';
            common.overlay_rem(); 
            swal(errors);
        }else {
            set_proposal_data(fields); // In travel/policy/common.js
        }

        return $return_type;

    }

    if(id === 'medical_his'){
        $return_type = true;
        errors = validate_ped();
        if(errors != ""){
            title = 'Errors : ';
            common.overlay_rem(); 
            swal(errors);
        }else {
            set_proposal_data(fields); // In travel/policy/common.js
        }

        return $return_type;

    }
    
    if(id === 'review'){
        return true;
    }
    
}