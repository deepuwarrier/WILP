$(document).ready(function() {
    $(function() {
        // For Updating the Sum Insured Value in Quotation Page
        // This button will increment the value
        $('.upqtyplus').click(function(e) {
            // Stop acting like a button
            e.preventDefault();
            // Get its current value
            var currentVal = parseInt($('#sum_insured_box').val());
            var triptype = $('#tripcheck').val();
            var destination = $('#area').val();
            var url = $('#map_si_url').val();
            // If is not undefined
            if (!isNaN(currentVal)) {
                $.ajax({
                    url: url,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
                    },
                    type: 'POST',
                    data: {
                        'type': triptype,
                        'area': destination,
                        'si': currentVal,
                        'ctrl': 'up'
                    },
                    success: function(response) {
                        console.log($.trim(response));
                        $('#sum_insured_box').val($.trim(response));
                    }
                });
            }
        });

        // This button will decrement the value till 25000
        $(".upqtyminus").click(function(e) {
            // Stop acting like a button
            e.preventDefault();
            // Get its current value
            var currentVal = parseInt($('#sum_insured_box').val());
            var triptype = $('#tripcheck').val();
            var destination = $('#area').val();
            var url = $('#map_si_url').val();
            // If it isn't undefined or its greater than 0
            if (!isNaN(currentVal) && currentVal > 0) {
                $.ajax({
                    url: url,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content')
                    },
                    type: 'POST',
                    data: {
                        'type': triptype,
                        'area': destination,
                        'si': currentVal,
                        'ctrl': 'down'
                    },
                    success: function(response) {
                        console.log($.trim(response));
                        $('#sum_insured_box').val($.trim(response));
                    }
                });
            }
        });


        // To show Updating Message to user
        $("#update-si-btn").click(function(e) {
            common.loader_msg(common.msg['updated_quote']);
            $('#update-si').submit();
        });

        // To show Updating Message to user
        $(document).on('click', '.buy-btn', function(e) {
            common.loader_msg(common.msg['submit_form']);
            var id = $(this).attr('data-item');
            var policy_id = $(this).attr('data-key');
            var url = $('#save_policyid').val();
            $.get(url, {
               policy_id : policy_id
            }, function(data, status) {     
              	$('#buy-policy-' + id).submit();
            });
        });

        // Loader show with message
        function loader_msg(msg) {
            //self.overlay_msg();
            $('#overlay').html("<span class='msg'>" + msg + "<span>");
            $('#overlay').fadeIn();
            $('#overlay').css("opacity", 1);
            $('#overlay').append('<div class="loader">Loading...</div>');
        }



    });

    $(document).on('click', 'a[id^="benefits"]', function(e) {
        common.loader_msg(common.msg['submit_form']);
        e.preventDefault();
        plan_code = $(this).attr('plan-code'); 
        policy_id = $(this).attr('quote-id');
        url = $(this).attr('data-url');
        $.get(
            url, {
                'code': plan_code,
                'policy_id': policy_id
            },
            function(data) {
                common.loader_rem();
                $('#BenefitModal').html(data);
                $('#BenefitModal').modal('show');

            }
        );

    }); 


    $(document).on('click', 'a[id^="breakup"]', function(e) {
        common.loader_msg(common.msg['submit_form']);
        e.preventDefault();
        plan_code = $(this).attr('plan-code'); 
        policy_id = $(this).attr('quote-id');
        url = $(this).attr('data-url');
        $.get(
            url, {
                'code': plan_code,
                'policy_id': policy_id
            },
            function(data) {
                common.loader_rem();
                $('#premiumBreakup').html(data);
                $('#premiumBreakup').modal('show');

            }
        );

    });

    $(document).on('click', '.filter_quote', function(e) {
        common.initQuote();
        var chks = "";
        $(".filter_quote").each(function() {
            if (this.checked) {
                var cd = $(this).val();
                chks += cd + ",";
            }
        });
        
        $("#tata_quote_ctnr_box").html('');
        $("#star_quote_ctnr_box").html('');
        $("#religare_quote_ctnr_box").html('');
        $("#hdfc_quote_ctnr_box").html('');
        
        $("#tata_quote_ctnr_box").append("<span id='tata_loader'></span>");
        common.loader("#tata_loader");
        chks = $.trim(chks);
        url = $('#filter_req').val();
        $.get(url,{
        	   chks : chks
        }, function(data, status) { 
           	$("#tata_loader").remove();
            $("#quote_ctnr_box").html('');
          	$("#tata_quote_ctnr_box").html(data);
          	$("#star_quote_ctnr_box").html('');
          	$("#hdfc_quote_ctnr_box").html('');
          	$("#religare_quote_ctnr_box").html('');
            sort_div();
        });

    }); // End of the filter_quote on click function 

});

// Loading the travel_quotes
function load_quotes(){
    common.initQuote();
    load_hdfc_quotes();
    load_tata_quotes();
    load_star_quotes();
    load_religare_quotes();
    load_fggi_quotes();
} 

function load_tata_quotes(){
    $("#tata_quote_ctnr_box").append("<span id='tata_loader'></span>");
    common.loader("#tata_loader");
    $.get(APP_URL + "/travel-insurance/load_tata_quotes", {
    }, function(data, status) {     
        common.loader_rem();
        $("#load_quote_box").html('');
        $("#tata_loader").remove();
        load_covers('tata');
        if(data!=null){
            $("#tata_quote_ctnr_box").html(data);
        }
        sort_div();
    });
}

function load_fggi_quotes(){
    $("#fggi_quote_ctnr_box").append("<span id='fggi_loader'></span>");
    common.loader("#fggi_loader");
    $.get(APP_URL + "/travel-insurance/load_fggi_quotes", {
    }, function(data, status) {     
        common.loader_rem();
        $("#load_quote_box").html('');
        $("#fggi_loader").remove();
        load_covers('tata');
        if(data!=null){
            $("#fggi_quote_ctnr_box").html(data);
        }
        sort_div();
    });
}

function load_hdfc_quotes(){
    $("#hdfc_quote_ctnr_box").append("<span id='hdfc_loader'></span>");
    common.loader("#hdfc_loader");
    $.get(APP_URL + "/travel-insurance/load_hdfc_quotes", {
    }, function(data, status) {     
        common.loader_rem();
        $("#load_quote_box").html('');
        $("#hdfc_loader").remove();
        load_covers('hdfc');
        if(data!=null){
            $("#hdfc_quote_ctnr_box").html(data);
        }
        sort_div();
    });
}

function load_star_quotes(){
    $("#star_quote_ctnr_box").append("<span id='star_loader'></span>");
    common.loader("#star_loader");
    $.get(APP_URL + "/travel-insurance/load_star_quotes", {
    }, function(data, status) {     
        common.loader_rem();
        $("#load_quote_box").html('');
        $("#star_loader").remove();
        load_covers('star');
        if(data!=null){
            $("#star_quote_ctnr_box").html(data);
        }
        sort_div();
    });
}

function load_religare_quotes(){
    $("#religare_quote_ctnr_box").append("<span id='religare_loader'></span>");
    common.loader("#religare_loader");
    $.get(APP_URL + "/travel-insurance/load_religare_quotes", {
    }, function(data, status) { 
        common.loader_rem();
        $("#load_quote_box").html('');
        $("#religare_loader").remove();
        load_covers('religare');
        if(data!=null){	
            $("#religare_quote_ctnr_box").html(data);
        }
        sort_div();
    });
}

function load_covers(company){
    $("#cover_box").append("<span id='cover_loader'></span>");
    common.loader("#cover_loader");
    $.get(APP_URL + "/travel-insurance/load_covers", {
    	  company : company
    }, function(data, status) { 
        common.loader_rem();
        $("#cover_loader").remove();
        if(data!=0){
            $("#cover_box").html(data);
        }
    });
}

function sort_div(){
    //check_quote_reponse();
    var divList = $(".quote-box");
    divList.sort(function(a, b){ return $(a).data("listing-price")-$(b).data("listing-price")});
    $("#quote_ctnr_box").html(divList);

    var noQuotes = $(".no_quotes_box");
    noQuotes.each(function(key,value){
      $("#no_quotes").append(value);
    });

    if(noQuotes.length > 0){
      $("#no_quote_text").show();
      $("#no_quote_text").removeClass("hidden");
    }
}

function check_quote_reponse(){
    religare_quote = $("#religare_quote_ctnr_box").text().trim();
    tata_quote = $("#tata_quote_ctnr_box").text().trim();
    hdfc_quote = $("#hdfc_quote_ctnr_box").text().trim();
    star_quote = $("#star_quote_ctnr_box").text().trim();
    fggi_quote = $("#fggi_quote_ctnr_box").text().trim();
    
    if(hdfc_quote == '' && 
       religare_quote == '' && 
       tata_quote == '' && 
       star_quote == '' && 
       fggi_quote == ''){
       $("#load_quote_box").html('<h5 class="card-title price"> -- No Quotes generated for your Request -- </h5>');
    }
}

