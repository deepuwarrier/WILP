$("#cust_dob").datepicker({
dateFormat: "dd-M-yy",
changeMonth: !0,
changeYear: !0,
minDate: $("#cust_dob").attr("data-minYear"),
maxDate: $("#cust_dob").attr("data-maxYear"),
yearRange: "-90:+1"
});

$("#proposer_store").click(function() {    store_proposal_data ();
//	$.ajax({	 url:store_proposal_data(), success:function(){	 retrive_proposal_data();	}	})
});	
$("#address_store").click(function() {     store_proposal_data ();
	// $.ajax({	 url:store_proposal_data(), success:function(){	 retrive_proposal_data();	}	})
});	
$("#vehicle_store").click(function() {    store_proposal_data ();
	//$.ajax({	 url:store_proposal_data(), success:function(){	 retrive_proposal_data();	}	})
});	
$("#preinsurer_store").click(function() {    store_proposal_data ();
	//$.ajax({	 url:store_proposal_data(), success:function(){	 retrive_proposal_data();	}	})
});	

function store_proposal_data () {
	
	$.get("/tw/store_proposal_data", {
		tw_trans_code : $("#tw_trans_code").val(),
		owner_type : $("#Individual").val() || "I",
		gender : $("#val_radio_male").is(":checked") == true ? "M" : "F",
		cus_dob : $("#cust_dob").val() || "",
		cust_name : $("#cust_name").val() || "",
		email_id : $("#customer_email").val() || "",
		mobile_no : $("#mobile").val() || "",
		aadhar_no : $("#aadhar_no").val() || "" ,
		
		houseno : $("#houseno").val() || "",
		street : $("#street").val() || "",
		locality : $("#locality").val() || "",
		state : $("#state").val() || "",
		city : $("#city").val() || "",
		pincode : $("#pincode").val() || "",
		
		twregno : $("#tw_reg_no").val() ,
		eng_no : $("#eng_no").val() || "",
		chassis_no : $("#chassis_no").val() || "",
		electrical : $("#eleacc").val() || "",
		non_electrical : $("#non_eleacc").val() || "",
		yom_selected : $("#yom_selected").val() || "",
		color : $("#color").val() || "",
		
		previnsurance : $("#previnsurance").val()  || "",
		policyno : $("#policyno").val() || "",
		nomineeName : $("#nomineeName").val() || "",
		nomi_age : $("#nomi_age").val() || "",
		nomineeRel : $("#nomineeRel").val() || ""
	}, function(data, status) {		});
	
}


function retrive_proposal_data() {
	$.get("/tw/retrive_proposal_data", {	
		tw_trans_code : $("#tw_trans_code").val()	
	},  function(data, status) {	  
		
		 $("#Individual").val( data['owner_type'] ) ;
		 if(data['proposer_gender']  == "M"){
			 $("#val_radio_male").prop('checked', true);  
		 } else  if(data['proposer_gender']  == "F"){
			 $("#val_radio_female").prop('checked', true);  
		 }
		 
		 $("#cust_dob").val( data['proposer_dob'] ) ;
		 $("#cust_name").val( data['proposer_name'] ) ;
		 $("#customer_email").val( data['proposer_email'] ) ;
		 $("#mobile").val( data['proposer_mobile'] ) ;
		 $("#aadhar_no").val( data['proposer_aadharno'] ) ;
		
		 $("#houseno").val( data['proposer_addr1'] ) ;
		 $("#street").val( data['proposer_addr2'] ) ;
		 $("#locality").val( data['proposer_addr3'] ) ;
		 $("#state").val( data['proposer_state_code'] ) ;
		 $("#state").trigger('change');
		
		 $("#pincode").val( data['proposer_pincode'] ) ;
		 load_onpage_cities( data['proposer_city_code'] );
		 $("#city").trigger('change');
		
		 if(data['tw_reg_no'] == null || data['tw_reg_no'] == ""){
			 var rto_code_raw = data['rto_code'];
			 $("#tw_reg_no").val( rto_code_raw.slice(0, 2) + "-" + rto_code_raw.slice(2) +"-" ) ;
		 }else{ $("#tw_reg_no").val( data['tw_reg_no'] ) ;	}
			 
		
		 
		 $("#eng_no").val( data['tw_engine_no'] ) ;
		 $("#chassis_no").val( data['tw_chassis_no'] ) ;
		 $("#electrical").val( data['eleacc'] ) ;
		 $("#non_electrical").val( data['non_eleacc'] ) ;
		 $("#yom_selected").val( data['yom'] ) ;
		 $("#color").val( data['color'] ) ;
		
		 $("#previnsurance").val( data['pre_insurer_code'] ) ;
		 $("#previnsurance").trigger('change');
		 $("#policyno").val( data['pre_policy_number'] ) ;
		 $("#nomineeName").val( data['nomi_name'] ) ;
		 $("#nomineeRel").val( data['nomi_rel_code'] ) ; $("#nomineeRel").trigger('change');
		 $("#nomi_age").val( data['nomi_age'] ) ;  $("#nomi_age").trigger('change');
	});
}

function strt_proposal_data() {
	store_proposal_data(); 
	//retrive_proposal_data(); 
	set_ppd();
}


$("#review").click(function() {  set_ppd();	});	
$("#preinsurer_store").click(function() {  set_ppd();	});	

function set_ppd() {  
	$("#p_Individual").text( $("#Individual").attr('data-name') || "" );
	$("#p_gender_group").text(  $("#gender_group input[type='radio']:checked").attr('data-name') || "" );
	$("#p_cust_dob").text( $("#cust_dob").val() || "" );
	$("#p_cust_name").text( $("#cust_name").val() || "" );
	$("#p_customer_email").text( $("#customer_email").val() || "" );
	$("#p_mobile").text( $("#mobile").val() || "" );
	$("#p_aadhar_no").text( $("#aadhar_no").val() || "" );
	
	$("#p_houseno").text( $("#houseno").val() || "" );
	$("#p_street").text( $("#street").val() || "" );
	$("#p_locality").text( $("#locality").val() || "" );
	$("#p_state").text( $('#state option:selected').attr('data-name')  || "" );
	$("#p_city").text( $('#city option:selected').attr('data-name') || "" ); 
	$("#p_pincode").text( $("#pincode").val() || "" ); 

	$("#p_reg_number").text( $("#tw_reg_no").val()); 
	$("#p_eng_no").text( $("#eng_no").val() || "" );
	$("#p_chassis_no").text( $("#chassis_no").val() || "" );
	$("#p_electrical").text( $("#eleacc").val() || "" );
	$("#p_non_electrical").text($("#non_eleacc").val() || "" );
	$("#p_yom_selected").text( $("#yom_selected").val() || "" );
	$("#p_color").text( $("#color").val() || "" );
	
	$("#p_previnsurance").text( $('#previnsurance option:selected').attr('data-name')   || "" ); 
	$("#p_policyno").text( $("#policyno").val() || "" );
	$("#p_nomineeName").text( $("#nomineeName").val() || "" );
	$("#p_nomineeRel").text(  $('#nomineeRel option:selected').attr('data-name') || "" );
	$("#p_nomi_age").text(  $("#nomi_age").val() || "" );
}


$("#tw-btn-pay").click(function() {
    if ($("#disclaimer").is(':checked')) {
        common.loader_msg("Connecting to Proposal Server.. Please wait ...");
        $.get("/tw/uiic_proposal_submit", {
            tw_trans_code: $("#tw_trans_code").val()
        }, function(data, status) {
           
            if (data["resp_flag"] == "verror") {
                sweetAlert(data["verror_txt"]);
                common.loader_rem();
            } else {
                common.loader_msg(data);
            }

        });
    } else {
        $("#tnc_box").effect("shake");
    }
});



$("#overlay").on("click", "#review-again", function() {   	common.loader_rem();  	});

$("#overlay").on("click", "#payment_submit", function() {   
	//go to payment submit controller
	$.get("/tw/submit_uiic_payment", {
		tw_trans_code : $("#tw_trans_code").val()
	}, function(data, status) {	 
		common.loader_rem();
		redirect_to_payment( data ); 		
	 
//     common.loader_msg("Redirecting to payment gateway.. Please wait ...");	 		
	});
	
});

function pm_submit_payment ( agreed_premium )  {  
	$.get("/tw/pm_submit_uiic_payment",  {
		tw_trans_code : $("#tw_trans_code").val(),
		agreed_premium : agreed_premium
	}, function(data, status) {	  
		common.loader_rem(); //common.loader_msg("Redirecting to payment gateway.. Please wait ..."); 
		redirect_to_payment( data );
	});
}


function redirect_to_payment (data) {
	var pay_form = '<form id="payment" name="uiic_payment" method="POST" action="https://pgi.billdesk.com/pgidsk/PGIMerchantPayment">';
//	var pay_form = '<form id="payment" name="uiic_payment" method="POST" action="http://sandbox.instainsure.com/PG/BillDeskPG.php">';
    pay_form += "<input  class='hidden' type='hidden' name='msg' value ='"+data+"'/>";
    pay_form += "<input  class='hidden' type='Submit' value ='Submit' id='submit_uiic_payment'/>";
    pay_form += "</form>";	 		
    $("body").append(pay_form);  
    $('#submit_uiic_payment').click();
	
};


if (typeof validate_lib != 'undefined') {
	form_field = {
		mobile: "mobile",
		cust_dob: "dob_dash_fmt",
		cust_name: "cust_name",
		nomineeName: "cust_name",
		customer_email: "email",
		aadhar_no: "aadhar_no",
		houseno: "houseno",
		street: "street",
		locality: "locality",
		pincode: "pincode",
		statecode: "required",
		citycode: "required",
		tw_reg_no:"tw_reg_no",
		eng_no: "tw_engno",
		chassis_no: "tw_chassisno",
		color: "color",
		policyno: "tw_policyno",
		nomi_age:"required",
		nomineeRel:"required",
		previnsurance:"required"
	};
	form_id = 'buy_policy_form';
    validate_lib.applyValidation(form_id,form_field)
} else {
	console.error("import validator_lib.js for validation");
}
