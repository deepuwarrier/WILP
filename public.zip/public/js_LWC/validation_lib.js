validate_lib = {
	vl_self:this,
	vali_sel: {},
	format : {
		// FW RULES
		string : "^[a-zA-Z]+$",
		str_sp: "^[a-zA-Z ]+$",
		number : "^\\d+$",
		alphanumerical: "^([\\d]*[a-zA-Z]*)+$",
		alphanumericalwithslash: "^([\\d]*[a-zA-Z/\]*)+$",
		alpha_slash_dash: "^([\\da-zA-Z/\][-]*)+$",
		alpha_dash: "^([\\da-zA-Z/\]*)+$",
		alpha:"^([\\dA-Za-z\\s])+$",
		// daterequired:true ,regex:"^[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}$",
		name:"^([a-zA-Z]*[ ]*)+$",
		fullname: "^(([a-zA-Z]{0,14}).(\\s[a-zA-Z]{3,14}){1,2})|([a-zA-Z]{2,14}).(\\s[a-zA-Z]{0,14}){1,2}$",//"^([a-zA-Z]{0,14}).(\\s[a-zA-Z]{2,14}){1,2}$",
		dateformatydd_mmm_yy: "^[0-9]{1,2}-[a-zA-Z-z]*-[0-9]{4}$",
		regno: "^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$",
		pincode:"^[1-9][0-9]{5}$",
		gstin: "^\\d{2}[a-zA-Z]{5}\\d{4}[a-zA-Z]{1}\\d[zZ]{1}[a-zA-Z\\d]{1}$",
		// TW RULES
		cust_name: 	"^[a-zA-Z]{3,18}[ ][a-zA-Z]{1,18}$",
		cust_dob: 	"^[0-9]{2}[-][a-zA-Z]{3}[-][0-9]{4}$",
		tcust_dob: 	"^[0-9]{2}[-][0-9]{2}[-][0-9]{4}$",       
    	aadhar_no: 	"^[0-9]{4}[-][0-9]{4}[-][0-9]{4}$",       
    	pan_no: 	"^[a-zA-Z0-9]{10}$",       
   		houseno: 	"^[a-zA-Z0-9 /]{2,15}$" ,
    	street: 	"^[a-zA-Z0-9 ]{5,40}$" ,
    	locality: 	"^[a-zA-Z0-9 ]{5,40}$" ,
    	pincode: 	"^[0-9]{6}$" ,
    	tw_reg_no: 	"^[a-zA-Z]{2}[-][0-9]{2}[-][a-zA-Z]{1,2}[-][0-9]{4}$" ,
    	eng_no: 	"^[a-zA-Z0-9]{8,30}$" ,
    	chassis_no: "^[a-zA-Z0-9]{10,40}$" ,
    	color: 		 "^[a-zA-Z ]{3,15}$" ,
    	policyno: 	"^[a-zA-Z0-9 /-]{8,30}$" ,
    	rsgi_preinsur_addr: "^[a-zA-Z0-9 /]{8,30}$" ,
    	claim_count: "^[1-9]$",
    	//Health Ruels
    	cust_dob_dash_d_m_y: "^[0-9]{2}[-][0-9]{2}[-][0-9]{4}$",
    	university_name: "^[a-zA-Z0-9.&'[\\](\\), -]+$",
    	program_dur: "^[0-9 ]+ [a-zA-Z]+$",
    	uni_addr:"^[a-zA-Z0-9_./\\:#(\), -]+$",
	},	
        
    mesages : {
    	firstname: "firstname is required",
    	mobile: "check mobile number is limeted to 10",
    	dob_dash_fmt: "Please enter date of birth ex:02-JUN-1991",
    	cust_name: { regex: "Valid first name, last name required."},
    	aadhar_no: { regex: "Aadhar format is wrong."},
    	tw_reg_no: { regex: "Reg number format is wrong."},
    	nomineeName: { regex: "Valid first name, last name required."},
    	pre_claim_count: { regex: "Min 1 max 9 claims allowed."},
    	rsgi_preinsur_addr: { regex: "Fill address min 8 max 30 char."},
    },

    getSelectorName: function(form_id,hidden=true){
    	var sel = 'hidden';
		var unsel = 'visible';
		
		if(hidden){
			sel = 'visible';
			unsel = 'hidden';
		}
		
		curr_selector = sel+'_'+form_id;
		prev_selector = unsel+'_'+form_id;

		return {curr_selector:curr_selector,
				prev_selector:prev_selector};
    },

    getErrorList: function(form_id,hidden=true){
    	errorList = {};
    	error = {};

    	selector = vl_self.getSelectorName(form_id,hidden);
    	
    	if(selector.curr_selector in vl_self.vali_sel)
    		errorList = vl_self.vali_sel[selector.curr_selector].errorList
		
		$.each(errorList,function(k,v){
			e = {name:'',message:''};
			if($(v.element).data('name') != 'undefined')
				e.name = $(v.element).data('name')
			else
				e.name = $(v.element).attr('name')
			e.message = v.message;
			error[k] = e;			
		})    	
		
		return error;
    },

	applyValidation: function(form_id,validation_rule,hidden=true){
		var ignore = ".col-sm-4.hidden :input";
		var rules = {};
		var mesages = {};
		
		$.each(validation_rule,function(key,value){
			if (value in vl_self.rules)
				rules[key] = vl_self.rules[value];
		})

		$.each(validation_rule,function(key,value){
			if (value in vl_self.mesages)
				mesages[key] = vl_self.mesages[value];
		})
		
		if(hidden)
			ignore = ":hidden";

		selector = vl_self.getSelectorName(form_id,hidden);

		if(selector.prev_selector in vl_self.vali_sel)
			vl_self.vali_sel[selector.prev_selector].destroy();

			vl_self.vali_sel[selector.curr_selector] = $("#"+form_id).validate({
			ignore : ignore,
			onfocusout: function(element) { $(element).valid(); },
			onfocusin: function(element) { $(element).valid(); },
			onkeyup: function(element) { $(element).valid(); },
			submitHandler: function() { alert("Submitted!") },
			rules: rules,
			messages: mesages
		    // errorPlacement: function (error, element) {
		    //     $(element).parent('div').addClass('has-error')
		    // }
		});
	},

	addFormGrpReq: function(arr){
		$.each(arr,function(key,val){
			$.validator.addClassRules(val, {
		  		require_from_group: [1, "."+val]
			});	
		})
	},
	
	isValidate: function(form_id){		
		return $('#'+form_id).valid();
	},

	init: function(){
		vl_self = this;

		vl_self.rules = {	firstname:{ 
					required:true,
					regex: this.format.string },
				lastname:{ 
					required:true,
					regex: this.format.string },
				mobile:{ 
					required:true,
					regex: this.format.number,
					minlength:10
				},
				aadhar:{ 
					required:true,
					regex: this.format.number,
					minlength: 12,
					maxlength: 12
				},
				aadhar_no:{
					required:true,
					regex: this.format.aadhar_no
				},
				dob_dash_fmt:{
					required:true,
					regex: this.format.cust_dob
				},
				cust_dob_dash_d_m_y:{
					required:true,
					regex: this.format.cust_dob_dash_d_m_y
				},
				cust_dob:{ 
					required:true,
					regex: this.format.dateformat
				},
				tcust_dob:{
					required:true,
					regex: this.format.tcust_dob	
				},
				tw_cust_dob: { 
					required:true,
					regex: this.format.dateformatydd_mmm_yy
				},
				email:{ 
					required: true,
					email: true
				},
				pan:{ 
					required:true,
					regex: this.format.alphanumerical
				},
				financierName: {
					required:true,
					regex: this.format.name
				},
				nomineeRel : {
					required:true ,
					regex: this.format.name
				},
				nomineeAge : {
					required:true ,
					regex: this.format.number,
					maxlength: 3
				},
				pincode:{
					required:true ,
					regex:this.format.pincode,
					minlength: 6,
					maxlength: 6
					},
				regno: {
					required:true,
					regex: this.format.regno},
				tw_reg_no: {
					required:true,
					regex: this.format.tw_reg_no
				},
				engno: {
					required:true,
					regex: this.format.alphanumerical,
					minlength: 6,
					maxlength: 30},
				tw_engno: {
					required:true,
					regex: this.format.alphanumerical,
					minlength: 8,
					maxlength: 30},
				chassisno: {
					required:true,
					regex: this.format.alphanumerical,
					minlength: 6,
					maxlength: 30},
				tw_chassisno: {
					required:true,
					regex: this.format.alphanumerical,
					minlength: 10,
					maxlength: 40},
				color: {
					required:true,
					regex:this.format.name,
					minlength: 3,
					maxlength: 15
				},
				policyno: {
					required:true ,
					regex: this.format.alpha_slash_dash},
				tw_policyno:{
					required:true ,
					regex: this.format.alpha_slash_dash,
					minlength: 8,
					maxlength: 30
				},
				driver_dob: { 
					required:true,
					regex: this.format.dateformat},
	    		noOfAccidents: { 
	    			required:true,
	    			regex: this.format.number},
	    		currentMillage: {
	    			required:true ,
	    			regex:this.format.number},
	    		nomineeName: {
	    			required:true ,
	    			regex:this.format.fullname},
	    		amount : {	
	    			required:true,
	    			regex:this.format.number},
	    		gstin: { 
	    			required:true ,
	    			regex: this.format.gstin,
	    			minlength: 15,
	    			maxlength: 15},
	    		fullname: { 
	    			required:true,
	    			regex: this.format.fullname},
	    		cust_name: {
	    			required:true,
	    			regex: this.format.cust_name
	    		},
      			houseno: {
      				required:true,
      				regex: this.format.alpha,
      				minlength:2,
      				maxlength:15
      			},
      			street: {
      				required:true ,
      				regex: this.format.alpha,
      				minlength:5,
      				maxlength:40
      			},
      			locality: {
      				required:true,
      				regex: this.format.alpha,
      				minlength:5,
      				maxlength:40
      			},
      			cmp_name: {
      				required:true,
      				regex: this.format.alpha,
      			},
      			required: {
      				required:true
      			},
      			pre_addr:{
      				required: true,
      				 regex: this.format.alpha_dash,
      				 minlength: 8,
      				 maxlength: 30
      			},
      			claim_count:{
					required: true,
					regex: this.format.claim_count,
					minlength: 1,
					maxlength: 1	
      			},
      			claim_amount:{
					required: true,
					regex: this.format.number,
					minlength: 2,
					maxlength: 7	
      			},
      			weight: {
      				required: true,
					regex: this.format.number,
					minlength: 1,
					maxlength: 3,
					max: 125
      			},
      			passport: {
      				required: true,
					regex: this.format.alphanumerical,
					minlength: 6,
					maxlength: 8,
      			},
      			university_name:{
      				required: true,
					regex: this.format.university_name,
					minlength: 1,
					maxlength: 35,	
      			},
      			program_dur:{
      				required: true,
					regex: this.format.program_dur
      			},
      			uni_addr:{
      				required: true,
					regex: this.format.uni_addr,
					minlength: 1,
					maxlength: 70,		
      			},
      			str_sp:{
      				required: true,
					regex: this.format.str_sp,
      			}
      			


      		// 	rsgi_no_age : {  
        //      numericality: {
        //        onlyInteger: true,
        //        greaterThan: 17,
        //        lessThanOrEqualTo: 115,               
        //      }
           
        // }
    	}

		$.validator.addMethod("regex"
			,function(value, element, regexp) {
        		var re = new RegExp(regexp);
        		return this.optional(element) || re.test(value);
    		},
    		"Invalid Input. Please correct."
		);

		frm_grp_req = ["illness_require","cate_insured"]

		$.each(frm_grp_req,function(key,val){
			$.validator.addClassRules(val, {
		  		require_from_group: [1, "."+val]
			});	
		})

		$.validator.addClassRules("level", {
			required: true,
			regex: this.format.number,
			minlength: 1,
			maxlength: 3
		});

		$.validator.addClassRules("insulin", {
			required: true,
			regex: this.format.number,
			minlength: 1,
			maxlength: 2
		});
		
	}
}	
validate_lib.init();