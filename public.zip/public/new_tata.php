<?php
date_default_timezone_set('Asia/Kolkata');


?>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title></title>
	<script
  src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" src="https://yckart.github.io/jquery.base64.js/jquery.base64.js"></script>
</head>
<body>

<form name="submit_payment" id="submit_payment" method="POST" action="https://pay.tataaig.com/PaymentGatewayAggr/_tataaig_payment_net"> <br>
 

<table>
	<tr>
		<td>
			lob
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="lob" id="lob" value="2">
		</td>
	</tr>
	<tr>
		<td>
			currencyCode
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="currencyCode" id="currencyCode" value="INR">
		</td>
	</tr>
	<tr>
		<td>
			reqID
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="reqID" id="reqID" value="PGI1000001">
		</td>
	</tr>
	<tr>
		<td>
			sourceReturnUrl
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="sourceReturnUrl" id="sourceReturnUrl" value="http://instainsure.com/status.php">
		</td>
	</tr>
	<tr>
		<td>
			policyNumber
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="policyNumber" id="policyNumber" value="PHP/3121/0000001348">
		</td>
	</tr>
	<tr>
		<td>
			transTimeStamp
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="transTimeStamp" id="transTimeStamp" value="<?php echo date("d-m-Y H:m:s").'.000'?>">
		</td>
	</tr>
	<tr>
		<td>
			paymentType
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="paymentType" id="paymentType" value="1">
		</td>
	</tr>
	<tr>
		<td>
			portalName
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="portalName" id="portalName" value="4">
		</td>
	</tr>
	<tr>
		<td>
			businessType
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="businessType" id="businessType" value="1002">
		</td>
	</tr>
	<tr>
		<td>
			paymentAmount
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="paymentAmount" id="paymentAmount" value="1">
		</td>
	</tr>
	<tr>
		<td>
			productCode
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="productCode" id="productCode" value="1004">
		</td>
	</tr>
	<tr>
		<td>
			directPayment
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="directPayment" id="directPayment" value="N">
		</td>
	</tr>
	<tr>
		<td>
			paymentAppId
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="paymentAppId" id="paymentAppId" value="4">
		</td>
	</tr>
	<tr>
		<td>
			consumer_app_ID
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="consumer_app_ID" id="consumer_app_ID" value="TTIB01">
		</td>
	</tr>
	<tr>
		<td>
			transactionID
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="transactionID" id="transactionID" value="1698159287">
		</td>
	</tr>
	<tr>
		<td>
			additionalInfo1
		</td>
		<td style="padding-left: 120px;">
			<input type="test" name="additionalInfo1" id="additionalInfo1" value="">
		</td>
	</tr>
	<tr>
		<td colspan="2" style="padding-left: 120px;"><input type="button" id="sbumit_primary" name="Submit" value="Submit"></td>
	</tr>
</table>
<!-- Encrypted String: <input  name="pgirequest" type="text" value="<?php echo $str;?>" /> <br>

<input id="submit_form" type="submit" value="submit" /> -->
</form>

<form style="" name="submit_paymenthidden" id="submit_paymenthidden" method="POST" action="https://pay.tataaig.com/PaymentGatewayAggr/_tataaig_payment_net">
    
Json Data <textarea id="json_text" col="90" rows="5"></textarea>    
    <br><br>
    
    
pgiRequest : 	<input type="input" name="pgiRequest" id="pgirequest" value="" size="180">
	<!-- <input type="submit" name=""> -->
</form>


<script type="text/javascript">
	

	$("#action_url").on('change',function() {
		form_url = $('#action_url').val();
		$('#submit_paymenthidden').attr('action',form_url);
	});
	$('#sbumit_primary').on('click',function(){
		$.base64.utf8encode = true;
		var data= {};
		$.each($("#submit_payment").serializeArray(),function( index, element ) {
			data[element.name] = element.value;
		});
		var str = JSON.stringify(data);
		
		$("#json_text").html(str);
		
		
		var request = $.base64.btoa(str);
		$('#pgirequest').val(request);
	  if(confirm("Press a button!\n Click OK -  for PG submit \n or \n Cancel -  see & copy encripted content.")) {	$('#submit_paymenthidden').submit(); }
	});
</script>
</body>
</html>