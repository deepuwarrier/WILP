<?php
if(!empty($_POST)){
	print_r($_POST);
} else if(!empty($_GET)){
	print_r($_GET);
} else {
	echo "Request does not have any value in GET or POST method.";
}

?>