@include('layouts.header')
<div class="wizard-container">
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{URL::asset('image/404.gif')}}" alt="Error" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h1> 404 Error </h1>
         <h4 class="card-title" style="color: #00669C;">Sorry.. We are not able to find what you are looking for</h4>
         <h5> Let us take you back home.</h5>
        <button type="submit" class="btn btn-success" onclick="goBack()">Go Back</button>
      </div>
   </div>
</div>
<br><br>
<hr>
@include('layouts.footer')

<script>
function goBack() { 
    window.history.back();
}
</script>
