@include('layouts.backend.header')
@include('layouts.backend.admin_menu')
<div class="container">
	 <section class="products_intro">
	 <div class="panel panel-default">
				<div class="panel-heading">
					<strong>Create Quote</strong>
                  			
				</div>
				<div class="panel-body">
				<div class="row" style="text-align: center;">
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/car-insurance" target="_blank">
                        <img src="{{URL::asset('image/car.svg')}}" width="40%" alt="Car Insurance">
                        <h4>Car<span> Insurance</span></h4>
                     </a>
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/two-wheeler-insurance" target="_blank">
                        <img src="{{URL::asset('image/bike.svg')}}" width="40%" alt="Two Wheeler Insurance">
                        <h4>Bike<span> Insurance</span></h4>
                     </a> 
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/health-insurance" target="_blank">
                        <img src="{{URL::asset('image/health.svg')}}" width="40%" alt="Health Insurance">
                        <h4>Health <span> Insurance</span></h4>
                     </a>
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/travel-insurance" target="_blank">
                        <img src="{{URL::asset('image/travel.svg')}}" width="40%" alt="Travel Insurance">
                        <h4>Travel<span> Insurance</span></h4>
                     </a>
                  </div>
               </div>  
				
				</div>
         </div>
	 
               
              
                      
    </section>         
 </div>
 

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>#Policy Count - Current Month</strong></div>
				<div class="panel-body"><canvas id="curr_mon_data"></canvas>	</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>#Policy Count - Current Month</strong></div>
				<div class="panel-body"><canvas id="curr_mon_ins_share"></canvas>	</div>
			</div>
		</div>
	</div>
</div>



@include('layouts.backend.footer')
<script src="{{URL::asset('js/admin/dashboard.js')}}" type="text/javascript"></script>
