<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>



                    <!-- Branding Image -->
                    <p class="navbar-brand"><a href="{{ URL::to('/adminpanel') }}">Home  </a> > <a href="{{ URL::to('/admin/product') }}"> Products List </a> > @if(isset($insta_product)) Update  <a style="text-decoration: none;">" {{ $insta_product['0']['product_name'] }} "</a> @else Add Product @endif</p>
                </div>

                <a class="nav navbar-nav navbar-right" href="{{ URL::to('/admin-logout') }}">
                          Logout
                    </a>
            </div>
        </nav>
@if (Session::has('message'))
   <div class="alert alert-info" style="text-align: center;color: red;" >{{ Session::get('message') }}</div>
@endif

        <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add Product</div>
                <div class="panel-body">
               
               <?php $selected_cat = isset($insta_product['0']['product_ctg_ref']) ? $insta_product['0']['product_ctg_ref'] : '' ; ?>    


            <form method="POST" class="form-horizontal" role="form" action="{{route('admin.store_product')}}" enctype="multipart/form-data"> {{ csrf_field() }}

            <input type="hidden" name="product_url" id="product_url" value="{{(isset($insta_product['0']['product_url'])) ? $insta_product['0']['product_url'] : ''}}">
            
                <div class="form-group">  
                    <label for="company" class="col-md-4 control-label">Insurance Company</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" id="company" name="insurance_company" value="{{(isset($insta_product['0']['company'])) ? $insta_product['0']['company'] : ''}}"  required>
                    </div>
                </div>
                 <div class="form-group">  
                    <label for="product_category" class="col-md-4 control-label">Product Category</label>
                    <div class="col-md-6">
                         <select data-md-selectize required data-live-search="true" name="product_category" id="product_category" class="form-control required show-info">
                            <option hidden="" selected="" disabled="" value="">Select Product 
                                    Category*</option>

                                @foreach($insta_category as $key => $value)
                                          <?php $selected = (isset($selected_cat) && $value['category_code'] == $selected_cat) ? 'selected' : ''?>
                                    <option {{$selected}} value="{{$value['category_code']}}"> {{$value['category_name']}} </option>
                                    @endforeach

                        </select>

                    </div>
                </div> 
                 <div class="form-group">  
                    <label for="product_code" class="col-md-4 control-label">Product Code</label>
                    <div class="col-md-6">
                        <input id="product_code" type="text" class="form-control" name="product_code"  value="{{(isset($insta_product['0']['product_code'])) ? $insta_product['0']['product_code'] : ''}}" required>
                    </div>
                </div> 

                <div class="form-group">  
                    <label for="product_name" class="col-md-4 control-label">Product Name</label>
                    <div class="col-md-6">
                        <input id="product_name" type="text" class="form-control" name="product_name" value="{{(isset($insta_product['0']['product_name'])) ? $insta_product['0']['product_name'] : ''}}" required>
                    </div>
                </div>
                <div class="form-group">  
                    <label for="product_url" class="col-md-4 control-label">Product URL</label>
                    <div class="col-md-6">
                        <input id="product_url" type="text" class="form-control" name="product_url" value="{{(isset($insta_product['0']['product_url'])) ? $insta_product['0']['product_url'] : ''}}" required>
                    </div>
<div class="container">
<a href="#" data-toggle="popover" data-placement="top" title="Url Format" data-content="Ex: product-url">URL info</a>
</div>
                </div>
                <div class="form-group">  
                    <label for="price" class="col-md-4 control-label">Product Price</label>
                    <div class="col-md-6">
                        <input id="price" type="text" class="form-control" name="price" value="{{(isset($insta_product['0']['price'])) ? $insta_product['0']['price'] : ''}}"  required>
                    </div>
                </div>
                <div class="form-group">  
                    <label for="unq_features" class="col-md-4 control-label">Unique Features</label>
                    <div class="col-md-6">
                        <input id="unq_features" type="text" class="form-control" name="unq_features" value="{{(isset($insta_product['0']['unique_features'])) ? $insta_product['0']['unique_features'] : ''}}" required>
                    </div>
<div class="container">
<a href="#" data-toggle="popover" data-placement="top" title="" data-content="More than one feature add with comma (,) separated">Feature info</a>
</div>
                </div>
                <div class="form-group">  
                    <label for="exclusion" class="col-md-4 control-label">Exclusions in product</label>
                    <div class="col-md-6">
                        <input id="exclusion" type="text" class="form-control" name="exclusion" value="{{(isset($insta_product['0']['exclusion'])) ? $insta_product['0']['exclusion'] : ''}}" required>
                    </div>
                </div>

                <div class="form-group">  
                    <label for="inclusion" class="col-md-4 control-label">Inclusions in product</label>
                    <div class="col-md-6">
                        <input id="inclusion" type="text" class="form-control" name="inclusion" value="{{(isset($insta_product['0']['inclusion'])) ? $insta_product['0']['inclusion'] : ''}}" required>
                    </div>
                </div>

                <div class="form-group">  
                    <label for="emi_details" class="col-md-4 control-label">EMI Details</label>
                    <div class="col-md-6">
                        <input id="emi_details" type="text" class="form-control" name="emi_details" value="{{(isset($insta_product['0']['emi_details'])) ? $insta_product['0']['emi_details'] : ''}}" required>
                    </div>
                </div>
                <div class="form-group">  
                    <label for="should_buy" class="col-md-4 control-label">Who Should Buy</label>
                    <div class="col-md-6">
                        <input id="should_buy" type="text" class="form-control" name="should_buy" value="{{(isset($insta_product['0']['should_buy'])) ? $insta_product['0']['should_buy'] : ''}}" required>
                    </div>
                </div>
                <div class="form-group">  
                    <label for="should_not_buy" class="col-md-4 control-label">Who Should Not Buy</label>
                    <div class="col-md-6">
                        <input id="should_not_buy" type="text" class="form-control" name="should_not_buy" value="{{(isset($insta_product['0']['should_not_buy'])) ? $insta_product['0']['should_not_buy'] : ''}}" required>
                    </div>
                </div>
                
                <div class="form-group">  
                    <label for="image" class="col-md-4 control-label">Upload Image</label>
                    <div class="col-md-6">

                      <input id="image" type="file" accept="image/*" class="form-control" name="image"    />
                    @if(isset($insta_product['0']['image']) && !empty($insta_product['0']['image']))
                        <img style="width: 50%;" src="{{URL::to('/')}}/image/uploads/{{$insta_product['0']['image']}}">
                    @else
                        <img style="width: 50%;" id="myImg" src="#" alt="your image" />   
                        @endif
                    </div>  


<div class="container">
<a href="#" data-toggle="popover" data-placement="top" title="" data-content="Format gif , jpeg, jpg, png. And Size must be less than 2MB">Image info</a>
</div>
                 </div>

                <div class="form-group">  
                    <label for="video" class="col-md-4 control-label">Video Url</label>
                    <div class="col-md-6">
                        <input id="video" type="text" class="form-control" name="video" value="{{(isset($insta_product['0']['video'])) ? $insta_product['0']['video'] : ''}}">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                         <button type="submit" class="btn btn-primary">
                            SUBMIT </button>
                         <button type="reset" class="btn btn-primary" name="Reset" value="Reset" style="width:17%"> CLEAR</button>
                    </div>
                </div>
                <a href="{{ URL::to('/admin/product') }}">  <span class="glyphicon glyphicon-backward"></span>
                Back To Productlist </a>
            </form>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>

<script type="text/javascript">
$(function () {
    $(":file").change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = imageIsLoaded;
            reader.readAsDataURL(this.files[0]);
        }
    });
});

function imageIsLoaded(e) {
    $('#myImg').attr('src', e.target.result);
};


$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});
</script>





</body>
</html>
