@include('layouts.backend.header')
@include('layouts.backend.agent_menu')

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<form id="change_password_form" action="{{URL::route('admin.change-password')}}">
	          <div class="form-group">
					<input type="password" class="form-control" id="old_password" name="old_password" value="" required="" title="Please enter you old password" placeholder="Old Password">
	              	<span class="help-block"></span>
	              	<span class="has-error" id="old_password_error"></span>
	          </div>
	          <div class="form-group">
	              <input type="password" class="form-control" id="new_password" name="new_password" value="" required="" title="Please enter you new password" placeholder="New Password">
	              <span class="help-block"></span>
	              <span class="has-error" id="new_password_error"></span>
	          </div>
	          <div class="form-group">
	              <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="" required="" title="Please confirm your password" placeholder="Confirm New Password">
	              <span class="help-block"></span>
	              <span class="has-error" id="confirm_password_error"></span>
	          </div>
	          <span class="has-error" id="password_change_success"></span>
	          <button type="button" id="change_password_button" class="btn btn-success btn-block">Change Password</button>
	        </form>
		</div>
	</div>
</div>



@include('layouts.backend.footer')