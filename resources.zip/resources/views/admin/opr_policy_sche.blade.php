@include('layouts.backend.header')

@include('layouts.backend.admin_menu')

<div class="container">
<form method="post" id="search_filter_form" action="/admin/operations/download-policy-schedule">
	{{csrf_field()}}
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
			<div class="panel-body">
			<h3>Search Policy</h3>
			   <div class="col-md-2">
					Product 
					<select class="form-control" id="product" name="product">
						<option value="PC">PC</option>
						<option value="TW">TW</option>
						<option value="TWTP">TW - TP</option>
						<option value="HL">HL</option>
						<option value="Tv">TV</option>	                       
	                 </select>
				</div>
				<div class="col-md-2">
					Company 
					<select class="form-control" id="company" name="company"> 
						<option value="UIIC">UIIC</option>
						<option value="HDFC">HDFC</option>                   
	                 </select>
				</div>
			    <div class="col-md-4">Policy Number <input name="policy_number" class="form-control" id="policy_number" value="37230031170160000151" placeholder="Policy Number"></div>
				<div class="col-md-4">
					<br> <input type="submit" class="btn btn-success" value="Generate"/>
				</div>
				</div>
			</div>
		</div>
	</div>
</form>	
</div>
@include('layouts.backend.footer')
