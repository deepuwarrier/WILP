@include('layouts.backend.header')

@include('layouts.backend.admin_menu')

<div class="container">
<form method="get" id="search_filter_form" action="/admin/reports/policy-summary-report">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
			<div class="panel-body">
			<h3>Policy Summary Report</h3>
			<div class="col-md-2">From Date <input name="from_date_filter" class="form-control datepicker" id="from_date" value="{{$from_date}}" placeholder="DD-MMM-YYYY"></div>
				<div class="col-md-2">To Date <input name="to_date_filter" class="form-control datepicker" id="to_date" value="{{$to_date}}" placeholder="DD-MMM-YYYY"></div>
				<div class="col-md-2">
					Branch 
					<select class="form-control" id="branch_filter" name="branch_filter">
		          		<option value="-1" >All</option>
			          	@foreach($filter_list["branch"] as $branch)             
									<option value="{{ $branch->branch_code }}">{{ $branch->branch_code }}</option>
						@endforeach					                       
	                 </select>
				</div>
				<div class="col-md-2">
					Product 
					<select class="form-control" id="product_filter" name="product_filter">
                       <option value="-1" >All</option>  
						@foreach($filter_list["product"] as $product)             
							<option value="{{ $product->module_name }}">{{ $product->module_name }}</option>
						@endforeach	                       
	                 </select>
				</div>
				<div class="col-md-2">
					Insurer 
					<select class="form-control" id="insurer_filter" name="insurer_filter">
	                       <option value="-1" >All</option>  
							@foreach($filter_list["insurer"] as $insurer)             
							<option value="{{ $insurer->insurer_code }}">{{ $insurer->insurer_code }}</option>
							@endforeach		                       
	                 </select>
				</div>
				<div class="col-md-2">
					Agent 
					<select class="form-control" id="agent_filter" name="agent_filter">
	                       <option value="-1" >All</option>  
							@foreach($filter_list["agent"] as $agent)             
							@if(!empty($agent->agent_name))             
							<option value="{{ !empty($agent->agent_name)?$agent->agent_name:'direct' }}">{{ !empty($agent->agent_name)?$agent->
							agent_name:'Direct' }}</option>
							@else
								<option value="{{ !empty($agent->agent_name)?$agent->agent_name:'direct' }}">{{ !empty($agent->agent_name)?$agent->
							agent_name:'Direct' }}</option>	
							@endif
							@endforeach	                       
	                 </select>
				</div>
				
				<div class="col-md-12">
					<br><input type="button" class="btn btn-success" id="view_report" value="View Report"/>
					<input type="hidden" class="btn btn-success" id="is_xls_download" name="is_xls_download" value="-1"/>
					&nbsp;<input type="button" id="xls_download" class="btn btn-info" value="Download XLS"/>
				</div>
				</div>
			</div>
		</div>
		<div id="ccnt_div"></div>
	</div>
</form>	
</div>
@include('layouts.backend.footer')
<script type="text/javascript">
$("#from_date,#to_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: !0,
	yearRange: "-90:+0"
	});

$("#view_report").click(function(){
	$.get("/admin/reports/policy-summary-report", {
		from_date_filter: $("#from_date").val(),
		to_date_filter: $("#to_date").val(),
		is_view:'true',
		product_filter: $("#product_filter").val(),
		branch_filter:$('#branch_filter').val(),
		is_xls_download:$('#is_xls_download').val(),
		insurer_filter:$('#insurer_filter').val(),
		agent_filter:$('#agent_filter').val(),
		agent_code: $("#agent_code").val()
	}, function(data, status) {
		console.log(data);
		$("#ccnt_div").html(data);
		if($('#is_data_empty').val() == 'true'){
			$('#xls_download').prop("disabled",true);
		} else {
			$('#xls_download').prop("disabled",false);
		}
	});
});

$("#xls_download").click(function(){
	$('#is_xls_download').val('true');
	$("#search_filter_form").submit();
});

</script>
