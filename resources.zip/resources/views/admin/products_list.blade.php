<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>InstaInsure Products</title>
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Branding Image -->
                    <a class="navbar-brand">
                         <p class="navbar-brand"><a href="{{ URL::to('/adminpanel') }}">Home  </a> > Products List</p>
                    </a>
                 </div>
                    <a class="nav navbar-nav navbar-right" href="{{ URL::to('/admin-logout') }}">
                          Logout
                    </a>
            </div>
        </nav>

        <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Products List

                    <a class="nav navbar-nav navbar-right" href="{{ route('admin.add_product') }}"> Add Product</a>
                </div>
                <div class="panel-body">
                <?php 
                if(isset($insta_product) && !empty($insta_product)){
                    foreach ($insta_product as $product) { ?>
                        <p> <a href="{{ URL::route('admin.edit-products',$product['product_code']) }}"> {{ $product['product_name']}} </a></p>
                   <? }
                }else{ ?>
                     <p> No Products available</p>
                <?php }?>


                </div>
            </div>
        </div>
    </div>
</div>
    </div>

</body>
</html>
