@include('layouts.backend.header')
@include('layouts.backend.agent_menu')



<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Active Leads</strong></div>
				<div class="panel-body">
				<table class="table">
				<tr>
					<th>Lead Date</th>
					<th>Product</th>
					<th>Insurer</th>
					<th>Lead Details</th>
					<th>Lead Status</th>
					<th>Operations</th>
				</tr>
			
			</table>
				</div>
			</div>
		</div>
	</div>
</div>

@include('layouts.backend.footer')
