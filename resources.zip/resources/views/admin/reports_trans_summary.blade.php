@include('layouts.backend.header')
@include('layouts.backend.admin_menu')

<div class="container">
<form method="post" id="search_filter_form" action="#">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
			<div class="panel-body">
			<h3>Transaction Report</h3>
			<div class="col-md-2">From Date <input  class="form-control datepicker" id="from_date" value="" placeholder="DD-MMM-YYYY"></div>
				<div class="col-md-2">To Date <input  class="form-control datepicker" id="to_date" value="" placeholder="DD-MMM-YYYY"></div>
				
				<div class="col-md-2">
					Product 
					<select class="form-control" id="product_code" >
                       <option value="PC" >Private Car</option>  
                       <option value="HL" >Health</option>  
                       <option value="TV" >Travel</option>  
                       <option value="TW" >Two Wheeler</option>  
	                 </select>
				</div>
				<div class="col-md-2">
					Agent
					<select class="form-control" id="agent_filter" name="agent_filter">
	                       <option value="all" >All</option>  
							@foreach($filter_list["agent"] as $agent)
							@if(!empty($agent->agent_name))             
							<option value="{{ !empty($agent->agent_code)?$agent->agent_code:'direct' }}">{{ !empty($agent->agent_name)?$agent->
							agent_name:'Direct' }}</option>
							@endif
							@endforeach                        
							<option value="direct">Direct</option>	
	                 </select>
				</div>
				<div class="col-md-2">
					<br><input type="button" id="trans_summary_search" class="btn btn-success" value="Search"/>
				</div>
				</div>
			</div>
		</div>
	</div>
</form>	
</div>

<div id="ccnt_div"></div>


@include('layouts.backend.footer')
<script type="text/javascript">
$("#from_date,#to_date").datepicker({
	dateFormat: "dd-M-yy",
	changeMonth: !0,
	changeYear: !0,
	yearRange: "-90:+0"
	});

$("#trans_summary_search").click(function(){
	$.get("/admin/reports/trans-summary-data", {
		from_date: $("#from_date").val(),
		to_date: $("#to_date").val(),
		product_code: $("#product_code").val(),
		agent_code: $("#agent_filter").val()
	}, function(data, status) {
		$("#ccnt_div").html(data);
	});
});


</script>