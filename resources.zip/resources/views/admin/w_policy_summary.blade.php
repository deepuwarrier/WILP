<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<!-- <div class="col-md-6"><h3>Policy Report</h3></div> -->
				<!-- <div class="col-md-6 pull-right">download</div> -->
				<div class="panel-body">
				<table class="table">
				<tr>
					<th>Branch Name</th>
					<th>Product</th>
					<th>Insurer</th>
					<th>Agent Name</th>
					<th>Policy Count</th>
					<th>OD Premium</th>
					<th>TP Premium</th>
					<th>Brokerage</th>
				</tr>
				<input type="hidden" name="is_data_empty" id='is_data_empty' value="{{((empty($policy_list->toArray())))?'true':'false'}}">
				@foreach($policy_list as $policy)
				<tr>
					<td>{{  $policy->branch_code }}</td>
					<td>{{  $policy->module_name }}</td>
					<td>{{  $policy->insurer_code }}</td>
					<td>{{  $policy->agent_name }}</td>
					<td>{{  $policy->policy_count }}</td>
					<td>{{  $policy->od_premium }}</td>
					<td>{{  $policy->tp_premium }}</td>
					<td>{{  $policy->brokerage_value }}</td>
				</tr>
	@endforeach
			<tr>
					<th colspan="4">Totals</td>
					<th>{{ $policy_list->sum('policy_count') }}</th>
					<th>{{ $policy_list->sum('od_premium') }}</th>
					<th>{{ $policy_list->sum('tp_premium') }}</th>
					<th>{{ $policy_list->sum('brokerage_value') }}</th>
				</tr>
			</table>
				</div>
			</div>
		</div>
	</div>
</div>