<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Active Leads - Pending for Payment</strong></div>
				<div class="panel-body">
				<table class="table">
	<tr>
		<th>Product</th>
		<th>Insurer</th>
		<th>Quote Date</th>
		<th>Customer Name</th>
                <th>Phone No.</th>
		<th>Trans. Details</th>
		<th>Trans. Status</th>
		<th>Policy Number</th>
                <th>View</th>
	</tr>
	@foreach($trans_data_list as $trans_data)
	<tr>
		<td>{{ $trans_data["product_name"]}}</td>
		<td>{{ $trans_data["insurer_name"]}}</td>
		<td>{{ $trans_data["quote_date"] }}</td>
		<td>{{ $trans_data["customer_name"] }}</td>
                <td> {{ $trans_data["customer_phone"] }} </td>
		<td>{{ $trans_data["trans_details"] }}</td>
		<td>{{ $trans_data["trans_status"] }}</td>
		<td>{{ $trans_data["policy_number"] }}</td>
                <td>@if($trans_data['url'] != '#')<a target="_blank" href="{{ $trans_data['url'] }}">View</a>@endif </td> 
	</tr>
	@endforeach				
</table>
				
				</div>
			</div>
		</div>
	</div>
</div>

