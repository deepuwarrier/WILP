@include('layouts.backend.header')
@include('layouts.backend.agent_menu')
<div class="container">
	 <section class="products_intro">
	 <div class="panel panel-default">
				<div class="panel-heading">
					<strong>Create Quote</strong>
                  			
				</div>
				<div class="panel-body">
				<div class="row" style="text-align: center;">
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/car-insurance" target="_blank">
                        <img src="{{URL::asset('image/car.svg')}}" width="40%" alt="Car Insurance">
                        <h4>Car<span> Insurance</span></h4>
                     </a>
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/two-wheeler-insurance" target="_blank">
                        <img src="{{URL::asset('image/bike.svg')}}" width="40%" alt="Two Wheeler Insurance">
                        <h4>Bike<span> Insurance</span></h4>
                     </a> 
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/health-insurance" target="_blank">
                        <img src="{{URL::asset('image/health.svg')}}" width="40%" alt="Health Insurance">
                        <h4>Health <span> Insurance</span></h4>
                     </a>
                  </div>
                  <div class="col-md-3">
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/travel-insurance" target="_blank">
                        <img src="{{URL::asset('image/travel.svg')}}" width="40%" alt="Travel Insurance">
                        <h4>Travel<span> Insurance</span></h4>
                     </a>
                  </div>
               </div>  
				
				</div>
         </div>
	 
               
              
                      
    </section>         
 </div>
 

<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Current Month</strong></div>
				<div class="panel-body"><canvas id="curr_mon_data"></canvas>	</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading"><strong>Insurers Share</strong></div>
				<div class="panel-body"><canvas id="curr_mon_ins_share"></canvas>	</div>
			</div>
		</div>
	</div>
</div>



@include('layouts.backend.footer')
<script>
$(document).ready(function() {
	$.ajax({
		url:'graph/bar_graph',
		type:'GET',
		success:function(data){
			console.log(data);
			var ctx = document.getElementById("curr_mon_data");
			var myBarChart = new Chart(ctx,{
			    type: 'bar',
			    data: {
			        labels: data.bar.labels,
			        datasets: [{
			        	label: '# of Policies',
			            data: data.bar.value,
				            backgroundColor: [
			            			'#d9ffb3',	
				                '#80D4FF',
				                '#CC99FF',
				                 '#00e6ac',
				            ]
			        }],
			    },
			     options : {
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero: true,
                 userCallback: function(label, index, labels) {
                     // when the floored value is the same as the value we have a whole number
                     if (Math.floor(label) === label) {
                         return label;
                     }

                 },
             }
         }],
     },
 }
			});

			var ctx2 = document.getElementById("curr_mon_ins_share");
			var myPieChart = new Chart(ctx2,{
			    type: 'pie',
			    data: {
			       	labels: data.pie.labels,
			        datasets: [{
			            label: '# of Votes',
			            data: data.pie.value,
				            backgroundColor: [
				            	'#d9ffb3',	
				                '#80D4FF',
				                '#CC99FF',
				                 '#00e6ac',
				                 '#ffffb3',
				                 '#ffebcc',
				            ],
				            borderColor: [
				                '#FFFFFF'
				            ],
				            borderWidth: 1
			        }]
			    }
			});
		}
	});
});
</script>