@include('layouts.header')
<div class="page-header" style="background-color: white">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<table class="table">
					<tr>
						<td><b>Agent Name</b></td>
						<td><b>{{!empty(session('username'))?session('username'):''}}</b></td>
					</tr>
					<tr>
						<td><b>Agent Code</b></td>
						<td><b>{{!empty(session('user_code'))?session('user_code'):''}}</b></td>
					</tr>
				</table>
			</div>
			<div class="col-md-offset-8">
				<table class="table">
					<tr>
						<td>Today</td>
						<td>{{$today['Policy']}}</td>
					</tr>
					<tr>
						<td>YTD</td>
						<td>{{$till_date['Policy']}}</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="row">
			<table class="table">
				<tr>
					<td>Lead</td>
					<td>Lead Date</td>
					<td>Quote</td>
					<td>Proposal</td>
					<td>Policy</td>
					<td>Last Activity</td>
				</tr>
				@foreach($prospects_details as $key => $value)
					<tr>
						@foreach($value->toArray() as $key2=>$value2)
							@if(strtolower($key2) == 'session_id')
								<td class="hidden">{{$value2}}</td>
							@elseif(strtolower($key2) == 'lead')
								<td><a href="{{URL::route('car-insurance.getquote',$value['session_id'])}}">{{$value2}}</a></td>
							@else
								<td>{{$value2}}</td>
							@endif
						@endforeach
					</tr>
				@endforeach
			</table>
			{{$prospects_details->render()}}
		</div>
 	</div>
</div>
@include('layouts.footer')
