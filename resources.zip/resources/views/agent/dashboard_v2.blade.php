<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>InstaInsure Control</title>
    <!-- Styles -->
    
     <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}"/>
     <link rel="stylesheet" type="text/css" href="{{ asset('css/css8393.css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('css/vertical-nav.css') }}" />
      <link href="{{ asset('css/insta-toolkit.css') }}" rel="stylesheet" />
      {{-- <link href="{{asset('css/insta.css')}}" rel="stylesheet" /> --}}
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <style type="text/css">
    .page-header .container {
	    padding-top: 80px;
	}
	.container {
	    color: #424242!important;
	}
</style>
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container" style="padding-top: 10px !important; ">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Branding Image -->
                    <a class="navbar-brand">
                        InstaInsure Agent Home
                    </a>
                 </div>
                    <ul class="nav navbar-nav navbar-right @if(empty(session('user_id')))hide  @endif" id="user_section">
                     <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="material-icons">account_box</i><span id="user_name">@if(!empty(session('username'))) {{session('username')}}@else Customer @endif</span>
                        <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-with-icons">
                           <li id="change_password" @if(empty(session('user_id'))) class="hide" @endif>
                             <a href="javascript:void(0);" style="text-align: left" data-toggle="modal" data-target="#change_password_modal" >
                               <i class="material-icons">account_circle</i> Change password
                             </a>
                           </li>
                           <li id="agent_dashboard" @if(empty(session('user_agent'))) class="hide" @endif>
                             <a href="{{route('agent_dashboard')}}" style="text-align: left">
                               <i class="material-icons">dashboard</i> Dashboard
                             </a>
                           </li>
                           <li id="daily_report" @if(empty(session('user_agent'))) class="hide" @endif>
                             <a href="{{route('agent_daily_report')}}" style="text-align: left">
                               <i class="material-icons">file_download</i> Daily Report
                             </a>
                           </li>
                           <li id="logout_div" @if(empty(session('user_id'))) class="hide" @endif>
                             <a href="#" style="text-align: left" id="logout" data-url="{{URL::route('customer.logout')}}">
                               <i class="material-icons">lock</i> Logout
                             </a>
                           </li>
                        </ul>
                     </li>
                  </ul>
				<a href="{{URL::to('/')}}" target="_blank" class="navbar-right nav navbar-brand ">Go to website</a>
            </div>
        </nav>
	<div class="page-header" style="background-color: white">
        <div class="container">
		<div class="row">
			<div class="col-md-5">
				<table class="table">
					<tr>
						<td><b>Agent Name</b></td>
						<td><b>{{!empty(session('username'))?session('username'):''}}</b></td>
					</tr>
					<tr>
						<td><b>Agent Code</b></td>
						<td><b>{{!empty(session('user_code'))?session('user_code'):''}}</b></td>
					</tr>
				</table>
			</div>
			<div class="col-md-offset-8">
				<table class="table">
					<tr>
						<td>Today</td>
						<td>{{$today['Policy']}}</td>
					</tr>
					<tr>
						<td>YTD</td>
						<td>{{$till_date['Policy']}}</td>
					</tr>
				</table>
			</div>
		</div>
		<div class="row">
			<table class="table">
				<tr>
					<td>Lead</td>
					<td>Lead Date</td>
					<td>Quote</td>
					<td>Proposal</td>
					<td>Policy</td>
					<td>Last Activity</td>
				</tr>
				@foreach($prospects_details as $key => $value)
					<tr>
						@foreach($value->toArray() as $key2=>$value2)
							@if(strtolower($key2) == 'session_id')
								<td class="hidden">{{$value2}}</td>
							@elseif(strtolower($key2) == 'lead')
								<td><a href="{{URL::route('car-insurance.getquote',$value['session_id'])}}" target="_blank">{{$value2}}</a></td>
							@else
								<td>{{$value2}}</td>
							@endif
						@endforeach
					</tr>
				@endforeach
			</table>
			{{$prospects_details->render()}}
		</div>
 	</div>
 </div>
</div>
 <!--   Core JS Files   -->
      <script src="{{URL::asset('js/jquery.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/jquery-ui.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
</body>
</html>

