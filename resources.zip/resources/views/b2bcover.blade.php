@include('layouts.header')

<div class="page-header blog-style">
         <div class="container" style="text-align: justify;">
            <div class="row">
               <div class="col-md-12">
                  <ol class="breadcrumb">
                     <li><a href="/">InstaInsure.com</a></li>
                     <li><a href="/blog">Blog Home</a></li>
                     <li class="active">Car Insurance</a></li>
                     <li class="active">What is Bumper to Bumper?</li>
                  </ol>
                  <div class="card card-background" style="background-image: url('/image/blog/nildep/nildep.png'">
                     <div class="content" style="padding-top:60px;">
                        <h2 class="dark">What is "Bumper to Bumper" Cover?</h2>
                     </div>
                  </div>
                  <blockquote>
                     <p>
                        "How many times have you heard the phrase “Bumper to Bumper” cover for your car? Ever got confused what it actually means, what is included or what is excluded? Then, you are reading the right article.”
                     </p>
                  </blockquote>
               </div>
               <div class="col-md-12">
                  <h3 class="title light">Read on:</h3>
                  <p>Let me start by explaining the core basics of car insurance. There are two types of car insurance.</p>
                  <ul>
                     <li>Third Party Insurance</li>
                     <li>Comprehensive insurance</li>
                  </ul>
                  <p>The <strong>Third Party</strong> insurance is a mandatory insurance, the bare minimum which your car should have before you hit the road. This statutory requirement is laid down in the Motor Vehicles Act. Legally you are not allowed to drive your car on a public road without this insurance cover. In an unfortunate event of you meeting with an accident and causing damage to another person’s car, property or life, the insurance company from whom you brought the Third Party Insurance policy pays on your behalf, to the affected person as per the guidelines mentioned in the Motor Vehicles Act. This policy will essentially keep you financially protected against damages caused to others because of you.</p>
                  <p>Now what about the damages caused to yourself in an accident? It is called “Own Damages” in the insurance terminology. This is where <strong>Comprehensive insurance</strong> kicks in. It pays for damages caused by you to others as well as it pays for your own loss/damage. So a comprehensive insurance has two components – <strong>Third Party</strong> (the mandatory component) and <strong>Own Damage</strong>.</p>
                  <p>It is now clear that, at an unfortunate event of an accident, if you have a comprehensive policy, the Insurance Company will pay you for the loss/damage of your car. But, how much the insurance company pays during a claim settlement is still unclear. Let me explain this in detail.</p>
                  <p>We hope this never happens, but let’s take a hypothetical situation of your car meeting with an accident after 3 years of buying it. Your car has already been used for 3 years and there are natural wear and tear to all parts of your car. While restoring your car, the used parts gets repaired or replaced by new ones. The entire concept of insurance mandates that no one should be profited by an insurance cover. Insurance is only to protect you from the risk of a loss. So if the insurance company replaces a 3 year old part with a new one, you end up getting a profit. So the insurance regulator in India – IRDAI has fixed a depreciation for any used parts of your car. At the time of the claim, the part gets replaced with a new one or gets repaired, but you pay for the depreciation.</p>
                  <p><b>Let’s take an example</b> – In a front on collision of a 3 year old Maruti Swift Dzire, the following parts were replaced/repaired by the workshop</p>
                  <img src="/image/blog/nildep/table1.png" alt="Without Nil Depreciation Example">
                  <p></p>
                  <p></p>
                  <p>The total cost for repair was <strong>52,000 INR</strong>. For every claim that you make, please be aware that there will be a minimum amount you have to pay compulsorily.  This is called the compulsory deductible. After considering the compulsory deductible and the depreciations, the Insurance Company will pay you <strong>34,450 INR</strong> and you will end up paying <strong>17,550 INR</strong> from your own pocket as per the above example.</p>
                  <p>Now that is a huge blow! You would surely have come across people who complain about not getting full settlement during a claim. The above example clearly shows why!</p>
                  <p>There had to be some way to ensure the Insurance Company pays you more during a claim. Hence was born an add-on called Nil-Depreciation. Also called Zero-Depreciation by some. It is basically an additional cover you can add to your basic comprehensive policy which will make all depreciations ZERO!</p>
                  <p><b>Let’s assume you had taken Nil-Depreciation add-on in your comprehensive policy</b> for an additional 3,000 INR. See the grid below. See how things change :</p>
                  <img src="/image/blog/nildep/table2.png" alt="With Nil Depreciation Example">
                  <p></p>
                  <p></p>
                  <p>That sounds amazing isn’t it? On a claim of 52,000 INR, the Insurance Company pays 51,000 INR. You pay only for the compulsory deductible which is a mere 1,000 INR. Of course you also paid an additional amount for the Nil-Depreciation Add-on when you bought the policy. Which means by paying an additional 3,000 INR you <strong>saved 14,550 INR</strong>!</p>
                  <p>Since the add-on takes care of your claim in its entirety, from the front bumper to the rear bumper without any deductions, it’s popularly known among the general public as “<strong><em>Bumper to Bumper</em></strong>”. Though in the actual insurance terminology it’s called <strong>Nil-Depreciation</strong> or <strong>Zero-Depreciation</strong>.</p>
                  <p>The insurance companies have restrictions based on the age of the car, number of claims during the previous year etc., while allowing the customer to take the Nil-Depreciation add-on with their comprehensive policy. Some companies allow the add-on till the age of 3, some 5 and some companies even go up to the age of 7. It all depends on the Insurance Company you choose to buy the policy from.</p>
                  <p>Next time, you decide to renew your car, see if your car is eligible for a Nil-Depreciation add-on and if your car is eligible think twice before <strong>not</strong> taking it!</p>
                  <p>If your insurance renewal is around the corner, check our portal <a href="http://www.instainsure.com">www.instainsure.com</a>. You can get the Nil-Depreciation add-on through our portal at best rates. And what’s more, you also get <strong>free assistance</strong> at time of a claim. Our claims expert will talk to the Insurance Company on your behalf to ensure you get the best settlement for your claim. Visit our site and experience the transparency before your decide where to renew your insurance from.</p>
                  <p>Drive safe!</p>
                  <div class="card card-blog">
                  <h3 style="color: #00669c">Feeling More Confident to Buy Insurance Online?</h3>
                  <h5>Try Generating a Car Insurance Quote Now. Its Super Quick and Simple!</h5>
                  <a href="/car-insurance" target="_blank" class="btn btn-success">Generate a Quote</a>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="row">
                     <div class="col-md-12" style="text-align: left">
                        <div class="blog-tags" style="padding-top: 20px;">
                           Tags:
                           <span class="label label-primary">Toyota Tsusho Insurance Broker India Pvt Ltd</span>
                           <span class="label label-primary">InstaInsure</span>
                           <span class="label label-primary">Insurance Broker</span>
                           <span class="label label-primary">Depreciation</span>
                           <span class="label label-primary">NCB</span>
                           <span class="label label-primary">Nil Depreciation</span>
                           <span class="label label-primary">Private Car Insurance</span>
                           <span class="label label-primary">Car Insurance Renewal</span>
                           <span class="label label-primary">TTIBI</span>
                           <span class="label label-primary">Bumper to Bumper</span>
                           <span class="label label-primary">Zero depreciation</span>
                        </div>
                     </div>
                  </div>
                  <hr>
                  <h4 class="card-title">Author : Deepak Venugopal</h4>
                  <p class="description">The article is written by Deepak Venugopal, Head- InstaInsure.com. You can shoot in your queries to deepak@instainsure.com or better still, call us at 7899-000-333</p>
                  <p>Please note that the above example is only an indicative and the actual figures will vary on a case to case basis. The example confines to the scope of explaining how a Nil-Depreciation works. There may be other deductions like consumables and salvage charges in your final bill. I will touch upon them shortly, in the next article.</p>
                  <div class="col-xs-8 hidesection" style="padding:20px 0;">
                     <div class="form-group is-empty"><input value="" placeholder="Email this blog" class="form-control" type="email"><span class="material-input"></span></div>
                  </div>
                  <div class="col-md-1 hidesection">
                     <button type="button" class="btn btn-primary btn-just-icon" name="button">
                     <i class="material-icons">mail</i>
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>

<br><br>
<hr>



@include('layouts.footer')

