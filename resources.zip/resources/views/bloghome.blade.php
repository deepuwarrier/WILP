@include('layouts.header')

<div class="page-header">
      <div class="container">

            <div class="text-center" style="color:#424242">
               <h2>Any one can Know! The point is to <b>understand</b>.</h2>
               <p><i> - Albert Einstein </i></p>
            </div>

            <div class="section">
            <div class="row" style="text-align: center;">
               
                  <ul class="nav nav-pills nav-pills-primary customnavpills">
                    <li class="active"><a href="#all" data-toggle="tab">All Insurance Blogs</a></li>
                    <li><a href="#car" data-toggle="tab">Car</a></li>
                    <li><a href="#health" data-toggle="tab">Health</a></li>
                    <li><a href="#travel" data-toggle="tab">Travel</a></li>
                    <li><a href="#2wheeler" data-toggle="tab">Two-Wheeler</a></li>
                    <li><a href="#home" data-toggle="tab">Home</a></li>
                    <li><a href="#term" data-toggle="tab">Term</a></li>
                    <li><a href="#industry" data-toggle="tab">Industry</a></li>
                  </ul>
                  <div class="tab-content tab-space">
                     <div class="tab-pane active" id="all">
                           <div class="row">

                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/lowpremium/lowpremium.png'">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">Be Aware: Low Premium comes at a cost!</h3>
                                       <p class="card-description">
                                          The insurance companies offer huge discounts when purchased online due to lower acquisition costs. But hold on! Everything that glitters is not gold.
                                       </p>
                                       <a href="/blog/be-aware-low-premium-comes-at-a-cost" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/nildep/nildep.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">What is Bumper to Bumper Cover?</h3>
                                       <p class="card-description">
                                          How many times have you heard the phrase “Bumper to Bumper” cover for your car? Ever got confused what it actually means, what is included or what is excluded
                                       </p>
                                       <a href="/blog/what-is-bumper-to-bumper-cover" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/insuranceday/insuranceday.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Industry</h6>
                                       <h3 class="card-title">Toyota Tsusho Insurance Day</h3>
                                       <p class="card-description">
                                          TTIBI - a 7 year old organization, the only Indo-Japanese collaboration of its kind, pulled off a remarkable opening for their Mumbai office – their 7th in India.
                                       </p>
                                       <a href="/blog/toyota-tsusho-insurance-day" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                     </div>
                     <div class="tab-pane" id="car">
                     <div class="row">

                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/lowpremium/lowpremium.png'">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">Be Aware: Low Premium comes at a cost!</h3>
                                       <p class="card-description">
                                          The insurance companies offer huge discounts when purchased online due to lower acquisition costs. But hold on! Everything that glitters is not gold.
                                       </p>
                                       <a href="lowpremium.html" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/nildep/nildep.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">What is Bumper to Bumper Cover?</h3>
                                       <p class="card-description">
                                          How many times have you heard the phrase “Bumper to Bumper” cover for your car? Ever got confused what it actually means, what is included or what is excluded>
                                       </p>
                                       <a href="/what-is-bumper-to-bumper-cover" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>

                     </div>
                     <div class="tab-pane" id="health">
                           <h4>Oh Oh! nothing here yet! Check back soon. :-)</h4>
                     </div>
                     <div class="tab-pane" id="travel">
<h4>Oh Oh! nothing here yet! Check back soon. :-)</h4>
                     </div>
                     <div class="tab-pane" id="2wheeler">
<h4>Oh Oh! nothing here yet! Check back soon. :-)</h4>
                     </div>
                     <div class="tab-pane" id="home">
<h4>Oh Oh! nothing here yet! Check back soon. :-)</h4>
                     </div>
                     <div class="tab-pane" id="term">
<h4>Oh Oh! nothing here yet! Check back soon. :-)</h4>
                     </div>
                     <div class="tab-pane" id="industry">
                     <div class="row">
                              <div class="col-md-4">
                                 <div class="card card-raised card-background" style="background-image: url('image/blog/insuranceday/insuranceday.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Industry</h6>
                                       <h3 class="card-title">Toyota Tsusho Insurance Day</h3>
                                       <p class="card-description">
                                          TTIBI - a 7 year old organization, the only Indo-Japanese collaboration of its kind, pulled off a remarkable opening for their Mumbai office – their 7th in India.
                                       </p>
                                       <a href="/blog/toyota-tsusho-insurance-day" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>

                     </div>
                  </div>
            </div>
         </div>
      </div>
   </div>

<br><br>
<hr>

@include('layouts.footer')

