      @include('car.layouts.inn-hdr')
      <div class="cd-section" id="carwizard">
         <div class="col-sm-12 removepaddingsmallscreen whitebg">
            <!--      Wizard container        -->
            <div class="wizard-container"><form name="update_quote" id="update_quote" method="post" action="{{URL::route('car-insurance.getquote',$trans_code)}}" style="margin-bottom: 0em;">
               <div class="col-sm-4" id="detail">
                  <div class="card card-form-horizontal" id="car_details">
                     <div class="content">
                        <div class="row">
                           <div class="col-xs-6 pull-right">
                              <a class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="change_details_page" href="{{URL::to('car-insurance')}}">Change</a>
                           </div>
                           <div class="col-xs-6 pull-left">
                              <h6 class="pull-left">Showing Results for</h6>
                           </div>
                        </div>
                        
                        <input type="hidden" class="ajaxRequiredData" name="make_code" id="make_code" value="{{$car_details['make_code']}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="model_code" id="model_code" value="{{$car_details['model_code']}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="state" id="state" value="{{$car_details['state']}}"/>
                       {{--  <input type="hidden" class="ajaxRequiredData" name="session_id" id="session_id" value="{{$car_details['session_id']}}"/> --}}
                        <input type="hidden" class="ajaxRequiredData" name="trans_code" id="trans_code" value="{{$trans_code}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="variant_code" id="variant_code" value="{{$car_details['variant_code']}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="vehicle_cc" id="vehicle_cc" value="{{$car_details['vehicle_cc']}}"/>
                        <input type="hidden" name="typeofbusines" id="typeofbusines" value="{{$car_details['typeOfBusiness']}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="make_name" id="make_name" value="{{$car_details['make_name']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="model_name" id="model_name" value="{{$car_details['model_name']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="variant_name" id="variant_name" value="{{$car_details['variant_name']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="fuel" id="fuel" value="{{$car_details['fuel']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="ncb" id="ncb" value="{{ $car_details['ncb']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="expiry_status" id="expiry_status" value="{{ $car_details['expiry_status']}}" />
                        <input type="hidden" name="new_ncb" id="new_ncb" value="{{ $car_details['new_ncb']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="idv_claim" id="idv_claim" value="{{$car_details['claim']}}" />
                        <input name="car_price" id="car_price" type="hidden" value="{{$car_details['price']}}"/>
                        <input name="ex_showroom_car_price" id="ex_showroom_car_price" type="hidden" value="{{$car_details['ex_showroom_car_price']}}"/>
                        <input type="hidden" class="ajaxRequiredData" name="rto" id="rto" value="{{ $car_details['rto']}}" />
                        <input type="hidden" class="ajaxRequiredData" name="year" id="year" value="{{ $car_details['year']}}" />
                        <input type="hidden" name="car_idv" id="car_idv" value="{{$car_details['idv']}}" />
                    
                        
                        {{ csrf_field() }}
                        <div class="row content pull-left">
                           <span class="label label-default base_detail">{{$car_details['make_name']}}</span>
                           <span class="label label-default base_detail">{{$car_details['model_name']}}</span>
                           <span class="label label-default base_detail">{{$car_details['variant_name']}}</span>
                           <span class="label label-default base_detail">{{$car_details['fuel']}}</span>
                           <span class="label label-default base_detail">{{ $car_details['rto']}}</span>
                           <span class="label label-default base_detail">{{ $car_details['year']}}</span>
                        </div>
                     </div>
                  </div>
                  @if($car_details['typeOfBusiness'] === 'New Business')
                  <div class="card">
                     <div class="col-xs-12">
                        <div class="titleinput">
                           <h6>Policy Package</h6>
                        </div>
                     </div>
                     <div class="col-xs-12">
                       <div class="col-sm-12" style="padding:0">
                                <div class="labelright">
                                  <div class="radiobutton">
                                    <input type="radio" 
                                      id="policy_package_one_yr" value="1"
                                      name="policy_type_selection" 
                                      class="required valid ajaxRequiredData"  
                                      {{($car_details['policy_type_selection'] === '1') ? 'checked=checked' : ''}}
                                      />                                   
                                  <label for="policy_package_one_yr" data-toggle="tooltip" data-placement="top" title="" data-container="body"  data-original-title="1Yr Own Damage + 3Yr Third Party Cover">Comprehensive for 1st Year</label>
                                  </div>
                                  <div class="radiobutton">
                                    <input type="radio"
                                      id="policy_package_three_yr" 
                                      name="policy_type_selection"  
                                      value="3" 
                                      class="required valid ajaxRequiredData" 
                                      {{($car_details['policy_type_selection'] === '3') ? 'checked=checked' : ''}} 
                                      />
                                      <label for="policy_package_three_yr"  data-toggle="tooltip" data-placement="top" title="" data-container="body"  data-original-title="3Yr Own Damage + 3Yr Third Party Cover">Comprehensive for 3 Years</label>
                                  </div>
                                </div>
                              </div>

                        <div class="col-xs-12">
                           <div class="titleinput update_footer">
                           </div>
                        </div>
                     </div>
                  </div> 
                  @endif

                  <div class="card importantinfo" id="idv">
                     <div class="col-xs-12">
                        <div class="titleinput">
                           <h6>Some Very Important Information</h6>
                        </div>
                     </div>
                     @if($car_details['typeOfBusiness'] === 'Rollover')
                     <div class="col-xs-4 hidden">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="">
                           <a href="#">
                              <p>Policy Status</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8 hidden" id="reg_summary">
                        <div class="labelright">
                        
                                 {{-- <select name="expiry_day" id="expiry_day" class="form-control valid ajaxRequiredData {{$car_details['expiry_status']== 0?'hidden':''}}"> --}}
                                 <select name="expiry_day" id="expiry_day" class="form-control valid ajaxRequiredData">
                                    <option value="" disabled>Choose Expire Days</option>
                                    <option value="0" {{ $car_details['expiry_status']== 0?'selected':''}}>Not Expired</option>
                                    <option value="1" {{ $car_details['expiry_status']== 1?'selected':''}}>Expired within 90 Days</option>
                                    <option value="2" {{ $car_details['expiry_status']== 2?'selected':''}}>Expired beyond 90 days</option>
                                 </select>
                              </div>
                        
                     
                   

                     </div>
                 <!--     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="">
                           <a href="#">
                              <p>Expire Days</p>
                           </a>
                        </div>
                     </div>
                     -->
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You will find this in your insurance policy copy or your renewal notice. Your new policy will start from the next day.">
                           <a href="#">
                              <p>Policy Exp. Date</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <input class="form-control ajaxRequiredData {{$car_details['expiry_status']== 2?'unclickable':''}}" type="text" value="{{ Carbon\Carbon::parse($car_details['policyExpiryDate'])->format('d/m/Y')}}" id='policy_expiry_date' name='policy_expiry_date'/>
                        </div>
                     </div>
                     @else
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You policy will need to start on the same day or before the day you plan to register your car.">
                           <a href="#">
                              <p>Policy Start. Date</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <input class="form-control ajaxRequiredData" type="text" value="{{ Carbon\Carbon::parse($car_details['policyStartDate'])->format('d/m/Y')}}" id='policy_start_date' name='policy_start_date'/>
                        </div>
                     </div>
                     @endif
                     
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You will find this in your insurance policy copy or your vehicle RC (Registration Certificate)">
                           <a href="#">
                              @if($car_details['typeOfBusiness'] === 'Rollover')
                                 <p>Car Reg. Date</p>                                
                              @else
                                 <p>Car Purchase Date</p>
                               @endif
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <input class="form-control ajaxRequiredData" type="text" id="car_registration_date" data-minYear="{{$car_details['car_regis_min']}}" data-maxYear="{{$car_details['car_regis_max']}}" name="car_registration_date" value="{{ Carbon\Carbon::parse($car_details['car_registration_date'])->format('d/m/Y')}}" />
                        </div>
                     </div>
                     @if($car_details['typeOfBusiness'] === 'Rollover')
                       <div class="col-xs-4">
                           <div class="labelleft"  data-toggle="tooltip" data-placement="top" title="Did you get any claim settled during your current policy period?">
                              <a href="#">
                                 <p>Claims </p>
                              </a>
                           </div>
                        </div>
                        <div class="col-xs-8" id="reg_summary">
                           <div class="labelright">
                              <div class="radiobutton">
                                 <input type="radio" class="ajaxRequiredData" name="claim_status" id="radio_3" value='Y' {{$car_details['claim']==='N'?'':'checked'}} {{$car_details['expiry_status']== 2?'disabled':''}}/>
                                 <label for="radio_3">Yes</label>
                              </div>
                              <div class="radiobutton">
                                 <input type="radio" class="ajaxRequiredData" name="claim_status" id="radio_4" id="claim_status" value="{{$car_details['claim']==='N'?'N':''}}" {{$car_details['claim']==='N'?'checked':''}} {{$car_details['expiry_status']== 2?'disabled':''}}/>
                                 <label for="radio_4">No</label>
                              </div>
                           </div>
                        </div>
                     @endif    
                     
                           
                     
                     @if($car_details['typeOfBusiness'] === 'Rollover')
                     <div class="col-xs-4">
                        <div class="labelleft"  data-toggle="tooltip" data-placement="top" title="Current No Claim Bonus percent can be found in your insurance policy copy's premium calculation table">
                           @if($car_details['typeOfBusiness'] === 'Rollover')
                             <p>NCB</p>
                           @else
                              <p>NCB Transfer</p>
                           @endif                     
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">

                           <div class="col-xs-3 ncblabel">
                              <span>Current: </span>
                           </div>
                           <div class="col-xs-3 ncbvalue">
                              <select name="current_ncb" id="current_ncb" class="form-control {{$car_details['expiry_status']== 2?'unclickable':''}} valid" aria-invalid="false" {{$car_details['claim']==='N'?'':'disabled="disabled"'}}>
                                 <option value="" disabled>Choose your option</option>
                                          <option value="0" {{ $car_details['ncb'] == '0' ? "selected=selected":''}}>0 %</option>
                                          <option value="20"{{ $car_details['ncb'] == '20' ? "selected=selected":''}} >20 %</option>
                                          <option value="25"{{ $car_details['ncb'] == '25' ? "selected=selected":''}}>25 %</option>
                                          <option value="35"{{ $car_details['ncb'] == '35' ? "selected=selected":''}}>35 %</option>
                                          <option value="45"{{ $car_details['ncb'] == '45' ? "selected=selected":''}}>45 %</option>
                                          <option value="50"{{ $car_details['ncb'] == '50' ? "selected=selected":''}}>50 %</option>
                              </select>
                           </div>
                           <div class="@if($car_details['typeOfBusiness'] != 'Rollover') hide @endif">
                              <div class="col-xs-3 ncblabel">
                                 <span>Eligible: </span>
                              </div>
                              <div class="col-xs-3 eligible">
                                 <span class="label-on-left pretext" id="new_ncb_span">{{$car_details['new_ncb']}}%</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     @else
                        <select class="hidden">
                           <option value="0" selected>0</option>
                        </select>  
                     @endif 
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="IDV (Insured Declared Value) is the current market value of your vehicle.">
                              <p>Expected IDV</p>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <div class="xQty">
                              <input type='button' value='-' class='qtyminus' data-qtymin = '{{isset($car_details["idv_min"])?round($car_details["idv_min"]):""}}' field='quantity' />
                              <input type='text' name='quantity' id="quantity" value='{{isset($car_details["updated_idv"])?$car_details["updated_idv"]:$car_details["idv"]}}' class='qtyValue ajaxRequiredData' min="50000"/>
                              <input type='button' value='+' class='qtyplus' data-qtymax = '{{isset($car_details["idv_max"])?round($car_details["idv_max"]):""}}' field='quantity' />
                           </div>
                           <a href="#"><i id="reset_idv" class="material-icons iconcustom unhidetohide" data-toggle="tooltip" data-placement="top" title="Reset to Recommended IDV">settings_backup_restore</i></a>
                        </div>
                     </div>
                     <div class="col-xs-12">
                        <div class="titleinput update_footer">
                           <button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_idv" >Update Quotes</button>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-sm-4">
                  <div class="card card-form-horizontal">
                     <div class="row accordion">
                        <div class="col-md-12">
                           <h6> Default Inclusions in your Car Insurance Policy </h6>
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="false">
                                    @foreach($covers as $cover)
                                       @if( $cover->cover_api_id === 'OD' || $cover->cover_api_id === 'TP' || $cover->cover_api_id === 'PA_LL')
                                          <div class="panel panel-default">
                                             <div class="panel-heading" role="tab">
                                                <h4 class="panel-title pull-left">
                                                   <a data-toggle="collapse" data-parent="#accordion1" href="#{{$cover->cover_api_id}}_toggle">{{$cover->cover_name}}</a>
                                                </h4>
                                                <div class="included"> 
                                                   <input  class="filter_quote hidden" name="{{$cover->cover_api_id}}" id="{{$cover->cover_api_id}}" value="#" type="checkbox" checked disabled>
                                                   <img class="checkmark" src="{{asset('image/check.png')}}" alt="Included">
                                                </div>
                                             </div>
                                             <div id="{{$cover->cover_api_id}}_toggle" class="panel-collapse collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                                <div class="panel-body">
                                                   {{$cover->cover_description}}
                                                </div>
                                             </div>
                                          </div>
                                       @else
                                          @continue
                                       @endif
                                    @endforeach
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-12" id="covers_summary_details">
                           <h6> Additional Features and Covers </h6>
                           <div class="row">
                              <div class="col-md-12 middleSectionInner1">
                                 <div class="panel-group" id="accordion2" role="tablist" aria-multiselectable="false">
                                    @foreach($covers as $cover)
                                       @if( $cover->cover_api_id === 'OD' || $cover->cover_api_id === 'TP' || $cover->cover_api_id === 'PA_LL')
                                         @continue
                                       @else
                                          <div class="panel panel-default">
                                             <div class="panel-heading" role="tab">
                                                <h4 class="panel-title pull-left">
                                                   <a data-toggle="collapse" data-parent="#accordion1" href="#{{$cover->cover_api_id}}_toggle">{{$cover->cover_name}}</a>
                                                </h4>
                                                <div align="right">
                                                   <div class="togglebutton">
                                                      <label>
                                                         @if(in_array($cover->cover_api_id, $selected_chcks))
                                                            <input class="filter_quote" id="{{$cover->cover_api_id}}" name="{{$cover->cover_api_id}}" value="{{$cover->cover_api_id}}" type="checkbox" checked="checked"/>
                                                         @else
                                                            <input class="filter_quote" id="{{$cover->cover_api_id}}" name="{{$cover->cover_api_id}}" value="{{$cover->cover_api_id}}" type="checkbox"/>
                                                         @endif
                                                      </label>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="{{$cover->cover_api_id}}_toggle" class="panel-collapse collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                                <div class="panel-body">
                                                   {{$cover->cover_description}}
                                                </div>
                                             </div>
                                          </div>
                                       @endif
                                    @endforeach
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               </form>
               <div class="col-sm-4">
                  <div class="insurance-list" id="quote_ctnr_box"></div>
                  <div class="insurance-list" id="last_decimal_quote_ctnr_box">

                    {!!$view_data!!}
                  </div>
                  <div class="insurance-list" id="no_quotes">
                     <p id="no_quote_text" class="hidden">
                        We did not get a quote from the below insurers

                     </p>
                    
                     
                  </div>
                  @include('car.quote.no_quote')
                  <div id="uiic_quote_ctnr_box"></div>
                  <div id="rsgi_quote_ctnr_box"></div> 
                  <div id="hdfc_quote_ctnr_box"></div> 
                  <div id="tata_quote_ctnr_box"></div>
                  <div id="bajaj_quote_ctnr_box"></div>
                  <div id="reliance_quote_ctnr_box"></div>  
                  <div id="last_decimal_loader"></div>                 
                  <div id="rs_loader"></div>
                  <div id="uiic_loader"></div>
                  <div id="tata_loader"></div>
                  <div id="hdfc_loader"></div>
                  <div id="bajaj_loader"></div>
                  <div id="reliance_loader"></div>
                  <div id="error_message" class="hide"></div>
                  <div class="row" id='email_quotes_div'>
                     <button onclick='jQuery("#email").modal();' type="button" class="btn btn-info btn-simple btn-xs pull-left" data-toggle="modal" data-target="#email_quote_modal">Email Quotes</button>
                     <!-- <button type="button" class="btn btn-info btn-simple btn-xs pull-right">Load More Quotes</button> -->
                  </div>
               </div>
            </div>
            <!-- wizard container -->
         </div>
      </div>
      <div id="modal_div"></div>
      <div class="modal fade" id="email_quote_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog">
            <form id="email_quote_form" method="POST">
               <input type="hidden" name="quote_form_url" id="quote_form_url" value="{{URL::route('send-quote-mail')}}">
               <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
                      <h4 class="modal-title" id="QuoteLabel"> E-mail Quotes</h4>
                  </div>
                     <div class="modal-body">    
                        {{ csrf_field() }}
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                           <input type="text" id="email_quote_name" name="email_quote_name" class="form-control" placeholder="Your name">
                        </div>
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                           <input type="email" id="email_quote" name="email_quote" class="form-control" placeholder="your@email.com">
                        </div>
                        <br />
                        <span id="quote_email_message"></span>
                     </div>
                     <div class="modal-footer">
                        <button type="button" value="sub" name="sub" id="quote_email_submit"  class="btn btn-primary" ><i class="fa fa-share"></i> Send </button>
                     </div>
               </div>
            </form>
         </div>
      </div>
      <form name="save_pdf" id="save_pdf" action="{{ URL::route('car.quote.getpdf') }}" method="POST" target="_blank">
      </form>
@include('car.layouts.inn-ftr')
<script src="{{ URL::asset('js/car/carquote.js') }}"></script>
