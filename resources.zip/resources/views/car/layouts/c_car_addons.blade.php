<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="addons-0" name="infocard-set-3" type="radio" checked/>
  <div infocard>
    <div class="content">
    <img src="/image/features.svg" style="width: 104px">
      <h2>Must have Addons</h2>
      <p>Flip through to now about the Addons you should consider to buy! </p>
      <label for="addons-1">Start Flipping</label>
    </div>
  </div>

  <input id="addons-1" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>What Matters?</h2>
      <p>
        Based on the age, make and model of your car, there are addons which you can include in your policy. <br><br>Note that not all Addons will be available for your car! <br><br>
        Some good to have addons are explained here for your reference!
      </p>
      <div class="row">
      <label for="addons-0"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-2"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="addons-2" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Bumper to Bumper</h2>
      <p>
        Technically known as “Zero Depreciation”. When your car meets with an accident, this add-on pays for the replacement of the damaged parts in full. If you don’t have this add-on, you will have to pay about 30% to 50% of the claim from your pocket.
      </p>
      <div class="row">
      <label for="addons-1"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-3"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="addons-3" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Engine Protect</h2>
      <p>
        Your standard car insurance covers damages to your car due to an accident, but not your engine. This add-on will pay for engine repairs if water enters your engine (due to flood, etc.), oil leakage or damages due to an accident.
      </p>
      <div class="row">
      <label for="addons-2"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-4"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
    </div>


  <input id="addons-4" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>NCB Protection</h2>
      <p>
        Each year that you do not make a claim, you get a discount called NCB (No Claim Bonus) during renewal. This add-on will preserve your accumulated NCB, even if you make a claim.
      </p>
      <div class="row">
      <label for="addons-3"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-5"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
    </div>

  <input id="addons-5" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Enhanced Roadside Assistance</h2>
      <p>
        In the event of a breakdown on the road, this add-on arranges for towing, change of flat tyre, mechanics services or even alternate transport.
      </p>
      <div class="row">
      <label for="addons-4"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-6"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
    </div>

    <input id="addons-6" name="infocard-set-3" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Return to Invoice</h2>
      <p>
        In the event of a total loss or theft of your car, this add-on pays the registration and road tax that you have paid, along the market value of your car. Whereas, a basic policy will not pay for your road tax and registration expenses.
      </p>
      <div class="row">
      <label for="addons-5"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-7"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
    </div>

  <input id="addons-7" name="infocard-set-3" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Yo Hoo!</h2>
      <p>Congratz! Now you have all the information required to include the right addons with your policy!</p>
      <a href="/car-insurance"><label>Generate a Quote</label></a>
      <div class="row">
      <label for="addons-6"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="addons-0"><i class="material-icons">autorenew</i></label>
      </div>
    </div>
    </div>
  
</div>
