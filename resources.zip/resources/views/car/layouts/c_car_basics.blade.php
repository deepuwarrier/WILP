<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="basics-0" name="infocard-set-1" type="radio" checked/>
  <div infocard>
    <div class="content">
    <img src="/image/basic.svg" style="width: 104px">
      <h2>Basics of Car Insurance</h2>
      <p>Flip through the basics of Car Insurance. Real Quick. Real simple!</p>
      <label for="basics-1">Start Flipping</label>
    </div>
  </div>

  <input id="basics-1" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Three Components</h2>
      <p>For simplicity lets say there are three components of Car Insurance.<br> 
1) Own Damage Cover<br>2) Third Party Damage Cover<br>3)Additional Covers</p>
      <div class="row">
      <label for="basics-0"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-2"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="basics-2" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Types of Policy</h2>
      <p>Based on how what all insurance components you add in your policy, there are three types of car insurance policy.</p>
      <div class="row">
      <label for="basics-1"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-3"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="basics-3" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Best Policy</h2>
      <p><b>1. Comprehensive with Addons</b></p>
      <p>This contains all the three components <br><b>Own Damage Cover <br>Third Party Damage Cover <br>Additional Features</b><br><br> <i>Zero Depreciation a.k.a Bumper to Bumper is the most commonly bought Additional Feature!</i>
      <div class="row">
      <label for="basics-2"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-4"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>

    </div>
  </div>
    <input id="basics-4" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Second Best</h2>
      <p><b>2. Basic Comprehensive</b></p>
      <p>This contains the two basic components <br><b>Own Damage Cover <br>Third Party Damage Cover </b><br><br><i>You are missing out on additional protection for your car. But Still a good choice.</i>
      <div class="row">
      <label for="basics-3"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-5"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
    <input id="basics-5" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Liability Only</h2>
      <p><b>3. Third Party</b></p>
      <p>This contains only the Third Party Damage Cover <br><br><i>Not Recommended. You are missing out on Own Damage Cover and Additional features.</i>
      <div class="row">
      <label for="basics-4"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-6"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
      <input id="basics-6" name="infocard-set-1" type="radio" />
  <div infocard>
    <div class="content">
      <h2>Ouh La!</h2>
      <p>You are now familiar with the basics of Car Insurance! Why not generate a quote?</p>
      <a href="/car-insurance"><label>Generate a Quote</label></a>
      <div class="row">
      <label for="basics-5"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="basics-0"><i class="material-icons">autorenew</i></label>
      </div>
    </div>
  </div>
</div>
