<div class="container">
            <div class="row">
               <div class="morepadding col-md-10 col-md-offset-1 centeralign">
                  <a href="/blog" target="_blank"><h2 data-aos="slide-right" data-aos-duration="600" class="title">Our Latest Blogs</h2></a>
                  <h5 data-aos="slide-right" data-aos-duration="600"><b>#</b>Knowledge <b>#</b>Information <b>#</b>Opinions <b>#</b>Insurance <b>#</b>Industry</h5>
                 
                  <br>
                  <div class="row">

                              <div class="col-md-4">
                                 <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-raised card-background" style="background-image: url('/image/blog/lowpremium/lowpremium.png'">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">Be Aware: Low Premium ahead!</h3>
                                       <p class="card-description blogpreview">
                                          The insurance companies offer huge discounts when purchased online due to lower acquisition costs. But hold on! Everything that glitters is not gold.
                                       </p>
                                       <a href="/blog/be-aware-low-premium-comes-at-a-cost" target="_blank" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-raised card-background" style="background-image: url('/image/blog/nildep/nildep.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Car Insurance</h6>
                                       <h3 class="card-title">What is Bumper to Bumper Cover?</h3>
                                       <p class="card-description blogpreview">
                                          How many times have you heard the phrase “Bumper to Bumper” cover for your car? Ever got confused what it actually means, what is included or what is excluded.
                                       </p>
                                       <a href="/blog/what-is-bumper-to-bumper-cover" target="_blank" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-4">
                                 <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-raised card-background" style="background-image: url('/image/blog/insuranceday/insuranceday.png')">
                                    <div class="content">
                                       <h6 class="category text-info">Industry</h6>
                                       <h3 class="card-title">Toyota Tsusho Insurance Day</h3>
                                       <p class="card-description blogpreview">
                                          TTIBI - a 7 year old organization, the only Indo-Japanese collaboration of its kind, pulled off a remarkable opening for their Mumbai office – their 7th in India.
                                       </p>
                                       <a href="/blog/toyota-tsusho-insurance-day" target="_blank" class="btn btn-primary btn-round">
                                          <i class="material-icons">format_align_left</i> Read Article
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
               </div>
            </div>
         </div>