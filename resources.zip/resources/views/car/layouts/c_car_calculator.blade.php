<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="premiumcalculation-0" name="infocard-set-2" type="radio" checked/>
  <div infocard>
    <div class="content">
     <img src="/image/calc.svg" style="width: 80px">
      <h2>Premium Calculation</h2>
      <p>Flip through to know how your premium is calculated!</p>
      <label for="premiumcalculation-1">Start Flipping</label>
    </div>
  </div>
  
  <input id="premiumcalculation-1" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Basic Components</h2>
      <p>The two basic components of car insurance premium calculation are :<br></p>
      <p><b>1) Own Damage Premium<br>2) Third Party Premium</b></p>
      <div class="row">
      <label for="premiumcalculation-0"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-2"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
  
  <input id="premiumcalculation-2" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>OD (Own Damage)</h2>
      <p><b>Own Damage Premium</b> is calculated at approximately <i>3.04% to 3.7%</i> of the value of your car.<br><br><b>The Influencing Factors are :</b><br>Age of the Vehicle, Registered Location & Cubic Capacity (CC)</p>
      <div class="row">
      <label for="premiumcalculation-1"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-3"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
   <input id="premiumcalculation-3" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Quick Tip!</h2>
      <p>It simply means that for every 1 Lac car insurance value, your OD premium would be between <b>3040 to 3700 INR</b></p>
      <div class="row">
      <label for="premiumcalculation-2"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-4"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
    <input id="premiumcalculation-4" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>TP (Third Party)</h2>
      <p><b>Third Party Premium</b> is calculated purely on the basis of the Cubic Capacity of your car. <br><br><b>Its a simple matrix</b><br>Less than 1000 CC - <b><i>INR 2,055</i></b> <br>Between 1000-1500 CC - <b><i>INR 3,132</i></b> <br>More than 1500 CC - <b><i>INR 8630</i></b></p>
      <div class="row">
      <label for="premiumcalculation-3"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-5"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="premiumcalculation-5" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Quick Tip!</h2>
      <p><b>Just add them!</b> <br><br> OD Premium + TP Premium is what you will have to pay! <br><br> <b>But hold on!</b> Its not over.<br>Dont you want to know about discounts?</p>
      <div class="row">
      <label for="premiumcalculation-4"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-6"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
  
  <input id="premiumcalculation-6" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>NCB Discounts</h2>
      <p>For every year you dont make a claim, you get a discount on the <i>"OD premium"</i> when you renew your policy.</p>
      <p>The discount on OD increases every year <br><b>0% -> 20% -> 25% -> 35% ->45% -> 50%</b>.
      <p>If you make a claim in any of the years, your NCB re-starts from 0%</p>
      <div class="row">
      <label for="premiumcalculation-5"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-7"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="premiumcalculation-7" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Additional Discounts</h2>
      <p>Every insurance company offers an additional discount on the <i>"OD Premium"</i>!</p> <p><b>This discount varies from 0% to 60%.</b></p>
      <p>Choose wisely! Look for reputation and service feedbacks as well!</p>
      <div class="row">
      <label for="premiumcalculation-6"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-8"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="premiumcalculation-8" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Additional Features</h2>
      <p>You will have to pay an additional premium for additional features you may opt for.</p>
      <p>A classic exampe is the <b>Zero Depreciation Add-on</b>, known as <i>Bumper to Bumper cover</i></p>
      <div class="row">
      <label for="premiumcalculation-7"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-9"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
    <input id="premiumcalculation-9" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Now Calculate!</h2>
      <p>You Total Premium is :</p>
      <p><b>(</b>OD Premium <b>+</b> Additional Features <b>-</b> NCB Discount <b>-</b> Additional Discount<b>)</b><b> + </b> TP Premium</b></p>
      <p><b>Complex?</b> <br>Dont worry, we are here to help you calculate it online!</p>
      <a href="/car-insurance"><label>Calculate Premium Online</label></a>
      <div class="row">
      <label for="premiumcalculation-8"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-10"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="premiumcalculation-10" name="infocard-set-2" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Kudos!</h2>
      <p>No one can beat you when it comes to premium calculation!</p>
      <p>If you generate a quote now, you may better understand the breakup!</p>
      <a href="/car-insurance"><label>Generate a Quote</label></a>
      <div class="row">
      <label for="premiumcalculation-9"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="premiumcalculation-0"><i class="material-icons">autorenew</i></label>
      </div>
    </div>
  </div>


</div>
