<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="inscompanies-0" name="infocard-set-4" type="radio" checked/>
  <div infocard>
    <div class="content">
    <img src="/image/stars.svg" style="width: 104px">
      <h2>Insurance Companies</h2>
      <p>Flip through for more info on insurance companies we are associated with! </p>
      <label for="inscompanies-1">Start Flipping</label>
    </div>
  </div>
  
  <input id="inscompanies-1" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Two Types</h2>
      <p>There are two types of Insurance Companies.</p>
      <p><i><b>(Life Insurance Companies)</b></i><br>Ones that insure Life.<br>
         <i><b>(General Insurance Companies)</b></i><br>Ones that insure Non-Life (Eg: Car, Health, Home etc) 
     </p>
      <div class="row">
      <label for="inscompanies-0"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-2"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="inscompanies-2" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>How Many?</h2>
      <p>As on date, there are <b>30</b> General Insurance companies and <b>12</b> Life Insurance companies in India.</p>
      <p>
      <a href="https://en.wikipedia.org/wiki/List_of_insurance_companies_in_India" target="_blank">Click here for the list of companies.</a>
      <div class="row">
      <label for="inscompanies-1"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-3"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
    <input id="inscompanies-3" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Top General Insurers</h2>
      <p>Market share of some major General Insurance Companies</p>
      <p>United India  - <b><i>12.31%</i></b><br>
      Bajaj Allianz - <b><i> 5.84%</i></b><br>
      HDFC ERGO - <b><i> 4.64%</i></b><br>
      IFFCO-Tokio   - <b><i> 4.04%</i></b><br>
      Bharti AXA - <b><i> 1.04%</i></b><br>
      <div class="row">
      <label for="inscompanies-2"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-4"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
  <input id="inscompanies-4" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Top Life Insurers</h2>
      <p>Major Life Insurance Companies</p>
      <p>LIC<br>
      SBI Life <br>
      ICICI <br>
      MAX Life <br>
      Birla Sunlife <br>
      <div class="row">
      <label for="inscompanies-3"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-5"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>

  <input id="inscompanies-5" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Factors!</h2>
      <p>Research on the following factors before choosing your insurer - </p>
      <p><i>Service Levels</i> <b>| </b>
      <i>Claims Settlement Ratio</i> <b>| </b>
      <i>Compliant Resolution Ratio</i> <b>| </b>
      <i>Volume of Business</i> <b>| </b>
      Brand Value <br><br>
      <b>Check out the Public Disclosures</b><br>
      <a href="https://www.irdai.gov.in/ADMINCMS/cms/NormalData_Layout.aspx?page=PageNo764&mid=31.1" target="_blank">Life Insurers</a><br>
      <a href="https://www.irdai.gov.in/ADMINCMS/cms/NormalData_Layout.aspx?page=PageNo765&mid=31.2" target="_blank">General Insurers</a></p>

      <div class="row">
      <label for="inscompanies-4"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-6"><i class="material-icons">keyboard_arrow_right</i></label>
      </div>
    </div>
  </div>
    <input id="inscompanies-6" name="infocard-set-4" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Hurray!</h2>
      <p>Now that you have an idea about the Insurance Companies, why not see their quotes?</p>
      <a href="/car-insurance"><label>Generate a Quote</label></a>
      <div class="row">
      <label for="inscompanies-5"><i class="material-icons">keyboard_arrow_left</i></label>
      <label for="inscompanies-0"><i class="material-icons">autorenew</i></label>
      </div>
    </div>
  </div>

</div>
