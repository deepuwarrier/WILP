<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="insstories-0" name="infocard-set-5" type="radio" checked/>
  <div infocard>
    <div class="content">
      <h2>Must hear Stories</h2>
      <p>Flip through a heart warming story. The characters are real! </p>
      <label for="insstories-1">Start Flipping</label>
    </div>
  </div>
  <input id="insstories-1" name="infocard-set-5" type="radio"/>
  <div infocard>
    <div class="content">
      <h2>Slide 1/X</h2>
      <p>There are two basic components to your premium</p>
      <p>1. Own Damage Premium </p><p>2. Third Party Premium</p>
      <label for="insstories-2"><i class="material-icons">keyboard_arrow_right</i></label>
      <label for="insstories-0"><i class="material-icons">keyboard_arrow_left</i></label>
    </div>
  </div>
  
</div>
