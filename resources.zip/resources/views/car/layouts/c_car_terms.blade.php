<div data-aos="zoom-in-up" data-aos-duration="600" infocard-stack>

  <input id="getquote-0" name="infocard-set-7" type="radio" checked/>
  <div infocard>
    <div class="content">
      <h2 style="color: #00669c">Confident Now?</h2>
      <p>Why not generate an online quote for your car insurance!! </p>
      <a href="/car-insurance"><label>Get a Quote</label></a>
    </div>
  </div>
</div>
