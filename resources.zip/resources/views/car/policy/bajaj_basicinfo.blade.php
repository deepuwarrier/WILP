<div>
@include('car.quote.quote_package_info',$modal_value)
@include('car.quote.quote_premium_breakup',$modal_value)
<form name="save_pdf" id="save_pdf" action="{{ URL::route('car.quote.getpdf') }}" method="POST" target="_blank">
</form>
</div>
<!-- status href contaoner -->
<input type="hidden" id="premiumstatus" name="premiumstatus" value="{{route('car.policy.premiumstatus')}}">
<input type="hidden" id="premiumreconfirm" name="premiumreconfirm" value="{{route('car.policy.premiumreconfirm')}}">
<input type="hidden" id="premiummissmatch" name="premiummissmatch" value="{{route('car.policy.premiummissmatchstatus')}}">
<input type="hidden" id="badresponse" name="badresponse" value="{{route('car.policy.badresponse')}}">

<input type="hidden" id="inspection_status" name="inspection_status" value="{{route('car.policy.inspection_status')}}">
<input type="hidden" id="init_payment" name="init_payment"
 value="{{route('car.policy.initiate_payment')}}">
 
<!-- end status href contaoner -->
<div class="wizard-container">
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:150px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right"  href="{{URL::to('car-insurance')}}">Change</a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Generating Policy For:</h6>
                    </div>
                </div>
                <div class="row content" style="text-align: left">
                    <span class="label label-default">{{ $user_data->make_name }}</span>
                    <span class="label label-default">{{ $user_data->model_name }}</span>
                    <span class="label label-default">{{ $user_data->car_fuel }}</span>
                    <span class="label label-default">{{ $user_data->variant_name }}</span>
                    <span class="label label-default">{{ $user_data->car_rto }}</span>
                    <span class="label label-default">{{ $user_data->car_year }}</span>
                </div>
            </div>
        </div>
    </div>
    <!-- wizard container -->
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:150px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right" href="{{URL::route('car-insurance.getquote',$user_data->session_id)}}">Change</a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information :</h6>
                    </div>
                </div>
                <table class="table customtable">
                    <tbody>
                        <tr>
                            @if($user_data->type_of_business === 'rollover')
                            @php
                                $diff = date('Y') - $user_data->car_year;
                             @endphp
                             @if($diff === 1)
                                <td>Purchase Date</td>
                             @else
                                <td>Registration Date</td>
                             @endif
                            @else
                            <td>Purchase Date</td>
                            @endif
                            <td class="text-right">
                                {{ date('d/m/Y',strtotime(str_replace('-','/',$user_data->car_registration_date))) }}
                            </td>

                            @if($user_data->type_of_business === 'rollover')
                                <td>Expiry Date</td>
                                <td class="text-right">
                                    {{ date('d/m/Y',strtotime(str_replace('-','/',$user_data->policy_expiry_date))) }}
                                </td>
                            @else
                            <td>Start Date</td>
                            <td class="text-right">
                                {{ date('d/m/Y',strtotime(str_replace('-','/',$user_data->policy_start_date))) }}
                            </td>
                            @endif
                        </tr>
                        <tr>
                            <td>IDV</td>
                            <td class="text-right">
                                {{ $quote->idv }}
                            </td>
                            <td>Eligible NCB</td>
                            <td class="text-right" id="ncb">
                                {{ $quote->current_ncb }}%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row card customcard" style="min-height:150px">
            <div class="col-xs-4 logobox">
                @if(isset($logo))
                <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                @else
                <img src="{{asset('image/logos/')}}/{{$quote->insurer_id}}.png" alt="Insurer Logo">
                @endif
            </div>
            <div class="col-xs-8 rightalign_ss" style="text-align: right">
                <h6>{{ $quote->getCmpName() }}</h6>
               
                <h5 class="card-title" style="font-size:30px">&#8377; <span id="passed_payment">{{ $quote->getTotalpremium() }}</span></h5>

                <a href="javascript:void(0)">
                    <i class="material-icons iconcustom modal_details" 
                    data-modal="packageInfo_{{$quote->getProductid() }}" 
                    data-trans_code="{{$quote->getTransCode()}}"
                    data-session_id="{{ $user_data->session_id }}" 
                    data-producid ="{{$quote->getProductid() }}"
                    data-toggle="tooltip" 
                    data-placement="top" id="" 
                    title="Package Info">stars</i></a>

                <a href="javascript:void(0)">
                    <i class="material-icons iconcustom modal_details" 
                    data-modal="premiumBreakup_{{ $quote->getProductid() }}" 
                    data-trans_code="{{$quote->getTransCode()}}"
                    data-session_id="{{ $user_data->session_id }}" 
                    data-producid ="{{ $quote->getProductid() }}" 
                    data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</i></a>
            </div>
        </div>
    </div>

</div>
<div id="modal_div"></div>
