<div>
@include('car.quote.quote_package_info',$modal_value)
@include('car.quote.quote_premium_breakup',['modal_value'=>$modal_value, 'policy_type' => $car_detail['policy_type_selection'], 'business_type' => $car_detail['typeOfBusiness'], 'od_start_date' => $car_detail['od_start_date'], 'od_end_date' => $car_detail['od_end_date'],'tp_start_date' => $car_detail['tp_start_date'],'tp_end_date' => $car_detail['tp_end_date']])
<form name="save_pdf" id="save_pdf" action="{{ URL::route('car.quote.getpdf') }}" method="POST" target="_blank">
</form>
</div>
<!-- status href contaoner -->
<input type="hidden" id="premiumstatus" name="premiumstatus" value="{{route('car.policy.premiumstatus')}}">
<input type="hidden" id="premiumreconfirm" name="premiumreconfirm" value="{{route('car.policy.premiumreconfirm')}}">
<input type="hidden" id="premiummissmatch" name="premiummissmatch" value="{{route('car.policy.premiummissmatchstatus')}}">
<input type="hidden" id="badresponse" name="badresponse" value="{{route('car.policy.badresponse')}}">

<input type="hidden" id="inspection_status" name="inspection_status" value="{{route('car.policy.inspection_status')}}">
<input type="hidden" id="init_payment" name="init_payment"
 value="{{route('car.policy.initiate_payment')}}">
 
<!-- end status href contaoner -->
<div class="wizard-container">
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:150px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right"  href="{{URL::to('car-insurance')}}">Change</a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Generating Policy For:</h6>
                    </div>
                </div>
                <div class="row content" style="text-align: left">
                    @if(isset($car_detail) && !empty($car_detail))
                    <span class="label label-default">{{ $car_detail['make_name'] }}</span>
                    <span class="label label-default">{{ $car_detail['model_name'] }}</span>
                    <span class="label label-default">{{ !empty($car_detail['fuel'])?$car_detail['fuel']:$car_detail['fuel_type'] }}</span>
                    <span class="label label-default">{{ $car_detail['variant_name'] }}</span>
                    <span class="label label-default">{{ $car_detail['rto'] }}</span>
                    <span class="label label-default">{{ $car_detail['year'] }}</span>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <!-- wizard container -->
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:150px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right" href="{{URL::route('car-insurance.getquote',$trans_code)}}">Change</a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information :</h6>
                    </div>
                </div>
                <div class="div_customtable" style="text-align: left">
                    <div class="col-md-12">
                        <div class="row">
                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                                @php
                                    $diff = date('Y') - $predefinedData['year'];
                                @endphp
                                @if($diff === 1)
                                    <div class="col-sm-3">
                                        <span class="p_title">
                                            Purchase Date
                                        </span>
                                    </div>
                                @else
                                    <div class="col-sm-3">
                                        <span class="p_title">
                                            Registration Date
                                        </span>
                                    </div>
                                @endif
                            @else
                                <div class="col-sm-3">
                                    <span class="p_title">
                                        Purchase Date
                                    </span>
                                </div>
                            @endif
                            <div class="col-sm-3">
                                <span class="text-right">
                                    {{ date('d/m/Y',strtotime(str_replace('-','/',$predefinedData['regDate']))) }}
                                </span>
                            </div>

                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                                <div class="col-sm-3">
                                    <span class="p_title">
                                        Expiry Date
                                    </span>
                                </div>
                                <div class="col-sm-3">
                                    <span class="text-right">
                                        {{ date('d/m/Y',strtotime(str_replace('-','/',$predefinedData['policyExpiryDate']))) }}
                                    </span>
                                </div>
                            @else
                                <div class="col-sm-3">
                                    <span class="p_title">
                                        Start Date
                                    </span>
                                </div>
                                <div class="col-sm-3">
                                    <span class="text-right">
                                         {{ date('d/m/Y',strtotime(str_replace('-','/',$predefinedData['policyStartDate']))) }}
                                    </span>
                                </div>
                            @endif
                        </div>
                        <div class="row">
                            <div class="col-sm-3">
                                <span class="p_title">
                                    IDV
                                </span>
                            </div>
                            <div class="col-sm-3">
                                <span class="text-right">
                                     {{ $predefinedData['idv_opted'] }}
                                </span>
                            </div>
                            <div class="col-sm-3">
                                <span class="p_title">
                                    Eligible NCB
                                </span>
                            </div>
                            <div class="col-sm-3">
                                <span class="text-right">
                                    {{ $predefinedData['ncb'] }}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row card customcard h_icons" style="min-height:150px">
            <div class="col-xs-4 logobox">
                @if(isset($logo))
                <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                @else
                <img src="{{asset('image/logos/')}}/{{$predefinedData['insurer_id']}}.png" alt="Insurer Logo">
                @endif
            </div>
            <div class="col-xs-8 rightalign_ss" style="text-align: right">
                
                <h6>{{ $cmp_name }}</h6>
                
                <h5 class="card-title" style="font-size:30px">&#8377; <span id="passed_payment">{{ $predefinedData['totalpremium'] }}</span></h5>

                @if($cmp_name == "Royal Sundram" || substr($cmp_name,0,8) == 'TATA AIG')
                    <img class="logo" src="{{URL::to('/')}}/image/easy_emi.jpg"> 
                @endif
               
                <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="packageInfo_{{$predefinedData['product_id']}}" data-trans_code="{{$predefinedData['trans_code']}}" data-producid ="{{$predefinedData['product_id']}}"data-toggle="tooltip" data-placement="top" id="" title="Package Info">stars</i></a>
               
                <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="premiumBreakup_{{$predefinedData['product_id']}}" data-trans_code="{{$predefinedData['trans_code']}}" data-producid ="{{$predefinedData['product_id']}}" data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</i></a>
            </div>
        </div>
    </div>

</div>
<div id="modal_div"></div>
