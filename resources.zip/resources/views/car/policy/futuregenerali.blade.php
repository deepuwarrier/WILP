@include('car.layouts.inn-hdr')
@include('car.policy.basicinfo')
<input type="hidden" name="proposal_error" id="proposal_error" value="{{ route('car.futuregenerali.proposal_error') }}">
{{-- start form wizard --}}
<div class="row">
    <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
        <div class="card wizard-card" data-color="green" id="wizardProfile">
            <form autocomplete="off" method="post" action="{{ URL::to('/car-insurance/futuregenerali/getpolicy') }}" id="buy_policy_form">
                <div class="wizard-navigation">
                   <ul class="nav nav-pills">
                        @if($redirected)
                            @php
                                $proposer_active = '';
                                $review_active  = 'active';
                            @endphp
                        @else
                            @php
                                $proposer_active = 'active';
                                $review_active  = '';
                             @endphp
                          @endif
                         <li style="width: 20%" class='{{$proposer_active}}'>
                            <a href="#proposer" data-toggle="tab" aria-expanded="">Proposer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#communication" data-toggle="tab">Communication</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#vehicle" data-toggle="tab">Vehicle Details</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#previousinsurer" data-toggle="tab">{{$predefinedData['prev_tab_title']}}</a>
                        </li>
                       <li style="width:20%" class="{{$review_active}}">
                            <a href="#review" data-toggle="tab">Review</a>
                        </li>
                    </ul>
                    <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                    <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                </div>
                <div class="tab-content" id='setdata' data-url='{{ route("car.policy.futuregenerali.setproposaldata") }}'>

                    <div class="tab-pane {{$proposer_active}}" id="proposer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Proposer Details!</h6>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft dark">
                                            <a>
                                                <p>Owner Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8 " style="padding:0">
                                        <div class="labelright">
                                            @if(isset($user_data['type']) && $user_data['type'] == "I")
                                            <?php
$ind = 'checked="true"';
$org = '';
?> @elseif(isset($user_data['type']) &&$user_data['type'] == "O")
                                                <?php
$ind = '';
$org = 'checked="true"';
?> @else
                                                    <?php
$ind = 'checked="true"';
$org = ''
?> @endif
                                                        <?php // temp set manualy individual selected all time
// $ind = 'checked="true"';
// $org = ''
?>
                                                        <div class="radiobutton">
                                                            <input type="radio" name="type" id="Individual" {{$ind}} value="I" data-name="Owner Type" />
                                                            <label for="Individual">INDIVIDUAL</label>
                                                        </div>
                                                        <div class="radiobutton">
                                                            <input type="radio" {{$org}} name="type" id="Organization" value="O" data-name="Owner Type" />
                                                            <label for="Organization">ORGANIZATION</label>
                                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Gender</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            @if(isset($user_data['gender']) && $user_data['gender'] == "M")
                                            <?php
$male = 'checked="true"';
$female = '';
?> @elseif(isset($user_data['gender']) &&$user_data['gender'] == "F")
                                                <?php
$male = '';
$female = 'checked="true"';
?> @else
                                                    <?php
$male = 'checked="true"';
$female = '';
?> @endif
                                                        <div class="radiobutton">
                                                            <input type="radio" name="gender" id="val_radio_male" value="M" data-md-icheck {{$male}} required show-info data-name="Gender" />
                                                            <label for="val_radio_male" class="inline-label required show-info">MALE</label>
                                                        </div>
                                                        <div class="radiobutton">
                                                            <input type="radio" name="gender" id="val_radio_female" value="F" data-md-icheck data-name="Gender" {{$female}}/>
                                                            <label for="val_radio_female" class="inline-label required show-info">FEMALE</label>
                                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input class="form-control required show-info" type="text" data-minYear="{{$minYear}}" id="cust_dob" name="cust_dob" placeholder="dd/mm/yyyy" value="{{$user_data['cust_dob'] or ''}}" data-name="Date of birth">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 organization hidden">

                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Company Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="companyname" value="{{$user_data['companyname'] or ''}}" placeholder="Company Name" id="companyname" class="form-control required show-info" data-name="Company Name">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=" col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Contact Person Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="contactperson" value="{{$user_data['contactperson'] or ''}}" placeholder="Contact Person Name" id="contactperson" class="form-control required show-info" data-name="Contact Person Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Full Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            {{-- <input type="text" name="fullname" value="{{$user_data['firstname'] or ''}} {{$user_data['lastname'] or ''}}" placeholder="Full Name" id="fullname" class="form-control required show-info" data-name="fullname"> --}}
                                            <input type="text" name="fullname" value="{{$fullname or ''}}" placeholder="Full Name" id="fullname" class="form-control required show-info" data-name="fullname">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Email ID</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="email" value="{{$user_data['email'] or ''}}" placeholder="Email" id="email" data-name="Email ID">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Mobile</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" placeholder="10 Digit Mobile Number" class="form-control required show-info" name="mobile" value="{{$user_data['mobile'] or ''}}" id="mobile"  maxlength="10" data-name="Mobile Number">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>PAN Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="pan" placeholder="Pan Number" id="pan" value="{{$user_data['pan'] or ''}}" data-name="PAN Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Aadhar Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="aadharno" placeholder="Aadhar Number" id="aadharno" maxlength="12"  value="{{$user_data['aadharno'] or ''}}" data-name="Aadhar  Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--
                           {{--  <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Customer Sub Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="custSubType" id="custSubType" class="form-control required show-info" data-name="Customer Sub Type">
<option selected  hidden="" disabled="" value="">Select Customer Sub Type</option>
                                                @foreach($clientmaptype as $key => $value)
<?php $selected = (isset($user_data['custSubType']) && $value['id'] == $user_data['custSubType']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nationality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="nationality" id="nationality" class="form-control required show-info" data-name="Nationality">
<option selected  hidden="" disabled="" value="">Select Nationality</option>
                                                @foreach($nationality as $key => $value)
<?php $selected = (isset($user_data['nationality']) && $value['id'] == $user_data['nationality']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            --}} -->
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Martital Status</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="martitalStatus" id="martitalStatus" class="form-control required show-info" data-name="Marital Status">     <option selected  hidden="" disabled="" value="">Select Marital Status</option>
                                            @php
                                                 unset($maritalstatus[0]) @endphp
                                                @foreach($maritalstatus as $key => $value)
<?php $selected = (isset($user_data['martitalStatus']) && $value['id'] == $user_data['martitalStatus']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--
                            {{-- <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Occupation</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="occupation" id="occupation" class="form-control required show-info" data-name="Occupation">
<option selected  hidden="" disabled="" value="">Select Occupation</option>
                                                @foreach($occupation as $key => $value)
<?php $selected = (isset($user_data['occupation']) && $value['id'] == $user_data['occupation']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div> --}} -->
                            
                            <div class="col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>
                                                    Capital

                                                </p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="capital" placeholder="Capital" id="capital" value="{{$user_data['nomineeAge'] or ''}}" data-name="Capital">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="communication">
                        <div class="row">
                            <h6 class="info-text"> Enter the Communication Details!</h6>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House/Apartment Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="houseno" value="{{$user_data['houseno'] or ''}}" placeholder="House Number" id="houseno" data-name="House/Apartment Number" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" value="{{$user_data['street'] or ''}}" name="street" placeholder="Street" id="street" data-name="Street" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="locality" value="{{$user_data['locality'] or ''}}" placeholder="Locality" id="locality" data-name="Locality" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="statecode" id="state" class="form-control required show-info" data-name="State" data-url="{{ URL::to('/car-insurance/futuregenerali/getmaster') }}">
                                                 
                                                <option   hidden="" value="">Select State</option>
                                                @foreach($state as $key => $state_value)
                                                @php $selected = (isset($user_data['statecode']) && $state_value["id"] == $user_data['statecode']) ? 'selected' : '' @endphp
                                                 <option  {{ $selected }} value='{{ $state_value["id"] }}'>{{ strtoupper($state_value["value"]) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="citycode-name">
                                            <select name="citycode" id="city" class="form-control required show-info" data-name="City">
                                            @php $selected = (isset($user_data['city'])) ? 'selected' : ''; @endphp
                                                <option hidden=""  value="">Select City</option>
                                                @foreach($city as $key => $value)
                                                @php $selected = (isset($user_data['citycode']) && $value["id"] == $user_data['citycode']) ? 'selected' : '' @endphp
                                                <option  {{ $selected }} class='city_option' value='{{ $value["id"] }}'>{{ strtoupper($value['value']) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="pincode" value="{{$user_data['pincode'] or ''}}" placeholder="Pincode" id="pincode"  maxlength="6" data-name="Pincode">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--
                           {{--  <h6 class="info-text col-sm-12">Enter The Driver Information</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">

                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="citycode-name">
                                            <input type="text" class="form-control show-info" name="driver_name" placeholder="Driver Name" id="driver_name" value="{{$user_data['driver_name'] or ''}}" data-name="Driver Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Driver Gender</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <div class="radiobutton">
                                                <input type="radio" name="driver_gender" id="val_radio_male_d" value="M" data-md-icheck checked="" required data-name="Driver Gender" />
                                                <label for="val_radio_male_d" class="inline-label required show-info">MALE</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="driver_gender" id="val_radio_female_d" value="F" data-md-icheck data-name="Driver Gender" />
                                                <label for="val_radio_female_d" class="inline-label required show-info">FEMALE</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input class="form-control required show-info" type="text" name="driver_dob" placeholder="dd/mm/yyyy" id="driver_dob" value="{{$user_data['driver_dob'] or ''}}" data-name="Date of birth">

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Qualification</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="qualification" id="qualification" class='form-control required show-info' data-name="Qualification">
<option selected  hidden="" disabled="" value="">Select Qualification</option>
                                                @foreach($driverqualification as $key => $value )
@php $selected = (isset($user_data['qualification']) && $value['id'] == $user_data['qualification']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{ $value['id'] }} ">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Experience</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="experience" id="experience" class='form-control required show-info' data-name="Experience">
<option selected  hidden="" disabled="" value="">Select Experience</option>
                                                @foreach($driverexperience as $key => $value )
@php $selected = (isset($user_data['experience']) && $value['id'] == $user_data['experience']) ? 'selected' : '' @endphp
                                                <option  {{$selected}} value="{{ $value['id'] }} ">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if('rollover' == $predefinedData['typeOfBusiness'] && 'Y' == $predefinedData['claim'] )
                            <div class="col-sm-4 ">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Claim History</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="claimHistory" id="claimHistory" class='form-control required show-info' data-name="Driver Claim History">
<option selected  hidden="" disabled="" value="">Select Claim History</option>
                                                @foreach($claimhistory as $key => $value )

@php $selected = (isset($user_data['claimHistory']) && $value['id'] == $user_data['claimHistory']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{ $value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 ">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>No Of Accidents</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info" name="noOfAccidents" placeholder="No Of Accidents" id="noOfAccidents" value="{{$user_data['noOfAccidents'] or ''}}" data-name="No Of Accidents">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @else
                            <input type="hidden" name="noOfAccidents" value="0">
                            <input type="hidden" name="claimHistory" value="1">
                            @endif
                        </div>
                         --}} -->
                         </div>
                    </div>
                    <div class="tab-pane" id="vehicle">
                        <div class="row">
                            <h6 class="info-text"> Enter the Vehicle Details!<span class="req"></span></h6>
                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Reg No.</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8 labelright">
                                        <div class="row">
                                            <div class="col-xs-3 clearall">
                                                <div class="form-group is-empty regprefill">
                                                    <input placeholder="{{ $car_detail['rto'] }}" value="{{ $car_detail['rto'] }}" id="rtono" disabled="" class="form-control" type="text">
                                                </div>
                                            </div>
                                            <div class="col-xs-9">
                                                <div class="form-group is-empty">
                                                    <input type="text" class="form-control required show-info" name="regno" id="reg-no" style="text-transform: uppercase;" value="{{$user_data['regno'] or ''}}" data-name="Registration Number" placeholder="MH-01-AB-1234">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Engine No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="engno" value="{{$user_data['engno'] or ''}}" placeholder="Engine Number" id="eng-no" value="" data-name="Engine No">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Chassis No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="chassisno" value="{{$user_data['chassisno'] or ''}}" placeholder="Chassis Number" id="chassis-no" data-name="Chassis No">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Electrical Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="electrical" id="electrical" class='form-control show-info ' data-name="Electrical Accessories">

<?php $selected = (isset($user_data['electrical'])) ? 'selected' : '';?>
                                                <option {{$selected}} value="" selectd>Nil</option>
                                                @foreach($elect_ass as $key => $value)
<?php $selected = (isset($user_data['electrical']) && $value == $user_data['electrical']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Non Electrical Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="non_electrical" id="non_electrical" class='form-control ' data-name="Non Electrical Accessories">
<?php $selected = (isset($user_data['non_electrical'])) ? 'selected' : '';?>
                                                <option {{$selected}} value="" selected>Nil</option>
                                                @foreach($non_elect_ass as $key => $value)
<?php $selected = (isset($user_data['non_electrical']) && $value == $user_data['non_electrical']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Year of Manufacturing</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="yom_selected" id="yom_selected" data-name="Year of Manufacturing" class='form-control show-info required'>
<?php $selected = (isset($user_data['yom_selected'])) ? '' : 'selected';?>
                                                <option {{$selected}} hidden="" disabled="" value="">Year of Manufacturing</option>
                                                @foreach($year_select as $key => $value)
<?php $selected = (isset($user_data['yom_selected']) && $value == $user_data['yom_selected']) ? 'selected' : ''?>
                                                <option value="{{ $value }}" {{$selected}}>{{ $value }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 ">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Color</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="color" placeholder="Color" id="color" class="form-control required show-info" data-name="Color">
<option selected  hidden="" disabled="" value="">Select Color</option>
                                                @foreach($color as $key => $value)
@php $selected = (isset($user_data['color']) && $value['id'] == $user_data['color']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                           <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Body Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="bodyType" id="bodyType" class="form-control required show-info" data-name="Body Type">
<option selected  hidden="" disabled="" value="">Select Body Type</option>
                                                @foreach($vehiclebody as $key => $value)
        @php $selected = (isset($user_data['bodyType']) && $value['id'] == $user_data['bodyType']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">{{$value['value'] }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                             <!--
                     {{--   <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Garage Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="garageType" id="garageType" class="form-control required show-info" data-name="Garage Type">
<option selected  hidden="" disabled="" value="">Select Garage Type</option>
                                                @foreach($garagetype as $key => $value)
@php $selected = (isset($user_data['garageType']) && $value['id'] == $user_data['garageType']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">{{$value['value'] }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Daily Millage</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="dailyMillage" id="dailyMillage" class="form-control required show-info" data-name="Daily Millage">
<option selected  hidden="" disabled="" value="">Select Daily Millage</option>
                                                @foreach($dailymillage as $key => $value)
@php $selected = (isset($user_data['dailyMillage']) && $value['id'] == $user_data['dailyMillage']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">{{strtoupper($value['value'])}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Road Type Codes</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="roadTypeCodes" id="roadTypeCodes" class="form-control required show-info" data-name="Road Type Codes">
<option selected  hidden="" disabled="" value="">Select Road Type Codes</option>
                                                @foreach($roadtype as $key => $value)
@php $selected = (isset($user_data['roadTypeCodes']) && $value['id'] == $ser_data['roadTypeCodes']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Preferred Repair</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="preferredRepair" id="preferredRepair" class="form-control required show-info" data-name="Preferred Repair">
<option selected  hidden="" disabled="" value="">Select Road Preferred Repair</option>
                                                @foreach($repair as $key => $value)
@php $selected = (isset($user_data['preferredRepair']) && $value['id'] == $user_data['preferredRepair']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}">{{strtoupper($value['value'])}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Current Millage</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="currentMillage" placeholder="Current Millage" id="currentMillage" value="{{$user_data['currentMillage'] or ''}}" data-name="Current Millage">
                                        </div>
                                    </div>
                                </div>
                            </div>
                              --}} -->
                        </div>
                    </div>

                    <div class="tab-pane" id="previousinsurer">
                        <div class="row">
                            <h6 class="info-text"> {{$predefinedData['prev_text']}}</h6>
                            @if($predefinedData['typeOfBusiness'] == 'rollover')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select id="previnsurance" name="previnsurance" class='form-control show-info {{ $requiredRollover }}' data-name="Previous Insurer">

                                                <option selected  hidden="" disabled="" value="">Previous Insurer</option>
                                                <!--
                                                @foreach($insurer as $insurer_key => $insurer_value )


                                                <option  value="{{ $insurer_value['id'] }}">{{ strtoupper($insurer_value['value'])}}</option>
                                                @endforeach
                                                -->
                                                @php
                                                 $class = (isset($user_data['previnsurance']))? "selected" : "";
                                                 @endphp
                                                <option {{ $class }} value="40062645">
                                                 Bajaj Allianz General Insurance Co Ltd.
                                                 </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info {{ $requiredRollover }}" name="policyno" value="{{$user_data['policyno'] or ''}}" placeholder="Policy Number" id="policyno" data-name="Policy Number">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Policy Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="previousPolicyType" id="previousPolicyType" class="form-control show-info {{ $requiredRollover }}" data-name="Previous Policy Type">
<option selected  hidden="" disabled="" value="">Select Previous Policy Typ</option>
                                                @foreach($policy_type as $key => $value)
<?php $selected = (isset($user_data['previousPolicyType']) && $value == $user_data['previousPolicyType']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if($predefinedData['claim'] === 'Y')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Claimhistory</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="numberClaims" id="numberClaims" class='form-control required show-info {{ $requiredRollover }}' data-name="Claimhistory">
<option selected  hidden="" disabled="" value="">Select Claimhistory</option>
                                                @foreach($claimhistory as $key => $value )
<?php $selected = (isset($user_data['numberClaims']) && $value['id'] == $user_data['numberClaims']) ? 'selected' : ''?>

                                                <option  {{$selected}} value="{{ $value['id'] }}">{{strtoupper($value['value'])}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="{{$user_data['nomineeName'] or ''}}" name="nomineeName" placeholder="Nominee Name" id="nomineeName" data-name="Nominee Name">
                                            <span class="form-control-bar "></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Age</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="nomineeAge" placeholder="Nominee Age" id="nomineeAge" value="{{$user_data['nomineeAge'] or ''}}" data-name="Nominee Age">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Relation</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="nomineeRel" placeholder="Nominee Relation" id="nomineeRel" class="form-control required show-info" data-name="Nominee Relation">
                                                @php $selected = (isset($user_data['nomineeRel'])) ? '' : 'selected'; @endphp
                                                <option {{ $selected }}  hidden="" disabled="" value=""> Select Nominee Relation </option>
                                                @foreach($nomineerelationship as $key => $value)
                                                @php $selected = (isset($user_data['nomineeRel']) && $value['id'] == $user_data['nomineeRel']) ? 'selected' : '' @endphp
                                                <option {{$selected}} value="{{$value['id'] }}"> {{strtoupper($value['value'])}} </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                             <!--
                            {{--
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Owner</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info {{ $requiredRollover }}" name="policyOwner" placeholder="Policy Owner" id="policyOwner" value="{{$user_data['policyOwner'] or ''}}" data-name="Policy Owner">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Ncb Declaration Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info {{ $requiredRollover }}" name="ncbDeclarationType" placeholder="Ncb Declaration Type" id="ncbDeclarationType" value="{{$user_data['ncbDeclarationType'] or ''}}" data-name="Ncb Declaration Type">
                                        </div>
                                    </div>
                                </div>
                            </div>
 --}} -->

                        </div>
                    </div>
                    <div class="tab-pane {{$review_active}}" id="review">

                        <h6 class="info-text"> Review the data you entered!</h6> @include("car.policy.preview")


                    </div>
                </div>
                @foreach($masterData as $key => $value)
                <input type="hidden" name="master_{{ $key }}" id="master_{{ $key }}" value="{{ $value }}">
                @endforeach
                <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}"> @foreach($predefinedData as $key => $value)
                <input type="hidden" name="{{ $key }}" id="{{ $key }}" value="{{ $value }}"> @endforeach {{ csrf_field() }} {{ method_field('post ') }}
                <input type="hidden" name="redirected" id="redirected" value="{{$redirected}}"> {{ csrf_field() }} {{ method_field('post ') }}
                <input type="hidden" name="return_page" id="return_page" value="{{ route('car.policy.futuregenerali.returnPage') }}">

                <div class="wizard-footer">
                    <div class="pull-right">
                        <input data-focus='modal_div' class="btn scrolltop btn-next btn-info" name="next" value="Next" type="button">
                        <input data-focus='modal_div' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="car-btn-pay">
                    </div>
                    <div class="pull-left">
                        <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
                    </div>
                    <div class="clearfix"></div>
                </div>
        </div>
    </div>
</div>
<input type="hidden" id="return_page" name="return_page" value="{{route('car.policy.futuregenerali.returnPage')}}">
  <input type="hidden" name="redirected" id="redirected" value="{{$redirected}}">  </form>
<div id="pay_form"></div>
</div>
</div>
<!-- fnished form wizard -->
@include('car.layouts.inn-ftr ')
<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation_helper.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/car/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/car/policy/futuregenerali.js ') }}"></script>\
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });
</script>
