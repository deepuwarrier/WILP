<style>
 .info_text{
   color: #4E4A4A;
  }
 .previewheight{
    min-height: 300px !important;
 }
</style>
<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#proposer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Proposer :</h6>
                    </div>
                </div>
                <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="proposer_preview">
                   
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#communication">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Communication :</h6>
                    </div>
                </div>
                <div class="row" style="font-size: 12px;">
                    <div class="col-sm-12" style="text-align: left" id="communication_preview">
                   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#vehicle">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Vehicle Details :</h6>
                    </div>
                </div>
                <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="vehicle_preview">
                   
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#previousinsurer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Previous Insurer :</h6>
                    </div>
                </div>
                <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="previousinsurer_preview">
                   
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <div class="col-md-12 radiobutton uk-form uk-form-row">
    <label>
        <input   name="disclaimer" type="checkbox" value="disclaimer"
        id="disclaimer" >

        I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.
    </label>
</div>

