<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#proposer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Proposer :</h6>
                    </div>
                </div>
                <table class="table customtable equal-width" id="proposer_preview">
                    <tbody>
                        <tr>
                            <td>Registration Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                            <td>Expiry Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                        </tr>
                        <tr>
                            <td>IDV</td>
                            <td class="text-right">
                                5,35,600
                            </td>
                            <td>Eligible NCB</td>
                            <td class="text-right">
                                20%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#communication">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Communication :</h6>
                    </div>
                </div>
                <table class="table customtable equal-width" id="communication_preview">
                    <tbody>
                        <tr>
                            <td>Registration Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                            <td>Expiry Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                        </tr>
                        <tr>
                            <td>IDV</td>
                            <td class="text-right">
                                5,35,600
                            </td>
                            <td>Eligible NCB</td>
                            <td class="text-right">
                                20%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#vehicle">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Vehicle Details :</h6>
                    </div>
                </div>
                <table class="table customtable equal-width" id="vehicle_preview">
                    <tbody>
                        <tr>
                            <td>Registration Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                            <td>Expiry Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                        </tr>
                        <tr>
                            <td>IDV</td>
                            <td class="text-right">
                                5,35,600
                            </td>
                            <td>Eligible NCB</td>
                            <td class="text-right">
                                20%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @if($predefinedData['typeOfBusiness'] == 'rollover')
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#previousinsurer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Previous Insurer :</h6>
                    </div>
                </div>
                <table class="table customtable equal-width" id="previousinsurer_preview">
                    <tbody>
                        <tr>
                            <td>Registration Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                            <td>Expiry Date</td>
                            <td class="text-right">
                                22/10/2016
                            </td>
                        </tr>
                        <tr>
                            <td>IDV</td>
                            <td class="text-right">
                                5,35,600
                            </td>
                            <td>Eligible NCB</td>
                            <td class="text-right">
                                20%
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @endif
</div>
<div class="col-md-12 radiobutton uk-form uk-form-row">
    <label>
        <input   name="disclaimer" type="checkbox" value="disclaimer"
        id="disclaimer" >

        I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.
    </label>
</div>
