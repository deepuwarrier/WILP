@include('car.layouts.inn-hdr')
@include('car.policy.basicinfo')
<input type="hidden" name="proposal_error" id="proposal_error" value="{{ route('car.rsgi.proposal_error') }}">
{{-- start form wizard --}}
<div class="row">
    <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
        <div class="card wizard-card" data-color="green" id="wizardProfile">
            <form autocomplete="off" method="post" action="{{ URL::route('car.policy.royal_sundaram.getpolicy')}}" id="buy_policy_form">
                <input type="hidden" value="{{$predefinedData['trans_code']}}" name="trans_code" id="trans_code" />
                <input type="hidden" value="{{$predefinedData['quote_id']}}" name="quote_id" id="quote_id" />
                <input type="hidden" value="{{$predefinedData['engineCapacityAmount']}}" name="engineCapacityAmount" id="engineCapacityAmount" />
                <div class="wizard-navigation">
                   <ul class="nav nav-pills">
                        @if($redirected)
                            @php
                                $proposer_active = '';
                                $review_active  = 'active';
                            @endphp
                        @else
                            @php
                                $proposer_active = 'active';
                                $review_active  = '';
                             @endphp
                          @endif
                         <li style="width: 20%" class='{{$proposer_active}}'>
                            <a href="#proposer" data-toggle="tab" aria-expanded="">Proposer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#communication" data-toggle="tab">Communication</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#vehicle" data-toggle="tab">Vehicle Details</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#previousinsurer" data-toggle="tab">{{$predefinedData['prev_tab_title']}}</a>
                        </li>
                       <li style="width:20%" class="{{$review_active}}">
                            <a href="#review" data-toggle="tab">Review</a>
                        </li>
                    </ul>
                    <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                    <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                </div>
                <div class="tab-content" id='setdata' data-url='{{ route("car.policy.setproposaldata") }}'>
                    <div class="tab-pane {{$proposer_active}}" id="proposer">
                        <div class="row">
                            <h6 class='info-text'>Enter the Proposer Details!</h6>
                          

                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Gender</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            @if(isset($user_data['gender']) && $user_data['gender'] == "M")
                                            <?php
$male = 'checked="true"';
$female = '';
?> @elseif(isset($user_data['gender']) &&$user_data['gender'] == "F")
                                            <?php
$male = '';
$female = 'checked="true"';
?> @else
<?php
$male = 'checked="true"';
$female = '';
?> @endif
                                            <div class="radiobutton">
                                                <input type="radio" name="gender" id="val_radio_male" value="M" data-md-icheck {{$male}} required show-info data-name="Gender" />
                                                       <label for="val_radio_male" class="inline-label required show-info">MALE</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="gender" id="val_radio_female" value="F" data-md-icheck data-name="Gender" {{$female}}/>
                                                <label for="val_radio_female" class="inline-label required show-info">FEMALE</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input class="form-control required show-info" type="text" data-minYear="{{$minYear}}" id="cust_dob" name="cust_dob" placeholder="dd/mm/yyyy" value="{{$user_data['cust_dob'] or ''}}" data-name="Date of birth">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 organization hidden">

                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Company Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="companyname" value="{{$user_data['companyname'] or ''}}" placeholder="Company Name" id="companyname" class="form-control required show-info" data-name="Company Name">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class=" col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Contact Person Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="contactperson" value="{{$user_data['contactperson'] or ''}}" placeholder="Contact Person Name" id="contactperson" class="form-control required show-info" data-name="Contact Person Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Name as per your car RC</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            {{-- <input type="text" name="fullname" value="{{$user_data['firstname'] or ''}} {{$user_data['lastname'] or ''}}" placeholder="Full Name" id="fullname" class="form-control required show-info" data-name="fullname"> --}}
                                            <input type="text" name="fullname" value="{{$fullname or ''}}" placeholder="Full Name" id="fullname" class="form-control required show-info" data-name="fullname">
                                        </div>
                                    </div>
                                </div>
                            </div>
                 
                               <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Occupation</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="occupation" id="occupation" class="form-control required show-info" data-name="Occupation">
                                  <option selected  hidden="" disabled="" value="">Select Occupation</option>
                                                @foreach($occupation as $key => $value)
<?php $selected = (isset($user_data['occupation']) && $value['id'] == $user_data['occupation']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value['id'] }}">
                                                    {{strtoupper($value['value'])}}
                                                </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Email ID</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="email" value="{{$user_data['email'] or ''}}" placeholder="Email" id="email" data-name="Email ID">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Mobile</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" placeholder="10 Digit Mobile Number" class="form-control required show-info" name="mobile" value="{{$user_data['mobile'] or ''}}" id="mobile" maxlength="10" data-name="Mobile Number">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Aadhar Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="aadharno" placeholder="Aadhar Number" id="aadharno" maxlength="12"  value="{{$user_data['aadharno'] or ''}}" data-name="Aadhar  Number">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="communication">
                        <div class="row">
                            <h6 class='info-text'>Address as per the Car Registration Certificate!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House/Apartment Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="houseno" value="{{$user_data['houseno'] or ''}}" placeholder="House Number" id="houseno" data-name="House/Apartment Number" maxlength="30">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="{{$user_data['street'] or ''}}" name="street" placeholder="Street" id="street" data-name="Street" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="locality" value="{{$user_data['locality'] or ''}}" placeholder="Locality" id="locality" data-name="Locality" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="statecode" id="state" class="form-control required show-info" data-name="State" data-url="{{ URL::route('car.policy.city') }}">
                                           
                                                <option  hidden=""  value="">Select State</option>
                                                @foreach($state as $key => $state_value)
                                                @php $selected = (isset($user_data['statecode']) && $state_value["id"] == $user_data['statecode']) ? 'selected' : '' @endphp
                                                 <option  {{ $selected }} value='{{ $state_value["id"] }}'>{{ strtoupper($state_value["value"]) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="citycode-name">
                                            <select name="citycode" id="city" class="form-control required show-info" data-name="City">
                                               @php $selected = (isset($user_data['city'])) ? 'selected' : ''; @endphp
                                                <option hidden=""  value="">Select City</option>
                                                @foreach($city as $key => $value)
                                                @php $selected = (isset($user_data['citycode']) && $value["id"] == $user_data['citycode']) ? 'selected' : '' @endphp
                                                <option  {{ $selected }} class='city_option' value='{{ $value["id"] }}'>{{ strtoupper($value['value']) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="pincode" value="{{$user_data['pincode'] or ''}}" placeholder="Pincode" id="pincode" maxlength="6" data-name="Pincode">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="card proposalcard">
                                    {{-- <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>My Permannat Registration Same As Above</p>
                                            </a>
                                        </div>
                                    </div> --}}
                                    {{-- <div class="col-sm-8" style="padding:0"> --}}
                                        {{-- <div class="labelright"> --}}
                                        <div class="radiobutton">
                                            <input type="checkbox" class="show-info" name="reg_add_is_same"  id="reg_add_is_same" value="{{$reg_add_is_same}}"  data-name="Pincode" {{$perm_diff}}>
                                        <label for="reg_add_is_same">Communication Address Same As Above</label>
                                        </div>
                                        {{-- </div> --}}
                                    {{-- </div> --}}
                                </div>
                            </div>
                            <div class="col-sm-4 info-label">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p></p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="" data-name="" value="&nbsp;">
                                            <input type="text" name="" data-name="<h6>Communication Address : </h6>" value="&nbsp;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House/Apartment Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="perm_houseno" value="{{$user_data['perm_houseno'] or ''}}" placeholder="House Number" 
                                            id="perm_houseno" data-name="House/Apartment Number" maxlength="30">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="{{$user_data['perm_street'] or ''}}" name="perm_street" placeholder="Street" id="perm_street" data-name="Street" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="perm_locality" id="perm_locality" value="{{$user_data['perm_locality'] or ''}}" placeholder="Locality"  data-name="Locality" maxlength="60">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="perm_statecode" id="perm_state" class="form-control required show-info" data-name="State" data-url="{{ URL::route('car.policy.city') }}">
                                           
                                                <option  hidden=""  value="">Select State</option>
                                                @foreach($state as $key => $state_value)
                                                @php $selected = (isset($user_data['perm_statecode']) && $state_value["id"] == $user_data['perm_statecode']) ? 'selected' : '' @endphp
                                                 <option  {{ $selected }} value='{{ $state_value["id"] }}'>{{ strtoupper($state_value["value"]) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="citycode-name">
                                            <select name="perm_citycode" id="perm_city" class="form-control required show-info" data-name="City">
                                               @php $selected = (isset($user_data['perm_city'])) ? 'selected' : ''; @endphp
                                                <option hidden=""  value="">Select City</option>
                                                @foreach($perm_city as $key => $value)
                                                @php $selected = (isset($user_data['perm_citycode']) && $value["id"] == $user_data['perm_citycode']) ? 'selected' : '' @endphp
                                                <option  {{ $selected }} class='city_option' value='{{ $value["id"] }}'>{{ strtoupper($value['value']) }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 perm">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="perm_pincode" value="{{$user_data['perm_pincode'] or ''}}" placeholder="Pincode"
                                             id="perm_pincode" maxlength="6" data-name="Pincode">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="vehicle">
                        <div class="row">
                            <h6 class='info-text'>Enter the Vehicle Details!</h6>
                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Reg No.</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                       <div class="labelright">

                                                    <input type="text" class="form-control required show-info" name="regno" id="reg-no" style="text-transform: uppercase;" value="{{$user_data['regno'] or ''}}" data-name="Registration Number" placeholder="MH-01-AB-1234">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Engine No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="engno" value="{{$user_data['engno'] or ''}}" placeholder="Engine Number" id="eng-no" value="" data-name="Engine No">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Chassis No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="chassisno" value="{{$user_data['chassisno'] or ''}}" placeholder="Chassis Number" id="chassis-no" data-name="Chassis No">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Year of Manufacturing</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="yom_selected" id="yom_selected" data-name="Year of Manufacturing" class='form-control show-info required'>
<?php $selected = (isset($user_data['yom_selected'])) ? '' : 'selected';?>
                                                <option {{$selected}} hidden="" disabled="" value="">Year of Manufacturing</option>
                                                @foreach($year_select as $key => $value)
<?php $selected = (isset($user_data['yom_selected']) && $value == $user_data['yom_selected']) ? 'selected' : ''?>
                                                <option value="{{ $value }}" {{$selected}}>{{ $value }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Is ownership changed in the past 12 months</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <div class="radiobutton">
                                                <input type="radio" name="ownership_change" id="ownership_change_n" value="N" 
                                                data-md-icheck 
                                                 required show-info 
                                                 data-name="Is Ownership Change" {{isset($ownership_change_n)?$ownership_change_n:''}}/>
                                                       <label for="ownership_change_n" class="inline-label required show-info">No</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="ownership_change" 
                                                id="ownership_change_y" 
                                                value="Y" 
                                                data-md-icheck
                                                 data-name="Is Ownership Change" {{isset($ownership_change_y)?$ownership_change_y:''}}/>
                                                <label for="ownership_change_y" class="inline-label required show-info">Yes</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Voluntary Deductible</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="vd" id="vd" class="form-control show-info required"
                                             data-name="Voluntary Deductible">
<option selected  hidden="" disabled="" value="">Select Voluntary Deductible</option>
                                                @foreach($vd as $key => $value)
<?php $selected = (isset($user_data['vd']) && $value == $user_data['vd']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$value}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Is Vehicle Financed?</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            @if(isset($user_data['vehicle_financed']) && $user_data['vehicle_financed'] == "Y")
                                                @php
                                                {{-- vehicle_financed --}}
                                                    $is_v_y_financed = 'checked="true"';
                                                    $is_v_n_financed = '';
                                                    $hidden = '';
                                                @endphp
                                            @elseif(isset($user_data['vehicle_financed']) && $user_data['vehicle_financed'] == "N")
                                                @php
                                                    $is_v_y_financed = '';
                                                    $is_v_n_financed = 'checked="true"';
                                                    $hidden = 'hidden';
                                                @endphp
                                            @else
                                                @php
                                                    $is_v_y_financed = '';
                                                    $is_v_n_financed = 'checked="true"';
                                                    $hidden = 'hidden';
                                                @endphp
                                            @endif
                                            <div class="radiobutton">
                                                <input type="radio" name="vehicle_financed" id="val_vehicle_financed_y" value="Y" data-md-icheck {{$is_v_y_financed}} required show-info data-name="Is Vehicle Financed?" />
                                                       <label for="val_vehicle_financed_y" class="inline-label required show-info">Yes</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="vehicle_financed" id="val_vehicle_financed_n" value="N" data-md-icheck data-name="Is Vehicle Financed?" {{$is_v_n_financed}}/>
                                                <label for="val_vehicle_financed_n" class="inline-label required show-info">No</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 is_v_financed {{$hidden}}">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Type of Finance</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="type_of_finance" id="type_of_finance" class="form-control show-info {{ $requiredRollover }}" data-name="Type of Finance">
<option selected  hidden="" disabled="" value="">Select Type of Finance</option>
                                                @foreach($type_of_finance as $key => $value)
<?php $selected = (isset($user_data['type_of_finance']) && $value == $user_data['type_of_finance']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 is_v_financed {{$hidden}}">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Financier Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="financierName" placeholder="Financier Name" id="financierName" value="{{$user_data['financierName'] or ''}}" data-name="Financier Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane" id="previousinsurer">
                        <div class="row">
                            <h6 class='info-text'>{{$predefinedData['prev_text']}}
            </h6>
                            @if($predefinedData['typeOfBusiness'] === 'rollover')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer</p>
                                            </a>
                                        </div>
                                    </div>
                                         <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select id="previnsurance" name="previnsurance" class='form-control show-info {{ $requiredRollover }}' data-name="Previous Insurer">
                                                @php $selected = (isset($user_data['previnsurance'])) ? '' : 'selected'; @endphp
                                                <option hidden=""  value="">Previous Insurer</option>
                                                @foreach($insurer as $insurer_key => $insurer_value )
                                                    @php $selected = (isset($user_data['previnsurance']) && $insurer_value['id'] == $user_data['previnsurance']) ? 'selected' : '' @endphp
                                                    <option {{ $selected }}  value="{{ $insurer_value['id'] }}">{{ strtoupper($insurer_value['value'])}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info {{ $requiredRollover }}" name="policyno" value="{{$user_data['policyno'] or ''}}" placeholder="Policy Number" id="policyno" data-name="Policy Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Policy Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="previousPolicyType" id="previousPolicyType" class="form-control show-info {{ $requiredRollover }}" data-name="Previous Policy Type">
<option selected  hidden="" disabled="" value="">Select Previous Policy Type</option>
                                                @foreach($policy_type as $key => $value)
<?php $selected = (isset($user_data['previousPolicyType']) && $value == $user_data['previousPolicyType']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer Address</p>
                                            </a>
                                        </div>
                                    </div>
                                         <div class="col-sm-8" style="padding:0">
                                            <div class="labelright">
                                                <input type="text" class="form-control show-info {{ $requiredRollover }}" 
                                                name="previnsurance_addr" 
                                                value="{{$user_data['previnsurance_addr'] or ''}}"
                                                 placeholder="Previous Insurer Address"
                                                  id="previnsurance_addr" 
                                                  data-name="Previous Insurer Address">
                                           </div>
                                    </div>
                                </div>
                            </div>
                            @if($predefinedData['prev_claim_status'] === 'Y')
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Number of claims</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="claim" id="claim" class="form-control required show-info" data-name="Number of claims">
<option selected  hidden="" disabled="" value="">Select Number of claims</option>
                                                @foreach($nu_of_claim as $key => $value)
<?php $selected = (isset($user_data['claim']) && $value == $user_data['claim']) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$value}}">{{$key}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Total Claim Amount (INR)</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info {{ $requiredRollover }}" name="claimAmountReceived" value="{{$user_data['claimAmountReceived'] or ''}}" placeholder="Total Claim Amount (INR)" id="claimAmountReceived" data-name="Total Claim Amount (INR)">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif
                            @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="{{$user_data['nomineeName'] or ''}}" name="nomineeName" placeholder="Nominee Name" id="nomineeName" data-name="Nominee Name">
                                            <span class="form-control-bar "></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                             <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Age</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                                 <select class="form-control required show-info" name="nomineeAge"  id="nomineeAge" data-name="Nominee Age">
                                                @for($i = 18;$i<=100;$i++)
                                                    {{ $sel = ($i == $user_data['nomineeAge'])? 'selected' : '' }}
                                                    <option value="{{ $i }}" {{$sel}}>{{ $i }}</option>
                                                @endfor
                                            </select>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Relation</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select class="form-control required show-info" name="nomineeRel"  id="nomineeRel" data-name="Nominee Relation">
                                                @foreach($nominee_rel as $key => $value)
                                               @php $sel = ($value == $user_data['nomineeRel'])? 'selected' : '' @endphp
                                                <option value="{{ $value }}" {{$sel}}>
                                                {{ $value }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane {{$review_active}}" id="review">

                        <h6 class='info-text'>Review the data you entered!</h6>

                        @include("car.policy.preview")

                    </div>
                </div>
                <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}"> 
                @foreach($predefinedData as $key => $value)
                    <input type="hidden" name="{{ $key }}" id="{{ $key }}" value="{{ $value }}"> 
                @endforeach 

                <input type="hidden" name="redirected" id="redirected" value="{{$redirected}}"> {{ csrf_field() }} {{ method_field('post ') }}
                <input type="hidden" name="prev_claim_status" id="prev_claim_status" value="{{$predefinedData['prev_claim_status']}}"> 
                                <input type="hidden" name="actual_ncb" id="actual_ncb" value="{{isset($predefinedData['actual_ncb'])?$predefinedData['actual_ncb']:$predefinedData['ncb']}}">
                <input type="hidden" name="return_page" id="return_page" value="{{ route('car.policy.unisompo.returnPage') }}">
                <input type='hidden' name='policy_cmp' id='policy_cmp' value="rsgi">
            </form>
            <div class="wizard-footer">
                <div class="pull-right">
                    <input data-focus='modal_div' class="btn scrolltop btn-next btn-info" name="next" value="Next" type="button">
                    <input data-focus='modal_div' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="car-btn-pay">
                </div>
                <div class="pull-left">
                    <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<div id="pay_form"></div>
<!-- fnished form wizard -->
@include('car.layouts.inn-ftr ')
<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation_lib.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/car/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/car/policy/royal_sundram.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });
</script>
