<select data-md-selectize show-info data-live-search="true"  class='form-control show-info required'
                                            placeholder="Financier Code" id="financierCode" name="financierName" data-name="Financier Code">
                                            <?php foreach ($aa as $key => $value) { ?>
                                           <option value="<?php echo $value['financier_code'] ?>"> <?php echo $value['value'] ?> </option>
                                           <?php } ?>
</select>