<div class="modal fade" id="moreInfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-body">

               <div class="row moreinfomodal">
               <h5 style="text-align: center">Some additional information we though might help you make the purchase decision simpler! </h5>

               <div id="collapse">
                   <div class="card customcard">
                     <div class="col-sm-4 logobox">
                        <img src="{{ URL::asset('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                     </div>
                        <div class="col-sm-4">
                           <h5 class="card-title price">&#8377; {{round($modal_value['totalpremium'])}}</h5>
                           <span class="label label-default extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                        </div>
                        <!-- <div class="col-sm-4 buybutton" style="margin-top: 15px;">
                           <button type="button" class="btn btn-success btn-sm">Buy Now</button>
                        </div> -->
                    
                       <div class="col-md-12">
                           <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingOne">
                                   <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne" class="collapsed">
                                       <h4 class="panel-title">
                                       Pros
                                       <i class="material-icons">keyboard_arrow_down</i>
                                       </h4>
                                   </a>
                               </div>
                           		<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
	                         		<div class="panel-body">
                            			@foreach($car_insure_pros as $values)
                            				<p>{{$values}}</p>
                            			@endforeach
	                         		</div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingTwo">
                                 <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                   <h4 class="panel-title">
                                     Cons
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                 <div class="panel-body">
                                   A
                                 </div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingThree">
                                 <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                   <h4 class="panel-title">
                                     Ranking and Stats
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" aria-expanded="false">
                                 <div class="panel-body">
                                   
                                 </div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingFour">
                                 <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                   <h4 class="panel-title">
                                     Policies we have isued
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour" aria-expanded="false">
                                 <div class="panel-body">
                                   
                                 </div>
                               </div>
                             </div>
                           </div>
                       </div>
                   </div>
               </div>

               </div>  


               </div>

               <div class="modal-footer">
                  <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
                  <a href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0" target="_blank">Save</a>
               </div>
            </div>
         </div>
      </div>
