<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Bootstrap core CSS     -->
    <link rel="stylesheet" href="{{public_path('css/bootstrap.min.css')}}" />
   <!-- <link href="css/custom.css" rel="stylesheet" /> -->
    <link rel="stylesheet" type="text/css" href="{{public_path('css/insta.css')}}" />
</head>
<style>
   body{
      background: white;
      margin:  0px;
   }
</style>
<body>
<div id="moreInfo">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-body">
               <div class="row moreinfomodal">
               <h5 style="text-align: center">Some additional information we though might help you make the purchase decision simpler! </h5>
               <div id="">
                   <div class="card customcard">
                     <div class="col-sm-4 logobox">
                        <img src="{{ public_path('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                     </div>
                        <div class="col-sm-4">
                           <h5 class="card-title price">&#8377; {{round($modal_value['totalpremium'])}}</h5>
                           <span class="extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                        </div>
                       <div class="col-md-12">
                           <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingOne">
                                   <a role="button" data-toggle="" data-parent="#accordion" href="#One" aria-expanded="false" aria-controls="One" class="d">
                                       <h4 class="panel-title">
                                       Pros
                                       <i class="material-icons">keyboard_arrow_down</i>
                                       </h4>
                                   </a>
                               </div>
                           		<div id="One" class="panel- " role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
	                         		<div class="panel-body">
                            			@foreach($car_insure_pros as $values)
                            				<p>{{$values}}</p>
                            			@endforeach
	                         		</div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingTwo">
                                 <a class="d" role="button" data-toggle="" data-parent="#accordion" href="#Two" aria-expanded="false" aria-controls="Two">
                                   <h4 class="panel-title">
                                     Cons
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="Two" class="panel- " role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                 <div class="panel-body">
                                   A
                                 </div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingThree">
                                 <a class="d" role="button" data-toggle="" data-parent="#accordion" href="#Three" aria-expanded="false" aria-controls="Three">
                                   <h4 class="panel-title">
                                     Ranking and Stats
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="Three" class="panel- " role="tabpanel" aria-labelledby="headingThree" aria-expanded="false">
                                 <div class="panel-body">
                                   
                                 </div>
                               </div>
                             </div>
                             <div class="panel panel-default">
                               <div class="panel-heading" role="tab" id="headingFour">
                                 <a class="d" role="button" data-toggle="" data-parent="#accordion" href="#Four" aria-expanded="false" aria-controls="Four">
                                   <h4 class="panel-title">
                                     Policies we have isued
                                     <i class="material-icons">keyboard_arrow_down</i>
                                   </h4>
                                 </a>
                               </div>
                               <div id="Four" class="panel- " role="tabpanel" aria-labelledby="headingFour" aria-expanded="false">
                                 <div class="panel-body">
                                   
                                 </div>
                               </div>
                             </div>
                           </div>
                       </div>
                   </div>
               </div>
               </div>  
               </div>
            </div>
         </div>
      </div>
</body>
</html>
