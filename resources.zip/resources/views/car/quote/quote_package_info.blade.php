<div class="modal fade" id="packageInfo_{{$modal_value['product_id']}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">

         <div class="card card-pricing card-margin">
         <div class="row customcard">
               <div class="col-sm-4 logobox">
                  @if(isset($logo))
                   {{-- <img src="{{ URL::asset($logo) }}" alt="Insurer Logo"> --}}
                                     <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                  @else
                  <img src="{{ URL::asset('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                  @endif
               </div>
                  <div class="col-sm-4">
                     <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$modal_value['premiumBreakup']['totalpremium']['basic_premium']}}</h5>
                     <span class="label label-default extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                  </div>
                  <!-- <div class="col-sm-4 buybutton" style="margin-top: 15px;">
                     <button type="button" class="btn btn-success btn-sm">Buy Now</button>
                  </div> -->
                  </div>
                     <div class="content">
                        <h3>Many Benefits in <b>one</b> Package</h3>
                        <ul>
                           
                           <!-- <li>In Addition to Standard Benefits</li> -->
                           @foreach($modal_value['premiumBreakup']['basic'] as $key => $data)
                                 <li>
                                    <b>{{$data['displayName']}}</b>
                                    
                                 </li>
                           @endforeach 
                           <?php $paandll = array('pa_addon_price', 'll_addon_price' );?>
                           @if(!empty($modal_value['premiumBreakup']['addon']))
                              @foreach($modal_value['premiumBreakup']['addon'] as $key => $data)
                                    <li>
                                       <b <?php if(!in_array($key, $paandll)){ echo $key.' style="color:#06699C"';} else { echo '';}?>>{{$data['displayName']}}</b>
                                       <!-- Included -->
                                    </li>
                              @endforeach
                           @endif
                        </ul>
                     </div>
                  </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
             <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="quote_package_info btn btn-info btn-success btn-xs" style="margin: 0">Save</a>
         </div>
      </div>
   </div>
</div>
