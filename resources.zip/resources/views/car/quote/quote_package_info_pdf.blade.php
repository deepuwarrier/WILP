<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Bootstrap core CSS     -->
    <link rel="stylesheet" href="{{public_path('css/bootstrap.min.css')}}" />
   <!-- <link href="css/custom.css" rel="stylesheet" /> -->
    <link rel="stylesheet" type="text/css" href="{{public_path('css/insta.css')}}" />
</head>
<style>
   body{
      background: white;
      margin:  0px;
   }
   .premium-breakup ul {
    list-style: none;
    padding: 0;
    max-width: 240px;
    margin: 10px auto;
  }
</style>
<body>
<div id="packageInfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
            <div class="modal-content premium-breakup-card ">
                <div class="modal-body premium-breakup">
                    <div class="card customcard">
         <div class="row customcard">
               <div class="col-sm-4 logobox">
 @if(isset($logo))
                                {{-- <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo"> --}}
                                <img src="{{public_path('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                            @else
                                <img src="{{public_path('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                            @endif
               </div>
                  <div class="col-sm-4">
                     <h5 class="card-title price" style="margin-top: 15px;"><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{round($modal_value['premiumBreakup']['totalpremium']['basic_premium'])}}</h5>
                     <span class="extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                  </div>
                  </div>
                     <div class="content">
                        <h3>Many Benefits in <b>one</b> Package</h3>
                        <ul>
                           
                           <!-- <li>In Addition to Standard Benefits</li> -->
                           @foreach($modal_value['premiumBreakup']['basic'] as $key => $data)
                                 <li>
                                    <b>{{$data['displayName']}}</b>
                                    
                                 </li>
                           @endforeach 

                           <?php $paandll = array('pa', 'll' );?>
                           @foreach($modal_value['premiumBreakup']['addon'] as $key => $data)
                                 <li>
                                    <b <?php if(!in_array($key, $paandll)){ echo $key.' style="color:#06699C"';} else { echo '';}?>>{{$data['displayName']}}</b>
                                    <!-- Included -->
                                 </li>
                           @endforeach
                        </ul>
                     </div>
                  </div>
         </div>
      </div>
   </div>
</div>
</body>
</html>
