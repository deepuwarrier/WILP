<div class="modal fade" id="premiumBreakup_{{$modal_value['product_id']}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
   <div class="modal-content premium-breakup-card ">
      <div class="modal-body premium-breakup">
         <div class="row card customcard_premium_breakup">
            <div class="col-sm-4 logobox">
               @if(isset($logo))
               {{-- <img src="{{ URL::asset($logo) }}" alt="Insurer Logo"> --}}
                                     <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                                    @else
                                    <img src="{{ URL::asset('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                                    @endif
                                 </div>
                                    <div class="col-sm-5" style="margin-top: 15px;">
                                       <h5 class="card-title price">&#8377; {{round($modal_value['premiumBreakup']['totalpremium']['basic_premium'])}}</h5>
                                       <span class="label label-default extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                                       
                                    </div>
                                    <div class="col-sm-3 buybutton" style="margin-top: 15px;">
                                       <!-- <button type="button" class="btn btn-success btn-sm">Buy Now</button> -->
                                    </div>
                              </div>
                              @if(isset($business_type) && $business_type == 'New Business')
                              <div class="col-sm-12" style="margin-bottom: 10px;">
                                 <div class="col-sm-4"></div>
                                 <div class="col-sm-5">
                                    @if($policy_type == 1)
                                    <div class="policy-package-modal">1 Year OD + 3 Years TP</div>
                                    @endif
                                    @if($policy_type == 3)
                                    <div class="policy-package-modal">3 Years OD + 3 Years TP</div>
                                    @endif
                                 </div>
                                 <div class="col-sm-3"></div>
                              </div>

                                 
                              @endif
                              <div style="text-align:left;">
                              <h3>Premium Breakup</h3>
                              <h4>Basic Covers</h4>
                              <ul>

                                 @foreach($modal_value['premiumBreakup']['basic'] as $data)
                                 <li>
                                    <span class="">{{$data['displayName']}}</span>
                                    <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                 </li>
                                 @endforeach
                              </ul>
                              <h4>Addon Covers</h4>
                              <ul>
                              @if(!empty($modal_value['premiumBreakup']['addon']))
                                 @foreach($modal_value['premiumBreakup']['addon'] as $data)
                                    <li>
                                       <span class="">{{$data['displayName']}}</span>
                                       <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                    </li>
                                 @endforeach
                              @else
                                 <p>No addons selected</p>
                              @endif
                              </ul>
                              <h4>Discounts</h4>
                              <ul>
                              @if(!empty($modal_value['premiumBreakup']['discounts']))
                                 @foreach($modal_value['premiumBreakup']['discounts'] as $data)
                                    <li>
                                       <span class="">{{$data['displayName']}}</span>
                                       <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                    </li>
                                 @endforeach
                              @else
                                 <li>
                                    <span class="">No Claim Bonus</span>
                                    <span class="value pull-right"> - 0</span>
                                 </li>
                              @endif
                              </ul>
                              <h4>Taxes</h4>
                              <ul>
                                 <li>
                                    <span class="">{{$modal_value['premiumBreakup']['serviceTax']['displayName']}}</span>
                                    <span class="value pull-right">  {{$modal_value['premiumBreakup']['serviceTax']['basic_premium']}}</span>
                                 </li>
                              </ul>
                              <h4>Final Premium</h4>
                              <ul>
                                 <li class="finalprm">
                                    <span class="">{{$modal_value['premiumBreakup']['totalpremium']['displayName']}}</span>
                                    <span class="pull-right">  {{$modal_value['premiumBreakup']['totalpremium']['basic_premium']}}</span>
                                 </li>
                              </ul>
                              <!-- <form class="nl pull-left">
                                 <button type="button" class="nl__btn btn-xs">Email This!</button>
                                 <input type="text" placeholder="your@email.com" class="nl__input aria-hidden">
                              </form> -->
                           </div>
                           @if(isset($business_type) && $business_type == 'New Business')
                           <div  style="margin-bottom: 10px; text-align: left; font-size: 12px;">
                                 <p>Own Damage Policy Period is ({{$od_start_date}}, {{$od_end_date}}) and Liability Policy Period is ({{$tp_start_date}}, {{$tp_end_date}})</p>
                              </div>
                           @endif   
                           <div class="modal-footer">
                              <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
                               <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="save_premium_breakup btn btn-info btn-success btn-xs" style="margin: 0">Save</a> 
                        </div>
                     </div>
                  </div>
               </div>
</div>
