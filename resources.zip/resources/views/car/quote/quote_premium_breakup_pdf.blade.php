<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Bootstrap core CSS     -->
    <link rel="stylesheet" href="{{public_path('css/bootstrap.min.css')}}" />
   <!-- <link href="css/custom.css" rel="stylesheet" /> -->
    <link rel="stylesheet" type="text/css" href="{{public_path('css/insta.css')}}" />
</head>
<style>
   body{
      background: white;
      margin:  0px;
   }
</style>
<body>
    <div id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content premium-breakup-card ">
                <div class="modal-body premium-breakup">
                    <div class="card customcard">
                        <div class="col-sm-4 logobox">
                            @if(isset($logo))
                                {{-- <img src="{{asset('image/logos/')}}/{{$logo}}" alt="Insurer Logo"> --}}
                                <img src="{{public_path('image/logos/')}}/{{$logo}}" alt="Insurer Logo">
                            @else
                                <img src="{{public_path('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                            @endif
                        </div>
                        <div class="col-sm-4">
                            <h5 class="card-title price" style="margin-top: 15px;"><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{round($modal_value['premiumBreakup']['totalpremium']['basic_premium'])}}</h5>
                            <span class="extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                        </div>

                    </div>
                    <h3>Premium Breakup</h3>
                    <h4>Basic Covers</h4>
                    <ul>
                        @foreach($modal_value['premiumBreakup']['basic'] as $data)
                        <li>
                            <span class="">{{$data['displayName']}}</span>
                            <span class="value pull-right">  {{$data['basic_premium']}}</span>
                        </li>
                        @endforeach
                    </ul>


                    <h4>Addon Covers</h4>
                    <ul>
                        @if(!empty($modal_value['premiumBreakup']['addon'])) @foreach($modal_value['premiumBreakup']['addon'] as $data)
                        <li>
                            <span class="">{{$data['displayName']}}</span>
                            <span class="value pull-right">  {{$data['basic_premium']}}</span>
                        </li>
                        @endforeach @else
                        <p>No addons selected</p>
                        @endif
                    </ul>
                    <h4>Discounts</h4>
                    <ul>
                     @if(!empty($modal_value['premiumBreakup']['discounts']))
                         @foreach($modal_value['premiumBreakup']['discounts'] as $data)
                                    <li>
                                       <span class="">{{$data['displayName']}}</span>
                                       <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                    </li>
                                 @endforeach
                      @else
                        <li>
                            <span class="">No Claim Bonus</span>
                            <span class="value pull-right"> - 0</span>
                         </li>
                    @endif
                    </ul>
                    <h4>Taxes</h4>
                    <ul>
                        <li>
                            <span class="">{{$modal_value['premiumBreakup']['serviceTax']['displayName']}}</span>
                            <span class="value pull-right">  {{$modal_value['premiumBreakup']['serviceTax']['basic_premium']}}</span>
                        </li>
                    </ul>
                    <h4>Final Premium</h4>
                        <ul>
                            <li class="finalprm">
                            <span class="">{{$modal_value['premiumBreakup']['totalpremium']['displayName']}}</span>
                            <span class="pull-right">  {{$modal_value['premiumBreakup']['totalpremium']['basic_premium']}}</span>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</body>
    </html>
