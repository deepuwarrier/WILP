

@if($error === 'true')
   
   <div class="row card customcard" id="error_message">
     <h5 class="card-title price">{{$message}}</h5>
  </div>
@else
<div class="quote-box" data-listing-price="{{$quotes['totalpremium']}}" data-insurer-id="{{$quotes['insurer_id']}}">
<div class="row card customcard">
  <div class="col-sm-4 logobox">
    @if(isset($logo))
      <img src="{{asset('image/logos/')}}/{{$logo}}"  class="logo" alt="Insurer Logo">
    @else
      <img src="{{asset('image/logos/')}}/{{$quotes['insurer_id']}}.png"  class="logo" alt="Insurer Logo">
    @endif
  </div>
  <div class="row col-sm-8 logoright">
     <div class="col-md-6">
        <h5 class="card-title price">&#8377; {{round($quotes['totalpremium'])}}</h5>
        <span class="label label-default extrapanelitem idv" style="font-weight: 500">IDV: {{$quotes['idv_received']}}</span>
     </div>
     <div class="col-md-6 buybutton hvr-grow">
        @if($quotes['product_id'] == 'bajaj')
          <form name="policy_submit" id="policy_submit" method="post" action="{{route('car.load_proposal')}}" target="_blank">
          <input type="hidden" name="action_url" value="{{URL::to('car-insurance/policy/')}}/{{$quotes['insurerroute']}}/{{$trans_code}}">
        @else
          <form name="policy_submit" id="policy_submit" method="post" action="{{route('car.load_proposal')}}">
            <input type="hidden" name="action_url" value="{{URL::to('car-insurance/policy/')}}/{{$quotes['insurerroute']}}/{{$trans_code}}">
        @endif
          {{ csrf_field() }}
          <input name="product_id" id="product_id" type="hidden" value="{{$quotes['product_id']}}"/>
          <input name="insurer_id" id="insurer_id" type="hidden" value="{{$quotes['insurer_id']}}"/>
          @if(isset($quotes['QUOTE_ID']))
            <input name="quote_id" id="quote_id" type="hidden" value="{{$quotes['QUOTE_ID']}}" />
            <input type="hidden" value="{{$car_details['vehicle_cc']}}" name="engineCapacityAmount" id="engineCapacityAmount"/>
          @endif
          @if(isset($quotes['quotation_number']))
            <input name="quote_id" id="quote_id" type="hidden" value="{{$quotes['quotation_number']}}" />
            <input type="hidden" value="{{$car_details['vehicle_cc']}}" name="engineCapacityAmount" id="engineCapacityAmount"/>
          @endif
          <input name="regDate" id="regDate" type="hidden" value="{{$car_details['car_registration_date']}}"/>
          <input name="policyStartDate" id="policyStartDate" type="hidden" value="{{$car_details['policyStartDate']}}"/>
          <input name="policyExpiryDate" id="policyExpiryDate" type="hidden" value="{{$car_details['policyExpiryDate']}}"/>
          {{-- <input name="vehicleId" id="vehicleId" type="hidden" value="{{$car_details['vehicleId']}}"/> --}}
          <input name="variant_code" id="variant_code" type="hidden" value="{{$car_details['variant_code']}}"/>
          <input name="netPremium" id="netPremium" type="hidden" value="{{$quotes['netPremium']}}"/>
          <input name="rto" id="rto" type="hidden" value="{{$car_details['rto']}}"/>
          <input name="idv" id="idv" type="hidden" value="{{$quotes['idv_received']}}"/>
          <input name="idv_opted" id="idv_opted" type="hidden" value="{{$quotes['idv_received']}}"/>
          <input name="ncb" id="ncb" type="hidden" value="{{$car_details['ncb']}}"/>
          <input name="new_ncb" id="new_ncb" type="hidden" value="{{$car_details['new_ncb']}}"/>
          <input name="claim" id="claim" type="hidden" value="{{$car_details['claim']}}"/>
          <input name="totalpremium" id="totalpremium" type="hidden" value="{{$quotes['totalpremium']}}"/>
          <input name="price" id="price" type="hidden" value="{{$car_details['price']}}"/>
            <input name="session_id" id="session_id" type="hidden" value="{{$trans_code}}"/>
          <input name="trans_code" id="trans_code" type="hidden" value="{{$trans_code}}"/>
          <input name="sc" id="sc" type="hidden" value="5"/>
          <input name="occupation" id="occupation" type="hidden" value="0"/>
          <button type="button" class="btn btn-success btn-md scrolltop" id="buy_policy" data-focus="idv">Buy Now</button>
          <input name="policy_type_selection" id="policy_type_selection" type="hidden" value="{{$car_details['policy_type_selection']}}"/>
          <input name="typeOfBusiness" id="typeOfBusiness" type="hidden" value="{{$car_details['typeOfBusiness']}}"/>
          @if(array_key_exists('basic',$quotes['premiumBreakup']))
            @foreach($quotes['premiumBreakup']['basic'] as $key => $value )
              <input name="{{ $key }}" id="{{ $key }}" type="hidden" value="{{ $value['basic_premium'] }}"/>
            @endforeach
          @endif
          @if(array_key_exists('addon',$quotes['premiumBreakup']))
            @foreach($quotes['premiumBreakup']['addon'] as $key => $value )
              <input name="{{ $key }}" id="{{ $key }}" type="hidden" value="{{ $value['basic_premium'] }}"/>
            @endforeach
          @endif
          @if(isset($pb_data))
          @foreach($pb_data->getAttributes() as $key => $value)
            <input name="pb[{{ $key }}]" type="hidden" value="{{ $value }}">
          @endforeach
          @endif
        </form> 
     </div>
     <div class="row">
        <div class="col-sm-12">
           <div class="content extrapanel h_icons">
              @if(isset($car_details['expiry_status']) && $car_details['expiry_status'])
                <span class="extrapanelitem" style="color: #E91E63">Inspection Required - </span>
              @endif
              
              <span class="extrapanelitem name" style="font-weight: 500">{{$quotes['insurerName']}}</span>   
                &nbsp;
                 @if($quotes['insurerName'] == 'Royal Sundaram GI' || substr($quotes['insurerName'],0,8) == 'TATA AIG')
               <img class="logo" src="{{URL::to('/')}}/image/easy_emi.jpg"> 
              @endif
              <a href="javascript:void(0)"><button style="background-color: Transparent;background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;" disabled="disabled" class="material-icons iconcustom modal_details" data-modal="packageInfo_{{ $quotes['product_id'] }}" data-trans_code="{{$trans_code}}"data-producid ="{{$quotes['product_id']}}"data-toggle="tooltip" data-placement="top" id="" title="Package Info">stars</button></a>

               <a href="javascript:void(0)"><button style="background-color: Transparent;background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;" disabled="disabled" class="material-icons iconcustom modal_details" data-modal="premiumBreakup_{{ $quotes['product_id'] }}" data-trans_code="{{$trans_code}}"data-producid ="{{$quotes['product_id']}}" data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</button></a>
<!-- <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="moreInfo" data-producid ="{{$quotes['product_id']}}"data-toggle="tooltip" data-placement="top" title="More Info">info_outline</i></a> -->
           </div>
        </div>
     </div>
  </div>
</div>

  @include('car.quote.quote_package_info',['modal_value'=>$quotes])
  @include('car.quote.quote_premium_breakup',['modal_value'=>$quotes, 'policy_type' => $car_details['policy_type_selection'], 'business_type' => $car_details['typeOfBusiness'], 'od_start_date' => $car_details['od_start_date'], 'od_end_date' => $car_details['od_end_date'],'tp_start_date' => $car_details['tp_start_date'],'tp_end_date' => $car_details['tp_end_date']])
</div>
@endif


