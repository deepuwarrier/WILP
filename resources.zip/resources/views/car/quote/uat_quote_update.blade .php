@if($error === 'true')
   
   <div class="row card customcard" id="error_message">
     <h5 class="card-title price">{{$message}}</h5>
  </div>
@else
<div class="row card customcard" data-listing-price="{{$quotes['totalpremium']}}" data-insurer-id="{{$quotes['insurer_id']}}">
  <div class="col-sm-4 logobox">
     <img src="{{asset('image/logos/')}}/{{$quotes['insurer_id']}}.png" alt="Insurer Logo">
  </div>
  <div class="row col-sm-8 logoright">
     <div class="col-md-6">
        <h5 class="card-title price">&#8377; {{round($quotes['totalpremium'])}}</h5>
        <span class="label label-default extrapanelitem" style="font-weight: 500">IDV: {{$quotes['idv_received']}}</span>
     </div>
     <div class="col-md-6 buybutton hvr-grow">
        <form name="policy_submit" id="policy_submit" method="post" action="{{route('car.load_proposal')}}">
          
          {{ csrf_field() }}
          <input name="product_id" id="product_id" type="hidden" value="{{$quotes['product_id']}}"/>
          <input name="insurer_id" id="insurer_id" type="hidden" value="{{$quotes['insurer_id']}}"/>
          @if(isset($quotes['QUOTE_ID']))
            <input name="quote_id" id="quote_id" type="hidden" value="{{$quotes['QUOTE_ID']}}" />
            <input type="hidden" value="{{$car_details['vehicle_cc']}}" name="engineCapacityAmount" id="engineCapacityAmount"/>
          @endif
          <input name="regDate" id="regDate" type="hidden" value="{{$car_details['car_registration_date']}}"/>
          <input name="policyStartDate" id="policyStartDate" type="hidden" value="{{$car_details['policyStartDate']}}"/>
          <input name="policyExpiryDate" id="policyExpiryDate" type="hidden" value="{{$car_details['policyExpiryDate']}}"/>
          {{-- <input name="vehicleId" id="vehicleId" type="hidden" value="{{$car_details['vehicleId']}}"/> --}}
          <input name="variant_code" id="variant_code" type="hidden" value="{{$car_details['variant_code']}}"/>
          <input name="netPremium" id="netPremium" type="hidden" value="{{$quotes['netPremium']}}"/>
          <input name="rto" id="rto" type="hidden" value="{{$car_details['rto']}}"/>
          <input name="idv" id="idv" type="hidden" value="{{$quotes['idv_received']}}"/>
          <input name="idv_opted" id="idv_opted" type="hidden" value="{{$quotes['idv_received']}}"/>
          <input name="ncb" id="ncb" type="hidden" value="{{$car_details['ncb']}}"/>
          <input name="new_ncb" id="new_ncb" type="hidden" value="{{$car_details['new_ncb']}}"/>
          <input name="claim" id="claim" type="hidden" value="{{$car_details['claim']}}"/>
          <input name="totalpremium" id="totalpremium" type="hidden" value="{{$quotes['totalpremium']}}"/>
          <input name="price" id="price" type="hidden" value="{{$car_details['price']}}"/>
            <input name="session_id" id="session_id" type="hidden" value="{{$car_details['session_id']}}"/>
            <input name="sc" id="sc" type="hidden" value="5"/>
            <input name="occupation" id="occupation" type="hidden" value="0"/>
            <button type="button" class="btn btn-success btn-md scrolltop" id="buy_policy" data-focus="idv">Buy Now</button>
        </form> 
     </div>
     <div class="row">
        <div class="col-sm-12">
           <div class="content extrapanel">
              <span class="extrapanelitem" style="font-weight: 500">{{$quotes['insurerName']}}</span>   
              <span class="extrapanelitem" style="font-weight: 500">GI</span>
              <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="packageInfo" data-session_id="{{$car_details['session_id']}}"data-producid ="{{$quotes['product_id']}}"data-toggle="tooltip" data-placement="top" id="" title="Package Info">stars</i></a>
               <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="premiumBreakup" data-session_id="{{$car_details['session_id']}}"data-producid ="{{$quotes['product_id']}}" data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</i></a>
<!-- <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="moreInfo" data-producid ="{{$quotes['product_id']}}"data-toggle="tooltip" data-placement="top" title="More Info">info_outline</i></a> -->
           </div>
        </div>
     </div>
  </div>
</div>
@endif
