<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <h5 class="category-social">
      </h5>
      <h4 class="card-title">
         <a>Since your External CNG kit value is greater then 50,000, you cannot buy this package online. 
            <br>Want to Redeclare CNG Kit ?</a>
         <br>
         {{-- <a>Go to Quote Page</a> --}}
      </h4>
      <input type='hidden' id='return_url' name ='return_url' value='{{$return_quote_url}}' />
      {{-- <button class="btn btn-failed" id="back_quote_no">No</button> --}}
      <form method="post" action="{{route('car.tata.proposal_error')}}" id="back_quote_no" style="display:inline-block">
         {{ csrf_field() }}
         <input type="hidden" value = '{{$trans_code}}' name='trans_code' class="btn btn-failed"/>
         <input type="hidden" value = 'cng_external_no' name='proposal_error_type' class="btn btn-failed"/>
         <button class="btn btn-failed" id="proposal_error_cng">No</button>
      </form>
      <button class="btn btn-success" id="back_quote_yes">Yes</button>
   </div>
</div>
</div>
</div>