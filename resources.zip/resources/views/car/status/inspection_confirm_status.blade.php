<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <h5 class="category-social">
         <i class="fa fa-newspaper-o"></i> Well Done!
      </h5>
      <h4 class="card-title">
         <a>We have collected all the information required to issue your policy!</a>
      </h4>
      <h4 class="card-title">
         Your vehicle will be inspected by an HDFC Ergo representative before the policy can be issued.<br/> Please confirm to schedule an inspection.

         
      </h4>
      <button class="btn btn-failed" id="review-again">I'll do it later</button>
      <button class="btn btn-success" id="inspection-submit">Processed</button>
   </div>
</div>
</div>
</div>