@include('layouts.header')
<div class="wizard-container">
   <div class="container genenq">
      <div class="col-md-12 card-contact">
         <h1 class="card-title" style="color: #00669C;">We tried our best!</h1>
         <h4 class="card-title" style="color: #00669C;">But as your previous policy was liability, your car has to be inspected first! </h4>
         <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5>

         <a href="{{URL::to('/')}}" class="btn btn-success">Home</a>
      </div>
   </div>
</div>
<br><br>
<hr>
@include('layouts.footer')