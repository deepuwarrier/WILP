<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <h5 class="category-social">
       <!--   <i class="fa fa-newspaper-o"></i> Well Done! -->
      </h5>
      <h4 class="card-title">
         <p style="font-weight: bold;font-size: 20px;"><b>Do you have {{$display_name}} addons in your previous policy?</b></p>
         <p><button class="btn btn-success" id="no_prevaddon">No, I don't</button>
         <button class="btn btn-success" id="yes_prevaddon">Yes, I have</button></p>
          <a>If not, then you cannot buy this package online. Please select different package from the quotes</a>
         <br>
         <!-- <a>Go to Quote Page</a> -->
      </h4>
     
      <!-- <input type='hidden' id='return_url' name ='return_url' value='{{$return_quote_url}}' />
      
       <form method="post" action="{{route('car.tata.proposal_error')}}" id="addon_include_proposal" style="display:inline-block">
         {{ csrf_field() }}
         <input type="hidden" value = '{{$trans_code}}' name='trans_code' class="btn btn-failed"/>
         <input type="hidden" value = '{{$display_name}}' name='display_name' class="btn btn-failed"/>
         <input type="hidden" value = 'addon_include_proposal_no' name='proposal_error_type' class="btn btn-failed"/>
         <button class="btn btn-failed" id="zerodep-including">No</button>
      </form>
      <button class="btn btn-success" id="zerodep-excluding">Yes</button> -->
   </div>
</div>
</div>
</div>