<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <h5 class="category-social">
       <!--   <i class="fa fa-newspaper-o"></i> Well Done! -->
      </h5>
      <h4 class="card-title">
         <a>Since you dont have Zero Dept. in your previous policy. Do you want to continue excluding Zero Dept ??</a>
         <a>Approx Payable Premium is {{ $premium }}</a>
      </h4>
      <button class="btn btn-failed" id="zerodep-including">No</button>
      <button class="btn btn-success" id="zerodep-excluding">Yes</button>
   </div>
</div>
</div>
</div>