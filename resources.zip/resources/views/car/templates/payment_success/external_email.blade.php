@include('layouts.email_header_template')
  <div class="wizard-container">
    <div class="premiumconfirmation">
      <div class="card">
        <div class="content">
          <p>Dear {{$name}},</p>
          <p>Congratulations on purchasing an insurance policy from {{$company_name}} through Instainsure.com.</p>

          @if(isset($data_value['udata']['POLICYNUMBER'])) 
          <p>Your Policy Number is: {{ $data_value['udata']['POLICYNUMBER'] }} </p>
          @endif
          @if(isset($data_value['udata']['PolicyNo']))
          <p>Your Policy Number is: {{ $data_value['udata']['PolicyNo'] }}</p>
          @endif
          @if(isset($data_value['udata']["WS_P_ID"]))
          <p>Your Policy Number is: {{ $data_value['udata']["WS_P_ID"] }}</p>
          @endif 
          <p>{{$company_name}} will sent you a copy of your insurance policy in a short while to this email id.</p><p>Meanwhile, if you have any queries, please feel free to contact us at the below coordinates.</p>
          </div>
      </div>
    </div>
  </div>
@include('layouts.email_footer_template')
