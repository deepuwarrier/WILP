@include('layouts.email_header_template')
	<p>Dear {{$name}},</p>
	<p>
		Our apologies for you were not able to complete your payment. Looks like we are experiencing a technical problemwith the Payment Gateway of <insurance company> server.
	</p>
	<p>
		Our customer support team will contact you shortly in order to complete your policy issuance.
	</p>
	<p>
		Please ignore if you have already completed your payment.
	</p>
	<p>
		Meanwhile, if you have any queries, please feel free to contact us at the below coordinates.
	</p>
@include('layouts.email_footer_template')
