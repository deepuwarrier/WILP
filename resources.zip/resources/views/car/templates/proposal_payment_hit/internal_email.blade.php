<html>
    <head>
        <title>New Enquiry</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
    </head>
    <body>
        <h2>A new policy has been initiated, below are the details.</h2>
        @if(isset($agent_name))
            <h4>The name of agent :- {{$agent_name}}</h4>
        @endif
        <div class="container">
            <table class="table panel panel-primary">
                <div class="row">
                    <tr class="panel-heading">
                        <td>
                            Request Url
                        </td>
                        <td>
                            Please, <a href="{{$proposal_request_url}}">click here</a> to vist request URL
                        </td>
                    </tr>
                </div>
                <div class="row">
                    <tr class="panel-heading">
                        <td colspan='2' class="panel-title">Transaction Details</td>
                    </tr>
                    @php
                        function displayCol($data){
                        if(is_array($data)){
                            foreach($data as $key => $value){
                                if(is_array($value)){
                                    displayCol($value);
                                } else {
                                    echo "<tr >
                                            <td class='row'>
                                                ".$key."
                                            </td>
                                            <td>
                                                ".$value."
                                            </td>
                                        </tr>";
                                }
                            }
                        } else {
                            echo "<tr >
                                    <td class='row'>
                                        {{$data}}
                                    </td>
                                </tr>";
                        }
                    }
                    @endphp
                    @if(is_object($data_value))
                        @php
                            $data_value = get_object_vars($data_value);
                        @endphp
                    @endif
                    @if(is_array($data_value))
                        @php
                            displayCol($data_value)
                        @endphp
                    @else 
                        {{$data_value['result']}}
                    @endif
                </div>
                @foreach($proposal_form_data as $key=>$value)
                    <div class="row">
                        @if($key === 'policy')
                            <tr class="panel-heading">
                                <td colspan='2' class="panel-title">Policy Details</td>
                            </tr>
                            @foreach($value as $key2=>$value2)
                                <tr>
                                    <td>{{$key2}}</td>
                                    <td>{{$value2}}</td>
                                </tr>
                            @endforeach
                        @endif
                        @if($key === 'vehicle')
                            <tr>
                                <td colspan='2'>Vehicle Details</td>
                            </tr>
                            @foreach($value as $key2=>$value2)
                                <tr>
                                    <td>{{$key2}}</td>
                                    <td>{{$value2}}</td>
                                </tr>
                            @endforeach
                        @endif
                        @if($key === 'proposer')
                            <tr >
                                <td colspan='2'>Proposer Details</td>
                            </tr>
                            @foreach($value as $key2=>$value2)
                                <tr>
                                    <td>{{$key2}}</td>
                                    <td>{{$value2}}</td>
                                </tr>
                            @endforeach
                        @endif
                        @if($key === 'prevpolicy')
                            <tr>
                                <td colspan='2'>Previous Policy Details</td>
                            </tr>
                            @foreach($value as $key2=>$value2)
                                <tr>
                                    <td>{{$key2}}</td>
                                    <td>{{$value2}}</td>
                                </tr>
                            @endforeach
                        @endif
                        @if($key === 'proposerDetails')
                            <tr>
                                <td colspan='2'>Proposer Details</td>
                            </tr>
                            @if(isset($value))
                                @if(is_object($value))
                                    @php
                                        $data_value = get_object_vars($value);
                                    @endphp
                                @else
                                    $data_value = $value;
                                @endif
                                @if(is_array($data_value))
                                    @php
                                        displayCol($data_value);
                                    @endphp
                                @else 
                                     <tr>
                                        {{-- <td>{{$key2}}</td> --}}
                                        <td>{{$data_value}}</td>
                                    </tr>
                                @endif
                            @endif
                        @else
                            <tr>
                                <td colspan='2'>Vechicle Details</td>
                            </tr>
                            @if(isset($value))
                                @if(is_object($value))
                                    @php
                                        $data_value = get_object_vars($value);
                                    @endphp
                                @endif
                                @if(is_array($data_value))
                                    @php
                                        displayCol($data_value);
                                    @endphp
                                @else 
                                     <tr>
                                        {{-- <td>{{$key2}}</td> --}}
                                        <td>{{$data_value}}</td>
                                    </tr>
                                @endif
                            @endif
                        @endif
                    </div>
                @endforeach
            </table>
        </div>
    </body>
</html>
