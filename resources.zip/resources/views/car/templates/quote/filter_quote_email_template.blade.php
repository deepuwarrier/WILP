@if($error === 'true')
   
   <div class="row card customcard">
     <h5 class="card-title price">{{$message}}</h5>
  </div>
@else
<div class="col-md-12" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;width: 100%;">
  @foreach ($filter_quotes as $key=>$quotes)
  <div class="row card customcard" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;text-align: center;margin: 0 0 8px 0!important;border-radius: 3px;color: #00669C;box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .14), 0 3px 1px -2px rgba(0, 0, 0, .2), 0 1px 5px 0 rgba(0, 0, 0, .12);display: inline-block;position: relative;width: 100%;">
    <div class="col-sm-4 logobox" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;width: 150px;padding: 10px;float: left;">
    @if(isset($quotes['logo']))
      <img src="{{asset('image/logos/')}}/{{$quotes['logo']}}" alt="Insurer Logo"style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border: 0;vertical-align: middle;page-break-inside: avoid;max-width: 100%!important;">
    @else
      <img src="{{asset('image/logos/')}}/{{$quotes['insurer_id']}}.png" alt="Insurer Logo"style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border: 0;vertical-align: middle;page-break-inside: avoid;max-width: 100%!important;">
    @endif
    </div>
    <div class="row col-sm-8 logoright" style="-webkit-box-sizing: border-box:margin-top:-75px;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;margin: 0:width:100%;padding: 0;">
       <div class="col-md-6 logobox" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;padding: 10px;">
          <a href="{{$return_quote_url}}">
          <button type="button" class="btn btn-success btn-md scrolltop" id="buy_policy" data-focus="idv" style="float:right;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font: inherit;color: #fff;overflow: visible;text-transform: none;-webkit-appearance: button;cursor: pointer;font-family: inherit;font-size: 14px;line-height: 1.42857143;display: inline-block;padding: 6px 12px;margin-bottom: 0;font-weight: 400;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius: 4px;background-color: #5cb85c;border-color: #4cae4c;">View More</button>
          </a>
          <h5 class="card-title price" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-family: inherit;font-weight: 600;line-height: 1.1;color: #424242;margin-top: 0;margin-bottom: 0px;font-size: 18px;padding-top: 13px;">&#8377; {{$quotes['totalpremium']}}</h5>
          <span class="extrapanelitem" style="font-weight: 500;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-size: 11px;">{{$quotes['insurerName']}}</span>   
          <span class="extrapanelitem" style="font-weight: 500;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;font-size: 11px;">GI</span>
          <span class="label label-default extrapanelitem" style="margin-left: 10px;font-weight: 500;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border: 1px solid #000;display: inline;padding: 1px 14px;font-size: 11px;line-height: 1;color: #424242;text-align: center;white-space: nowrap;vertical-align: baseline;border-radius: .25em;border-style: solid;border-width: 1px;border-color: #92cf1b;background-color: white!important;">IDV: {{$quotes['idv_received']}}</span>
       </div>
       <div class="row" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;margin-right: -15px;margin-left: -15px;">
          <div class="col-sm-12"style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;position: relative;min-height: 1px;padding-right: 15px;padding-left: 15px;width: 100%;">
             <div class="content extrapanel" style="-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;border-top-style: solid;border-width: 1px;border-color: #eee;color: #00669c;text-align: right;padding: 6px 10px 5px 0!important;">
                
             </div>
          </div>
       </div>
    </div>
  </div>
  @endforeach
</div>
@endif
