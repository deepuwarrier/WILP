@include('layouts.header')
<div class="wizard-container">
   <div class="container genenq">
      <div class="col-md-6" style="text-align:right; padding-right: 50px;">
         <a> <img class="img" height="300" src="{{URL::asset('image/error-img/error-img-1.jpg')}}" alt="Error" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <img class="img" height="140" src="{{URL::asset('image/error-img/400.jpg')}}" alt="Error" />
         <h5> Lets get you landed from where you took off.</h5>
         <a href="{{url('/')}}"> <img class="img" height="50" src="{{URL::asset('image/error-img/error_home_btn.jpg')}}" alt="Error" /></a>
      </div>
   </div>
</div>
<br><br>
<hr>
@include('layouts.footer')
<script>
function goBack() { 
    window.history.back();
}
</script>