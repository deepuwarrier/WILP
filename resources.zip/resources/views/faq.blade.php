@include('layouts.header')

<div class="page-header">
	<div class="container faqsection">
		<h3 style="color: #00669c">Frequently Asked Questions</h3>
	
		<span><i class="material-icons">search</i></span>
		<input type="text" class="live-search-box faqsearchbox"
			placeholder="Type Your Search Keywords Here" /> @foreach ($faqlist as
		$faqlitem)

		<div class="topic">
			<div class="open">
				<h4 class="question">
					{{$faqlitem->faq_qtn}}<span class="ptag">{{$faqlitem->faq_kwd}}</span>
				</h4>
			</div>
			<p class="answer">{{$faqlitem->faq_ans}}</p>
		</div>
		@endforeach



	</div>
</div>

<br><br>
<hr>

@include('layouts.footer')

<script src="{{URL::asset('js/faq.js')}}"></script>