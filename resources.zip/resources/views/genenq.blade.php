@include('layouts.header')

<div class="wizard-contactsection">
  
<div class='contactsection'>
  <header style="">
    <h6 style="color: grey">Rome was not built in a day - <i>Coming Soon</i></h6>
 <h2 style="color: #E91E63">We are a click away!</h2>
    <p>Our insurance consultant will be happy to help you over a call.</p>
       
  </header>

  <form method="POST" id="generalenuiry" name="generalenuiry">
  
  {{ csrf_field() }}
 
 <input type="hidden" name="insurance_type" id="insurance_type" value="{{$insurance_type}}" class="form-control">
 
  <div class='contactform'>
    <contactform>
      <div class='field'>
        <label class="control-label">Enter your name</label>
        <input id='name' name='name' type='text' placeholder='' class="requiredField">
        <span class="hide" style="color:red;" id="error_name">Please enter your name.</span>
        </div>


      <div class='field'>
        <label class="control-label">Email Address</label>
        <input id='email' name='email' type='email' placeholder='' class="requiredField">
        <span class="hide" style="color:red;" id="error_email">Please enter your name.</span>
      </div>


      <div class='field'>
        <label class="control-label">Mobile Number</label>
        <input id='mobile' name='mobile' type='Mobile' placeholder='' class="requiredField">
        <span class="hide" style="color:red;" id="error_mobile">Please enter your name.</span>
      </div>


      <div class='field'>
        <label class="control-label">City</label>
        <input id='city' name='city' type='text' placeholder=''>
      </div>


      <div class='checkbox'>
          By submitting this form, you agree to be contacted by a professional insurance consultant from InstaInsure.
      </div>

      <button type="submit" class="btn btn-success">Submit</button>
            <p class="card-title" id="success_message" style='color:green'></p>
    </contactform>


  </div>
  <!-- / END contactform -->
  </form>
</div>
</div>

@include('layouts.footer')

<script type="text/javascript">
   $('#generalenuiry').submit(function(event) {
      var error = 0;
      $('.requiredField').each(function() {
         var id = $(this).attr('id');
         var value = $('#'+id).val();
         if (value === '' || typeof value === "undefined") {
            $(this).parent().addClass('has-error is-focused')
            error = 1;
         } else {
            error = 0;
         } 
      });
      if(error=== 0){
         $(this).find('button[type=submit]').prop('disabled', true);
         var data = $('#generalenuiry').serialize();
         $.ajax({
            url: '/sendmail',
            type: 'POST',
            data: data,
            success:function(data){
               $('#success_message').html(data.message);

            }
         });      
      }
      return false;
   });
</script>
<script>
$('input').bind('focus', function() {
  $(this).parent('.field').css({ 'background-color' : '#f5f8f9'});
});
$('input').bind('blur', function() {
  $(this).parent('.field').css({ 'background-color' : 'none'});
});

</script>
