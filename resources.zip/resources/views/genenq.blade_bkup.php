@include('layouts.header')
<div class="wizard-container">
   <div class="container genenq">
      <div class="col-md-6 clearall">
         <a> <img class="img" src="image/contact.png" alt="Contact Us" /></a>
      </div>
      <div class="col-md-6 clearall card-contact">

         <form method="POST" id="generalenuiry" name="generalenuiry">
            {{ csrf_field() }}
            <input type="hidden" name="insurance_type" id="insurance_type" value="{{$insurance_type}}" class="form-control">
            <div class="padleft">
            <h4 class="card-title" style="color: #00669C;">Coming Online soon!</h4>
            <p>Meanwhile, contact us to get the best quote!</p>
            
            <div class="col-md-6 clearall">
               <div class="form-group label-floating padtop">
                  <label class="control-label padtop">Your Name</label>
                  <input type="text" id="name" name="name" class="form-control requiredField">
                  <span class="hide" style="color:red;" id="error_name">Please enter your name.</span>
               </div>
            </div>
            <div class="col-md-6 clearall">
               <div class="form-group label-floating padtop">
                  <label class="control-label padtop">Mobile #</label>
                  <input type="Mobile" id="mobile" name="mobile" class="form-control requiredField">
                  <span class="hide control-label" style="color:red;" id="error_mobile">Please enter your mobile number.</span>
               </div>
            </div>
            <div class="col-md-12 clearall">
               <div class="form-group label-floating padtop">
                  <label class="control-label padtop">Email address</label>
                  <input type="email" id="email" name="email" class="form-control requiredField"/>
                  <span class="hide" style="color:red;" id="error_email">Please enter your email address.</span>
               </div>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
            <p class="card-title" id="success_message" style='color:green'></p>
            </div>
         </form>
         </div>
 

   </div>
</div>
<br><br>
<hr>
@include('layouts.footer')
<script type="text/javascript">
   $('#generalenuiry').submit(function(event) {
      var error = 0;
      $('.requiredField').each(function() {
         var id = $(this).attr('id');
         var value = $('#'+id).val();
         if (value === '' || typeof value === "undefined") {
            $(this).parent().addClass('has-error is-focused')
            error = 1;
         } else {
            error = 0;
         } 
      });
      if(error=== 0){
         $(this).find('button[type=submit]').prop('disabled', true);
         var data = $('#generalenuiry').serialize();
         $.ajax({
            url: '/sendmail',
            type: 'POST',
            data: data,
            success:function(data){
               $('#success_message').html(data.message);

            }
         });      
      }
      return false;
   });
</script>
