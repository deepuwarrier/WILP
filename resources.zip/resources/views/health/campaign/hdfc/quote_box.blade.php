<div class="section-border-1">
   <div class="row p-4">
      <div class="col-md-4 ">
         <img src="https://i.imgur.com/aAQSOVl.png" height="80">
      </div>
      <div class="col-md-8 medisure_label text-uppercase text-right" style="">
         <h2><span>HDFC</span> medisure super topup</h2>
         <h3><span>HOSPITALISATION</span>&#8377;{{ $data['sum_insured'] }}</h3>
         <h3><span>DEDUCTIBLE</span>&#8377;{{ $data['deductible'] }}</h3> 
      </div>
      <div class="ul_quote col-md-12">
         <ul class="row">
            <li class="col-md-5">Free-Look Period</li>
            <li class="col-md-7" >15 days</li>
         </ul>
         <ul class="row">
            <li class="col-md-5">Day Care Procedures</li>
            <li class="col-md-7" >Pharmacy bill & consultation fee</li>
         </ul>
         <ul class="row">
            <li class="col-md-5" >Pre and Post-hospitalisation expenses</li>
            <li class="col-md-7" >30 days before &amp; 60 days after </li>
         </ul>
         <ul class="row">
            <li class="col-md-5" >Claim support</li>
            <li class="col-md-7" >6 Hours response guarantee</li>
         </ul>
         <ul class="row">
            <li class="col-md-5" >PED examination expense</li>
            <li class="col-md-7">50% reimbursement</li>
         </ul>
      </div>
   </div>
   <div class="ins_buy_section">
      <div class="row">
         <div class="col-md-7">
            <h4>Existing disease covered after 3 years</h4>
         </div>
         <div class="col-md-5">
            <h3>&#8377;{{ $data['premium'] }}</h3>
            <p>inclusive of 18% GST</p>
            <button id="buy_now">BUY NOW</button>
            <p><a href="#" data-toggle="modal" data-target="#Premium_modal">view plan details</a></p>
         </div>
      </div>
   </div>
</div>