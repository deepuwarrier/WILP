@include('health.campaign.layouts.header') 
<link rel="stylesheet" href="{{ asset('campaign_assets/css/ticket.css') }}">
<style type="text/css">
   td {
   padding-top: .4em;
   padding-bottom: .4em;
   }
</style>
<input type="hidden" name="hdfc_quote_url" id="hdfc_quote_url" value="{{ route('health.load_hdfc_quotes') }}">
<input type="hidden" name="hdfc_proposal_url" id="hdfc_proposal_url" value="{{ route('health.load_proposal') }}">
<input type="hidden" name="page_pointer" id="page_pointer" value="{{ ( session()->has('pointer') && (session()->get('pointer') == 'proposal') ) ? 'hide' : 'show' }}">
<input type="hidden" name="cust_modal_trigger" id="cust_modal_trigger" value="{{ ( session()->has('customer_details_modal'))  ? session()->get('customer_details_modal') : '' }}">
<div class="sticky_footer" style="position:fixed;width:100%;background:white;height: 70px;bottom:0;z-index:2000" >
   <div class="row">
      <div class=" col-md-4"></div>
      <div class=" col-md-7" style="margin-top:20px">
         <p class="text-center"><button class="btn btn-default btn-sticky-footer" id="back" style="visibility: hidden">BACK</button>
            <button class="btn btn-default btn-sticky-footer" id="proceed_next">Proceed to <span id="next_item">next</span></button>
         </p>
      </div>
   </div>
</div>
<!-- ini_Modal Modal -->
<div id="ini_Modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header flex-column border-0">
            <h2 class="text-center w-100">Just one Click Away</h2>
            <p class="text-center w-100">Secure your financial well-being during medical emergencies</p>
         </div>
         <div class="modal-body">
            <form id="customer_details_form" data-url="{{route('health.campaign.save_cust_modal_data')}}">
                <div class="row">
                  <div class="col-md-6">
                     <div class="form__row">
                        <label class="form__label" for="customer_first_name">First Name</label>
                        <input name="customer_first_name" id="customer_first_name" class="form__input" type="text" placeholder="" />
                        <span class="form__row-border"></span>
                     </div>
                  </div>  
                  <div class="col-md-6">
                     <div class="form__row">
                        <label class="form__label" for="customer_last_name">Last Name</label>
                        <input name="customer_last_name" id="customer_last_name" class="form__input" type="text" placeholder="" />
                        <span class="form__row-border"></span>
                     </div>
                  </div>   
                </div>   
               <div class="form__row">
                  <label class="form__label" for="customer_email">Email</label>
                  <input name="customer_email" id="customer_email" class="form__input" type="text" placeholder="" />
                  <span class="form__row-border"></span>
               </div>
               <div class="form__row">
                  <label class="form__label" for="customer_mobile">Mobile Number</label>
                  <input name="customer_mobile" id="customer_mobile" class="form__input" type="text" placeholder="" maxlength="10" />
                  <span class="form__row-border"></span>
               </div>
               <div class="form__row">
                  <button type="button" id="customer_details_form_submit_btn" class="btn btn-submit">Submit</button>
               </div>
            </form>
         </div>
         <div class="modal-footer border-0">
         </div>
      </div>
   </div>
</div>
<!-- Ini_modal closed -->
<!-- BMI_modal Modal -->
<div id="bmi_modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header flex-column border-0">
            <h2 class="text-center w-100">Medical Evaluation required</h2>
            <p class="text-center w-100">Please accept the condition to continue</p>
         </div>
         <div class="modal-body" id="bmi_modal_body">
         </div>
         <div class="modal-footer border-0">
         </div>
      </div>
   </div>
</div>
<!-- BMI_modal closed -->
<!-- OTP modal -->
<div id="otp_modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header flex-column border-0">
            <h2 class="text-center w-100">OTP Verification</h2>
         </div>
         <div class="modal-body" id="">
          <form id="otp_form" data-url="">
                <div class="row">
                  <div class="col-md-12">
                     <div class="form__row">
                       <center><label class="form__label">Attempts <span id="otp_attempts_text"></span></label></center>
                     </div>
                     <div class="form__row">
                        <label class="form__label" for="customer_first_name">OTP</label>
                        <input name="otp" id="otp" class="form__input otp" type="text" placeholder="" maxlength="10" />
                        <span class="form__row-border"></span>
                     </div>
                     <div class="form__row">
                        <button type="button" id="opt_verification_btn" class="btn btn-submit">Verify</button>
                     </div>
                  </div> 
                </div>
              </form>   
         </div>
         <div class="modal-footer border-0">
         </div>
      </div>
   </div>
</div>
<!-- OTP modal closed -->
<!-- PG connect starts -->
<div id="pg_modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header flex-column border-0">
         </div>
         <div class="modal-body">
            <img src="{{URL::asset('campaign_assets/images/redirection-img.jpg')}}" class="d-block m-auto">
            <h3>Redirecting to Insurance Company's Payment Gateway</h3>
            <p>Please be patient, as this could take a moment</p>
            <p class="text-center"><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></p>
         </div>
         <div class="modal-footer border-0">
         </div>
      </div>
   </div>
</div>
<!-- PG connect ends -->
<!-- Section -- intro -->
<!--<div class="section section--intro" id="intro">-->
<!--   <div class="">-->
<!--      <div class="section__content section__content--fluid-width section__content--intro">-->
<!--         <div class="intro position-absolute">-->
<!--            <div class="intro__content">-->
<!--               <p class="intro__title">Live Your Life<span>Worry Free!</span></p>-->
<!--               <p class="intro__subtitle">A Super Top Up health cover is all you need against uncertain medical expenses</p>-->
<!--               <div class="intro__buttons intro__buttons--left">-->
                  <!--<a href="index-2.html" class="btn btn--green-bg btn--play modal-toggle" data-openpopup="animation">HOW IT WORKS</a>-->
<!--                  <a class="btn btn--purple-bg get_started_btn" id="get_started_btn">GET STARTED</a>-->
<!--               </div>-->
<!--            </div>-->
<!--         </div>-->
<!--      </div>-->
<!--      <div class="intro-animation">-->
<!--         <img src="https://i.imgur.com/Whk9N0v.png" alt="" title=""/>-->
<!--      </div>-->
<!--      <svg class="svg-intro-bottom" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">-->
<!--         <path d="M0,90 L30,100 L100,20 L100,100 0,100 Z" fill="#eaeef1"/>-->
<!--      </svg>-->
<!--   </div>-->
<!--</div>-->
<!-- Section -- Basic Inputs -->
<section class="section section--about" id="customer_details_container">
   <div class="section__content section__content--fluid-width section__content--about">
      <div class="grid grid--5col grid--about">
        <div class="row">       
          <div class="col-md-6">
            <!--<h2 class="grid__title">Hurray!. Get your  super topup insurance; on budget</h2>-->
            <!--<h3 class="grid__title">Hurray!. Get your customised super topup plans; <span>on budget</span></h3>-->
            <!--<h3 class="grid__title">Get a  super topup policy; avail <span>cashless medical treatment</span>!.</h3>-->
            <h3 class="grid__title " id="left_title">Stay Worry Free with <span>Super Top Up</span>!.</h3>
             <p class="intro__subtitle " id="left_subtitle"> Get Free Claim Assistance from Insurance Veterans!. Super Top Up Your Health Cover With Just</p>
            <img src="https://i.imgur.com/qs2Yw2e.png" height="140" id="left_img_02" class="campaign-off-display">
            <img src="https://i.imgur.com/baAETgo.jpg" height="240" style="margin-left: -50px; margin-top:30px;" class="campaign-off-display" id="left_img_03">
         </div>
          <div class="col-md-6">
            <form id="initial_input_form" method="post" action="{{route('health.campaign.save_initial_inputs')}}" class="w-100">
               <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">  
               <div class="row">
                <div class="col-md-3"></div>
                  <div class="col-md-3">
                     <img src="{{URL::asset('campaign_assets/images/people/male.jpg')}}" height="120" class="m-auto d-block">
                     <div class="radio radio-success">
                        <input type="radio" name="self" id="insr_male" value="male" {{(!empty($data['initial_inputs']) && $data['initial_inputs']['self'] == 'male') ? 'checked=""' : ''}}>
                        <label for="insr_male">This is me</label>
                     </div>
                     <div class="styled-select blue semi-square">
                        <select id="male_age" name="male_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['adult']['title']); $index++)
                            <option value="{{$data['adult']['value'][$index]}}"   
                            {{(isset($data['initial_inputs']['male_age']) && $data['initial_inputs']['male_age'] == $data['adult']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['adult']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <img src="{{URL::asset('campaign_assets/images/people/female.jpg')}}" height="120" class="m-auto d-block">
                     <div class="radio radio-success">
                        <input type="radio" name="self" id="insr_female" value="female" 
                     {{(!empty($data['initial_inputs']) && $data['initial_inputs']['self'] == 'female') ? 'checked=""' : ''}} >
                        <label for="insr_female">This is me</label>
                     </div>
                     <div class="styled-select blue semi-square">
                        <select id="female_age" name="female_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['adult']['title']); $index++)
                            <option value="{{$data['adult']['value'][$index]}}"
                            {{(isset($data['initial_inputs']['female_age']) && $data['initial_inputs']['female_age'] == $data['adult']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['adult']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12" style="margin-top: 10px; height: 10px; border-bottom: 1.5px dotted #b9b6b6;"></div>
               </div>
               <div class="row" style="margin-top:20px">
                   <div class="col-md-3 p-t-10">&nbsp;</div>
                  <div class="col-md-3">
                     <img src="{{URL::asset('campaign_assets/images/people/son.jpg')}}" height="120" class="m-auto d-block">
                     <label class="front__label text-center m-auto d-block align-middle">Son</label>
                     <div class="styled-select blue semi-square">
                        <select id="son_age" name="son_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['child']['title']); $index++)
                            <option value="{{$data['child']['value'][$index]}}"
                            {{(isset($data['initial_inputs']['son_age']) && $data['initial_inputs']['son_age'] === $data['child']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['child']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3 p-t-10">
                     <img src="{{URL::asset('campaign_assets/images/people/daughter.jpg')}}" height="120" class="m-auto d-block">
                     <label class="front__label text-center m-auto d-block align-middle">Daughter</label>
                     <div class="styled-select blue semi-square">
                        <select id="daughter_age" name="daughter_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['child']['title']); $index++)
                            <option value="{{$data['child']['value'][$index]}}"
                            {{(isset($data['initial_inputs']['daughter_age']) && $data['initial_inputs']['daughter_age'] === $data['child']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['child']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div>
                  <!-- <div class="col-md-3 p-t-10">
                     <img src="{{URL::asset('campaign_assets/images/people/father.jpg')}}" height="120" class="m-auto d-block">
                     <label class="front__label align-middle m-auto d-block text-center">Father</label>
                     <div class="styled-select blue semi-square">
                        <select id="father_age" name="father_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['parent']['title']); $index++)
                            <option value="{{$data['parent']['value'][$index]}}" 
                            {{(isset($data['initial_inputs']['father_age']) && $data['initial_inputs']['father_age'] == $data['parent']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['parent']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div>
                  <div class="col-md-3">
                     <img src="{{URL::asset('campaign_assets/images/people/mother.jpg')}}" height="120" class="m-auto d-block">
                     <label class="front__label align-middle m-auto d-block text-center">Mother</label>
                     <div class="styled-select blue semi-square">
                        <select id="mother_age" name="mother_age">
                           <option selected="" disabled="">Select Age</option>
                            @for($index=0; $index < sizeof($data['parent']['title']); $index++)
                            <option value="{{$data['parent']['value'][$index]}}"
                            {{(isset($data['initial_inputs']['mother_age']) && $data['initial_inputs']['mother_age'] == $data['parent']['value'][$index]) ? 'selected=""' : ''}}
                            >{{$data['parent']['title'][$index]}}</option>
                            @endfor
                        </select>
                     </div>
                  </div> -->
               </div>
            </form>
            <div class="clearfix"></div>
            <p class="text-center m-5 d-block">
               <a class="text_clear link-red" id="clear_initial_selection_btn" >--- Oopsi Made a Mistake Selecting :/ ---</a>
            </p>
            <p class="text-center"><a class="btn btn--green-bg" id="get_plans" >GET SUPER TOPUP PLANS</a></p>
         </div>
         </div>
      </div>
       <br><br> 
   </div>
</section>
<!-- Section -- Basic Inputs ends-->
<!-- Section -- Quote -->
<section class="section section--about campaign-off-display" id="quote_searching_container">
   <input type="hidden" name="trans_code" id="trans_code" value=" {{ session()->get('trans_code') }}">
   <div class="container-fluid">
      <div class="section__content section__content--fluid-width section__content--about">
         <h2 class="section__title section__title--centered">Your Plan is getting ready...</h2>
         <div class="section__description section__description--centered">
            Dear <span class="text_style1">Sreehari</span>, relax while we bring the best plan for you. 
         </div>
         <div class="grid grid--5col grid--about">
            <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
         </div>
      </div>
   </div>
</section>
<section class="section section--about m-b-50 campaign-off-display" id="quote_container">
   <div class="container-fluid">
      <div class="section__content section__content--fluid-width section__content--about">
         <!-- <h2 class="section__title section__title--centered">Your Health Plan is ready</h2>
         <div class="section__description section__description--centered">
            Congrats <span class="text_style2">Sreehari</span>, Your customized super-topup plan is ready to purchase. Please click on the Sum Insured and Deductible to see the respective plan; and<br> <span class="text_style3">'Buy Button'</span> to purchase the policy. 
         </div> -->
         <div class="row">
            <div class="col-md-7">
               <div id="quote_box_loader_container">
                  <div id="quote_box_loader">
                     <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
                  </div>
               </div>
               <!-- Quote Box -->
               <div id="quote_box_container"></div>
            </div>
            <div class="col-md-5 m_covered_det">
               <!-- Members Covered -->
               <div id="mem_covered_container">
                  <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
               </div>
               <!-- Members Covered ends-->
               <!-- Sum Insured -->
               <div class="col-md-12 sum_ins_section">
                  <p class="sum_ins">Policy coverage (Sum Insured)</p>
                  <div class="row but_range">
                     <div class="col-md-12" id="si_container" style="line-height: 1.7em">
                        <button id="si_five" class="btn--special si--btn" value="500000">&#8377;5 lakhs</button>
                        <button id="si_six"  class=" btn--special si--btn" value="600000">&#8377;6 lakhs</button>
                        <button id="si_ten"  class=" btn--special si--btn" value="1000000">&#8377;10 lakhs</button>
                        <button id="si_eleven"  class=" btn--special si--btn" value="1100000">&#8377;11 lakhs</button>
                        <button id="si_fifteen"  class=" btn--special si--btn" value="1500000">&#8377;15 lakhs</button>
                        <button id="si_sixteen"  class=" btn--special si--btn" value="1600000">&#8377;16 lakhs</button>
                        <button id="si_twenty"  class=" btn--special si--btn btn-active" value="2000000">&#8377;20 lakhs</button>
                     </div>
                  </div>
                  <!-- Sum Insured ends-->
                  <!-- Deductible -->
                  <p class="sum_ins">Deductible</p>
                  <div class="row but_range">
                     <div class="col-md-12" id="deductible_container">
                        <button class=" btn--special dd--btn" value="400000">&#8377;4 lakhs</button>
                        <button class=" btn--special dd--btn btn-active" value="500000">&#8377;5 lakhs</button>
                     </div>
                  </div>
                  <!-- Deductible ends-->
                  <!-- Policy Term -->
                  <p class="sum_ins">Policy Tenure </p>
                  <div class="row but_range">
                     <div class="col-md-12" style="">
                        <button class=" btn--special tenure--btn btn-active" value="1">&#8377;1 Year</button>
                        <button class=" btn--special tenure--btn" value="2">&#8377;2 Years</button>
                     </div>
                  </div>
                  <!-- Policy Term ends-->
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Section -- Quote Inputs ends -->  
<!-- Section -- Proposal  --> 
<section class="section section--about campaign-off-display" id="proposal_container">
   <div class="sticky_close_btn_wrap position-absolute">
      <a href="#" id="close_proposal" url="{{route('health.campaign.close_proposal')}}">
         <div class="sticky_close_btn" title="Return to Quote Page">
            <p><img src="{{URL::asset('campaign_assets/images/cancel.png')}}"></p>
         </div>
      </a>
   </div>
   <input type="hidden" name="save_proposal_url" id="save_proposal_url" value="{{ route('health.campaign.save_proposal_data') }}">
   <div class="container-fluid">
      <div class="section__content section__content--fluid-width section__content--about">
         <h2 class="section__title section__title--centered">Policy Buyer's Details</h2>
         <p class="section__description section__description--centered">
            A simple and affordable solution to help ensure that you have an adequate Health Insurance cover!. It can be renewed annually or for a period of 2 years throughout your lifetime
         </p>
         <div class="grid grid--5col grid--about" id="widget_insurance">
            <div class="row">
               <div class="col-md-3"></div>
               <!-- Wizard status -->
               <div class="col-md-9" >
                  <ul class="widget_ul" id="widget_ul">
                     <li><a href="#" id="INSURED_MEMBERS_">1. Insured Members</a></li>
                     <li ><a href="#" id="ADDRESS_">2. Address</a></li>
                     <li ><a href="#" id="MEDICAL_HISTORY_">3. Medical History</a></li>
                     <li ><a href="#" id="PAYMENT_">4. Payment</a></li>
                  </ul>
               </div>
               <!-- Wizard status ends -->
               <!-- Spacing -->
               <!-- <div class="col-md-12" style="height: 50px;"></div> -->
               <!-- Spacing -->   
               <div class="col-md-3" style="margin-bottom: 100px;">
                  <div class="row text-center" style=" background-color: #f6f6f6; padding: 0px 0px 20px 0px; border-radius: 8px;">
                     <div style="background-color: red;  padding: 50px 0px 20px 0px; border-top-left-radius: 8px; border-top-right-radius: 8px;width:100%">
                        <div class="">
                           <img src="https://i.imgur.com/aAQSOVl.png" height="80">
                        </div>
                        <div style="padding: 10px 0px 0px 0px; text-transform: uppercase; color: grey; font-size: 15px; color: white;">
                           <strong>medisure super topup</strong>
                        </div>
                     </div>
                     <!-- <div class="row ticket-body"> -->
                     <div class="col-md-4" ">
                        <p class="m_amt" id="proposal_box_coverage">&#8377;0</p>
                        <p class="m_text">coverage</p>
                     </div>
                     <div class="col-md-4" >
                        <p class="m_amt" id="proposal_box_deductible">&#8377;0</p>
                        <p class="m_text">Deductible</p>
                     </div>
                     <div class="col-md-4">
                        <p class="m_amt" id="proposal_box_tenure">0</p>
                        <p class="m_text"> Tenure</p>
                     </div>
                  </div>
                  <!-- </div> -->
                  <div class="row" style="padding: 30px 0px 0px 0px;background-color: #f6f6f6; padding: 0px 0px 20px 0px; border-radius: 8px;">
                     <hr class="m_hr">
                     <p class="m_total w-100">Total Payable <span >&#8377;<span class="box_premium" id="proposal_box_premium" style="padding: 0">0</span></span></p>
                  </div>
                  <!--  <center><button class="tmp_save">Temp Save</button></center> -->
               </div>
               <div class="col-md-9 widget_parent">
                  <div class="row widget_ch" id="INSURED_MEMBERS">
                     <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
                  </div>
                  <!-- Address --> 
                  <div class="row widget_ch" id="ADDRESS" style="display: none">
                     <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
                  </div>
                  <!-- Address ends -->
                  <!-- Medical History --> 
                  <div class="row widget_ch" id="MEDICAL_HISTORY" style="display: none">
                     <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
                  </div>
                  <!-- Medical History ends -->
                  <!-- Proposal Submission --> 
                  <div class="row widget_ch" id="PAYMENT" style="display: none">
                     <center><img src="https://i.imgur.com/Sk39sU0.gif" height="100"></center>
                  </div>
                  <!-- Proposal Submission ends--> 
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Section -- Proposal  ends-->
<!-- Section -- Get In Touch -->
<!-- <section class="section section--cta " id="cta" style="margin-top: 100px;">
   <div class="section__content section__content--fluid-width section__content--padding section__content--cta">
      <h2 class="section__title section__title--centered section__title--cta">Get In Touch!</h2>
      <div class="section__description section__description--centered section__description--cta">
         Got something you want to talk about?. Our call & chat support is available from 10 a.m. to 6 p.m. on all days except Sundays & public holidays.
      </div>
      <div class="intro__buttons intro__buttons--centered">
         <a href="" class="btn btn--green-bg">CALL US NOW!</a>
      </div>
   </div>
   <svg class="svg-cta-top" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
      <path d="M0,100 L20,0 L100,20 100,0 0,0 Z" fill="#fff"/>
   </svg>
   <svg class="svg-cta-bottom" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">
      <path d="M0,0 L80,100 L100,10 100,100 0,100 Z" fill="#fff"/>
   </svg>
   </section> -->
<!-- Section -- Get In Touch ends-->
<!-- pdata_Modal Modal -->
<div id="Premium_modal" class="modal fade" role="dialog">
   <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
         <div class="modal-header flex-column border-0">
            <!-- <div class="sticky_close_btn_wrap position-absolute">
               <a href="">
                  <div class="sticky_close_btn">
                     <p><img src="{{URL::asset('campaign_assets/images/cancel-white.png')}}"></p>
                  </div>
               </a>
            </div> -->
            <h2 class="text-center w-100">HDFC Medisure Supertopup</h2>
            <p class="text-center w-100">Download policy wordings <a href="https://www.hdfcergo.com/documents/downloads/Brochures/myhealth_medisure_super_top_up_insurance_brochure.pdf" target="_blank" style="color: white;"><i class="fa fa-download" aria-hidden="true"></i></a></p>
         </div>
         <div class="modal-body">
            <div class="wrap">
               <ul class="tabs group">
                  <li><a class="active" href="#/one">Policy Coverage</a></li>
                  <li><a href="#/two">Claim Process</a></li>
                  <li><a href="#/three">Additional benefits</a></li>
               </ul>
               <div id="content" class="coverage_det">
                  <div id="one" class="tab_ul">
                     <ul>
                       <li>In-patient hospitalisation expenses: If the treatment of an illness or accidental injury is taken in a hospital, we cover the medical expenses incurred by you towards your hospitalisation on room rent/ICU/Therapeutic Unit, Medical Practitioner fees, Anaesthetist fees, nurse fees, blood, oxygen and anaesthesia. There are no sub-limits under this cover</li>
                       <li>Pre and Post-hospitalisation medical expenses: We understand that medical expenses start even before hospitalisation and continue post hospitalisation also. That’s why we cover all the medical expenses you incur up to 30 days before being admitted into a hospital and for 60 days after you have been discharged from hospital These expenses are payable subject to following condition</li>
                       <li></i>Such medicalexpenses are incurred for the same condition for which Your hospitalization was requiredandthe Inpatient Hospitalization claim for such hospitalization is admissible by Us</li>
                       <li>Expenses for Pre existing diseases: The Policy covers expenses incurred for the treatment of diseases that you have before taking the Policy.Such will be covered only after 3 continuous renewals with us</li>
                      
                     
                     <li>Day Care Procedures: The Policy also covers the medical expenses incurred by you for treatment or procedures that requires less than 24 hours of hospitalisation undertaken under general or local anesthesia. There is no static list for day care procedures in the policy as advances in medical science leads to many more being added continuously. So, even if it is a new procedure,you can be rest assured that,we will cover it.However,this cover excludes diagnostic procedures and treatments taken in an out-patient department. For the indicative list of covered treatments, please refer website www.hdfcergo.com</li>
                   </ul>
                  </div>
                  <div id="two" class="tab_ul" style="display: none">
                     <center><img src="https://i.imgur.com/P9Q5pW7.jpg" height="400"></center>
                  </div>
                  <div id="three" class="tab_ul" style="display: none">
                    <ul>
                     <li>Free-Look Period: This gives you an option of cancelling the Policy within 15 days from the date of receipt of Policy documents, if you are not satisfied with the coverage and terms of the Policy. We will refund the premium paid after adjusting the amounts spent on stamp duty charges, Medical examination (wherever applicable)and proportionate premium(If Policy has already commenced). Refund will not be applicable if you have made a claim against Policy during that period</li>
                     <li>Tax Benefit under Section 80D: This Policy offers tax benefits under Section 80D</li>
                     <li>Two Year Policy Period: You can take the Policy for a continuous period of two years and  get a 5% discount on the total premium amount of 2 years</li>
                     <li>Guaranteed Renewal for Life: You can renew your Policy throughout your lifetime, provided your application for renewal and the renewal premium are received in full before the due date or within a maximum of 30 days from such date. Please note that no claims will be payable during this gap period of 30 days</li>
                     <li>No Claims Experience Loading on Renewal: Even if you make a claim during the Policy year, we do not increase the premium to be paid at the time of renewaldueto claimsinthePolicy</li>
                     
                   <p class="phead">Service Guarantee:</p>
                     <li>In case of a Cashless Claim: HDFC assure a response within 6 hours for a cashless facility request, provided your intimation is received during working
                      hours from 9 am to 9 pm on Monday to Saturday. Incase HDFC fail to meet this assurance; HDFC will pay a fixed compensation/penalty of 1000. If your intimation is received after working hours on a working day, or any time during a holiday, HDFC assure a response within 8 hours</li>
                      <li>In case of a Reimbursement Claim: HDFC assure a response within 6 working days from the date of receipt of the complete set of documents</li></ul>
                    </div> <!-- three -->
                     
                  </div> <!-- content -->
               </div> <!-- wrap -->
             </div><!-- modal-body -->
            <div class="modal-footer border-0">
         </div>
         </div>
         
      </div>
 
</div>
<!-- p_data modal closed -->
@include('health.campaign.layouts.footer')
<link rel="stylesheet" href="{{ asset('campaign_assets/css/custom.css') }}">
<link rel="stylesheet" href="{{ asset('campaign_assets/css/ticket.css') }}">
<script src="{{URL::asset('campaign_assets/js/jquery.transitions.js')}}"></script>  
<script src="{{URL::asset('campaign_assets/js/widget.js')}}"></script>
<script src="{{URL::asset('campaign_assets/js/custom.js')}}"></script>
<script src="{{URL::asset('campaign_assets/js/details.js')}}"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="{{URL::asset('campaign_assets/js/proposal/proposal_validate.js')}}"></script>  
<script type="text/javascript">
var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || {widgetcode:"fcc4f109d0e86feac5f0570d60ffec93c383b8c5de17e92e033505b2ebdd3d4a5f5e9b2d67c73a39b99d25c184bb6b82", values:{},ready:function(){}};var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);d.write("<div id='zsiqwidget'></div>");
</script>
<script>
    window.fbAsyncInit = function() {
        FB.init({
            appId: '2055575661177439',
            xfbml: true,
            version: 'v2.8'
        });
    };

(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk')); 
</script>
@if (session()->has('pointer') )
@if(session()->get('pointer') == 'quote')
<script type="text/javascript">
   $( document ).ready(function() {
      var trans_code = $('#trans_code').val();
      $('#customer_details_container').removeClass('campaign-off-display');
      $('#quote_searching_container').removeClass('campaign-off-display');
      helper.scroll_to_container('#quote_searching_container');
      helper.load_hdfc(trans_code); 
   });   
</script>
@endif
@if(session()->get('pointer') == 'proposal')
<script type="text/javascript">
   $( document ).ready(function() {
      var trans_code = $('#trans_code').val();
      helper.load_proposal(trans_code);
   });   
</script>
@endif
@endif