<footer class="footer" id="footer">
   <div class="footer__content footer__content--fluid-width footer__content--svg">
      <div class="grid grid--5col">
         <div class="grid__item grid__item--x2">
            <h3 class="grid__title grid__title--footer-logo">TOYOTA TSUSHO INS. BROKING INDIA PVT. LTD.</h3>
            <p class="grid__text grid__text--copyright">IRDAI Composite Licence Number : 381. Valid Up To : 01/09/2020. CIN : U66010KA2008PTC045231</p>
            <p class="grid__text grid__text--copyright">Copyright &copy; 2018 TTIBI.  <br />All Rights Reserved. Proudly made in IN. </p>
            <p class="grid__text grid__text--copyright"><strong>Insurance is a subject matter of solicitation.</strong></p>
         </div>
         <div class="grid__item">
            <h3 class="grid__title grid__title--footer">Company</h3>
            <ul class="grid__list grid__list--fmenu">
               <li><a href="http://ttibi.com/about/">About</a></li>
               <li><a href="http://ttibi.com/board-of-directors/">Board of Directors</a></li>
               <li><a href="http://ttibi.com/careers/">Carrers</a></li>
               <li><a href="http://ttibi.com/awards-and-recognition/">Awards</a></li>
            </ul>
         </div>
         <div class="grid__item">
            <h3 class="grid__title grid__title--footer">Products</h3>
            <ul class="grid__list grid__list--fmenu">
               <li><a href="http://ttibi.com/motor-insurance/">Car Insurance</a></li>
               <li><a href="http://ttibi.com/motor-insurance/">Two wheeler Insurance</a></li>
               <li><a href="http://ttibi.com/health-insurance/">Health Insurance</a></li>
               <li><a href="http://ttibi.com/travel-insurance/">Travel Insurance</a></li>
            </ul>
         </div>
         <div class="grid__item">
            <h3 class="grid__title grid__title--footer">Related Programs</h3>
            <ul class="grid__list grid__list--fmenu">
               <li><a href="https://www.instainsure.com/">InstaInsure</a></li>
               <li><a href="http://lexusprotect.co.in/">Toyota protect</a></li>
               <li><a href="https://www.eichersecure.com/">Eicher Secure</a></li>
               <li><a href="https://www.eichersecure.com/">We Care Yamaha</a></li>
            </ul>
         </div>
      </div>
   </div>
</footer>
<script src="{{URL::asset('campaign_assets/js/jquery-3.3.1.min.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/jquery.mask.js')}}"></script> 
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="{{URL::asset('campaign_assets/js/jquery.validate.min.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/jquery.paroller.min.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/jquery.custom.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/swiper.min.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/swiper.custom.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/menu.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/loading.js')}}"></script> 
<script src="{{URL::asset('campaign_assets/js/jquery.cookie.js')}}"></script>
<script type="text/javascript">
   $('body').loading({message: "loading..."});
   $('body').show();
</script>
<script>
  		window.fbAsyncInit = function() {
    	FB.init({
      	appId      : '2055575661177439',
      	xfbml      : true,
      	version    : 'v2.8'
    		});
  		};

  		(function(d, s, id){
     	var js, fjs = d.getElementsByTagName(s)[0];
     	if (d.getElementById(id)) {return;}
     		js = d.createElement(s); js.id = id;
     		js.src = "//connect.facebook.net/en_US/sdk.js";
     		fjs.parentNode.insertBefore(js, fjs);
   		}(document, 'script', 'facebook-jssdk'));
	</script>
<script src="{{URL::asset('campaign_assets/js/tooltipster.bundle.min.js')}}"></script> 
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</body>
</html>