<header class="header">
		<div class="header__content header__content--fluid-width">
			<div class="header__logo-title"><a href="http://ttibi.com/" target="_blank"><img src="http://ttibi.com/wp-content/uploads/2019/01/TTIBI-Logo-Small.png"></a></div>
			<nav class="header__menu">                                                                   
				<ul>
			    @if(isset($count))		
					<li class="header__btn header__btn--login"><a  style="cursor: default;">{{$count}} <i class="fas fa-apple-alt"></i></a></li>
				@endif			
				</ul>
			</nav>
		</div>		
	</header>