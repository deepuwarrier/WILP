<div class="row">
   @foreach($members as $index => $item)    
   <div class="col-md-4">
      <p class="text-center" style="padding-top: 10px; font-size: 18px; font-weight: 500">
         <img src="{{URL::asset($member_image_array[$index])}}" height="70">
         <span class="age"> {{ $age[$index] }}</span>
      </p>
   </div>
   @endforeach
</div>