<div id="address_container" class="w-100">
   <form id="ADDRESS_FORM" class="w-100">
      <h4 class="w-100">Address</h4>
      <div class="row w-100">
         <div class="col-md-4">
            <div class="form__row">
               <label class="form__label" for="state">State</label>
               <select name="state" id="state" class="form__select" route="{{route('health.get_city')}}">
                  <option selected="" value="" hidden="">Select an option</option>
                  @foreach($data['state_list'] as $state_data)
                  <option value="{{$state_data['state_code']}}" 
                       {{ ( !empty($saved_data) && isset($saved_data['state']) && ($saved_data['state'] == $state_data['state_code'] ) ) ? 'selected=""' : ''  }}>{{ucwords(strtolower($state_data['state_name']))}}</option>
                  @endforeach
               </select>
               <span class="form__row-border"></span>
            </div>
         </div>
         <div class="col-md-4">
            <div class="form__row">
               <label class="form__label" for="city">City</label>
               <select name="city" id="city" class="form__select">
                  <option selected="" value="" hidden="">City list is empty</option>
                  @if( !empty($saved_data) && isset($saved_data['city_list']) )
                     @foreach($saved_data['city_list'] as $city_data)
                       <option value="{{$city_data['city_code']}}" 
                       {{ ( !empty($saved_data) && isset($saved_data['city']) && ($saved_data['city'] == $city_data['city_code'] ) ) ? 'selected=""' : ''  }}>{{ucwords(strtolower($city_data['city_name']))}}</option>
                     @endforeach
                  @endif   
               </select>
               <span class="form__row-border"></span>
            </div>
         </div>
         <div class="col-md-4">
            <div class="form__row">
               <label class="form__label" for="pincode">Pincode</label>
               <input name="pincode" 
                      id="pincode" 
                      class="form__input" 
                      type="text" 
                      placeholder="" 
                      maxlength="6" 
                      value = "{{ ( !empty($saved_data) && isset($saved_data['pincode']) ) ? $saved_data['pincode'] : '' }}"
                      />
               <span class="form__row-border"></span>
            </div>
         </div>
      </div>
      <div class="row w-100">
         <div class="col-md-12">
            <div class="form__row">
               <label class="form__label" for="street">Address Line 1</label>
               <input name="street" 
                      id="street" 
                      class="form__input" 
                      type="text" 
                      placeholder="" 
                      value = "{{ (!empty($saved_data) && isset($saved_data['street']) ) ? $saved_data['street'] : '' }}"/>
               <span class="form__row-border"></span>
            </div>
         </div>
         <div class="col-md-12">
            <div class="form__row">
               <label class="form__label" for="locality">Address Line 2</label>
               <input name="locality" 
                      id="locality" 
                      class="form__input" 
                      type="text" 
                      placeholder=""
                      value = "{{ (!empty($saved_data) && isset($saved_data['locality']) ) ? $saved_data['locality'] : '' }}" />
               <span class="form__row-border"></span>
            </div>
         </div>
      </div>
</div>
</form>