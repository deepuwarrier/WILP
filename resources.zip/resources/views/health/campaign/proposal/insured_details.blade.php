@if($data)
<form id="INSURED_MEMBERS_FORM" class="w-100"> 
@foreach($data['member_list'] as $index => $item)
<h4 class="w-100">{{$item}}  Details</h4>
<span style="font-size: 14px; color:#bdbfbd; font-weight: 500;">Age {{$data['age_list'][$index]}}</span>
<div class="row w-100">
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">First Name</label>
         <input name="firstname[]" 
            id="firstname{{$index}}" 
            class="form__input" 
            type="text" 
            placeholder="" 
            value = "{{ (!empty($saved_data) && isset($saved_data['firstname'][$index]) ) ? $saved_data['firstname'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Last Name</label>
         <input name="lastname[]" 
            id="lastname{{$index}}" 
            class="form__input" 
            type="text" 
            placeholder=""
            value = "{{ (!empty($saved_data) && isset($saved_data['lastname'][$index]) ) ? $saved_data['lastname'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
</div>
@if($item == 'Self')
<div class="row w-100">
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Mobile No.</label>
         <input name="mobile" 
            id="mobile" 
            class="form__input" 
            type="text" 
            placeholder="" 
            otp-status-url= "{{route('health.campaign.check_otp_status')}}"
            verify-otp-url= "{{route('health.campaign.verify_otp')}}" 
            value = "{{ (!empty($saved_data) && isset($saved_data['mobile']) ) ? $saved_data['mobile'] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Email ID</label>
         <input name="email" 
            id="email" 
            class="form__input" 
            type="text" 
            placeholder="" 
            value = "{{ (!empty($saved_data) && isset($saved_data['email']) ) ? $saved_data['email'] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
</div>
@endif
<div class="row w-100">
   <div class="col-md-3">
      <div class="form__row">
         <label class="form__label" for="namec">Height</label>
         <input name="height_feet[]" 
            id="height_feet{{$index}}" 
            class="form__input" 
            type="text" 
            placeholder="Feet"
            value = "{{ (!empty($saved_data) && isset($saved_data['height_feet'][$index]) ) ? $saved_data['height_feet'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   <div class="col-md-3">
      <div class="form__row">
         <label class="form__label" for="namec">&nbsp;</label>
         <input name="height_inches[]" 
            id="height_inches{{$index}}" 
            class="form__input" 
            type="text" 
            placeholder="Inches"
            value = "{{ (!empty($saved_data) && isset($saved_data['height_inches'][$index]) ) ? $saved_data['height_inches'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Weight</label>
         <input name="weight[]" 
            id="weight{{$index}}" 
            class="form__input" 
            type="text" 
            placeholder="Kg"
            value = "{{ (!empty($saved_data) && isset($saved_data['weight'][$index]) ) ? $saved_data['weight'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
</div>
<div class="row w-100">
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="dob_list">Date of Birth</label>
         <input name="dob_list[]" 
            id="dob_list{{$index}}" 
            class="form__input datepicker" 
            type="text" 
            min-date = "{{$data['dob_list'][$index]['min_date']}}"
            max-date = "{{$data['dob_list'][$index]['max_date']}}"
            placeholder="Eg: 12-01-1989 (Day-Month-Year)"
            value = "{{ (!empty($saved_data) && isset($saved_data['dob_list'][$index]) ) ? $saved_data['dob_list'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   @if($index == 0)
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Aadhaar Number</label>
         <input name="aadhaar_num[]" 
            id="aadhaar_num{{$index}}" 
            class="form__input aadhaar" 
            type="text" 
            placeholder="" 
            maxlength="14"
            value = "{{ (!empty($saved_data) && isset($saved_data['aadhaar_num'][$index]) ) ? $saved_data['aadhaar_num'][$index] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   @endif
</div>
   @if($index + 1 < sizeof($data['member_list']))
      <div class="col-md-12" style="height: 50px;"></div>
   @endif
@endforeach   
@endif  
<div class="col-md-12" style="height: 20px;"></div>
<p class="w-100">Policy Nominee Details</p>
<div class="row nominee_det w-100">
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Nominee Name</label>
         <input name="nominee_name" 
            id="nominee_name" 
            class="form__input" 
            type="text" 
            placeholder="" 
            value = "{{ (!empty($saved_data) && isset($saved_data['nominee_name']) ) ? $saved_data['nominee_name'] : '' }}"
            />
         <span class="form__row-border"></span>
      </div>
   </div>
   <div class="col-md-6">
      <div class="form__row">
         <label class="form__label" for="namec">Relationship</label>
         <select name="nominee_relation" id="nominee_relation" class="form__select required">
            <option selected="" value="" hidden="">Select an option</option>
            <option value="B" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'B' ) ? 'selected=""' : '' }}>Sibling</option>
            <option value="E" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'E' ) ? 'selected=""' : '' }}>Niece</option>
            <option value="G" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'G' ) ? 'selected=""' : '' }}>GrandParent</option>
            <option value="H" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'H' ) ? 'selected=""' : '' }}>GrandChild</option>
            <option value="K" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'K' ) ? 'selected=""' : '' }}>Brother-in-Law</option>
            <option value="L" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'L' ) ? 'selected=""' : '' }}>Sister-in-Law</option>
            <option value="N" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'N' ) ? 'selected=""' : '' }}>Nephew</option>
            <option value="P" {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'P' ) ? 'selected=""' : '' }}>Parent</option>
            <option value="S"  {{ (!empty($saved_data) && $saved_data['nominee_relation'] == 'S' ) ? 'selected=""' : '' }}>Spouse</option>
         </select>
         <span class="form__row-border"></span>
      </div>
   </div>
</div>
<div class="col-md-12" style="height: 100px;"></div>
</form>