<h4 class="w-100 p-0">Medical History</h4>
@if($data)
<form id="MEDICAL_HISTORY_FORM" class="w-100">
   <div class="form__row medical_H">
      <label class="p-0" for="namec">Does any person(s) to be insured is suffering from any disease, illness or injury?</label>
      <button class="btn ped_question 
         {{($saved_data['ped_list'] != null && $saved_data['ped_list']['ped']['illness'] == '1') ? 'btn-active' : ''}}" type="button" value="yes">Yes</button>
      <button class="btn ped_question 
         {{($saved_data['ped_list'] != null && $saved_data['ped_list']['ped']['illness'] == '0') ? 'btn-active' : ''}}" type="button" value="no">No</button>
   </div>
   <input type="hidden" 
          name="ped_qn" 
          id="ped_qn" 
          @if(($saved_data['ped_list'] != null) && ($saved_data['ped_list']['ped']['illness'] == '0'))
          value= "n"
          @elseif(($saved_data['ped_list'] != null) && ($saved_data['ped_list']['ped']['illness'] == '1'))
          value= "y"
          @else
          value= ""
          @endif
          >

   <div class="row medical_H 
        {{($saved_data['ped_list'] != null && $saved_data['ped_list']['ped']['illness'] == '1') ? '' : 'campaign-off-display'}}" id="ped_container">
      <div class="col-md-12" style="font-weight: 500;">
      <label class="w-100 p-0">Select member</label>
      </div>
      @foreach($data['member_list'] as $index => $item)
      <div class="col-md-4">
         <?php $ped_index = 'disease_member_'.($index + 1); ?>
         <div class="checkbox check-primary">
            <input type="checkbox" value="disease_member_{{$index + 1}}"  name="disease_member_{{$index + 1}}" id="disease_member_{{$index + 1}}" {{(isset($saved_data['ped_list']['pedname'][$ped_index])) ? 'checked=""' : ''}}>
            <label for="disease_member_{{$index + 1}}">{{ ($item === 'Self') ? 'You' : $item  }} ({{$data['age_list'][$index]}})</label>
            <input name="pedname[disease_member_{{$index + 1}}]" 
                  id="disease_member_{{$index + 1}}_textfield" 
                  class="form__input" 
                  type="text" 
                  value="{{(isset($saved_data['ped_list']['pedname'][$ped_index])) ? $saved_data['ped_list']['pedname'][$ped_index]: ''}}"
                  placeholder="Mention the details here" />
            <span id="disease_member_{{$index + 1}}_textfield_error" style="color: red;"></span>      
            <span class="form__row-border"></span>
         </div>
      </div>
      @endforeach
      <div class="col-md-12">
         <br><span id="ped_common_error" style="color: red;"></span>
      </div>
      <!-- <div class="col-md-12">
         <center><img src="{{URL::asset('campaign_assets/images/ped_doc.jpg')}}"></center>
      </div>  -->  
   </div>
</form>
@endif