<div id="payment_container" class="w-100">
<form id="PAYMENT_FORM" class="w-100">
<img src="https://i.imgur.com/gW2wNqD.jpgs" class="d-block m-auto">
<div class="row w-100">
  <p class="proposal-declaration">Declaration: By clicking on make payment button you confirm that all the information provided in the proposal form are true to the best of your knowledge and also agree to appoint Toyota Tsusho Insurance Broker to represent you as your Insurance Broker</p>

   <input type="hidden" name="pg_service_url" id="pg_service_url" value="{{route('health.campaign.connect_pg')}}">
   <div class="checkbox check-primary d-block w-100">
      <p class="text-center"> 
         <input type="checkbox" 
                value="DD" 
                id="checkbox8" 
                class="payment_checkbox" {{( ($pay_mode!=null) && $pay_mode =='DD') ?  'checked=""' : '' }}>

         <label for="checkbox8">Pay Via Netbanking</label>
         <input type="checkbox" 
                value="CC" 
                id="checkbox9" 
                class="payment_checkbox" {{( ($pay_mode!=null) && $pay_mode =='CC') ?  'checked=""' : '' }}>
         <label for="checkbox9">Pay Via Credit/Debit Card</label>
      </p>
   </div>
   <div class="col-md-12" style="margin-top: -10px;">
      <center><input type="hidden" 
                     name="payment_option" 
                     id="payment_option" 
                     value="{{( $pay_mode!=null) ? $pay_mode : ''}}">
      </center>
   </div>
   <button type="button" class="btn btn--green-bg m-auto d-block proposal-make-payment-btn" id="make_payment_btn">Make Payment - &#8377;<span class="box_premium"></span></button>
</div>
</form>
<br><br><br>
</div>