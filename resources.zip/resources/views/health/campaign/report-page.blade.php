<!DOCTYPE html>
<head>
   <title>TTIBI | Toyota Tsusho Insurance Broker India Pvt Ltd | Super topup</title>
   <link rel="shortcut icon" type="image/png" href="https://i.imgur.com/oa3PnSj.png"/>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
   <meta name="robots" content="index, follow">
   <meta name="language" content="EN">
   <meta name="copyright" content="InstaInsure">
   <meta name="document-classification" content="Internet">
   <meta name="document-type" content="Public">
   <meta name="document-rating" content="Safe for Kids">
   <meta name="document-distribution" content="Global">
   <meta name="description" content="InstaInsure is one stop destination to buy all your insurance starting from Car Insurance,Bike insurance,Travel Insurance,Health Insurance.">
   <meta name="keywords" content="instainsure, buy insurance online, buy insurance for car, buy insurance online for bike, buy insurance for travel, buy insurance online for health">
   <meta name="description" content="InstaInsure is one stop destination to buy all your insurance starting from Car Insurance,Bike insurance,Travel Insurance,Health Insurance." />
   <!-- <link rel="stylesheet" href="{{ asset('campaign_assets/bootstrap.css') }}"> -->
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/swiper.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/style.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/tooltipster.bundle.min.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/loading.css') }}">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,900" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
</head>
<body>
   @include('health.campaign.layouts.nav') 
   <section class="section">
      <div class="section__content section__content--fluid-width section__content--intro ">
         <div class="intro w-100">
            <div class="intro__content w-100">
               <form method="post" action="{{route('health.campaign.fetchreport')}}" class="w-100">
               <div class="row">
               	  <div class="col-md-3">
               	  	  <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
               	  	  <input type="hidden" name="report_passcode" id="report_passcode" value="Ttibi@999">  
				      <div class="form__row">
				         <label class="form__label" for="from_date">From date</label>
				         <input  
				            id="from_date"
				            name="from_date" 
				            class="form__input datepicker" 
				            type="text" 
				            min-date = ""
				            max-date = ""
				            placeholder=""
				            value = "{{$date['from_date']}}"
				            readonly="readonly"
				            />
				         <span class="form__row-border"></span>
				      </div>
				   </div>
				   <div class="col-md-3">
				      <div class="form__row">
				         <label class="form__label" for="to_date">To date</label>
				         <input 
				            id="to_date" 
				            name="to_date" 
				            class="form__input datepicker" 
				            type="text" 
				            min-date = ""
				            max-date = ""
				            placeholder=""
				            value = "{{$date['to_date']}}"
				            readonly="readonly"
				            />
				         <span class="form__row-border"></span>
				      </div>
				   </div>
				   <div class="col-md-3">
				   	<div class="form__row">
				   		<!-- <p class="text-center"><a class="btn btn--green-bg" id="get_plans" >FETCH</a></p> -->
				   		<label class="form__label" for="">&nbsp;</label>
				         <input 
				            type="submit" 
				            value = "Fetch"
				            class="report_fetch_btn" 
				            />
				         <span class="form__row-border"></span>
				      </div>
				    </div>	
				   	</form>
			
                  <div class="col-md-12">
                  	 <br><br>
                  	 @if($status)
                     <table class="table report-table">
                        <thead class="thead-dark">
                           <tr>
                              <th scope="col">#</th>
                              <th scope="col">Name</th>
                              <th scope="col">Mobile</th>
                              <th scope="col">Email</th>
                              <th scope="col">Plan</th>
                              <th scope="col">Stage</th>
                              <th scope="col">Date</th>
                           </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $index=>$item)
                           <tr>
                              <td>{{$index + 1}}</td>
                              <td>{{$item['firstname'][0]}} {{$item['lastname'][0]}}</td>
                              <td>{{$item['mobile']}}</td>
                              <td>{{$item['email']}}</td>
                              <td>{{$item['members_list']}}</td>
                              <td>{{$item['campaign_customer_pointer']}}</td>
                              <td>{{$item['created_at']}}</td>
                           </tr>
                        @endforeach   
                        </tbody>
                     </table>
                     @else
                     <center><img src="https://i.imgur.com/NdEqYDM.jpg"></center>
                     <center><h5 class="no-record-head">No record found!</h5></center>
                     <center><p class="no-record-msg">May be you can try a different date</p></center>
                     @endif
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/custom.css') }}">
   <script src="{{URL::asset('campaign_assets/js/jquery-3.3.1.min.js')}}"></script> 
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script src="{{URL::asset('campaign_assets/js/jquery.validate.min.js')}}"></script> 
   <script src="{{URL::asset('campaign_assets/js/campaign-reports.js')}}"></script> 
   <script src="{{URL::asset('campaign_assets/js/menu.js')}}"></script> 
   <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
   <script src="{{URL::asset('campaign_assets/js/proposal/proposal_validate.js')}}"></script> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   @if (session()->has('error') )
   <script type="text/javascript">
      $( document ).ready(function() {
           swal({
                  title: 'Authentication failed',
                  html: true,
                  text: "  ",
                  icon: 'warning',
                  buttons: false
              });
      });   
   </script>
   <?php session()->forget('error'); ?>
   @endif
</body>
</html>