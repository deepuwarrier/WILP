<!DOCTYPE html>
<head>
   <title>TTIBI | Toyota Tsusho Insurance Broker India Pvt Ltd | Super topup</title>
   <link rel="shortcut icon" type="image/png" href="https://i.imgur.com/oa3PnSj.png"/>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
   <meta name="robots" content="index, follow">
   <meta name="language" content="EN">
   <meta name="copyright" content="InstaInsure">
   <meta name="document-classification" content="Internet">
   <meta name="document-type" content="Public">
   <meta name="document-rating" content="Safe for Kids">
   <meta name="document-distribution" content="Global">
   <meta name="description" content="InstaInsure is one stop destination to buy all your insurance starting from Car Insurance,Bike insurance,Travel Insurance,Health Insurance.">
   <meta name="keywords" content="instainsure, buy insurance online, buy insurance for car, buy insurance online for bike, buy insurance for travel, buy insurance online for health">
   <meta name="description" content="InstaInsure is one stop destination to buy all your insurance starting from Car Insurance,Bike insurance,Travel Insurance,Health Insurance." />
   <!-- <link rel="stylesheet" href="{{ asset('campaign_assets/bootstrap.css') }}"> -->
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/swiper.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/style.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/tooltipster.bundle.min.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/loading.css') }}">
   <link rel="stylesheet" href="{{ asset('campaign_assets/css/custom.css') }}">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,900" rel="stylesheet">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" >
</head>
<body>
	@include('health.campaign.layouts.nav') 
   <section class="section">
      <div class="section__content section__content--fluid-width section__content--intro ">
         <div class="intro w-100">
            <div class="intro__content w-100">
               <div class="row">
                  <div class="col-md-4"></div>
                  <div class="col-md-4">
                     <form id="campaign-report-form" action="{{route('health.campaign.fetchreport')}}" method="post">
                     	<input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">  
                        <div class="row">
                           <div class="col-md-12">
                           	  <center><img src="https://i.imgur.com/wHyUq5h.jpg" height="200"></center>
                              <div class="form__row">
                                 <center><label class="form__label">Authentication<span id="otp_attempts_text"></span></label></center>
                              </div>
                              <div class="form__row">
                                 <label class="form__label" for="report_passcode">Passcode</label>
                                 <input name="report_passcode" id="report_passcode" class="form__input report-passcode" type="password" placeholder="" maxlength="10" />
                                 <span class="form__row-border"></span>
                              </div>
                              <br>
                              <div class="form__row">
                                 <p class="text-center"><a class="btn btn--green-bg" id="report_pass_verify_btn" >VERIFY</a></p>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div class="col-md-4"></div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <script src="{{URL::asset('campaign_assets/js/jquery-3.3.1.min.js')}}"></script> 
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script src="{{URL::asset('campaign_assets/js/jquery.validate.min.js')}}"></script> 
   <script src="{{URL::asset('campaign_assets/js/campaign-reports.js')}}"></script> 
   <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
   <script src="{{URL::asset('campaign_assets/js/proposal/proposal_validate.js')}}"></script> 
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   <script src="{{URL::asset('campaign_assets/js/loading.js')}}"></script> 
   @if (session()->has('error') )
	<script type="text/javascript">
	   $( document ).ready(function() {
	        swal({
                title: 'Authentication failed',
                html: true,
                text: "  ",
                icon: 'warning',
                buttons: false
            });
	   });   
	</script>
	<?php session()->forget('error'); ?>
    @endif
</body>
</html>