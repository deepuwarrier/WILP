<img src="{{URL::asset('campaign_assets/images/doc.jpg')}}" height="200" class="d-block m-auto">
<table style="width: 100%; text-align: center;">
   @if(isset($data['bmi_check']) && $data['bmi_check'] == 'true')
   <tr>
      <td style="font-weight: 600;">BMI of {{$data['member'][0]['name']}} based on height({{$data['member'][0]['height']}}) and weight({{$data['member'][0]['weight']}}) is {{$data['member'][0]['bmi']}}</td>
   </tr>
   @endif
   @if(isset($data['ped_check']) && $data['ped_check'] == 'true')
   <tr>
      <td> {{ $data['ped_msg']}} </td>
   </tr>
   @endif
   @if(isset($data['age_check']) && $data['age_check'] == 'true')
   <tr>
      <td> {{ $data['age_msg']}} 
   <tr>
      <td>
         @endif
</table>
<p>Your policy is subject to medical evaluation. {{ strtoupper($data['insurer_id']) }} Health Insurance team will contact you for further processing. You can Proceed to online payment, but policy may be issued post clearance of medical test.</p>
<button type="button" class="btn btn--green-bg m-auto d-block proposal-make-payment-btn" id="accept_medical_condition">Yea, I accept the condition. Proceed to payment</button>