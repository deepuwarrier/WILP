@include('health.layouts.inn-hdr')
<style>
.members {
min-width:150px !important;
font-weight: normal !important;
}
.age_list{
font-weight: normal !important;
}
</style> 

<!--      Wizard container        -->
<div class="wizard-container addmargin">
    <div class="card wizard-card" data-color="green" id="wizardProfile">
        <form  action="{{ URL::route('health.load_policy_page',$trans_code) }}" method="post" id="formuserdata">
            <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
            <input type="hidden" name="sum_insured" id="sum_insured" value="500000">
            <input type="hidden" name="pincode" id="pincode" value="560001">
            <input type="hidden" name="trans_code" id="trans_code" value="{{$trans_code}}">
            <input type="hidden" name="session_id" id="session_id" value="@if(@$userdetails){{ $userdetails['session_id'] }}@endif" class="required">
            <h3 style="text-align: center; color: #92cf1b; font-weight: 400;">
                              InstaInsure.com </h3> 
                              <h4><i style="color: #00669c; padding:0 5px 0 5px; display: block;"><b>Compare</b> and <b>Buy</b> the best Health Insurance policy online. <b>Super Quick!</b></i>
                           </h4>
            <div class="wizard-navigation">
                <ul class="nav nav-pills">
                    <li style="width: 14.2857%;" class="active">
                        <a href="#members" data-toggle="tab" aria-expanded="true">Members</a>
                    </li>
                </ul>
            </div> 
            <div class="tab-content">
                <div class="tab-pane active" id="members">
                    <div class="row">
                        <h6>Add Members</h6>
                        <div class="container tabdata" data-url='' id='members-container'>
                            <section id="form-repeater">
                                <div class="repeater-default">
                                    <div class="container-fluid" id ="placeDiv">
                                            @if(@$userdetails)
                                                <?php  $dob = explode('|', $userdetails['dob_list']);
                                                    $age = explode('|', $userdetails['age_list']);
                                                    $members = count(explode('|', $userdetails['dob_list'])); 
                                                    $mem = explode("|", $userdetails['members_list']); 
                                                ?>
                                                <input type="hidden" name="membercount" id="memcount" value="{{ $members }}">
                                                @if ($members>=1)
                                                    @for($i = 0; $i < $members ; $i++)
                                                        @if($i>=1) <div class="row" id="appendfield"> 
                                                        @else
                                                         <div class="row">@endif
                                                            <div class="datarepeaterbox" data-repeater-item>
                                                                <div class="col-xs-6">
                                                                    <select name="memberslist[]" data-item="member{{$i}}" id="mem_add" counter="{{$i}}" class="members form-control required" aria-invalid="false">
                                                                        @if($mem[$i] == 'SELF')
                                                                            <option value="SELF ">SELF </option>
                                                                        @else
                                                                            @foreach($relmembers as $rem)
                                                                                <option value="{{$rem['rel_id']}} " <?php if ($rem['rel_id'] === $mem[$i]) { echo "selected" ;} ?>> {{$rem['rel_name']}}</option>
                                                                            @endforeach 
                                                                        @endif         
                                                                    </select>
                                                                    <span class="material-input"></span>
                                                                </div>
                                                                <div class="col-xs-4">
                   
                    <select name="agelist[]" id="age" class="age_list form-control required" aria-invalid="false" data-item = '{{$age[$i]}}'>

                   
                    @if($age[$i] === '3m') 
                    <option value="3m" selected>1-3 Months</option>
                    <option value="10m">3-12 Months</option>
                    @elseif($age[$i] === '10m')
                    <option value="3m">1-3 Months</option>
                    <option value="10m" selected>3-12 Months</option>
                    @else
                    @if($mem[$i] == 'SONM' || $mem[$i] == 'UDTR')
                    <option value="3m">1-3 Months</option>
                    <option value="10m">3-12 Months</option>
                    @endif
                    @endif
    
                   @foreach($age_list[$mem[$i]] as $key => $val)
                    <option value="{{$val}}" {{((strcmp($age[$i],$val))) ? '' : 'selected' }}> {{$val}} Years</option>

                    @endforeach

                    </select>
                                                                    <span class="material-input"></span>
                                                                </div>
                                                                @if($i==0)
                                                                    <div class="col-xs-2" id="addmem">
                                                                        <input type="button" class="material-icons" id="add-member" value="add"/>
                                                                    </div>
                                                                @else
                                                                  
                   <div class="col-xs-2" id="delete-member">
                      <input type="button" name="remove" class="material-icons" value="remove" id="del{{$i}}"/>
                    </div> 


                                                                @endif
                                                            </div>
                                                        </div>

                                                    @endfor 
                                                @endif
                                            @else
                                            <div class="row">
                                                <div class="datarepeaterbox" data-repeater-item>
                                                    <div class="col-xs-6">
                                                        <select name="memberslist[]" data-item="member0" id="mem_add" class="members form-control required" aria-invalid="false" >
                                                            <option value="SELF"> SELF </option>
                                                        </select>
                                                        <span class="material-input"></span>
                                                    </div>
                                                    <div class="col-xs-4">
                                                        <select name="agelist[]" id="age" class="age_list form-control required" aria-invalid="false" >
                                                            <option value="" >Select Age</option>
                                                            @for($i=18;$i<=110;$i++)
                                                                <option value="{{$i}}">{{$i}} Years</option>
                                                            @endfor
                                                        </select>
                                                        <span class="material-input"></span>
                                                    </div>
                                                    <div class="col-xs-2" id="addmem">
                                                        <input type="button" class="material-icons" id="add-member" value="add"/>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                    <br>
                                    <input class="quotes-btn btn btn-finish btn-info" name="finish" value="Generate Quotes"  type="button" id="submit-form">
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- wizard container -->
<div class="homelogobox">
    @include('layouts.c_partners')
</div>


<div class="features-1" >@include('layouts.c_legacy') </div>
<div class="features-5" >@include('layouts.c_whyus') </div>
<div class="testimonials-2 section-image" >@include('layouts.c_testimonial')</div>
<div class="blogs-2" style="padding-top: 80px">@include('layouts.c_blog')</div>
<div class="team-1" >@include('layouts.c_team')</div>
<div class="contactus-1 section-image">@include('layouts.c_contact')</div>
<!-- footer section -->

@include('health.layouts.inn-ftr')

<script type="text/javascript" src="{{ URL::asset('js/health/healthdetails.js') }}"></script>