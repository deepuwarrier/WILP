<div id="overlay" style="display:none"></div>
@include('layouts.footer') 

      <script src="{{ asset('js/common.js') }}"></script>
      <script src="{{URL::asset('js/sweetalert2.js') }}"></script>
      <script src="{{asset('js/perfect-scrollbar.jquery.min.js')}}" type="text/javascript"></script>
      <script src="{{asset('js/jquery.bootstrap-wizard.js')}}"></script>
      <script src="{{asset('js/component/jquery.validate.min.js')}}"></script>
      <script src="{{asset('js/insta-toolkit.js')}}"></script>
      <script src="{{asset('js/component/demo.js')}}"></script>
      <script src="{{asset('js/component/rtoasset.js')}}"></script>
      <script src="{{asset('js/jquery.repeater.js')}}" type="text/javascript"></script>
      <script src="{{asset('js/form-repeater.js')}}" type="text/javascript"></script>
      <script src="{{asset('js/jquery.isonscreen.js')}}" type="text/javascript"></script>
      <script type="text/javascript">
         $().ready(function() {
         demo.initMaterialWizard();
         });
      </script>
      <style>
      input.dedqtyplus { width: 30px; height: 29px; background-color: white !important;border-style: none;border-radius: 20px;font-size: 20px;font-weight: 400;}
      input.dedqtyminus {width: 20px;height: 29px; background-color: white !important;border-style: none;border-radius: 20px;float: left;font-size: 30px;font-weight: 400;}
      </style>
      <script>// Get all the keys from document
         var keys = document.querySelectorAll('#js-calculator button');
         
         // Add onclick event to all the keys and perform operations
         for(var i = 0; i < keys.length; i++) {if (window.CP.shouldStopExecution(1)){break;}
            keys[i].onclick = function(e) {
               // Get the input and button values
               var input = document.querySelector('.screen');
               var inputVal = input.innerHTML;
               var btnVal = this.innerHTML;
               
               // Now, just append the key values (btnValue) to the input string and finally use javascript's eval function to get the result
               // If clear key is pressed, erase everything
               if(btnVal == 'Clear') {
                  input.innerHTML = '';
                  decimalAdded = false;
               }
               
               // if any other key is pressed, just append it
               else {
                  input.innerHTML += btnVal;
               }
               
               // prevent page jumps
               e.preventDefault();
            } 
         }
         window.CP.exitedLoop(1);
         
      </script>
    
      

