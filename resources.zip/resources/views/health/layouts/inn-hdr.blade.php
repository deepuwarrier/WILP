@include('layouts.header')
<link href="{{asset('css/select2.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="{{asset('css/wizard.css')}}" />
<link href="{{asset('css/font-awesome.min.css')}}" rel="stylesheet">

<style>
.radiobutton input[type='radio']:disabled + label{ cursor:not-allowed !important; }

#appendfield { margin-top: 10px; }
</style>
<style type="text/css">
  .ui-datepicker-prev { display: none; }
  .ui-datepicker-next { display: none; }
</style>
<script type="text/javascript">
	var APP_URL = '<?php echo URL::to('/');?>';
</script>