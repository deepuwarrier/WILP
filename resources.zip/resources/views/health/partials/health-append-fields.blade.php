<div class="row" id="appendfield">
  <div class="datarepeaterbox" data-repeater-item>
      <div class="col-xs-6">
           <select name="memberslist[]" data-item="member{{$counter}}" id="mem_add" counter="{{$counter}}" class="members form-control valid" aria-invalid="false" required>
           <option value="">Relationship</option>
               @foreach($relmembers as $members)
            <option value="{{ $members->rel_id }}">{{ $members->rel_name }}</option>
          @endforeach
          </select>
          <span class="material-input"></span>
      </div>
      <div class="col-xs-4">
        <select name="agelist[]" id="age" class="age_list form-control valid" aria-invalid="false">
          <option value="" >Select Age</option>
          @for($i=18;$i<=110;$i++)
              <option value="{{$i}}">{{$i}} Years</option>
          @endfor
       </select>
         
          <span class="material-input"></span>
      </div> 

      <div class="col-xs-2">
          <input type="button" class="material-icons" name="remove" value="remove" id="del{{$counter}}" />
      </div>
  </div>
</div>
