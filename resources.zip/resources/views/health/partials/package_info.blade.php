<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-body">
            <div class="card card-pricing card-margin">
                <div class="row customcard">
                    <div class="col-sm-4 logobox">
                        <img src="{{ $res['img_url'] }}">
                    </div>
                      <div class="col-sm-4">
                          <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{ round($res['total_premium'])}}</h5>
                          <span class="label label-default extrapanelitem">SI: &#8377; {{ $res['suminsured'] }}</span>
                          @if(substr($res['product_id'], 0, 3 ) === 'HST')
                          <p class="extrapanelitem" style="color: #E91E63">Deductible &#8377; {{$res['deductables']}}</p>
                          @endif
                          @if($data['product_type'] === 'S' && ($res['product_id'] === 'Classic' || $res['product_id'] === 'Supreme'))
                          <p class="extrapanelitem" style="color: #E91E63">Deductible &#8377; {{$res['deductables']}}</p>
                          @endif

                          <p>{{$res['product_name']}}</p>
                          @if(($res['product_id'] == 'religare_elite'
                              || $res['product_id'] == 'religare_elite_plus'
                              || $res['product_id'] == 'religare_super_saver')
                              && $res['age'] > 60)
                          <p class="extrapanelitem" style="color: #E91E63; margin-top: -15px;">20% co-payment applied</p>
                          @endif

                      </div>
                </div>

                <div class="content" style="margin-top: -6%;">
                  @if($res['product_type'] == 'S' && ($res['product_id'] == 'Classic' || $res['product_id'] == 'Supreme' ))
                  @else
                  <center><h3>Many Benefits in <b>one</b> Package</h3></center>
                  <center><h4><span id="mhdr">Available covers in Package</span></h4></center>
                    <div>
                        <table class="table responsive" style="text-align: left; font-size: 12px;">
                            <tbody>
                                @foreach ($data['benifit_plan'] as $cover)
                                    <?php $coverplans = (implode('|', $cover));
                                          $package_info = (explode('|', $coverplans)); ?>
                                      <tr>
                                        <td style="color:black; width: 44%;">{{$package_info['0']}}</td>
                          <!-- pakage information starts -->
                                          <?php if(!empty($coverplans)){ ?> 
                                          <td>

                                             {{ $package_info['1'] }}
                                          </td>
                                          <?php } ?>
                                          <td></td> 
                          <!-- package information ends -->
                                      </tr>
                                 
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                  @endif
                </div>
            </div>
          <!-- RELIGARE SUPER TOPUP-->
            @if($res['product_id'] == 'religare_elite'
                || $res['product_id'] == 'religare_elite_plus'
                || $res['product_id'] == 'religare_global'
                || $res['product_id'] == 'religare_super_saver')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://cms.religarehealthinsurance.com/cms/public/uploads/download_center/care-(health-insurance-product)--prospectus-cum-sales-literature.pdf" target="_blank"> Download Product Brochure.</a></u><br><br>

              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="https://cms.religarehealthinsurance.com/cms/public/uploads/download_center/care-(health-insurance-product)---policy-terms-&-conditions.pdf" target="_blank"> Download Policy Wording.</a></u>

            @endif

            <!-- RELIGARE SUPER TOPUP-->
            @if($res['product_id'] == 'INRELSTP')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://cms.religarehealthinsurance.com/cms/public/uploads/download_center/enhance-(top-up-insurance-product)---brochure.pdf" target="_blank"> Download Product Brochure.</a></u><br><br>

              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href=" https://cms.religarehealthinsurance.com/cms/public/uploads/download_center/enhance-(top-up-insurance-product)---policy-terms-&-conditions.pdf" target="_blank"> Download Policy Wording.</a></u>
              
            @endif
            

            <!-- RSGI Classic Plans -->
            @if($res['product_id'] == 'Classic' && $res['product_type'] == 'B')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://www.royalsundaram.in/files/lifeline-classic-brochure.pdf" target="_blank"> Download Product Brochure.</a></u><br><br>
            @endif

            <!-- RSGI Supreme Plans -->
            @if($res['product_id'] == 'Supreme' && $res['product_type'] == 'B')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://www.royalsundaram.in/files/lifeline-supreme-brochure.pdf" target="_blank"> Download Product Brochure.</a></u><br><br>
            @endif

             <!-- RSGI Elite Plans -->
            @if($res['product_id'] == 'Elite' && $res['product_type'] == 'B')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://www.royalsundaram.in/files/lifeline-elite-brochure.pdf" target="_blank"> Download Product Brochure.</a></u><br><br>
            @endif


            <!-- RSGI Top UP  -->
            @if($res['product_type'] == 'S' && ($res['product_id'] == 'Classic' || $res['product_id'] == 'Supreme'))
              To know the features and benifits of this product, please refer the insurer top up product brochure. <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/rsgi_lifeline_with_topup_one_pager.pdf')}}" target="_blank"> Download TopUp Product Brochure.</a></u><br><br>

              @if($res['product_id'] == 'Classic')
              To know the features and benifits of this product, please refer the insurer LifeLine product brochure. <u><a style="color:#00669C" href="https://www.royalsundaram.in/files/lifeline-classic-brochure.pdf" target="_blank"> Download LifeLine Product Brochure.</a></u><br><br>
              @endif

              @if($res['product_id'] == 'Supreme')
              To know the features and benifits of this product, please refer the insurer LifeLine product brochure. <u><a style="color:#00669C" href="https://www.royalsundaram.in/files/lifeline-supreme-brochure.pdf" target="_blank"> Download LifeLine Product Brochure.</a></u><br><br>
              @endif


            @endif

            <!-- RSGI policy wording -->
            @if($res['product_id'] == 'Classic' || $res['product_id'] == 'Supreme' || $res['product_id'] == 'Elite')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="https://www.royalsundaram.in/Files/lifeline-terms.pdf" target="_blank"> Download Policy Wording.</a></u>
            @endif

               <!-- HDFC all Plan pdf -->
            @if(substr($res['product_id'], 0, 3 ) === 'SRE' || substr($res['product_id'], 0, 3 ) === 'HSS' || substr($res['product_id'], 0, 3 ) === 'HS1' || substr($res['product_id'], 0, 3 ) === 'GRE' || substr($res['product_id'], 0, 3 ) === 'HSG' || substr($res['product_id'], 0, 3 ) === 'HG1')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/policywordings/health-suraksha-insurance-faqs-policy-wording.pdf" target="_blank"> Download Policy Wording.</a></u>            
            @endif
            <br><br>
            <!-- Health Suraksha Silver Regain  plan -->
            @if(substr($res['product_id'], 0, 3 ) === 'SRE')
              To know the features and benifits of this product, please refer the insurer product brochure.<u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/Brochures/Health%20Suraksha%20Silvr%20Plan%20Regain%20and%20ECB.pdf" target="_blank"> Download Product Brochure.</a></u>            
            @endif

            <!-- Health Suraksha Silver plan -->
            @if(substr($res['product_id'], 0, 3 ) === 'HSS' || substr($res['product_id'], 0, 3 ) === 'HS1')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/Brochures/health-suraksha-silver-plan.pdf" target="_blank"> Download Product Brochure.</a></u>            
            @endif


            <!-- Health Suraksha Gold Regain & Gold plan -->
            @if(substr($res['product_id'], 0, 3 ) === 'GRE' || substr($res['product_id'], 0, 3 ) === 'HSG' || substr($res['product_id'], 0, 3 ) === 'HG1')
              To know the features and benifits of this product, please refer the insurer product brochure. <u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/Brochures/Health%20Suraksha%20Gold%20Plan%20Regain%20and%20ECB.pdf" target="_blank"> Download Product Brochure.</a></u>            
            @endif
            
            <!-- Health Super TopUp plan -->
            @if(substr($res['product_id'], 0, 3 ) === 'HST')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/policywordings/myhealth_Medisure_Super_Top_Up_Insurance_Policy_Wordings.pdf" target="_blank"> Download Policy Wording</a></u><br><br>
              Click here to 
              <u><a style="color:#00669C" href="https://www.hdfcergo.com/documents/downloads/Brochures/myhealth_medisure_super_top_up_insurance_brochure.pdf" target="_blank"> Download Policy Brochure</a></u> 
            @endif
            
            <!-- Star package info Starts -->
            @if($res['product_id'] == 'MCINEW') 
              To know the features and benifits of this product, please refer the insurer product brochure. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Medi-Classic-Individual-Brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif
            @if($res['product_id'] == 'FHONEW') 
              To know the features and benifits of this product, please refer the insurer product brochure. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Family-Health-Optima-Insurance-brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif
            @if($res['product_id'] == 'COMPREHENSIVEIND' || $res['product_id'] == 'COMPREHENSIVE')
              To know the features and benifits of this product, please refer the insurer product brochure. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Comprehensive-Brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif
            @if($res['product_id'] == 'DIABETESIND' || $res['product_id'] == 'DIABETESFMLY')
              To know the features and benifits of this product, please refer the insurer product brochure. 
              <u> <a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Diabetes-Safe-Brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif
            @if($res['product_id'] == 'REDCARPET')
              To know the features and benifits of this product, please refer the insurer product brochure. <u> <a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Senior-Citizen-Red-Carpet-Brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif
      <!-- Star Policy Wording starts-->
            @if($res['product_id'] == 'MCINEW')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Mediclassic-Individual-Insurance-Policy-terms.pdf')}}" target="_blank">Download Policy Wording.</a></u>   
            @endif
            @if($res['product_id'] == 'FHONEW')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-FHO-Insurance-policy.pdf')}}"  target="_blank"> Download Policy Wording.</a></u>  
            @endif
            @if($res['product_id'] == 'COMPREHENSIVEIND' || $res['product_id'] == 'COMPREHENSIVE')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Comprehensive-Insurance-Policy.pdf')}}" target="_blank">Download Policy Wording.</a></u>
            @endif
            @if($res['product_id'] == 'DIABETESIND' || $res['product_id'] == 'DIABETESFMLY')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Diabetes-Safe-Insurance-Policy.pdf')}}"  target="_blank"> Download Policy Wording.</a></u> 
            @endif
            @if($res['product_id'] == 'REDCARPET')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Star-Senior-Citizens-Red-Carpet-Health-Insurance-Policy.pdf')}}"  target="_blank"> Download Policy Wording.</a></u>  
            @endif
            <!-- Ends Star package info -->

             <!--Reliance package info -->

             @if($res['product_id'] == 'HealthGain') 
              To know the features and benifits of this product, please refer the insurer product brochure. 
              <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Reliance-HealthGain-Policy-Brochure.pdf')}}"  target="_blank">  Download Product Brochure.</a></u><br><br>
            @endif

            @if($res['product_id'] == 'HealthGain')
              For exact terms and conditions of the policy, read the policy wordings carefully before concluding the purchase. <u><a style="color:#00669C" href="{{ URL::asset('pdf/health/Reliance-HealthGain-Policy-wording.pdf')}}"  target="_blank"> Download Policy Wording.</a></u>  
            @endif

            <!-- Ends Reliance package info -->

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
            <span id="editor"></span>
        </div>
    </div>
</div>