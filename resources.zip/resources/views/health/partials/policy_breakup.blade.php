<div class="modal-dialog">
   <div class="modal-content premium-breakup-card ">
      <div class="modal-body premium-breakup">
         <div class="card customcard">
            <div class="col-sm-4 logobox">
               <img src="{{$res['img_url']}}">
            </div>
            <div class="col-sm-4"> 
               <h5 class="card-title price" style="margin-top: 15px;" >&#8377; {{ $res['total_premium'] }}</h5>
               <span class="label label-default extrapanelitem">SI: &#8377; {{ $res['suminsured']}} </span>
               @if($res['product_type'] == 'S')
                  <p class="extrapanelitem" style="color: #E91E63">Deductible &#8377; {{$res['deductables']}}</p>
               @endif
               <p>  {{$res['product_name']}}  </p>
               @if(($res['product_id'] == 'religare_elite'
                     || $res['product_id'] == 'religare_elite_plus'
                     || $res['product_id'] == 'religare_super_saver')
                     && $res['age'] > 60)
                  <p class="extrapanelitem" style="color: #E91E63; margin-top: -15px;">20% co-payment applied</p>
               @endif
            </div>
            <div class="col-sm-4 buybutton" style="margin-top: 15px;">
               <p>&nbsp;</p>
            </div>
         </div>
         <h3>Premium Breakup</h3>
         <h4>Basic Premium</h4>
         <ul>
            <li>
               <span class="">Basic Premium</span>
               <span class="value pull-right">&#8377;  {{ $res['basepremium'] }}</span>
            </li>
         </ul>
         <h4>Taxes</h4>
         <ul>
            <li>
               <span>Goods & Service Tax</span>
               <span class="pull-right">&#8377;  {{ round($res['servicetax']) }}</span>
            </li>
         </ul>
         <h4>Total Premium</h4>
         <ul>
            <li class="finalprm">
               <span>Payable Premium</span>
               <span class="pull-right">&#8377;  {{ $res['total_premium'] }}</span>
            </li>
         </ul>
      </div>
      <div class="modal-footer">
         <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
         </div>
      </div> 
   </div>
</div>