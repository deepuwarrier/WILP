<!-- status href contaoner -->
<input type="hidden" id="premiumstatus" name="premiumstatus" value="{{route('health.policy.premiumstatus')}}">
<input type="hidden" id="premiumreconfirm" name="premiumreconfirm" value="{{route('health.policy.premiumreconfirm')}}">
<input type="hidden" id="premiummissmatch" name="premiummissmatch" value="{{route('health.policy.premiummissmatchstatus')}}">
<input type="hidden" id="policy_check" name="policy_check" value="{{route('health.policy_check')}}">
<input type="hidden" id="hdfc_policy_check" name="hdfc_policy_check" value="{{route('health.hdfc_policy_check')}}">
<input type="hidden" id="star_policy_check" name="star_policy_check" value="{{route('health.star_policy_check')}}">
<input type="hidden" id="reliance_policy_check" name="reliance_policy_check" value="{{route('health.reliance_policy_check')}}">
<input type="hidden" id="badresponse" name="badresponse" value="{{route('health.policy.badresponse')}}">
<!-- end status href contaoner -->
<input type="hidden" id="api_bad_response" name="badresponse" value="{{route('health_api_bad_response')}}">

<div class="wizard-container">
    <div class="col-md-4">
    <!-- User_details preview blade -->
        <div class="card card-form-horizontal">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a href="{{ route('health.healthhome') }}"><button type="button" class="btn btn-info btn-xs pull-right">Change</button></a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Insurance Policy For :</h6>
                    </div>
                </div>
                <input type="hidden" class="ajaxRequiredData" name="trans_code" id="trans_code" value="{{ $quote->get_trans_code()}}"/>
                <div class="row content" style="text-align: left">
                    <p><span class="label label-default">Members Age :</span>
                    <span class="label label-default">{{ $quote->get_insurer_age_list() }}</span></p>
                </div>
            </div>
        </div>
    </div>
    <!-- wizard container -->
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:130px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                 <form  action="{{ URL::route('health.load_policy_page', $quote->get_trans_code()) }}" method="post" id="choicedata">
                        <input type="hidden" name="update_cust_choice" value="1">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type='hidden' name='suminsured' value="{{ $quote->get_sum_insured() }}" />
                            <input type='hidden' name='deductibles' value="{{ $quote->get_deductible_amount() }}" />
                            <input type="hidden" name="plan_type" value="{{$quote->get_plan_type()}}">
                            <input type="hidden" name="product_type" value="{{$quote->get_product_type()}}">
                             <input type="hidden" name="tenure" value="{{$quote->get_tenure()}}">
                            <button type="submit" class="btn btn-info btn-xs pull-right">Change</button>
                        </form>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information :</h6>
                    </div>
                </div>
                <table class="table customtable">
                    <tbody>
                        <tr>
                            <td>Policy Start-Date</td>
                            <td class="text-right">
                                {{ $quote->get_policy_start() }}
                            </td>
                            <td>Policy End-Date</td>
                            <td class="text-right">
                                {{ $quote->get_policy_end() }}
                            </td>
                        </tr>
                        <tr>
                            <td>Sum Insured</td>
                            <td class="text-right">
                                &#8377; {{ $quote->get_sum_insured() }} 
                            </td>
                            <td> Policy Type</td>
                            <td class="text-right">
                                @if($quote->get_plan_type() == 'FF') Family Floater @else Individual @endif
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row card customcard" style="min-height:130px">
            <div class="col-xs-4 logobox">
                <img src="{{URL::to('/')}}/image/logos/{{$insurer_details['insurer_logo']}}">
            </div>
                <div class="col-xs-8 centeralign" style="text-align: right">
                           <h6>{{$insurer_details['insurer_name']}}
             
                        <h5 class="card-title" style="font-size:30px">&#8377; {{round($quote->get_totalPremium())}}</h5>
                        
                        @if($quote->get_product_type() == 'S' && !empty($quote->get_deductible_amount())) 
                        <span class="extrapanelitem" style="color: #E91E63">Deductible &#8377;{{ $quote->get_deductible_amount() }}</span>
                        @endif
                      {{ $quote->get_product_name() }}  

            <!-- Package info -->
        <a href="#" id="h_benefits" name="h_benefits" class="h_benefits"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#BenefitModal").modal();' title="Package Info">stars</i></a>
            <input type="hidden" name="totalPremium" id="totalPremium" value="{{$quote->get_totalPremium()}}">
            <input type="hidden" name="servicetax" id="servicetax" value="{{$quote->get_serviceTax()}}">
          <input type="hidden" name="sum_insured" id="sum_insured" value="{{ $quote->get_sum_insured() }}">
          <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{$insurer_details['insurer_logo']}}">
          <input type="hidden" name="product_id" id="product_id" value="{{$quote->get_product_id()}}">
          <input type="hidden" name="product_name" id="product_name" value="{{$quote->get_product_name()}}">
          <input type="hidden" name="basepremium" id="basepremium" value="{{$quote->get_premium()}}">
          <input type="hidden" name="h_benifitUrl" id="h_benifitUrl" value="{{route('health.h_benefit_req')}}"> 
 <!-- Premium breakup  -->
             <a href="#" id="h_breakup" name="h_breakup" class="h_breakup"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#premiumBreakup").modal();' title="Premium Breakup">description</i></a>
           <input type="hidden" name="totalPremium" id="totalPremium" value="{{round($quote->get_totalPremium())}}">
            <input type="hidden" name="servicetax" id="servicetax" value="{{$quote->get_serviceTax()}}">
          <input type="hidden" name="sum_insured" id="sum_insured" value="{{ $quote->get_sum_insured() }}">
          <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{$insurer_details['insurer_logo']}}">
          <input type="hidden" name="product_id" id="product_id" value="{{$quote->get_product_id()}}">
          <input type="hidden" name="product_name" id="product_name" value="{{$quote->get_product_name()}}">
           <input type="hidden" name="basepremium" id="basepremium" value="{{$quote->get_premium()}}">
          <input type="hidden" name="h_breakupUrl" id="h_breakupUrl" value="{{route('healthbr')}}"> 
         </div>
       </div>
      </div>
    </div>
</div>
