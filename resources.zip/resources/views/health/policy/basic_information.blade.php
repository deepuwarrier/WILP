<!-- status href contaoner -->
<input type="hidden" id="premiumstatus" name="premiumstatus" value="{{route('health.policy.premiumstatus')}}">
<input type="hidden" id="premiumreconfirm" name="premiumreconfirm" value="{{route('health.policy.premiumreconfirm')}}">
<input type="hidden" id="premiummissmatch" name="premiummissmatch" value="{{route('health.policy.premiummissmatchstatus')}}">

<input type="hidden" id="policy_check" name="policy_check" value="{{route('health.policy_check')}}">

<input type="hidden" id="hdfc_policy_check" name="hdfc_policy_check" value="{{route('health.hdfc_policy_check')}}">

<input type="hidden" id="badresponse" name="badresponse" value="{{route('health.policy.badresponse')}}">
<!-- end status href contaoner -->
<input type="hidden" id="api_bad_response" name="badresponse" value="{{route('health_api_bad_response')}}">

<div class="wizard-container">
    <div class="col-md-4">
         @include('health.quote.user_details_preview')
    </div>
    <!-- wizard container -->
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:130px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                 <form  action="{{ URL::route('health.load_policy_page',$data['userdata']['trans_code']) }}" method="post" id="choicedata">
                        <input type="hidden" name="update_cust_choice" value="1">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type='hidden' name='suminsured' value="{{ $data['userdata']['sum_insured'] }}" />
                            <input type='hidden' name='deductables' value="{{ $data['userdata']['deductables'] }}" />
                            <input type="hidden" name="plan_type" value="{{$data['userdata']['plan_type']}}">
                            <input type="hidden" name="product_type" value="{{$data['userdata']['product_type']}}">
                             <input type="hidden" name="tenure" value="{{$data['userdata']['tenure']}}">
                            <button type="submit" class="btn btn-info btn-xs pull-right">Change</button>
                        </form>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information :</h6>
                    </div>
                </div>
                <table class="table customtable">
                    <tbody>
                        <tr>
                            <td>Policy Start-Date</td>
                            <td class="text-right">
                                {{ date("d-m-Y", strtotime($data['policy_dates']['p_start'])) }}
                            </td>
                            <td>Policy End-Date</td>
                            <td class="text-right">
                                {{ date("d-m-Y", strtotime($data['policy_dates']['p_ends'])) }}
                            </td>
                        </tr>
                        <tr>
                            <td>Sum Insured</td>
                            <td class="text-right">
                                @if(isset($data['userdata']['sum_insured']))
                                &#8377; {{ $data['userdata']['sum_insured'] }} 
                                @else()
                                &#8377; {{ $data['userdata']['sum_insured'] }} 
                                @endif
                            </td>
                            <td> Policy Type</td>
                            <td class="text-right">
                                @if($data['userdata']['plan_type'] == 'FF') Family Floater @else Individual @endif
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row card customcard" style="min-height:130px">
            <div class="col-xs-4 logobox">
                <img src="{{URL::to('/')}}/image/logos/{{ $data['userdata']['insurerName'] }}_logo.png">
            </div>
            <div class="col-xs-8 centeralign" style="text-align: right">
                <h6>{{$data['userdata']['insurerName']}}</h6>
                <h5 class="card-title" style="font-size:30px">&#8377;{{round($data['userdata']['totalPremium'])}}</h5>
                @if($data['userdata']['product_type'] == 'S' &&isset($data['userdata']['deductables']) && !empty($data['userdata']['deductables'])) 
                <span class="extrapanelitem" style="color: #E91E63">Deductible &#8377;{{$data['userdata']['deductables']}}</span>@endif
                @if($data['userdata']['insurerName'] == 'religare')
                <span class="extrapanelitem" style="color: #E91E63">EMI available for this plan - </span>
                @endif 
                <span class="extrapanelitem"> {{$data['userdata']['productName']}} {{$data['userdata']['product_planname']}} </span>          

        <a href="#" id="h_benefits" name="h_benefits" class="h_benefits"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#BenefitModal").modal();' title="Package Info">stars</i></a>
        <input type="hidden" name="totalPremium" id="totalPremium" value="{{round($data['userdata']['totalPremium'])}}">
        <input type="hidden" name="servicetax" id="servicetax" value="{{round($data['userdata']['serviceTax'])}}">
        <input type="hidden" name="sum_insured" id="sum_insured" value="{{$data['userdata']['sum_insured']}}">
        <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{$data['userdata']['insurerName']}}_logo.png">
        <input type="hidden" name="product_id" id="product_id" value="{{$data['userdata']['productId']}}">
        <input type="hidden" name="product_name" id="product_name" value="{{$data['userdata']['productName']}}">
        <input type="hidden" name="basepremium" id="basepremium" value="{{round($data['userdata']['basePremium'])}}">
        <input type="hidden" name="h_benifitUrl" id="h_benifitUrl" value="{{route('health.h_benefit_req')}}">

        <!-- Premium breakup  -->
        <a href="#" id="h_breakup" name="h_breakup" class="h_breakup"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#premiumBreakup").modal();' title="Premium Breakup">description</i></a>
        <input type="hidden" name="totalPremium" id="totalPremium" value="{{round($data['userdata']['totalPremium'])}}">
        <input type="hidden" name="servicetax" id="servicetax" value="{{round($data['userdata']['serviceTax'])}}">
        <input type="hidden" name="sum_insured" id="sum_insured" value="{{ $data['userdata']['sum_insured']}}">
        <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{$data['userdata']['insurerName']}}_logo.png">
        <input type="hidden" name="product_id" id="product_id" value="{{$data['userdata']['productId']}}">
        <input type="hidden" name="product_name" id="product_name" value="{{$data['userdata']['productName']}}">
        <input type="hidden" name="basepremium" id="basepremium" value="{{round($data['userdata']['basePremium'])}}">
        <input type="hidden" name="h_breakupUrl" id="h_breakupUrl" value="{{route('healthbr')}}"> 

         </div>
       </div>
      </div>
    </div>
</div>