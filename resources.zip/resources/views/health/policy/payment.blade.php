
@if($policy['error'])

     <?php echo $policy['error'];?>
@else
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
BrokerEdge API Reference v1.01.03 Copyright © Last Decimal Pvt. Limited 107 | P a g e BrokerEdge® API Documentation LAST DECIMAL.

<head id="Head1" runat="server">
    <title></title>
    <script language="javascript" type="text/javascript">
        function submitHealthForm() {
            document.PAYMENTFORM.submit();
        }
    </script>
</head>

<body>
    
    <!-- <form action='https://www.religarehealthinsurance.com/portalui/PortalPayment.run' name='PAYMENTFORM' method='post'> -->
    <form action="{{ $policy['online_purchase_link'] }}" name='PAYMENTFORM' method='post'>
        <div>
            <input type='hidden' name='proposalNum' value="{{ $policy['proposalNum'] }}" />
            <input type='hidden' name='returnURL' value="{{ $policy['returnURL'] }}" /> 
        </div>
        <script language='javascript' type="text/javascript">
            submitHealthForm();
        </script>
    </form>
    
</body>

</html>
@endif