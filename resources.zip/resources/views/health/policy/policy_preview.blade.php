<style>
 .info_text{
   color: #4E4A4A;
  }
 .previewheight{
    min-height: 300px !important;
 }
</style>
<div class="row">
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#insured" id="insured_btn">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">Insured Details:</h6>
                </div>
            </div>
            <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="insured_preview">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#communication">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">Communication:</h6>
                </div>
            </div>
            <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="communication_preview">
                </div>
            </div>
        </div>
    </div>
</div>


<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#healthhistory">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">Health History:</h6>
                </div>
            </div>
            <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="health_ped_preview">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button type="button" class="btn btn-info btn-xs pull-right change" data-href="#nominee_details">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    @if($quote->get_insurer_name() == 'rsgi')
                    <h6 class="pull-left">More Info:</h6>
                    @else
                    <h6 class="pull-left">Nominee Details:</h6>
                    @endif
                </div>
            </div>
            <div class="row" style="font-size: 12px;">
                <div class="col-sm-12" style="text-align: left" id="nominee_details_preview">
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<div class="col-md-12 radiobutton uk-form uk-form-row">
    
    <label>
        <input name="disclaimer" type="checkbox" value="disclaimer"
        id="disclaimer" >

        I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.
    </label>
</div>