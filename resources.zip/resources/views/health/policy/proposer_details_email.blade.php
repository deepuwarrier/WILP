<html>
	<head>
		<title>New Enquiry</title>
	</head>
	<body>
	<?php

		$members = count($data_value->dob); 
		$mem = $data_value->relationshipId; 
	?>
	<p>A new policy has been applied with the following details</p>
		<table>
			<tr colspan='2'>
				<td><strong>Policy Type:</strong></td>
				@if($data_value->plan_type == 'FF')
					<td>Family Floater</td>
				@else
					<td>Individual</td>
				@endif
			</tr>
			<tr><td></td></tr>

			<tr colspan='2'>
				<td><strong>Policy Details:</strong></td>
			</tr>
			<tr>
				<td>Insurer Name - </td>
				<td>{{$data_value->insurerName}}</td>
			</tr>
			<tr>
				<td>Policy Start Dtae - </td>
				<td>{{$data_value->p_start}}</td>
			</tr>
			<tr>
				<td>Policy End Dtae - </td>
				<td>{{$data_value->p_ends}}</td>
			</tr>
			<tr>
				<td>Sum Insured </td>
				<td>&#8377; {{$data_value->suminsured['0']}}</td>
			<tr>
				<td>Base Premium </td>
				<td>&#8377; {{$data_value->basePremium}}</td>
			</tr>
			<tr>
				<td>Service Tax </td>
				<td>&#8377; {{$data_value->serviceTax}}</td>
			</tr>
			<tr>
				<td>Total Premium </td>
				<td>&#8377; {{$data_value->totalPremium}}</td>
			</tr>
			<tr><td></td></tr>

				<tr colspan='2'>
				<td><strong>Proposer Details:</strong></td>
			</tr>
			<tr>
				<td>No of Adults</td>
				<td>{{$data_value->adults}}</td>
			</tr>
			<tr>
				<td>No of Children</td>
				<td>{{$data_value->children}}</td>
			</tr>
			<tr><td></td></tr>
			@if ($members>=1)
				@for($i = 1; $i <= $members ; $i++)
					<tr><td> <u>Person {{$i}} Details</u></td></tr>
					<tr>
						<td> DOB </td>
						<td>{{$data_value->dob[$i-1]}}</td>
					</tr>
					<tr>
						<td>Full Name </td>
						<td> {{ $data_value->firstname[$i-1]}} {{ $data_value->lastname[$i-1]}}</td>
					</tr>
					
				@endfor
			@endif  
			<tr><td></td><td></tr>

			<tr colspan='2'>
				<td><strong>Communication Details:</strong></td>
			</tr>
			<tr>
				<td>Address</td>
				<td>{{$data_value->houseno}}, {{$data_value->street}}, {{$data_value->locality}},<br>
				{{$data_value->city}}, {{$data_value->state_name}},<br>
				PIN - {{ $data_value->pincode}}</td>
			</tr>
			<tr>
				<td>Email</td>
				<td>{{$data_value->email}}</td>
			</tr>
			<tr>
				<td>Mobile</td>
				<td>{{$data_value->mobile}}</td>
			</tr>
		</table>
	</body>
</html>