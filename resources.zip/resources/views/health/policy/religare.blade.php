@include('health.layouts.inn-hdr') @include('health.policy.basic_information')
<!-- start form wizard  -->
 <form autocomplete="off"  method="post" action="{{ route('health.policy.religare.submit_proposal') }}" id="buy_policy_form" name="pro_form">
  <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
  <input type="hidden" name="membercount" id="membercount" value="{{ sizeof($data['userdata']['members_list'])}}">
  <input type="hidden" name="session_id" id="session_id" value="{{$data['userdata']['session_id']}}"/>
  <input type="hidden" name="trans_code" id="trans_code" value="{{$data['userdata']['session_id']}}"/>
  <input type="hidden" id="insurer_name" name="insurer_name" value="{{ $data['userdata']['insurerId'] }}">
  <input type="hidden" id="insurerId" name="insurerId" value="{{ $data['userdata']['insurerId'] }}">
  <input type="hidden" name="datastatus" id="datastatus" value="{{route('health.getconfirm')}}">
</form>  
<style type="text/css">
  .show-info{
    text-transform: uppercase !important;
  }
</style>
<div class="row">
   <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
      <div class="card wizard-card" data-color="green" id="wizardProfile">
         <div class="wizard-navigation">
           <ul class="nav nav-pills">
              <li style="width: 20%;" class="active">
                 <a href="#insured" data-toggle="tab" aria-expanded="">Insured</a>
              </li>
              <li style="width:20%;">
                 <a href="#communication" data-toggle="tab">Communication</a>
              </li>
              <li style="width:20%;">
                 <a href="#healthhistory" data-toggle="tab">Health History</a>
              </li>
              <li style="width:20%;">
                 <a href="#nominee_details" data-toggle="tab">Nominee Details</a>
              </li>
              <li style="width:20%;">
                 <a href="#review" data-toggle="tab">Review</a>
              </li>
           </ul>
           <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;"></div>
           <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;"></div>
         </div>
         <div class="tab-content" id='setdata' data-url='{{route("health.policy.religare.setproposaldata") }}'>
            <div class="tab-pane active" id="insured">
                  <h6 class='info-text'>Enter the Insured Details!</h6>
                  @foreach($data['userdata']['members_list'] as $index=>$relationship)
                  <!-- Row -->
                  <div class="row">
                      @if($index == 0)
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>SELF</strong> <small>(Primary Insured) </small></h5>
                      @else
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>
                          @if($relationship == 'SONM')
                            SON
                          @elseif($relationship == 'UDTR')
                            DAUGHTER
                          @else
                            {{$relationship}}
                          @endif
                        </strong></h5>  
                      @endif
                    <!-- DOB -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Date of birth</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text"  
                                  id="dob_list{{$index}}" 
                                  name="dob_list[]"  
                                  value="{{$data['userdata']['dob_list'][$index]['selected_date']}}" 
                                  class="form-control required show-info"
                                                                    min-date = ""
                                  max-date = ""  
 
                                  data-name="Person {{$index + 1}}: DOB">  
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End DOB --> 
                   <!-- First Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>First Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text"  
                                  id="firstname{{$index}}" 
                                  name="firstname[]" 
                                  maxlength="30" 
                                  value="{{isset($data['userdata']['firstname'][$index]) ? $data['userdata']['firstname'][$index] : ''}}" 
                                  class="form-control required show-info"
                                  data-name="First Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End First Name --> 
                   <!-- Last Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Last Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <input type="text"  
                                id="lastname{{$index}}" 
                                name="lastname[]" 
                                maxlength="30"  
                                value="{{isset($data['userdata']['lastname'][$index]) ? $data['userdata']['lastname'][$index] : ''}}" 
                                class="form-control required show-info"
                                data-name="Last Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Last Name --> 

                   <!-- PAN Number -->
                   @if(isset($data['en_rel_pan_id']) && $data['en_rel_pan_id'] == true && $index == 0)
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>PAN Number</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <input type="text"  
                                id="pan" 
                                name="pan_number"  
                                maxlength="10" 
                                value="{{isset($data['userdata']['pan_number']) ? $data['userdata']['pan_number'] : ''}}" 
                                class="form-control required show-info"
                                data-name="PAN Number">
                             </div>
                          </div>
                       </div>
                    </div>
                   @endif
                   <!-- PAN Number -->

                   <!-- Aadhaar Num -->
                    @if ($index == 0)
                    <div class="col-sm-4">
                      <div class="card proposalcard">
                        <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                              <a>
                               <p>Aadhaar Number<span class="req">*</span></p>
                              </a>
                            </div>
                        </div>
                        <div class="col-sm-8" style="padding:0">
                          <div class="labelright">
                              <input type="text" 
                                id="aadhaar"
                                name="aadhaar_num" 
                                placeholder="Aadhaar Number" 
                                value="{{(isset($data['userdata']['aadhaar_num'])) ? $data['userdata']['aadhaar_num'] : ''}}" maxlength="14" 
                                class="form-control required show-info" 
                                data-name="Aadhaar Number">
                          </div>
                        </div>
                      </div>
                    </div>
                    @endif
                    <!-- Aadhaar Num -->
                   
                   <!-- Gender -->
                   @if(isset($data['en_gender']) && $index == 0)
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Gender</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                              <div class="radiobutton">
                                <input type="radio" 
                                  id="gender_male" value="M"
                                  name="gender" 
                                  class="required valid gender"  
                                  data-name= "Gender" 
                                  {{($data['userdata']['gender'][$index] === 'M') ? 'checked=checked' : ''}} />
                                <label for="gender_male" data-name="Gender">Male</label>
                              </div>
                              <div class="radiobutton">
                                <input type="radio"
                                  id="gender_female" 
                                  name="gender"  
                                  value="F" 
                                  class="required valid gender" 
                                  data-name= "Gender"
                                  {{($data['userdata']['gender'][$index] === 'F') ? 'checked=checked' : ''}} />
                                  <label for="gender_female" data-name="Gender">Female</label>
                              </div>
                            </div>
                          </div>
                       </div>
                    </div>
                   @endif
                   <!-- End Gender --> 
                 </div> 
               <!-- End Row --> 
               @endforeach
            </div>    
            <div class="tab-pane" id="communication">
                <h6 class='info-text'>ENTER THE COMMUNICATION DETAILS!</h6>
                <!-- Row -->
                <div class="row">
                   <!-- EMAIL -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>Email ID</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text" 
                                  id="user_email" 
                                  name="email"  
                                  value="{{$data['userdata']['email']}}" 
                                  class="form-control required show-info" 
                                  data-name="Email">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End EMAIL -->
                   <!-- MOBILE -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>Mobile</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text"  
                                  id="mobile" 
                                  name="mobile"
                                  maxlength="10" 
                                  minlength="10" 
                                  value="{{$data['userdata']['mobile']}}" 
                                  class="form-control required show-info"
                                  data-name="Mobile">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End MOBILE --> 
                   <!-- HOUSE NUMBER/NAME -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>House/Apartment Number</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text"  
                                  id="houseno" 
                                  name="house_num"  
                                  value="{{$data['userdata']['house_num']}}" 
                                  class="form-control required show-info"
                                  data-name="House/Apartment Number">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End HOUSE NUMBER/NAME -->
                   <!-- STREET -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>Street</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text" 
                                  id="street" 
                                  name="street"  
                                  value="{{$data['userdata']['street']}}"
                                  class="form-control required show-info" 
                                  data-name="Street">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End STREET -->
                   <!-- LOCALITY -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>Locality</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text" 
                                  id="locality" 
                                  name="locality"  
                                  value="{{$data['userdata']['locality']}}" 
                                  class="form-control required show-info"
                                  data-name="Locality">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End LOCALITY -->
                   <!-- STATE -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>State</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="hidden" 
                                  id="healthstateurl" 
                                  name="healthstateurl" 
                                  value="{{route('health.get_city')}} ">
                               <select data-md-selectize required 
                                  data-live-search="true" 
                                  id="state"
                                  name="state" 
                                  class="form-control required show-info" 
                                  data-name="state">
                                  <option hidden="" selected="" disabled="" value="">Select State*</option>
                                  @foreach($data['state_list'] as $state)
                                  <option 
                                  @if($data['userdata']['state'] == $state['state_code'])
                                  selected="selected"
                                  @endif
                                  value="{{$state['state_code']}}">{{strtoupper($state['religare_code'])}}</option>
                                  @endforeach
                                  <input type="hidden" name="state_name" value="{{$state['religare_code']}}">
                               </select>
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End STATE -->
                   <!-- CITY -->
                   <div class="col-sm-4">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>City</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <select data-md-selectize required 
                                  data-live-search="true" 
                                  id="city"
                                  name="city"  
                                  class="form-control required show-info" 
                                  data-name="City">
                               @if(isset($data['city_list']))
                               @foreach($data['city_list'] as $city)
                               <option 
                               @if($data['userdata']['city'] == $city['religare_code'])
                               selected="selected"
                               @endif()
                               value="{{($city['religare_code'])}}"> {{strtoupper($city['religare_code'])}}
                               </option>
                               @endforeach 
                               @endif
                               </select>
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End CITY -->  
                   <!-- PINCODE -->
                   <div class="col-sm-4 individual">
                      <div class="card proposalcard">
                         <div class="col-sm-4" style="padding:0">
                            <div class="labelleft">
                               <a>
                                  <p>Pincode</p>
                               </a>
                            </div>
                         </div>
                         <div class="col-sm-8" style="padding:0">
                            <div class="labelright">
                               <input type="text" 
                                  id="cust_pincode" 
                                  name="cust_pincode" 
                                  maxlength="6" 
                                  value="{{$data['userdata']['cust_pincode']}}" 
                                  class="form-control required show-info" 
                                  data-name="Pincode">
                            </div>
                         </div>
                      </div>
                   </div>
                   <!-- End PINCODE -->            
                </div>
                <!-- End Row --> 
            </div>
            <div class="tab-pane" id="healthhistory">
               <h6 class='info-text'>Enter the Health Details!</h6>
               <!-- Row -->      
               <div class="container tabdata">
                  <div class="col-sm-12" style="padding:0">
                     <div class="card proposalcard">
                        @foreach($data['pedlist'] as $index => $ped)
                        <div class="col-sm-12" style="padding:0">
                           <div class="labelleft">
                              <a>
                              <p>{{$index + 1 }}. {{$ped['name']}} 
                                 <input type="checkbox"
                                    id="{{ $ped['religare_code'].'-yes' }}"
                                    name="ped_list[{{ $ped['religare_code'] }}]" 
                                    value="1"
                                    data-name= "{{ ucwords($ped['short_code']) }}"
                                    data-type= "1"> 
                                    <label><strong>Yes</strong></label>
                              </p>
                              </a>
                           </div>
                        </div>
                        <!-- Container -->
                        <div id = "{{$ped['religare_code']}}_q_container" class="col-sm-12" style="display:none;">
                           @foreach($data['userdata']['members_list'] as $index=>$relationship)
                              <div class="col-sm-3" style="padding: 15px;">
                                <div class="col-sm-12">
                                 <input type="checkbox"
                                    id="{{$ped['religare_code']}}_{{$index}}_since_yes" 
                                    name="ped_since_choice[{{$ped['religare_code']}}][]"
                                    value="{{$index}}"> 
                                    <span id="{{$ped['religare_code']}}_{{$index}}_member">{{$relationship}}</span>
                                </div>
                                @if($ped['religare_code'] == 'PEDSmokeDetails')
                                <div class="col-sm-12">
                                <input type="textarea" 
                                    id="{{$ped['religare_code']}}_{{$index}}_details"
                                    name="ped_details[PEDSmokeDetails][{{$index}}]" 
                                    maxlength="25" 
                                    data-name= "Freq & Amt consumed"
                                    class ="form-control required show-info"
                                    placeholder="Freq & Amt consumed"
                                    style="display: none;">
                                </div>    
                                @endif
                                @if($ped['religare_code'] == 'PEDotherDetails')
                                <div class="col-sm-12">
                                <input type="textarea" 
                                    id="{{$ped['religare_code']}}_{{$index}}_details"
                                    name="ped_details[PEDotherDetails][{{$index}}]" 
                                    maxlength="25" 
                                    data-name= "Ailments Details"
                                    class ="form-control required show-info"
                                    placeholder="Disease Details"
                                    style="display: none;">
                                </div>    
                                @endif
                                <div class="col-sm-6" 
                                      style="display: none;" 
                                      id="{{$ped['religare_code']}}_{{$index}}_since_month_container">
                                 <select data-md-selectize  
                                    data-live-search="true" 
                                    id="{{$ped['religare_code']}}_{{$index}}_since_month"
                                    name="ped_since_month[{{$ped['religare_code']}}][{{$index}}]"
                                    class="form-control" 
                                    data-name="Since"
                                    placeholder="Existing Since">
                                    <option hidden="" selected="" disabled="" value="">Month</option>
                                    @for($i=1;$i<=12;$i++)
                                      <option value="{{$i}}">{{$i}}</option>
                                    @endfor
                                   </select>
                                </div>
                                <div class="col-sm-6" 
                                     style="display: none;" 
                                     id="{{$ped['religare_code']}}_{{$index}}_since_year_container">
                                 <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="{{$ped['religare_code']}}_{{$index}}_since_year"
                                    name="ped_since_year[{{$ped['religare_code']}}][{{$index}}]"  
                                    class="form-control" 
                                    data-name="Since"
                                    placeholder="Existing Since">
                                    <option hidden="" selected="" disabled="" value="">Year</option>
                                    @for($i=$data['userdata']['ped_year']['max'][$index];$i>=$data['userdata']['ped_year']['min'][$index];$i--)
                                      <option value="{{$i}}">{{$i}}</option>
                                    @endfor
                                   </select>     
                                </div> 
                              </div>
                           @endforeach 
                        </div>
                        <!-- Container ends -->
                        @endforeach
                     </div>

                  </div>
               </div>
               <!-- End Row -->
            </div>
            <div class="tab-pane" id="nominee_details">
                <h6 class='info-text'>ENTER NOMINEE DETAILS!</h6>
                <!-- Row -->
                <div class="row">
                  <!-- Nominee Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Nominee Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <input type="text" 
                                class="form-control required show-info" 
                                id="nomineename" 
                                name="nominee_name" 
                                value="{{$data['userdata']['nominee_name']}}" 
                                data-name="Nominee Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Nominee Name --> 
                   <!-- Nominee Age -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Nominee Age</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <select class="form-control required show-info" 
                                id="nomineeage" 
                                name="nominee_age"
                                aria-invalid="false" 
                                data-name="Nominee Age">
                                <option value="" >Select Age</option>
                                    @for($nominee=18;$nominee<=99;$nominee++)
                                        <?php $selected = (isset($data['userdata']['nominee_age']) && $nominee == $data['userdata']['nominee_age']) ? 'selected' : ''?>
                                        <option {{$selected}} value="{{$nominee}}" >{{$nominee}}</option>
                                    @endfor
                                </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Nominee Age -->
                   <!-- Nominee Relationship -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Nominee Relationship</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <select data-md-selectize required 
                                data-live-search="true" 
                                id="nomineerel"
                                name="nominee_relation"  
                                class="form-control required show-info" 
                                data-name="Nominee Ralationship">
                                <option hidden="" selected="" disabled="" value="">Select Nominee Relationship*</option>
                                @foreach($data['nominee_rel'] as $nominee)
                                <?php $selected = (isset($data['userdata']['nominee_relation']) && strtoupper($nominee['religare_code']) == $data['userdata']['nominee_relation']) ? 'selected' : ''?>
                                <option  {{$selected}}  value="{{($nominee['religare_code'])}}">{{strtoupper($nominee['nominee_rel'])}}</option>
                                @endforeach 
                               </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Nominee Relationship --> 
                   <!-- NCB-Super Add-on -->
                   @if(isset($data['en_add_on']) && $data['en_add_on'] == true)
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-6" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>NCB-Super Add-On</p>
                                   <small>{{isset($data['add_on_ncb_label']) ? $data['add_on_ncb_label'] : ''}}</small>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-6" style="padding:0">
                            <div class="labelright">
                              <div class="radiobutton">
                                <input type="radio" 
                                  id="ncb_yes" 
                                  value="Y"
                                  name="add_on[ncb]" 
                                  class="required valid gender"  
                                  data-name= "NCB-Super"
                                  {{($data['userdata']['add_on']['ncb'] == 'Y') ? 'checked=checked': ''}}/>
                                <label for="ncb_yes" data-name="NCB-Super"
                                 data-toggle="tooltip" 
                                 data-placement="top" 
                                 title="" 
                                 data-container="body" 
                                 data-original-title="By selecting this add–on cover you can further increase your sum insured amount by 50% for every claim free year up to a maximum of 100%. Hence – in total with both NCB & NCB Super one can increase their sum insured up to 150% in 5 years."
                                 >Yes</label>
                              </div>
                              <div class="radiobutton">
                                <input type="radio"
                                  id="ncb_no" 
                                  name="add_on[ncb]"  
                                  value="N" 
                                  class="required valid gender" 
                                  data-name= "NCB-Super"
                                  {{(isset($data['dis_add_on_ncb'])) ? 'disabled =""': ''}}
                                  {{($data['userdata']['add_on']['ncb'] == 'Y') ? '': 'checked=checked'}}/>
                                  <label for="ncb_no" data-name="NCB-Super">NO</label>
                              </div>
                            </div>
                          </div>
                       </div>
                    </div>
                   @endif 
                   <!-- End NCB-Super Add-on --> 
                   <!-- Unlimited recharge Add-on -->
                    @if(isset($data['en_add_on']) && $data['en_add_on'] == true)
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-6" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Unlimited recharge Add-On</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-6 style="padding:0">
                            <div class="labelright">
                              <div class="radiobutton">
                                <input type="radio" 
                                  id="ur_yes" 
                                  value="Y"
                                  name="add_on[ur]" 
                                  class="required valid" 
                                  data-name= "Unlimited Recharge" 
                                  {{($data['userdata']['add_on']['ur'] == 'Y') ? 'checked=checked': ''}} />
                                <label for="ur_yes" data-name="Unlimited Recharge"
                                 data-toggle="tooltip" 
                                 data-placement="top" 
                                 title="" 
                                 data-container="body" 
                                 data-original-title="By selecting this add–on cover your sum insured amount is re-instated in your policy every time your sum insured exhausts. And this can be availed unlimited number of times."
                                 >Yes</label>
                              </div>
                              <div class="radiobutton">
                                <input type="radio"
                                  id="ur_no" 
                                  name="add_on[ur]"  
                                  value="N" 
                                  class="required valid" 
                                  data-name= "Unlimited Recharge"
                                  {{($data['userdata']['add_on']['ur'] == 'Y') ? '': 'checked=checked'}} />
                                  <label for="ur_no" data-name="Unlimited Recharge">NO</label>
                              </div>
                            </div>
                          </div>
                       </div>
                    </div>
                    @endif
                   <!-- Unlimited recharge Add-on --> 
                </div> 
                <!-- End Row --> 
            </div>                  
            <div class="tab-pane" id="review">
              <h6 class='info-text'>Review the data you entered!</h6>
              @include('health.policy.preview')
            </div>           
         </div>
         <div class="wizard-footer">
            <div class="pull-right">
               <input data-focus='h_benefits' class="btn scrolltop btn-next btn-info" name="next"  id="nextform" value="Next" type="button">
               <input data-focus='h_benefits' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="health-btn-pay">
            </div>
            <div class="pull-left">
               <input data-focus='h_benefits' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
            </div>
            <div class="clearfix"></div>
         </div>   
      </div>                        
   </div>
</div>
</div>

<!-- premium breakup modal -->
<div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup"></div>
  
<!--Package Info Modal -->
<div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits"></div>

<input type="hidden" name="offline_policy" id="offline_policy" value="{{route('health.policy.religare.offlinepolicy') }}" />

@include('health.layouts.inn-ftr')

<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation_helper.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/religare.js ') }}"></script>
<script type="text/javascript">load_dob_list()</script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/religare_form_validation.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/sweetalert2.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/healthquote.js') }}"></script>
<script src="{{ URL::asset('js/health/quotation_page.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });
</script>
