@include('health.layouts.inn-hdr') @include('health.policy.basic_information')
<?php 
    $mem_count = count($data['userdata']['members_list']);
    $members  = $data['userdata']['members_list'];
    
?>
<div class="row">
   <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
      <div class="card wizard-card" data-color="green" id="wizardProfile">
         
        <form autocomplete="off"  method="post" action="{{ route('health.policy.rsgi.getpolicy') }}" id="buy_policy_form">
            <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
             <input type="hidden" name="session_id" id="session_id" value="{{$data['userdata']['session_id']}}"/>
             <input type="hidden" name="trans_code" id="trans_code" value="{{$data['userdata']['trans_code']}}"/>
            <input type='hidden' name='plan_type' value="{{$data['userdata']['plan_type']}}" />
            <input type='hidden' name='SI' value="{{$data['userdata']['sum_insured']}}" />
            <input type="hidden" id="insurerId" name="insurerId" value="{{ $data['userdata']['insurerId'] }}">
            <input type="hidden" id="dob_list" name="dob_list" value="{{ implode('|',$data['userdata']['dob_list'])}}">
            <input type="hidden" id="insurer_name" name="insurer_name" value="{{$data['userdata']['insurerName']}}" >
            <input type="hidden" id="product_id" name="product_id" value="{{ $data['userdata']['productId'] }}">
            <input type="hidden" id="rsgi_quote_id" name="rsgi_quote_id" value="{{$data['userdata']['rsgi_quote_id']}}">
            <input type="hidden" id="basePremium" name="basePremium" value="{{round($data['userdata']['basePremium'])}}">
            <input type="hidden" id="totalPremium" name="totalPremium" value="{{ round($data['userdata']['totalPremium']) }}">
            <input type="hidden" id="serviceTax" name="serviceTax" value="{{ round($data['userdata']['serviceTax']) }}" >
            <input type="hidden" id="cgst" name="cgst" value="{{ round($data['userdata']['cgst']) }}" >
            <input type="hidden" id="sgst" name="sgst" value="{{ round($data['userdata']['sgst']) }}" >
            <input type="hidden" name="p_start" value="{{ $data['policy_dates']['p_start'] }}" >
            <input type="hidden" name="p_ends" value="{{ $data['policy_dates']['p_ends'] }}" >
            <input type="hidden" name="covers" value="{{ $data['userdata']['cover_id'] }}" >
            <input type="hidden" name="tenure" value="{{ $data['userdata']['tenure'] }}" >
            <input type='hidden' name="membercount" id="membercount" value="{{ $mem_count }}" />
            <input type='hidden' name="rsgi_hosp_cash" id="rsgi_hosp_cash" value="{{ $data['userdata']['rsgi_hosp_cash'] }}" />
            <input type='hidden' name="rsgi_top_up" id="rsgi_top_up" value="{{ $data['userdata']['rsgi_top_up'] }}" />
             <input type="hidden" name="deductable" id="deductable" value="{{$data['userdata']['deductables']}}">
            
            <div class="wizard-navigation">
               <ul class="nav nav-pills">
                  <li style="width: 20%;" class="active">
                     <a href="#insured" data-toggle="tab" aria-expanded="">Insured</a>
                  </li>
                  <li style="width:20%;">
                     <a href="#communication" data-toggle="tab">Communication</a>
                  </li>
                  <li style="width:20%;">
                     <a href="#healthhistory" data-toggle="tab">Health History</a>
                  </li>
                   <li style="width:20%;">
                     <a href="#nominee_details" data-toggle="tab">More Info</a>
                  </li>
                  <li style="width:20%;">
                     <a href="#review" data-toggle="tab">Review</a>
                  </li>
               </ul>
               <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
               <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
            </div>
            <div class="tab-content" id='setdata' data-url='{{ route("health.policy.rsgi.setproposaldata") }}'>

              <!-- Insured Section Starts --> 
               <div class="tab-pane active" id="insured">
                  @if ($mem_count >= 1)
                  @for($i = 1; $i <= $mem_count; $i++)
                 <!-- Listing Relationship names by rel id  from  HealthRelationship Model -->
                  
                  <?php $relmembers = (new \App\Models\Health\HealthRelationship)->select('rel_name')->where('rel_id',$members[$i-1])->get(); 
                  
                  $dob_list = (new \App\Libraries\HealthLib)->get_membersdob($data['userdata']['age_list']);

                  $age_type = $data['userdata']['age_list'];
                  $titles =   $data['userdata']['title'];
                  $height_feet = explode('|',$data['userdata']['height_feet']);
                  $height_inch = explode('|',$data['userdata']['height_inches']);
                  $weight = explode('|',$data['userdata']['weight']);
                  $genderlist =  $data['userdata']['gender'];
                  $occupation =  explode('|',$data['userdata']['occupation']); 
                  $designation = explode('|',$data['userdata']['designation']);
                  $business = explode('|',$data['userdata']['business']);

                  foreach($genderlist as $mem_gender){
                     $gender[] = $mem_gender; 
                      }
                  foreach($titles as $memtitle){
                     $title[] = $memtitle;
                     }  
                  ?>
                  <input type="hidden" name="adults" value="{{$dob_list['adult']}}">
                  <input type="hidden" name="children" value="{{$dob_list['children']}}">
                  <input type="hidden" name="title[]" value="{{ $title[$i-1]}}">
                  <input type="hidden" name="relationshipId" value="{{implode('|',$data['userdata']['members_list'])}}">
                  <input type="hidden" name="agelist" value="{{implode('|', $data['userdata']['age_list'])}}">
                  <input type='hidden' name="gender[]" value="{{$gender[$i-1]}}" />
                  <input type='hidden' name='suminsured[]' value="{{$data['userdata']['sum_insured']}}" />
                  <div class="row">
                     @if ($i <= 1)
                     <h6 class='info-text'>Enter the Insured Details!</h6>
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>SELF</strong> <small>(Primary Insured) </small></h5>
                        @else 
                     <h6 class='info-text'></h6>
                     <h5 style="text-align: -webkit-left; margin-left: 40px;">
                       <strong>{{ $relmembers['0']['attributes']['rel_name'] }}</strong>
                     </h5>
                     @endif
                     <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                      <?php $newDate = date("d/m/Y", strtotime($data['userdata']['dob_list'][$i-1])); ?>
                                            <input class="datepicker form-control required show-info" type="text" id="dob{{$i}}" name="dob[]"  value="{{$newDate}}" data-name="Person {{$i}}: Date of birth" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Gender  -->
                         @if ($i < 2)
                           @if(in_array("WIFE", $members))
                           <input type="hidden" name="gender[{{$i}}]" value="0">
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" checked="checked"/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" disabled />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           @elseif(in_array("HUS", $members))
                           <input type="hidden" name="gender[{{$i}}]" value="1">
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" disabled/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" checked="true"  />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>

                                    </div>
                                 </div>
                              </div>
                           </div>
                           @else
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" checked="checked"/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                              @endif 
                           @endif  
                   <!-- Gender ends -->
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>First Name<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" name="firstname[]" id="firstname{{$i}}" class="form-control required show-info" value="{{(isset($data['userdata']['firstname'][$i-1])) ? $data['userdata']['firstname'][$i-1] : ''}}" data-name="First Name ">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Last Name<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" name="lastname[]" id="lastname{{$i}}" class="form-control required show-info" value="{{(isset($data['userdata']['lastname'][$i-1])) ? $data['userdata']['lastname'][$i-1] : ''}}" data-name="Last Name">
                              </div>
                           </div>
                        </div>
                     </div>

                      <!-- PAN for above 66 aged person ends -->
                   @if ($i <= 1)
                      @if(round($data['userdata']['totalPremium']) >= '50000')
                        <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>PAN Number<span class="req">*</span></p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                      <div class="labelright">
                                        <input type="text" class="form-control required show-info" name="pan" placeholder="Pan Number" id="pan" value="{{(isset($data['userdata']['pan_number'])) ? $data['userdata']['pan_number'] : ''}}"  data-name="PAN Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                      @endif
                  @endif
               
               <!-- Aadhaar Num -->
              @if ($i <= 1)
               <div class="col-sm-4">
                  <div class="card proposalcard">
                      <div class="col-sm-4" style="padding:0">
                          <div class="labelleft">
                              <a>
                                  <p>Aadhaar Number<span class="req">*</span></p>
                              </a>
                          </div>
                      </div>
                      <div class="col-sm-8" style="padding:0">
                        <div class="labelright">
                          <input type="text" class="form-control required show-info" name="aadhaar" placeholder="Aadhaar Number" id="aadhaar" value="{{(isset($data['userdata']['aadhaar_num'])) ? $data['userdata']['aadhaar_num'] : ''}}" maxlength="14" data-name="Aadhaar Number">
                          </div>
                      </div>
                  </div>
              </div>
              @endif
              
                      <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Height<span class="req">*</span></p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                       
                                          <div class="col-xs-6" style="padding-left: 4px;">
                                              <select name="feet[]" id="feet{{$i}}" class="form-control required show-info" data-name="Person {{$i}}: Feet">
                                                <option value="" >Select Feet</option>
                                                 @for($f=1; $f<=8; $f++)
                                                <?php $selected = (isset($height_feet[$i-1]) && $f == $height_feet[$i-1]) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$f}}" >{{$f}}</option>
                                               @endfor
                                              </select>
                                          </div>

                                          <div class="col-xs-6">
                                              <select name="inches[]" id="inches{{$i}}" class="form-control required show-info" data-name="Person {{$i}}: Inches">
                                                <option value="" >Select Inches</option>
                                                @for($h='0'; $h<='11'; $h++)
                                                <?php $selected = (isset($height_inch[$i-1]) && $h == $height_inch[$i-1]) ? 'selected' : ''?>
                                                <option {{$selected}} value="{{$h}}" >{{$h}}</option>
                                               @endfor
                                              </select>
                                          </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Weight (In Kg)<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="textarea" name="weight[]" id="weight{{$i}}" class="form-control required show-info" value="{{(isset($weight[$i-1])) ? $weight[$i-1] : ''}}" maxlength="3" data-name="Person {{$i}}: Weight ">
                              </div>
                           </div>
                        </div>
                     </div>

                      <!-- Proposer Nationality -->
                      <div class=" col-sm-4 individual" style="display:none;">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nationality<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="hidden"  name="nationality" value="Indian">
                              </div>
                           </div>
                        </div>
                     </div>
                     
                     @if ($i <= 1)
                     <!-- Marital Status-->
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Marital Status<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                              <select name="marital_status" id="marital_status" class="form-control required show-info" data-name="Person {{$i}}: Marital Status">
                                 @if('SELF' == in_array('SELF', $members) && ('WIFE' == in_array('WIFE', $members)   || 'SONM' == in_array('SONM', $members) || 'UDTR' == in_array('UDTR', $members)))
                                    <option value="Married" > Married </option>
                                  @else
                                    <option selected  hidden="" disabled="" value="" >Select Marital Status</option> 
                                    <option value="Single" <?php if($data['userdata']['marital_status'] == "Single") echo 'selected="selected"'; ?>> Single </option>
                                    <option value="Married" <?php if($data['userdata']['marital_status'] == "Married") echo 'selected="selected"'; ?>> Married </option>
                                    @endif
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- Educational Qulification -->
                      <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Educational Qualification<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <select name="education" id="education" class="form-control required show-info" data-name="Person {{$i}}: Education">
                                 <option selected  hidden="" disabled="" value="" >Select Education</option> 

  <option value="Less than Matriculation" <?php if($data['userdata']['education'] == "Less than Matriculation") echo 'selected="selected"'; ?>> Less than Matriculation </option>
  <option  value="Matriculation" <?php if($data['userdata']['education'] == "Matriculation") echo 'selected="selected"'; ?> > Matriculation </option>
  <option  value="Graduate" <?php if($data['userdata']['education'] == "Graduate") echo 'selected="selected"'; ?>> Graduate </option>
  <option  value="Post-Graduate" <?php if($data['userdata']['education'] == "Post-Graduate") echo 'selected="selected"'; ?>> Post-Graduate </option>
  <option  value="Professional Course" <?php if($data['userdata']['education'] == "Professional Course") echo 'selected="selected"'; ?>> Professional Course </option>

                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     @endif

                    

              <!-- Occupation list starts -->
               <?php foreach($age_type as $childage){ $agelimit = $childage;}?>

               @if(($relmembers['0']['attributes']['rel_name'] == 'SON' || $relmembers['0']['attributes']['rel_name'] == 'DAUGHTER') && ($agelimit >= 5 && $agelimit <= 18))
                      <div class=" col-sm-4 individual" >
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Occupation<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <select name="occupation{{$i}}" id="occupation{{$i}}" class="form-control required show-info" data-name="Person {{$i}}: Occupation">
                                     <option value="STUDENT"> STUDENT </option>
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>

                     @elseif(($relmembers['0']['attributes']['rel_name'] == 'SON' || $relmembers['0']['attributes']['rel_name'] == 'DAUGHTER') && $agelimit <= 4)
                      <div class=" col-sm-4 individual" style="display: none;">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Occupation<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <select name="occupation{{$i}}" id="occupation{{$i}}" class="form-control required show-info" data-name="Person {{$i}}: Occupation">
                                     <option value="OTHERS"> OTHER NORMAL </option>
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                  @else
                   <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Occupation<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <select name="occupation{{$i}}" id="occupation{{$i}}"  class="form-control required show-info occupation" data-name="Person {{$i}}: Occupation">
                                    <option selected  hidden="" disabled="" value="" >Select Occupation</option> 
                                       @foreach($data['members_occupation'] as $key => $value)
                                          <?php $selected = (isset($occupation[$i-1]) && $value['rsgi_code'] == $occupation[$i-1]) ? 'selected' : ''?>
                                    <option {{$selected}} value="{{$value['rsgi_code']}}"> {{$value['occupation_name']}} </option>
                                    @endforeach
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     @endif

                     <!-- Option to enter occupation details -->

                      <div class="col-sm-4" id="occ_details{{$i}}">

                    @if(isset($occupation[$i-1]) && ($occupation[$i-1] == 'SALARIED' || $occupation[$i-1] == 'OTHERS')) 
                      @if(isset($designation[$i-1]) && $designation[$i-1] != null )
                      <div class="card proposalcard">
                        <div class="col-sm-4" style="padding:0">
                          <div class="labelleft">
                            <a><p>DESIGNATION<span class="req">*</span></p></a>
                          </div>
                        </div>
                        <div class="col-sm-8" style="padding:0">
                          <div class="labelright">
                            <input type="textarea" class="form-control show-info" name="designation{{$i}}" id="designation{{$i}}"  maxlength="50" value="{{isset($designation[$i-1]) ? $designation[$i-1] : ''}}" data-name="Designation">
                          </div>
                        </div>
                      </div>
                      @endif 
                    @endif

                     @if(isset($occupation[$i-1]) && $occupation[$i-1] == 'SELF EMPLOYED') 
                      @if(isset($business[$i-1]) && $business[$i-1] != null )
                      <div class="card proposalcard">
                        <div class="col-sm-4" style="padding:0">
                          <div class="labelleft">
                            <a><p>BUSINESS<span class="req">*</span></p></a>
                          </div>
                        </div>
                        <div class="col-sm-8" style="padding:0">
                          <div class="labelright">
                            <input type="textarea" class="form-control show-info" name="business{{$i}}" id="business{{$i}}"  maxlength="50" value="{{isset($business[$i-1]) ? $business[$i-1] : ''}}" data-name="Designation">
                          </div>
                        </div>
                      </div>
                      @endif 
                    @endif

                     </div>

                  <!-- Occupation ends -->
                 

                        </div>
                     @endfor
                  @endif
               </div>
       
      
                <!-- Communication Section Starts -->          
               <div class="tab-pane" id="communication">
                  <div class="row">
                     <h6 class='info-text'>Enter the Communication Details!</h6>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Email ID<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required email show-info" name="email" id="user_email" value="@if($data['userdata']['email']){{$data['userdata']['email']}}@endif" data-name="Email">
                              </div>
                           </div>
                        </div>
                     </div>
                     
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Mobile<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                              <input type="text" placeholder="10 Digit Mobile Number" class="form-control required digits show-info" name="mobile" id="mobile" maxlength="10" minlength="10" value="@if($data['userdata']['mobile']){{$data['userdata']['mobile']}}@endif" data-name="Mobile Number">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>House/Apartment Number<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="houseno" id="houseno" value="@if($data['userdata']['house_num']){{$data['userdata']['house_num']}}@endif" data-name="House/Apartment Number">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Street<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="street" id="street" value="@if($data['userdata']['street']){{$data['userdata']['street']}}@endif" data-name="Street">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Locality<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="locality" id="locality" value="@if($data['userdata']['locality']){{$data['userdata']['locality']}}@endif" data-name="Locality">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>State<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <input type="hidden" name="healthstateurl" id="healthstateurl" value="{{route('health.get-city')}} ">
                              <div class="labelright">
                                 <select data-md-selectize required data-live-search="true" name="state" id="state" class="form-control required show-info" data-name="state">
                                   

                                  <option hidden="" selected="" disabled="" value="">Select State*</option>
                                    @foreach($data['state_list'] as $state)
                                    <option <?php if($data['userdata']['state'] == $state['state_code']) echo 'selected="selected"'; ?>  value="{{$state['state_code']}}">{{strtoupper($state['rsgi_code'])}}</option>
                                    @endforeach
                                    <input type="hidden" name="state_name" value="{{$state['rsgi_code']}}">

                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>City<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <select data-md-selectize required data-live-search="true" name="city" id="city" class="form-control required show-info" data-name="City">
                                   @if(isset($data['city_list']))
                                   @foreach($data['city_list'] as $city)
                                 <option <?php if($data['userdata']['city'] == $city['rsgi_code']) echo 'selected="selected"'; ?>  value="{{($city['rsgi_code'])}}"> {{strtoupper($city['rsgi_code'])}}
                                 </option>
                              @endforeach 
                              @endif
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Pincode<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required digits show-info" name="cust_pincode" id="cust_pincode"  maxlength="6" value="@if($data['userdata']['cust_pincode']){{$data['userdata']['cust_pincode']}}@endif" data-name="Pincode">
                              </div>
                           </div>
                        </div>
                     </div>
                     
                  </div>
               </div>
       <!-- Health history starts -->        
                  @include('health.policyped.rsgi_health_ped')

        <div class="tab-pane" id="nominee_details">
                  <div class="row">
                     <h6 class='info-text'>Enter Nominee Details!</h6>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee Name<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="nomineename" id="nomineename" value="@if($data['userdata']['nominee_name']){{$data['userdata']['nominee_name']}}@endif" data-name="Nominee Name">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee DOB<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                              <input class="form-control required show-info" type="text" id="nominee_dob" name="nominee_dob"  value="@if($data['userdata']['nominee_dob']){{$data['userdata']['nominee_dob']}}@endif" data-name="Nominee DOB" readonly>
                              <span class="material-input"></span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee Relationship<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                           <input type="hidden" name="nomineenameurl" id="nomineenameurl" value="{{route('health.get-nominee_rel')}} ">
                              <div class="labelright">

                              <select data-md-selectize required data-live-search="true" name="nomineerel" id="nomineerel" class="form-control required show-info" data-name="Nominee Ralationship">
                                    <option hidden="" selected="" disabled="" value="">Select Nominee Relationship*</option>
                                    @foreach($data['nominee_rel'] as $nominee)
                                      <option <?php if($data['userdata']['nominee_relation'] == strtoupper($nominee['rsgi_code'])) echo 'selected="selected"'; ?>  value="{{strtoupper($nominee['rsgi_code'])}}">{{strtoupper($nominee['rsgi_code'])}}</option>
                                    @endforeach 
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>


              <!-- Super Top up flow -->
                  @if($data['userdata']['product_type'] == "B" && $data['userdata']['product_planname'] !== "Elite")
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Deductible</p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                              <select data-md-selectize data-live-search="true" name="deductable" id="deductable" class="form-control  show-info" data-name="Deductible Amount">
                                    <option value="not-opted">Not Opted</option>
                                    @foreach($data['deductables'] as $dedamount)
                                      <option <?php if($data['userdata']['deductables'] == $dedamount['deductable']) echo 'selected="selected"'; ?> value="{{$dedamount['deductable']}}">&#8377;  {{$dedamount['deductable']}}</option>
                                    @endforeach 
                                 </select>
                              </div>
                           </div>
                        </div>
                     </div>
                  @endif
              <!-- End Super Top up flow -->

              <!-- International Treatment for Elite plan-->
               @if($data['userdata']['product_planname'] == "Elite")
                 <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Include treatment in USA & Canada</p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      <div class="radiobutton">
                                          <input type="radio" name="rsgi_international_treatment" id="radio_{{$i}}" value="On" data-name= "Include treatment in USA & Canada" />
                                          <label for="radio_{{$i}}" >Yes</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="rsgi_international_treatment" id="sdo_{{$i}}" value="Off"  data-name= "Include treatment in USA & Canada" checked="checked"/>
                                          <label for="sdo_{{$i}}">No</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                  @endif
              <!-- End International Treatment for Elite plan-->

             <!-- Hospital Cash Add-On for top up -->
              @if($data['userdata']['product_type'] == "S")
                 <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Hospital Cash Add-On</p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      <div class="radiobutton">
                                          <input type="radio" name="rsgi_hosp_cash" id="radio_{{$i}}" value="on" data-name= "Hospital Cash" {{($data['userdata']['rsgi_hosp_cash'] === "on") ? 'checked=checked' : ''}}/>
                                          <label for="radio_{{$i}}" >Yes</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="rsgi_hosp_cash" id="sdo_{{$i}}" value="off"  data-name= "Hospital Cash" {{($data['userdata']['rsgi_hosp_cash'] !== "on") ? 'checked=checked' : ''}}/>
                                          <label for="sdo_{{$i}}">No</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
              @endif
              <!-- End Hospital Cash Add-On for top up -->
            </div>
         </div>

      <!-- Review Section Starts -->
               <div class="tab-pane" id="review">
                  <h6 class='info-text'>Review the data you entered!</h6>
                  @include('health.policy.preview')
               </div>
            </div>
            <input type="hidden" name="return_page" id="return_page" value="{{ route('health.policy.rsgi.returnPage') }}">   

            <input type="hidden" name="offline_policy" id="offline_policy" value="{{ route('health.policy.rsgi.offlinepolicy') }}">  


         </form>

         <div class="wizard-footer">
            <div class="pull-right">
               <input data-focus='h_benefits' class="btn scrolltop btn-next btn-info" name="next"  id="nextform" value="Next" type="button">
               <input data-focus='h_benefits' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="health-btn-pay">
            </div>
            <div class="pull-left">
               <input data-focus='h_benefits' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
            </div>
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
</div>

<div class="modal fade" id="selectedFeatures" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
            <div class="card card-pricing card-margin">
               <div class="row customcard">
                  <div class="col-sm-4 logobox">
                     <img src="{{URL::to('/')}}/image/logos/{{ $data['userdata']['insurerId'] }}.png">
                  </div>
                  <div class="col-sm-4">
                     <h5 class="card-title price" style="margin-top: 15px;">INR {{ round($data['userdata']['totalPremium']) }}</h5>
                     <span class="label label-default extrapanelitem">SI: {{ $data['userdata']['sum_insured'] }}</span>
                  </div>
               </div>
               <div class="content">
                  <h3>The <b>features</b> you have selected are</h3>
                  <ul>
                     <li><b>Standard Policy</b></li>
                     <li><b>RSA</li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-info btn-success btn-xs">Save</button>
         </div>
      </div>
   </div>
</div> 

<!-- premium breakup modal -->
  <div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup"> </div>

<!--Package Info Modal -->
  <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits">
  </div>
<div id="pay_form"></div>
<input type="hidden" name="datastatus" id="datastatus" value="{{route('health.getconfirm')}}"> 
@include('health.layouts.inn-ftr')

<script>
$('#occupation1').on('change', function(){ 
   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details1').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation1" id="designation1"  maxlength="50" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details1').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business1" id="business1"  maxlength="50" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details1').html('<input type="hidden" name="business" value=""/>')
    }
       
    });


$('#occupation2').on('change', function(){ 

   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details2').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation2" id="designation2"  maxlength="50" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details2').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business2" id="business2"  maxlength="50" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details2').html('<input type="hidden" name="business" value=""/>')
    }
       
    }); 

$('#occupation3').on('change', function(){ 

   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details3').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation3" id="designation3"  maxlength="50" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details3').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business3" id="business3"  maxlength="50" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details3').html('<input type="hidden" name="business" value=""/>')
    }
       
    }); 

$('#occupation4').on('change', function(){ 

   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details4').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation4" id="designation4"  maxlength="50" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details4').html('<div class="card proposalcard"><div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business4" id="business4"  maxlength="50" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details4').html('<input type="hidden" name="business" value=""/>')
    }
       
    }); 

$('#occupation5').on('change', function(){ 

   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details5').html('<div class="card proposalcard"><div class="col-sm-5" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation5" id="designation5"  maxlength="50" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details5').html('<div class="card proposalcard"><div class="col-sm-5" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business5" id="business5"  maxlength="50" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details5').html('<input type="hidden" name="business" value=""/>')
    }
       
    }); 

$('#occupation6').on('change', function(){ 

   var name = $(this).val();
    if(name == 'SALARIED' || name == 'OTHERS'){
      $('#occ_details6').html('<div class="card proposalcard"><div class="col-sm-6" style="padding:0"><div class="labelleft"><a><p>DESIGNATION<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="designation6" id="designation6"  maxlength="60" value="" data-name="Designation"></div></div></div>');
    }
    else if(name == 'SELF EMPLOYED'){
      $('#occ_details6').html('<div class="card proposalcard"><div class="col-sm-6" style="padding:0"><div class="labelleft"><a><p>BUSINESS<span class="req">*</span></p></a></div></div><div class="col-sm-8" style="padding:0"><div class="labelright"><input type="textarea" class="form-control show-info" name="business6" id="business6"  maxlength="60" value="" data-name="Business"></div></div></div>');

    } else{
      $('#occ_details6').html('<input type="hidden" name="business" value=""/>')
    }
       
    }); 



   var yearRange = "-97:+1";
      $('.datepicker').datepicker({
      dateFormat: 'dd/mm/yy',
      changeMonth: true,
      changeYear: false,
      yearRange: yearRange,
      maxDate: new Date(),
      defaultDate: '01/01/1980'})

// Nominee DOB

$(function () {
    var start = new Date();
    start.setFullYear(start.getFullYear() - 96);
    var end = new Date();
    end.setFullYear(end.getFullYear() - 18);

    $('#nominee_dob').datepicker({
        dateFormat: 'dd/mm/yy',
        changeMonth: true,
        changeYear: true,
        minDate: start,
        maxDate: end,
        yearRange: start.getFullYear() + ':' + end.getFullYear()
    });
});

</script>
<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation_helper.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/royalsundaram.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/policy/rsgi_form_validation.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/sweetalert2.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/health/healthquote.js') }}"></script>
<script src="{{ URL::asset('js/health/quotation_page.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });

</script>
