@include('health.layouts.inn-hdr') @include('health.policy.basic_info')
<!-- start form wizard  -->
<div class="row">
  <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
    <div class="card wizard-card" data-color="green" id="wizardProfile">
      <form autocomplete="off"  method="post" action="{{ route('health.star_submit_proposal') }}" id="buy_policy_form">
        <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
        <input type="hidden" id="hl_trans_code" name="hl_trans_code" value="{{$quote->get_trans_code()}}">
        <input type="hidden" id="insurer_name" name="insurer_name" value="{{ $quote->get_insurer_name() }}">
        <input type="hidden" id="product_id" name="product_id" value="{{ $quote->get_product_id() }}">
        <input type="hidden" id="membercount" name="membercount" value="{{$quote->get_member_count()}}">
        <input type="hidden" id="gender_list" name="gender_list" value="{{implode('|',$quote->get_gender())}}">
        <input type="hidden" name="age_list" value="{{implode('|',$quote->get_age_list())}}">
        <input type="hidden" name="relation_list" value="{{$base_data->get_relation_list()}}">
        <input type="hidden" id="members_list" name="members_list" value="{{implode('|',$quote->get_members_list())}}">
        <input type="hidden" name="agree_med_chkup" value="{{ $data['agree_med_chkup'] }}">
         <input type="hidden" id="sum_insured" name="sum_insured" value="{{$quote->get_sum_insured()}}">
        <input type="hidden" id="sumInsuredId" name="sumInsuredId" value="{{$quote->get_sumInsuredId()}}">
        <input type="hidden" id="schemeId" name="schemeId" value="{{$quote->get_schemeId()}}">
        <input type="hidden" id="planId" name="planId" value="{{$quote->get_planId()}}">
        <input type="hidden" id="policy_start" name="policy_start" value="{{$quote->get_policy_start()}}">
        <input type="hidden" id="policy_end" name="policy_end" value="{{$quote->get_policy_end()}}">
        <input type="hidden" id="totalPremium" name="totalPremium" value="{{$quote->get_totalPremium()}}">
        <input type="hidden" name="datastatus" id="datastatus" value="{{route('health.getconfirm')}}">
         <input type="hidden" id="tenure" name="tenure" value="{{$quote->get_tenure()}}">
            <div class="wizard-navigation">
              <ul class="nav nav-pills">
                <li style="width: 20%;" class="active">
                  <a href="#insured" data-toggle="tab" aria-expanded="">Insured</a>
                </li>
                <li style="width:20%;">
                  <a href="#communication" data-toggle="tab">Communication</a>
                </li>
                <li style="width:20%;">
                  <a href="#healthhistory" data-toggle="tab">Health History</a>
                </li>
                <li style="width:20%;">
                  <a href="#nominee_details" data-toggle="tab">Nominee Details</a>
                </li>
                <li style="width:20%;">
                  <a href="#review" data-toggle="tab">Review</a>
                </li>
              </ul>
               <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
               <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
            </div>
            <div class="tab-content" id='setdata' data-url='{{ route("health.policy.star.setproposaldata") }}'>

      <!-- Insured Section Starts --> 
              <div class="tab-pane active" id="insured">
               @if ($quote->get_member_count() >= 1)
                @for($i = 1; $i <= $quote->get_member_count(); $i++)
                  <div class="row">
                      @if ($i <= 1)
                     <h6 class='info-text'>Enter the Insured Details!</h6>
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>{{$quote->get_members_list()[$i-1]}}</strong> <small>(Primary Insured) </small></h5>
                        @else 
                     <h6 class='info-text'></h6>
                     <h5 style="text-align: -webkit-left; margin-left: 40px;">
                       <strong> {{$quote->get_members_list()[$i-1]}}</strong>
                     </h5>
                     @endif
                     <h6 class='info-text'></h6>
                     <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                          <input type="text" id="dob_list{{$i-1}}" name="dob_list[]" value="{{isset($data['dob_list'][$i-1]) ? $data['dob_list'][$i-1]: $doblist[$i-1]['selected_date']}}" class="form-control required show-info" min-date = "" max-date = "" data-name="Person {{$i}}: DOB">
                                      <!-- <input type="text" id="dob_list{{$i-1}}" name="dob_list[]" value="{{isset($data['dob_list'][$i-1]) ? $data['dob_list'][$i-1]: $doblist[$i-1]['selected_date']}}" class="form-control required show-info" min-date = "{{$doblist[$i-1]['min_date']}}" max-date = "{{$doblist[$i-1]['max_date']}}" data-name="Person {{$i}}: DOB"> --> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                         @if ($i < 2)
                           @if(in_array("WIFE", $quote->get_members_list()))
                           <input type="hidden" name="gender[{{$i}}]" value="0">
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" checked="checked"/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" disabled />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           @elseif(in_array("HUSBAND", $quote->get_members_list()))
                           <input type="hidden" name="gender[{{$i}}]" value="1">
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" disabled/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" checked="true"  />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>

                                    </div>
                                 </div>
                              </div>
                           </div>
                           @else
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Gender </p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" class="required valid gender" id="radio_{{$i}}" value="M" data-name= "Gender"  data-operator ="{{$i}}" checked="checked"/>
                                          <label for="radio_{{$i}}" >Male</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="gender[{{$i}}]" id="sdo_{{$i}}" value="F" class="required valid gender" data-name= "Gender" data-operator ="{{$i}}" />
                                          <label for="sdo_{{$i}}">Female</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                              @endif 
                           @endif  
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>First Name<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" name="firstname[]" id="firstname{{$i}}" class="form-control required show-info" value="{{(isset($data['firstname'][$i-1])) ? $data['firstname'][$i-1] : ''}}" data-name="First Name ">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Last Name<span class="req">*</span></p>
                                 </a>
                              </div>
                            </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" name="lastname[]" id="lastname{{$i}}" class="form-control required show-info" value="{{(isset($data['lastname'][$i-1])) ? $data['lastname'][$i-1] : ''}}" data-name="Last Name">
                              </div>
                           </div>
                        </div>
                     </div> 
                      <!-- PAN Number -->
                  @if ($i <= 1)
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>PAN Number<span class="req">*</span></p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                              <input type="text"  
                                id="pan" 
                                name="pan_number"  
                                maxlength="10" 
                                value="{{isset($data['usr_data']['pan_number']) ? $data['usr_data']['pan_number'] : ''}}" 
                                class="form-control required show-info"
                                data-name="PAN Number">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- PAN Number -->
                     <!-- Aadhaar Num -->
                           <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a><p>Aadhaar Number<span class="req">*</span></p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                       <input type="text" class="form-control required show-info" name="aadhaar_num" placeholder="Aadhaar Number" id="aadhaar" value="{{(isset($data['usr_data']['aadhaar_num'])) ? $data['usr_data']['aadhaar_num'] : ''}}" maxlength="14"  data-name="Aadhaar Number">
                                    </div>
                                 </div>
                              </div>
                           </div>
                           @endif 
                           <!-- Aadhaar Num ends-->
                    <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Height<span class="req">*</span></p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                       
                                          <div class="col-xs-6" style="padding-left: 4px;">
                                              <select name="height_feet[]" id="feet{{$i}}" class="form-control required show-info" data-name="Person : Feet">
                                                <option value="" >Select Feet</option>
                                                 @for($f=1; $f<=8; $f++)
                                                <option  {{(isset($data['height_feet'][$i-1]) && $f == $data['height_feet'][$i-1]) ? 'selected' : ''}} value="{{$f}}" >{{$f}}</option>
                                               @endfor
                                              </select>
                                          </div>
                                          <div class="col-xs-6">
                                              <select name="height_inches[]" id="inches{{$i}}" class="form-control required show-info" data-name="Person : Inches">
                                                <option value="" >Select Inches</option>
                                                @for($h='0'; $h<='11'; $h++)
                                                <option {{(isset($data['height_inches'][$i-1]) && $h == $data['height_inches'][$i-1]) ? 'selected' : ''}} value="{{$h}}" >{{$h}}</option>
                                               @endfor
                                              </select>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                     <div class=" col-sm-4 individual">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Weight (In Kg)<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                          <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="textarea" name="weight[]" id="weight{{$i}}" class="form-control required show-info" value="{{(isset($data['weight'][$i-1]) ? $data['weight'][$i-1] : '')}}" data-name="Weight ">
                              </div>
                           </div>
                        </div>
                     </div> 
                     <!-- Occupation list starts -->
                      <?php foreach($quote->get_age_list() as $childage) {$agelimit = $childage;}?>
                      @if($quote->get_product_id() != "DIABETESIND" && $quote->get_product_id() != "DIABETESFMLY")
                        @if(($quote->get_members_list()[$i-1] == 'SON' || $quote->get_members_list()[$i-1] == 'DAUGHTER') && $agelimit <= 18)
                          <div class=" col-sm-4 individual" >
                            <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                <div class="labelleft">
                                  <a><p>Occupation<span class="req">*</span></p></a>
                                </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                <div class="labelright">
                                  <select name="occupation[]" id="occupation{{$i}}" class="form-control required show-info occupation" data-name="Person : Occupation">
                                    <option value="12"> STUDENT </option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                        @else
                          <div class=" col-sm-4 individual">
                            <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                <div class="labelleft">
                                  <a><p>Occupation<span class="req">*</span></p></a>
                                </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                <div class="labelright">
                                  <select name="occupation[]" id="occupation{{$i}}"  class="form-control required show-info occupation" data-name="Person : Occupation">
                                    <option selected  hidden="" disabled="" value="" >Select Occupation</option> 
                                    @foreach ($base_data->get_occupation_list() as $occupation_obj)
                                      <?php $occupation_code = isset($occupation_obj->star_code) ? $occupation_obj->star_code : $occupation_obj->star_code_red; 
                                      $selected = (isset($data['occupation'][$i-1]) && $occupation_code == $data['occupation'][$i-1]) ? 'selected' : ''?>
                                        <option {{$selected}} value="{{$occupation_code}}" data-name=" {{$occupation_obj->occupation_name}} "> {{$occupation_obj->occupation_name}} </option>
                                    @endforeach
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                        @endif
                      @endif
                     <!-- Option to enter occupation details -->
                      </div>
                   @endfor
                  @endif
               </div> 
                <!-- Communication Section Starts -->          
              <div class="tab-pane" id="communication">
                  <div class="row">
                     <h6 class='info-text'>Enter the Communication Details!</h6>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Email ID<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required email show-info" name="email" id="user_email" value="{{(isset($data['usr_data']['email']) ? $data['usr_data']['email'] : '')}}" data-name="Email">
                              </div>
                           </div>
                        </div>
                     </div>
                     
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Mobile<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                              <input type="text" placeholder="10 Digit Mobile Number" class="form-control required digits show-info" name="mobile" id="mobile"  maxlength="10" minlength="10" value="{{(isset($data['usr_data']['mobile']) ? $data['usr_data']['mobile'] : '')}}" data-name="Mobile Number">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>House/Apartment Number<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="houseno" id="houseno" value="{{(isset($data['usr_data']['houseno']) ? $data['usr_data']['houseno'] : '')}}" data-name="House/Apartment Number">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Street<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="street" id="street" value="{{(isset($data['usr_data']['street']) ? $data['usr_data']['street'] : '')}}" data-name="Street">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Locality<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="locality" id="locality" value="{{(isset($data['usr_data']['locality']) ? $data['usr_data']['locality'] : '')}}" data-name="Locality">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Pincode</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text" class="form-control required digits show-info" maxlength="6" name="cust_pincode" id="cust_pincode" value="{{(isset($data['usr_data']['cust_pincode']) ? $data['usr_data']['cust_pincode'] : '')}}" data-name="Pincode">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>State</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <input type="hidden" name="stateurl" id="stateurl" value="{{route('getcity')}} ">
                                 <div class="labelright">
                                    <input class="form-control show-info" type="text" name="state" id="state" value="{{(isset($data['usr_data']['state']) ? $data['usr_data']['state'] : '')}}" readonly="true" data-name="State">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>City</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                <div class="labelright">
                                <select data-md-selectize required data-live-search="true" name="city" id="city" class="form-control required show-info" data-name="City">
                                @if(!empty($data['city']))   
                                  @foreach($data['city'] as $city)
                                    <option <?php if($data['usr_data']['city'] == $city->city_id) echo 'selected="selected"'; ?>  value="{{$city->city_id}}"> {{strtoupper($city->city_name)}} </option>
                                  @endforeach
                                @endif
                                </select>
                                </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Area</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                 <select data-md-selectize required data-live-search="true" name="cust_area" id="cust_area" class="form-control required show-info" data-name="Area" >
                                @if(!empty($data['area']))   
                                  @foreach($data['area'] as $area)
                                    <option <?php if($data['usr_data']['cust_area'] == $area->areaID) echo 'selected="selected"'; ?>  value="{{$area->areaID}}"> {{strtoupper($area->areaName)}} </option>
                                  @endforeach
                                @endif
                                    </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                  </div>
               </div>
                <!-- Health history starts -->  
                  @include('health.policyped.star_ped')
                <!-- Health history ends -->
                <div class="tab-pane" id="nominee_details">
                  <div class="row">
                     <h6 class='info-text'>Enter Nominee Details!</h6>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee Name<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">
                                 <input type="text" class="form-control required show-info" name="nominee_name" id="nomineename" value="{{(isset($data['usr_data']['nominee_name']) ? $data['usr_data']['nominee_name'] : '')}}" data-name="Nominee Name">
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee Age<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                              <div class="labelright">

                              <select class="form-control required show-info" name="nominee_age" id="nomineeage" aria-invalid="false" data-name="Nominee Age">
                                 <option value="" >Select Age</option>
                                   @for($n=18;$n<=99;$n++)
                                    <?php $selected = (isset($data['usr_data']['nominee_age']) && $n == $data['usr_data']['nominee_age']) ? 'selected' : ''?>
                                      <option {{$selected}} value="{{$n}}" >{{$n}}</option>
                                 @endfor
                              </select>
                              <span class="material-input"></span>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4">
                        <div class="card proposalcard">
                           <div class="col-sm-4" style="padding:0">
                              <div class="labelleft">
                                 <a>
                                    <p>Nominee Relationship<span class="req">*</span></p>
                                 </a>
                              </div>
                           </div>
                           <div class="col-sm-8" style="padding:0">
                           <div class="labelright">
                           <select name="nominee_relation" id="nomineerel"  class="form-control required show-info occupation" data-name="Nominee Ralationship">
                         <option hidden="" selected="" disabled="" value="">Select Nominee Relationship*</option>
                             @foreach ($base_data->get_nominee_rel_list() as $nominee_obj)
                                <option  <?php if($data['usr_data']['nominee_relation'] == $nominee_obj->star_code) echo 'selected="selected"'; ?> value="{{$nominee_obj->star_code}}" data-name=" {{$nominee_obj->nominee_rel}} "> {{$nominee_obj->nominee_rel}} </option>
                              @endforeach
                                 </select>

                              </div>
                           </div>
                        </div>
                     </div>
<!-- Hospital cash Add-on only for MCI product -->
                  @if($quote->get_product_id() == "MCINEW")
                      <div class="col-sm-4">
                              <div class="card proposalcard">
                                 <div class="col-sm-4" style="padding:0">
                                    <div class="labelleft">
                                       <a>
                                          <p>Hospital Cash Add-On</p>
                                       </a>
                                    </div>
                                 </div>
                                 <div class="col-sm-8" style="padding:0">
                                    <div class="labelright">
                                      <div class="radiobutton">
                                          <input type="radio" name="star_add_on" id="hoc_on" value="1" data-name= "Hospital Cash Add-on" {{($data['usr_data']['star_add_on'] === "1") ? 'checked=checked' : ''}}/>
                                          <label for="hoc_on" >Yes</label>
                                       </div>
                                       <div class="radiobutton">
                                          <input type="radio" name="star_add_on" id="hoc_off" value="0"  data-name= "Hospital Cash" {{(empty($data['usr_data']['star_add_on']) || $data['usr_data']['star_add_on'] === "0") ? 'checked=checked' : ''}}/>
                                          <label for="hoc_off">No</label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                  @endif
        <!-- End Hospital cash Add-on -->
            </div>
         </div>
      <!-- Review Section Starts -->
               <div class="tab-pane" id="review">
                  <h6 class='info-text'>Review the data you entered!</h6>
                   @include('health.policy.policy_preview')
               </div>
            </div>
            <input type="hidden" name="return_page" id="return_page" value="{{ route('health.policy.star.returnPage') }}">   
            <input type="hidden" name="offline_policy" id="offline_policy" value="{{ route('health.policy.star.offlinepolicy') }}">  
         </form>
         <div class="wizard-footer">
            <div class="pull-right">
               <input data-focus='h_benefits' class="btn scrolltop btn-next btn-info" name="next"  id="nextform" value="Next" type="button">
               <input data-focus='h_benefits' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="health-btn-pay">
            </div>
            <div class="pull-left">
               <input data-focus='h_benefits' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
            </div>
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
</div>


<!-- premium breakup modal -->
  <div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup"> </div>
<!--Package Info Modal -->
  <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits">
  </div>

<div id="pay_form"></div>
<input type="hidden" name="datastatus" id="datastatus" value="{{route('health.getconfirm')}}">
<input type="hidden" name="state_city" id="state_city" value="{{route('state_city')}}"> 
<input type="hidden" name="area_city" id="area_city" value="{{route('area_city')}}"> 
@include('health.layouts.inn-ftr')
<script src="{{ URL::asset('js/validate.min.js') }}"></script>
<script src="{{ URL::asset('js/validation_lib.js') }}"></script>
<script src="{{ URL::asset('js/health/policy/common.js')}}"></script>
<script src="{{ URL::asset('js/health/policy/star.js')}}"></script>
<script src="{{ URL::asset('js/health/policy/star_form_validation.js') }}"></script>
<script type="text/javascript">load_dob_list()</script>
<script src="{{ URL::asset('js/sweetalert2.js') }}"></script>
<script src="{{ URL::asset('js/health/healthquote.js') }}"></script>
<script src="{{ URL::asset('js/health/quotation_page.js') }}"></script>
<script src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript"> 
    $(document).ready(function() {
      $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });
</script>
