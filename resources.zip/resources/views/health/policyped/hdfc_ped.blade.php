<div class="tab-pane" id="healthhistory">
	<div class="row">
	<h6 class='info-text'>Enter the Medical Details!</h6>
		<div class="container tabdata">
			<div class="col-sm-12" style="padding:0">
				<div class="card proposalcard">
					 @foreach($base_data->get_ped_list() as $key => $ped)
						<div class="col-sm-12" style="padding:0">
							<div class="col-sm-10" style="padding:0">
								<div class="labelleft">
									<a> <p><strong>{{ $ped['name'] }}</strong> </p></a>
								</div> 
							</div>

							<div class="col-sm-2" style="padding:15px">
								<div class="radiobutton">
									<input type="radio" name="ped[{{ $ped['hdfc_code'] }}]" id="illness-yes" value="1" data-name= "illness" data-key ="illness" data-operator =""/>
									<label for="illness-yes" >Yes</label>
								</div>
								<div class="radiobutton">
									<input type="radio" name="ped[{{ $ped['hdfc_code'] }}]" id="illness-no" value="0" data-name= "illness" data-key ="illness" data-operator ="" checked="checked"/>
									<label for="illness-no">No</label>
								</div>
							</div>
						</div>
					@endforeach
					<!-- If yes display members list -->
					<div  id="having_illness" name="having_illness" style="display: none;">
						<div class="sublist col-sm-8">
							@if ($quote->get_member_count() >= 1)
                				@for($i = 1; $i <= $quote->get_member_count(); $i++) 
									<div class="col-sm-6">
										<p> @if ($i <= 1) SELF @else {{$quote->get_members_list()[$i-1] }} @endif
										<div class="col-sm-6">
											<textarea  name="pedname[disease_member_{{$i}}]" id="disease_member_{{$i}}" value="" data-name= "Disease" data-key ="Disease" class="illness_require"></textarea> 
										</div>
										<br/><br/>
									</div>
								@endfor
							@endif 
						</div>
					</div>
					<!-- Ends members list -->				
				</div>
			</div>
		</div>
	</div>
</div>
