<div class="tab-pane" id="healthhistory">
    <div class="row">
      <h6 class='info-text'>Enter the Medical Details!</h6>
      <div class="container tabdata">
        <div class="col-sm-12" style="padding:0">
          <div class="card proposalcard">
             <?php $dob_list = $data['dob_list']; ?>
          @foreach($base_data->get_ped_list() as $key => $ped)
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10" style="padding:0">
                <div class="labelleft">
                  <a> <p><strong>{{ $ped['name'] }}</strong> </p></a>
                </div> 
              </div>
              <div class="col-sm-2" style="padding:15px">
                <div class="radiobutton">
                  <input type="radio" name="ped[{{ $ped['reliance_code'] }}]" class="question_list_yes" id="{{ $ped['reliance_code'] }}_yes" value="Yes" data-name= "{{ $ped['short_code'] }}" data-key ="{{ $ped['reliance_code'] }}" data-operator =""/>
                  <label for="{{ $ped['reliance_code'] }}_yes" >Yes</label>
                </div>
                <div class="radiobutton">
                  <input type="radio" name="ped[{{ $ped['reliance_code'] }}]" class="question_list_no" id="{{ $ped['reliance_code'] }}_no" value="No" data-name= "{{ $ped['short_code'] }}" data-key ="{{ $ped['reliance_code'] }}" data-operator ="" checked="checked"/>
                  <label for="{{ $ped['reliance_code'] }}_no">No</label>
                </div>
              </div>
            </div>
<!-- If yes display members list -->
          <div  id="{{ $ped['reliance_code'] }}" name="{{ $ped['reliance_code'] }}" style="display: none;">
            <div class="sublist col-sm-8">
              @if ($quote->get_member_count() >= 1)
                        @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                  <div class="col-sm-6">
                    <p> {{$quote->get_members_list()[$i-1] }} (Select Month and Year)
                    <div class="col-sm-8">
                      <div class="col-xs-12" style="margin-bottom: 30px;">
                  <div class="col-xs-6" style="padding-left: 4px;">
                      <select name="ped[member_{{$i}}_month]"  class="form-control  show-info" data-name="month{{$i}}">
                          <option hidden="" selected="" disabled="" value="">Month</option>
                          <option value="01">January</option>
                          <option value="02">February</option>
                          <option value="03">March</option>
                          <option value="04">April</option>
                          <option value="05">May</option>
                          <option value="06">June</option>
                          <option value="07">July</option>
                          <option value="08">August</option>
                          <option value="09">September</option>
                          <option value="10">October</option>
                          <option value="11">November</option>
                          <option value="12">December</option>
                      </select>
                  </div>
                  <div class="col-xs-6">
                      <select name="ped[member_{{$i}}_year]"  class="form-control required show-info dateyear" data-name="Year {{$i}}">
                          <option hidden="" selected="" disabled="" value="" >Year</option>
                        
                         <?php 
                          $currently_selected = date('Y'); 
                                $earliest_year = date('Y', strtotime($dob_list[$i-1])); 
                                $latest_year = date('Y');
                          ?>
                                   @foreach(range( $latest_year, $earliest_year ) as $year)
                                      <option value="{{$year}}" >{{$year}}</option>
                                   @endforeach
                       </select>
                  </div>
          </div>

                    </div>
                    <br/><br/>
                  </div>
                @endfor
              @endif 
            </div>
          </div>
          <!-- Ends members list -->    
@endforeach
<!-- end of question info -->
        </div>
      </div>
    </div>
  </div>
</div>
