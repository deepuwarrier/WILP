<?php 
      $pedlist = [

        ["seq"=> "1",
             "code"=> "1", 
             "id"=> "Head1", 
             "questiontext"=> "Does any of the person(s) to be insured under this policy suffer from any of the following diseases - Diabetes/ Pancreatitis/ Heart/ Jointpain/ Kidney/ Paralysis/ Congenital/ HIV",
             "reponsetype"=> "YESNO"],

         ["seq"=> "2",
             "code"=> "2", 
             "id"=> "HEDHealthHospitalized", 
             "questiontext"=> "Have any of the person(s) to be insured been diagnosed / hospitalized for any illness / injury during the last 48 months ?",
             "reponsetype"=> "YESNO"],
            
         ["seq"=> "3",
             "code"=> "3", 
             "id"=> "HEDHealthClaim", 
             "questiontext"=> "Have any of the person(s) to be insured ever filed a claim with their current/ previous insurer ?",
             "reponsetype"=> "YESNO"],

         ["seq"=> "4",
             "code"=> "4", 
             "id"=> "HEDHealthDeclined", 
             "questiontext"=> "Has any proposal for Health insurance been declined, cancelled or charged a higher premium for any of the person(s) to be insured ?",
             "reponsetype"=> "YESNO"],

         ["seq"=> "5",
             "code"=> "5", 
             "id"=> "HEDHealthCovered", 
             "questiontext"=> "Is any of the person(s) to be insured, already covered under any other health insurance policy of Religare Health Insurance ?",
             "reponsetype"=> "YESNO"],

          ["seq"=> "6",
             "code"=> "6", 
             "id"=> "PEDRespiratoryDetails", 
             "questiontext"=> "Does any of the person(s) to be insured have any Respiratory disease/ Disease of Lungs, Pleura and airway related diseases, including, but not limited to Asthma/ Tuberculosis/ Pleural effusion/ Bronchitis/ Emphysema ?",
             "reponsetype"=> "YESNO"],

          ["seq"=> "7",
             "code"=> "7", 
             "id"=> "PEDEndoDetails", 
             "questiontext"=> "Does any of the person(s) to be insured have any disorders of the endocrine system, including, but not limited to Pituitary/ Parathyroid/ adrenal gland disorders ?",
             "reponsetype"=> "YESNO"],

          ["seq"=> "8",
             "code"=> "8", 
             "id"=> "PEDillnessDetails", 
             "questiontext"=> "Has any of the person(s) to be insured consulted/taken treatment or recommended to take investigations/medication/surgery other than for childbirth/ minor injuries?",
             "reponsetype"=> "YESNO"],

          ["seq"=> "9",
             "code"=> "9", 
             "id"=> "PEDSurgeryDetails", 
             "questiontext"=> "Has any of the person(s) to be insured been hospitalized or has been under any treatment for any illness/injury or has undergone surgery other than for childbirth/ minor injuries ?",
             "reponsetype"=> "YESNO"],
            
          ["seq"=> "10",
             "code"=> "10", 
             "id"=> "PEDotherDetails", 
             "questiontext"=> "Does the person(s) to be insured have any other diseases or ailments not mentioned above ?",
             "reponsetype"=> "YESNO"],

          ["seq"=> "11",
             "code"=> "11", 
             "id"=> "PEDSmokeDetails", 
             "questiontext"=> "Does any of the person(s) to be insured smoke, consume alcohol, or chew tobacco, ghutka or paan or use any recreational drugs beyond moderate limits ?",
             "reponsetype"=> "YESNO"],
            
         ];
?>


<div class="tab-pane" id="healthhistory">
  <div class="row">
      <h6 class='info-text'>Enter the Health Details!</h6>
      <div class="container tabdata">
          <div class="col-sm-12" style="padding:0">
              <div class="card proposalcard">
                @foreach($pedlist as $key => $ped)
                  
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10" style="padding:0">
            <div class="labelleft">
              <a> <p>{{ $ped['questiontext'] }} </p>
              </a>
            </div> 
            </div>
            <div class="col-sm-2" style="padding:15px">
            <div class="radiobutton">
              <input type="radio" name="ped[{{ $ped['id'] }}]" class="preexisting-illness" id="{{ $ped['id'].'-yes' }}" value="1" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator =""/>
              <label for="{{ $ped['id'].'-yes' }}" >Yes</label>
            </div>
            <div class="radiobutton">
              <input type="radio" name="ped[{{  $ped['id'] }}]" id="{{ $ped['id'].'-no' }}" value="0" class="preexisting-illness" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator ="" checked="checked"/>
              <label for="{{ $ped['id'].'-no' }}">No</label>
            </div>
            </div>
          </div>  
          <input type="hidden" name="{{ $ped['id'] }}_code"
           value="{{ $ped['code'] }}">
        @endforeach 

        </div>
      </div>
    </div>
  </div>
</div>
