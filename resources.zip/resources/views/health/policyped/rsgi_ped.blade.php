<?php 
  $age_list = $data['age_list'];
?>
 <div class="tab-pane" id="healthhistory">
    <div class="row">
      <h6 class='info-text'><span style="color:#00669c">Enter the Medical Details!</span></h6>
      <div class="container tabdata">
        <div class="col-sm-12" style="padding:0">
          <div class="card proposalcard">
            <strong><span style="color:#00669c">Medical Questions!</span></strong>
          @foreach($base_data->get_ped_list() as $key => $ped)
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10" style="padding:0">
                <div class="labelleft">
                  <a> <p><strong>{{ $ped['name'] }}</strong> </p></a>
                </div> 
              </div>
              <div class="col-sm-2" style="padding:15px">
                <div class="radiobutton">
                  <input type="radio" name="ped[{{ $ped['rsgi_code'] }}]" class="question_list_yes" id="{{ $ped['rsgi_code'] }}_yes" value="Yes" data-name= "{{ $ped['rsgi_code'] }}" data-key ="{{ $ped['rsgi_code'] }}" data-operator =""/>
                  <label for="{{ $ped['rsgi_code'] }}_yes" >Yes</label>
                </div>
                <div class="radiobutton">
                  <input type="radio" name="ped[{{ $ped['rsgi_code'] }}]" class="question_list_no" id="{{ $ped['rsgi_code'] }}_no" value="No" data-name= "{{ $ped['rsgi_code'] }}" data-key ="{{ $ped['rsgi_code'] }}" data-operator ="" checked="checked"/>
                  <label for="{{ $ped['rsgi_code'] }}_no">No</label>
                </div>
              </div>
            </div>
        <!-- If yes display members list -->
          <div  id="{{ $ped['rsgi_code'] }}" name="{{ $ped['rsgi_code'] }}" style="display: none;">
            <div class="sublist col-sm-8">
              @if ($quote->get_member_count() >= 1)
                @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                  <div class="col-sm-4">
                      <p> @if ($i <= 1) SELF @else {{$quote->get_members_list()[$i-1] }} @endif
                      <input type="checkbox" name="{{ $ped['rsgi_code'] }}_member{{$i}}" class="{{ $ped['rsgi_code'] }} rsgi-ped_question question_list {{$quote->get_members_list()[$i-1]}}" data-members='{{$quote->get_members_list()[$i-1]}}' data-queid={{'ped_question'.$i}} id="{{ $ped['rsgi_code'] }}_member{{$i}}" @if("input[type=checkbox]:checked") value="Yes" @else value="No" @endif data-name= "" data-key ="" data-operator =""  /> </p>
                  </div>
                @endfor
              @endif 
            </div>
          </div>
        <!-- Ends members list -->  
@endforeach
<!--Question info  -->
<div class="sublist col-sm-8" style="margin-top: 6%;">
    @for($i = 1; $i <= $quote->get_member_count(); $i++)
      <div  id="ped_question{{$i}}" name="ped_question{{$i}}" style="display: none;">
          <div class="col-sm-4">
                  <div>
                    <p>{{$quote->get_members_list()[$i-1]}}</b> (Enter illness details)</p>
          <p>Name of the illness/injury</p>
              <textarea  name="question_info[nameOfIllness_{{$i}}]" id="nameOfIllness_{{$i}}" value="" data-name= "Disease" data-key ="Disease" style="width: 100%;"></textarea> 
          <p>Date of first diagnosis</p>
          <div class="col-xs-12" style="margin-bottom: 30px;">
                  <div class="col-xs-6" style="padding-left: 4px;">
                      <select name="question_info[monthOfDiagnosis_{{$i}}]" id="monthOfDiagnosis_{{$i}}" class="form-control  show-info" data-name="month{{$i}}">
                          <option hidden="" selected="" disabled="" value="">Month</option>
                          <option value="01">January</option>
                          <option value="02">February</option>
                          <option value="03">March</option>
                          <option value="04">April</option>
                          <option value="05">May</option>
                          <option value="06">June</option>
                          <option value="07">July</option>
                          <option value="08">August</option>
                          <option value="09">September</option>
                          <option value="10">October</option>
                          <option value="11">November</option>
                          <option value="12">December</option>
                      </select>
                  </div>
                  <div class="col-xs-6">
                      <select name="question_info[yearOfDiagnosis_{{$i}}]" id="yearOfDiagnosis_{{$i}}" class="form-control  show-info dateyear" data-name="Year {{$i}}">
                          <option hidden="" selected="" disabled="" value="" >Year</option>
                        
                         <?php  $currently_selected = date('Y'); 
                                $earliest_year = date('Y', strtotime($data['dob_list'][$i-1])); 
                                $latest_year = date('Y');
                          ?>
                                   @foreach(range( $latest_year, $earliest_year ) as $year)
                                      <option value="{{$year}}" >{{$year}}</option>
                                   @endforeach
                       </select>
                  </div>
          </div>
          <p>Treatment/Medication</p>
          <div class="col-xs-12" style="margin-bottom: 30px;">
             <select data-md-selectize  name="question_info[medicationDetail_{{$i}}]" id="medicationDetail_{{$i}}" class="form-control show-info" data-name="">
                <option hidden="" selected="" disabled="" value="">Select Treatment Type</option>
                  <option value="Received" >Received</option>
                  <option value="Receiving" >Receiving</option>
              </select>
          </div>
          <p>Treatment Outcome</p>
          <div class="col-xs-12" style="margin-bottom: 30px;">
                    <select name="question_info[treatmentOutCome_{{$i}}]" id="treatmentOutCome_{{$i}}" class="form-control  show-info" data-name="">

                        <option hidden="" selected="" disabled="" value="" >Select Treatment Outcome</option>
                        <option value="Fully Cured" >Fully Cured</option>
                        <option value="Partially Cured" >Partially Cured</option>
                        <option value="Ongoing" >Ongoing</option>
                    </select>
          </div>
        </div>
      </div>
      </div>
      @endfor
    </div>
<!-- end of question info -->
<!-- lifestyle Details -->
<!-- Questions -->
<!-- Question 1 -->
<div class="Alcohol" >
  <div class="col-sm-12" style="padding:0; margin-top:0%;">
    <div class="col-sm-10" style="padding:0">
     <strong><span style="color:#00669c">Life style Questions!</span></strong>
      <div class="labelleft">
        <a> <p>Have any of the person(s) consume Alcohol ?</p> </a>
      </div> 
    </div>
    <div class="col-sm-2" style="padding:15px">
      <div class="radiobutton">
        <input type="radio" name="Alcohol" id="Alcohol_yes" value="1" data-name= "Alcohol" data-key ="Alcohol" data-operator =""/>
        <label for="Alcohol_yes" >Yes</label>
      </div>
      <div class="radiobutton">
        <input type="radio" name="Alcohol" id="Alcohol_no" value="0" data-name= "Alcohol" data-key ="Alcohol" data-operator ="" checked="checked"/>
        <label for="Alcohol_no">No</label>
      </div>
    </div>
</div>
<!-- If yes display members list -->
<div  id="lifestyle_alcohol" name="lifestyle_alcohol" style="display: none;">
  <div class="sublist col-sm-8">
  @for($i = 1; $i <= $quote->get_member_count(); $i++) 
    <div class="col-sm-4">
      @if($age_list[$i-1] >= 18)
      <p> {{$quote->get_members_list()[$i-1]}}
      <input type="checkbox" name="alcohol_member{{$i}}" class="lifestyle_alcohol rsgi-lifestyle_question" id="alcohol_member{{$i}}" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Alcohol Member{{$i}}" data-key ="Alcohol Member{{$i}}" data-operator ="{{$i}}"/> </p>
      @endif
    </div>
  @endfor
  </div>
</div>
<!--Quantity and No of years  -->
<div class="sublist col-sm-8">
  @for($i = 1; $i <= $quote->get_member_count(); $i++) 
  <div  id="alcohol_quantity{{$i}}" name="alcohol_quantity{{$i}}" style="display: none;">
    <div class="col-sm-4">
      <p>Mention Quantity (ml/week)</p>
      <input type="textarea" name="alcohol_quantity_{{$i}}" id="alcohol_quantity_{{$i}}" value="" data-name= "Consuming Quantity" data-key ="Consuming Quantity" maxlength="3" class="required" /> 
      <br/>
      <p>No. of years</p>
      <div class="col-xs-8" style="padding-left: 4px;">
        <select data-md-selectize  name="alcohol_no_of_years_{{$i}}" id="alcohol_no_of_years_{{$i}}" class="form-control show-info required" data-name="No. of years">
          <option hidden="" selected="" disabled="" value="">Select Years*</option>
          @for($alc=1; $alc <= $age_list[$i-1];$alc++)
            <option value="{{$alc}}" >{{$alc}}</option>
          @endfor
        </select>
      </div>
    </div>
  </div>
  @endfor
</div>
</div>
<!-- Question 2 -->
<div class="Smoke">
  <div class="col-sm-12" style="padding:0">
    <div class="col-sm-10" style="padding:0">
      <div class="labelleft">
        <a> <p>Have any of the person(s) smoke ?</p> </a>
      </div> 
    </div>
    <div class="col-sm-2" style="padding:15px">
      <div class="radiobutton">
        <input type="radio" name="Smoke" id="Smoke_yes" value="1" data-name= "Smoke" data-key ="Smoke" data-operator =""/>
        <label for="Smoke_yes" >Yes</label>
      </div>
      <div class="radiobutton">
        <input type="radio" name="Smoke" id="Smoke_no" value="0" data-name= "Smoke" data-key ="Smoke" data-operator ="" checked="checked"/>
        <label for="Smoke_no">No</label>
      </div>
    </div>
</div>
<!-- If yes display members list -->
<div  id="lifestyle_smoke" name="lifestyle_smoke" style="display: none;">
    <div class="sublist col-sm-8">
    @for($i = 1; $i <= $quote->get_member_count(); $i++) 
    <div class="col-sm-4">
    @if($age_list[$i-1] >= 18)
      <p>{{$quote->get_members_list()[$i-1]}}
      <input type="checkbox" name="smoke_member{{$i}}" class="lifestyle_smoke rsgi-lifestyle_question" id="smoke_member{{$i}}" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Smoke Member{{$i}}" data-key ="Smoke Member{{$i}}" data-operator ="{{$i}}"/> </p>
    @endif
  </div>
@endfor
</div>
</div>
<!--Quantity and No of years  -->
<div class="sublist col-sm-8">
    @for($i = 1; $i <= $quote->get_member_count(); $i++)
      <div  id="smoke_quantity{{$i}}" name="smoke_quantity{{$i}}" style="display: none;">
        <div class="col-sm-4">
          <p>Mention Quantity  (smoke/day)</p>
          <input type="textarea" name="smoke_quantity_{{$i}}" id="smoke_quantity_{{$i}}" value="" data-name= "Consuming Quantity" data-key ="Consuming Quantity" maxlength="3" class="required" /> 
          <p>No. of years</p>
          <div class="col-xs-8" style="padding-left: 4px;">
            <select data-md-selectize name="smoke_no_of_years_{{$i}}" id="smoke_no_of_years_{{$i}}" class="form-control show-info required" data-name="No. of years">
                <option hidden="" selected="" disabled="" value="">Select Years*</option>
                  @for($smk=1; $smk <= $age_list[$i-1];$smk++)
                    <option value="{{$smk}}" >{{$smk}}</option>
                  @endfor
            </select>
          </div>
        </div>
      </div>
      @endfor
    </div>
</div>
<!-- Question 3 -->
<div class="Tobacco">
    <div class="col-sm-12" style="padding:0">
        <div class="col-sm-10" style="padding:0">
          <div class="labelleft">
              <a> <p>Have any of the person(s) consume Tobacco/Gutka/Pan/Pan masala ?</p> </a>
          </div> 
        </div>
        <div class="col-sm-2" style="padding:15px">
          <div class="radiobutton">
              <input type="radio" name="Tobacco" id="Tobacco_yes" value="1" data-name= "Tobacco" data-key ="Tobacco" data-operator =""/>
              <label for="Tobacco_yes" >Yes</label>
          </div>
        <div class="radiobutton">
          <input type="radio" name="Tobacco" id="Tobacco_no" value="0" data-name= "Tobacco" data-key ="Tobacco" data-operator ="" checked="checked"/>
          <label for="Tobacco_no">No</label>
        </div>
      </div>
</div>
<!-- If yes display members list -->
<div  id="lifestyle_tobacco" name="lifestyle_tobacco" style="display: none;">
      <div class="sublist col-sm-8">
       
          @for($i = 1; $i <= $quote->get_member_count(); $i++) 
            <div class="col-sm-4">
              @if($age_list[$i-1] >= 18)
                <p> {{$quote->get_members_list()[$i-1]}}
                <input type="checkbox" name="tobacco_member{{$i}}" class="lifestyle_tobacco rsgi-lifestyle_question" id="tobacco_member{{$i}}" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Tobacco Member{{$i}}" data-key ="Tobacco Member{{$i}}" data-operator ="{{$i}}"/> </p>
                @endif
            </div>
          @endfor
        
      </div>
</div>
<!--Quantity and No of years  -->
<div class="sublist col-sm-8">
    @for($i = 1; $i <= $quote->get_member_count(); $i++)
      <div  id="tobacco_quantity{{$i}}" name="tobacco_quantity{{$i}}" style="display: none;">
        <div class="col-sm-4">
          <p>Mention Quantity (consume/day)</p>
          <input type="textarea" name="tobacco_quantity_{{$i}}" id="tobacco_quantity_{{$i}}" value="" data-name= "Consuming Quantity" data-key ="Consuming Quantity" maxlength="3" class="required"/> 
          <p>No. of years</p>
          <div class="col-xs-8" style="padding-left: 4px;">
            <select data-md-selectize  name="tobacco_no_of_years_{{$i}}" id="tobacco_no_of_years_{{$i}}" class="form-control show-info required" data-name="No. of years">
            <option hidden="" selected="" disabled="" value="">Select Years*</option>
            @for($tobacco=1; $tobacco <= $age_list[$i-1];$tobacco++)
              <option value="{{$tobacco}}" >{{$tobacco}}</option>
            @endfor
            </select>
          </div>
        </div>
    </div>
    @endfor
</div>
</div>
<!-- Question 4 -->
<div class="Narcotics">
    <div class="col-sm-12" style="padding:0">
      <div class="col-sm-10" style="padding:0">
        <div class="labelleft">
            <a> <p>Have any of the person(s) consume Narcotics ?</p> </a>
        </div> 
      </div>
      <div class="col-sm-2" style="padding:15px">
        <div class="radiobutton">
          <input type="radio" name="Narcotics" id="Narcotics_yes" value="1" data-name= "Narcotics" data-key ="Narcotics" data-operator =""/>
          <label for="Narcotics_yes" >Yes</label>
        </div>
        <div class="radiobutton">
          <input type="radio" name="Narcotics" id="Narcotics_no" value="0" data-name= "Narcotics" data-key ="Narcotics" data-operator ="" checked="checked"/>
          <label for="Narcotics_no">No</label>
        </div>
      </div>
</div>
<!-- If yes display members list -->
<div  id="lifestyle_narcotics" name="lifestyle_narcotics" style="display: none;">
    <div class="sublist col-sm-8">
          @for($i = 1; $i <= $quote->get_member_count(); $i++) 
              <div class="col-sm-4">
                  @if($age_list[$i-1] >= 18)
                    <p> {{$quote->get_members_list()[$i-1]}}
                    <input type="checkbox" name="narcotics_member{{$i}}" class="lifestyle_narcotics rsgi-lifestyle_question" id="narcotics_member{{$i}}" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Narcotics Member{{$i}}" data-key ="Narcotics Member{{$i}}" data-operator ="{{$i}}"/> </p>
                  @endif
              </div>
          @endfor
    </div>
</div>
<!--Quantity and No of years  -->
<div class="sublist col-sm-8">
  @for($i = 1; $i <= $quote->get_member_count(); $i++)
    <div id="narcotics_quantity{{$i}}" name="narcotics_quantity{{$i}}" style="display: none;">
      <div class="col-sm-4">
        <p>Mention Quantity (consume/day)</p>
          <input type="textarea" name="narcotics_quantity_{{$i}}" id="narcotics_quantity_{{$i}}" value="" data-name= "Consuming Quantity" data-key ="Consuming Quantity" maxlength="3" class="required"/> 
        <p>No. of years</p>
          <div class="col-xs-8" style="padding-left: 4px;">
            <select data-md-selectize name="narcotics_no_of_years_{{$i}}" id="narcotics_no_of_years_{{$i}}" class="form-control show-info required" data-name="No. of years">
                <option hidden="" selected="" disabled="" value="">Select Years*</option>
                @for($narcotics=1; $narcotics <= $age_list[$i-1];$narcotics++)
                    <option value="{{$narcotics}}" >{{$narcotics}}</option>
                @endfor
            </select>
        </div>
      </div>
    </div>
@endfor
</div>
</div>
<!-- End Questions -->
<!-- End lifestyle Details -->
        </div>
      </div>
    </div>
  </div>
</div>
