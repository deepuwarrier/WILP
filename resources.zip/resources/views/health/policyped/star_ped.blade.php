<div class="tab-pane" id="healthhistory">
  <div class="row">
  <h6 class='info-text'>Enter the Health Details!</h6>
    <div class="container tabdata">
      <div class="col-sm-12" style="padding:0">
        <div class="card proposalcard">
          <strong><span style="color:#00669c">Medical Questions !</span></strong> <br><br>
          @if($quote->get_product_id() == "FHONEW")
          <!-- Illness Question For FHO -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>1. </b> Do you have any health problems ? Has the person proposed for insurance been advised for Sub-fertility/Infertility ?</p>
            </div>
            <div class="col-sm-2">
              <div class="radiobutton">
                <input type="radio" name="illness" id="illness_yes" value="1" data-name= "Any Pre-existing illness" />
                <label for="illness_yes" >Yes</label>
              </div>
              <div class="radiobutton">
                <input type="radio" name="illness" id="illness_no" value="0"  data-name= "Any Pre-existing illness" checked="checked"/>
                <label for="illness_no">No</label>
              </div>
            </div>
          </div>
          <!-- If yes display text field -->
          <div id="having_illness" name="having_illness" style="display: none;">
            <div class="sublist col-sm-8">
              <p style= "margin-left: 4%;"> Enter Pre existing Disease for below applicable member <span class="req" style="color:red;">*</span></p>
              @if ($quote->get_member_count() >= 1)
                @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                  <div class="col-sm-3">
                    <p style= "margin-left: 10%;"> <b> {{$quote->get_members_list()[$i-1]}}</b>  
                    <div class="col-sm-3">
                      <textarea  name="illness[{{$i}}]" id="illness_member_{{$i}}" value="" data-name= "" data-key ="" class="illness_require"></textarea> 
                    </div><br/><br/>
                  </div>
                @endfor
              @endif 
            </div>
          </div>
            <!-- End of FHO illness text field -->
          @else
          <!-- Illness Question -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>1. </b>  Does any of the person(s) to be insured under this policy suffering from any Disease, illness or Injury ?</p>
            </div>
            <div class="col-sm-2">
              <div class="radiobutton">
                <input type="radio" name="illness" id="illness_yes" value="1" data-name= "Any Pre-existing illness" />
                <label for="illness_yes" >Yes</label>
              </div>
              <div class="radiobutton">
                <input type="radio" name="illness" id="illness_no" value="0"  data-name= "Any Pre-existing illness" checked="checked"/>
                <label for="illness_no">No</label>
              </div>
            </div>
          </div>
          <!-- If yes display text field -->
          <div id="having_illness" name="having_illness" style="display: none;">
            <div class="sublist col-sm-8">
              <p style= "margin-left: 4%;"> Enter Pre existing Disease for below applicable member <span class="req" style="color:red;">*</span></p>
              @if ($quote->get_member_count() >= 1)
                @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                  <div class="col-sm-3">
                    <p style= "margin-left: 10%;"> <b> {{$quote->get_members_list()[$i-1]}}</b>  
                      <div class="col-sm-3">
                        <textarea  name="illness[{{$i}}]" id="illness_member_{{$i}}" value="" data-name= "" data-key ="" required></textarea> 
                      </div><br/><br/>
                  </div>
                @endfor
              @endif 
            </div>
          </div>
          <!-- End of illness text field -->
          @endif
          <!-- Critical Illness Question -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p><b>2. </b>  Have you or any member of your family proposed to be insured, suffered or are suffering from any disease/ailment/adverse medical condition of any kind especially Heart/Stroke/Cancer/Renal disorder/Alzheimer's disease/Parkinsons's disease ?</p>
            </div>
            <div class="col-sm-2">
              <div class="radiobutton">
                <input type="radio" name="criticalIllness" id="criticalIllness_yes" value="1" data-name= "Suffering from critical illness" />
                <label for="criticalIllness_yes" >Yes</label>
              </div>
              <div class="radiobutton">
                <input type="radio" name="criticalIllness" id="criticalIllness_no" value="0"  data-name= "Suffering from critical illness" checked="checked"/>
                <label for="criticalIllness_no">No</label>
              </div>
            </div>
          </div>
          <!-- End of Critical Illness -->
          <!-- Comp products winter sport & Manual labour -->
          @if($quote->get_product_id() == "COMPREHENSIVEIND" || $quote->get_product_id() == "COMPREHENSIVE")
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10">
                <p><b>3.</b>  Does your occupation require you to engage in manual labour ?</p>
              </div>
              <div class="col-sm-2">
                <div class="radiobutton">
                  <input type="radio" name="engageManualLabour" id="engageManualLabour_yes" value="1" data-name= "Engage Manual Labour" />
                  <label for="engageManualLabour_yes" >Yes</label>
                </div>
              <div class="radiobutton">
                <input type="radio" name="engageManualLabour" id="engageManualLabour_no" value="0"  data-name= "Engage Manual Labour" checked="checked"/>
                <label for="engageManualLabour_no">No</label>
              </div>
            </div>
          </div>
          <!-- If yes display text field -->
          <div id="ManualLabour" name="ManualLabour" style="display: none;">
            <div class="sublist col-sm-8">
              <p style= "margin-left: 4%;"> Enter Manual Labour details for below applicable member <span class="req" style="color:red;">*</span></p>
              @if ($quote->get_member_count() >= 1)
                @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                  <div class="col-sm-3">
                    <p style= "margin-left:10%;"> <b> {{$quote->get_members_list()[$i-1]}}</b> 
                    <div class="col-sm-3">
                      <textarea  name="engageManualLabour[{{$i}}]" id="labour_member_{{$i}}" value="" required></textarea> 
                    </div><br/><br/>
                  </div>
                @endfor
              @endif 
            </div>
          </div>
          <!-- Winter Sports  -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>4.</b>  Do you engage in or propose to engage in any activity or sport which is hazardous or adventurous in nature such as Racing Mountaineering Winter Sports etc if so Please specify ?</p>
            </div>
            <div class="col-sm-2">
              <div class="radiobutton">
                <input type="radio" name="engageWinterSports" id="engageWinterSports_yes" value="1" data-name= "Engage Winter Sports" />
                <label for="engageWinterSports_yes" >Yes</label>
              </div>
              <div class="radiobutton">
                <input type="radio" name="engageWinterSports" id="engageWinterSports_no" value="0"  data-name= "Engage Winter Sports" checked="checked"/>
                <label for="engageWinterSports_no">No</label>
              </div>
            </div>
          </div>
          <!-- If yes display text field -->
          <div id="WinterSports" name="WinterSports" style="display: none;">
            <div class="sublist col-sm-8">
              <p style= "margin-left: 4%;"> Enter Winter Sports details for below applicable member <span class="req" style="color:red;">*</span></p>
                @if ($quote->get_member_count() >= 1)
                  @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                    <div class="col-sm-3">
                      <p style= "margin-left: 10%;"> <b> {{$quote->get_members_list()[$i-1]}}</b> 
                      <div class="col-sm-3">
                        <textarea  name="engageWinterSports[{{$i}}]" id="sports_member_{{$i}}" value="" required></textarea> 
                      </div><br/><br/>
                    </div>
                  @endfor
                @endif 
            </div>
          </div>
          <!-- end Winter Sports  -->
          @endif
          <!-- End Comp products winter sport & Manual labour -->
          <!-- Diabet product details -->
          @if($quote->get_product_id() == "DIABETESIND" || $quote->get_product_id() == "DIABETESFMLY")
          <!-- Eye / Kidney / Non healing wonds -->
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10">
                <p><b>3.</b>  Does any of the person(s) to be insured under this policy  facing problem related to Eye/ Kidney/ Non-healing Wounds anywhere in the body ?</p>
              </div>
              <div class="col-sm-2">
                <div class="radiobutton">
                  <input type="radio" name="eyeProblem" id="eyeProblem_yes" value="1" data-name= "Eye/Kidney/Non-healing Wounds problem" />
                  <label for="eyeProblem_yes" >Yes</label>
                </div>
                <div class="radiobutton">
                  <input type="radio" name="eyeProblem" id="eyeProblem_no" value="0"  data-name= "Eye/Kidney/Non-healing Wounds problem" checked="checked"/>
                  <label for="eyeProblem_no">No</label>
                </div>
              </div>
            </div>
            <!-- Drugs details -->
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10">
                <p><b>4.</b>  Have you been taking drugs/medicines regularly during the last 1 year for any disease/illness (other than hypertension/ diabetes/ hypothyroidism) ?</p>
              </div>
              <div class="col-sm-2">
                <div class="radiobutton">
                  <input type="radio" name="criticalDrugs" id="criticalDrugs_yes" value="1" data-name= "Taking Drugs" />
                  <label for="criticalDrugs_yes" >Yes</label>
                </div>
                <div class="radiobutton">
                  <input type="radio" name="criticalDrugs" id="criticalDrugs_no" value="0"  data-name= "Taking Drugs" checked="checked"/>
                  <label for="criticalDrugs_no">No</label>
                </div>
              </div>
            </div>
            <!-- Insulin details -->
            <div class="col-sm-12" style="padding:0">
              <div class="col-sm-10">
                <p><b>5.</b> Does any of the person(s) to be insured under this policy is on Insulin ?</p>
              </div>
              <div class="col-sm-2">
                <div class="radiobutton">
                  <input type="radio" name="insulinProblem" id="insulinProblem_yes" value="1" data-name= "Insulin Problem" />
                  <label for="insulinProblem_yes" >Yes</label>
                </div>
                <div class="radiobutton">
                  <input type="radio" name="insulinProblem" id="insulinProblem_no" value="0"  data-name= "Insulin Problem" checked="checked"/>
                  <label for="insulinProblem_no">No</label>
                </div>
              </div>
            </div>
            <!-- If yes display text field -->
            <div id="InsulinProblem" name="InsulinProblem" style="display: none;">
              <div class="sublist col-sm-8">
                <p style= "margin-left: 4%;"> Enter Number of years for below Insulin applicable member <span class="req" style="color:red;">*</span></p>
                @if ($quote->get_member_count() >= 1)
                  @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                    <div class="col-sm-3">
                      <p style= "margin-left: 10%;"><b>{{$quote->get_members_list()[$i-1]}}</b> 
                      <div class="col-sm-3">
                        <textarea type="text" name="insulinFrom[{{$i}}]" id="insulin_member_{{$i}}" value="" class="insulin"></textarea>
                      </div><br/><br/>
                    </div>
                  @endfor
                @endif 
              </div>
          </div>
            <!-- Diabetes Mellitus Details -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p><b>6.</b>  How long are you suffering from Diabetes Mellitus ?</p>
            </div>
          </div>
          <div class="sublist col-sm-12">
            @if ($quote->get_member_count() >= 1)
              @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                <div class="col-sm-4">
                  <p><b> {{$quote->get_members_list()[$i-1]}}</b> (Please select) <b><span class="req" style="color:red;">*</span> </b>
                  <div class="col-sm-4">
                    <select name="diabetesMellitus[{{$i}}]" id="diabetesMellitus_member_{{$i}}" value="" data-name= "Diabetes Mellitus" class="required">
                      <option hidden="" selected="" disabled="" value="">Select</option>
                      <option value = "past 1 year"> Past 1 Year </option>
                      <option value = "1-5 year"> 1 - 5 years</option>
                      <option value = "6-10 year">6 - 10 years</option>
                      <option value = "11-15 year">11 - 15 years</option>
                      <option value = "more than 20 years">More than 20 years</option>
                    </select> 
                  </div><br/><br/>
                </div>
              @endfor
            @endif 
          </div>
          <!-- Blood sugar level -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>7.</b>  Enter all members Fasting Blood Sugar</p>
            </div>
          </div>
          <div class="sublist col-sm-12">
            @if ($quote->get_member_count() >= 1)
              @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                <div class="col-sm-4">
                  <p><b>{{$quote->get_members_list()[$i-1]}}</b> (Enter Blood sugar level) <b><span class="req" style="color:red;">*</span> </b>
                  <div class="col-sm-4">
                    <input type="text" name="bloodSugar[{{$i}}]" id="bloodSugar_member_{{$i}}" value="" data-name= "Blood Sugar Level" class="level"></p>
                  </div><br/><br/>
                </div>
              @endfor
            @endif 
          </div>
          <!--  Serum Creatinine -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>8.</b>  Enter all members Serum Creatinine</p>
            </div>
          </div>
          <div class="sublist col-sm-12">
            @if ($quote->get_member_count() >= 1)
              @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                <div class="col-sm-4">
                  <p><b>{{$quote->get_members_list()[$i-1]}} </b> (Enter Serum Creatinine)<span class="req" style="color:red;">*</span>
                  <div class="col-sm-4">
                    <input type="text" name="serumCreatinine[{{$i}}]" id="serumCreatinine_member_{{$i}}" value="" data-name= "Serum Creatinine"  class="level"></p>
                  </div><br/><br/>
                </div>
              @endfor
            @endif 
          </div>
          <!-- Hba1c -->
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10">
              <p> <b>9. </b>  Enter HbA1c (Glycated hemoglobin)</p>
            </div>
          </div>
          <div class="sublist col-sm-12">
            @if ($quote->get_member_count() >= 1)
              @for($i = 1; $i <= $quote->get_member_count(); $i++) 
                <div class="col-sm-4">
                  <p><b>{{$quote->get_members_list()[$i-1]}}</b> (Enter HbA1c) <b><span class="req" style="color:red;">*</span> </b>
                  <div class="col-sm-4">
                    <input type="text" name="hba1c[{{$i}}]" id="hba1c_member_{{$i}}" value="" data-name= "Hba1c" class="level"></p>
                  </div><br/><br/>
                </div>
               @endfor
            @endif 
        </div>
      @endif
      <!-- End of Diabet product details -->
      <!-- Social Status  -->
      <br><br>
      <div class="col-sm-12" style="padding:0; margin-top:2%;">
        <strong><span style="color:#00669c">Social Status</span></strong><br><br>
        <div class="col-sm-12" style="padding:0">
          <div class="col-sm-10">
            <p>Does any of the person(s) to be insured belong to the special categories of <span class="blueitalictext">BPL</span>, <span class="blueitalictext">Differently abled</span> or working in an <span class="blueitalictext">Unorganized or Informal Sector</span> ?</p>
          </div>
          <div class="col-sm-2">
            <div class="radiobutton">
              <input type="radio" name="social_status" class="socialstatus" id="social-status" value="1" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}"/>
                <label for="social-status" >Yes</label>
            </div>
            <div class="radiobutton">
              <input type="radio" name="social_status" id="socialstatuss" value="0" class="socialstatus" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}" checked="checked"/>
              <label for="socialstatuss">No</label>
            </div>
          </div>
          <div id="socialstatus_bpl" name="socialstatus_bpl" style="display: none;">
            <div class="col-sm-10 pad10bottom">
              <strong>Please select the categories that applies to any of the person(s) to be insured</strong>
            </div>
            <div class="sublist">
              <div class="col-sm-10">
                <p>Working in an Unorganized Sector?</p>
              </div>
              <div class="col-sm-2">    
                <input type="checkbox" name="unorganized_sector" class="unorganized cate_insured" id="unorganized-sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "UnOrganized Sector" data-key ="UnOrganized Sector" data-operator ="{{$i}}"/>
              </div>
            <div class="col-sm-10">
              <p>Working in an Informal sector</p>
            </div>
            <div class="col-sm-2">
              <input type="checkbox" name="informal_sector" class="informalsector cate_insured" id="informal_sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Informal Sector" data-key ="Informal Sector" data-operator ="{{$i}}"/>
            </div>
            <div class="col-sm-10">
              <p>Below Poverty Line (BPL)</p>
            </div>
            <div class="col-sm-2">
              <input type="checkbox" name="below_poverty" class="belowpoverty cate_insured" id="below_poverty" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Below Poverty" data-key ="Below Poverty" data-operator ="{{$i}}"/>
            </div>
          <div class="col-sm-10">
            <p>Differently abled</p>
          </div>
          <div class="col-sm-2">
            <input type="checkbox" name="handicaped" class="handicaped cate_insured" id="handicaped" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Handicaped Disabled" data-key ="Handicaped Disabled" data-operator ="{{$i}}"/>
          </div>
        </div>
      </div>
  </div>
</div>
<!-- Social status ends -->
    </div>
    </div>  
    </div>
  </div>
</div>
