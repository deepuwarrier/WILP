  

  <!-- Social Status  -->
  <br><br>
    <div class="col-sm-12" style="padding:0; margin-top:2%;">
     <strong><span style="color:#00669c">Social Status</span></strong><br><br>
      <div class="col-sm-12" style="padding:0">
          <div class="col-sm-10">
          <p>Does any of the person(s) to be insured belong to the special categories of <span class="blueitalictext">BPL</span>, <span class="blueitalictext">Differently abled</span> or working in an <span class="blueitalictext">Unorganized or Informal Sector</span> ?</p>
        </div>
        <div class="col-sm-2">
          <div class="radiobutton">
            <input type="radio" name="social_status" class="socialstatus" id="social-status" value="1" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}"/>
            <label for="social-status" >Yes</label>
          </div>
          <div class="radiobutton">
            <input type="radio" name="social_status" id="socialstatuss" value="0" class="socialstatus" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}" checked="checked"/>
            <label for="socialstatuss">No</label>
          </div>
        </div>
        <div id="socialstatus_bpl" name="socialstatus_bpl" style="display: none;">
          <div class="col-sm-10 pad10bottom">
            <strong>Please select the categories that applies to any of the person(s) to be insured</strong>
          </div>
          <div class="sublist">
            <div class="col-sm-10">
              <p>Working in an Unorganized Sector?</p>
            </div>
            <div class="col-sm-2">    
              <input type="checkbox" name="unorganized_sector" class="unorganized" id="unorganized-sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "UnOrganized Sector" data-key ="UnOrganized Sector" data-operator ="{{$i}}"/>
            </div>
            <div class="col-sm-10">
              <p>Working in an Informal sector</p>
            </div>
            <div class="col-sm-2">
              <input type="checkbox" name="informal_sector" class="informalsector" id="informal_sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Informal Sector" data-key ="Informal Sector" data-operator ="{{$i}}"/>
            </div>
            <div class="col-sm-10">
              <p>Below Poverty Line (BPL)</p>
            </div>
            <div class="col-sm-2">
              <input type="checkbox" name="below_poverty" class="belowpoverty" id="below_poverty" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Below Poverty" data-key ="Below Poverty" data-operator ="{{$i}}"/>
            </div>
            <div class="col-sm-10">
              <p>Differently abled</p>
            </div>
            <div class="col-sm-2">
              <input type="checkbox" name="handicaped" class="handicaped" id="handicaped" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Handicaped Disabled" data-key ="Handicaped Disabled" data-operator ="{{$i}}"/>
            </div>
          </div>
        </div>
      </div>
    </div>

<!-- Social status ends -->
