<?php 
if($data['userdata']['productId'] == '129HL05I01' || '129HL08I01' || '129HL01F01'){
      $pedlist = [
        ["seq"=> "1",
             "code"=> "1", 
             "id"=> "illness", 
             "questiontext"=> "Does any of the person(s) to be insured have at any point of time been affected by any disease, taken treatment or undergone surgeries ?",
             "reponsetype"=> "YESNOText"],

        ["seq"=> "2",
             "code"=> "2", 
             "id"=> "criticalIllness", 
             "questiontext"=> "Is any of the person(s) to be insured suffering from Cancer, Chronic Kidney diseases, Heart diseases, Psychiatric or related disorders, Brain disorders or Renal disorders or taking medicines regularly during the last 1 year for any disease/illness (other than hypertension/ diabetes/ hypothyroidism ) ?",
             "reponsetype"=> "YESNOText"],
         ];

}

if($data['userdata']['productId'] == '129HL07F01'){
  if($relmembers['0']['attributes']['rel_name'] == 'WIFE' || $relmembers['0']['attributes']['rel_name'] == 'HUS'){
     $pedlist = [

          ["seq"=> "1",
             "code"=> "1", 
             "id"=> "illnessDependent", 
             "questiontext"=> "Do you have any health problems ?",
             "reponsetype"=> "YESNOText"],

        ["seq"=> "2",
             "code"=> "2", 
             "id"=> "illnessSelfSpouse", 
             "questiontext"=> "Do you have any health problems ? Has the person proposed for insurance been advised for treatment of SUB-FERTILITY / INFERTILITY ?",
             "reponsetype"=> "YESNOText"] ,
          
        ["seq"=> "3",
             "code"=> "3", 
             "id"=> "criticalIllness", 
             "questiontext"=> "Does this member proposed to be insured, suffered or are suffering from any disease/ailment/adverse medical condition of any kind especially Heart/Stroke/ Cancer/Renal disorder/Alzheimer's disease/Parkinson's disease ?",
             "reponsetype"=> "YESNOText"],  
             ];

 }

 else {
       $pedlist = [

          ["seq"=> "1",
             "code"=> "1", 
             "id"=> "illness", 
             "questiontext"=> "Does any of the person(s) to be insured have at any point of time been affected by any disease, taken treatment or undergone surgeries ?",
             "reponsetype"=> "YESNOText"],

        ["seq"=> "2",
             "code"=> "2", 
             "id"=> "criticalIllness", 
             "questiontext"=> "Is any of the person(s) to be insured suffering from Cancer, Chronic Kidney diseases, Heart diseases, Psychiatric or related disorders, Brain disorders or Renal disorders  or taking medicines regularly during the last 1 year for any disease/illness (other than hypertension/ diabetes/ hypothyroidism ) ?",
             "reponsetype"=> "YESNOText"],
          ];

 }
}
?>

<div class="tab-pane" id="healthhistory">
  <div class="row">
      <h6 class='info-text'>Enter the Health Details!</h6>
      <div class="container tabdata">
         <div class="col-sm-12" style="padding:0">
              <div class="card proposalcard">
    <!-- Illness before 12 moths for REd Carpet -->
      @if($data['userdata']['productId'] == '129HL08I01')
         <div class="col-sm-10">
            <p> Is any of the person(s) to be insured having Illness during the last 1 year ?
            </p>
         </div>
         <div class="col-sm-2">
            <div class="radiobutton">
               <input type="radio" name="illnessBeforeTwelveMonths" class="illnessBeforeTwelveMonths" id="illnessBeforeTwelveMonths" value="1" data-name="Illness Before 1 year" data-key ="Illness Before 1 year" data-operator ="{{$i}}"/>
               <label for="illnessBeforeTwelveMonths" >Yes</label>
            </div>
            <div class="radiobutton">
               <input type="radio" name="illnessBeforeTwelveMonths" id="illbfryear" value="0" class="illnessBeforeTwelveMonths" data-name= "Illness Before 1 year" data-key ="Illness Before 1 year" data-operator ="{{$i}}" checked="checked" />
               <label for="illbfryear">No</label>
            </div>
         </div>
      @endif
    <!-- Ends  -->
    <!-- Other Than FHO product PED questions  -->
     @foreach($pedlist as $key => $ped)
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10" style="padding:0">
            <div class="labelleft">
              <a> <p>{{ $ped['questiontext'] }} </p>
              </a>
            </div> 
            </div>
            <div class="col-sm-2" style="padding:15px">
            <div class="radiobutton">
              <input type="radio" name="ped[{{ $ped['id'] }}]" class="preexisting-illness" id="{{ $ped['id'].'-yes' }}" value="1" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator =""/>
              <label for="{{ $ped['id'].'-yes' }}" >Yes</label>
            </div>
            <div class="radiobutton">
              <input type="radio" name="ped[{{  $ped['id'] }}]" id="{{ $ped['id'].'-no' }}" value="0" class="preexisting-illness" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator ="" checked="checked"/>
              <label for="{{ $ped['id'].'-no' }}">No</label>
            </div>
            </div>
          </div>  
          <input type="hidden" name="{{ $ped['id'] }}_code"
           value="{{ $ped['code'] }}">
        @endforeach 
<!-- Ends  -->
 <!-- Social Status  -->
 <br><br>
         <div class="col-sm-10">
            <p>Does any of the person(s) to be insured belong to the special categories of <span class="blueitalictext">BPL</span>, <span class="blueitalictext">Differently abled</span> or working in an <span class="blueitalictext">Unorganized or Informal Sector</span>?</p>
         </div>
         <div class="col-sm-2">
            <div class="radiobutton">
               <input type="radio" name="social_status" class="socialstatus" id="social-status" value="1" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}"/>
               <label for="social-status" >Yes</label>
            </div>
            <div class="radiobutton">
               <input type="radio" name="social_status" id="socialstatuss" value="0" class="socialstatus" data-name= "Social Status" data-key ="Social Status" data-operator ="{{$i}}" checked="checked"/>
               <label for="socialstatuss">No</label>
            </div>
         </div>
         <div  id="socialstatus_bpl" name="socialstatus_bpl" style="display: none;">
            <div class="col-sm-10 pad10bottom">
               <strong>Please select the categories that applies to any of the person(s) to be insured</strong>
            </div>
            <div class="sublist">
               <div class="col-sm-10">
                  <p>Working in an Unorganized Sector?</p>
               </div>
               <div class="col-sm-2">    
                  <input type="checkbox" name="unorganized-sector" class="unorganized" id="unorganized-sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "UnOrganized Sector" data-key ="UnOrganized Sector" data-operator ="{{$i}}"/>
               </div>
               <div class="col-sm-10">
                  <p>Working in an Informal sector</p>
               </div>
               <div class="col-sm-2">
                  <input type="checkbox" name="informal-sector" class="informalsector" id="informal_sector" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Informal Sector" data-key ="Informal Sector" data-operator ="{{$i}}"/>
               </div>
               <div class="col-sm-10">
                  <p>Below Poverty Line (BPL)</p>
               </div>
               <div class="col-sm-2">
                  <input type="checkbox" name="below-poverty" class="belowpoverty" id="below_poverty" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Below Poverty" data-key ="Below Poverty" data-operator ="{{$i}}"/>
               </div>
               <div class="col-sm-10">
                  <p>Differently abled</p>
               </div>
               <div class="col-sm-2">
                  <input type="checkbox" name="handicaped" class="handicaped" id="handicaped" @if("input[type=checkbox]:checked") value="1" @else value="0" @endif data-name= "Handicaped Disabled" data-key ="Handicaped Disabled" data-operator ="{{$i}}"/>
               </div>
            </div>
         </div>

<!-- Ends -->
         </div>
      </div>

    </div>
  </div>
</div>
