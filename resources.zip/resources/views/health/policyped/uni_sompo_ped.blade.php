<?php $pedlist = [

        ["seq"=> "1",
             "code"=> "1", 
             "id"=> "hospitalized", 
             "questiontext"=> "Have any of the person(s) to be insured been Hospitalized as an In-Patient in the last 4 years ?",
             "reponsetype"=> "YESNO"],
            
            ["seq"=> "2",
             "code"=> "1",
             "id"=> "illness",
             "questiontext"=> "Have any of the person(s) to be insured suffered from or currently suffering from any disease, illness, disability, injury, accident or any other medical condition?",
             "reponsetype"=> "YESNO"],
            
            ["seq"=> "3",            
             "code"=> "1",           
             "id"=> "medication",            
             "questiontext"=> "Have any of the person(s) to be insured taken any medication for more than 2 weeks in last 5 years?",         
             "reponsetype"=> "YESNO"],

             ["seq"=> "4",            
             "code"=> "1",           
             "id"=> "comorbidity",            
             "questiontext"=> "Is any of the person(s) to be insured having one or more additional diseases or disorders co-occurring with a primary disease or disorder (Comorbidity)?",         
             "reponsetype"=> "YESNO"],
         ];
?>
<div class="tab-pane" id="healthhistory">
  <div class="row">
      <h6 class='info-text'>Enter the Health Details!</h6>
      <div class="container tabdata">
          <div class="col-sm-12" style="padding:0">
              <div class="card proposalcard">
                @foreach($pedlist as $key => $ped)
                  
          <div class="col-sm-12" style="padding:0">
            <div class="col-sm-10" style="padding:0">
            <div class="labelleft">
              <a> <p>{{ $ped['questiontext'] }} </p>
              </a>
            </div> 
            </div>
            <div class="col-sm-2" style="padding:15px">
            <div class="radiobutton">
              <input type="radio" name="ped[{{ $ped['id'] }}]" class="preexisting-illness" id="{{ $ped['id'].'-yes' }}" value="1" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator =""/>
              <label for="{{ $ped['id'].'-yes' }}" >Yes</label>
            </div>
            <div class="radiobutton">
              <input type="radio" name="ped[{{  $ped['id'] }}]" id="{{ $ped['id'].'-no' }}" value="0" class="preexisting-illness" data-name= "{{ ucwords($ped['id']) }}" data-key ="{{ ucwords($ped['id']) }}" data-operator ="" checked="checked"/>
              <label for="{{ $ped['id'].'-no' }}">No</label>
            </div>
            </div>
          </div>  
          <input type="hidden" name="{{ $ped['id'] }}_code"
           value="{{ $ped['code'] }}">
        @endforeach 

        </div>
      </div>
    </div>
  </div>
</div>
