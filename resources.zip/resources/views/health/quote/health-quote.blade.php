@include('health.layouts.inn-hdr')
<div class="cd-section" id="carwizard">
<meta name="csrf-token" content="{{ csrf_token() }}">
   <div class="col-sm-12 removepaddingsmallscreen">
      <!--      Wizard container        -->
      <div class="wizard-container">
         <div class="col-sm-4">
         <!-- User details Update starts-->
            @include('health.quote.user_details_preview')
         
         <!-- Sum Insured & Coverage type Update Starts -->
            @include('health.quote.plan_update')

         <div class="col-sm-4">
            <div class="card card-form-horizontal">
               <div class="row accordion">
                  <div class="col-md-12">
                     <h6> Default Inclusions in your Insurance Policy </h6>
                     <div class="row">
                        <div class="col-md-12">
                           <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="false">
                              <div class="panel panel-default">
                                 <div class="panel-heading" role="tab">
                                    <h4 class="panel-title pull-left">
                                    <a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne1">In-Patient Hospitalization</a></h4>
                                    <div class="included"> 
                                       <img class="checkmark" src="{{asset('image/check.png')}}">
                                    </div>
                                 </div>
                                 <div id="collapseOne1" class="panel-collapse collapse">
                                    <div class="panel-body">This basic component takes care of the In-patient hospitalisation expenses such as, room rent, surgeon's charges, anesthesia, etc</div>
                                 </div>
                              </div>
                              <div class="panel panel-default">
                                 <div class="panel-heading" role="tab">
                                    <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne2">Day Care Procedures</a></h4>
                                   <div class="included"> 
                                       <img class="checkmark" src="{{asset('image/check.png')}}">
                                    </div>
                                 </div>
                                 <div id="collapseOne2" class="panel-collapse collapse">
                                    <div class="panel-body">This is a basic inclusion in all policies and pays for surgical procedures which can be done in a day's time such as cataract, etc</div>
                                 </div>
                              </div>
                              <div class="panel panel-default">
                                 <div class="panel-heading" role="tab">
                                    <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne3">Pre & Post Hospitalization</a></h4>
                                    <div class="included"> 
                                       <img class="checkmark" src="{{asset('image/check.png')}}">
                                    </div>
                                 </div>
                                 <div id="collapseOne3" class="panel-collapse collapse">
                                    <div class="panel-body">The expenses for medical check-ups or tests before and after your admission in a hospital is paid due to the presence of this component in your policy</div>
                                 </div>
                              </div>
                              <div class="panel panel-default">
                                 <div class="panel-heading" role="tab">
                                    <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne5">Lifelong Renewals</a></h4>
                                    <div class="included"> 
                                       <img class="checkmark" src="{{asset('image/check.png')}}">
                                    </div>
                                 </div>
                                 <div id="collapseOne5" class="panel-collapse collapse">
                                    <div class="panel-body">All the health insurance plans can be renewed life-long. Your policy will continue to cover you as long as your keep renewing it</div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                   <!-- Covers List Starts -->
                  <div class="col-md-12">
                     <div id="cover_box">
                     </div>
                  </div>
                   
                  <!--  add covers blade here -->
                  </div>
                   <!-- Covers List Ends -->
               </div>
            </div>
         </div>

         <!--Quote Response Starts  -->
         <div class="col-sm-4">
            <div class="insurance-list" id="quote_ctnr_box">
               <h5 class="card-title price">-- Loading Quotes --  </h5> 
            </div>
            <div id="no_quotes">
               <p id="no_quote_text" class="hidden">
                  We did not get a quote from the below insurers
               </p>
            </div>
            
            <div id="error_message" class="hide"></div>
                <div id="rsgi_quote_ctnr_box"></div> 
                <div id="hdfc_quote_ctnr_box"></div> 
                <div id="star_quote_ctnr_box"></div> 
                <div id="religare_quote_ctnr_box"></div> 
                <div id="reliance_quote_ctnr_box"></div> 
                <div id="rsgi_loader"></div>
                <div id="hdfc_loader"></div>
                <div id="star_loader"></div>
                <div id="reli_loader"></div>
                <div id="reliance_loader"></div>
             <div class="row" id='email_quotes_div'>
                     <button onclick='jQuery("#email").modal();' type="button" class="btn btn-info btn-simple btn-xs pull-left" data-toggle="modal" data-target="#email_quote_modal">Email Quotes</button>
                     <!-- <button type="button" class="btn btn-info btn-simple btn-xs pull-right">Load More Quotes</button> -->
                  </div>     
         </div>
         <!--Quote Response Ends  -->

      </div>
      <!-- wizard container -->
   </div>
</div>
         
  
</div>
<div> &nbsp; </div>
<input type="hidden" id="session_key" value="{{$attributes['session_id']}}" />
<input type="hidden" id="trans_code" value="{{$attributes['trans_code']}}" />
  <!-- Modal for email quote starts below -->
<div class="modal fade" id="email_quote_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog">
            <form id="email_quote_form" method="POST">
              <input type="hidden" name="quote_form_url" id="quote_form_url" value="{{URL::route('send-quote-mail')}}">
               <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
                      <h4 class="modal-title" id="QuoteLabel"> E-mail Quotes</h4>
                  </div>
                     <div class="modal-body">    
                        {{ csrf_field() }}
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                           <input type="text" id="email_quote_name" name="email_quote_name" class="form-control" placeholder="Your name">
                        </div>
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                           <input type="email" id="email_quote" name="email_quote" class="form-control" placeholder="your@email.com">
                        </div>
                        <br />
                        <span id="quote_email_message"></span>
                     </div>
                     <div class="modal-footer">
                        <button type="button" id="quote_email_submit" value="sub" name="sub" class="btn btn-primary" ><i class="fa fa-share"></i> Send </button>
                     </div>
               </div>
            </form>
         </div>
      </div>
<!-- Modal for email quote ends abow -->
@include('health.layouts.inn-ftr')
<script type="text/javascript" src="{{ URL::asset('js/health/healthquote.js') }}"></script>
<script type="text/javascript" language="JavaScript"> $( document ).ready(function() { load_health_quotes();  }); </script>

<script type="text/javascript" language="JavaScript"> $( document ).ready(function() { load_health_covers();  }); </script>

