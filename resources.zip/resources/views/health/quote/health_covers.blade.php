<div class="row">
    <input type="hidden" name="userid" value="{{ $attributes['id'] }}">
    <input type="hidden" name="sum_insured" value="{{ $attributes['sum_insured'] }}">
    <input type="hidden" name="plan_type" value="{{ $attributes['plan_type'] }}"> 
    @if($attributes['product_type'] == 'S') 
    <!-- Super top up covers list -->
    @else 
        <h6> Select the Must Haves for you! </h6>
        <?php $coverId = []; $hcover =[];
            //covers from Table 
            $temp_cont = 0; $carry = array();
            $response = $data['response'];
            $h_covers = $data['h_covers'];
            $response_count = count($response);
            foreach ($h_covers as $cvr_value) {
                $hcover = $cvr_value->cover_id;
                $carry[$hcover] = 0; 
                // Last decimal responce covers
                foreach($response as $value) { 
                    if(!empty($value->covers)){
                        $covers_list = json_decode($value->covers);
                        if(!empty($covers_list)){
                            foreach($covers_list as $cover) { 
                                if($hcover === $cover->coverId){ $temp_cont++; }
                            }
                        }
                    }
                }
                $carry[$hcover] =  $temp_cont;
                $temp_cont = 0;
            }
        ?>
        <?php  $temp_mem_count = count($h_covers); $checks = explode('|',$attributes['cover_id']); ?>
            @for($i = 0; $i < $temp_mem_count ; $i++)
                <div class="col-lg-6">
                    <label class="card-raised checkboxcard" data-toggle="" data-placement="top" title="" data-container="body" data-original-title="{{ $h_covers[$i]['description'] }}">
                        <input class="filter_quote" id="filter_quote" name="optionsCheckboxes" type="checkbox" value="{{ $h_covers[$i]['cover_id'] }}" @if(in_array($h_covers[$i]['cover_id'],$checks)) checked @endif onclick="filter_quote()" ><span class="checkbox-material" ><span class="check"></span></span> {{ $h_covers[$i]['cover_name'] }}
                    </label>
                </div>
            @endfor
    @endif     
</div>
<script type="text/javascript" src="{{ URL::asset('js/health/healthquote.js') }}"></script>
