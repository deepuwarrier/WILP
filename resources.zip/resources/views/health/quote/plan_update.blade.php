<form  action="{{ URL::route('health.load_policy_page',$attributes['trans_code']) }}" method="post" id="choicedata">

          <input type="hidden" name="_token" value="{{ csrf_token() }}">
          <input type="hidden" name="update_cust_choice" value="1">
          <input type="hidden" name="trans_code" value = {{$attributes['trans_code']}}>
         <?php $memcount = count(explode("|", $attributes['members_list']));?> 
           <input type="hidden" name="temp_mem" value="{{$memcount}}">
           
          
            <div class="card" id="confirm_update">
               <div class="col-xs-12">
                  <div class="titleinput">
                     <h6>Some Very Important Choices to make!</h6>
                  </div>
               </div>

               <!-- PRODUCT TYPE -->
               <div class="col-xs-4" style="padding:0 0 10px 10px">
                  <div class="labelleft">
                     <a href="#">
                        <p data-toggle="tooltip" data-placement="top" onclick='jQuery("#policyType").modal();'title="Click to know the different Between Family Floater and Individual Cover">Product Type</p>
                     </a>
                  </div>
               </div>

               <div class="col-xs-8" style="padding:0 10px 10px 0">
                  <div class="labelright" style="padding: 7px">
                     <div class="radiobutton">
                        <input type="radio" @if($attributes['product_type'] == 'B') checked="true"  @endif value="B" name="product_type" id="basic"/>
                        <label for="basic">Basic</label>
                     </div>
                     <div class="radiobutton">
                        <input type="radio" @if($attributes['product_type'] == 'S') checked="true"  @endif  value="S" name="product_type" id="super_top_up"/>
                        <label for="super_top_up">Super Top Up</label>
                     </div>
                  </div>
               </div>

               <!-- POLICY TYPE -->
               <div class="col-xs-4" style="padding:0 0 10px 10px">
                  <div class="labelleft">
                     <a href="#">
                        <p data-toggle="tooltip" data-placement="top" onclick='jQuery("#policyType").modal();'title="Click to know the different Between Family Floater and Individual Cover">Policy Type</p>
                     </a>
                  </div>
               </div>

               <div class="col-xs-8" style="padding:0 10px 10px 0">
                  <div class="labelright" style="padding: 7px">
                     <div class="radiobutton">
                        <input type="radio" @if($attributes['plan_type'] == 'FF') checked="true" @endif value="FF" name="plan_type" id="radio_1" @if($memcount == '1') disabled @endif class="floater" />
                        <label for="radio_1">Family Floater</label>
                     </div>
                     <div class="radiobutton">
                        <input type="radio"  @if($attributes['plan_type'] == 'INDV') checked="true"  @endif value="INDV" name="plan_type" id="radio_2" class="indiv"/>
                        <label for="radio_2">Individual</label>
                     </div>
                  </div>
               </div>

               <!-- Tenure slab for RSGI UAT test -->
               <div class="col-xs-4" style="padding:0 0 10px 10px">
                  <div class="labelleft">
                     <a href="#">
                        <p data-toggle="tooltip" data-placement="top">Tenure</p>
                     </a>
                  </div>
               </div>
               <div class="col-xs-8" style="padding:0 10px 10px 0">
                  <div class="labelright" style="padding: 7px">
                     <div class="radiobutton">
                        <input type="radio" @if($attributes['tenure'] == '1') checked="true" @endif value="1" name="tenure" id="radio_11" class="tenure1"/>
                        <label for="radio_11">1 Year</label>
                     </div>
                     <div class="radiobutton">
                        <input type="radio"  @if($attributes['tenure'] == '2') checked="true"  @endif value="2" name="tenure" id="radio_22" class="tenure2"/>
                        <label for="radio_22">2 Years</label>
                     </div>
                     <div class="radiobutton">
                        <input type="radio"  @if($attributes['tenure'] == '3') checked="true"  @endif value="3" name="tenure" id="radio_33" class="tenure3"/>
                        <label for="radio_33">3 Years</label>
                     </div>

                  </div>
               </div>
               <!-- End Tenure section  -->

               <span id="basic-container">
                  <div class="col-xs-4" style="padding:0 0 10px 10px">
                     <div class="labelleft">
                        <a href="#"> <p data-toggle="tooltip" data-placement="top">Sum Insured</p></a>
                     </div>
                  </div>
                  <div class="col-xs-8" style="padding:0 10px 10px 0">
                     <div class="labelright">
                        <div class="col-xs-4 ncblabel">
                           <span>Sum Insured: </span>
                        </div>
                        <div class="col-xs-4 ncbvalue">
                           <div class="form-group">
                              <select name="sum_insured" id="sum_insured" class="form-control valid" aria-invalid="false" data-ovalue="">
                              <option value="" disabled="">Choose your option</option>
                              @foreach($attributes['sum_insured_list'] as $sum_insured)
                              <option <?php if($attributes['sum_insured'] == $sum_insured['insta_si']) echo 'selected="selected"'; ?>  value="{{$sum_insured['insta_si']}}"> &#8377; 
                                  {{$sum_insured['insta_si']}}
                              </option>
                              @endforeach
                              </select><span class="material-input"></span>
                           </div>
                        </div>
                     </div>
                  </div>
               </span>

               <span id="super-top" style="display: {{($attributes['product_type'] == 'S') ? 'block;' : 'none;' }}">
               <div class="col-xs-4" style="padding:0 0 10px 10px">
                  <div class="labelleft">
                     <a href="#">
                        <p data-toggle="tooltip" data-placement="top">Deductibles</p>
                     </a>
                  </div>
               </div>

               <div class="col-xs-8" style="padding:0 10px 10px 0">
                  <div class="labelright">
                        <div class="col-xs-4 ncblabel">
                           <span>Deductibles: </span>
                        </div>
                        <div class="col-xs-4 ncbvalue">
                           <div class="form-group">
                              <select name="deductables" id="deductables" class="form-control valid" aria-invalid="false" data-ovalue="">
                              <option value="" disabled="">Choose your option</option>
                                 @foreach($attributes['deductible_list'] as $deductibles)
                                 <option <?php if(isset($attributes['deductables']) && $attributes['deductables'] == $deductibles['deductable']) echo 'selected="selected"'; ?>  value="{{$deductibles['deductable']}}"> &#8377; {{$deductibles['deductable']}}</option>
                                 @endforeach
                              </select><span class="material-input"></span>
                           </div>
                        </div>
                     </div>
               </div>
               </span>

               <div class="col-xs-12">
                  <div class="titleinput">
                     <button type="button" id="choiceupdate" class="btn btn-primary btn-xs pull-right">Update Quotes</button>
                  </div>
               </div>
            </div>
         </form>  
        <div class="card" style="background-color: #b8e2eb;">
         <img class="healthimage" src="{{asset('image/healthanim.gif')}}" alt="Health Insurance">
      </div> 
      </div>