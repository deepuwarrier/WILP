@if(!empty($response))
    @foreach($response as $index => $res)
      @if(!empty($res))
      <div class="row card customcard quote-box"  data-listing-price="{{$res->get_totalPremium()}}" data-insurer-id="{{$res->get_product_id()}}">
          <div class="col-sm-4 logobox">
            <img src="{{URL::to('/')}}/image/logos/{{$res->get_insurer_name()}}_logo.png">
          </div>
          <div class="row col-sm-8 logoright">
            <div class="col-md-6">
              <h5 class="card-title price">&#8377; {{round($res->get_totalPremium())}}</h5>
              <div style="padding-bottom: 5px">
                <span class="label label-default extrapanelitem pad">SI: &#8377; {{ $res->get_sum_insured() }}</span>
              </div>    
            </div>
            <div class="col-md-6 buybutton hvr-grow">
              <form name="policy_submit" method="get" action="{{URL::to('health-insurance/load_proposal_page')}}">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="trans_code" value="{{$res->get_trans_code()}}"/>
                <input type="hidden" name="product_id" value="{{$res->get_product_id()}}"/>
                <input type="hidden" name="product_name" value="{{$res->get_product_name()}}"/>
                <input type="hidden" name="product_plan" value="{{$res->get_product_plan()}}"/>
                <input type="hidden" name="insurer_name" value="{{$res->get_insurer_name()}}"/>
                <input type="hidden" name="sum_insured" value="{{$res->get_sum_insured()}}"/>
                <input type="hidden" name="deductible_amount" value="{{$res->get_deductible_amount()}}"/>
                <input type="hidden" name="sum_insuredid" value="{{$res->get_sumInsuredId()}}"/>
                <input type="hidden" name="scheme_id" value="{{$res->get_schemeId()}}"/>
                <input type="hidden" name="plan_id" value="{{$res->get_planId()}}"/>
                <input type="hidden" name="plan_code" value="{{$res->get_planCode()}}"/>
                <input type="hidden" name="premium" value="{{$res->get_premium()}}"/>
                <input type="hidden" name="serviceTax" value="{{$res->get_serviceTax()}}"/>
                <input type="hidden" name="total_premium" value="{{$res->get_totalPremium()}}"/>
                <input type="hidden" name="rsgi_quote_id" value="{{$res->get_rsgi_QuoteId()}}"/>
                <button type="submit" class="btn btn-success btn-md scrolltop" data-focus="idv"  data-focus="idv">Buy Now</button>   
              </form>
            </div>
            <div class="row">
              <div class="col-sm-12">
                <div class="content extrapanel">
                   @if($res->get_insurer_name() == 'religare')
                    <span class="extrapanelitem" style="color: #E91E63">EMI available for this plan - </span>
                  @endif
                  @if(!empty($res->get_product_type()) && $res->get_product_type() === 'S')
                    <input type="hidden" name="product_type" id="product_type" value="{{$res->get_product_type()}}">
                    <span class="extrapanelitem" style="color: #E91E63">Deductible &#8377; {{$res->get_deductible_amount()}}</span>
                  @endif
                  <span class="extrapanelitem" style="font-weight: 500"> {{$res->get_product_name()}} </span> 

                  <!-- Package Info -->
            <a href="#" id="h_benefits{{$index}}" name="h_benefits{{$index}}" class="h_benefits"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#BenefitModal").modal();' title="Package Info">stars</i></a>
            <input type="hidden" name="totalPremium" id="totalPremium" value="{{$res->get_totalPremium()}}">
            <input type="hidden" name="servicetax" id="servicetax" value="{{$res->get_serviceTax()}}">
            <input type="hidden" name="sum_insured" id="sum_insured" value="{{ $res->get_sum_insured() }}">
            <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{ $res->get_insurer_name() }}_logo.png">
            <input type="hidden" name="product_id" id="product_id" value="{{$res->get_product_id()}}">
            <input type="hidden" name="product_name" id="product_name" value="{{$res->get_product_name()}}">
            <input type="hidden" name="basepremium" id="basepremium" value="{{$res->get_premium()}}">
            <input type="hidden" name="h_benifitUrl" id="h_benifitUrl" value="{{route('health.h_benefit_req')}}"> 
                  <!-- Premium breakup  -->
            <a href="#" id="h_breakup{{$index}}" name="h_breakup{{$index}}" class="h_breakup"><i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#premiumBreakup").modal();' title="Premium Breakup">description</i></a>
            <input type="hidden" name="totalPremium" id="totalPremium" value="{{round($res->get_totalPremium())}}">
            <input type="hidden" name="servicetax" id="servicetax" value="{{$res->get_serviceTax()}}">
            <input type="hidden" name="sum_insured" id="sum_insured" value="{{ $res->get_sum_insured() }}">
            <input type="hidden" name="img_url" id="img_url" value="{{URL::to('/')}}/image/logos/{{ $res->get_insurer_name() }}_logo.png">
            <input type="hidden" name="product_id" id="product_id" value="{{$res->get_product_id()}}">
            <input type="hidden" name="product_name" id="product_name" value="{{$res->get_product_name()}}">
            <input type="hidden" name="basepremium" id="basepremium" value="{{$res->get_premium()}}">
            <input type="hidden" name="h_breakupUrl" id="h_breakupUrl" value="{{route('healthbr')}}"> 
                </div>
              </div>
            </div>
        </div>
      </div>
      @endif
    @endforeach
  @endif

  @if(isset($products) && !empty($products))
    @foreach($products as $index => $product)
      @include('health.quote.no_quote')
    @endforeach
  @endif
  <!-- Package Info -->
  <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits">
  </div>
  <!--  Premium breakup info  -->
  <div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup">
  </div>
  <script src="{{ URL::asset('js/health/quotation_page.js') }}"></script>
