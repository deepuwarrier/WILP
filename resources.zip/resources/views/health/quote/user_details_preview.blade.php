<?php 
       $insurer_age = isset($data['userdata']['age_list']) ? $data['userdata']['age_list'] : explode("|", $attributes['age_list']) ;  
       $adult_age =''; $child_age ='';
       
       foreach($insurer_age as $memage)
       {
         if($memage == '3m'){  $child_age .= '1-3 Months,'; }
         elseif($memage == '10m'){ $child_age .= '3-12 Months,'; }
         else{  if($memage <= 21){ $child_age .=  $memage.'Years,'; }
                else{ $adult_age .=  $memage.'Years,'; } }
       }
?> 
     <div class="card card-form-horizontal" id="detail">
               <div class="content">
                  <div class="row">
                     <div class="col-xs-6 pull-right">
                        <a href="{{ route('health.healthhome') }}"><button type="button" class="btn btn-info btn-xs pull-right">Change</button></a>
                     </div>
                     <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Insurance Policy For :</h6>
                     </div>
                  </div>

                   <input type="hidden" class="ajaxRequiredData" name="trans_code" id="trans_code" value="{{isset($data['userdata']['trans_code']) ? $data['userdata']['trans_code'] : $attributes['trans_code']}}"/>

                  <div class="row content" style="text-align: left">
                     <p><span class="label label-default base_detail">Members Age :</span>
                     <span class="label label-default base_detail">{{trim($adult_age.''.$child_age, ',')}}

                     </span></p>

                  </div>
               </div>
            </div>
