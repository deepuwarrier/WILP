@include('health.layouts.inn-hdr')
<div class="wizard-container addmargin">
    <div class="row"> 
    @if($status)
    <div class="premiumconfirmation">
    <div class="card">
        <div class="content content-success" style="border-bottom-left-radius: 0px;border-bottom-right-radius: 0px">
            <h3 class="category-social whitefont">
                 <i class="fa fa-newspaper-o"></i> Congratulations!!
              </h3>
            <h4 class="card-title">
                 <a>You payment has been processed Successfully!</a>
              </h4>
            <p class="card-description">
                Thank you for your patronage.
            </p>
        </div>
        <div class="content">
            <h4 class="card-title">
              <div class="logobox">
                <img src="{{URL::to('/')}}/image/logos/{{$logo}}_logo.png" alt="Insurer Logo" width="150" height="150">
              </div>
                <a>Your policy will hit your inbox shortly.</a>
            </h4>
            <h5 class="category-social">
                 <i class="fa fa-newspaper-o"></i>Please note your policy number!
              </h5>
            <p></p>
                    @if(!empty($udata['1']))
                    <h2>{{ $udata[1] }}</h2>
                    @endif
                    <p>
                    @if(isset($udata['download_link']))
                        <a href="{{ $udata['download_link'] }}" target="_target" class='btn btn-primary'>Download Policy</a>
                    @endif
                </p>
            <div class="content hidden">
                <form class="nl">
                    <button type="button" class="nl__btn btn-xs">Email This!</button>
                    <input placeholder="your@email.com" class="nl__input aria-hidden" type="text">
                </form>
            </div>
            <div class="content">
                <p>Your policy will be sent to your email id shortly by the insurance company</p>
                <p>Meanwhile, you will soon receive a welcome email from us as well!</p>
            </div>
        </div>
    </div>
    </div>
     @else
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h1 class="card-title" style="color: #00669C;">We tried our best!</h1>
         <h4 class="card-title" style="color: #00669C;">But somehow, we could not get you across! </h4>
         <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5>
           <h5>Your Transaction Reference Number : <strong style="color: #00669C;">{{ $udata['2'] }}</strong></h5>
           <h5> Transaction Status -  {{ $udata['6'] }} </h5> 
         <a href="/health-insurance"><button type="submit" class="btn btn-success">Home</button></a>
      </div>
   </div>
   @endif
    </div>
</div>
@include('health.layouts.inn-ftr')