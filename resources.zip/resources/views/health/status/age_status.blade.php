<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
   
      <img src="{{URL::to('/')}}/image/logos/{{strtolower($data['insurer_id'])}}_logo.png" width="150" height="150">

      	@if(isset($data['insurer_id']) && $data['insurer_id'] == 'rsgi')
      	<table style="width: 100%;">
	      	@if(isset($data['bmi_check']) && $data['bmi_check'] == 'true')
	      	<tr><td>BMI of {{$data['member'][0]['name']}} based on height({{$data['member'][0]['height']}}) and weight({{$data['member'][0]['weight']}}) is {{$data['member'][0]['bmi']}}</td></tr>
	      	@endif

	      	@if(isset($data['ped_check']) && $data['ped_check'] == 'true')
	      	<tr><td> {{ $data['ped_msg']}} </td></tr>
	      	@endif

	      	@if(isset($data['age_check']) && $data['age_check'] == 'true')
	      	<tr><td> {{ $data['age_msg']}} <tr><td>
	      	@endif

	      	@if(isset($data['si_check']) && $data['si_check'] == 'true')
	      	<tr><td> {{ $data['si_msg']}} <tr><td>
	      	@endif
	     </table>
	    @endif

      @if(isset($data['insurer_id']) && $data['insurer_id'] == 'religare')
        <table style="width: 100%;">
          @if(isset($data['ped_check']) && $data['ped_check'] == 'true')
          <tr><td> {{ $data['ped_msg']}} </td></tr>
          @endif

          @if(isset($data['age_check']) && $data['age_check'] == 'true')
          <tr><td> {{ $data['age_msg']}} <tr><td>
          @endif

          @if(isset($data['si_check']) && $data['si_check'] == 'true')
          <tr><td> {{ $data['si_msg']}} <tr><td>
          @endif
       </table>
      @endif


       @if(isset($data['insurer_id']) && $data['insurer_id'] == 'hdfc')
         <table style="width: 100%;">
          @if(isset($data['bmi_check']) && $data['bmi_check'] == 'true')
          <tr><td>BMI of {{$data['member'][0]['name']}} based on height({{$data['member'][0]['height']}}) and weight({{$data['member'][0]['weight']}}) is {{$data['member'][0]['bmi']}}</td></tr>
          @endif
          
            @if(isset($data['ped_check']) && $data['ped_check'] == 'true')
            <tr><td> {{ $data['ped_msg']}} </td></tr>
            @endif

            @if(isset($data['age_check']) && $data['age_check'] == 'true')
            <tr><td> {{ $data['age_msg']}} <tr><td>
            @endif
        </table>
       @endif

       @if(isset($data['insurer_id']) && $data['insurer_id'] == 'star')
         <table style="width: 100%;">
            @if(isset($data['age_check']) && $data['age_check'] == 'true')
            <tr><td> {{ $data['age_msg']}} <tr><td>
            @endif
            @if(isset($data['illness']) && $data['illness'] == 'true')
            <tr><td> {{ $data['illness_msg']}} <tr><td>
            @endif
        </table>
       @endif

       @if(isset($data['insurer_id']) && $data['insurer_id'] == 'reliance')
         <table style="width: 100%;">
            @if(isset($data['age_check']) && $data['age_check'] == 'true')
            <tr><td> {{ $data['age_msg']}} <tr><td>
            @endif
            @if(isset($data['illness']) && $data['illness'] == 'true')
            <tr><td> {{ $data['illness_msg']}} <tr><td>
            @endif
        </table>
       @endif

      <p>Your policy is subject to medical evaluation. {{ strtoupper($data['insurer_id']) }} Health Insurance team will contact you for further processing.
          <br/>You can Proceed to online payment, but policy may be issued post clearance of medical test.</p>
      <button type="button" class="btn btn-default btn-primary btn-xs" data-href="#insured" id ="bmi_change_btn">Change</button>
                <button type="button" class="btn btn-info btn-success btn-xs" name="age_status_proceed" id="age_status_proceed">Proceed</button>     

   </div>
</div>
</div>
</div>