<div class="wizard-container paymentcontainer">
<div class="col-sm-12">
<div class="card">
   <div class="content content-danger">
      <h5 class="category-social">
         <i class="fa fa-newspaper-o"></i> Oh ohh!
      </h5>
      <h4 class="card-title">
         <a>Looks like we are facing a temporary issue while trying to contact the Insurance Company :-(</a>
      </h4>
      <p><b>But do not worry. We will call you shortly to help complete your policy issuance</b></p>
      <p><h7><a href="">Try Again</a></h7></p>
   </div>
   <h5 style="font-size: 13px">Want to talk to us? Call us right now : <b>+91 7899-000-333</b></h5>
   </div>
</div>
</div>