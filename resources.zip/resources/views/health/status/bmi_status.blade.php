<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <img src="{{URL::to('/')}}/image/logos/{{$data['insurer_id']}}_logo.png" width="150" height="150">
      @if(isset($data['bmi_check'])) 
      <div id="medical-chkup">
                <p>BMI of {{$data['member'][0]['name']}} based on height({{$data['member'][0]['height']}}) and weight({{$data['member'][0]['weight']}}) is {{$data['member'][0]['bmi']}}</p>
                <p>{{$data['msg']}}</p>
                <button type="button" class="btn btn-default btn-primary btn-xs" data-href="#insured" id ="bmi_change_btn">Change</button>
                <button type="button" class="btn btn-info btn-success btn-xs" name="age_status_proceed" id="age_status_proceed">Proceed</button>
            </div> 
      @endif       
   </div>
</div>
</div>
</div>