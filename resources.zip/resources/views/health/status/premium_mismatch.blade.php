<div class="wizard-container paymentcontainer">
<div class="col-sm-6">
   <div class="card premiumconfirmation">
      <div class="content content-info">
         <h5 class="category-social">
            <i class="fa fa-newspaper-o"></i> All is good!
         </h5>
         <h4 class="card-title">
            <a>There seems to be a small change in your premium!</a>
         </h4>
      </div>
      <div class="row customcard" style="min-height:130px">
         <div class="col-xs-12 logobox min">
            <img src="{{ URL::asset('image/travel/insurer_logo/')}}/{{$request['companyId']}}.png">
         </div>
         <div class="col-xs-12">
            <h6>Premium Payable</h6>
            <h5 class="card-title" style="font-size:30px">&#8377; {{ $request['act_prem'] }}</h5>       
         </div>
      </div>
   </div>
</div>

<div class="col-sm-6 ">
   <div class="card premiumconfirmation">
      <div class="content content-success">
         <h5 class="category-social dark">
            <i class="fa fa-newspaper-o"></i>Proceed to the Payment Gateway!
         </h5>
         <button type="submit" class="btn btn-primary" id="re-submit">
            Make Payment
         </button>
          <p><h7><a id="review-again"  style="cursor:pointer">Review Again</a></h7></p>
         <p>Your payment will be collected directly by the insurance company</p>
         <p>Once the payment is successfull, all policy related documents will be sent to your email.</p>
      </div>
      <h5 style="font-size: 13px; padding: 5px;">Any last minute question? Call us right now : <b>+91 7899-000-333</b></h5>
   </div>
</div>
</div>
