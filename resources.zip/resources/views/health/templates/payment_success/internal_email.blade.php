<html>
    <head>
        <title>New Enquiry</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

      <style type="text/css">
        .panel-primary {
            border-color: #337ab7;
        }
        .panel {
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .table {
            margin-bottom: 20px;
            max-width: 100%;
            width: 100%;
        }
        .row {
            margin-left: -15px;
            margin-right: -15px;
        }
        .panel-heading {
            border-bottom: 1px solid transparent;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            padding: 10px 15px;
        }
        .panel-title {
            color: inherit;
            font-size: 16px;
            margin-bottom: 0;
            margin-top: 0;
        }
      </style>
    </head>
    <body>
        <p>A new policy has been applied with the following details</p>
       
          <?php 
        $members = count($proposal_form_data['dob']); 
        $mem = $proposal_form_data['relationshipId']; 
        ?> 
            <table class="table responsive" style="font-size: 12px;">
                <tr>
                <td>Plan Type:</td>
                @if($proposal_form_data['plan_type'] == 'FF')
                    <td>Family Floater</td>
                @else
                    <td>Individual</td>
                @endif
            </tr>
        </table>



        <h4>Proposer Details:</h4>
        <table class="table responsive" style="font-size: 12px;">
            <tr>
                <td>No. of Adults</td>
                <td>{{$proposal_form_data['adults']}}</td>
            </tr>
            <tr>
                <td>No. of Children</td>
                <td>{{$proposal_form_data['children']}}</td>
            </tr>
            @if ($members>=1)
                @for($i = 1; $i <= $members ; $i++)
                    <tr>
                        <td> <b>Person {{$i}} Details</b></td>
                        <td> </td>
                    </tr>
                    <tr>
                        <td> DOB </td>
                        <td>{{$proposal_form_data['dob'][$i-1]}}</td>
                    </tr>
                    <tr>
                        <td>Full Name </td>
                        <td> {{$proposal_form_data['firstname'][$i-1]}} {{$proposal_form_data['lastname'][$i-1]}} </td>
                    </tr>

                @if(isset($proposal_form_data['occupation']) && !empty($proposal_form_data['occupation']))
                    <tr>
                        <td>Occupation </td>
                        <td> {{ $proposal_form_data['occupation'][$i-1]}}</td>
                    </tr>
                @endif

         @endfor
            <tr><td>
                <b> Nominee Details </b></td><td> </td></tr>
                 @if($proposal_form_data['nomineename'] != 'null' || $proposal_form_data['nomineename'] != '')
                    <tr>
                        <td>Nominee Name </td>
                        <td> {{ $proposal_form_data['nomineename']}}</td>
                    </tr>
                @endif

                @if($proposal_form_data['nomineeage'] != 'null' || $proposal_form_data['nomineeage'] != '')
                    <tr>
                        <td>Nominee Age</td>
                        <td> {{ $proposal_form_data['nomineeage']}} Years</td>
                    </tr>
                @endif

                @if($proposal_form_data['nomineerel'] != 'null'  || $proposal_form_data['nomineerel'] != '')
                    <tr>
                        <td>Nominee Relation </td>
                        <td> {{ $proposal_form_data['nomineerel']}}</td>
                    </tr>
                @endif

                @if(isset($proposal_form_data['appointeename']) && ($proposal_form_data['appointeename'] != 'null'  || $proposal_form_data['appointeename'] != ''))
                    <tr>
                        <td>Appointee Name </td>
                        <td> {{ $proposal_form_data['appointeename']}}</td>
                    </tr>
                @endif

                @if(isset($proposal_form_data['appointeeage']) && ($proposal_form_data['appointeeage'] != 'null'  || $proposal_form_data['appointeeage'] != ''))
                    <tr>
                        <td>Appointee Age </td>
                        <td> {{ $proposal_form_data['appointeeage']}} Years</td>
                    </tr>
                @endif

                @if(isset($proposal_form_data['appointeerel']) && ($proposal_form_data['appointeerel'] != 'null'  || $proposal_form_data['appointeerel'] != ''))
                    <tr>
                        <td>Appointee Relation </td>
                        <td> {{ $proposal_form_data['appointeerel']}}</td>
                    </tr>
                @endif

               
            @endif  
            
        </table>


        <h4>Policy Details: </h4>    
        <table class="table responsive" style="font-size: 12px;">
            <tr>
                <td>Insurer Name  </td>
                <td>{{$proposal_form_data['insurerName']}}</td>
            </tr>
            <tr>
                <td>Policy Start Dtae  </td>
                <td>{{$proposal_form_data['p_start']}}</td>
            </tr>
            <tr>
                <td>Policy End Dtae  </td>
                <td>{{$proposal_form_data['p_ends']}}</td>
            </tr>
            <tr>
                <td>Sum Insured </td>
                <td>&#8377; {{$proposal_form_data['suminsured']['0']}}</td>
            </tr>
             <tr>
                <td>Goods & Service Tax (CGST + SGST)</td>
                <td>&#8377; {{($proposal_form_data['cgst']) +  ($proposal_form_data['sgst'])}} </td>
            </tr>
            <tr>
                <td>Total Premium </td>
                <td>&#8377; {{$proposal_form_data['totalPremium']}}</td>
            </tr>
            
        </table>

         <h4>Health Details:</h4> 
         <table class="table responsive" style="font-size: 12px;">
             @foreach($proposal_form_data['ped'] as $key=>$value)
            <tr>
                <td>{{ucwords($key)}}</td>
                <td>@if($value == '0')  No @else Yes @endif</td>
            </tr>
            @endforeach
           </table> 

        <h4>Communication Details:</h4>
        <table class="table responsive" style="font-size: 12px;">
            <tr> 
                <td>Address</td>
                <td>{{$proposal_form_data['houseno']}}, {{$proposal_form_data['street']}}, {{$proposal_form_data['locality']}},<br>
                {{$proposal_form_data['city']}}, {{$proposal_form_data['state']}},<br>
                PIN - {{ $proposal_form_data['cust_pincode']}}</td>
            </tr>
            <tr>
                <td>Email</td>
                <td>{{$proposal_form_data['email']}}</td>
            </tr>
            <tr>
                <td>Mobile</td>
                <td>{{$proposal_form_data['mobile']}}</td>
            </tr>
        </table>    
       
        </div>
    </body>
</html>
