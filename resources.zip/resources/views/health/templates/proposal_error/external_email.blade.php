<html>
<head>
	<title></title>
</head>
<body>
	<p>Dear {{$name}},</p>
	<p>
		Our apologies for you were not able to complete your payment. Looks like we are experiencing a technical problemwith the Payment Gateway of <insurance company> server.
	</p>
	<p>
		Our customer support team will contact you shortly in order to complete your policy issuance.
	</p>
	<p>
		Please ignore if you have already completed your payment.
	</p>
	<p>
		Meanwhile, if you have any queries, please feel free to contact us at the below coordinates.
	</p>
	<p>
		InstaInsure Customer Support Team: 
	</p>
	<p>
		Whatsapp/ Call/ SMS : +91 7899-000-333 |  Email : support@instainsure.com
	</p>
	<p>
		For escalations email deepak@instainsure.com
	</p>
	<p>
		InstaInsure.com is a digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI). IRDAI Composite License No: 431 Valid upto 01/09/2017. Insurance is the subject matter of solicitation.
	</p>
</body>
</html>
