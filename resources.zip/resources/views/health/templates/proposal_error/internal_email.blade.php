<html>
    <head>
        <title>New Enquiry</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

      <style type="text/css">
        .panel-primary {
            border-color: #337ab7;
        }
        .panel {
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .table {
            margin-bottom: 20px;
            max-width: 100%;
            width: 100%;
        }
        .row {
            margin-left: -15px;
            margin-right: -15px;
        }
        .panel-heading {
            border-bottom: 1px solid transparent;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            padding: 10px 15px;
        }
        .panel-title {
            color: inherit;
            font-size: 16px;
            margin-bottom: 0;
            margin-top: 0;
        }
      </style>
    </head>
    <body>
        <p>A new policy has been applied with the following details</p>
       
          <?php 
        $members = count($data_value['dob']); 
        $mem = $data_value['relationshipId']; 
        ?> 
            <table class="table responsive" style="font-size: 12px;">
                <tr>
                <td>Plan Type:</td>
                @if($data_value['plan_type'] == 'FF')
                    <td>Family Floater</td>
                @else
                    <td>Individual</td>
                @endif
            </tr>
        </table>



        <h4>Proposer Details:</h4>
        <table class="table responsive" style="font-size: 12px;">
            <tr>
                <td>No. of Adults</td>
                <td>{{$data_value['adults']}}</td>
            </tr>
            <tr>
                <td>No. of Children</td>
                <td>{{$data_value['children']}}</td>
            </tr>
            @if ($members>=1)
                @for($i = 1; $i <= $members ; $i++)
                    <tr>
                        <td> <b>Person {{$i}} Details</b></td>
                        <td> </td>
                    </tr>
                    <tr>
                        <td> DOB </td>
                        <td>{{$data_value['dob'][$i-1]}}</td>
                    </tr>
                    <tr>
                        <td>Full Name </td>
                        <td> {{$data_value['firstname'][$i-1]}} {{$data_value['lastname'][$i-1]}} </td>
                    </tr>

                @if(isset($data_value['occupation']) && !empty($data_value['occupation']))
                    <tr>
                        <td>Occupation </td>
                        <td> {{ $data_value['occupation'][$i-1]}}</td>
                    </tr>
                @endif

         @endfor
            <tr><td>
                <b> Nominee Details </b></td><td> </td></tr>
                 @if($data_value['nomineename'] != 'null' || $data_value['nomineename'] != '')
                    <tr>
                        <td>Nominee Name </td>
                        <td> {{ $data_value['nomineename']}}</td>
                    </tr>
                @endif

                @if($data_value['nomineeage'] != 'null' || $data_value['nomineeage'] != '')
                    <tr>
                        <td>Nominee Age</td>
                        <td> {{ $data_value['nomineeage']}} Years</td>
                    </tr>
                @endif

                @if($data_value['nomineerel'] != 'null'  || $data_value['nomineerel'] != '')
                    <tr>
                        <td>Nominee Relation </td>
                        <td> {{ $data_value['nomineerel']}}</td>
                    </tr>
                @endif

                @if(isset($data_value['appointeename']) && ($data_value['appointeename'] != 'null'  || $data_value['appointeename'] != ''))
                    <tr>
                        <td>Appointee Name </td>
                        <td> {{ $data_value['appointeename']}}</td>
                    </tr>
                @endif

                @if(isset($data_value['appointeeage']) && ($data_value['appointeeage'] != 'null'  || $data_value['appointeeage'] != ''))
                    <tr>
                        <td>Appointee Age </td>
                        <td> {{ $data_value['appointeeage']}} Years</td>
                    </tr>
                @endif

                @if(isset($data_value['appointeerel']) && ($data_value['appointeerel'] != 'null'  || $data_value['appointeerel'] != ''))
                    <tr>
                        <td>Appointee Relation </td>
                        <td> {{ $data_value['appointeerel']}}</td>
                    </tr>
                @endif

               
            @endif  
            
        </table>


        <h4>Policy Details: </h4>    
        <table class="table responsive" style="font-size: 12px;">
            <tr>
                <td>Insurer Name  </td>
                <td>{{$data_value['insurerName']}}</td>
            </tr>
            <tr>
                <td>Policy Start Dtae  </td>
                <td>{{$data_value['p_start']}}</td>
            </tr>
            <tr>
                <td>Policy End Dtae  </td>
                <td>{{$data_value['p_ends']}}</td>
            </tr>
            <tr>
                <td>Sum Insured </td>
                <td>&#8377; {{$data_value['suminsured']['0']}}</td>
            </tr>
             <tr>
                <td>Goods & Service Tax (CGST + SGST)</td>
                <td>&#8377; {{($data_value['cgst']) +  ($data_value['sgst'])}} </td>
            </tr>
            <tr>
                <td>Total Premium </td>
                <td>&#8377; {{$data_value['totalPremium']}}</td>
            </tr>
            
        </table>

         <h4>Health Details:</h4> 
         <table class="table responsive" style="font-size: 12px;">
             @foreach($data_value['ped'] as $key=>$value)
            <tr>
                <td>{{ucwords($key)}}</td>
                <td>@if($value == '0')  No @else Yes @endif</td>
            </tr>
            @endforeach
           </table> 

        <h4>Communication Details:</h4>
        <table class="table responsive" style="font-size: 12px;">
            <tr> 
                <td>Address</td>
                <td>{{$data_value['houseno']}}, {{$data_value['street']}}, {{$data_value['locality']}},<br>
                {{$data_value['city']}}, {{$data_value['state']}},<br>
                PIN - {{ $data_value['cust_pincode']}}</td>
            </tr>
            <tr>
                <td>Email</td>
                <td>{{$data_value['email']}}</td>
            </tr>
            <tr>
                <td>Mobile</td>
                <td>{{$data_value['mobile']}}</td>
            </tr>
        </table>    
       
        </div>
    </body>
</html>
