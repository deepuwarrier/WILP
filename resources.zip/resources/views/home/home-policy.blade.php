<!DOCTYPE html>
<html lang="en" ng-app>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="{{ URL::asset('js/car/cardetails.js') }}"></script>
        
        
        <script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.3.3/angular.min.js"></script>
        
        
        <title>InstaInsure: Car Insurance</title>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="content">
               <p> Car Details Page</p>
			
			
			<p style="align:center">
			 
			@foreach ($car_makes as $cmks)
			<button id="{{ $cmks->make_id }}">{{ $cmks->make }}</button>  
			@endforeach
			
			</p>
			
			<hr>
			
					
		<p style="align:center">
			 
			@foreach ($car_models as $cmdls)
			<button id="{{ $cmdls->model_id }}">{{ $cmdls->model }}</button>  
			@endforeach
			
			</p>
			
			
			<div>
         <label>Name:</label>
         <input type = "text" ng-model = "yourName" placeholder = "Enter a name here">
         <hr />
         
         <h1>Hello {{yourName}}!</h1>
      </div>
			
			
			
			

        </div>
        </div>
    </body>
</html>
