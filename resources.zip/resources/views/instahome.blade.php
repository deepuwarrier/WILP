@include('layouts.header')
<div class="page-header" id="home" style="background-color: white">
         <div class="container">
               <section class="products_intro">
                  <div data-aos="slide-down" data-aos-duration="500" class="contain_very_small">
                     <h1 style="color: #92cf1b">InstaInsure.com</h1>
                  </div>
               </section>
               <ul class="products_grid">
                  <h3 data-aos="fade-down" data-aos-duration="500" style="color: #00669c; padding-bottom: 20px;">
                     Which insurance are you looking for today?
                  </h3>
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/car-insurance">
                        <img src="{{URL::asset('image/car.svg')}}" alt="Car Insurance">
                        <h3>Car<span>Insurance</span></h3>
                     </a>
                  </li>
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/two-wheeler-insurance">
                        <img src="{{URL::asset('image/bike.svg')}}" alt="Two Wheeler Insurance">
                        <h3>Bike<span>Insurance</span></h3>
                     </a>
                  </li>
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/health-insurance">
                        <img src="{{URL::asset('image/health.svg')}}" alt="Health Insurance">
                        <h3>Health <span>Insurance</span></h3>
                     </a>
                  </li>
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/travel-insurance">
                        <img src="{{URL::asset('image/travel.svg')}}" alt="Travel Insurance">
                        <h3>Travel<span>Insurance</span></h3>
                     </a>
                  </li>
                  <!--
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/home-insurance">
                        <img src="{{URL::asset('image/home.svg')}}" alt="Home Insurance">
                        <h3>Home<span>Insurance</span></h3>
                     </a>
                  </li>
                  <li>
                     <a data-aos="fade-up" data-aos-duration="500" class="hvr-float-shadow" href="/term-insurance">
                        <img src="{{URL::asset('image/life.svg')}}" alt="Term Life Insurance">
                        <h3>Term Life<span>Insurance</span></h3>
                     </a>
                  </li>
                  -->
               </ul>
               
               <div class="homelogobox">
                  @include('layouts.c_partners')
              </div>
            
            
         </div>
      </div>

<div class="features-1" id="legacy" >@include('layouts.c_legacy')</div>
<div class="features-5" id="whyus" >@include('layouts.c_whyus')</div>
<div class="testimonials-2 section-image" id="testimonials" >@include('layouts.c_testimonial')</div>
<div class="blogs-2" id="blogs" style="padding-top: 80px">@include('layouts.c_blog')</div>
 <div class="team-1" id="team" > @include('layouts.c_team')</div>   
 <!-- <div class="contactus-1 section-image" id="contactus" >@include('layouts.c_contact')</div> -->
<div id="overlay" style="display: none;"></div>
@include('layouts.footer')
@include('layouts.vnavfooter')

 <script src="{{URL::asset('js/jquery.isonscreen.js')}}" type="text/javascript"></script>
 
