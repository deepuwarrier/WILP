<html>
<head>
	<title>New user has been registered</title>
</head>
<body>
	<p>Hello ,</p>
	<p>A new user has been registred to InstaInsure.com!</p>
	<p>Through {{$source}}</p>
	<p>His email is {{$email}}</p>
	<p>And number is {{$mobile_number}}</p>
	@if(isset($offer_month))
		<p>His insurance expiry month is {{$offer_month}}</p>
	@endif
	<p><u>InstaInsure Customer Support Team: </u></p>
	<p>Whatsapp/ Call/ SMS : +91 7899-000-333 |  Email : support@instainsure.com</p>
	<p>For escalations email deepak@instainsure.com</p>
	<p>InstaInsure.com is a digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI). IRDAI Composite License No: 431 Valid upto 01/09/2017. Insurance is the subject matter of solicitation.</p>
</body>
</html>
