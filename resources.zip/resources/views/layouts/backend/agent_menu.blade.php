<nav class="navbar navbar-default navbar-static-top">
   <div class="container">
      <div class="navbar-header">
         <!-- Collapsed Hamburger -->
         <button type="button" class="navbar-toggle collapsed"
            data-toggle="collapse" data-target="#app-navbar-collapse">
            <span class="sr-only">Toggle Navigation</span> <span
               class="icon-bar"></span> <span class="icon-bar"></span> <span
               class="icon-bar"></span>
         </button>
         <!-- Branding Image -->
         <a class="navbar-brand"> InstaInsure Dashboard</a>
      </div>

      <div class="collapse navbar-collapse" id="app-navbar-collapse">

         <ul class="nav navbar-nav navbar-right">

            <li><a href="/agent/dashboard">Home</a></li>
            <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><b>PRODUCT CATALOGUE</b><span class="caret"></span></a>
               <ul class="dropdown-menu" role="menu">
                   <li>
                          <a href="https://www.hdfcergo.com/OnlineProducts/motoronline/NewBusiness/CalculatePremium.aspx?RefEnc=3pHUwKngLt9IFJgyOV0h4Q==" target="_blank">
                           Hdfc Ergo 4W (Break In)
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/MotorTPLOnline/newbusiness/prodselection.aspx?prod=2319&refenc=2SYhQAKT9XVIFJgyOV0h4Q==" target="_blank">
                           Hdfc Ergo 4W (Liabiity only)
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/twonline/newbusiness/calculatepremium.aspx?RefEnc=R7NEApW5FTVIFJgyOV0h4Q==" target="_blank">
                           Hdfc Ergo 2W (Break-In)
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/MotorTPLOnline/newbusiness/prodselection.aspx?prod=2320&amp;refenc=2SYhQAKT9XVIFJgyOV0h4Q==" target="_blank">
                           Hdfc Ergo 2W (Liability Only)
                           </a>
                        </li>
                         <li>
                           <a href="https://general.bajajallianz.com/MotorInsurance/onlineportal/motorNew/indexCar.jsp?p_product_code=1801&src=CBM_02641" target="_blank">
                           Bajaj Allianz 4W (No Break-In)
                           </a>
                        </li>
                        <li>
                           <a href="https://general.bajajallianz.com/MotorInsurance/onlineportal/motorNew/index.jsp?src=CBM_02642" target="_blank">
                           Bajaj Allianz 2W 
                           </a>
                        </li>
                         <li>
                           <a href="https://www.instainsure.com/two-wheeler-insurance/tp" target="_blank">
                           UIIC 2W (Liability Only)
                           </a>
                  </li>
                        <li>
                           <a href="https://goo.gl/oZ1y5g" target="_blank">
                           Hdfc Life
                           </a>
                        </li>
                        <li>
                           <a href="https://www.iciciprulife.com/term-insurance-plans/iprotect-smart-term-insurance-calculator.html?UID=6271" target="_blank">
                           ICICI Pru Life
                           </a>
                        </li>
                        <li>
                           <a href="https://www.iciciprulife.com/health-insurance-plans/icici-pru-heart-cancer-health-insurance-calculator-worksite.html?UID=6273" target="_blank">
                           ICICI Heart and Cancer
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/HomePortal/CalculatePremium.aspx?ref=HMD00007" target="_blank">
                           Hdfc Ergo Home
                           </a>
                        </li>
                        <li>
                           <a href="https://general.bajajallianz.com/Insurance/myHomeNew/initMyHomeNew.do?pid=4014&src=CBM_02657" target="_blank">
                           Bajaj Allianz Home
                           </a>
                        </li>
                       <li>
                           <a href="https://general.bajajallianz.com/Insurance/travel/basicinfo.jsp?src=CBM_02588" target="_blank">
                           Bajaj Allianz Travel
                           </a>
                        </li>
                         <li>
                           <a href="https://healthinsurancepartner.libertyvideocon.com/login.aspx?ReturnUrl=%2f" target="_blank">
                           Liberty Videocon - Super Topup (IMD1096932)
                           </a>
                        </li> 
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/HealthOnline/HSP-CIP/CIPCalculatePremium.aspx?ref=HSD00047" target="_blank">
                           HDFC Critical Illness
                           </a>
                        </li>
                        <!-- <li>-->
                        <!--   <a href="https://www.hdfcergo.com/OnlineProducts/PAOnline/PA/CalculatePremium.aspx?ref=TTIB0001" target="_blank">-->
                        <!--   HDFC Personal Accident-->
                        <!--   </a>-->
                        <!--</li>-->
                        <li>
                           <a href="https://web.newindia.co.in/NIABancsPortal/IntermediaryLogin.html" target="_blank">
                           New India Assurance - All Products (BR_TSUSHOB/Vision@2020)
                           </a>
                        </li>
               </ul>
            </li>
            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><b>TUTORIALS </b><span class="caret"></span></a>
               <ul class="dropdown-menu" role="menu">
                  <li>
                           <a href="https://youtu.be/D8cCRHULGkw" target="_blank">Car Insurance</a>
                        </li>
                        <li>
                           <a href="https://youtu.be/3AafISYacbs" target="_blank"> 2 Wheeler Insurance</a>
                        </li>
                         <li id="wheeler_tut_break_in">
                           <a href="https://youtu.be/3OH80rd8QQ8" target="_blank">2 Wheeler Break-In</a>
                        </li>
                        <li>
                           <a href="https://youtu.be/80rhcyoXoZ8" target="_blank"> Health Insurance </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/dxi0J31DSqQ" target="_blank"> Health Super Topup </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/8530kB0-fTI" target="_blank">Travel Insurance </a>
                        </li>       
               </ul>
            </li>


            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> <b>REPORTS</b><span class="caret"></span></a>
               <ul class="dropdown-menu" role="menu">
                  <li><a href="/agent/reports/trans-summary-search">Transaction Status Report</a></li>
                  <li><a href="/agent/reports/policy-summary-report">Policy Summary Report</a></li>
               </ul>
            </li>


            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
               <strong>{{!empty(session('user_name'))?session('user_name'):''}}</strong>
                <span class="caret"></span>
            </a>

               <ul class="dropdown-menu" role="menu">
                <!--  <li><a href="#"> Manage Profile </a></li>. -->
                  <li><a href="{{URL::to('/agent/change-password')}}"> Change Password </a></li>
                  <li><a href="{{ URL::to('/agent-logout') }}"> Logout </a></li>
               </ul></li>
         </ul>
      </div>
   </div>
</nav>
