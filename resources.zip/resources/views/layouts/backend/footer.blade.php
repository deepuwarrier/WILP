</div>
</body>
</html>
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{URL::asset('js/jquery-ui.min.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('js/sweetalert2.js')}}"></script>
<script src="{{ asset('js/component/jquery.validate.min.js') }}"></script>
<script src="{{URL::asset('js/validation_helper.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('js/common.js')}}" type="text/javascript"></script>
