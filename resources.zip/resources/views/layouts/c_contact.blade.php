<div data-aos="flip-up" data-aos-duration="1000" class="container">
            <div class="row">
               <div class="col-md-5">
                  <h2 class="title dark">Get in Touch</h2>
                  <h5 class="description">You need more information?</h5>
                  <div class="info info-horizontal">
                     <div class="icon icon-primary">
                        <i class="material-icons">pin_drop</i>
                     </div>
                     <div class="description">
                        <h4 class="info-title">Our Office</h4>
                        <p> 1st Floor, Crown Point,<br>
                           Lavelle Road,<br>
                           Bangalore, India<br>
                           Pin: 560001
                        </p>
                     </div>
                  </div>
                  <div class="info info-horizontal">
                     <div class="icon icon-primary">
                        <i class="material-icons">phone</i>
                     </div>
                     <div class="description">
                        <h4 class="info-title">Give us a ring</h4>
                        <p> Customer Advisor<br>
                           +91-7899-000-333<br>
                           Mon - Fri, 9:30-18:30
                        </p>
                     </div>
                  </div>
               </div>
               

                           <div class="row">
                              <div class="col-md-6 padtop">
                                 <button type="button" class="btn btn-primary">Send Message</button>                                 
                              </div>
                           </div>
						    <div class="row">
                              <div class="smessage">
                                 
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
