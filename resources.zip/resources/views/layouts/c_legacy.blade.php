<div class="row">
            <div data-aos="fade-up" data-aos-duration="600" class="col-md-8 col-md-offset-2 text-center">
               <h2 class="title">Trusted by 2,000,000 + Customers</h2>
               <h4 class="description">A Joint Venture between Toyota Tsusho Corporation (TTC) Japan and Kirloskars (India) <br> <b>Toyota Tsusho Insurance Broker India Pvt Limited (TTIBI) </b>established in 2008, is now among the top 5 Insurance Brokers in India.</h4>
            </div>
         </div>

<div class="row">
            <div data-aos="fade-left" data-aos-duration="600"  class="col-md-4">
               <div class="info">
                  <div class="icon icon-info">
                     <i class="material-icons">chat</i>
                  </div>
                  <h3 class="info-title">3,000,000 +</h3>
                  <h5>Policies Issued</h5>
                  <p>More than 1000 crores of premium placed. 4% of the total premium placed through insurance brokers in India is placed through us. </p>
               </div>
            </div>
            <div data-aos="fade-in" data-aos-duration="600" class="col-md-4">
               <div class="info">
                  <div class="icon icon-success">
                     <i class="material-icons">verified_user</i>
                  </div>
                  <h3 class="info-title">100,000 +</h3>
                  <h5>Claims Assisted</h5>
                  <p>Thanks to our strong relationship with all major insurance companies, we have been successful in effectivley settling 93% of all claims reported to us.</p>
               </div>
            </div>
            <div data-aos="fade-right" data-aos-duration="600" class="col-md-4">
               <div class="info">
                  <div class="icon icon-danger">
                     <i class="material-icons">fingerprint</i>
                  </div>
                  <h3 class="info-title">90%</h3>
                  <h5>Customer Retention</h5>
                  <p>Nothing is more encouraging than a happy customer. Our customers love us as we go the extra mile to ensure that they are delighted.</p>
               </div>
            </div>
         </div>