<div data-aos="fade-up" data-aos-duration="1000">
<h5>From the <b>Toyota</b> stable, comes a digital initiative with the core values of <i>Trust</i>, <i>Honesty</i> and <i>Professionalism</i>.</h5>
                  <p>Bringing the best products from the biggest names in the Insurance Industry</p>
                  <img class="sizer hvr-grow" src="{{URL::asset('image/logos/uiicgi_logo.png')}}" alt="United India Logo">
                  <img class="sizer hvr-grow" src="{{URL::asset('image/logos/hdfcgi_logo.png')}}" alt="HDFC Ergo Logo">
            <img class="sizer hvr-grow" src="{{URL::asset('image/logos/bajajallianzgi_logo.png')}}" alt="Bajaj Allianz Logo">
               <img class="sizer hvr-grow" src="{{URL::asset('image/logos/bhartiaxagi_logo.png')}}" alt="Bharti AXA Logo">
             <img class="sizer hvr-grow" src="{{URL::asset('image/logos/iffcogi_logo.png')}}" alt="IFFCO Tokio Logo">
             <img class="sizer hvr-grow" src="{{URL::asset('image/logos/fggi_logo.png')}}" alt="Future Generali Logo">
               <img class="sizer hvr-grow" src="{{URL::asset('image/logos/usgi_logo.png')}}" alt="Universal Sompo Logo">
               </div>