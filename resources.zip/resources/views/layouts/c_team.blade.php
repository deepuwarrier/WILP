<div data-aos="zoom-in" data-aos-duration="1000" class="container">
            <div class="row">
               <div class="col-md-12  text-center">
                  <h2 class="title">Our Management Team</h2>
                  <h5 class="description">The collective experience of the team would run into decades!</h5>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4">
                  <div class="card card-profile card-plain managementpreview">
                     <div class="card-avatar">
                        <a>
                        <img class="img" src="{{URL::asset('image/people/vijay.png')}}" alt="Vijaya  Kumar Govada" />
                        </a>
                     </div>
                     <div class="content">
                        <h4 class="card-title">Vijaya Kumar Govada</h4>
                        <h6 class="category text-muted">CEO and Director</h6>
                        <p class="card-description">
                           He is obsessed with customer service. Having worked in the insurance industry for more than 30 years, he is now working on his brainchild instainsure.com to make it a market leader.
                        </p>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card card-profile card-plain managementpreview">
                     <div class="card-avatar">
                        <a>
                        <img class="img" src="{{URL::asset('image/people/tsukada.png')}}" alt="Yoshiaki Tsukada" />
                        </a>
                     </div>
                     <div class="content">
                        <h4 class="card-title">Yoshiaki Tsukada</h4>
                        <h6 class="category text-muted">Whole - Time Director</h6>
                        <p class="card-description">
                           He helps us focus on the core objectives and rings in a Japanese touch to everything that we do.
                        </p>
                        
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="card card-profile card-plain managementpreview">
                     <div class="card-avatar">
                        <a>
                        <img class="img" src="{{URL::asset('image/people/deepak.png')}}" alt="Deepak Venugopal" />
                        </a>
                     </div>
                     <div class="content">
                        <h4 class="card-title">Deepak Venugopal</h4>
                        <h6 class="category text-muted">Head - Instainsure</h6>
                        <p class="card-description">
                           He brings in positive energy and motivates the team to deliver the best. He and his team is fighting a new battle every day in war fields of technology and marketing.
                        </p>
                        
                     </div>
                  </div>
               </div>
               </div>
             