<div class="container">
            <div class="row">
               <div  class="col-md-6 col-md-offset-3 text-center">
                  <h2 data-aos="zoom-in-down" data-aos-duration="600" class="title">Our Clients Love Us</h2>
                  <h5 data-aos="zoom-in-up" data-aos-duration="600" class="description">We are because you are!</h5>
               </div>
            </div>
            <div class="row">
               <div class="col-md-4">
                  <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-testimonial">
                     <div class="icon">
                        <i class="material-icons">format_quote</i>
                     </div>
                     <div class="content">
                        <h5 class="card-description testimonialpreview">
                           Thank you for your unending patience and support for getting both the renewals done. Truly Appreciate!
                        </h5>
                     </div>
                     <div class="footer">
                        <h4 class="card-title">Adit Mandanna</h4>
                        <h6 class="category">Bangalore</h6>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-testimonial">
                     <div class="icon">
                        <i class="material-icons">format_quote</i>
                     </div>
                     <div class="content">
                        <h5 class="card-description testimonialpreview">
                           "Thank you so much for helping me out in the Renewal of my insurance online. I appreciate your efforts in making me comfortable while doing an online transaction."
                        </h5>
                     </div>
                     <div class="footer">
                        <h4 class="card-title">Murugan J</h4>
                        <h6 class="category">Chennai</h6>
                     </div>
                  </div>
               </div>
               <div class="col-md-4">
                  <div data-aos="zoom-in-up" data-aos-duration="600" class="card card-testimonial">
                     <div class="icon">
                        <i class="material-icons">format_quote</i>
                     </div>
                     <div class="content">
                        <h5 class="card-description testimonialpreview">
                           "Thank you very much for your excellent services. We are delighted to take insurance through TTIBI."
                        </h5>
                     </div>
                     <div class="footer">
                        <h4 class="card-title">Anupam Vasdani</h4>
                        <h6 class="category">Mumbai</h6>
                     </div>
                  </div>
               </div>
            </div>
         </div>