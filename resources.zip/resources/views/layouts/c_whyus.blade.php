<div data-aos="zoom-in" data-aos-duration="1000" class="col-md-8 col-md-offset-2 text-center">
            <h2 class="title">Why you may like us?</h2>
         </div>
<div class="container">
            <div class="row">
               <div data-aos="fade-right" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="hvr-grow material-icons">wb_incandescent</i>
                     </div>
                     <h3 class="info-title">We focus on the Features</h3>
                     <p>We help you choose the best product by focusing on various features that can be a part of your insurance policy. </p>
                  </div>
               </div>
               <div data-aos="fade-in" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="material-icons">supervisor_account</i>
                     </div>
                     <h3 class="info-title">Dedicated Advisors</h3>
                     <p>Dedicated in the true sense, we help you understand the product you are buying and give you opinions from insurance experts.</p>
                  </div>
               </div>
               <div data-aos="fade-left" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="material-icons">redeem</i>
                     </div>
                     <h3 class="info-title">Best Products</h3>
                     <p>Handpicked products which are researched, studied and analysed. We ensure only the best products reach you! </p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div data-aos="fade-right" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="material-icons">loyalty</i>
                     </div>
                     <h3 class="info-title">Best Prices</h3>
                     <p>Prices are pre-negotiated, which means you buy the best insurance at the best price!</p>
                  </div>
               </div>
               <div data-aos="fade-in" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="material-icons">not_interested</i>
                     </div>
                     <h3 class="info-title">No Sales Pitches</h3>
                     <p>You will never have us ringing you in the middle of a meeting, while you are driving or at midnight! We just dont do cold calls! </p>
                  </div>
               </div>
               <div data-aos="fade-left" data-aos-duration="600" class="col-sm-4">
                  <div class="info">
                     <div data-aos="flip-left" data-aos-duration="1000" class="icon">
                        <i class="material-icons">thumbs_up_down</i>
                     </div>
                     <h3 class="info-title">Honest Analysis</h3>
                     <p>We have no sides to take but yours! We provide honest analysis of the insurance product you are about to buy. Plain and Simple! </p>
                  </div>
               </div>
            </div>
         </div>