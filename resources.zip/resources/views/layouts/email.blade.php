<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Enquiry Received</title>
</head>
<body>

            <tbody>
               <tr>
                  <td>
                        <table align="center" style="Margin:0 auto;background:#edf1f4;border-collapse:collapse;border-radius:10px;border-spacing:0;float:none;margin:0 auto;max-width:600px;padding:0;text-align:center;vertical-align:top;width:100%;word-break:keep-all!important">
                           <tbody>
                              <tr>
                                 <td>
                                    <table style="margin-top:10px">
                                       <tbody>
                                          <tr>
                                             <td>
                                                <table style="background:#fff;border-collapse:collapse;border-radius:10px;padding:0;padding-left:15%!important;padding-right:15%!important;top;width:95%;word-break:keep-all!important" align="center">
                                                   <tbody style="word-break:keep-all!important">
                                                      <tr>
                                                         <td style="margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">
                                                            <table>
                                                               <tbody>
                                                                  <tr>
                                                                     <td>
                                                                        <div><a href="https://www.instainsure.com" target="_blank"><img src="https://www.instainsure.com/image/instainsure_logo.png" style="display:block;float:none;margin:0 auto;max-height:70px;max-width:200px;padding:40px"></a>
                                                                        </div>
                                                                        <table style="border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                           <tbody>
                                                                              <tr>
                                                                                 <th style="color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0 auto;padding:0;padding-bottom:0;padding-left:6%!important;padding-right:6%!important;text-align:left;width:96%;word-break:keep-all!important">
                                                                                    <table style="border-collapse:collapse;border-spacing:0">
                                                                                       <tbody>
                                                                                          <tr>
                                                                                             <th style="color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0;text-align:left;word-break:keep-all!important">
                                                                                                <p></p>
                                                                                                <div style="font-size:14px!important;text-align:left;word-break:keep-all!important">
                                                                                                   Hello!<br><br>We are writing to let you that a new enquiry has been recevied from {{$name}}.
                                                                                                   <br><br>
                                                                                                   The Lead can be contacted at {{$mobile}} and Email id is {{$email}}
                                                                                                   <br style="word-break:keep-all!important"><br style="word-break:keep-all!important">You are advised to:<br style="word-break:keep-all!important">
                                                                                                   <ul>
                                                                                                      <li>Check if this is a Spam </li>
                                                                                                      <li>If not, please call the lead right away.</li>
                                                                                                      <li>If the lead does not pick the call, please leave an email/sms</li>
                                                                                                   </ul>
                                                                                                   <br style="word-break:keep-all!important">
                                                                                                   
                                                                                             </th>
                                                                                             <th class="m_-5879607541028847299expander" style="Margin:0;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0!important;text-align:left;width:0;word-break:keep-all!important"></th>
                                                                                          </tr>
                                                                                       </tbody>
                                                                                    </table>
                                                                                 </th>
                                                                              </tr>
                                                                           </tbody>
                                                                        </table>
                                                                        <table style="background:#282c35;border-bottom-left-radius:10px;border-bottom-right-radius:10px;border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                           <tbody style="word-break:keep-all!important">
                                                                              <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                 <th style="Margin:0 auto;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0 auto;padding:0;padding-bottom:5px;padding-left:4%;padding-right:4%;text-align:left;width:96%;word-break:keep-all!important">
                                                                                    <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                       <tbody>
                                                                                          <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                             <th style="Margin:0;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0;text-align:left;word-break:keep-all!important">
                                                                                                <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="32px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:32px;font-weight:400;line-height:32px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                                <center style="color:white;min-width:88%;width:100%;word-break:keep-all!important">InstaInsure.com
                                                                                                <table class="" style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="5px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:5px;font-weight:400;line-height:5px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">1st Floor, Crown Point, Lavelle Road, Bangalore, Karnataka - 560001</p>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">A digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI) 
IRDAI Composite License No: 431 Valid upto 01/09/2017.</p>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">Insurance is a subject matter of solicitation.
                                                                                                <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="5px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:5px;font-weight:400;line-height:5px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                             </th>
                                                                                          </tr>
                                                                                       </tbody>
                                                                                    </table>
                                                                                 </th>
                                                                              </tr>
                                                                           </tbody>
                                                                        </table>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </center>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
</div>

</body>
</html>
