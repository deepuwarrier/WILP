<html>
<head>
	<title>New Enquiry</title>
</head>
<body>
	<p>Hello {{$name}}!</p>
	<p>We are glad you are in touch with us.</p>
	<p>Our customer support team will get in touch with you shortly to help you with your enquiry.</p>
	<p>Meanwhile, if you want to call us, our coordinates are as below!</p>
	<p>InstaInsure Customer Support Team: </p>
	<p>Whatsapp/ Call/ SMS : +91 7899-000-333 |  Email : support@instainsure.com</p>
	<p>For escalations email deepak@instainsure.com</p>
	<p>InstaInsure.com is a digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI). IRDAI Composite License No: 431 Valid upto 01/09/2017. Insurance is the subject matter of solicitation.</p>
</body>
</html>
