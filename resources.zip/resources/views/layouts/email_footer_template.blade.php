<br style="word-break:keep-all!important"><br style="word-break:keep-all!important">InstaInsure Customer Support Team:<br style="word-break:keep-all!important">
<ul>
                                                                                                      <li>Whatsapp/ Call/ SMS us at +91 7899-000-333 </li>
                                                                                                      <li>Email us at <i><a href="mailto:support@instainsure.com">support@instainsure.com</a></i></li>
                                                                                                   </ul>
                                                                                                   <br>
                                                                                                   For any escalations, please write to <i>deepak@instainsure.com</i>
                                                                                                   <br>

                                                                                                   <br style="word-break:keep-all!important">
                                                                                                   
                                                                                             </th>
                                                                                             <th style="Margin:0;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0!important;text-align:left;width:0;word-break:keep-all!important"></th>
                                                                                          </tr>
                                                                                       </tbody>
                                                                                    </table>
                                                                                 </th>
                                                                              </tr>
                                                                           </tbody>
                                                                        </table>
                                                                        <table style="background:#282c35;border-bottom-left-radius:10px;border-bottom-right-radius:10px;border-collapse:collapse;border-spacing:0;display:table;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                           <tbody style="word-break:keep-all!important">
                                                                              <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                 <th style="Margin:0 auto;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0 auto;padding:0;padding-bottom:5px;padding-left:4%;padding-right:4%;text-align:left;width:96%;word-break:keep-all!important">
                                                                                    <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                       <tbody>
                                                                                          <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                             <th style="Margin:0;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:16px;font-weight:400;line-height:1.4;margin:0;padding:0;text-align:left;word-break:keep-all!important">
                                                                                                <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="32px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:32px;font-weight:400;line-height:32px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                                <center style="color:white;min-width:88%;width:100%;word-break:keep-all!important">InstaInsure.com
                                                                                                <table class="" style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="5px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:5px;font-weight:400;line-height:5px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">1st Floor, Crown Point, Lavelle Road, Bangalore, Karnataka - 560001</p>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">A digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI) 
IRDAI Composite License No: 431 Valid upto 01/09/2017.</p>
                                                                                                <p style="Margin:0;Margin-bottom:16px;color:#89959b;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:11px;font-weight:400;line-height:1.4;margin:0;margin-bottom:16px;padding:0;text-align:center;word-break:keep-all!important">Insurance is a subject matter of solicitation.
                                                                                                <table style="border-collapse:collapse;border-spacing:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:keep-all!important">
                                                                                                   <tbody style="word-break:keep-all!important">
                                                                                                      <tr style="padding:0;text-align:left;vertical-align:top;word-break:keep-all!important">
                                                                                                         <td height="5px" style="Margin:0;border-collapse:collapse!important;color:#33373d;font-family:-apple-system,Helvetica,Arial,sans-serif;font-size:5px;font-weight:400;line-height:5px;margin:0;padding:0;text-align:left;vertical-align:top;word-break:keep-all!important;word-wrap:break-word">&nbsp;</td>
                                                                                                      </tr>
                                                                                                   </tbody>
                                                                                                </table>
                                                                                             </th>
                                                                                          </tr>
                                                                                       </tbody>
                                                                                    </table>
                                                                                 </th>
                                                                              </tr>
                                                                           </tbody>
                                                                        </table>
                                                                     </td>
                                                                  </tr>
                                                               </tbody>
                                                            </table>
                                                         </td>
                                                      </tr>
                                                   </tbody>
                                                </table>
                                             </td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </center>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
</div>

</body>
</html>