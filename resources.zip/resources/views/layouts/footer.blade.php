  <footer class="footer footer-white">

    <div class="social-line text-center">
                 
                     <div class="col-md-12">
                        <h4 style="color: white;">Have a <b>Question</b>? We have the <i>Answer</i>.</h4>
                     </div>
                        <h3 style="font-weight: 500">Call us at: +91 7899-000-333</h3>
                  
            </div>
         <div class="container">
            <div class="content text-center">
               <div class="row">
                  <div class="col-md-3">
                     <a href="/">
                        <h5>InstaInsure.com</h5>
                     </a>
                     <p>A digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI) <br> <b>IRDAI Composite License Number : 381<br> Valid upto: 01/09/2020 <br>CIN : U66010KA2008PTC045231.</b><br>Principal Officer : Vijaya Kumar Govada, email: vgovada@ttibi.co.in <br>Insurance is the subject matter of solicitation. 
 </p>
                  </div>
                  <div class="col-md-2">
                     <h5>Pages</h5>
                     <ul class="links-vertical">
                        <li>
                           <a href="/"> Home </a>
						</li>
                        <li>
                           <a href="/blog" target="_blank"> Blog </a>
						</li>
                        <li>
                           <a href="/team" target="_blank"> Team </a>
						</li>
                        <li>
                           <a href="/faqs" target="_blank"> FAQ </a>
						</li>
            <li>
                           <a href="/terms" target="_blank"> Terms & Conditions </a>
            </li>
            <li>
                           <a href="/privacy" target="_blank"> Privacy Policy </a>
            </li>
            <li>
                           <a href="http://ttibi.co.in/?q=board-directors" target="_blank"> Board of Directors  </a>
            </li>
                     </ul>
                  </div>
                  <div class="col-md-2">
                     <h5>Product Catalogue</h5>
                     <ul class="links-vertical">
                        <li>
                           <a href="/car-insurance"> Car Insurance </a>
						</li>
                        <li><a href="/home-insurance"> Home Insurance </a></li>
                        <li>
                           <a href="/travel-insurance"> Travel Insurance </a>
						</li>
                        <li><a href="/two-wheeler-insurance"> Bike Insurance </a></li>
                        <li>
                           <a href="/health-insurance"> Health Insurance </a>
						</li>
                        <li>
                           <a href="/term-insurance"> Term Insurance </a>
						</li>
                     </ul>
                  </div>
                  <div class="col-md-2">
                     <h5>Links</h5>
                     <ul class="links-vertical">
                        <li>
                           <a href="https://www.irdai.gov.in/" target="_blank"> IRDAI Portal</a>
						</li>
                        <li><a href="http://www.igms.irda.gov.in/WebPages/PolicyHolderUserDetails.aspx" target="_blank"> IRDAI Complaint Registration </a></li>
                     </ul>
                  </div>
                  <div class="col-md-3">
                     <h5>Show us some love</h5>
                     <div class="social-area" itemscope="" itemtype="http://schema.org/LocalBusiness">
                <a itemprop="sameAs" href="https://www.facebook.com/instainsure" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-facebook-square"></i></a>
                <a itemprop="sameAs" href="https://twitter.com/InstaInsure" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-twitter"></i></a>
                <a itemprop="sameAs" href="https://www.instagram.com/instainsureofficial/" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-instagram"></i></a>
                <a itemprop="sameAs" href="https://www.youtube.com/channel/UCfGpxZlH3iOaSsOic4a56FQ" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-youtube"></i></a>
            </div>
                     
                  </div>
               </div>
            </div>
            <hr>
            <div class="copyright">
               Copyright © <script>document.write(new Date().getFullYear())</script> InstaInsure.com All Rights Reserved.
            </div>
         </div>
      </footer>

      <!--   Core JS Files   -->
      <script src="{{URL::asset('js/jquery.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/jquery-ui.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/insta.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/sweetalert2.js')}}"></script>
      <script src="{{URL::asset('js/aos.js')}}" type="text/javascript"></script>     
      <script src="{{URL::asset('js/script.js')}}" type="text/javascript"></script>
      <script src="{{ asset('js/component/jquery.validate.min.js') }}"></script>
      <script src="{{URL::asset('js/validation_helper.js')}}" type="text/javascript"></script>
      <!---    common js file for all -->
      <script src="{{ asset('js/common.js') }}"></script>
		<script>
		 AOS.init();
	   </script> 
      <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
 
  ga('create', 'UA-94028710-1', 'auto');
  ga('send', 'pageview');
 
</script>     
<script src="https://cdn.pagesense.io/js/ttibionline/2ac46f1783c44f24ab082a59cbecdb76.js"></script>

   </body>




</html>
