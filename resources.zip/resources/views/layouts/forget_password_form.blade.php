<div id="forget_hide" class="hide" style="margin:5%;">
  <form id="forget_password_form" method="POST" action="{{URL::route('customer.forgotPassword')}}" novalidate="novalidate" >
    {{csrf_field()}}
  <div class="form-group">
      <label for="username" class="control-label">Email Id</label>
      <input type="text" class="form-control" id="forgetPassword_email" name="forgetPassword_email" value="" required="" title="Please enter your registered email" placeholder="example@website.com">
      <span class="help-block"></span>
      <span class="has-error" id="forget_email_error"></span>
  </div>
  <div class="text-center">
    <button type="submit" id="forgetPassword_button" class="btn btn-success input-block-level">Reset Password</button>
  </div>
</form>
<div class="row">
  <a href="javascript:void(0);" id="register_modal" data-url="{{URL::route('customer.registerForm')}}" class="pull-left">Not register? Register Now!!</a>
</div>
</div>
