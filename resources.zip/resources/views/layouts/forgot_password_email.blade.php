@include('layouts.email_header_template')
	@section('title', 'Reset your password at InstaInsure.com')
	<p>Dear {{$name}},</p>
	<p>Welcome to InstaInsure.com!</p>
	<p>Your new reset password is {{$password}}</p>
@include('layouts.email_footer_template')
