<!doctype html>
<html>
<head>
 <title>{{ $MTxt->page_mt_title or 'Instainsure.com - Buy Insurance Online'  }}</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">	
<meta name="robots" content="index, follow">
<meta name="language" content="EN">
<meta name="copyright" content="InstaInsure">
<meta name="document-classification" content="Internet">
<meta name="document-type" content="Public">
<meta name="document-rating" content="Safe for Kids">
<meta name="document-distribution" content="Global">  
<meta name="keywords" content="{{ $MTxt->page_mt_kwds or 'Instainsure.com - Buy Insurance Online'}}">
<meta name="description" content="{{ $MTxt->page_mt_desc or 'Instainsure.com - Buy Insurance Online'}}">
<link rel="shortlink" href="/"> <link rel="canonical" href=" " /><link rel="icon" href="{{ asset('image/instainsure_logo_small.svg')}}">

<meta property="og:title" content="Buy Insurance Online - Super Quick!">
<meta property="og:type" content="company">
<meta property="og:url" content="www.instainsure.com">
<meta property="og:image" content="http://www.instainsure.com/image/instainsure_logo.svg">
<meta property="og:site_name" content="InstaInsure">
<meta property="fb:admins" content="1438463946367385">
<meta property="fb:app_id" content="814715792006798">
<meta property="og:description" content="InstaInsure.com allows you to buy an insurance policy super quick! Best Prices, Super Features and Amazing Discounts!">
<meta name="csrf-token" content="{{ csrf_token() }}">
<fb:like href="http://developers.facebook.com/" width="450" height="80">
<link rel="icon" href="{{ asset('image/instainsure_logo_small.svg')}}">

      
      <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}"/>
     
      <link href="{{asset('css/insta-base.css')}}" rel="stylesheet" />
      <link href="{{ asset('css/insta-toolkit.css') }}" rel="stylesheet" />
    
      <link href="{{ asset('css/insta.css') }}" rel="stylesheet" />
      <!--     Fonts and icons     -->
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="{{ asset('css/css8393.css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('css/vertical-nav.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('css/wizard.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ asset('css/hover.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ asset('css/aos.css') }}"/>
    
   </head>
   <body class="custompage">
      <nav class="navbar navbar-primary navbar-fixed-top" id="sectionsNav">
         <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
               <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a href="/" class="card-logo instalogo">
               <img src="{{URL::asset('image/instainsure_logo.svg')}}" alt="InstaInsure Logo">
               </a>
            </div>
            <div class="collapse navbar-collapse" id="navigation-example">
               <ul class="nav navbar-nav navbar-right">
                  <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                     <i class="material-icons">view_carousel</i>Product Catalogue
                     <b class="caret"></b>
                     </a>
                     <ul class="dropdown-menu dropdown-with-icons">
                        <li>
                           <a href="/car-insurance">
                           <i class="material-icons">directions_car</i> Car Insurance
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/motoronline/NewBusiness/CalculatePremium.aspx?RefEnc=3pHUwKngLt9IFJgyOV0h4Q==" target="_blank">
                           <i class="material-icons">directions_car</i> Car Break-In
                           </a>
                        </li>
                        <li>
                           <a href="/two-wheeler-insurance">
                           <i class="material-icons">motorcycle</i> 2 Wheeler Insurance
                           </a>
                        </li>
                         <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/twonline/newbusiness/calculatepremium.aspx?RefEnc=R7NEApW5FTVIFJgyOV0h4Q==" target="_blank">
                           <i class="material-icons">motorcycle</i> 2 Wheeler Break-In
                           </a>
                        </li>
                        <li>
                           <a href="/health-insurance">
                           <i class="material-icons">local_hospital</i> Health Insurance
                           </a>
                        </li>
                        <li>
                           <a href="https://www.hdfcergo.com/OnlineProducts/MedisureOnline/HSTOP/CalculatePremium.aspx?ref=MSD00012" target="_blank">
                           <i class="material-icons">local_hospital</i> Health Super Topup
                           </a>
                        </li>
                        
                        <li>
                           <a href="/travel-insurance">
                           <i class="material-icons">flight</i> Travel Insurance
                           </a>
                        </li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                     <i class="material-icons">view_carousel</i>Tutorials
                     <b class="caret"></b>
                     </a>
                     <ul class="dropdown-menu dropdown-with-icons">
                        <li>
                           <a href="https://youtu.be/D8cCRHULGkw" target="_blank">
                           <i class="material-icons">directions_car</i> Car Insurance
                           </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/3AafISYacbs" target="_blank">
                           <i class="material-icons">motorcycle</i> 2 Wheeler Insurance
                           </a>
                        </li>
                         <li>
                           <a href="https://youtu.be/3OH80rd8QQ8" target="_blank">
                           <i class="material-icons">motorcycle</i> 2 Wheeler Break-In
                           </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/80rhcyoXoZ8" target="_blank">
                           <i class="material-icons">local_hospital</i> Health Insurance
                           </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/dxi0J31DSqQ" target="_blank">
                           <i class="material-icons">local_hospital</i> Health Super Topup
                           </a>
                        </li>
                        <li>
                           <a href="https://youtu.be/8530kB0-fTI" target="_blank">
                           <i class="material-icons">flight</i> Travel Insurance
                           </a>
                        </li>
                     </ul>
                  </li>
                   <li>
                     <a href="/blog" target="_blank" style="text-align: left">
                     <i class="material-icons">art_track</i> Blog
                     </a>
                  </li>
                  <li>
                     <a href="/faqs" target="_blank" style="text-align: left">
                     <i class="material-icons">question_answer</i> Faq
                     </a>
                  </li>
                  <li>
                     <a target="_blank" style="text-align: left" href="/premium-calculator">
                     <i class="material-icons">exposure</i> Calculator
                     </a>
                  </li>
                  <li id="refresh_div" @if(empty(session('user_agent'))) class="hide" @endif>
                    <a href="{{route('car.car_refresh')}}" style="text-align: left" id="refresh_quote">
                      <i class="material-icons">refresh</i>Refresh
                    </a>
                  </li>
                  <li id="login_div" @if(!empty(session('user_id'))) class="hide" @endif>
                    <a href="javascript:void(0);" data-toggle="modal" data-target="#login_modal" style="text-align: left" id="login">
                      <i class="material-icons">lock_open</i> Login
                    </a>
                  </li>
                  <ul class="nav navbar-nav @if(empty(session('user_id')))hide  @endif" id="user_section">
                     <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="material-icons">account_box</i><span id="user_name">@if(!empty(session('username'))) {{session('username')}}@else Customer @endif</span>
                        <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-with-icons">
                           <li id="change_password" @if(empty(session('user_id'))) class="hide" @endif>
                             <a href="javascript:void(0);" style="text-align: left" data-toggle="modal" data-target="#change_password_modal" >
                               <i class="material-icons">account_circle</i> Change password
                             </a>
                           </li>
                           <li id="agent_dashboard" @if(empty(session('user_agent'))) class="hide" @endif>
                             <a href="{{route('agent_dashboard')}}" style="text-align: left">
                               <i class="material-icons">dashboard</i> Dashboard
                             </a>
                           </li>
                           <li id="daily_report" @if(empty(session('user_agent'))) class="hide" @endif>
                             <a href="{{route('agent_daily_report')}}" style="text-align: left">
                               <i class="material-icons">file_download</i> Daily Report
                             </a>
                           </li>
                           <li id="logout_div" @if(empty(session('user_id'))) class="hide" @endif>
                             <a href="javascript:void(0);" style="text-align: left" id="logout" data-url="{{URL::route('customer.logout')}}">
                               <i class="material-icons">lock</i> Logout
                             </a>
                           </li>
                        </ul>
                     </li>
                  </ul>
                  <li>
                     <a class="helpline">
                     <i class="material-icons">call</i> +91 7899-000-333
                     </a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      @include('layouts.login_registration');
