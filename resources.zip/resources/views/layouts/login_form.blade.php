<div id="login_hide">
    <div style="margin:5%;">
        <div class="row loginformstyle">
            <form id="loginForm" method="POST"action="{{URL::route('customer.login')}}" novalidate="novalidate">
                {{csrf_field()}}
                <div class="form-group">
<!--                     <label for="username" class="control-label">Mobile Number</label>
 -->                    <input type="text" class="form-control" id="login_mobile_number" name="login_mobile_number" value="" required="" title="Please enter your registered mobile number" placeholder="Enter your Registered Mobile Number">
                    <span class="help-block"></span>
                    <span class="has-error" id="email_error"></span>
                </div>
                <div class="form-group">
<!--                     <label for="password" class="control-label">Password</label>
 -->                    <input type="password" class="form-control" id="password" name="password" value="" required="" title="Please enter your password" placeholder="Enter Your Password">
                    <span class="help-block"></span>
                    <span class="has-error" id="password_error"></span>
                </div>
                <div id="loginErrorMsg" class="alert alert-error hide">Wrong mobile number or password</div>
                {{-- <div class="checkbox">
                    <label>
                        <input type="checkbox" name="remember" id="remember"> Remember login
                    </label>
                    <p class="help-block">(if this is a private computer)</p>
                </div> --}}
                <div class="text-center">
                  <button type="submit" id="login_button" class="btn btn-success input-block-level">Login</button>
                </div>
            </form>
        </div>
        <div class="row loginoptions">
            <a href="javascript:void(0);" id="register_modal" data-url="{{URL::route('customer.registerForm')}}" class="pull-left">Register Here</a>
            <a href="javascript:void(0);" id="forgot_password" data-url="{{URL::route('customer.passwordForgetForm')}}" class="pull-right">Forgot Password</a>
        </div>
    </div>
</div>
