<!-- Modal -->

<div class="modal fade loginformstyle" id="change_password_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel">Change your Password.</h4>
      </div>
      <div class="modal-body">
        <form id="change_password_form" action="{{URL::route('customer.changePassword')}}">
          <div class="form-group">
              <input type="password" class="form-control" id="old_password" name="old_password" value="" required="" title="Please enter you old password" placeholder="Old Password">
              <span class="help-block"></span>
              <span class="has-error" id="old_password_error"></span>
          </div>
          <div class="form-group">
              <input type="password" class="form-control" id="new_password" name="new_password" value="" required="" title="Please enter you new password" placeholder="New Password">
              <span class="help-block"></span>
              <span class="has-error" id="new_password_error"></span>
          </div>
          <div class="form-group">
              <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="" required="" title="Please confirm your password" placeholder="Confirm New Password">
              <span class="help-block"></span>
              <span class="has-error" id="confirm_password_error"></span>
          </div>
          <button type="button" id="change_password_button" class="btn btn-success btn-block">Change Password</button>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade loginstyle" id="login_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div id="login-overlay" class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
              <h4 class="modal-title" id="myModalLabel"><span class="glyphicon glyphicon-arrow-left hide" id="back_login" data-url="{{URL::route('customer.loginForm')}}" aria-hidden="true"></span> Login to <b style="color: #00669c"> <i>InstaInsure.com!</i></b></h4>
          </div>
          <div class="modal-body">
              <div class="row">
                  <div class="col-md-10 col-md-offset-1">
                      <div class="well login_registration_body" id="login_registration_body">
                          @include('layouts.login_form')
                          @include('layouts.registration_form')
                          @include('layouts.forget_password_form')
                      </div>
                  </div>
                  {{-- <div class="col-xs-6">
                      <p class="lead">Register now for <span class="text-success">FREE</span></p>
                      <ul class="list-unstyled" style="line-height: 2">
                          <li><span class="fa fa-check text-success"></span> See all your Policies</li>
                          <li><span class="fa fa-check text-success"></span> Fast renew</li>
                          <li><span class="fa fa-check text-success"></span> Save your favorite quotes</li>
                          <li><span class="fa fa-check text-success"></span> Fast checkout</li>
                          {{-- <li><span class="fa fa-check text-success"></span> Get a gift <small>(only new customers)</small></li> --}}
                          {{-- <li><a href="/read-more/"><u>Read more</u></a></li> --}}
                    {{--  </ul>
                      <form id="registrationForm" action="{{URL::route('customer.registration')}}">
                        <label for="username" class="control-label">Email Id</label>
                           <input type="text" class="form-control" id="register_email" name="register_email" value="" required="" title="Please enter you username" placeholder="example@gmail.com">
                        <span class="help-block"></span>
                        <span class="has-error" id="registration_error"></span>
                           <input type="button" class="btn btn-info btn-block" id="register" name="register" value="Register" required="" title="Please enter you username" placeholder="example@gmail.com">
                        <span class="help-block"></span>
                      </form>
                      {{-- <p><a href="/new-customer/" class="btn btn-info btn-block">Register</a></p> --}}
                {{-- </div> --}}
              </div>
          </div>
      </div>
  </div>
</div>
