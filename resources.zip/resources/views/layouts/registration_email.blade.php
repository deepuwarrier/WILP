@include('layouts.email_header_template')
@section('title', 'Thank You for registering at InstaInsure.com')                                                                                                	
	<p>Dear {{$name}},</p>
	<p>Welcome to InstaInsure.com!</p>
	<p>At InstaInsure, you have a trusted companion for all you Insurance needs.</p>
	<p>Few things you can do with InstaInsure.com<p>
	<ol>
		<li>
			Generate a Quote - Start Buying a Car/Bike/Travel/Health Insurance policy right away – <a href="https://www.instainsure.com/">Click Here</a>
		</li>
		<li>
			Plan Ahead - Calculate an approximate total Insurance premium required to secure all your valuable assets – <a href="https://www.instainsure.com/premium-calculator">Click here</a>
		</li>
		<li>
			Resume Anytime – At every stage we have your progress saved. A single click lets you resume from where you left off.
		</li>
		<li>
			Share – You can share the insurance quote with your family for their opinion.
		</li>
		<li>
			Help – You can refer us to your friends and help them save money by buying insurance through InstaInsure. Yes, we are more economical than anyone else around.
		</li>
		<li>
			Be served – Be pamperedbythe finest service from our customer support team.
		</li>
	</ol>
	<p>
		So why wait any longer? Get going!
	</p>
	@include('layouts.email_footer_template')
