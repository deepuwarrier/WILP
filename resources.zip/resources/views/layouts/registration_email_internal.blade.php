<html>
<head>
	<title>New user Registered</title>
</head>
<body>
	<p>Hello,</p>
	<p>A new user has been registered to instainsure.com and his details are as follows</p>
	<ol>
		<li>Username : {{$name}}</li>
		<li>Email address : {{$email}}</li>
		<li>Mobile-number : {{$number}}</li>
	</ol>
</body>
</html>