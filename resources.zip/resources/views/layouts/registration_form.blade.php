<!-- Modal -->
<div class="hide" id="regi_hide" style="margin:5%;">
<p class="lead">Registration is <span class="text-success">Free</span> and <span class="text-success">Easy!</span></p>

<form id="registrationForm" method="POST" action="{{URL::route('customer.registration')}}">
  {{csrf_field()}}
  <input type="text" class="form-control" id="register_name" name="register_name" value=""  title="Please enter you name" placeholder="Your Name">
  <span class="help-block"></span>
  
  <input type='hidden' name='otp_gen' id='otp_gen' value="{{route('car.policy.gen_otp')}}">
  <input type='hidden' name='very_otp' id='very_otp' value="{{route('car.policy.very_otp')}}">
  <input type="text" class="form-control" id="register_mobile_number" name="register_mobile_number" value=""  title="Your Valid Mobile Number" placeholder="Valid 10 Digit Mobile Number">
  <span class="help-block"></span>
  
  <input type="text" class="form-control" id="register_email" name="register_email" value="" title="Please enter you email address" placeholder="Your Email ID">
  <span class="help-block"></span>
  
  <input type="password" class="form-control" id="register_password" name="register_password" value=""  title="Please enter you password" placeholder="Enter a Password">
  <span class="help-block"></span>

{{--
  <input type="password" class="form-control" id="register_confirm_password" name="register_confirm_password" value=""  title="Confirm Your Password">
  <span class="help-block"></span>
  <span class="has-error" id="registration_error"></span> --}}
  
  <input type="submit" class="btn btn-info btn-block" id="user_registration_form" name="user_registration_form" value="Register"  title="Please enter you username" placeholder="example@gmail.com">
  <span class="help-block"></span>
</form>

</div>
