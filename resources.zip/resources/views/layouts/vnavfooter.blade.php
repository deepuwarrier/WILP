<nav id="cd-vertical-nav">
         <ul>
            <li>
               <a href="#home" data-number="1">
               <span class="cd-dot"></span>
               <span class="cd-label">Home</span>
               </a>
            </li>
            <li>
               <a href="#legacy" data-number="2">
               <span class="cd-dot"></span>
               <span class="cd-label">Legacy</span>
               </a>
            </li>
            <li>
               <a href="#whyus" data-number="3">
               <span class="cd-dot"></span>
               <span class="cd-label">Why Us?</span>
               </a>
            </li>
            <li>
               <a href="#testimonials" data-number="4">
               <span class="cd-dot"></span>
               <span class="cd-label">Testimonials</span>
               </a>
            </li>
            <li>
               <a href="#blogs" data-number="5">
               <span class="cd-dot"></span>
               <span class="cd-label">Blogs</span>
               </a>
            </li>
            <li>
               <a href="#team" data-number="6">
               <span class="cd-dot"></span>
               <span class="cd-label">Team</span>
               </a>
            </li>
            <li>
               <a href="#contactus" data-number="7">
               <span class="cd-dot"></span>
               <span class="cd-label">Contact Us</span>
               </a>
            </li>
         </ul>
      </nav>
      <script src="{{URL::asset('js/vertical-nav.js')}}" type="text/javascript"></script>
      


