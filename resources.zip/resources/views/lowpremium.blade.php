@include('layouts.header')

<div class="page-header blog-style">
         <div class="container" style="text-align: justify;">
            <div class="row">
               <div class="col-md-12">
                  <ol class="breadcrumb">
                     <li><a href="/">InstaInsure.com</a></li>
                     <li><a href="/blog">Blog Home</a></li>
                     <li class="active">Car Insurance</a></li>
                     <li class="active">Be Aware! Low Premium ahead!</li>
                  </ol>
                  <div class="card card-background" style="background-image: url('/image/blog/lowpremium/lowpremium.png'">
                     <div class="content" style="padding-top: 80px">
                        <h2 class="dark">Be Aware! Low Premium ahead!</h2>
                     </div>
                  </div>
                  <blockquote>
                     <p>
                        "Food, grocery, travel and anything that you can think of is now available for us to buy online. Buying Insurance online, too has become a convenient task and quite beneficial too. The insurance companies offer huge discounts when purchased online due to lower acquisition costs. But hold on! Everything that glitters is not gold.”
                     </p>
                  </blockquote>
               </div>
               <div class="col-md-12">
                  <h3 class="title light">Read on:</h3>
                  <p>The cost of your insurance (called “Premium”) that appear on your screen may be the result of a thrashed down IDV (Insured Declared Value). IDV, also known as Sum Insured is the assumed market value of your vehicle. If your vehicle was to be stolen or meets with an accident where the entire vehicle is lost, IDV is the maximum amount the insurance company will pay you.</p>
                  <p>IRDAI, who governs the Indian Insurance Industry has also defined a set of process to determine the value of your vehicle, year on year. This is understandable because there is a constant percentage reduction in the value of your car every year.</p>
                  <p>But the story does not end there. Let’s now get to the trick of low Premiums!</p>
                  <p></p>
                  <p>One factor that you may have to pay attention to, on the portal is the IDV.</p>
                  <p>You might knowingly or unknowingly choose the lowest price, without realizing what IDV that price is charged on. If the low price is being offered at the cost of a low IDV, it might actually mean a significant loss to you. We have been told time and again that Insurance itself is an instrument to avoid risks. However, by taking a lower IDV, you are being exposed to a risk, even while avoiding the risk.</p>
                  <p>So the trick is revealed. If an online portal wants to show you rock bottom prices, what do they do? Simple! Reduce the value of your car, way below the market rate.</p>
                  <p>Don’t fall for it!</p>
                  <p>What if you are not sure how to fix the IDV for your vehicle? We have a simple solution. Think that – if you were to sell off your car today, what price would you sell it for? Now, try to set an IDV closer to that price. Though the IDV edit option is hidden in almost all the online portals, find it, change it to your wish and re check the premiums. You will surely be in for a surprise!</p>
                  <p>Ok now, if you really want to reduce the premium without compromising on IDV, here is the deal. Don’t raise small claims – you will lose your long accumulated NCB in the run for getting a small claim. Install an anti-theft device – it reduces your premium. And better still, transfer the NCB of your old vehicle to your new vehicle – the NCB is for the owner, not the car!</p>
                  <p>If you still want to reduce your IDV in the bargain for a lower premium, go ahead, but be warned and drive safe!</p>
                  <div class="card card-blog">
                  <h3 style="color: #00669c">Feeling More Confident to Buy Insurance Online?</h3>
                  <h5>Try Generating a Car Insurance Quote Now. Its Super Quick and Simple!</h5>
                  <a href="/car-insurance" target="_blank" class="btn btn-success">Generate a Quote</a>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="row">
                     <div class="col-md-12" style="text-align: left">
                        <div class="blog-tags" style="padding-top: 20px;">
                           Tags:
                           <span class="label label-primary">Toyota Tsusho Insurance Broker India Pvt Ltd</span>
                           <span class="label label-primary">InstaInsure</span>
                           <span class="label label-primary">Insurance Broker</span>
                           <span class="label label-primary">Depreciation</span>
                           <span class="label label-primary">IDV during renewal</span>
                           <span class="label label-primary">IRDAI</span>
                           <span class="label label-primary">Private Car Insurance</span>
                           <span class="label label-primary">Car Insurance Renewal</span>
                           <span class="label label-primary">TTIBI</span>
                        </div>
                     </div>
                  </div>
                  <hr>
                  <h4 class="card-title">Author : Bindu Madhavi</h4>
                  <p class="description">Bindu Madhavi, a part of the InstaInsure team has seen the fight for lower premiums and thought this article on IDV might help reduce the ignorance in at least a small fraction of the people. If you need help with choosing the right policy for you, email us at support@instainsure.com or call us on +91 7899-000-333. We will help you clear your queries and assist you in the purchase process as well. </p>
                  <div class="col-xs-8 hidesection" style="padding:20px 0;">
                     <div class="form-group is-empty"><input value="" placeholder="Email this blog" class="form-control" type="email"><span class="material-input"></span></div>
                  </div>
                  <div class="col-xs-1 hidesection">
                     <button type="button" class="btn btn-primary btn-just-icon" name="button">
                     <i class="material-icons">mail</i>
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>

<br><br>
<hr>

@include('layouts.footer')

