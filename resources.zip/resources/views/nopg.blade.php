@include('layouts.header')
<div class="wizard-container">
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="image/spark.gif" alt="Error" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h1 class="card-title" style="color: #00669C;">We tried our best!</h1>
         <h4 class="card-title" style="color: #00669C;">But somehow, we could not get you across! </h4>
         <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5>

         <button type="submit" class="btn btn-success">Home</button>
      </div>
   </div>
</div>
<br><br>
<hr>
@include('layouts.footer')