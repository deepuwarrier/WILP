@include('layouts.header')
<link rel="shortcut icon" type="image/x-icon" href="//production-assets.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" />
<link rel="mask-icon" type="" href="//production-assets.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" />
<link rel="canonical" href="http://codepen.io/Arhax/pen/rWjgoY" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:100,300,400,600" rel="stylesheet" type="text/css">
<link href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css">
<link href="/css/calc.css" rel="stylesheet" type="text/css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/common.js"></script>
<script src="/js/jquery.validate.min.js"></script>
<script src="/js/calc.js"></script>
<header class="business-header"><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 budget  text-center">
                <h4 class="insta-calc-title"> Your one stop place to calculate your Insurance Requirements</h3>
                <hr>
                 <div class="col-lg-6 col-md-6">
                <div class="budget__title">
                    Your Total Assets Value <span class="budget__title--month" style="display:none;"></span>:
                </div>
                     <div class="budget__value total_value">₹<span id="budget_total_value"><?= isset($total_value) ? number_format(ceil($total_value)) : 0 ;?></span></div>
                 </div>
                <div class="col-lg-6 col-md-6">
                <div class="budget__title">
                    Approx Insurance Cost :
                </div>
                <div class="budget__value insure_value">₹<span id="budget_insure_value"><?= isset($insure_value) ? number_format(ceil($insure_value)) : 0 ;?></span></div>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="row add">
            <div class="col-xs-12 col-md-offset-3 col-sm-6 col-md-4 ">
                    <?php if(isset($product_data) && count($product_data) > 0){ ?>
                    <select class="add__description input-lg input-sm input-xs col-xs-12 col-sm-12" id="product_id" >
                        <option value="" selected="selected" disabled="disabled">Please add your assets</option>
                        <?php foreach ($product_data as $value){ 
                            ?>
                        <option value="<?php echo $value->calc_product_id; ?>" ><?php echo $value->product; ?></option>
                        <?php } ?>
                       <?php  ?>
                    </select>
                    <?php } ?>
            </div>
            <div class="col-xs-12 col-sm-6  col-md-5 ">
                <div class="col-xs-10 col-sm-6  col-md-3 no-padding">
                <input id="product_value" class="col-xs-12 add__value" placeholder="Value" type="number">                    
                </div>
                <div class="col-xs-2 col-sm-2 col-md-9  pull-left">
                    <button class="add__btn" type="button" onclick="add_product();">
                            <i class="ion-ios-checkmark-outline"></i>
                    </button>
                </div>
            </div>            
                
                      {{ csrf_field() }}
                    
        </div>
    <div id="calc_list">
        <div class="container">
            <?php if(isset($category_data) && count($category_data) > 0){ ?> 
            <?php foreach ($category_data as $category){ ?>
            <div class="col-sm-4">
             <div class="car text-center">
            <h2 class="car__title"><?=$category->category;?> Insurance</h2>
            <div class="home__list row">   
            <?php if (isset($products) && count($products) > 0) { ?>
            <div class="car__list col-xs-12">
                <?php
                foreach ($products as $value) { 
                    if($value->calc_category_id == $category->calc_category_id){
                    ?>
                    <div id="car-0" class="item clearfix row">
                        <input type="hidden" id="product_<?=$value->calc_product_id;?>" value="<?=$value->product_value;?>">
                        <div class="col-xs-4 text-left"><?=$value->product;?></div>
                        <div class="col-xs-8">
                            <div class="col-xs-5">₹<?=number_format(ceil($value->product_value));?></div>
                             <div class="col-xs-1 no-padding">
                                <button class="item__delete--btn " type="button" onclick="remove_product('<?=$value->calc_product_id;?>','<?=$value->product_value;?>')">
                                    <i class="ion-ios-close-outline"></i>
                                </button>
                            </div>
                         <a href="<?=$category->link;?>" target="_blank" class="col-xs-6" >
                                <button class="btn btn-success btn-sm">Get Quote</button>
                            </a>
                           
                        </div>
                    </div>
                <?php }} ?>
            </div>
            <?php } ?>
            </div>
             </div>
        </div>
            <?php }} ?>
	</div>
</div>
<footer>
    <div id="overlay" style="display:none"></div>
    <div class="social-line text-center" style="background-color: #777777;">
        <div class="col-md-12">
            <h4 style="color: white;">Take the <b>Right Step! </b>Secure <i>Your Assets</i>.</h4>
        </div>
        <a href="/#contactus" target="_blank"><button class="btn btn-success btn-md">Contact us</button></a>
        <button class="btn btn-success btn-md"  data-toggle="modal" data-target="#emailthis_modal">Email this</button>
    </div>
    
</footer>
    
 <div class="modal fade" id="emailthis_modal" tabindex="-1" role="dialog" 
     aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" 
   data-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel"> E-mail This</h4>
</div>
            <div class="modal-body">
                <form id="emailthis_form" action="" method="post">
                    {{ csrf_field() }}
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                        <input type="email" id="email" name="email" class="form-control" placeholder="your@email.com">
                    </div>
                    <br />
                    <button type="button" value="sub" name="sub" class="btn btn-primary" onclick="send_email();"><i class="fa fa-share"></i> Send </button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


@include('layouts.footer')

