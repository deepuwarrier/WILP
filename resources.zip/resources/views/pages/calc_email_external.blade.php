<html>
    <head>
        <title>Premium Calculator</title>
        <!-- Bootstrap core CSS     -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
    </head>
    <body>
    <p>Hello!</p>

    <p>Congratulations. You have taken a step in the right direction by calculating an approximate Insurance premium to protect your valuable assets! </p>
        <div class="container">
            <div class="row">
                <table class="table panel panel-primary">
                    <tr class="panel-heading">
                        <th colspan='2' class="panel-title">your Insurance Requirements</th>
                    </tr>
                    <tr>
                        <td>
                            Your Total Assets Value 
                        </td>
                        <td>
                           &#8377; <?php echo isset($total_value) ? ceil($total_value) : 0 ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Approx Insurance Cost
                        </td>
                        <td>
                           &#8377; <?php echo isset($insure_value) ? ceil($insure_value) : 0 ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="row">&nbsp;</div>
            @foreach($category_data as $key=>$value)
            <?php
            if (isset($products) && count($products) > 0) {
                foreach ($products as $value1) {
                    if ($value->calc_category_id == $value1->calc_category_id) {
                        ?>
                        <div class="row">
                            <table class="table panel panel-primary">
                                <tr class="panel-heading">
                                    <th class="panel-title"> {{$value->category}}</th>
                                    <td>{{$value1->product}}</td>
                                    <td>&#8377; {{ceil($value1->product_value)}}</td>
                                </tr>
                            </table>
                        </div>
                        <?php
                    }
                }
            }
            ?>
            @endforeach
        </div>
        <p>It’s never too late to protect your assets! Buy Insurance now. </p>
        <p>Please contact us if you would like to get expert advice before deciding on your insurance requirements.</p>
        <p>InstaInsure Customer Support Team: </p>
        <p>Whatsapp/ Call/ SMS : +91 7899-000-333 |  Email : support@instainsure.com</p>
        <p>For escalations email deepak@instainsure.com</p>
        <p>Disclaimer: The above premiums are only an approximation based on our analytics. The actual premiums are bound to vary as per your actual data.</p>
        <p>InstaInsure.com is a digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI). IRDAI Composite License No: 431 Valid upto 01/09/2017. Insurance is the subject matter of solicitation.</p>
    </body>
</html>
