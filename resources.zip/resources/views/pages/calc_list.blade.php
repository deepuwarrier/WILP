<div class="container">
            <?php if(isset($category_data) && count($category_data) > 0){ ?> 
            <?php foreach ($category_data as $category){ ?>
            <div class="col-sm-4">
             <div class="car text-center">
            <h2 class="car__title"><?=$category->category;?> Insurance</h2>
            <div class="home__list row">   
            <?php if (isset($products) && count($products) > 0) { ?>
            <div class="car__list col-xs-12">
                <?php
                foreach ($products as $value) { 
                    if($value->calc_category_id == $category->calc_category_id){
                    ?>
                    <div id="car-0" class="item clearfix row">
                        <input type="hidden" id="product_<?=$value->calc_product_id;?>" value="<?=$value->product_value;?>">
                        <div class="col-xs-4 text-left"><?=$value->product;?></div>
                        <div class="col-xs-8">
                            <div class="col-xs-5">₹<?=number_format(ceil($value->product_value));?></div>
                             <div class="col-xs-1 no-padding">
                                <button class="item__delete--btn " type="button" onclick="remove_product('<?=$value->calc_product_id;?>','<?=$value->product_value;?>')">
                                    <i class="ion-ios-close-outline"></i>
                                </button>
                            </div>
                         <a href="<?=$category->link;?>" target="_blank" class="col-xs-6" >
                                <button class="btn btn-success btn-sm">Get Quote</button>
                            </a>
                           
                        </div>
                    </div>
                <?php }} ?>
            </div>
            <?php } ?>
            </div>
             </div>
        </div>
            <?php }} ?>
	</div>