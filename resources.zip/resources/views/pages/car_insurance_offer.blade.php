@include('car.layouts.inn-hdr')
  <link rel="stylesheet" type="text/css" href="{{ asset('css/infocard.css') }}"/>
<div class="page-header" id="home" style="background-color: white">
         <div class="container" style="padding-left:5px; padding-right: 5px;">
         
                 <section class="products_intro">
                  <div data-aos="slide-down" data-aos-duration="500" class="contain_very_small">
                     <h1 style="color: #92cf1b">InstaInsure.com</h1>
                     <h3>Avail your Guaranteed 60% off on Car Insurance</h3>
                     <p style="color: #ababab">You get a Comprehensive Insurance Policy bundled with a Free claims assistance package and a dedicated Insurance Consultant.</p>
                  </div>
               </section>
                <div class="col-sm-6">
               <img src="/image/car-deal.gif" class="img-responsive" alt="Car Insurance Deal">

               </div>

               <div class="col-sm-6 padtopoffer" id="carInsuranceOffer">
                <div class="card card-contact">
                     <form role="form" id="carInsuranceOfferForm" method="post" action="{{ URL::route('pages.car_insurance_offer_form')}}"> 
                        {{ method_field('POST') }}
                        {{csrf_field()}}
                        <div class="header header-raised header-primary text-center">
                           <h4 class="card-title">Unlock the Deal</h4>
                        </div>
                        <div class="content">
                                 <div class="form-group label-floating">
                                    <label class="control-label">Your Mobile Number</label>
                                    <input type="text" id="car_offer_mobile" name="car_offer_mobile" class="form-control">
                                 </div>
                           <div class="form-group label-floating padtop">
                              <label class="control-label padtop">Your Email address</label>
                              <input type="email" name="car_offer_email" id="car_offer_email" class="form-control"/>
                           </div>
                           <div class="form-group label-floating padtop">
                              <label class="control-label padtop">Your Insurance Expiry Month</label>
                              <select class="form-control" name="car_offer_insu_exp_month" id="car_offer_insu_exp_month">
                                <option hidden="" value=""></option>
                                <option value="Jan">Jan</option>
                                <option value="Feb">Feb</option>
                                <option value="Mar">Mar</option>
                                <option value="Apr">Apr</option>
                                <option value="May">May</option>
                                <option value="Jun">Jun</option>
                                <option value="Jul">Jul</option>
                                <option value="Aug">Aug</option>
                                <option value="Sep">Sep</option>
                                <option value="Oct">Oct</option>
                                <option value="Nov">Nov</option>
                                <option value="Dec">Dec</option>
                              </select>
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <button type="button" id="car_insurance_offer_button" class="btn btn-success">Unlock Deal</button> 
                                 <p class="dealinfo"><b>Note:</b> Deal is valid within 6 months from date of unlock.</p>                            
                              </div>
                           </div>
                            <div class="row">
                              <div class="smessage">
                                 
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>

                  
               </div>
               
               <div class="row">
               <div class="homelogobox">
                  @include('layouts.c_partners')
              </div>
              </div>
            
            
         </div>
  <div class="">
    <h2 style="text-align: center" data-aos="zoom-in-up" data-aos-duration="600" class="title">Some Interesting Flips</h2>
    <div class="infocardsection features-1 col-lg-3">@include('car.layouts.c_car_basics')</div>
    <div class="infocardsection features-1 col-lg-3">@include('car.layouts.c_car_calculator')</div>
    <div class="infocardsection features-1 col-lg-3" >@include('car.layouts.c_car_ins_companies')</div> 
  </div>
  <div class="infocardsection features-1 col-lg-3">@include('car.layouts.c_car_addons')</div>
</div>
<div class="features-1">@include('layouts.c_legacy')</div>
<div class="features-5">@include('layouts.c_whyus')</div>
<div class="testimonials-2 section-image">@include('layouts.c_testimonial')</div>
@include('car.layouts.inn-ftr')

 <script src="{{URL::asset('js/jquery.isonscreen.js')}}" type="text/javascript"></script>

 <script type="text/javascript">
   $('#generalenuiry').submit(function(event) {
      var error = 0;
      $('.requiredField').each(function() {
         var id = $(this).attr('id');
         var value = $('#'+id).val();
         if (value === '' || typeof value === "undefined") {
            $(this).parent().addClass('has-error is-focused')
            error = 1;
         } else {
            error = 0;
         } 
      });
      if(error=== 0){
         $(this).find('button[type=submit]').prop('disabled', true);
         var data = $('#generalenuiry').serialize();
         $.ajax({
            url: '/sendmail',
            type: 'POST',
            data: data,
            success:function(data){
               $('#success_message').html(data.message);

            }
         });      
      }
      return false;
   });
</script>
<script>
$('input').bind('focus', function() {
  $(this).parent('.field').css({ 'background-color' : '#f5f8f9'});
});
$('input').bind('blur', function() {
  $(this).parent('.field').css({ 'background-color' : 'none'});
});

</script>

 
