@include('layouts.header')
   <div class="container">
   
      @foreach($insta_products as $product)
         <div class="row" class="col-md-12">
        
         @if(isset($product['image']) && !empty($product['image']))
         <!--  Product Image  -->
            <div class="col-md-4">
               <h2 class="title dark">Get in Touch</h2>
               <h5 style="color:black;" class="description">Product Image</h5>
               <div class="icon icon-primary">
                  <img style="width:50%;" src="{{URL::to('/')}}/image/uploads/{{ $product['image'] }}">
               </div>
           </div> 
         @endif

         <!-- Product Unique features  -->
            <div class="col-md-4">
               <h2 class="title dark">Get in Touch</h2>
               <div class="description">
                  <h5 style="color:black;" class="description">Unique Features</h5>
                  <?php $unique_features = explode(',', $product['unique_features']); ?>
                  @foreach($unique_features as $features)
                     <p style="color:black;"> &#9672; {{$features}}</p>
                  @endforeach
               </div>
            </div>

         <!-- Products price and emi details -->
            <div class="col-md-4">
               <h2 class="title dark">Get in Touch</h2>
               <div class="description">
                  <h5 style="color:black;" class="description">Product Details</h5>
                  <p class="info-title">Title: {{$product['product_name']}} </p>
                  <p class="info-title">Price:  &#x20B9; {{$product['price']}} </p>
                  <p class="info-title">EMI:  {{$product['emi_details']}} </p>
                  <button type="button" class="btn btn-primary">Buy Now</button>  
               </div>                               
            </div>
         </div>


         <div class="row" class="col-md-12">
            <div class="col-md-4">
             <!-- Inclusions in product -->
                  <h2 class="title dark">Get in Touch</h2>
                  <div class="description">
                     <h5 style="color:black;" class="description">Inclusions in product</h5>
                     <?php $product_inclusion = explode(',', $product['inclusion']); ?>
                     @foreach($product_inclusion as $inclusion)
                        <p style="color:black;"> {{$inclusion}}</p>
                     @endforeach
                  </div>

             <!-- Exclusions in product -->
                  <h2 class="title dark"></h2>
                  <div class="description">
                     <h5 style="color:black;" class="description">Exclusions in product</h5>
                     <?php $product_exclusion = explode(',', $product['exclusion']); ?>
                     @foreach($product_exclusion as $exclusion)
                        <p style="color:black;"> {{$exclusion}}</p>
                     @endforeach
                  </div>
            </div>


             <div class="col-md-4">
             <!-- Who should Buy this product -->
               <h2 class="title dark">Get in Touch</h2>
               <div class="description">
                  <h5 style="color:black;" class="description">Who should buy ?</h5>
                  <?php $product_should_buy = explode(',', $product['should_buy']); ?>
                  @foreach($product_should_buy as $should_buy)
                     <p style="color:black;"> {{$should_buy}}</p>
                  @endforeach
               </div>

               <!-- Who should not Buy this product -->
               <h2 class="title dark"></h2>
               <div class="description">
                  <h5 style="color:black;" class="description">Who should not buy ?</h5>
                  <?php $product_should_not_buy = explode(',', $product['should_not_buy']); ?>
                  @foreach($product_should_not_buy as $should_not_buy)
                     <p style="color:black;"> {{$should_not_buy}}</p>
                  @endforeach
               </div>
            </div>
         </div>


<!-- Example video -->
         @if(isset($product['video']) && !empty($product['video']))
           <div class="row" class="col-md-12">
               <h2 class="title dark">Get in Touch</h2>
               <div class="description">
                  <h5 style="color:black;" class="description">Example Video</h5>
                  <iframe width="1000" height="315" src="{{$product['video']}}" frameborder="0" allowfullscreen></iframe>
               </div>
            </div> 
            @endif
            
      @endforeach
   </div>
@include('layouts.footer')
