@include('layouts.header')

<p>&nbsp;</p>
<link rel="shortcut icon" type="image/x-icon" href="//production-assets.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" />
<link rel="mask-icon" type="" href="//production-assets.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" />
<link rel="canonical" href="http://codepen.io/Arhax/pen/rWjgoY" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:100,300,400,600" rel="stylesheet" type="text/css">
<link href="https://www.instainsure.com/css/ionicons.min.css" rel="stylesheet" type="text/css">
<link type="text/css" rel="stylesheet" href="style.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/calc.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<div class="top" >
    <div class="budget" style="padding-bottom: 20px;">
        <br><h4> Your one stop place to calculate your Insurance Requirements</h4><hr>
        <div class="budget__title">
            Your Total Assets Value <span class="budget__title--month" style="display:none;"></span>
        </div>
        <div class="budget__value">₹ <span id="budget_total_value"><?= isset($total_value) ? $total_value : 0.00 ;?></span></div>
               
        <div class="budget__income clearfix">
            <div class="budget__income--text">Approx Insurance Cost</div>
            <div class="right">
                <div class="budget__income--value">₹ <span id="budget_insure_value"><?= isset($insure_value) ? $insure_value : 0.00 ;?></span></div>
                <div class="budget__income--percentage">&nbsp;</div>
            </div>
        </div>
    </div>
</div>
<div class="bottom">
    <div class="add">
        <div class="row">
            <div class="col-md-offset-3  col-md-3">    
                <div class="form-group">
                    <?php if(isset($product_data) && count($product_data) > 0){ ?>
                    <select class="add__description" id="product_id" >
                        <option value="" selected="selected" disabled="disabled">Please add all your assets</option>
                        <?php foreach ($product_data as $value){ 
                            ?>
                        <option value="<?php echo $value->calc_product_id; ?>" ><?php echo $value->product; ?></option>
                        <?php } ?>
                       <?php  ?>
                    </select>
                    <?php } ?>
                </div>
            </div>
            <div class="col-md-6">    
                <div class="form-group">   
                    {{ csrf_field() }}
                    <input type="number" class="add__value" placeholder="Value" id="product_value">
                    <button class="add__btn" type="button" onclick="add_product();"><i class="ion-ios-checkmark-outline"></i></button>
                </div>
            </div>   
        </div>
    </div>     
</div>         
<div class="container" id="calc_list">
      <?php if(isset($category_data) && count($category_data) > 0){ ?> 
<?php foreach ($category_data as $category){ ?>
<div class="car">
        <h2 class="car__title"><?=$category->category;?> Insurance</h2>
        <div class="home__list">
            <?php if (isset($products) && count($products) > 0) { ?>
            <div class="car__list">
                <?php
                foreach ($products as $value) { 
                    if($value->calc_category_id == $category->calc_category_id){
                    ?>
                    <div id="car-0" class="item clearfix">
                        <input type="hidden" id="product_<?=$value->calc_product_id;?>" value="<?=$value->product_value;?>">
                        <div class="item__description"><?=$value->product;?></div>
                        <div class="right clearfix">
                            <div class="item__value"><?=$value->product_value;?></div>
                            <div class="item__delete">
                                <button class="item__delete--btn " type="button" onclick="remove_product('<?=$value->calc_product_id;?>')">
                                    <i class="ion-ios-close-outline"></i>
                                </button>
                            </div>
                            <a href="<?=$category->link;?>" target="_blank" style="padding-left:10px;">
                                <button class="btn btn-success btn-sm">Get Quote</button>
                            </a>
                        </div>
                    </div>
                <?php }} ?>
            </div>
            <?php } ?>
        </div>
    </div> 
<?php }} ?>
</div>  
<div class="container ext">
    <div class="social-line text-center" style="background-color: #777777;">
        <div class="col-md-12">
            <h4 style="color: white;">Take the <b>Right Step! </b>Secure <i>Your Assets</i>.</h4>
        </div>
        <a href="/#contactus" target="_blank"><button class="btn btn-success btn-md">Contact us</button></a>
        <button class="btn btn-success btn-md">Email this</button>
    </div>
</div>      
</div>     

@include('layouts.footer')

<script src="/js/calc.js"></script>


