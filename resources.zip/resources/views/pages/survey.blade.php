@include('layouts.header')
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<style type="text/css">
    .spacer {
        padding-top: 15px !important;
    }

    .error {
    color:red !important;
    }
</style>

<div class="container">
    <h2 style="text-align: center;">SURVEY</h2> 
    <form autocomplete="off" method="post" action="{{route('submit_health_survey', $agent_id)}}" id="survey_form">
    <div class="col-sm-12">
        <!-- Contact Details -->
        <div class="col-sm-12">
            <strong>Contact Details</strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-4">
                <input class="form-control required show-info" type="text" id="" name="customer_name" placeholder="Name" required>
            </div>
            <div class="col-sm-4">
                <input class="form-control required show-info" type="text" id="" name="customer_mobile" placeholder="Mobile Number" onkeypress="return isNumberKey(event, this)" maxlength="10" required-digit>
            </div>
            <div class="col-sm-4">
                <input class="form-control required show-info" type="text" id="" name="customer_email" placeholder="Email ID" required>
            </div>
            <div class="col-sm-4">
                <input class="form-control required show-info" type="text" id="" name="customer_organisation" placeholder="Organisation" required>
            </div>
            <div class="col-sm-4">
                <select class="form-control valid" aria-invalid="false" id="state" name="state"  onchange='selct_district(this.value)'>
                </select>
            </div>
            <div class="col-sm-4">
                <select class="form-control valid" aria-invalid="false" id="city" name="city">
                    <option selected="" disabled="" value="">Select Your City</option>
                </select>
            </div>
        </div>      
        <div class="col-sm-12 spacer"></div>
        <!-- Question 1 -->
        <div class="col-sm-12">
            <strong>1. You are interested in taking health insurance for</strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">
                <select class="form-control required valid" aria-invalid="false" id="insurance_for" name="insurance_for">
                <option selected="" disabled="" value="">Select you answer*</option>
                <option value="Self">Self Only</option>
                <option value="Family">Your Family</option>
                <option value="Parents">Your Parents</option>
                <option value="Employee">Your Employee</option>
                <option value="Others">Others</option>
                </select>
            </div>
        </div> 
        <div class="col-sm-12 spacer"></div>
        <!-- Question 2 -->
        <div class="col-sm-12">
            <strong>2. Details of family members to be covered under the health insurance policy</strong>
        </div>
        <div class="col-sm-12" id="members">
            <div class="col-sm-4">
                <input class="form-control show-info" type="text" id="" name="membername[]" placeholder="Name">
            </div>
            <div class="col-sm-4">
                <select class="form-control valid" aria-invalid="false" name="memberage[]" id="">
                    <option selected="" disabled="" value="">Select Age*</option>
                    <option value="0">Less than 1 Year</option>
                    @for($i=1; $i<90; $i++) 
                    <option value="{{$i}}">{{$i}} Years</option>
                    @endfor
                </select>
            </div>
            <div class="col-sm-4">
                <select class="form-control valid" aria-invalid="false" id="" name="memberrelationship[]">
                <option selected="" disabled="" value="">Select Relationship*</option>
                <option value="Spouse<">Spouse</option>
                <option value="Son">Son</option>
                <option value="Daughter">Daughter</option>
                <option value="Father">Father</option>
                <option value="Mother">Mother</option>
                <option value="Brother">Brother</option>
                <option value="Sister">Sister</option>
                <option value="Father-In-Law">Father-In-Law</option>
                <option value="Mother-In-Law">Mother-In-Law</option>
                <option value="Others">Others</option>
                </select>
            </div>
        </div>
        <div class="col-sm-6">

            <div class="col-sm-2">
                <input type="button" id="add_members" data-toggle="tooltip" data-placement="top" title="Add Member" class="btn btn-success btn-xs" value="+ Add"/>
            </div>
            <div class="col-sm-3">
                <input type="button" id="remove_members" data-toggle="tooltip" data-placement="top" title="Remove Member" class="btn btn-danger btn-xs" value="- Remove"/>
            </div>

        </div>
        <div class="col-sm-12 spacer"></div>
        <!-- Question 3 -->
        <div class="col-sm-12">
            <strong>3. Do you or any of the family members to be covered for health insurance have any </strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">a. Existing diseases / ailments
            </div>
            <!--
            <div class="col-sm-2">
                <div class="radiobutton">
                    <input type="radio" name="disease" class="required valid" id="disease" value="1" />
                    <label for="disease">Yes</label>
                </div>
                <div class="radiobutton">
                    <input type="radio" name="disease" id="disease_no" value="0" class="required valid" checked="checked" />
                    <label for="disease_no">No</label>
                </div>
            </div>
            -->
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="existing_diseases" placeholder="If Yes, Provide details here">
            </div>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">b. Undergone surgery
            </div>
            <!--
            <div class="col-sm-2">
                <div class="radiobutton">
                    <input type="radio" name="surgery" class="required valid" id="surgery" value="1" />
                    <label for="surgery">Yes</label>
                </div>
                <div class="radiobutton">
                    <input type="radio" name="surgery" id="surgery_no" value="0" class="required valid" checked="checked" />
                    <label for="surgery_no">No</label>
                </div>
            </div>
            -->
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="surgery" placeholder="If Yes, Provide details here">
            </div>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">C. Taking treatment for any health related condition

            </div>
            <!--
            <div class="col-sm-2">
                <div class="radiobutton">
                    <input type="radio" name="treatment" class="required valid" id="treatment" value="1" />
                    <label for="treatment">Yes</label>
                </div>
                <div class="radiobutton">
                    <input type="radio" name="treatment" id="treatment_no" value="0" class="required valid" checked="checked" />
                    <label for="treatment_no">No</label>
                </div>
            </div>
            -->
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="treatment" placeholder="If Yes, Provide details here">
            </div>
        </div>
        <div class="col-sm-12 spacer"></div>
        <!-- Question 4 -->
        <div class="col-sm-12">
            <strong>4. Are you covered under your Employer provided Health Insurance Policy?</strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="employer_si" placeholder="If Yes, Provide the Sum Insured">
            </div>
        </div>   
        <div class="col-sm-12 spacer"></div>
        <!-- Question 5 -->
        <div class="col-sm-12">
            <strong>5. Have you taken any health insurance policy for your family? </strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="existing_si" placeholder="If Yes, Provide the Sum Insured">
            </div>
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="existing_si_since" placeholder="If Yes, Covered Since">
            </div>
        </div> 
        <div class="col-sm-12 spacer"></div>
        <!-- Question 6 -->
        <div class="col-sm-12">
            <strong>6. What is the total amount of Health Insurance cover you are looking for?</strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">
                <input class="form-control show-info" type="text" id="" name="opted_si" 
                placeholder="3,00,000, 5,00,000, 10,00,000 etc">
            </div>
        </div>
        <div class="col-sm-12 spacer"></div>
        <!-- Question 7 -->
        <div class="col-sm-12">
            <strong>7. Type of Plan you are looking for</strong>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-6">
                <select class="form-control valid" aria-invalid="false" name="plan_type" id="">
                <option selected="" disabled="" value="">Select you answer*</option>
                <option value="Regular Health Insurance Policy">Regular Health Insurance Policy</option>
                <option value="Super Top Up">Super Top Up</option>
                <option value="Critical Illness">Critical Illness</option>
                <option value="Not Sure">Not Sure</option>
            </select>
            </div>
        </div>
        <div class="col-sm-12 spacer"></div>
        <div class="col-sm-12">
            <div class="col-sm-12" id="submit_container">
                <button type ='submit' class="btn btn-success pull-right" id="submit_survey">Submit Survey</button>
            </div>
        </div>
        {{ csrf_field() }} 
        </form>
    </div>
</div>
<br>
<br>
<hr> @include('layouts.footer')
<script type="text/javascript" src="{{ URL::asset('js/state.js ') }}"></script>
<script>
(function () {
  var count = 1;
    $('#add_members').click(function() { 
      count += 1;  
      var data = '<span><div class="col-sm-4"><input class="form-control show-info" type="text" id="" name="membername[]" placeholder="Name"></div><div class="col-sm-4"><select class="form-control valid" aria-invalid="false" name="memberage[]" id=""><option selected="" disabled="" value="">Select Age*</option><option value="">Less than 1 Year</option>@for($i=1; $i<90; $i++) <option value="{{$i}}">{{$i}} Years</option>@endfor</select></div><div class="col-sm-4"><select class="form-control valid" aria-invalid="false" id="" name="memberrelationship[]"><option selected="" disabled="" value="">Select Relationship*</option><option value="Spouse<">Spouse</option><option value="Son">Son</option><option value="Daughter">Daughter</option><option value="Father">Father</option><option value="Mother">Mother</option><option value="Brother">Brother</option><option value="Sister">Sister</option><option value="Father-In-Law">Father-In-Law</option><option value="Mother-In-Law">Mother-In-Law</option><option value="Others">Others</option></select></div></span>';  
      if(count<7){
        $('#members').append(data);
      }
    });

    $('#remove_members').click(function() { 
        count--;
        $('#members span:last').remove();
    });

    $('#submit_survey').click(function() { 
        if($('#survey_form').valid()) {
            $('#submit_container').html('<p class="btn btn-success pull-right">Submitting <img src ="{{ URL::asset("image/survey_loader.gif") }}" height ="25" width ="25"/></p>');
            $('#survey_form').submit();
        }
    });
})();    
</script>