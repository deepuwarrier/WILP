@include('layouts.header')

<div class="page-header">
	<div class="container" id="fullteam">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center">
				<h2 style="color: #92cf1b">Our Team</h2>
				<h5 class="description">We derive strength from the people, the
					team, their ideas, passion and hard work.</h5>
			</div>
		</div>

		@foreach ($teamlist as $teamitem)
		<div class="col-md-6" style="padding-bottom: 20px;">
			<div class="card-plain col-md-5">
				<div class="card-image">
					<a> <img class="img" src="image/people/{{$teamitem->team_photo}}" alt="Team InstaInsure" /></a>
				</div>
			</div>
			<div class="col-md-7">
				<div class="content">
					<h4 class="card-title">{{$teamitem->team_name}}</h4>
					<h6 class="category text-muted">{{$teamitem->team_role}}</h6>
					<p class="card-description">{{$teamitem->team_desc}}</p>
				</div>
			</div>
		</div>
		@endforeach

	</div>
</div>

<br><br>
<hr>
@include('layouts.footer')
