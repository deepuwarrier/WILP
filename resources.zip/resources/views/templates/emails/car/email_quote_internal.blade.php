<html>
    <head>
        <title>Qute Page Email</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

      <style type="text/css">
        .panel-primary {
            border-color: #337ab7;
        }
        .panel {
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .table {
            margin-bottom: 20px;
            max-width: 100%;
            width: 100%;
        }
        .row {
            margin-left: -15px;
            margin-right: -15px;
        }
        .panel-heading {
            border-bottom: 1px solid transparent;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            padding: 10px 15px;
        }
        .panel-title {
            color: inherit;
            font-size: 16px;
            margin-bottom: 0;
            margin-top: 0;
        }
      </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
            <table class="table panel panel-primary">
            @foreach($data_list as  $data_key => $data_value)
                <tr class="panel-heading">
                    <td class="panel-title">{!! $data_key !!}</td>
                    <td class="panel-title">{!! $data_value !!}</td>
                </tr>
            @endforeach    
                </table>
        </div>
        </div>
    </body>
</html>
