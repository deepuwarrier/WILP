<html>
<head>
  <title></title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <style type="text/css">
  .whitefont {
      color: white;
  }
  .card [class*="content-"] {
    border-radius: 6px;
  }
  .card [class*="header-"], .card [class*="content-"] {
      color: #FFF;
  }
  .card .header-success, .card .content-success {
      background: linear-gradient(60deg,#66bb6a,#388e3c);
  }
  .card .content {
      padding: 15px 30px;
  }
  .card {
    box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .14), 0 3px 1px -2px rgba(0, 0, 0, .2), 0 1px 5px 0 rgba(0, 0, 0, .12);
  }
  .card {
      margin: 0 0 20px 0;
      border-radius: 3px;
      color: #00669C;
  }
  .card {
      display: inline-block;
      position: relative;
      width: 100%;
      margin-bottom: 30px;
      border-radius: 6px;
      color: rgba(0,0,0,.87);
      background: #fff;
      box-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 rgba(0,0,0,.12);
  }
  .premiumconfirmation {
      min-height: 280px!important;
      display: inline-block;
      padding: 0px!important;
      margin: 0px!important line-height:1.5em;
  }
  </style>
</head>
<body>
  <div class="wizard-container">
    <div class="premiumconfirmation">
      <div class="card">
        <div class="content">
          <p>Dear Customer,</p>
          <p>Congratulations on purchasing an insurance policy through Instainsure.com.</p>
          <p>Insurance company will sent you a copy of your insurance policy in a short while to this email id.</p><p>Meanwhile, if you have any queries, please feel free to contact us at the below coordinates.</p>
          <p>InstaInsure Customer Support Team:</p>
          <p>Whatsapp/ Call/ SMS : +91 7899-000-333 |  Email : support@instainsure.com</p>
          <p>For escalations email deepak@instainsure.com</p>
          <p>InstaInsure.com is a digital initiative of Toyota Tsusho Insurance Broker India Pvt Ltd (TTIBI). IRDAI Composite License No: 431 Valid upto 01/09/2017. Insurance is the subject matter of solicitation.</p>
          </div>
      </div>
    </div>
  </div>
</body>
</html>
