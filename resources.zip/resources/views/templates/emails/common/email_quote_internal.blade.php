<h3>Below is the requested quote url for transaction no :- {{$data_set['transaction_code']}}</h3>
<hr>
{{$data_set['quote_url']}}