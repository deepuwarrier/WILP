<html>
    <head>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>
      <style type="text/css">
.panel-primary {
	border-color: #337ab7;
}

.panel {
	background-color: #fff;
	border: 1px solid transparent;
	border-radius: 4px;
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
	margin-bottom: 20px;
}

.table {
	margin-bottom: 20px;
	max-width: 100%;
	width: 100%;
}

.row {
	margin-left: -15px;
	margin-right: -15px;
}

.panel-heading {
	border-bottom: 1px solid transparent;
	border-top-left-radius: 3px;
	border-top-right-radius: 3px;
	padding: 10px 15px;
}

.panel-title {
	color: inherit;
	font-size: 16px;
	margin-bottom: 0;
	margin-top: 0;
}


</style>
    </head>
    <body>
     <h4>Dear Admin,</h4>
     <h4>Please find below transcation details. <h4>
     
    
    <div class="container">
	<table class="table panel panel-primary">
                <tr class="panel-heading">
                    <td class="panel-title" width="25%"> Transaction Status </td>
                    <td class="panel-title">: <b> {{$data_set["trans_status"]}} </b></td>
                </tr>
                <tr class="panel-heading">
                    <td class="panel-title"> Agent Name </td>
                    <td class="panel-title">: <b>{{ $data_set["agent_name"]  }}</b></td>
                </tr>
                <tr class="panel-heading">
                    <td class="panel-title"> Transcation Ref  </td>
                    <td class="panel-title">: {{ $data_set["trans_ref_url"] }}</td>
                </tr>
        </table>
        </div>
    
<div class="container">
<h3>Customer Details</h3>
<table class="table panel panel-primary">
<tr class="panel-heading">
	<td class="panel-title" width="25%">Name</td><td class="panel-title">: {{$data_set["proposer_name"]}}</td>
</tr>
<tr class="panel-heading">
	<td class="panel-title">Phone / Email </td><td class="panel-title">: {{ $data_set["proposer_phone"] }} / {{ $data_set["proposer_email"] }}</td>
</tr>
</table>
</div>


<div class="container">
<h3>Policy Details</h3>
<table class="table panel panel-primary">
<tr class="panel-heading">
	<td class="panel-title" width="25%">Insurance Company</td><td class="panel-title">: {{ $data_set["insurer_name"] }}</td>
</tr>
<tr class="panel-heading">
    <td class="panel-title" width="25%">Product Name</td><td class="panel-title">: {{ $data_set["product_name"] }}</td>
</tr>
<tr class="panel-heading">
	<td class="panel-title">Policy Exp Date</td><td class="panel-title">: {{ $data_set["policy_exp_date"] }}</td>
</tr>
<tr class="panel-heading">
	<td class="panel-title">Policy Start Date </td><td class="panel-title">: {{ $data_set["policy_start_date"] }}</td>
</tr>
<tr class="panel-heading">
	<td class="panel-title">Sum Insured</td><td class="panel-title">: {{ $data_set["sum_insured"] }}</td>
</tr>
<tr class="panel-heading">
	<td class="panel-title">Total Premium </td><td class="panel-title">:  {{ $data_set["final_premium"] }}</td>
</tr>
</table>
</div>
        
</body>
</html>
