@include('layouts.header')

<div class="page-header blog-style">
         <div class="container" style="text-align: justify;">
            <div class="row">
               <div class="col-md-12">
                  <ol class="breadcrumb">
                     <li><a href="/">InstaInsure.com</a></li>
                     <li><a href="/blog">Blog Home</a></li>
                     <li class="active">Industry</a></li>
                     <li class="active">Insurance Day</li>
                  </ol>
                  <div class="card card-background" style="background-image: url('/image/blog/insuranceday/insuranceday.png'">
                     <div class="content" style="padding-top:60px;">
                        <h2 class="dark">Toyota Tsusho Insurance Day</h2>
                     </div>
                  </div>
                  <blockquote>
                     <p>
                        "22nd December 2015 marked a golden day in the history of Toyota Tsusho Insurance Broker India (TTIBI).”
                     </p>
                  </blockquote>
                  <p>The 7 year old organization, the only Indo-Japanese collaboration of its kind, pulled off a remarkable opening for their Mumbai office – their 7th in India. TTIBI has a market share of 6.2% in the Indian Insurance Broking Industry. TTIBI is a joint venture between VikramGeet Investments and Holdings (Kirloskars) and Toyota Tsusho Corporation, Japan.</p>
               </div>
               <div class="col-md-12">
                  <h3 class="title light">Read on:</h3>
                  <p>Contrary to the modest operating style of TTIBI, a gala evening was organized at Grand Hyatt in Mumbai to share the sweetness of success and enduring relationships. TTIBI believes in mutual support and trust for being the core foundation of a relationship. The presence of prominent personalities from top Insurance companies and valuable clients set a proof to their strong relationship with all the stake holders and patrons.</p>
                  <p>The CEOs of New India Assurance, United India, HDFC ERGO, IFFCO Tokio, Bajaj Allianz, Chola MS, Reliance General, Raheja QBE, Future Generali, Liberty Videocon graced the occasion with their presence. The event also witnessed the presence of several CXOs and General Managers of Insurance Companies. The attendance of DPs, CEOs, top TKM Officials and Large clients comprising the Toyota Family added flavor to the evening.</p>
                  <p>The event kicked off with a message from Vikram Kirloskar San, Promotor of TTIBI, read out by Sundararaman San, the Chairman of TTIBI. Vijay Govada San, Director & CEO of TTIBI welcomed the guests, followed by a few words from Kenji Ogura San, the Whole-Time Director of TTIBI. While Vijay San in his trademark soft spoken style, narrated the inspiring story of TTIBI’s growth and principles, Ogura San expressed how excited Japan is about TTIBI’s growth. Ogura San also mentioned that TTIBI has become the 2nd largest operation for TTC, next only to Japan.</p>
                  <p>Once the hosts – Vijay San and Ogura San welcomed the guests, it was up to G Srinivasan San the CMD of New India Assurance, a stalwart in the insurance industry to officially inaugurate the branch symbolically by lighting the lamp. N Raja San, SVP & Director of Marketing and Sales at Toyota Kirloskar Motor spoke about the trust he had in TTIBI and noted the vast assembly as a proof to it.</p>
                  <p>Apart from Srinivasan San, Milind Karat San – CEO of United India, Yogesh Lohiya San – MD of IFFCO Tokio, Gopal Ratnam San – MD of Chola MS, and others spoke about their relationship with TTIBI. The contributions made by TTIBI to the industry was touched upon unanimously by all the speakers. “I am watching TTIBI since the time they were established. I am confident about their future as a market leader.” said Srinivasan San during his speech.</p>
                  <p>Among many others, Arun Agarwal San, the representative of Lloyds Re in India and Saraswathi San, representative of ACR Re was a noted presence.</p>
                  <p>The highlight, apart from the personalities who assembled for the event was, the story of TTIBI played out through a video at the venue. The 7th office of TTIBI was thus established. It also marked the shifting of base of, TTIBI’s Re-Insurance vertical to Mumbai. The leadership team of TTIBI who were present during the event, took the opportunity to interact with the Industry experts and absorb their suggestions and views. Vijay San and Ogura San were overwhelmed by the warm acceptance given to TTIBI by the Industry and the idea to name the event as “Toyota Tsusho Insurance Day” seemed justified. The event left a lasting smile on everyone associated with TTIBI.</p>
                  <p>At TTIBI, the efforts to instill more professionalism, transparency and ethics into the insurance industry will continue forever.</p>
                  <div class="card card-blog">
                  <h3 style="color: #00669c">Want to Associate with the Market Leader?</h3>
                  <h5>Try Generating a Car Insurance Quote Now. Its Super Quick and Simple!</h5>
                  <a href="/car-insurance" target="_blank" class="btn btn-success">Generate a Quote</a>
                  </div>
               </div>
               <div class="col-md-12">
                  <div class="row">
                     <div class="col-md-12" style="text-align: left">
                        <div class="blog-tags" style="padding-top: 20px;">
                           Tags:
                           <span class="label label-primary">Insurance Day</span>
                           <span class="label label-primary">Toyota Tsusho Insurance Broker India Pvt Ltd</span>
                           <span class="label label-primary">InstaInsure</span>
                           <span class="label label-primary">Insurance Broker</span>
                           <span class="label label-primary">Chola MS</span>
                           <span class="label label-primary">G Srinivasan</span>
                           <span class="label label-primary">IFFCO Tokio</span>
                           <span class="label label-primary">Milind Kharat</span>
                           <span class="label label-primary">N Raja</span>
                           <span class="label label-primary">New India Assurance</span>
                           <span class="label label-primary">S Gopalarathnam</span>
                           <span class="label label-primary">Toyota Kirloskar Motor</span>
                           <span class="label label-primary">Vijaya Govada</span>
                           <span class="label label-primary">Yogesh Lohia</span>
                           <span class="label label-primary">United India</span>
                           <span class="label label-primary">Kenji Ogura</span>
                           <span class="label label-primary">TTIBI</span>
                        </div>
                     </div>
                  </div>
                  <hr>
                  <h4 class="card-title">Author : Deepak Venugopal</h4>
                  <p class="description">InstaInsure.com is proud to be a fully owned subsidiary of Toyota Tsusho Insurance Broker India Pvt Ltd. Our corporate office is based in the garden city of Bengaluru, neatly tucked off in a corner of Lavelle road with a Pin-code 01!</p>
                  <div class="col-xs-8 hidesection" style="padding:20px 0;">
                     <div class="form-group is-empty"><input value="" placeholder="Email this blog" class="form-control" type="email"><span class="material-input"></span></div>
                  </div>
                  <div class="col-xs-1 hidesection">
                     <button type="button" class="btn btn-primary btn-just-icon" name="button">
                     <i class="material-icons">mail</i>
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>

<br><br>
<hr>

@include('layouts.footer')

