 <script src="{{ asset('js/component/rtoasset.js') }}"></script>
  <script>// Get all the keys from document
      var keys = document.querySelectorAll('#js-calculator button');
      
      // Add onclick event to all the keys and perform operations
      for(var i = 0; i < keys.length; i++) {if (window.CP.shouldStopExecution(1)){break;}
        keys[i].onclick = function(e) {
          // Get the input and button values
          var input = document.querySelector('.screen');
          var inputVal = input.innerHTML;
          var btnVal = this.innerHTML;
          
          // Now, just append the key values (btnValue) to the input string and finally use javascript's eval function to get the result
          // If clear key is pressed, erase everything
          if(btnVal == 'Clear') {
            input.innerHTML = '';
            decimalAdded = false;
          }
          
          // if any other key is pressed, just append it
          else {
            input.innerHTML += btnVal;
          }
          
          // prevent page jumps
          e.preventDefault();
        } 
      }
      window.CP.exitedLoop(1);
      
   </script>
 <!-- Travel Card -->
                     <div id="js-calculator">
                        <!-- Screen and clear key -->
                        <h6>
                        Use the <b style="color:#00669c;">Dial Pad</b> to enter the Number of Days of Travel
                        <h6>
                        <span style="font-size: 20px">Days :</span>
                        <span class="screen" style="font-size: 20px"></span>
                        <div class="row">
                           <div class="col-xs-12">&nbsp;</div>
                        </div>
                        <!-- operators and other keys -->
                        <div class="card table-responsive rtocard">
                           <table class="traveltable">
                              <tbody>
                                 <tr>
                                    <td><button type="button" class="btn btn-white">1</button></td>
                                    <td><button type="button" class="btn btn-white">2</button></td>
                                    <td><button type="button" class="btn btn-white">3</button></td>
                                 </tr>
                                 <tr>
                                    <td><button type="button" class="btn btn-white">4</button></td>
                                    <td><button type="button" class="btn btn-white">5</button></td>
                                    <td><button type="button" class="btn btn-white">6</button></td>
                                 </tr>
                                 <tr>
                                    <td><button type="button" class="btn btn-white">7</button></td>
                                    <td><button type="button" class="btn btn-white">8</button></td>
                                    <td><button type="button" class="btn btn-white">9</button></td>
                                 </tr>
                                 <tr>
                                    <td><button type="button" class="btn btn-white">0</button></td>
                                    <td><button type="button" class="btn-calc">Clear</button></td>
                                    <td><input id ="proceed_duration" class="btn-calc duration-btn " style="background-color: #00669C" value="Proceed" type="button"></td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                     <!-- Travel Card -->  