<h6> Select the duration of your Travel</h6>
<div class="container tabdata" > 
    <input class="std_duration btn btn-fill btn-white btn-wd " name="duration" id="std_30" value="30 Days" type="button"> 
	<input class="std_duration btn btn-fill btn-white btn-wd" name="duration" id="std_60" value="60 Days" type="button">  
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_90" value="90 Days" type="button"> 
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_120" value="120 Days" type="button">  
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_180" value="180 Days" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_270" value="270 Days" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_one" value="1 Year" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd" name="duration" id="std_456" value="456 Days" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd" name="duration" id="std_546" value="546 Days" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_636" value="636 Days" type="button">
	<input class="std_duration btn  btn-fill btn-white btn-wd " name="duration" id="std_two" value="2 Years" type="button">
</div>