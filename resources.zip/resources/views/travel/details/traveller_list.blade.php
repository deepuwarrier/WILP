<div class="container" >
   <div class="row">
   <div class="col-sm-4"></div>  

   <div class="col-sm-4">  
   <form id="traveller_info_form"> 
      <div class="col-sm-5">
         <select name="relationship[]" id="member" class="form-control relationship valid" aria-invalid="false">
            <option value="1">Self</option>
         </select>
         <span class="material-input"></span>
      </div>
      <div class="{{ ($data['trip_type'] == 'S') ? 'col-sm-5' : 'col-sm-7' }}" >
         <select name="age[]" id="age" class="age form-control valid" aria-invalid="false">
            <option hidden="" selected="" disabled="" value="">Select Age</option>
            @if($data['trip_type'] == 'S')
               @for($i=$data['single-min-limit']; $i<=$data['single-max-limit']; $i++)
               <option value="{{$i}}">{{$i}} Years</option>
               @endfor
            @elseif($data['trip_type'] == 'M')
               @for($i=$data['amt-min-limit']; $i<=$data['amt-max-limit'] ; $i++)
               <option value="{{$i}}">{{$i}} Years</option>
               @endfor
            @else 
               @for($i=$data['student-min-limit']; $i<=$data['student-max-limit'] ; $i++)
               <option value="{{$i}}">{{$i}} Years</option>
               @endfor  
            @endif   
         </select>
      </div>
      @if($data['trip_type'] == 'S')
      <div class="col-sm-2" id="add-container">
         <input id ="add_traveller" type="button" class="material-icons btn-primary" value="add"/>
      </div>
      @endif 
      <span id="member_container"></span>
   </form>      
   </div>
   <div class="col-sm-4"></div>  
   </div>
   <input type="button" class="btn btn-info quotes-btn" value="Generate Quotes" id="generate_quote" />
</div>