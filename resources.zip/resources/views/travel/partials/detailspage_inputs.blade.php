<br>
<div class="row datarepeaterbox">
   <div class="col-xs-6">
      <select name="relationship[]" id="member" class="form-control relationship valid" aria-invalid="false" required>
         <option disabled="Choose an option" selected="">Relationship*</option>
         @foreach($relmembers as $members)
         <option value="{{ $members->relationship_id }}"> {{ $members->relationship_name }} </option>
         @endforeach
      </select>
      <span class="material-input"></span>
   </div>
   <div class="col-xs-4">
      <select name="age" id="age" class="age form-control valid" aria-invalid="false">
         <option value="">Select Age</option>
         @for($i=18; $i<=100 ; $i++)
         <option value="{{$i}}">{{$i}} Years</option>
         @endfor
      </select>
      <span class="material-input"></span>
   </div>
   <div class="col-xs-2">
      <input type="button" class="material-icons del" value="remove" id="del">
   </div>
</div>