<style>
 .info_text{
   color: #4E4A4A;
  }
 .previewheight{
    min-height: 300px !important;
 }
</style>
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <a id = "traveler_preview"
                       class="btn btn-info btn-xs pull-right change" 
                       data-href="#travel">Change</a>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">Traveller :</h6>
                </div>
            </div>
            <div class="row" id ="traveller" style = "font-size: 12px;">
            @foreach($response['traveller_info']['name'] as $index => $name) 
                <div class="col-sm-12" style = "text-align: left">
                   <div class="col-sm-4">
                      <span class = "info_text">{{($response['traveller_info']['member_count'] > 1) ? $index + 1. : '' }} Name :</span> 
                      </br> {{strtoupper($name)}}  
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">Passport No. : </span>  
                      </br> {{strtoupper($response['traveller_info']['passport'][$index])}}
                   </div>
                   <div class="col-sm-2">
                      <span class = "info_text">DOB : </span>  
                      </br> {{strtoupper($response['traveller_info']['dob'][$index])}} 
                   </div>
                   @if(isset($response['traveller_info']['aadhaar'][$index]))
                   <div class="col-sm-3">
                      <span class = "info_text">Aadhaar No. : </span> 
                      </br> {{ strtoupper($response['traveller_info']['aadhaar'][$index])}}
                   </div>
                   @endif
                      @if($index == 0)
                       @if(isset($response['traveller_info']['nominee_name']))
                       <div class="col-sm-4">
                          <span class = "info_text">Nominee Name : </span> 
                          </br> {{ strtoupper($response['traveller_info']['nominee_name'])}}
                       </div>
                       @endif
                       @if(isset($response['traveller_info']['nominee_relation']))
                       <div class="col-sm-3">
                          <span class = "info_text">Relationship : </span> 
                          </br> {{ strtoupper($response['traveller_info']['nominee_relation'])}}
                       </div>
                       @endif
                      @endif 
                       @if(isset($response['traveller_info']['occupation'][$index]))
                       <div class="col-sm-4">
                          <span class = "info_text">Occupation : </span> 
                          </br> {{ strtoupper($response['traveller_info']['occupation'][$index])}}
                       </div>
                       @endif 
                </div>
              @endforeach 
            </div>
   
            @if(isset($response['en_proposer_details']) && $response['en_proposer_details'] == true)
            <div class="row" id ="proposer" style = "font-size: 12px;">
                <div class="col-sm-12" style = "text-align: left">
                    <div class="col-sm-4">
                        <span class = "info_text">Proposer Name :</span> 
                        </br> {{strtoupper($response['traveller_info']['guardian_name'])}}  
                    </div>
                    <div class="col-sm-3">
                        <span class = "info_text">DOB :</span> 
                        </br> {{strtoupper($response['traveller_info']['guardian_dob'])}}  
                    </div>
                    <div class="col-sm-2">
                        <span class = "info_text">Relationship :</span> 
                        </br> {{strtoupper($response['traveller_info']['guardian_relationship'])}}  
                    </div>
                </div>
                <div class="col-sm-12" style = "text-align: left">
                    <div class="col-sm-4">
                        <span class = "info_text">Trip Start Date :</span> 
                        </br>{{  $response['trip_info']['start_date'] }}  
                    </div>
                    <div class="col-sm-3">
                        <span class = "info_text">Trip end Date :</span>  
                        </br> {{ $response['trip_info']['end_date'] }}
                    </div>
                </div>
            </div>
            @endif
            @if(isset($response['traveller_info']['en_add_on']) && $response['traveller_info']['en_add_on'] == true && !empty($response['traveller_info']['add_on']))
            <div class="row" id ="" style = "font-size: 12px;">
                <div class="col-sm-12" style = "text-align: left">
                    <div class="col-sm-12">&nbsp;</div>
                    <div class="col-sm-12">
                      <span class = "info_text">Optional Cover :</span> 
                      </br>{{ $response['traveller_info']['add_on'] }}
                    </div>
                </div>
            </div> 
            @endif              
        </div>
    </div>
</div>
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button id = "communication_preview"
                            type="button" 
                            class="btn btn-info btn-xs pull-right change" 
                            data-href="#communication">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">COMMUNICATION :</h6>
                </div>
            </div>
            <div class="row" id ="traveller" style = "font-size: 12px;">
                <div class="col-sm-12" style = "text-align: left">
                   <div class="col-sm-3">
                      <span class = "info_text">Email ID :</span> 
                      </br>{{  strtoupper($response['communication_info']['email']) }}  
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">Mobile : </span>  
                      </br> {{  $response['communication_info']['mobile'] }}
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">House Name/Number : </span>  
                      </br> {{  strtoupper($response['communication_info']['house_no'])  }}
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">Street : </span> 
                      </br> {{  strtoupper($response['communication_info']['street']) }}
                   </div>
                </div>
                <div class="col-sm-12" style = "text-align: left">
                  <div class="col-sm-3">
                      <span class = "info_text">State : </span> 
                      </br> {{  strtoupper($response['communication_info']['state']) }}
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">City : </span> 
                      </br> {{  strtoupper($response['communication_info']['city']) }}
                   </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            @if(isset($response['en_academic_details']) && $response['en_academic_details'] == true)
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button id = "travel_details_preview"
                            type="button" 
                            class="btn btn-info btn-xs pull-right change" 
                            data-href="#academic_details">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">ACADEMIC DETAILS :</h6>
                </div>
            </div>
            <div class="row" id ="traveller" style = "font-size: 12px;">
                    <div class="col-sm-12" style = "text-align: left">
                       <div class="col-sm-6">
                          <span class = "info_text">University Name :</span> 
                          </br>{{  strtoupper($response['academic_info']['university_name']) }}  
                       </div>
                       <div class="col-sm-3">
                          <span class = "info_text">Program Name :</span>  
                          </br> {{ strtoupper($response['academic_info']['program_name']) }}
                       </div>
                       <div class="col-sm-3">
                          <span class = "info_text">Program Duration: </span>  
                          </br> {{  strtoupper($response['academic_info']['program_duration'])  }}
                       </div>
                       <div class="col-sm-12">
                          <span class = "info_text">University Address: </span>  
                          </br> {{  strtoupper($response['academic_info']['university_address'])  }}
                       </div>
                       <div class="col-sm-6">
                          <span class = "info_text">Country: </span>  
                          </br> {{  strtoupper($response['academic_info']['university_country'])  }}
                       </div>
                       <div class="col-sm-3">
                          <span class = "info_text">State: </span>  
                          </br> {{  strtoupper($response['academic_info']['university_state'])  }}
                       </div>
                       <div class="col-sm-3">
                          <span class = "info_text">City: </span>  
                          </br> {{  strtoupper($response['academic_info']['university_city'])  }}
                       </div>
                       <div class="col-sm-6">
                          <span class = "info_text">Sponser Name: </span>  
                          </br> {{  strtoupper($response['academic_info']['sponser_name'])  }}
                       </div>
                       <div class="col-sm-3">
                          <span class = "info_text">Sponser DOB: </span>  
                          </br> {{  strtoupper($response['academic_info']['sponser_dob'])  }}
                       </div>
                       @if(isset($response['en_sponser_relation']) && $response['en_sponser_relation'] == true)
                       <div class="col-sm-3">
                          <span class = "info_text">Relationship: </span>  
                          </br> {{  strtoupper($response['academic_info']['sponser_relationship'])  }}
                       </div>
                       @endif
                    </div>
            </div>
            @else
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button id = "travel_details_preview"
                            type="button" 
                            class="btn btn-info btn-xs pull-right change" 
                            data-href="#travel_details">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">TRIP DETAILS :</h6>
                </div>
            </div>
            <div class="row" id ="traveller" style = "font-size: 12px;">
                <div class="col-sm-12" style = "text-align: left">
                   <div class="col-sm-3">
                      <span class = "info_text">Trip Start Date :</span> 
                      </br>{{  $response['trip_info']['start_date'] }}  
                   </div>
                   <div class="col-sm-3">
                      <span class = "info_text">Trip end Date :</span>  
                      </br> {{ $response['trip_info']['end_date'] }}
                   </div>
                   @if(isset($response['trip_info']['purpose']))
                   <div class="col-sm-3">
                      <span class = "info_text">Purpose of Visit: </span>  
                      </br> {{  strtoupper($response['trip_info']['purpose'])  }}
                   </div>
                   @endif
                   @if(isset($response['trip_info']['visiting_country']))
                   <div class="col-sm-6">
                      <span class = "info_text">Visiting Country: </span>  
                      </br> {{  strtoupper($response['trip_info']['visiting_country'])  }}
                   </div>
                   @endif
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
<div class="col-sm-6">
    <div class="card card-form-horizontal previewheight">
        <div class="content">
            <div class="row">
                <div class="col-xs-6 pull-right">
                    <button id = "medical_his_preview"
                            type="button" 
                            class="btn btn-info btn-xs pull-right change" 
                            data-href="#medical_his">Change</button>
                </div>
                <div class="col-xs-6 pull-left">
                    <h6 class="pull-left">MEDICAL HISTORY:</h6>
                </div>
            </div>
            <div class="row" id ="traveller" style = "font-size: 12px;">
                <div class="col-sm-12" style = "text-align: left">
                  @if($response['ped_info'])
                   @foreach($response['ped_info']['short_code'] as $item => $value)
                    <div class="col-sm-3">
                      <span class = "info_text">{{$value}} : </span>  
                      </br> Yes
                    </div>
                   @endforeach
                  @else
                  <div class="col-sm-12">
                      <span class = "info_text">No pre-existing dieases declared</span> 
                   </div>
                  @endif 
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12 radiobutton uk-form uk-form-row">
    <label id="travel_terms_box">
        <input name="disclaimer" type="checkbox" value="disclaimer"
        id="fst_disclaimer" >
        {{$response['disclaimer']}}
    </label>
</div>
<div class="col-md-12">

  @if(isset($response['tata_licence']))
    <div class="col-md-6 pull-left">
      <strong>{{$response['tata_licence']}}</strong>
    </div>
  @endif

  @if(isset($response['tata_version']))
    <div class="col-md-6">
            <strong  style="float: right !important;">{{$response['tata_version']}}</strong>
        </div>
  @endif
  
</div>