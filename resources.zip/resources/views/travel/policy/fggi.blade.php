@include('travel.layouts.inn-hdr') @include('travel.policy.basicinfo')
<!-- start form wizard  -->
 <form autocomplete="off"  method="post" action="{{ route('health.policy.religare.submit_proposal') }}" id="buy_policy_form" name="pro_form">
  <input type="hidden" name="trans_code" id="trans_code" value="{{$data['userdata']['trans_code']}}">
  <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">

<style type="text/css">
  .show-info{
    text-transform: uppercase !important;
  }
</style>
<!-- hidden fields -->
	<input type="hidden" name="travelcount" id="travelcount" value="{{sizeof($data['userdata']['relationship'])}}">
	<input type="hidden" name="set_data" id="set_data" value="{{route('travel.fggi.setproposal')}}">
<!-- hidden field end -->
<div class="row">
   <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
      <div class="card wizard-card" data-color="green" id="wizardProfile">
         <div class="wizard-navigation">
            <ul class="nav nav-pills">
               <li style="width: 20%;" class="active">
                  <a id ="travel_btn" href="#travel" data-toggle="tab" aria-expanded="">Traveller</a>
               </li>
               <li style="width:20%;">
                  <a id ="communication_btn" href="#communication" data-toggle="tab">Communication</a>
               </li>
               <li style="width:20%;">
                  <a id ="travel_details_btn" href="#travel_details" data-toggle="tab">Trip Details</a>
               </li>
               <li style="width:20%;">
                  <a id ="medical_btn" href="#medical_his" data-toggle="tab">Medical History</a>
               </li>
               <li style="width:20%;">
                  <a href="#review" data-toggle="tab">Review</a>
               </li>
            </ul>
            <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
            <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
         </div>
         <div class="tab-content">
            <!-- Insured Section -->
            	<div class="tab-pane active" id="travel">
                  <h6 class='info-text'>Enter the Insured Details!</h6>
                  @foreach($data['userdata']['relationship'] as $index=>$relationship)
                  <!-- Row -->
                  <div class="row">
                      @if($index == 0)
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>SELF</strong> <small>(Primary Insured) </small></h5>
                      @else
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>
                        {{$relationship}}
                        </strong></h5>  
                      @endif
                      <!-- Gender -->
                      @if(sizeof($data['userdata']['relationship']) < 2)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Gender</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                <div class="labelright">
                                  <div class="radiobutton">
                                    <input type="radio" 
                                      id="gender_male" value="M"
                                      name="gender" 
                                      class="required valid gender"  
                                      data-name= "Gender" 
                                      {{($data['userdata']['gender'][$index] === 'M') ? 'checked=checked' : ''}} />
                                    <label for="gender_male" data-name="Gender">Male</label>
                                  </div>
                                  <div class="radiobutton">
                                    <input type="radio"
                                      id="gender_female" 
                                      name="gender"  
                                      value="F" 
                                      class="required valid gender" 
                                      data-name= "Gender"
                                      {{($data['userdata']['gender'][$index] === 'F') ? 'checked=checked' : ''}} />
                                      <label for="gender_female" data-name="Gender">Female</label>
                                  </div>
                                </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Gender --> 
                      <!-- First Name -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Full Name</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="name{{$index}}" 
                                      name="name[]"  
                                      value="{{isset($data['userdata']['name'][$index]) ? $data['userdata']['name'][$index] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Full Name">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End First Name --> 
                       <!-- Date Of Birth -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Date of Birth</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="dob{{$index}}" 
                                      name="dob[]"  
                                      value="{{isset($data['userdata']['dob'][$index]) ? $data['userdata']['dob'][$index] : $data['userdata']['dob_list'][$index]['selected_date']}}" 
                                      class="datepicker form-control required show-info"
                                      min-date ="{{$data['userdata']['dob_list'][$index]['min_date']}}"
                                      max-date ="{{$data['userdata']['dob_list'][$index]['max_date']}}"
                                      data-name="DOB">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Date Of Birth -->
                       <!-- Passport Number -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Passport No.</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="passport{{$index}}" 
                                      name="passport[]"  
                                      value="{{isset($data['userdata']['passport'][$index]) ? $data['userdata']['passport'][$index] : ''}}" 
                                      class="form-control required show-info"
                                      maxlength="8"
                                      data-name="Passport No.">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Passport Number -->
                       <!-- Aadhaar Number -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Aadhaar No.</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="aadhaar" 
                                      name="aadhaar_num"  
                                      maxlength="14"
                                      value="{{isset($data['userdata']['aadhaar_num']) ? $data['userdata']['aadhaar_num'] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Aadhaar No.">
                                 </div>
                              </div>
                           </div>
                        </div>
                        @endif
                       <!-- End Aadhaar Number -->
                       <!-- Marital Status -->
                       @if(isset($data['en_marital_status']) && $data['en_marital_status'] == true)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Marital Status</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="marital_status"
                                    name="marital_status"  
                                    class="form-control required show-info">
                                    <option hidden="" selected="" disabled="" value="">Select Marital Status </option>
                                        @foreach($data['marital_status_list'] as $marital_status)
                                        <option value="{{($marital_status['status_code'])}}"
                                        {{(isset($data['userdata']['marital_status']) && $data['userdata']['marital_status'] == $marital_status['status_code']) ? 'selected' : ''}}
                                        >{{strtoupper($marital_status['status_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif 
                       <!-- End Marital Status  -->
                       <!-- Visa Type -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Visa Type</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="visa_type{{$index}}"
                                    name="visa_type[]"
                                    location-data = "{{$data['userdata']['area']}}"  
                                    class="form-control required show-info">
                                    <option hidden="" selected="" disabled="" value="">Select a Visa Type  </option>
                                        @foreach($data['visa_type_list'] as $visa_type)
                                        <option value="{{($visa_type['visa_code'])}}"
                                        {{(isset($data['userdata']['visa_type'][$index]) && $data['userdata']['visa_type'][$index] == $visa_type['visa_code']) ? 'selected' : ''}}
                                        >{{strtoupper($visa_type['visa_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif 
                       <!-- End Visa Type --> 
                       <!-- Occupation -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Occupation</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="occupation{{$index}}"
                                    name="occupation[]"  
                                    class="form-control required show-info">
                                    <option hidden="" selected="" disabled="" value="">Select an Occupation </option>
                                        @foreach($data['occupation_list'] as $occupation)
                                        <option value="{{($occupation['fggi_code'])}}"
                                        {{(isset($data['userdata']['occupation'][$index]) && $data['userdata']['occupation'][$index] == $occupation['fggi_code']) ? 'selected' : ''}}
                                        >{{strtoupper($occupation['occ_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Occupation --> 
                       <!-- Nominee Name -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Nominee Name</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="nomineename" 
                                      name="nomineename"  
                                      value="{{isset($data['userdata']['nomineename']) ? $data['userdata']['nomineename'] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Nominee Name">
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Nominee Name --> 
                      <!-- Nominee Relationship -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Nominee Relationship</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="nomineerel"
                                    name="nomineerel"  
                                    class="form-control required show-info" 
                                    data-name="Nominee Ralationship">
                                    <option hidden="" selected="" disabled="" value="">Select a Relationship</option>
                                        @foreach($data['nominee_list'] as $nominee)
                                        <option value="{{($nominee['fggi_code'])}}"
                                        {{($data['userdata']['nomineerel'] == $nominee['fggi_code']) ? 'selected' : ''}}
                                        >{{strtoupper($nominee['relationship_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Nominee Relationship --> 
                  </div> 
               <!-- End Row --> 
               @endforeach
            </div>  
            <!-- Insured Section ends  -->
            <!-- Communication Section -->
            <div class="tab-pane" id="communication">
                  <h6 class='info-text'>ENTER THE COMMUNICATION DETAILS!</h6>     
                  <!-- Row -->
                  <div class="row">
                    <!-- EMAIL -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Email ID</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="email" 
                                  name="email"  
                                  value="{{$data['userdata']['email']}}" 
                                  class="form-control required show-info"
                                  maxlength="50" 
                                  data-name="Email">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End EMAIL -->     
                   <!-- Mobile -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Mobile</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="mobile" 
                                  name="mobile"  
                                  value="{{$data['userdata']['mobile']}}" 
                                  class="form-control required show-info" 
                                  maxlength="10" 
                                  minlength="10"
                                  data-name="Mobile">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Mobile -->
                   <!-- House Name/Number -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>House Name/Number</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="house_name" 
                                  name="house_name"  
                                  value="{{$data['userdata']['house_name']}}" 
                                  class="form-control required show-info" 
                                  data-name="HouseName/Number">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End House Name/Number -->
                   <!-- Street -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Street</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="street" 
                                  name="street"  
                                  value="{{$data['userdata']['street']}}" 
                                  class="form-control required show-info" 
                                  data-name="Street">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Street -->
                   <!-- State -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>State</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="state"
                                    name="state"  
                                    class="form-control required show-info" 
                                    data-name="State">
                                    <option hidden="" selected="" disabled="" value="">Select State</option>
                                        @foreach($data['state_list'] as $state)
                                        <option value="{{($state['state_code'])}}"
                                        	{{($data['userdata']['state'] == $state['state_code']) ? 'selected' : ''}}
                                       	 >{{strtoupper($state['state_name'])}}</option>
                                        @endforeach 
                                   </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- State -->
                   <!-- City -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>City</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="city"
                                    name="city"  
                                    class="form-control required show-info" 
                                    data-url  = "{{route('getcity')}}"
                                    data-name="City">
                                     @if(isset($data['city_list']) && $data['city_list'] !=false)
                                     	@foreach($data['city_list'] as $city)
                                          <option value="{{($city['city_name'])}}"
                                          	{{($data['userdata']['city'] == $city['city_name']) ? 'selected' : ''}}
                                          	>{{strtoupper($city['city_name'])}}</option>
                                          @endforeach 
                                     @else
                                    	<option hidden="" selected="" disabled="" value="">Select City</option>
                                    	@endif
                                    </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End City -->
                   <!-- Pincode -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Pincode</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="pincode" 
                                  name="pincode"  
                                  value="{{$data['userdata']['pincode']}}" 
                                  class="form-control required show-info" 
                                  maxlength="6"
                                  data-name="Pincode">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Pincode -->         
                 </div> 
                 <!-- End Row --> 
            </div> 
            <!-- Communication Section ends -->
            <!-- Travel Details Section -->
            <div class="tab-pane" id="travel_details">
                  <h6 class='info-text'>ENTER THE TRIP DETAILS!</h6>     
                  <!-- Row -->
                  <div class="row">
                   <!-- Travel Start Date -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Trip Start Date</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="trip_start_date" 
                                  name="trip_start_date"  
                                  value="{{$data['userdata']['trip_start_date']['selected_date']}}" 
                                  class="form-control required show-info" 
                                  min-date = "{{$data['userdata']['trip_start_date']['min_date']}}"
                                  max-date = "{{$data['userdata']['trip_start_date']['max_date']}}"
                                  max-duration = "{{$data['userdata']['trip_start_date']['max_duration']}}"
                                  data-name="Trip Start">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Travel Start Date -->
                   <!-- Travel End Date -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Trip End Date</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="trip_end_date" 
                                  name="trip_end_date"  
                                  value="{{$data['userdata']['trip_end_date']}}" 
                                  class="form-control required show-info" 
                                  data-name="Trip End" disabled>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Travel End Date -->
                   <!-- Travel End Date -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Purpose of Visit</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="purpose"
                                    name="purpose"  
                                    class="form-control required show-info" 
                                    data-name="Purpose of Visit">
                                    <option hidden="" selected="" disabled="" value="">Select Purpose</option>
                                    @foreach($data['purpose_list'] as $index => $purpose)
                                    <option value="{{$purpose['fggi_code']}}" 
                                    {{( isset($data['userdata']['purpose'])  && $data['userdata']['purpose'] == $purpose['fggi_code']) ? 'selected' : ''}}>{{strtoupper($purpose['purpose_name'])}}</option>
                                    @endforeach
                                    </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Travel End Date --> 
                   <!-- Visiting Country -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Visiting Country</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="visiting_country"
                                    name="visiting_country"  
                                    class="form-control required show-info" 
                                    data-name="State">
                                    <option hidden="" selected="" disabled="" value="">Select Country</option>
                                        @foreach($data['country_list'] as $country)
                                        <option value="{{($country['fggi_code'])}}"
                                          {{($data['userdata']['visiting_country'] == $country['fggi_code']) ? 'selected' : ''}}
                                         >{{strtoupper($country['fggi_code'])}}</option>
                                        @endforeach 
                                   </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Visiting Country -->
                  </div>
                  <!-- End Row -->
             </div> 
            <!-- Travel Details Section ends --> 
             <!-- Medical History Section -->
            <div class="tab-pane" id="medical_his">
                  <h6 class='info-text'>ENTER YOUR MEDICAL HISTORY!</h6>     
                  <!-- Row -->      
               <div class="container tabdata">
                  <div class="col-sm-12" style="padding:0">
                     <div class="card proposalcard">
                        @foreach($data['ped_list'] as $index => $ped)
                        <div class="col-sm-12" style="padding:0">
                           <div class="labelleft">
                              <a>
                              <p>{{$index + 1 }}. {{$ped['ped_title']}} ? 
                                 <input type="checkbox"
                                    id="{{$ped['fggi_code']}}_yes"
                                    name="ped_choice[{{$ped['fggi_code']}}]" 
                                    value="1"
                                    data-name= "{{ ucwords($ped['ped_short_code']) }}"
                                    data-type= "1" 
                                    {{(isset($data['userdata']['ped']['ped_choice'][$ped['fggi_code']])) ? 
                                    'checked' : ''}}> 
                                    <label><strong>Yes</strong></label>
                              </p>
                              </a>
                           </div>
                        </div>
                        <div class="col-sm-6">
                              <input type="text" 
                                name="ped_details[{{$ped['fggi_code']}}]"
                                id="{{$ped['fggi_code']}}_details" 
                                placeholder ="Specify the details here" 
                                class="form-control required  show-info" 
                                data-name ="Description" 
                                maxlength="60"
                                value ="{{(isset($data['userdata']['ped']['ped_details'][$ped['fggi_code']])) ? 
                                        $data['userdata']['ped']['ped_details'][$ped['fggi_code']] : ''}}"
                                style="display: {{(isset($data['userdata']['ped']['ped_choice'][$ped['fggi_code']])) ? 
                                                'block' : 'none'}};">
                        </div>
                        @endforeach
                     </div>
                  </div>
               </div>
               <!-- End Row -->
             </div>
            <!-- End Medical History -->      
            <!-- Review Section -->      
            <div class="tab-pane" id="review">
              <h6 class='info-text'>Review the data you entered!</h6>
              <div class="container tabdata">
                 <div class="row" id ="preview_box"></div>
               </div>
            </div>  
            <!-- Review Section ends -->         
         </div>
         </form>  
         <div class="wizard-footer">
            <div class="pull-right">
               <input type="button"
                 name="next"  
                 id="nextform" 
                 value="Next"
                 data-focus='h_benefits' 
                 class="btn scrolltop btn-next btn-info">
               <input type="button"
                 name="finish" 
                 id="travel-btn-pay"
                 data-focus='h_benefits'
                 value="Finish" 
                 class="btn scrolltop btn-finish btn-info"
                 style="display: none;">
            </div>
            <div class="pull-left">
               <input type="button"
                 data-focus='h_benefits' 
                 class="btn scrolltop btn-previous btn-info disabled" 
                 name="previous" 
                 value="Previous">
            </div>
            <div class="clearfix"></div>
         </div>   
      </div>                        
   </div>
</div>
</div>

<!-- premium breakup modal -->
<div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup"></div>

<!--Package Info Modal -->
 <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits"></div>
 
<!-- To genrate otp-->
   <input type='hidden' name='policy_cmp' id='policy_cmp' value="hdfc">
   <input type='hidden' name='travel_otp_gen' id='travel_otp_gen' value="{{route('travel_gen_otp')}}">
   <input type='hidden' name='travel_very_otp' id='travel_very_otp' value="{{route('travel_very_otp')}}">
<!-- end otp -->

@include('travel.layouts.inn-ftr')
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/fggi.js ') }}"></script>
<script src="{{ URL::asset('js/validation_lib.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/fggi_form_validation.js ') }}"></script>
<script type="text/javascript">load_dob_list()</script>
<script type="text/javascript">load_trip_list()</script>
<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script src="{{ URL::asset('js/sweetalert2.js') }}"></script>
<script type="text/javascript">
   $(document).ready(function() {
       $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
   });
</script>