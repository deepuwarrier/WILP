@include('travel.layouts.inn-hdr') @include('travel.policy.basicinfo')
<!-- start form wizard  -->
 <form autocomplete="off"  method="post" action="{{ route('health.policy.religare.submit_proposal') }}" id="buy_policy_form" name="pro_form">
  <input type="hidden" name="trans_code" id="trans_code" value="{{$data['userdata']['trans_code']}}">
  <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
  
<style type="text/css">
  .show-info{
    text-transform: uppercase !important;
  }
</style>
<!-- hidden fields -->
	<input type="hidden" name="travelcount" id="travelcount" value="{{sizeof($data['userdata']['relationship'])}}">
	<input type="hidden" name="set_data" id="set_data" value="{{route('travel.hdfc.setproposal')}}">
	<input type="hidden" name="updated_premium" id="updated_premium" value="0">
<!-- hidden field end -->
<div class="row">
   <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
      <div class="card wizard-card" data-color="green" id="wizardProfile">
         <div class="wizard-navigation">
            <ul class="nav nav-pills">
               <li style="width: 20%;" class="active">
                  <a id ="travel_btn" href="#travel" data-toggle="tab" aria-expanded="">Traveller</a>
               </li>
               <li style="width:20%;">
                  <a id ="communication_btn" href="#communication" data-toggle="tab">Communication</a>
               </li>
               @if(isset($data['en_academic_tab']) && $data['en_academic_tab'] == true)
               <li style="width:20%;">
                  <a id ="academic_btn" href="#academic_details" data-toggle="tab">Academic Details</a>
               </li>
               @else
               <li style="width:20%;">
                  <a id ="travel_details_btn" href="#travel_details" data-toggle="tab">Trip Details</a>
               </li>
               @endif
               <li style="width:20%;">
                  <a id ="medical_btn" href="#medical_his" data-toggle="tab">Medical History</a>
               </li>
               <li style="width:20%;">
                  <a href="#review" data-toggle="tab">Review</a>
               </li>
            </ul>
            <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
            <div class="moving-tab" style="width: 311.2px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
         </div>
         <div class="tab-content">
            <!-- Insured Section -->
            	<div class="tab-pane active" id="travel">
                  <h6 class='info-text'>Enter the Insured Details!</h6>
                  @foreach($data['userdata']['relationship'] as $index=>$relationship)
                  <!-- Row -->
                  <div class="row">
                      @if($index == 0)
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>SELF</strong> <small>(Primary Insured) </small></h5>
                      @else
                        <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>
                        {{$relationship}}
                        </strong></h5>  
                      @endif
                      <!-- Gender -->
                      @if(sizeof($data['userdata']['relationship']) < 2)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Gender</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                <div class="labelright">
                                  <div class="radiobutton">
                                    <input type="radio" 
                                      id="gender_male" value="M"
                                      name="gender" 
                                      class="required valid gender"  
                                      data-name= "Gender" 
                                      {{($data['userdata']['gender'][$index] === 'M') ? 'checked=checked' : ''}} />
                                    <label for="gender_male" data-name="Gender">Male</label>
                                  </div>
                                  <div class="radiobutton">
                                    <input type="radio"
                                      id="gender_female" 
                                      name="gender"  
                                      value="F" 
                                      class="required valid gender" 
                                      data-name= "Gender"
                                      {{($data['userdata']['gender'][$index] === 'F') ? 'checked=checked' : ''}} />
                                      <label for="gender_female" data-name="Gender">Female</label>
                                  </div>
                                </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Gender --> 
                      <!-- First Name -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Full Name</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="name{{$index}}" 
                                      name="name[]"  
                                      value="{{isset($data['userdata']['name'][$index]) ? $data['userdata']['name'][$index] : ''}}" 
                                      class="form-control required show-info"
                                      maxlength="70"
                                      data-name="Full Name">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End First Name --> 
                       <!-- Date Of Birth -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Date of Birth</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="dob{{$index}}" 
                                      name="dob[]"  
                                      value="{{isset($data['userdata']['dob'][$index]) ? $data['userdata']['dob'][$index] : $data['userdata']['dob_list'][$index]['selected_date']}}" 
                                      class="datepicker form-control required show-info"
                                      min-date ="{{$data['userdata']['dob_list'][$index]['min_date']}}"
                                      max-date ="{{$data['userdata']['dob_list'][$index]['max_date']}}"
                                      data-name="DOB">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Date Of Birth -->
                       <!-- Passport Number -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Passport No.</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="passport{{$index}}" 
                                      name="passport[]"  
                                      value="{{isset($data['userdata']['passport'][$index]) ? $data['userdata']['passport'][$index] : ''}}" 
                                      class="form-control required show-info"
                                      maxlength="8"
                                      data-name="Passport No.">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Passport Number -->
                       <!-- Aadhaar Number -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Aadhaar No.</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="aadhaar" 
                                      name="aadhaar_num"  
                                      maxlength="14"
                                      value="{{isset($data['userdata']['aadhaar_num']) ? $data['userdata']['aadhaar_num'] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Aadhaar No.">
                                 </div>
                              </div>
                           </div>
                        </div>
                        @endif
                       <!-- End Aadhaar Number -->
                       <!-- Nominee Name -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Nominee Name</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="nomineename" 
                                      name="nomineename"  
                                      value="{{isset($data['userdata']['nomineename']) ? $data['userdata']['nomineename'] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Nominee Name">
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Nominee Name --> 
                      <!-- Nominee Relationship -->
                       @if($index == 0)
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Nominee Relationship</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="nomineerel"
                                    name="nomineerel"  
                                    class="form-control required show-info" 
                                    data-name="Nominee Ralationship">
                                    <option hidden="" selected="" disabled="" value="">Select a Relationship</option>
                                        @foreach($data['nominee_list'] as $nominee)
                                        <option value="{{($nominee['hdfc_code'])}}"
                                        {{($data['userdata']['nomineerel'] == $nominee['hdfc_code']) ? 'selected' : ''}}
                                        >{{strtoupper($nominee['relationship_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                       @endif
                      <!-- End Nominee Relationship -->  
                      @if(isset($data['en_academic_tab']) && $data['en_academic_tab'] == true)
                      <!-- Travel Start Date -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Trip Start Date</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text" 
                                      id="trip_start_date" 
                                      name="trip_start_date"  
                                      value="{{$data['userdata']['trip_start_date']['selected_date']}}" 
                                      class="form-control required show-info" 
                                      min-date = "{{$data['userdata']['trip_start_date']['min_date']}}"
                                      max-date = "{{$data['userdata']['trip_start_date']['max_date']}}"
                                      max-duration = "{{$data['userdata']['trip_start_date']['max_duration']}}"
                                      data-name="Trip Start">
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Travel Start Date -->
                       <!-- Travel End Date -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Trip End Date</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text" 
                                      id="trip_end_date" 
                                      name="trip_end_date"  
                                      value="{{$data['userdata']['trip_end_date']}}" 
                                      class="form-control required show-info" 
                                      data-name="Trip End" disabled>
                                 </div>
                              </div>
                           </div>
                        </div>
                       <!-- End Travel End Date -->
                      @endif
                  </div> 
               <!-- End Row --> 
               @endforeach
               <!-- Start Row --> 
               @if(isset($data['en_academic_tab']) && $data['en_academic_tab'] == true)
                <br>
                <div class="row">
                    <h5 style="text-align: -webkit-left; margin-left: 40px;"><strong>
                        Proposer</strong></h5>
                    <!-- Proposer Name -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Full Name</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="guardian_name" 
                                      name="guardian_name"  
                                      maxlength="45"
                                      value="{{isset($data['userdata']['guardian_name']) ? $data['userdata']['guardian_name'] : ''}}" 
                                      class="form-control required show-info"
                                      data-name="Proposer Name">
                                 </div>
                              </div>
                           </div>
                        </div>
                    <!-- End Proposer Name -->  
                    <!-- Proposer Date Of Birth -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Date of Birth</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                    <input type="text"  
                                      id="guardian_dob" 
                                      name="guardian_dob"  
                                      value="{{isset($data['userdata']['guardian_dob']) ? $data['userdata']['guardian_dob'] : $data['guardian_dob']['selected_date']}}" 
                                      class="datepicker form-control required show-info"
                                      min-date ="{{$data['guardian_dob']['min_date']}}"
                                      max-date ="{{$data['guardian_dob']['max_date']}}"
                                      data-name="Proposer DOB">
                                 </div>
                              </div>
                           </div>
                        </div>
                      <!-- End Proposer Date Of Birth --> 
                      <!-- Proposer Relationship -->
                        <div class="col-sm-4 individual">
                           <div class="card proposalcard">
                              <div class="col-sm-4" style="padding:0">
                                 <div class="labelleft">
                                    <a>
                                       <p>Relationship</p>
                                    </a>
                                 </div>
                              </div>
                              <div class="col-sm-8" style="padding:0">
                                 <div class="labelright">
                                  <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="guardian_relationship"
                                    name="guardian_relationship"  
                                    class="form-control required show-info" 
                                    data-name="Proposer Ralationship">
                                    <option hidden="" selected="" disabled="" value="">Select a Relationship</option>
                                        @foreach($data['guardian_relationship'] as $item)
                                        <option value="{{($item['relationship_code'])}}"
                                        {{($data['userdata']['guardian_relationship'] == $item['relationship_code']) ? 'selected' : ''}}
                                        >{{strtoupper($item['relationship_name'])}}</option>
                                        @endforeach 
                                   </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                    <!-- End Proposer Relationship -->
                </div>         
                <!-- End Row --> 
               @endif  
            </div>  
            <!-- Insured Section ends  -->
            <!-- Communication Section -->
            <div class="tab-pane" id="communication">
                  <h6 class='info-text'>ENTER THE COMMUNICATION DETAILS!</h6>     
                  <!-- Row -->
                  <div class="row">
                    <!-- EMAIL -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Email ID</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="email" 
                                  name="email"  
                                  value="{{$data['userdata']['email']}}" 
                                  class="form-control required show-info" 
                                  data-name="Email">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End EMAIL -->     
                   <!-- Mobile -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Mobile</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="mobile" 
                                  name="mobile"  
                                  value="{{$data['userdata']['mobile']}}" 
                                  class="form-control required show-info" 
                                  maxlength="10" 
                                  minlength="10"
                                  data-name="Mobile">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Mobile -->
                   <!-- House Name/Number -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>House Name/Number</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="house_name" 
                                  name="house_name"  
                                  value="{{$data['userdata']['house_name']}}" 
                                  class="form-control required show-info" 
                                  data-name="HouseName/Number">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End House Name/Number -->
                   <!-- Street -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Street</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="street" 
                                  name="street"  
                                  value="{{$data['userdata']['street']}}" 
                                  class="form-control required show-info" 
                                  data-name="Street">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Street -->
                   <!-- State -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>State</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="state"
                                    name="state"  
                                    class="form-control required show-info" 
                                    data-name="State">
                                    <option hidden="" selected="" disabled="" value="">Select State</option>
                                        @foreach($data['state_list'] as $state)
                                        <option value="{{($state['state_code'])}}"
                                        	{{($data['userdata']['state'] == $state['state_code']) ? 'selected' : ''}}
                                       	 >{{strtoupper($state['state_name'])}}</option>
                                        @endforeach 
                                   </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- State -->
                   <!-- City -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>City</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="city"
                                    name="city"  
                                    class="form-control required show-info" 
                                    data-url  = "{{route('getcity')}}"
                                    data-name="City">
                                     @if(isset($data['city_list']) && $data['city_list'] !=false)
                                      @foreach($data['city_list'] as $city)
                                          <option value="{{($city['city_name'])}}"
                                            {{($data['userdata']['city'] == $city['city_name']) ? 'selected' : ''}}
                                            >{{strtoupper($city['city_name'])}}</option>
                                          @endforeach 
                                     @else
                                    	<option hidden="" selected="" disabled="" value="">Select City</option>
                                    	@endif
                                    </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End City -->
                   <!-- Pincode -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Pincode</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="pincode" 
                                  name="pincode"  
                                  value="{{$data['userdata']['pincode']}}" 
                                  class="form-control required show-info" 
                                  maxlength="6"
                                  data-name="Pincode">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Pincode -->         
                 </div> 
                 <!-- End Row --> 
            </div> 
            <!-- Communication Section ends -->
            <!-- Travel Details Section -->
            @if(isset($data['en_academic_tab']) && $data['en_academic_tab'] == true)
            <div class="tab-pane" id="academic_details">
                  <h6 class='info-text'>ENTER THE ACADEMIC DETAILS!</h6>     
                  <!-- Row -->
                  <div class="row">
                  <!-- University Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>University Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="university_name" 
                                  name="university_name"  
                                  value="{{$data['userdata']['university_name']}}" 
                                  class="form-control required show-info" 
                                  data-name="University Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End University Name -->
                   <!-- Program Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Program Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="program_name" 
                                  name="program_name"  
                                  value="{{$data['userdata']['program_name']}}" 
                                  class="form-control required show-info" 
                                  data-name="Program Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Program Name -->
                   <!-- Program Duration -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Program Duration</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="program_duration" 
                                  name="program_duration"  
                                  value="{{$data['userdata']['program_duration']}}" 
                                  class="form-control required show-info"
                                  placeholder="Eg: 3 years or 30 days etc." 
                                  data-name="Program Duration">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Program Duration -->
                   <!-- University Address -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>University Address</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="university_address" 
                                  name="university_address"  
                                  value="{{$data['userdata']['university_address']}}" 
                                  class="form-control required show-info" 
                                  data-name="University Address">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End University Address -->
                   <!-- Country -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Country</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="university_country" 
                                  name="university_country"  
                                  value="{{$data['userdata']['university_country']}}" 
                                  class="form-control required show-info" 
                                  data-name="Country">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Country -->
                   <!-- State -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>State</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="university_state" 
                                  name="university_state"  
                                  value="{{$data['userdata']['university_state']}}" 
                                  class="form-control required show-info" 
                                  data-name="State">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End State --> 
                   <!-- City -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>City</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="university_city" 
                                  name="university_city"  
                                  value="{{$data['userdata']['university_city']}}" 
                                  class="form-control required show-info" 
                                  data-name="City">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End City -->
                   <!-- Sponser Name -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Sponser Name</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="sponser_name" 
                                  name="sponser_name"  
                                  value="{{$data['userdata']['sponser_name']}}" 
                                  class="form-control required show-info" 
                                  data-name="Sponser Name">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Sponser Name -->
                   <!-- Sponser DOB -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Sponser DOB</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="sponser_dob" 
                                  name="sponser_dob"  
                                  value="{{isset($data['userdata']['sponser_dob']) ? $data['userdata']['sponser_dob'] : $data['guardian_dob']['selected_date']}}" 
                                  class="datepicker form-control required show-info"
                                  min-date ="{{$data['guardian_dob']['min_date']}}"
                                  max-date ="{{$data['guardian_dob']['max_date']}}" 
                                  data-name="Sponser DOB">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Sponser DOB -->  
                  </div>
                  <!-- End Row -->
            </div>   
            @else  
            <div class="tab-pane" id="travel_details">
                  <h6 class='info-text'>ENTER THE TRIP DETAILS!</h6>     
                  <!-- Row -->
                  <div class="row">
                   <!-- Travel Start Date -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Trip Start Date</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="trip_start_date" 
                                  name="trip_start_date"  
                                  value="{{$data['userdata']['trip_start_date']['selected_date']}}" 
                                  class="form-control required show-info" 
                                  min-date = "{{$data['userdata']['trip_start_date']['min_date']}}"
                                  max-date = "{{$data['userdata']['trip_start_date']['max_date']}}"
                                  max-duration = "{{($data['userdata']['triptype'] == 'S') ? $data['userdata']['duration'] : '365'}}"
                                  data-name="Trip Start">
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Travel Start Date -->
                   <!-- Travel End Date -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Trip End Date</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <input type="text" 
                                  id="trip_end_date" 
                                  name="trip_end_date"  
                                  value="{{$data['userdata']['trip_end_date']}}" 
                                  class="form-control required show-info" 
                                  data-name="Trip End" disabled>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Travel End Date -->
                   <!-- Purpose of visit -->
                    <div class="col-sm-4 individual">
                       <div class="card proposalcard">
                          <div class="col-sm-4" style="padding:0">
                             <div class="labelleft">
                                <a>
                                   <p>Purpose of Visit</p>
                                </a>
                             </div>
                          </div>
                          <div class="col-sm-8" style="padding:0">
                             <div class="labelright">
                                <select data-md-selectize required 
                                    data-live-search="true" 
                                    id="purpose"
                                    name="purpose"  
                                    class="form-control required show-info" 
                                    data-name="Purpose of Visit">
                                    <option hidden="" selected="" disabled="" value="">Select Purpose</option>
                                    <option value="Business" 
                                      {{( isset($data['userdata']['purpose'])  && $data['userdata']['purpose'] == 'Business') ? 'selected' : ''}}
                                      >Business</option>
                                    <option value="Holiday" 
                                      {{( isset($data['userdata']['purpose'])  && $data['userdata']['purpose'] == 'Holiday') ? 'selected' : ''}}
                                      >Holiday</option>
                                    </select>
                             </div>
                          </div>
                       </div>
                    </div>
                   <!-- End Purpose of visit --> 
                  </div>
                  <!-- End Row -->
             </div> 
            @endif  

            <!-- Travel Details Section ends --> 
            <!-- Medical History Section -->
            <div class="tab-pane" id="medical_his">
                  <h6 class='info-text'>ENTER YOUR MEDICAL HISTORY!</h6>     
                  <!-- Row -->      
               <div class="container tabdata">
                  <div class="col-sm-12" style="padding:0">
                     <div class="card proposalcard">
                        @foreach($data['ped_list'] as $index => $ped)
                        <div class="col-sm-12" style="padding:0">
                           <div class="labelleft">
                              <a>
                              <p>{{$index + 1 }}. {{$ped['ped_title']}} ? 
                                 <input type="checkbox"
                                    id="{{$ped['hdfc_code']}}_yes"
                                    name="ped_choice[{{$ped['hdfc_code']}}]" 
                                    value="1"
                                    data-name= "{{ ucwords($ped['ped_short_code']) }}"
                                    data-type= "1" 
                                    {{(isset($data['userdata']['ped']['ped_choice'][$ped['hdfc_code']])) ? 
                                    'checked' : ''}}> 
                                    <label><strong>Yes</strong></label>
                              </p>
                              </a>
                           </div>
                        </div>

                        @if($data['sub_ped_list'])
                        @foreach($data['sub_ped_list'] as $ped_code => $sub_ped)
                          @if($ped['ped_code'] == $ped_code)
                          <div id = "sub_ped_container" class=" error-cont" style="display: {{(isset($data['userdata']['ped']['ped_choice'][$ped['hdfc_code']])) ? 
                                                'block' : 'none'}};">
                            <div class="col-sm-12 error-place">
                            </div>        
                            <div class="col-sm-12">
                            
                            @foreach($sub_ped as $sub_ped_data)
                              <div class="col-sm-3">
                                <input type="checkbox"
                                    id="{{$sub_ped_data['hdfc_code']}}"
                                    name="sub_ped[{{$sub_ped_data['hdfc_code']}}]" 
                                    class="illness_require"
                                    value="1"
                                    {{(isset($data['userdata']['ped']['sub_ped'][$sub_ped_data['hdfc_code']])) ? 
                                    'checked' : ''}}> 
                                    <label> {{$sub_ped_data['ped_title']}} </label>
                              </div>
                            @endforeach 
                            </div>
                          </div>  
                          @endif
                        @endforeach
                        @endif

                        <div class="col-sm-12"> 
                        <div class="col-sm-6">
                              <input type="text" 
                                name="ped_details[{{$ped['hdfc_code']}}]"
                                id="{{$ped['hdfc_code']}}_details" 
                                placeholder ="Specify the details here" 
                                class="form-control required  show-info" 
                                data-name ="Description" 
                                maxlength="60"
                                value ="{{(isset($data['userdata']['ped']['ped_details'][$ped['hdfc_code']])) ? 
                                        $data['userdata']['ped']['ped_details'][$ped['hdfc_code']] : ''}}"
                                style="display: {{(isset($data['userdata']['ped']['ped_details'][$ped['hdfc_code']])) ? 
                                                'block' : 'none'}};">
                        </div>
                        </div>
               
                        @endforeach
                     </div>
                  </div>
               </div>
               <!-- End Row -->
             </div>
            <!-- End Medical History -->      
            <!-- Review Section -->      
            <div class="tab-pane" id="review">
              <h6 class='info-text'>Review the data you entered!</h6>
              <div class="container tabdata">
                 <div class="row" id ="preview_box"></div>
               </div>
            </div>  
            <!-- Review Section ends -->         
         </div>
         <div class="wizard-footer">
            <div class="pull-right">
               <input type="button"
                 name="next"  
                 id="nextform" 
                 value="Next"
                 data-focus='h_benefits' 
                 class="btn scrolltop btn-next btn-info">
               <input type="button"
                 name="finish" 
                 id="travel-btn-pay"
                 data-focus='h_benefits'
                 value="Finish" 
                 class="btn scrolltop btn-finish btn-info"
                 style="display: none;">
            </div>
            <div class="pull-left">
               <input type="button"
                 data-focus='h_benefits' 
                 class="btn scrolltop btn-previous btn-info disabled" 
                 name="previous" 
                 value="Previous">
            </div>
            <div class="clearfix"></div>
         </div>   
      </div>                        
   </div>
</div>
</div>
</form>
<!-- premium breakup modal -->
<div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup"></div>

<!--Package Info Modal -->
 <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits"></div>
 
<!-- To genrate otp-->
   <input type='hidden' name='policy_cmp' id='policy_cmp' value="hdfc">
   <input type='hidden' name='travel_otp_gen' id='travel_otp_gen' value="{{route('travel_gen_otp')}}">
   <input type='hidden' name='travel_very_otp' id='travel_very_otp' value="{{route('travel_very_otp')}}">
<!-- end otp -->

@include('travel.layouts.inn-ftr')
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/common.js ') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/hdfc.js ') }}"></script>
<script src="{{ URL::asset('js/validation_lib.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/travel/policy/hdfc_form_validation.js ') }}"></script>
<script type="text/javascript">load_dob_list()</script>
<script type="text/javascript">load_trip_list()</script>
<script type="text/javascript" src="{{ URL::asset('js/validate.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script src="{{ URL::asset('js/sweetalert2.js') }}"></script>
<script type="text/javascript">
   $(document).ready(function() {
       $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
   });
</script>