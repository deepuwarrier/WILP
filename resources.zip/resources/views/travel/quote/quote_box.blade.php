@if ($error)
  <div class="row card">
    <br>
    <p>No Quotes generated for your Request</p>
  </div>  
@else
  <div class="row card customcard quote-box" data-listing-price="{{$item['NetPremiumAmt']}}">
    <div class="col-sm-4 logobox">
      <img class="logo" src="{{asset($item['logo'])}}">
    </div>
    <div class="row col-sm-8 logoright">
      <div class="col-md-6">
          <h5 class="card-title price">&#8377;  {{ round($item['NetPremiumAmt']) }}</h5>
          <div style="padding-bottom: 5px">
            <span class="label label-default extrapanelitem  idv">SI : {{(strpos($item['PlanDesc'], 'Europe') !== false || strpos($item['ProductDescription'], 'Schengen')) ? '&#8364;' : '$'}}{{$item['sum-insured']}}</span>
          </div>
      </div>
      <div class="col-md-6 buybutton hvr-grow">
          <form  
             action="{{ route('travel.load_proposal') }}" 
             method="post" 
             id="buy-policy-{{$item['policyId']}}">
             <button type="button" 
                id="buy-btn" 
                class="btn btn-success  btn-md buy-btn"
                data-key ="{{$item['policyId']}}" 
                data-item ="{{$item['policyId']}}">Buy Now</button> 
                  {{ csrf_field() }}
                  <input type="hidden" name="PlanDesc" value="{{ $item['PlanDesc'] }}">
                  <input type="hidden" name="ProductDescription" value="{{ $item['ProductDescription'] }}">
                  @if(array_key_exists('shortDescription',$item))
                  <input type="hidden" name="shortDescription" value="{{ $item['PlanDesc'].' '.$item['shortDescription'] }}">
                  @else 
                  <input type="hidden" name="shortDescription" value="{{ $item['PlanDesc'] }}">
                  @endif
              <input type="hidden" name="productCode" value="{{ $item['productCode'] }}">
              <input type="hidden" name="trans_code" value="{{$item['trans_code']}}">

              
              @if(array_key_exists('Seniorflag',$item) && $item['Seniorflag'] == true)
              <input type="hidden" name="Seniorflag" value="true">
              @else
              <input type="hidden" name="Seniorflag" value="false">
              @endif
		<input type="hidden" name="destinationCode" value="{{ $item['destinationCode'] }}">
		<input type="hidden" name="planCode" value="{{ $item['PlanCode']}}">
		<input type="hidden" name="companyId" value="{{ $item['companyId']}}">
		<input type="hidden" name="policy_id" value="{{$item['policyId']}}">
                <input type="hidden" name="CoverageValue" value="{{( array_key_exists('CoverageValue',$item)) ? $item['CoverageValue'] : null }}">
              	<input type="hidden" name="net_premium_amt" value="{{ round($item['NetPremiumAmt']) }}">
		<input type="hidden" name="tax_amt" value="{{ round($item['TotalTaxAmt']) }}">
              	<input type="hidden" name="proposal_url" value="{{URL::to('travel-insurance/')}}/{{$item['url_code']}}/{{$item['trans_code']}}">
          </form> 
      </div>           
    </div>
    <div class="row">
      <div class="col-md-12">
          <div class="content extrapanel h_icons">
            <span class="extrapanelitem name" style="font-weight: 500">{{$item['ProductDescription']}} {{$item['PlanDesc']}}{{(isset($item['shortDescription']))? ' '.$item['shortDescription'] : ''}}</span>
            &nbsp;
            @if($item['companyId'] == 'hdfc' || $item['companyId'] == 'religare' || $item['companyId'] == 'tata')
                <img class="logo" src="{{URL::to('/')}}/image/easy_emi.jpg"> 
            @endif
              <a href="#" 
                id ="benefits{{$index}}" 
                name ="benefits{{$index}}" 
                class="benefits"
                data-url = "{{route('benefitreq', $item['trans_code'] )}}"
                data-model="benefits_{{ $item['policyId']}}"
                plan-code = "{{$item['PlanCode']}}"
                quote-id = "{{$item['policyId']}}">
                <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" title="View benefits">stars</i></a>

              <a href="#" 
                id="breakup{{$index}}" 
                data-model="breakup_{{ $item['policyId']}}"
                name="breakup{{$index}}" 
                class="breakup"
                data-url = "{{route('breakupreq', $item['trans_code'] )}}"
                plan-code = "{{$item['PlanCode']}}"
                quote-id = "{{$item['policyId']}}">
                <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</i></a>
                                 
          </div>
      </div>
    </div>
  </div>
  <input type="hidden" name="plan-code[]" 
  value="{{ $item['PlanCode']}}" class="plancode">
  @include('travel.quote.quote_benefit_info',['data'=>$benifit])
  @include('travel.quote.quote_premium_breakup',['data'=>$pb])
@endif