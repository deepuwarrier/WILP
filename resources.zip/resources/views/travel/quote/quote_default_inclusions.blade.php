<div class="col-md-12">
   <h6 style="text-align: left"> Default Inclusions in your Insurance Policy </h6>
   <div class="row">
      <div class="col-md-12">
         <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="false">
            <div class="panel panel-default">
               <div class="panel-heading" role="tab">
                  <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne1">Emergency Medical Cover/Expenses</a></h4>
                  <div align="right">
                     <img class="checkmark" src={{asset('image/check.png')}}> 
                  </div>
               </div>
               <div id="collapseOne1" class="panel-collapse collapse">
                  <div class="panel-body">While travelling outside India, if you have to be hospitalised on emergency due to illness or injury, hospitalisation expenses will be covered up to the specified amount.</div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading" role="tab">
                  <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne2">Loss of Passport</a></h4>
                  <div align="right">
                     <img class="checkmark" src={{asset('image/check.png')}}>
                  </div>
               </div>
               <div id="collapseOne2" class="panel-collapse collapse">
                  <div class="panel-body">While travelling outside India, if you lose your passport, then the expenses for obtaining a duplicate or new passport will be paid up to a specified amount.</div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading" role="tab">
                  <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne3">Loss of personal Baggage</a></h4>
                  <div align="right">
                     <img class="checkmark" src={{asset('image/check.png')}}>
                  </div>
               </div>
               <div id="collapseOne3" class="panel-collapse collapse">
                  <div class="panel-body">While travelling outside India if you lose your checked-in baggage and it’s not your fault, you will be compensated with a certain amount.</div>
               </div>
            </div>
            <div class="panel panel-default">
               <div class="panel-heading" role="tab">
                  <h4 class="panel-title pull-left"><a data-toggle="collapse" data-parent="#accordion1" href="#collapseOne4">Accidental Death and Dismemberment Cover</a></h4>
                  <div align="right">
                     <img class="checkmark" src={{asset('image/check.png')}}>
                  </div>
               </div>
               <div id="collapseOne4" class="panel-collapse collapse">
                  <div class="panel-body"> While travelling outside India, if there is death or permanent total disability to the insured person, a certain amount is paid as compensation.</div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>