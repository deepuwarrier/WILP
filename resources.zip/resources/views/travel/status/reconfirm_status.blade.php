<div class="wizard-container paymentcontainer">
<div class="col-sm-8 col-md-offset-2">
<div class="card">
   <div class="content">
      <h5 class="category-social">
         <i class="fa fa-newspaper-o"></i> Well Done!
      </h5>
      <h4 class="card-title">
         <a href="#pablo">We have collected all the information required to issue your policy!</a>
      </h4>
      <p class="card-description">
         Please wait while we contact the insurance company and <b>re-confirm your premium</b>.
      </p>
   </div>
</div>
</div>
</div>