<html>
    <head>
        <title>New Enquiry</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

      <style type="text/css">
        .panel-primary {
            border-color: #337ab7;
        }
        .panel {
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .table {
            margin-bottom: 20px;
            max-width: 100%;
            width: 100%;
        }
        .row {
            margin-left: -15px;
            margin-right: -15px;
        }
        .panel-heading {
            border-bottom: 1px solid transparent;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            padding: 10px 15px;
        }
        .panel-title {
            color: inherit;
            font-size: 16px;
            margin-bottom: 0;
            margin-top: 0;
        }
      </style>
    </head>
    <body>
        <p>A new policy has been applied with the following details</p>
        <?php 
            $triptype = '';
            if($data_value->triptype === 'S'){
                    $triptype = 'Single Trip';
                } elseif($data_value->triptype  === 'M'){
                    $triptype = 'MultiTrip Trip';
                } elseif($data_value->triptype  === 'ST'){
                    $triptype = 'Student Trip';
                } 
             $count = ($data_value->travelcount <2)? 'Single Traveller' : $data_value->travelcount.' Travellers';
            ?>
        <h4>Traveller Details</h4>
        <table class="table table-striped responsive" style="font-size: 12px;">
            <th>Sl</th>
            <th>Name</th>
            <?php if($data_value->triptype != 'ST'){ ?> 
            <th>Relationship</th>
            <?php }?> 
            <th>Dob</th>
            <?php if(isset($data_value->nomineename) && isset($data_value->nomineerel) ) { 
               echo '<th>Nominee Name</th>';
               echo '<th>Relationship</th>';
            } ?> 
            <?php if(isset($data_value->passport)) { 
               echo '<th>Passport No.</th>';
            } ?>   
            @foreach($data_value->name as $index=>$value)
            <tr>
                <td>{{$index+1}}</td>
                <td>{{strtoupper($value)}}</td>
                <?php if($data_value->triptype != 'ST'){ ?> 
                <td>{{strtoupper($data_value->relationship[$index])}}</td>
                <?php }?> 
                <td>{{$data_value->cust_dob[$index]}}</td>
                <?php if(isset($data_value->nomineename[$index]) && isset($data_value->nomineerel[$index])) { 
                        echo '<td>'.strtoupper($data_value->nomineename[$index]).'</td>';
                        echo '<td>'.strtoupper($data_value->nomineerel[$index]).'</td>';
                      }else {
                        if($data_value->travelcount > 1){
                            echo '<td>N/A</td><td>N/A</td>';
                        }
                      }  
                ?>  
             <?php if(isset($data_value->passport)) { 
               echo '<td>'.strtoupper($data_value->passport[$index]).'</td>';
            } ?> 
            </tr>
            @endforeach
        </table>
        <h4>Travel Details</h4>    
        <table class="table responsive" style="font-size: 12px;">
            <tr>
                <td>APPLIED FOR</td>
                <td>{{strtoupper($company_name)}}</td>
            </tr>
            @if(isset($data_value->total_premium))
            <tr>
                <td>TOTAL PREMIUM</td>
                <td>&#8377;{{strtoupper($data_value->total_premium)}}</td>
            </tr>
            @endif
            @if(isset($data_value->tax))
            <tr>
                <td>SERVICE TAX</td>
                <td>&#8377;{{strtoupper($data_value->tax)}}</td>
            </tr>
            @endif
            <tr>
                <td>TRIP TYPE</td>
                <td>{{strtoupper($triptype)}}</td>
            </tr>
            <tr>
                <td>TRAVEL ZONE</td>
                <td>{{strtoupper($zone)}}</td>
            </tr>
            <tr>
                <td>NO. TRAVELLERS</td>
                <td>{{strtoupper($count)}}</td>
            </tr>
            @if(isset($data_value->purpose))

            <tr>
                <td>PURPOSE</td>
                <td>{{isset($data_value->purpose) ? strtoupper($data_value->purpose) : ''}}</td>
            </tr>
            @endif
            <tr>
                <td>DURATION</td>
                <td>{{$data_value->duration + 1 }} DAYS</td>
            </tr>
            <tr>
                <td>START DATE</td>
                <td>{{strtoupper($data_value->startdate)}}</td>
            </tr>
            @if(isset($data_value->si))
            <tr>
                <td>OPTED SUM INSURED</td>
                <td>${{$data_value->si}}</td>
            </tr>
            @endif
            <tr>
                <td>PLAN</td>
                <td>{{$data_value->plancode}}</td>
            </tr>
            @if(isset($data_value->mobile))
            <tr>
                <td>CONTACT NUMBER</td>
                <td>{{$data_value->mobile}}</td>
            </tr>
            @endif
            @if(isset($data_value->email))
            <tr>
                <td>EMAIL ID</td>
                <td>{{strtoupper($data_value->email)}}</td>
            </tr>
            @endif

        </table>
        @if($data_value->triptype == 'ST')
        <h4>Academic Details</h4>
        <table class="table responsive" style="font-size: 12px;">
            @if(isset($data_value->university_name))
            <tr>
                <td>UNIVERSITY NAME</td>
                <td>{{strtoupper($data_value->university_name)}}</td>
            </tr>
            @endif
            @if(isset($data_value->university_address))
            <tr>
                <td>UNIVERSITY ADDRESS</td>
                <td>{{strtoupper($data_value->university_address)}}</td>
            </tr>
            @endif
            @if(isset($data_value->university_country))
            <tr>
                <td>UNIVERSITY COUNTRY</td>
                <td>{{strtoupper($data_value->university_country)}}</td>
            </tr>
            @endif
            @if(isset($data_value->university_state))
            <tr>
                <td>UNIVERSITY STATE</td>
                <td>{{strtoupper($data_value->university_state)}}</td>
            </tr>
            @endif
            @if(isset($data_value->university_city))
            <tr>
                <td>UNIVERSITY CITY</td>
                <td>{{strtoupper($data_value->university_city)}}</td>
            </tr>
            @endif
            @if(isset($data_value->program_name))
            <tr>
                <td>PROGRAM</td>
                <td>{{strtoupper($data_value->program_name)}}</td>
            </tr>
            @endif
            @if(isset($data_value->program_duration))
            <tr>
                <td>PROGRAM DURATION</td>
                <td>{{strtoupper($data_value->program_duration)}}</td>
            </tr>
            @endif
            @if(isset($data_value->sponser_name))
            <tr>
                <td>SPONSER NAME</td>
                <td>{{strtoupper($data_value->sponser_name)}}</td>
            </tr>
            @endif
            @if(isset($data_value->sponser_dob))
            <tr>
                <td>SPONSER DOB</td>
                <td>{{strtoupper($data_value->sponser_dob)}}</td>
            </tr>
            @endif
            @if(isset($data_value->sponser_relationship))
            <tr>
                <td>RELATIONSHIP WITH SPONSER</td>
                <td>{{strtoupper($data_value->sponser_relationship)}}</td>
            </tr>
            @endif
            @if(isset($data_value->guardian_name))
            <tr>
                <td>GUARDIAN NAME</td>
                <td>{{strtoupper($data_value->guardian_name)}}</td>
            </tr>
            @endif
            @if(isset($data_value->guardian_relationship))
            <tr>
                <td>RELATIONSHIP WITH GUARDIAN</td>
                <td>{{strtoupper($data_value->guardian_relationship)}}</td>
            </tr>
            @endif
            @if(isset($data_value->guardian_dob))
            <tr>
                <td>GUARDIAN DOB</td>
                <td>{{strtoupper($data_value->guardian_dob)}}</td>
            </tr>
            @endif
        </table>    
        @endif
        </div>
    </body>
</html>
