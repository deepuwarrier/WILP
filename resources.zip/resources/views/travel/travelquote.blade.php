@include('travel.layouts.inn-hdr')
    <input type="hidden" name="trans_code" value="{{ $trans_code }}" id="trans_code">
    <div class="cd-section" id="carwizard">
        <meta name="csrf-token" content="{{ csrf_token() }}">
         <div class="col-sm-12 removepaddingsmallscreen">
            <!--      Wizard container        -->
            <div class="wizard-container">
               <div class="col-sm-4">
                  {!!$selection_box!!}
                  <div class="card" id="confirm_update">
                            <div class="col-xs-12">
                              <div class="titleinput">
                                 <h6>Choose your Sum Insured:</h6>
                              </div>
                            </div>
                           <div class="col-xs-4" style="padding:0 0 10px 10px">
                              <div class="labelleft">
                                 <a href="#"><p data-toggle="tooltip" data-placement="top" onclick='jQuery("#SI").modal();'title="Click to know how to choose the Sum Insured">Sum Ins. ($)</p></a>
                              </div>
                            </div>
                           <form  action=" {{route('travel.getquotes', $trans_code)}} " method="post" id="update-si">
                           <div class="col-xs-8" style="padding:0 10px 10px 0">
                              <div class="labelright">
                                    <div class="xQty">
                                      <input type="button" value="-" class="qtyminus upqtyminus" field="sum-insured"/>
                                      <input type="text" id= 'sum_insured_box' name="sum-insured" value="{{ $request['sum-insured'] }}" class="qtyValue" readonly/>
                                      <input type="button" value="+" class="qtyplus upqtyplus" field="sum-insured"/>
                                    </div>  
                              </div>
                           </div>

                           <div class="col-xs-12">
                              <div class="titleinput" style="padding:0" id="idv_footer">
                                 <button type="button" class="btn btn-primary btn-xs pull-right" id="update-si-btn">Update Quotes</button>
                              </div>
                           </div>
                          {{ method_field('GET') }}
                        </form>
                        <input type="hidden" name="range-hid" id="range-hid" value="1">
                  </div>
     
                  <div class="card" style="background-color: #186e7d">
                        <img src="{{asset('image/travel.gif')}}" alt="Travel Insurance">

                  </div>
               </div>
               <div class="col-sm-4">
                  <div class="card card-form-horizontal">
                     <div class="row accordion"> 
                      {!!$cov_data!!}
                     </div>
                     <div id ="cover_box"  class="row accordion"> 
                     </div>
                  </div>
               </div>
              
              <!--Quote Response Starts  -->
              <div class="col-sm-4">
                <div id="quote_ctnr_box"></div>
                <div id="load_quote_box"><h5 class="card-title price">-- Loading Quotes --  </h5> 
                </div>
                <div id="no_quotes">
                   <p id="no_quote_text" class="hidden">
                      We did not get a quote from the bellow insurers
                   </p>
                </div>
                <div id="error_message" class="hide"></div>
                <div id="tata_quote_ctnr_box" status="0"></div>
                <div id="hdfc_quote_ctnr_box" status="0"></div> 
                <div id="star_quote_ctnr_box" status="0"></div>
                <div id="religare_quote_ctnr_box" status="0"></div>
                <div id="fggi_quote_ctnr_box" status="0"></div> 
                <div id="ld_loader"></div>
                <div class="row" id='email_quotes_div'>
                     <button onclick='jQuery("#email").modal();' type="button" class="btn btn-info btn-simple btn-xs pull-left" data-toggle="modal" data-target="#email_quote_modal">Email Quotes</button>
                     <!-- <button type="button" class="btn btn-info btn-simple btn-xs pull-right">Load More Quotes</button> -->
                  </div>
              </div>
              <!--Quote Response Ends  -->

            <!-- wizard container -->
         </div>
         <div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="Premium Breakup">
         </div>
         <!-- Package modal -->
         <div class="modal fade" id="BenefitModal" tabindex="-1" role="dialog" aria-labelledby="Benefits">
        </div>
      </div> 
 </div>     
<div class="" id="">&nbsp;</div>
<input type="hidden" name="filter_req" id="filter_req" value="{{route('travel_filter_quote', $trans_code )}}"> 
<input type="hidden" name="save_policyid" id="save_policyid" value="{{route('save_policyid', $trans_code )}}"> 
<input type="hidden" name="map_si_url" id="map_si_url" value="{{route('map_sum_insured')}}"> 
<!-- Modal for email quote starts below -->
<div class="modal fade" id="email_quote_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog">
           <form id="email_quote_form" method="POST">
              <input type="hidden" name="quote_form_url" id="quote_form_url" value="{{URL::route('send-quote-mail')}}">
               <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
                      <h4 class="modal-title" id="QuoteLabel"> E-mail Quotes</h4>
                  </div>
                     <div class="modal-body">    
                        {{ csrf_field() }}
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                           <input type="text" id="email_quote_name" name="email_quote_name" class="form-control" placeholder="Your name">
                        </div>
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                           <input type="email" id="email_quote" name="email_quote" class="form-control" placeholder="your@email.com">
                        </div>
                        <br />
                        <span id="quote_email_message"></span>
                     </div>
                     <div class="modal-footer">
                        <button type="button" id="quote_email_submit" value="sub" name="sub" class="btn btn-primary" ><i class="fa fa-share"></i> Send </button>
                     </div>
               </div>
            </form>
         </div>
      </div>
<!-- Modal for email quote ends abow -->
@include('travel.layouts.inn-ftr')
<script src="{{ URL::asset('js/travel/travelquote.js') }}"></script>
<script type="text/javascript" language="JavaScript"> $( document ).ready(function() { load_quotes();  }); </script>