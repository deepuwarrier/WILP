<span>
<div class="col-sm-5">
         <select name="relationship[]" id="member" class="form-control relationship valid" aria-invalid="false" age-id = "{{$id}}" >
            <option hidden="" selected="" disabled="" value="">Select Relationship</option>
            @foreach($data as $index => $item)
            <option value="{{$item['relationship_id']}}">{{$item['relationship_name']}}</option>
            @endforeach
         </select>
         <span class="material-input"></span>
      </div>
      <div class="col-sm-5">
         <select name="age[]" id="{{$id}}" class="age form-control valid" aria-invalid="false">
            <option hidden="" selected="" disabled="" value="">Select Age</option>
         </select>
      </div>
      <div class="col-sm-2" id="add-container">
       <input id ="remove_traveller" type="button" class="material-icons del btn-primary" value="remove"/>
      </div>
</span>      