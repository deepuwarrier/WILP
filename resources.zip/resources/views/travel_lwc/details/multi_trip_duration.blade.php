<h6> Select the duration of your Travel</h6>
<div class="container tabdata" >          
     <input class="duration btn btn-fill btn-white btn-wd" name="duration" id="30_days" info-id ="SM" value="Less than 30 Days" type="button">
     <input class="duration btn  btn-fill btn-white btn-wd" name="duration" id="45_days" info-id ="ME"  value="Less than 45 Days" type="button">
     <input class="duration btn  btn-fill btn-white btn-wd" name="duration" id="60_days" info-id ="LA"  value="Less than 60 Days" type="button">
      <input class="duration btn  btn-fill btn-white btn-wd" name="duration" id="90_days" info-id ="L90" value="Less than 90 Days" type="button">
 </div>