<input class="area btn btn-fill btn-white btn-wd" name="area" id="world_wide" info-id ="1" value="World Wide" type="button" >
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="world_wide_excl_usa" info-id ="6" value="Word Wide - Excluding USA" type="button">
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="world_wide_excl_usa_can" info-id ="2" value="Word Wide - Excluding USA & Canada" type="button"> 
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="asia" info-id ="3" value="Asia" type="button">
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="africa" info-id ="5" value="Africa" type="button">
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="europe" info-id ="4" value="Europe" type="button">
<input class="area btn  btn-fill btn-white btn-wd" name="area" id="schengen" info-id ="7" value="Schengen" type="button">