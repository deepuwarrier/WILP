@foreach($response as $city )
  <option value = "{{$city['city_name']}}">{{strtoupper($city['city_name'])}}</option>
@endforeach
