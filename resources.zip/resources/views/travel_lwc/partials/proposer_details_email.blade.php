<html>
    <head>
        <title>New Enquiry</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
        table {
            font-size: 100%;
        }
        </style>
    </head>
    <body>
        <p>A new policy has been applied with the following details</p>
        <?php 
            $triptype = '';
            if($data_value->triptype === 'S'){
                    $triptype = 'Single Trip';
                } elseif($data_value->triptype  === 'M'){
                    $triptype = 'MultiTrip Trip';
                } elseif($data_value->triptype  === 'ST'){
                    $triptype = 'Student Trip';
                } 
             $count = ($data_value->travelcount <2)? 'Single Traveller' : $data_value->travelcount.' Travellers';
            ?>
        <h4>Travel Details</h4>    
        <table class="table table-striped responsive">
            <tr>
                <td>APPLIED FOR</td>
                <td>{{strtoupper($company)}}</td>
            </tr>
            <tr>
                <td>TRIP TYPE</td>
                <td>{{strtoupper($triptype)}}</td>
            </tr>
            <tr>
                <td>TRAVEL ZONE</td>
                <td>{{strtoupper($zone)}}</td>
            </tr>
            <tr>
                <td>NO. TRAVELLERS</td>
                <td>{{strtoupper($count)}}</td>
            </tr>
            @if(isset($data_value->purpose))

            <tr>
                <td>PURPOSE</td>
                <td>{{isset($data_value->purpose) ? strtoupper($data_value->purpose) : ''}}</td>
            </tr>
            @endif
            <tr>
                <td>DURATION</td>
                <td>{{$data_value->duration}} DAYS</td>
            </tr>
            <tr>
                <td>START DATE</td>
                <td>{{strtoupper($data_value->startdate)}}</td>
            </tr>
            @if(isset($data_value->si))
            <tr>
                <td>Opted Sum Insured</td>
                <td>{{$data_value->si}}</td>
            </tr>
            @endif
            <tr>
                <td>PLAN</td>
                <td>{{$data_value->plancode}}</td>
            </tr>
            @if(isset($data_value->mobile))
            <tr>
                <td>CONTACT NUMBER</td>
                <td>{{$data_value->mobile}}</td>
            </tr>
            @endif
            @if(isset($data_value->email))
            <tr>
                <td>EMAIL ID</td>
                <td>{{strtoupper($data_value->email)}}</td>
            </tr>
            @endif
            <!-- HDFC Response -->
            @if(isset($hdfc_data) && ($hdfc_data['Msg'] == 'Successfull' || $hdfc_data['Msg'] == 'Successful'))
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Successful')}}</td>
                </tr>
                <tr>
                    <td>POLICY NUMBER</td>
                    <td>{{strtoupper($hdfc_data['PolicyNo'])}}</td>
                </tr>
                <tr>
                    <td>PROPOSAL NUMBER</td>
                    <td>{{strtoupper($hdfc_data['ProposalNo'])}}</td>
                </tr>
            @endif
            @if(isset($hdfc_data) && ($hdfc_data['Msg'] != 'Successfull' ))
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Failed')}}</td>
                </tr>
                <tr>
                    <td>PROPOSAL NUMBER</td>
                    <td>{{strtoupper($hdfc_data['ProposalNo'])}}</td>
                </tr>
            @endif
            <!-- HDFC Response ends -->

            <!-- TATA AIG Response -->
            @if(isset($response) && $response != null)
                <tr>
                    <td>TRANSACTION AMOUNT</td>
                    <td>&#8377;{{round($response[4])}}</td>
                </tr>
                @if($response[6] == '0300')
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Successful')}}</td>
                </tr>
                <tr>
                    <td>POLICY NUMBER</td>
                    <td>{{strtoupper($policyno)}}</td>
                </tr>
                <tr>
                    <td>REFERENCE NUMBER</td>
                    <td>{{strtoupper($response[2])}}</td>
                </tr>
                @else
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Failed')}}</td>
                </tr>
                <tr>
                    <td>REASON FOR FAILURE</td>
                    <td>{{strtoupper($response[5])}}</td>
                </tr>
                <tr>
                    <td>REFERENCE NUMBER</td>
                    <td>{{strtoupper($response[2])}}</td>
                </tr>
                @endif
            @endif    
            <!-- TATA AIG Response ends -->

            <!-- Religare Response -->
            @if(isset($religare_data) && $religare_data['policyNumber'] != null)
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Successful')}}</td>
                </tr>
                <tr>
                    <td>POLICY NUMBER</td>
                    <td>{{strtoupper($religare_data['policyNumber'])}}</td>
                </tr>
                <tr>
                    <td>TRANSACTION NUMBER</td>
                    <td>{{strtoupper($religare_data['transactionRefNum'])}}</td>
                </tr>
            @endif
            
            @if(isset($religare_data) && $religare_data['policyNumber'] == null)
                <tr>
                    <td>TRANSACTION STATUS</td>
                    <td>{{strtoupper('Failed')}}</td>
                </tr>
                <tr>
                    <td>REASON FOR FAILURE</td>
                    <td>{{strtoupper($religare_data['errorMsg'])}}</td>
                </tr>
                <tr>
                    <td>TRANSACTION NUMBER</td>
                    <td>{{strtoupper($religare_data['transactionRefNum'])}}</td>
                </tr>
            @endif
           <!-- Religare Response ends --> 
        </table>
        <h4>Traveller Details</h4>
        <table class="table table-striped responsive">
            <th>Sl</th>
            <th>Name</th>
            <th>Relationship</th>
            <th>Dob</th>
            <?php if(isset($data_value->nomineename)) { 
               echo '<th>Nominee Name</th>';
               echo '<th>Relationship</th>';
            } ?> 
            <?php if(isset($data_value->passport)) { 
               echo '<th>Passport No.</th>';
            } ?>   
            @foreach($data_value->name as $index=>$value)
            <tr>
                <td>{{$index+1}}</td>
                <td>{{strtoupper($value)}}</td>
                <td>{{strtoupper($data_value->relationship[$index])}}</td>
                <td>{{$data_value->cust_dob[$index]}}</td>
                <?php if(isset($data_value->nomineename)) { 
               echo '<td>'.strtoupper($data_value->nomineename[$index]).'</td>';
               echo '<td>'.strtoupper($data_value->nomineerel[$index]).'</td>';
            } ?>  
             <?php if(isset($data_value->passport)) { 
               echo '<td>'.strtoupper($data_value->passport[$index]).'</td>';
            } ?> 
            </tr>
            @endforeach
        </table>
    </body>
</html>