<div class="col-md-12">
   <h6> Select the Must Haves for you! </h6>
   <div class="row">
        @foreach($common as $index=>$data)
           <?php $cover_title =  (new \App\Be\Travel\TravelQuoteBe)->getCoverTitle($data);?>
           <?php $cover_name  =  (new \App\Be\Travel\TravelQuoteBe)->getCoverName($data);?>
           <div class="col-md-6">
           <label class="card-raised checkboxcard" data-toggle="tooltip" data-placement="top" title="" data-container="body" data-original-title="{{$cover_name}}">
           <input class="filter_quote" name="travel_cov" type="checkbox" id="{{$data}}" value="{{$data}}" checked><span class="checkbox-material"><span class="check"></span></span>
           {{$cover_title}}
         </label >
         </div>
        @endforeach
        @foreach($other as $index=>$data)
           <?php $cover_title =  (new \App\Be\Travel\TravelQuoteBe)->getCoverTitle($data);?>
           <?php $cover_name  =  (new \App\Be\Travel\TravelQuoteBe)->getCoverName($data);?>
           <div class="col-md-6">
           <label class="card-raised checkboxcard" data-toggle="tooltip" data-placement="top" title="" data-container="body" data-original-title="{{$cover_name}}">
           <input  class="filter_quote" name="travel_cov" type="checkbox" value="{{$data}}" id="{{$data}}" ><span class="checkbox-material"><span class="check"></span></span>
           {{$cover_title}}
         </label>
         </div>
        @endforeach
   </div>
</div>