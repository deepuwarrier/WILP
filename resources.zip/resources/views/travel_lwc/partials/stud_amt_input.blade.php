<div class="row datarepeaterbox">
   <div class="col-xs-6">
      <select name="relationship[]" id="member" class="form-control relationship valid" aria-invalid="false" required>
         <option value="1">Self</option>
      </select>
      <span class="material-input"></span>
   </div>
   <div class="col-xs-6">
      <select name="age" id="age" class="age form-control valid" aria-invalid="false">
         <option value="">Select Age</option>
         @if($request['type'] == 'ST')
            @for($i=12; $i<=40 ; $i++)
            <option value="{{$i}}" {{($request['self']!= null && $request['self'] == $i) ? 'selected' : ''}}>{{$i}} Years</option>
            @endfor
         @else  
            @for($i=18; $i<=70 ; $i++)
            <option value="{{$i}}" {{($request['self']!= null && $request['self'] == $i) ? 'selected' : ''}}>{{$i}} Years</option>
            @endfor 
         @endif   
      </select>
      <span class="material-input"></span>
   </div>
</div>