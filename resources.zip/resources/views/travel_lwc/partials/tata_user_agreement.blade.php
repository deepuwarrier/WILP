<div class="wizard-container paymentcontainer">
   <div class="col-sm-8 col-md-offset-2">
      <div class="card">
         <div class="content">
          @if($data)
            <h5 class="category-social">
               Terms &amp; Conditions
            </h5>
            @if($data['triptype'] === 'ST')
            <h4 class="card-title"></h4>
               <div class="col-xs-12" style="text-align: left; overflow:auto; height: 300px; font-weight: normal; color: #474240!important; line-height: 1.5em">
                  <p>I declare that the information provided in this application is correct. The insured is currently in India and is a resident of India holding a valid Indian passport/Indian work or residence permit.The applicant is above 16 years of age. I also confirm that this policy is not being issued to cover risks directly or indirectly associated with travel in, to, or through Afghanistan, Cuba or Democratic Republic of Congo I/ We hereby declare, on my behalf and on behalf of all persons proposed to be insured that the above statements, answers and/or particulars given by me are true and complete in all respects to the best of my knowledge and that I/We am/ are authorized to propose on behalf of these other persons. I/ We understand that the information provided by me will form the basis of insurance policy, is subject to the Board approved underwriting policy of the Insurance company and that the policy will come into force only after full receipt of the premium chargeable. I/ We further declare that I/We will notify in writing any change occurring in the occupation or general health of the life to be insured/ proposer after the proposal has been submitted but before communication of the risk acceptance by the company. I/We declare and consent to the company seeking medical information from any doctor or from a hospital who at anytime has attended on the life to be insured/ proposer or from any past or present employer concerning anything which affects the physical and mental health of the life to be assured/proposer and seeking information from any insurance company to which an application for insurance on the life to be assured/ proposer has been made for the purpose of underwriting the proposal and/or claim settlement. I/ We authorize the company to share information pertaining to my proposal including the medical records for the sole purpose of proposal underwriting and/or claims settlement and with any Governmental and/or Regulatory Authority.</p>
                  <p><strong>AML guidelines</strong>:</p>
                   <ol> 
                     <li>I/We hereby confirm that all premiums have been/will be paid from bonafide sources and no premiums have been/will be paid out of proceeds of crime related to any of the offence listed in preventions of Money Laundering Act, 2002</li>
                     <li>I understand that the Company has the right to call for documents to establish sources of funds</li>
                     <li>The insurance Company has right to cancel the insurance contract in case I am/have been found guilty by any competent court of law under any of the statutes,directly or indirectly governing the prevention of money laundering in India</li>
                   </ol>  
                  <p><strong>Section 41 of Insurance Act 1938 (Prohibition of rebates)</strong></p>
                  <ol>
                   <li>No person shall allow or offer to allow either directly or indirectly as an inducement to any person to take out or renew or continue an insurance in respect of any kind of risk relating to lives or property in India, any rebate of the whole or part of the commission payable or any rebate of premium shown on the policy, nor shall any person taking out or renewing or continuing a policy accept any rebate, except such rebate as may be allowed in accordance with the published prospectus or tables of the insurer</li>
                   <li>Any person making default in complying with the provisions of this section shall be liable for penalty which may extend to ten lakh rupees</li>
                  </ol>   
                  <p><strong>64VB</strong>:</p>
                  <p>Commencement of risk cover under the policy is subject to receipt of premium by Tata AIG General Insurance Company Limited</p>
                  <p><strong>General Exclusions:</strong></p>
                  <p>This entire Policy does not provide benefits for any loss resulting in whole or in part from, or expenses incurred, directly or indirectly in respect of</p>
                  <ol>
                     <li>where the Insured Person is travelling against the advice of a Physician; or receiving or on a waiting list for receiving specified medical treatment; or is travelling for the purpose of obtaining treatment; or has received a terminal prognosis for a medical condition; or</li>
                     <li>any Pre-existing Condition or any complication arising there from it; or</li>
                     <li>suicide, attempted suicide (whether sane or insane) or intentionally self-inflicted Injury or Illness, or sexually transmitted conditions, mental or nervous disorder, anxiety, stress or depression, Acquired Immune Deficiency Syndrome (AIDS), Human Immune deficiency Virus (HIV) infection; or</li>
                     <li>serving in any branch of the Military or Armed Forces of any country, whether in peace or War, and in such an event We, upon written notification by You, shall return the pro rata premium for any such period of service under the circumstances described in a Hazard ; or</li>
                     <li>being under the influence of drugs, alcohol, or other intoxicants or hallucinogens unless properly prescribed by a Physician and taken as prescribed; or</li>
                     <li>participation in an actual or attempted felony, riot, crime,misdemeanor, or civil commotion; or</li>
                     <li>operating or learning to operate any aircraft, or performing duties as a member of the crew on any aircraft; or</li>
                     <li>any loss arising out of War, civil war, invasion, insurrection,revolution, act of foreign enemy, hostilities (whether War be declared or not), rebellion, mutiny, use of military power or usurpation of government or military power; or</li>
                     <li>ionising radiation or contamination by radioactivity from any nuclear fuel or from any nuclear waste from burning nuclear fuel;or</li>
                     <li>the radioactive, toxic, explosive or other dangerous properties of any explosive nuclear equipment or any part of that equipment;or</li>
                     <li>self exposure to needless peril (except in an attempt to save human life); or</li>
                     <li>congenital anomalies or any complications or conditions arising therefrom; or</li>
                     <li>participation in winter sports, skydiving/parachuting, hang gliding,bungee jumping, scuba diving, mountain climbing (where ropes or guides are customarily used), riding or driving in races or rallies using a motorized vehicle or bicycle, caving or pot-holing, hunting or equestrian activities, skin diving or other underwater activity,rafting or canoeing involving white water rapids, yachting or boating outside coastal waters (2 miles), participation in any Professional Sports, any bodily contact sport or any other hazardous or potentially dangerous sport for which You are untrained. This exclusion does not apply to injuries resulting from inter collegiate sports</li>
                     <li>the Insured Person riding on a motorcycle or any other motorized two wheeledmodeof conveyance as driver or as passenger</li>
                     <li>any loss resulting directly or indirectly, contributed or aggravated or prolonged by childbirth or from pregnancy, or</li>
                     <li>for any loss of which a contributing cause was Your actual or attempted commission of, or willful participation in, an illegal act or any violation or attempted violation of the law or Your resistance to arrest;</li>
                     <li>any loss, injury, damage or legal liability arising directly or indirectly from: Travel in, to, or through Afghanistan, Cuba or Democratic Republic of Congo; or</li>
                     <li>any loss, injury, damage or legal sustained directly or indirectly by:Any terrorist or member of a terrorist organization, narcotics trafficker, or purveyor of nuclear, chemical or biological weapons</li>

                  </ol>
                  For complete list of detailed exclusion, please refer policy wordings
               </div>
               @elseif($data['triptype'] === 'S' && $data['area'] === '0')
               <div class="col-xs-12" style="text-align: left; overflow:auto; height: 300px; font-weight: normal; color: #474240!important; line-height: 1.5em">
                  <p>I declare that the information provided in this application is correct. The insured is currently in India and is a resident of India holding a valid Indian passport/Indian work or residence permit.The applicant is above 18 years of age. I also confirm that this policy is not being issued to cover risks directly or indirectly associated with travel in, to, or through Afghanistan, Cuba or Democratic Republic of Congo I/ We hereby declare, on my behalf and on behalf of all persons proposed to be insured that the above statements, answers and/or particulars given by me are true and complete in all respects to the best of my knowledge and that I/We am/ are authorized to propose on behalf of these other persons. I/ We understand that the information provided by me will form the basis of insurance policy, is subject to the Board approved underwriting policy of the Insurance company and that the policy will come into force only after full receipt of the premium chargeable.I/ We further declare that I/We will notify in writing any change occurring in the occupation or general health of the life to be insured/ proposer after the proposal has been submitted but before communication of the risk acceptance by the company. I/We declare and consent to the company seeking medical information from any doctor or from a hospital who at anytime has attended on the life to be insured/ proposer or from any past or present employer concerning anything which affects the physical and mental health of the life to be assured/proposer and seeking information from any insurance company to which an application for insurance on the life to be assured/ proposer has been made for the purpose of underwriting the proposal and/or claim settlement. I/ We authorize the company to share information pertaining to my proposal including the medical records for the sole purpose of proposal underwriting and/or claims settlement and with any Governmental and/or Regulatory Authority. </p>
                  <p><strong>AML guidelines</strong>:</p>
                   <ol> 
                     <li>  I/We hereby confirm that all premiums have been/will be paid from bonafide sources and no premiums have been/will be paid out of proceeds of crime related to any of the offence listed in preventions of Money Laundering Act, 2002</li>
                     <li>I understand that the Company has the right to call for documents to establish sources of funds</li>
                     <li>The insurance Company has right to cancel the insurance contract in case I am/have been found guilty by any competent court of law under any of the statutes,directly or indirectly governing the prevention of money laundering in India</li>
                   </ol>  
                  <p><strong>Section 41 of Insurance Act 1938 (Prohibition of rebates)</strong></p>
                  <ol>
                   <li>No person shall allow or offer to allow either directly or indirectly as an inducement to any person to take out or renew or continue an insurance in respect of any kind of risk relating to lives or property in India, any rebate of the whole or part of the commission payable or any rebate of premium shown on the policy, nor shall any person taking out or renewing or continuing a policy accept any rebate, except such rebate as may be allowed in accordance with the published prospectus or tables of the insurer</li>
                   <li>Any person making default in complying with the provisions of this section shall be liable for penalty which may extend to ten lakh rupees</li>
                  </ol>   
                  <p><strong>64VB</strong>:</p>
                  <p>Commencement of risk cover under the policy is subject to receipt of premium by Tata AIG General Insurance Company Limited</p>
                  <p><strong>General Exclusions:</strong></p>
                  <p>This entire Policy does not provide benefits for any loss resulting in whole or in part from, or expenses incurred, directly or indirectly in respect of</p>
                  <ol>
                     <li>where the Insured Person is travelling against the advice of a Physician; or receiving or on a waiting list for receiving specified medical treatment; or is travelling for the purpose of obtaining treatment; or has received a terminal prognosis for a medical condition; or</li>
                     <li>any Pre-existing Condition or any complication arising there from it; or</li>
                     <li>suicide, attempted suicide (whether sane or insane) or intentionally self-inflicted Injury or Illness, or sexually transmitted conditions, mental or nervous disorder, anxiety, stress or depression, Acquired Immune Deficiency Syndrome (AIDS), Human Immune deficiency Virus (HIV) infection; or</li>
                     <li>being under the influence of drugs, alcohol, or other intoxicants or hallucinogens unless properly prescribed by a Physician and taken as prescribed; or</li>
                     <li>participation in an actual or attempted felony, riot, crime,misdemeanor, or civil commotion; or</li>
                  </ol>
                  For complete list of detailed exclusion, please refer policy wordings
               </div>
               @else
               <div class="col-xs-12" style="text-align: left; overflow:auto; height: 300px; font-weight: normal; color: #474240!important; line-height: 1.5em">
                  <p>I declare that the information provided in this application is correct.The insured is currently in India and is a resident of India holding a valid Indian passport/Indian work or residence permit.The applicant is above 18 years of age.I also confirm that this policy is not being issued to cover risks directly or indirectly associated with travel in, to, or through Afghanistan, Cuba or Democratic Republic of Congo.I/ We hereby declare, on my behalf and on behalf of all persons proposed to be insured that the above statements, answers and/or particulars given by me are true and complete in all respects to the best of my knowledge and that I/We am/ are authorized to propose on behalf of these other persons.I/ We understand that the information provided by me will form the basis of insurance policy, is subject to the Board approved underwriting policy of the Insurance company and that the policy will come into force only after full receipt of the premium chargeable.I/ We further declare that I/We will notify in writing any change occurring in the occupation or general health of the life to be insured/ proposer after the proposal has been submitted but before communication of the risk acceptance by the company.I/We declare and consent to the insurance company seeking medical information from any doctor or from a hospital who at anytime has attended on the life to be insured/ proposer or from any past or present employer concerning anything which affects the physical and mental health of the life to be assured/proposer and seeking information from any insurance company to which an application for insurance on the life to be assured/ proposer has been made for the purpose of underwriting the proposal and/or claim settlement.I/ We authorize the insurance company to share information pertaining to my proposal including the medical records for the sole purpose of proposal underwriting and/or claims settlement and with any Governmental and/or Regulatory Authority.</p>
                  <p><strong>AML guidelines</strong>:</p>
                   <ol> 
                     <li>  I/We hereby confirm that all premiums have been/will be paid from bonafide sources and no premiums have been/will be paid out of proceeds of crime related to any of the offence listed in preventions of Money Laundering Act, 2002</li>
                     <li>I understand that the Company has the right to call for documents to establish sources of funds</li>
                     <li>The insurance Company has right to cancel the insurance contract in case I am/have been found guilty by any competent court of law under any of the statutes,directly or indirectly governing the prevention of money laundering in India</li>
                   </ol>  
                  <p><strong>Section 41 of Insurance Act 1938 (Prohibition of rebates): Statutory warning </strong></p>
                  <ol>
                   <li>No person shall allow or offer to allow either directly or indirectly as an inducement to any person to take out or renew or continue an insurance in respect of any kind of risk relating to lives or property in India, any rebate of the whole or part of the commission payable or any rebate of premium shown on the policy, nor shall any person taking out or renewing or continuing a policy accept any rebate, except such rebate as may be allowed in accordance with the published prospectus or tables of the insurer</li>
                   <li>Any person making default in complying with the provisions of this section shall be liable for penalty which may extend to ten lakh rupees</li>
                  </ol>   
                  <p><strong>64VB</strong>:</p>
                  <p>Commencement of risk cover under the policy is subject to receipt of premium by Tata AIG General Insurance Company Limited</p>
                  <p><strong>General Exclusions:</strong></p>
                  <ol>
                     <li>Insured Person is traveling against the advice of a Physician; or is travelling for the purpose of obtaining treatment</li>
                     <li>Any Pre-existing Condition or any complication arising from it; or</li>
                     <li>Suicide, attempted suicide (whether sane or insane) or intentionally self inflicted Injury or Illness, or sexually transmitted conditions, mental or nervous disorder, anxiety, stress or depression, Acquired Immune Deficiency Syndrome (AIDS), Human Immune deficiency Virus (HIV) infection; or</li>
                     <li>Serving in any branch of the Military or Armed Forces of any country, whether in peace or War</li>
                     <li>Being under the influence of drugs, alcohol, or other intoxicants or hallucinogens unless properly prescribed by a Physician and taken as prescribed; or</li>
                     <li>Participation in an actual or attempted felony, riot, crime, misdemeanor, or civil commotion; or</li>
                     <li>Operating or learning to operate any aircraft, or performing duties as a member of the crew on any aircraft or Scheduled Airline; or</li>
                     <li>Any loss arising out of War, civil war, invasion, insurrection, revolution, act of foreign enemy</li>
                     <li>Any loss, damage cost or expense of whatsoever nature directly or indirectly caused by, resulting from or in connection with any act of terrorism</li>
                     <li>Any loss arising out of the intentional use of military force to intercept, prevent, or mitigate any known or suspected Act of Terrorism;or</li>
                     <li>The use, release or escape of nuclear materials that directly or indirectly results in nuclear reaction or radiationor radioactive contamination;</li>
                     <li>The radioactive, toxic, explosive or other dangerous properties of any explosive nuclear equipment or any part of that equipment; or</li>
                     <li>Performance of manual work for employment or any other potentially dangerous occupation; or</li>
                     <li>Congenital anomalies or any complications or conditions arisingtherefrom; or</li>
                     <li>Osteoporosis (porosity and brittleness of the bones due to loss of protein from the bones matrix) or pathological fracture (any fracture in an area where pre-existing Disease has caused the weakening of the bone)</li>
                     <li>Participation in winter sports, skydiving/parachuting, hang gliding, bungee jumping, scuba diving, mountain climbing</li>
                     <li>Pregnancy and all related conditions, This however does not include ectopic pregnancy proved by diagnostic means and is certified to be life threatening by the Physician; or</li>
                     <li>For any loss of which a contributing cause was your actual or attempted commission of, or willful participation in, an illegal act or any violation or attempted violation of the law or Your resistance to arrest;</li>
                     <li>Any loss, injury, damage or legal liability arising directly or indirectly from: Travel in, to, or through Afghanistan, Cuba or Democratic Republic of Congo; or</li>
                     <li>Any loss, injury, damage or legal sustained directly or indirectly by: Any terrorist or member of a terrorist organisation, narcotics trafficker, or purveyor of nuclear, chemical or biological weapons</li>
                  </ol>
                  For complete list of detailed exclusion, please refer policy wordings
               </div>
               @endif
               <div class="" style="float: right;">
                     <label><input type="checkbox" value="1" id="agree_btn">&nbsp;I, have read and understood the @if($data['triptype'] === 'ST')
                     <a href="https://www.tataaiginsurance.in/taig/taig/tata_aig/about_us/Media_Centre/pdf/policy_wordings/student_guard.pdf" target="_blank"><u>policy wordings</u></a>
                     @elseif($data['triptype'] === 'S' && $data['area'] == '3')
                     <a href="https://www.tataaiginsurance.in/taig/taig/tata_aig/about_us/Media_Centre/pdf/policy_wordings/Asia_Travel_Guard_Policy_Wording.pdf" target="_blank"><u>policy wordings</u></a>
                     @else
                     <a href="https://www.tataaiginsurance.in/about-us/Media_Centre/pdf/policy_wordings/Travel_Guard_Policy_Wording.pdf" target="_blank"><u>policy wordings</u></a>
                     @endif
                     and above mentioned Terms &amp; Conditions
                     </label>
                     <span style="width: 2%;">&nbsp;&nbsp;</span>&nbsp;&nbsp;
                     <a href="#" id="close_agreement"><label>Close</label></a>
               </div>
         @else
            <h5 class="category-social">
               Unable to fetch user agreement this time !. Please try again
            </h5>
            <h6 class="category-social">
               If you are seeing this message more than 3 attempts, Call us at: +91 7899-000-333 
            </h6>   
            <div class="" style="float: right;">
              <span style="width: 2%;">
                <a href="#" id="close_agreement"><label>Close</label></a>
              </span>  
            </div> 
         @endif <!--  end of data check  -->  
          
         </div>
      </div>
   </div>
</div>