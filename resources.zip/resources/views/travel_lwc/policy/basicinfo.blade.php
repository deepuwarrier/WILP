<div class="wizard-container">
         <div class="col-md-4">
            <div class="card card-form-horizontal" style="min-height:130px">
               <div class="content">
                  <div class="row">
                     <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right"  href="{{route('updatereq')}}">Change</a>
                     </div>
                     <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Generating Policy For :</h6>
                     </div>
                  </div>
                  <div class="row content" style="text-align: left">
                     <span class="label label-default">{{$data['basic_info']['trip_info']}}</span>
                     <span class="label label-default">{{$data['basic_info']['location_info']}}</span>
                     <span class="label label-default">{{$data['basic_info']['member_info']}}</span>
                     <span class="label label-default">Age : {{$data['basic_info']['age_info']}}</span>
                  </div>
               </div>
            </div>
         </div>
         <!-- wizard container -->
         <div class="col-md-4">
            <div class="card card-form-horizontal" style="min-height:130px">
               <div class="content">
                  <div class="row">
                     <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right" href="{{route('travel.getquotes', $data['userdata']['trans_code'])}}">Change</a>
                     </div>
                     <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information : </h6>
                     </div>
                  </div>
                  <table class="table customtable">
                     <tbody>
                        <tr>
                           <td>Product</td>
                           <td class="text-right">{{$data['basic_info']['product_title']}}</td>
                           <td>Plan</td>
                           <td class="text-right">{{$data['basic_info']['plan_title']}}</td>
                        </tr>
                        <tr>
                           <td>Sum Insured</td>
                           <td class="text-right">{{$data['basic_info']['sum_insured']}}</td>
                           <td>&nbsp;</td>
                           <td>&nbsp;</td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <!--  Common Hidden fields -->
         <input type="hidden" name="actual_premium" id="actual_premium" value="{{$data['userdata']['premium']}}">
         <input type="hidden" name="plancode" id="plancode" value="{{$data['basic_info']['plan_code']}}">
         <input type="hidden" name="policy_id" id="policy_id" value="{{$data['userdata']['quote_id']}}">
         <input type="hidden" name="company_id" id="company_id" value="{{$data['basic_info']['company_id']}}">
         <input type="hidden" name="company_code" id="company_code" value="{{$data['basic_info']['company_code']}}">
         <!--  Common Hidden fields ends -->
         <div class="col-md-4">
            <div class="row card customcard" style="min-height:130px">
               <div class="col-xs-4 logobox">
                   <img src="{{asset('image/logos/'.$data['basic_info']['company_id'].'_logo.png')}}">
               </div>
               <div class="col-xs-8 centeralign" style="text-align: right">
                   <h6>{{$data['basic_info']['company_name']}}</h6>
                   <h5 class="card-title" style="font-size:30px">{{$data['basic_info']['total_premium']}}</h5>

                   <a href="#" 
                     id ="benefits" 
                     name ="benefits" 
                     class="benefits"
                     data-url = "{{route('benefitreq', $data['userdata']['trans_code'] )}}"
                     plan-code = "{{$data['basic_info']['plan_code']}}"
                     quote-id = "{{$data['userdata']['quote_id']}}">

                     <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top"
                     title="View benefits">stars</i></a>

                   <a href="#" 
                     id="breakup" 
                     name="breakup" 
                     class="breakup"
                     data-url = "{{route('breakupreq', $data['userdata']['trans_code'] )}}"
                     plan-code = "{{$data['basic_info']['plan_code']}}"
                     quote-id = "{{$data['userdata']['quote_id']}}">

                     <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#premiumBreakup").modal();' title="Premium Breakup">description</i></a> 
                </div> 
            </div>
         </div>
      </div>