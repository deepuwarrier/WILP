<div class="modal-dialog">
    <div class="modal-content coveragestyle">
       <div class="modal-body premium-breakup">
        @if($data)
          <div class="card customcard">
             <div class="col-sm-4 logobox">
                <img src="{{asset($data['logo'])}}" id="company_logo">
             </div>
             <div class="col-sm-5">
             	<h5 class="card-title price" style="margin-top: 5px;">{{$data['total_premium']}}</h5>
             	<span class="label label-default extrapanelitem"> SI: {{$data['sum_insured']}} </span>
             	<div>
               		<span class="extrapanelitem" style="font-weight: 500">{{$data['product']}} {{$data['plan']}}</span>
            		</div>
             </div>
          </div>
          <center>
             <h4>{{$data['title']}}</h4>
          </center>
          <div class="table-responsive">
          	<table class="table responsive" style="text-align: left; font-size: 12px; color: black;">
               <tbody>
               	@foreach($data['coverage']['title'] as $index => $title)
               	<tr>
               		<td>{{(isset($data['coverage']['value'][$index])) ? $title : ''}}</td>
               		<td>{{(isset($data['coverage']['value'][$index])) ? $data['coverage']['value'][$index] : ''}}</td>
               	</tr>	
               	@endforeach
               	@if(isset($data['policy_terms']))
               	<tr>
                  <td colspan="2">
                     Read more about <a target="_blank" href="{{ URL::asset($data['policy_terms']) }}"><u>coverage terms</u>.</a>
                  </td>
                 </tr>
                @endif
                @if(isset($data['product_brochure']))
                <tr>
                  <td colspan="2">
                     Read the <a target="_blank" href="{{ URL::asset($data['product_brochure']) }}"><u>product brochure</u>.</a>
                  </td>
                 </tr>
                @endif
                @if(isset($data['senior_flag']) && isset($data['senior_terms']))
               	<tr>
                  <td colspan="2">
                     {{$data['senior_terms']}}
                     @if(isset($data['policy_benefits']))<nobr>
                     	<a target="_blank" href="{{ URL::asset($data['policy_benefits']) }}"><u>Download Senior Plan Benefit</u>.</a>
                     @endif
                  </td>
                 </tr>
                 @endif
                 <tr>
                  <td colspan="2">
                     @if(isset($data['policy_wording']))
                     {{$data['gen_wording']}}<a target="_blank" href="{{$data['policy_wording']}}"><u>Download Policy Wording</u>.</a><nobr>
                     @endif
                     @if(isset($data['policy_exclusions']))
                     </a> Click here for <a target="_blank" href="{{URL::asset($data['policy_exclusions'])}}"><u>exclusions</u>.</a>
                     @endif
                  </td>
                 </tr>
               </tbody>
             </table>  
          </div>
        @else
        	<center><p>No Record Found</p></center>
        @endif
       </div>
       <div class="modal-footer">
          <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
          <span id="editor"></span>
       </div>
    </div>
</div>