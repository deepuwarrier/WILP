@if ($error)
  <div class="row card">
    <br>
    <p>No Quotes generated for your Request</p>
  </div>  
@else
  <div class="row card customcard quote-box" data-listing-price="{{$item['NetPremiumAmt']}}">
    <div class="col-sm-4 logobox">
      <img class="logo" src="{{asset($item['logo'])}}">
    </div>
    <div class="row col-sm-8 logoright">
      <div class="col-md-6">
          <h5 class="card-title price">&#8377;  {{ round($item['NetPremiumAmt']) }}</h5>
          <div style="padding-bottom: 5px">
            <span class="label label-default extrapanelitem  idv">SI : {{(strpos($item['PlanDesc'], 'Europe') !== false || strpos($item['ProductDescription'], 'Schengen')) ? '&#8364;' : '$'}}{{$item['sum-insured']}}</span>
          </div>
      </div>
      <div class="col-md-6 buybutton hvr-grow">
          <form  
             action="{{ route('travel.load_proposal') }}" 
             method="post" 
             id="buy-policy-{{$item['policyId']}}">
	   <input type="hidden" name="companyId" value="{{ $item['companyId']}}">
           <input type="hidden" name="trans_code" value="{{$item['trans_code']}}">
	   <input type="hidden" name="policy_id" value="{{$item['policyId']}}">
	   {{ csrf_field() }}
             <button type="button" 
                id="buy-btn" 
                class="btn btn-success  btn-md buy-btn"
                data-key ="{{$item['policyId']}}" 
                data-item ="{{$item['policyId']}}">Buy Now</button> 
	 <input type="hidden" name="proposal_url" value="{{URL::to('travel-insurance/')}}/{{$item['url_code']}}/{{$item['trans_code']}}">        
  </form> 
      </div>           
    </div>
    <div class="row">
      <div class="col-md-12">
          <div class="content extrapanel">
            <span class="extrapanelitem name" style="font-weight: 500">{{$item['ProductDescription']}} {{$item['PlanDesc']}}{{(isset($item['shortDescription']))? ' '.$item['shortDescription'] : ''}}</span>

              <a href="#" 
                id ="benefits{{$index}}" 
                name ="benefits{{$index}}" 
                class="benefits"
                data-url = "{{route('benefitreq', $item['trans_code'] )}}"
                plan-code = "{{$item['PlanCode']}}"
                quote-id = "{{$item['policyId']}}">
                <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" title="View benefits">stars</i></a>

              <a href="#" 
                id="breakup{{$index}}" 
                name="breakup{{$index}}" 
                class="breakup"
                data-url = "{{route('breakupreq', $item['trans_code'] )}}"
                plan-code = "{{$item['PlanCode']}}"
                quote-id = "{{$item['policyId']}}">
                <i class="material-icons iconcustom" data-toggle="tooltip" data-placement="top" onclick='jQuery("#premiumBreakup").modal();' title="Premium Breakup">description</i></a>
                                 
          </div>
      </div>
    </div>
  </div>
@endif
