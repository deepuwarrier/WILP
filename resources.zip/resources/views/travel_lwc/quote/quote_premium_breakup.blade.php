<div class="modal-dialog">
    <div class="modal-content premium-breakup-card">
       <div class="modal-body premium-breakup">
        @if($data)
          <div class="card customcard">
             <div class="col-sm-4 logobox">
                <img src="{{asset($data['logo'])}}" id="company_logo">
             </div>
             <div class="col-sm-5">
             	<h5 class="card-title price" style="margin-top: 5px;">{{$data['total_premium']}}</h5>
             	<span class="label label-default extrapanelitem"> SI: {{$data['sum_insured']}} </span>
             	<div>
               		<span class="extrapanelitem" style="font-weight: 500">{{$data['product']}} {{$data['plan']}}</span>
            		</div>
             </div>
          </div>
          <h3>Premium Breakup</h3>
          <h4>Basic Premium</h4>
          @if($data['travel_count'] < 2)
          <ul>
          	<li>
          		<span>Single Traveller</span>
          		<span class="value pull-right">{{$data['basic_premium']}}</span>
          	</li>
          </ul>
          @else
          @foreach($data['split_up']['values'] as $index => $premium)
          <ul>
          	<li>
          		<span>{{$data['split_up']['keys'][$index]}}</span> 
          		<span class="value pull-right">{{$premium}}</span>
          	</li>
          </ul>
          @endforeach
          @endif
          <h4>Taxes</h4>
          <ul>
          	<li>
          		<span>Goods & Service Tax</span>
          		<span class="value pull-right">{{$data['tax']}}</span>
          	</li>
          </ul>
          <h4>Final Premium</h4>
          <ul>
          	<li>
          		<span><strong>Payable Premium</strong></span>
          		<span class="value pull-right"><strong>{{$data['total_premium']}}</strong></span>
          	</li>
          </ul>
          @if(isset($data['policy_additinal_info_1']))
        	 	<small>{{$data['policy_additinal_info_1']}}</small>
        	  @endif
        	  @if(isset($data['policy_additinal_info_2']))
        	  	<br><small style="color: green;">{{$data['policy_additinal_info_2']}}</small>
        	  @endif
        @else
        	<center><p>No Record Found</p></center>
        @endif
       </div>
       <div class="modal-footer">
          <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
          <span id="editor"></span>
       </div>
    </div>
</div>