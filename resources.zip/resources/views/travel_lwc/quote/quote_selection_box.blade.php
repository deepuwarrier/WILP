<div class="card card-form-horizontal">
                     <div class="content">
                        <div class="row">
                           <div class="col-xs-6 pull-right">
                            <a href="{{route('updatereq')}}" class="btn btn-info btn-xs pull-right">Change</a> 
                           </div>
                           <div class="col-xs-6 pull-left">
                              <h6 class="pull-left">Showing Results for :</h6>
                           </div>
                        </div>
                        <div class="row content" id="detail" style="text-align: left">
                          <input type="hidden" name="tripcheck" id ='tripcheck' value="{{$request['triptype']}}">
                          <input type="hidden" name="area" id ='area' value="{{$request['area']}}">
                           <span class="label label-default base_detail">{{ $request['trip_info'] }}</span>
                           <span class="label label-default base_detail">{{ $request['location'] }}</span>
                           <span class="label label-default base_detail">{{ $request['member_info'] }}</span>
                           <span class="label label-default base_detail"> Age : {{ $request['age'] }}
                           </span>
                        </div>
                     </div>
                  </div>
