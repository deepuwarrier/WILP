@include('health.layouts.inn-hdr')
<div class="wizard-container addmargin">
    <div class="row"> 

    @if($data['status'])
    <div class="premiumconfirmation">
    <div class="card">
        <div class="content content-success" style="border-bottom-left-radius: 0px;border-bottom-right-radius: 0px">
            <h3 class="category-social whitefont">
                 <i class="fa fa-newspaper-o"></i> Congratulations!!
              </h3>
            <h4 class="card-title">
                 <a>Your payment has been processed Successfully!</a>
              </h4>
            <p class="card-description">
                Thank you for your patronage.
            </p>
        </div>
        <div class="content">
            <h4 class="card-title">
              <div class="logobox">
                 <img src="{{ URL::asset($data['logo']) }}" alt="Insurer Logo">
              </div>
                <a>Your policy will hit your inbox shortly.</a>
            </h4>
            <h5 class="category-social">
                 <i class="fa fa-newspaper-o"></i>Please note your policy number!
              </h5>
            <p></p>
                    <h2>{{ $data['pg_response']['policyNumber'] }}</h2>
                    @if(isset($data['policy_link']))
                    <a href="{{$data['policy_link']}}" target="_target" class='btn btn-primary'>Download Policy</a>
                    @endif
                    <p></p>
            
            <div class="content hidden">
                <form class="nl">
                    <button type="button" class="nl__btn btn-xs">Email This!</button>
                    <input placeholder="your@email.com" class="nl__input aria-hidden" type="text">
                </form>
            </div>
            <div class="content">

                <p>Your policy will be sent to your email id shortly by the insurance company</p>
                <p>Meanwhile, you will soon receive a welcome email from us as well!</p>
            </div>


        </div>
    </div>
    </div>
   @elseif($data['pg_response']['uwDecision'] == "PENDINGREQUIREMENTS") 
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h4 class="card-title" style="color: #00669C;">Thank you. We have accepted your initial payment.</h4>
         <h5>Your policy is subject to medical evaluation. Please note down your 
            @if(isset($data['pg_response']['policyNumber']))
            Policy No <strong style="color: #00669C;">{{$data['pg_response']['policyNumber']}}</strong> 
            ,
            @else
            Transaction no <strong style="color: #00669C;">{{$data['pg_response']['transactionRefNum']}}</strong>
            @endif
            Kindly use this number for all your future communication with us.<br/>We will assess the same as per RELIGARE underwriting guidelines and will keep you informed.</h5>
         <a href="/health-insurance"><button type="submit" class="btn btn-success">Home</button></a>
      </div>
   </div>
   @elseif($data['pg_response']['uwDecision'] == "DRAFT") 
        <div class="container genenq" style="margin-top: -4%">
              <div class="col-md-6 card-contact">
                 <a> <img class="img" src="{{ URL::asset('image/consultant.svg')}}" alt="Insurance Consultant" /></a>
              </div>
              <div class="col-md-6 card-contact">
                 <h2 class="card-title" style="color: #00669C;">Incomplete Transaction !</h2>
                 <h4 class="card-title" style="color: #4CAF50;">Transaction failed for your policy purchase with us. Please note the reference number {{ $data['pg_response']['transactionRefNum'] }}</h4>
                 <h5> One of our consultant will get in touch with you shortly to help you purchase this policy.</h5>

                 <h6>In a hurry? Call us right now : <b>+91 7899-000-333</b></h6>

                 <a href="/travel-insurance"><button type="submit" class="btn btn-success">Home</button></a>
              </div>
        </div>
   @else
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h1 class="card-title" style="color: #00669C;">We tried our best!</h1>
         <h4 class="card-title" style="color: #00669C;">But somehow, we could not get you across! </h4>
         <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5> 
         <h5>Your Transaction Reference Number : <strong style="color: #00669C;">{{$data['pg_response']['transactionRefNum']}}</strong></h5>
         <a href="/health-insurance"><button type="submit" class="btn btn-success">Home</button></a>
      </div>
   </div>
    @endif
    </div>
</div>
@include('health.layouts.inn-ftr')