@include('car.layouts.inn-hdr')
<div class="wizard-container addmargin">
    <div class="row">
    @if($data['status'])
    <div class="premiumconfirmation">
            <div class="card">
                <div class="content content-success" style="border-bottom-left-radius: 0px;border-bottom-right-radius: 0px">
                    <h3 class="category-social whitefont">
                         <i class="fa fa-newspaper-o"></i> Congratulations!!
                      </h3>
                    <h4 class="card-title">
                         <a href="#pablo">Your payment has been processed Successfully!</a>
                      </h4>
                    <p class="card-description">
                        Thank you for your patronage.
                    </p>
                </div>
                <div class="content">
                    <h4 class="card-title">
                      <div class="logobox">
                         <img src="{{URL::asset($data['logo'])}}">
                      </div>
                        <a href="#pablo">Your policy will hit your inbox shortly.</a>
                    </h4>
                    <h5 class="category-social">
                         <i class="fa fa-newspaper-o"></i>Please note your reference number!
                      </h5>
                    <p></p>
                    <h2>{{ $data['transaction_num'] }}</h2>
                    <p></p>

                    <div class="content hidden">
                        <form class="nl">
                            <button type="button" class="nl__btn btn-xs">Email This!</button>
                            <input placeholder="your@email.com" class="nl__input aria-hidden" type="text">
                        </form>
                    </div>
                    <div class="content">

                        <p>Your policy will be sent to your email id shortly by the insurance company</p>
                        <p>Meanwhile, you will soon recieve a welcome email from us as well!</p>
                    </div>


                </div>
            </div>
            </div>
     @else
        @if(isset($data['transaction_num']) && !empty($data['transaction_num']))
        <div class="container genenq" style="margin-top: -4%">
              <div class="col-md-6 card-contact">
                 <a> <img class="img" src="{{ URL::asset('image/consultant.svg')}}" alt="Insurance Consultant" /></a>
              </div>
              <div class="col-md-6 card-contact">
                 <h2 class="card-title" style="color: #00669C;">Incomplete Transaction !</h2>
                 <h4 class="card-title" style="color: #4CAF50;">Transaction failed for your policy purchase with us. Please note the reference number {{ $data['transaction_num'] }}</h4>
                 <h5> One of our consultant will get in touch with you shortly to help you purchase this policy.</h5>

                 <h6>In a hurry? Call us right now : <b>+91 7899-000-333</b></h6>

                 <a href="/travel-insurance"><button type="submit" class="btn btn-success">Home</button></a>
              </div>
        </div>
       @else
       <div class="container genenq">
          <div class="col-md-6">
             <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" /></a>
          </div>
          <div class="col-md-6 card-contact">
             <h1 class="card-title" style="color: #00669C;">We tried our best!</h1>
             <h4 class="card-title" style="color: #00669C;">But somehow, we could not get you across! </h4>
             <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5>

             <a href="/travel-insurance"><button type="submit" class="btn btn-success">Home</button></a>
          </div>
       </div>
       @endif

    @endif
    </div>
</div>
@include('car.layouts.inn-ftr')
