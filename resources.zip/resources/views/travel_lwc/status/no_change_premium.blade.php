<div class="wizard-container paymentcontainer">
  <div class="col-sm-6 centerdiv">
    <div class="card premiumconfirmation">
      <div class="content content-info">
        <h5 class="category-social dark">
            <i class="fa fa-newspaper-o"></i> Proceed to the Payment Gateway!
        </h5>
        <h4 class="card-title">
            <a>There is no change in your premium!</a>
        </h4>
      </div>
      
      <div class="row customcard" style="min-height:130px">
        <div class="col-sm-12 logobox min">
            <img src="{{ URL::asset('image/logos/')}}/{{$request['company_id']}}_logo.png">
        </div>
        <div class="col-xs-12">
            <h6>Premium Payable</h6>
            <h5 class="card-title" style="font-size:30px">&#8377; {{ $request['premium'] }}</h5>       
        </div>
      </div>

      <!-- PAYMENT MODE CHOICE -->
      @if($request['company_id'] == 'hdfc')
      <div class="col-xs-12">
        <input type="radio" name="pay_mode" id="paymode_cc" value="cc" class="required valid" checked="checked"/>
        <label for="paymode_cc">Credit/Debit Card</label>
        <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
        <input type="radio" name="pay_mode" id="paymode_dd" value="dd" class="required valid"/>
        <label for="paymode_dd">NetBanking</label>
      </div>
      @endif
      <!-- PAYMENT MODE CHOICE END -->

      <button type="submit" class="btn btn-success" id="payment-submit">Make Payment</button>
      <p><h7><a id="review-again"  style="cursor:pointer;color: #006696;">Review Again</a></h7></p>
      <p style="line-height: 1.5;">Your payment will be collected directly by the insurance company. Once the payment is successfull, all policy related documents will be sent to your email.</p>

      <h5 style="font-size: 13px; padding: 5px;background-color: #0097a7;color:#FFF;">Any last minute question? Call us right now : <b>+91 7899-000-333</b></h5>
    </div>
  </div>        
</div>                      

