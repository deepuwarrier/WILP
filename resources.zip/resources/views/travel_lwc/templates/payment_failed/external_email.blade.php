@include('layouts.email_header_template')
  @section('title', 'Sorry, but your payment has been failed.')
  <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" style="width:250px;"/></a>
      </div>
      <div class="col-md-6 card-contact">
        <p>Dear {{$name}},</p>
        <p>Your transaction with {{$company_name}} through Instainsure.com has failed.</p>
        @if(isset($proposal_request_url))
        <p>You can continue and re-attempt the payment by clicking below.</p> 
        <p><a href="{{$proposal_request_url}}"><button class="btn btn-primary">Complete payment</button></a></p>
        @endif
        <p>If you got this email despite money getting deducted from your account, please contact us immediately and quote the below transaction code. We will help you resolve the issue on top priority.</p>
        @if(isset($data_value->tata_transno))
        -- Transaction Code: {{$data_value->tata_transno}} --
        @endif
        @if(isset($data_value->religare_transno))
        -- Transaction Code: {{$data_value->religare_transno}} --
        @endif
        @if(isset($data_value->proposalno))
        -- Transaction Code: {{$data_value->proposalno}} --
        @endif
        @if(isset($data_value->star_transno))
        -- Transaction Code: {{$data_value->star_transno}} --
        @endif
      </div>
   </div>
@include('layouts.email_footer_template')