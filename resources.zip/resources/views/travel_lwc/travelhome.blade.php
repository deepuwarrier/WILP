@include('travel.layouts.inn-hdr') 
<style>
   .relationship { 
   min-width: 150px!important; 
   font-weight: normal !important;
   }
   .age{       
   font-weight: normal !important;
   }
</style>

<form id="detail_page_form">
<input type="hidden" name="trans_code" id="trans_code" value="{{$trans_code}}">
<input type="hidden" name="triptype" id="trip_type" value="" class="required">
<input type="hidden" name="area" id="trip_area" value="" class="required">
<input type="hidden" name="duration" id="trip_duration" value="" class="required">
<input type="hidden" name="amt_duration" id="amt_duration" value="" class="required">
<input type="hidden" name="std_duration" id="std_duration" value="" class="required">
<input type="hidden" name="relationship_list" id="relationship_list" value="" class="required">
<input type="hidden" name="age_list" id="age_list" value="" class="required">
<input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">
</form>

<form  action=" {{route('travel.getquotes', $trans_code )}} " method="get" id="generate_quote_form"></form>

<div class="wrapper">
   <div class="col-sm-12">
      <!--      Wizard container        -->
      <div class="wizard-container addmargin">
         <div class="card wizard-card" data-color="green" id="wizardProfile">
            <h3 style="text-align: center; color: #92cf1b; font-weight: 400;">InstaInsure.com </h3>
            <h4><i style="color: #00669c; padding:0 5px 0 5px; display: block;"><b>Compare</b> and <b>Buy</b> the best Travel Insurance policy online. <b>Super Quick!</b></i>
            </h4>
            <div class="wizard-navigation">
               <ul class="nav nav-pills">
                  <li style="width: 25%;" class="active">
                     <a href="#type" data-toggle="tab" aria-expanded="true">Travel Type</a>
                  </li>
                  <li style="width:25%;" id="area-tab">
                     <a href="#area" data-toggle="tab">Area of Travel</a>
                  </li>
                  <li style="width:25%;">
                     <a href="#duration" data-toggle="tab">Travel Duration</a>
                  </li>
                  <li style="width:25%;">
                     <a href="#travellers" data-toggle="tab">Travellers</a>
                  </li>
               </ul>
               <div class="moving-tab" style="width: 235.556px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Travel Type</div>
            </div>
            <div class="tab-content">
               <div class="tab-pane active" id="type">
                  <div class="row">
                     <h6>Select your Travel Type</h6>
                     <div class="container tabdata" id='type-container'>
                        <input 
                           id="single_trip" 
                           name="trip" 
                           value="Single Trip" 
                           type="button"
                           class="type btn btn-fill btn-white btn-wd" >
                        <input 
                           id="multi_trip" 
                           name="trip" 
                           value="Multi Trip"
                           type="button"
                           class="type btn  btn-fill btn-white btn-wd" >
                        <input 
                           id="student_trip" 
                           name="trip" 
                           value="Student Trip" 
                           type="button"
                           class="type btn btn-fill btn-white btn-wd" >
                     </div>
                  </div>
               </div>
               <div class="tab-pane" id="area">
                  <div class="row">
                     <h6>Select your area of Travel</h6>
                     <div class="container tabdata" id='area_container'>
                     </div>
                  </div>
               </div>
               <div class="tab-pane" id="duration">
                  <div class="row">
                     <div class="container tabdata" id="duration_container">          
                     </div>
                  </div>
               </div>
               <div class="tab-pane" id="travellers">
                  <div class="row">
                     <h6> Add Traveller Details</h6>
                     <div class="container tabdata" id='traveller_container'>
                     </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="wizard-footer">
            </div>
         </div>
      </div>
      <!-- End of travel-form -->               
      <!-- wizard container -->
   </div>
</div>
<!-- footer section -->
<div class="homelogobox">
   @include('layouts.c_partners')
</div>
<div class="features-1" >@include('layouts.c_legacy') </div>
<div class="features-5" >@include('layouts.c_whyus') </div>
<div class="testimonials-2 section-image" >@include('layouts.c_testimonial')</div>
<div class="blogs-2" style="padding-top: 80px">@include('layouts.c_blog')</div>
<div class="team-1" >@include('layouts.c_team')</div>
<div class="contactus-1 section-image">@include('layouts.c_contact')</div>
<!-- footer section -->
@include('travel.layouts.inn-ftr')
<script src="{{URL::asset('js/jquery.isonscreen.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('js/dyn_comp_loader.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('js/travel/moment.js')}}" type="text/javascript"></script>
<script type="text/javascript" src="{{ URL::asset('js/travel/traveldetails.js') }}"></script>