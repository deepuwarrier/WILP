<!doctype html>
<html>
<head>
 <title>{{ $MTxt->page_mt_title or 'Instainsure.com - Buy Insurance Online'  }}</title>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">  
<meta name="robots" content="index, follow">
<meta name="language" content="EN">
<meta name="copyright" content="InstaInsure">
<meta name="document-classification" content="Internet">
<meta name="document-type" content="Public">
<meta name="document-rating" content="Safe for Kids">
<meta name="document-distribution" content="Global">  
<meta name="keywords" content="{{ $MTxt->page_mt_kwds or 'Instainsure.com - Buy Insurance Online'}}">
<meta name="description" content="{{ $MTxt->page_mt_desc or 'Instainsure.com - Buy Insurance Online'}}">
<meta name="detectify-verification" content="85a4d4dd83d0294dde2c053a04c9d4a2" />
<link rel="shortlink" href="/"> <link rel="canonical" href=" " /><link rel="icon" href="{{ asset('image/instainsure_logo_small.svg')}}">

<meta property="og:title" content="Buy Insurance Online - Super Quick!">
<meta property="og:type" content="company">
<meta property="og:url" content="www.instainsure.com">
<meta property="og:image" content="http://www.instainsure.com/image/instainsure_logo.svg">
<meta property="og:site_name" content="InstaInsure">
<meta property="fb:admins" content="1438463946367385">
<meta property="fb:app_id" content="814715792006798">
<meta property="og:description" content="InstaInsure.com allows you to buy an insurance policy super quick! Best Prices, Super Features and Amazing Discounts!">
<meta name="csrf-token" content="{{ csrf_token() }}">
<fb:like href="http://developers.facebook.com/" width="450" height="80">
<link rel="icon" href="{{ asset('image/instainsure_logo_small.svg')}}">

      
      <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}"/>
     
      <link href="{{asset('css/insta-base.css')}}" rel="stylesheet" />
      <link href="{{ asset('css/insta-toolkit.css') }}" rel="stylesheet" />
    
      <link href="{{ asset('css/insta.css') }}" rel="stylesheet" />
      <!--     Fonts and icons     -->
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="{{ asset('css/css8393.css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('css/vertical-nav.css') }}" />
      <link rel="stylesheet" type="text/css" href="{{ asset('css/wizard.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ asset('css/hover.css') }}"/>
      <link rel="stylesheet" type="text/css" href="{{ asset('css/aos.css') }}"/>
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link href="{{asset('css/select2.min.css')}}" rel="stylesheet" />
        <script src='https://www.google.com/recaptcha/api.js'></script>

    
   </head>
   <body class="custompage">
   

     
      <nav class="navbar navbar-primary navbar-fixed-top" id="sectionsNav">
         <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
               <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
               <a href="/ttibi" class="card-logo instalogo">
               <img src="{{URL::asset('http://ttibi.co.in/sites/all/themes/ttibi/logo.png')}}" alt="InstaInsure Logo">
               </a>

		</div>
         </div>
      </nav>

<p>&nbsp;</p>
<style>
    .tp-policy .add-on {
    color: rgb(66, 66, 66) !important;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
}

.tp-policy .togglebutton{
    display: inline
}
.tp-policy .proposalcard{
    min-height: 135px !important;
}
.tp-spacer{
padding-bottom:10px;
}

.flb{ font-size:10px; }
.espc{ margin-bottom:5px;}
.upcase {text-transform: uppercase;}


</style>


<div class="container tp-policy" >
    <div class="row">
        <div class="col-md-12">
        <h3 style="text-align: center; padding-top:40px;" class="info-text">TTIBI : Group Mediclaim Declaration Portal</h3>
        </div>
    </div>
</div>

    <div class="container">  
    <form  method="get" action="/ttibi_search1">  
        <!-- Contact Details -->
        <div class="row">
            <div class="col-md-12">
            <div class="card proposalcard ">
                <div class="col-sm-12">
                    <h5 class="info-text">Search Employee</h5>
                </div>
                 
               <div class='col-sm-4 tp-spacer'>
              <span class="flb">Employee Code</span>
                    <input class="form-control upcase" type="text" id="emp_code" name="emp_code" maxlength="40"  value="" placeholder="Employee Code" >
                </div>
                <div class='col-sm-4 tp-spacer'>
               <span class="flb">Date of Birth</span>
                    <input class="form-control datepicker" type="text" id="emp_dob" name="emp_dob" placeholder="DOB" value="" readonly >
                </div>
                <div class='col-sm-4 tp-spacer'>
                    <button type ="submit" class="btn btn-success pull-right" id="submit_buynow" >Search</button>
                 </div>
               {!! $msg_txt !!} 
            </div>
            </div>
        </div>
        </form>
    </div>


@if($emp_data !=null)

    <div class="container">  
    <form id="gmc_details_submit" method="post" action="/ttibi_member_submit1">  
 {!! csrf_field() !!}
        <!-- Contact Details -->
        <div class="row">
            <div class="col-md-12">
            <div class="card proposalcard ">
                <div class="col-sm-12">
                    <h5 class="info-text">Employee Family Details </h5>
                </div>
      <table width="100%" border="1">
        <tr>
          <th style="
    padding:  10px;
">Name</th>
          <th style="
    padding:  10px;
" >DOB</th>
          
          <th style="
    padding:  10px;
">Gender</th>
          <th style="
    padding:  10px;
">Relation</th>
          <th style="
    padding:  10px;
">SI Value</th>
          <th style="
    padding:  10px;
">Email</th>
        </tr>        
     @foreach($emp_data as $emp)    
         <tr>
          <td><input type="text" class="member_name" style="
    border-style:  none;padding: 10px;" name="{{$emp->auto_id}}||member_name" value="{{$emp->member_name}}"></td>
          <td><input type="text" class="member_dob" style="
    border-style:  none;padding: 10px;" name="{{$emp->auto_id}}||date_of_birth" value="{{$emp->date_of_birth}}"></td>
          
          <td>
           <select class="form-control" style="
    border-style:  none;padding: 10px;" name="{{$emp->auto_id}}||gender">
                        <option value="M" @if( $emp->gender == "M")  selected @endif >Male</option>
                        <option value="F" @if( $emp->gender == "F")  selected @endif >Female</option>
                    </select>
          </td>
          <td>
              <select class="form-control"  style="
    border-style:  none;padding: 10px;" name="{{$emp->auto_id}}||relation">
                        <option value="Employee" @if( $emp->relation == "Employee")  selected @endif >Employee</option>
                        <option value="Wife" @if( $emp->relation == "Wife")  selected @endif >Wife</option>
            <option value="Husband" @if( $emp->relation == "Husband")  selected @endif >Husband</option>
                        <option value="Son" @if( $emp->relation == "Son")  selected @endif >Son</option>
                        <option value="Daughter" @if( $emp->relation == "Daughter")  selected @endif >Daughter</option>
                        <option value="Father" @if( $emp->relation == "Father")  selected @endif >Father</option>
                        <option value="Mother" @if( $emp->relation == "Mother")  selected @endif >Mother</option>
                    </select>
          </td>
          <td><input type="text" style="
    border-style:  none;padding: 10px;color: #424242;" name="{{$emp->auto_id}}||sum_insured" value="{{$emp->sum_insured}}" readonly></td>
          <td><input type="text" style="
    border-style:  none; width: 100%;padding: 10px;color: #424242;" name="{{$emp->auto_id}}||email_addr" value="{{$emp->email_addr}}"></td>
         </tr> 
  @endforeach            
          
              
      </table>   
        
         <div class="col-sm-4 tp-spacer" style="
    padding-left:  0px;
">
                    <button type="submit" class="btn btn-success">Submit Details</button>
                    <button type="reset" class="btn btn-info pull-left">Reset</button>
                 </div>      
               
            </div>
            </div>
        </div>
        </form>
    </div>

@endif





<br>
<br>
  <footer class="footer footer-white">

   
         
            <div class="copyright">
               Copyright © <script>document.write(new Date().getFullYear())</script> InstaInsure.com All Rights Reserved.
            </div>
   
      </footer>

      <!--   Core JS Files   -->
      <script src="{{URL::asset('js/jquery.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/jquery-ui.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/bootstrap.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/insta.min.js')}}" type="text/javascript"></script>
      <script src="{{URL::asset('js/sweetalert2.js')}}"></script>
      <script src="{{URL::asset('js/aos.js')}}" type="text/javascript"></script>     
      <script src="{{URL::asset('js/script.js')}}" type="text/javascript"></script>
      <script src="{{ asset('js/component/jquery.validate.min.js') }}"></script>
      <script src="{{URL::asset('js/validation_helper.js')}}" type="text/javascript"></script>
      <!---    common js file for all -->
      <script src="{{ asset('js/common.js') }}"></script>
    <script>
     AOS.init();
     </script> 
      <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
 
  ga('create', 'UA-94028710-1', 'auto');
  ga('send', 'pageview');
 
</script>     


   </body>



<script type="text/javascript">
$("#emp_dob").datepicker({
  dateFormat: "dd/mm/y",
  changeMonth: !0,
  changeYear: !0,
//  minDate: "01/01/25",
//  maxDate: "01-Mar-2018",
  yearRange: "-99:+0"
  });

$(".member_dob").datepicker({
  dateFormat: "dd/mm/y",
  changeMonth: !0,
  changeYear: !0,
//  minDate: "01/01/25",
//  maxDate: "01-Mar-2018",
  yearRange: "-99:+0"
  });

$(function(){
    $('#gmc_details_submit').on('submit',function(event){
  var is_error = false;
  $('.member_name').each (function(index, element) {
      if($(this).val() == "") { is_error = true; }
  });
  $('.member_dob').each (function(index, element) {
     if($(this).val() == "") { is_error = true; }
  }); 
  if(is_error){
    event.preventDefault();
    alert("Please ensure Name & Dob of Each Member is Filled Correctly.");     
  }
    });
});


</script>
