@include('layouts.footer')

 <script src="{{ asset('js/component/jquery.bootstrap-wizard.js') }}"></script>
      <script src="{{ asset('js/component/jquery.validate.min.js') }}"></script>
      <script src="{{ asset('js/jquery.tagsinput.js') }}"></script> 
      <script src="{{ asset('js/component/insta-toolkit.js') }}"></script>
      <script src="{{ asset('js/component/demo.js') }}"></script>
      <script src="{{ URL::asset('js/sweetalert2.js') }}"></script>
      <script src="{{ asset('js/component/rtoasset.js') }}"></script>
      <!---    common js file for all -->
      <script src="{{ asset('js/common.js') }}"></script>
      
      
<script type="text/javascript">
         $().ready(function() {
         demo.initMaterialWizard();
         });
         </script>
         
          <script>// Get all the keys from document
      var keys = document.querySelectorAll('#js-calculator button');
      
      // Add onclick event to all the keys and perform operations
      for(var i = 0; i < keys.length; i++) {if (window.CP.shouldStopExecution(1)){break;}
      	keys[i].onclick = function(e) {
      		// Get the input and button values
      		var input = document.querySelector('.screen');
      		var inputVal = input.innerHTML;
      		var btnVal = this.innerHTML;
      		
      		// Now, just append the key values (btnValue) to the input string and finally use javascript's eval function to get the result
      		// If clear key is pressed, erase everything
      		if(btnVal == 'Clear') {
      			input.innerHTML = '';
      			decimalAdded = false;
      		}
      		
      		// if any other key is pressed, just append it
      		else {
      			input.innerHTML += btnVal;
      		}
      		
      		// prevent page jumps
      		e.preventDefault();
      	} 
      }
      window.CP.exitedLoop(1);
      
   </script>
   <div id="overlay" style="display:none"></div>