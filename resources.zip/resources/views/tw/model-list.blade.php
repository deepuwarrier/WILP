@foreach ($mlist as $mdidx=>$mdlst)
<input class="btn btn-next btn-fill btn-wd {{ ($mdlst->model_code == $selected['model_code']) ? 'btn-blue' : 'btn-white'}}"  data-model-id="{{$mdlst->model_code}}" name="twmdl"  id="{{$mdlst->model_code}}"  value="{{$mdlst->model_name}}" type="button"> 
@if ($mdidx == 8)<hr>@endif
@endforeach
