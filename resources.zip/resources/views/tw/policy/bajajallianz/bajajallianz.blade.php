@include('tw.layouts.inn-hdr')

@include('tw.policy.q_preview')

<!-- start form wizard  -->
<div class="row">
    <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
        <div class="card wizard-card" data-color="green" id="wizardProfile">
            <form autocomplete="off" method="post" action="{{ URL::to('/car-insurance/unitedindia/getpolicy') }}" id="buy_policy_form">
                <div class="wizard-navigation">
                    <ul class="nav nav-pills">
                        <li style="width: 20%;" class="active">
                            <a href="#proposer" data-toggle="tab" aria-expanded="">Proposer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#communication" data-toggle="tab">Communication</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#vehicle" data-toggle="tab">Vehicle Details</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#previousinsurer" data-toggle="tab">Previous Insurer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#review" data-toggle="tab">Review</a>
                        </li>
                    </ul>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                </div>
                <div class="tab-content" id='setdata' data-url='{{ route("car.policy.unitedindia.setproposaldata") }}'>
                    <div class="tab-pane active" id="proposer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Proposer Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft dark">
                                            <a>
                                                <p>Owner Type*</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                           

                                            <div class="radiobutton">
                                                <input type="radio" name="type" id="Individual"  value="I" data-name="Owner Type"  checked />
                                                <label for="Individual">INDIVIDUAL</label>
                                            </div>
<!--                                             <div class="radiobutton"> -->
<!--                                                 <input type="radio"  name="type" id="Organization" value="O" data-name="Owner Type" /> -->
<!--                                                 <label for="Organization">ORGANIZATION</label> -->
<!--                                             </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Gender*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            

                                            <div class="radiobutton">
                                                <input type="radio" name="gender" id="val_radio_male" value="M" data-md-icheck required show-info checked data-name="Gender" />
                                                       <label for="val_radio_male" class="inline-label required show-info">MALE</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="gender" id="val_radio_female" value="F" data-md-icheck data-name="Gender" />
                                                <label for="val_radio_female" class="inline-label required show-info">FEMALE</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input class="form-control required show-info" type="text" data-minYear="" id="cust_dob" name="cust_dob" placeholder="dd/mm/yyyy" value="12-Dec-1995" data-name="Date of birth">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Company Name*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="companyname" value="" placeholder="Company Name" id="companyname" class="form-control required show-info" data-name="Company Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Contact Person Name*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="contactperson" value="" placeholder="Contact Person Name" id="contactperson" class="form-control required show-info" data-name="Contact Person Name">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>First Name*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="firstname" value="Ravi" placeholder="First Name" id="firstname" class="form-control required show-info" data-name="firstname" placeholder="First Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Last Name*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="lastname" value="Rao" placeholder="Last Name" id="lastname" class="form-control required show-info" data-name="Lastname">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Email ID*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="email" value="itsravirao@yahoo.com" placeholder="Email" id="email" data-name="Email ID">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Mobile*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" placeholder="10 Digit Mobile Number" class="form-control required show-info" name="mobile" value="9482097800" id="mobile" onkeypress="return isNumberKey(event, this)" maxlength="10" data-name="Mobile Number">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- may be need to uncomment
                                <div class="col-sm-4">
                                    <div class="card proposalcard">
                                        <div class="col-sm-4" style="padding:0"><div class="labelleft"><a><p>PAN Number*</p></a></div></div>
                                        <div class="col-sm-8" style="padding:0"><div class="labelright">
                                            <input type="text" class="form-control required show-info" name="pan" placeholder="Pan Number" id="pan" value="" data-name="PAN Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            -->
                        </div>
                    </div>
                    <div class="tab-pane" id="communication">
                        <div class="row">
                            <h6 class="info-text"> Enter the Communication Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House/Apartment Number*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="houseno" value="202 Swati Apartments" placeholder="House Number" id="houseno" data-name="House/Apartment Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="30 B main 17B Cross" name="street" placeholder="Street" id="street" data-name="Street">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="locality" value="JP Nagar 6th Phase" placeholder="Locality" id="locality" data-name="Locality">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="statecode" id="state" class="form-control required show-info" data-name="State" data-url="{{ URL::to('/car-insurance/unitedindia/getmaster') }}">


                                                <option selected  hidden="" disabled="" value="">Select State</option>



                                                <option  value='KA'  selected>KA</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="citycode" id="city" class="form-control required show-info" data-name="City">


                                                <option selected hidden="" disabled="" value="">Select City</option>

                                                <option  class='city_option' value='SBC' selected>BLR</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="pincode" value="560078" placeholder="Pincode" id="pincode" onkeypress="return isNumberKey(event, this)" maxlength="6" data-name="Pincode">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="vehicle">
                        <div class="row">
                            <h6 class="info-text"> Enter the Vehicle Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Reg No.*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="row labelright">
                                            <div class="col-xs-3 clearall">
                                                <div class="form-group is-empty regprefill">
                                                    <input placeholder="" value="KA05" id="rtono" disabled="" class="form-control" type="text">
                                                </div>
                                            </div>
                                            <div class="col-xs-9">
                                                <div class="form-group is-empty">
                                                    <input type="text" class="form-control required show-info" name="regno" id="reg-no" style="text-transform: uppercase;" value="AB2244" data-name="Registration Number" placeholder="AB1234">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Engine No*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="engno" value="akjkljj898sdefjs" placeholder="Engine Number" id="eng-no" value="" data-name="Engine No">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Chassis No*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="chassisno" value="adkfj987sdf87sdfdf" placeholder="Chassis Number" id="chassis-no" data-name="Chassis No">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Electrical Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="electrical" id="electrical" class='form-control show-info ' data-name="Electrical Accessories">
                                                <option  value="" selectd>Nil</option>
                                                <option  value=""></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Non Electrical Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" name="non_electrical" id="non_electrical" class='form-control ' data-name="Non Electrical Accessories">
                                                <option  value="" selected>Nil</option>
                                                <option value=""></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Year of Manufacturing*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" class='form-control required' name="yom_selected" id="yom_selected" data-name="Year of Manufacturing">
                                                <option hidden="" disabled="" value="">Year of Manufacturing</option>
                                                <option value="2017"  selected>2014</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Body Type*</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="citycode-name">
                                            <select name="bodyType" id="bodyType" class="form-control required show-info" data-name="Body Type">
                                                <option hidden="" disabled="" value="">Body Type*</option>
                                                <option  value='sss' selected>ssss</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Color*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" value="RED" name="color" placeholder="Color" id="color" data-name="Color">
                                            <span class="form-control-bar "></span>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="previousinsurer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Previous Year Insurance Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select id="previnsurance" name="previnsurance" class='form-control show-info ' data-name="Previous Insurer">

                                                <option selected hidden="" disabled="" value="">Previous Insurer</option>

                                                <option  value="3" selected>HDFC General Insurance</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Number*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info " name="policyno" value="kjkljsdfsd98sdfsfsd" placeholder="Policy Number" id="policyno" data-name="Policy Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Name*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info required" name="nomineeName" value="Ashok Saha" placeholder="Nominee Name" id="nomineeName" data-name="Nominee Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Relationship*</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="nomineeRel" placeholder="Nominee Relation" id="nomineeRel" class='form-control show-info required' data-name="Nominee Relationship">
                                                <option  hidden="" disabled="" value="">Nominee Relationship</option>
                                                <option  value="EMP">Employer</option>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane" id="review">
                        <h6 class="info-text"> Review the data you entered!</h6> 

@include("tw.policy.p_preview")                        
                        
                    </div>
                </div>
                <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}"> 
                <input type="hidden" name="" id="" value=""> 
            </form>
            <div class="wizard-footer">
                <div class="pull-right">
                    <input data-focus='modal_div' class="btn scrolltop btn-next btn-info" name="next" value="Next" type="button">
                    <input data-focus='modal_div' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="car-btn-pay">
                </div>
                <div class="pull-left">
                    <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- fnished form wizard -->

@include('tw.layouts.inn-ftr')
  