<option value="" data-name="" > Select a City </option>
@foreach ($city_list as $city)
 <option value="{{$city->city_code}}" data-name="{{$city->city_name}}" > {{$city->city_name}} </option>
@endforeach