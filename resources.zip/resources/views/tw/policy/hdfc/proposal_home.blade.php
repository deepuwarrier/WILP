@include('tw.layouts.inn-hdr')

@include('tw.policy.q_preview')

<!-- start form wizard  -->
<div class="row" >
    <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
        <div class="card wizard-card" data-color="green" id="wizardProfile">
            <form autocomplete="off" method="post"  id="buy_policy_form">
                <div class="wizard-navigation">
                    <ul class="nav nav-pills">
                        <li style="width: 20%;" class="active">
                            <a href="#proposer" data-toggle="tab" aria-expanded="" id="proposer_tab" onclick="strt_proposal_data();">Proposer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#communication" data-toggle="tab" id="commu_tab" onclick="strt_proposal_data();" >Communication</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#vehicle" data-toggle="tab" id="vehicle_tab" onclick="strt_proposal_data();">Vehicle Details</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#previousinsurer" data-toggle="tab" id="preinsr_tab" onclick="strt_proposal_data();">Previous Insurer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#review" data-toggle="tab" onclick="strt_proposal_data();">Review</a>
                        </li>
                    </ul>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                </div>
                <div class="tab-content" id='setdata' >
                    <div class="tab-pane active" id="proposer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Proposer Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft dark">
                                            <a>
                                                <p>Owner Type</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                           

                                            <div class="radiobutton">
                                                <input type="radio" name="type" id="Individual"  value="I" data-name="INDIVIDUAL"  checked />
                                                <label for="Individual">INDIVIDUAL</label>
                                            </div>

<!--                                             <div class="radiobutton"> -->
<!--                                                 <input type="radio"  name="type" id="Organization" value="O" data-name="Owner Type" /> -->
<!--                                                 <label for="Organization">ORGANIZATION</label> -->
<!--                                             </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Gender</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="gender_group">
                                            <div class="radiobutton" >
                                                <input type="radio" name="gender" id="val_radio_male" value="M" checked data-name="MALE" />
                                                       <label for="val_radio_male" class="inline-label required show-info">MALE</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="gender" id="val_radio_female" value="F" data-name="FEMALE" />
                                                <label for="val_radio_female" class="inline-label required show-info">FEMALE</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input class="form-control required" type="text" data-minYear="01-Jan-1918" data-maxYear="30-Jun-1998"  id="cust_dob" name="cust_dob" placeholder="dd-mmm-yyyy" value="" data-name="Date of birth">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Company Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="companyname" value="" placeholder="Company Name" id="companyname" class="form-control required show-info" data-name="Company Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Contact Person Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="contactperson" value="" placeholder="Contact Person Name" id="contactperson" class="form-control required show-info" data-name="Contact Person Name">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Full Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="cust_name" value="" id="cust_name" class="form-control required" placeholder="Full Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Email ID</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="customer_email" value="" placeholder="Email" id="customer_email" data-name="Email ID">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Mobile</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" placeholder="10 Digit Mobile Number" class="form-control" name="mobile" value="" id="mobile"  maxlength="10">
                                        </div>
                                    </div>
                                </div>
                            </div>
  
<div class="col-sm-4">
    <div class="card proposalcard">
        <div class="col-sm-4" style="padding:0">
            <div class="labelleft">
                <a>
                    <p>Aadhar Number</p>
                </a>
            </div>
        </div>
        <div class="col-sm-8" style="padding:0">
            <div class="labelright">
                <input type="text" placeholder="12 Digit Aadhar Number" class="form-control" name="aadhar_no" value="" id="aadhar_no" maxlength="14">
            </div>
        </div>
    </div>
</div>                        
                            
                            
                            
                        </div>


    <div class="wizard-footer">
    <div class="pull-right">
    <input  class="btn scrolltop btn-next btn-info"  id="proposer_store"   name="next" value="Next" type="button"/>
    </div>
    <div class="clearfix"></div>
    </div> 

</div>

<!--  Start : Address Details  Section ----------------------------------------------------------------------------------------------- -->
                    
                    <div class="tab-pane" id="communication">
                        <div class="row">
                            <h6 class="info-text"> Enter the Communication Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="houseno" value="" placeholder="House Number" id="houseno" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street Address</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" value="" name="street" placeholder="Street" id="street">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="locality" value="" placeholder="Locality" id="locality" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="statecode" id="state" class="form-control required show-info"   >
                                        <option selected  hidden="" disabled="" value="">Select State</option>
                                @foreach ($base_data->state_list() as $state_obj)
                                                <option value="{{$state_obj->state_code}}" data-name=" {{$state_obj->state_name}} "> {{$state_obj->state_name}} </option>
                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="citycode" id="city" class="form-control required show-info" >
                                                <option selected hidden="" disabled="" value="">Select City</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="pincode" value="" placeholder="Pincode" id="pincode"  maxlength="6" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

    <div class="wizard-footer">
    <div class="pull-right">
    <input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="address_store"  name="next" value="Next" type="button">
    </div>
     <div class="pull-left">
                    <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
                </div>
    <div class="clearfix"></div>
    </div>   
                        
</div>

<!--  Start : Vehicle Details  Section ----------------------------------------------------------------------------------------------- -->      

                    <div class="tab-pane" id="vehicle">
                        <div class="row">
                            <h6 class="info-text"> Enter the Vehicle Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Reg No.</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                                    <input type="text" class="form-control" name="tw_reg_no" id="tw_reg_no" style="text-transform: uppercase;" value="" placeholder="MH-01-AB-1234">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Engine No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="eng_no" value="" placeholder="Engine Number" id="eng_no" value="" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Chassis No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="chassis_no" value="" placeholder="Chassis Number" id="chassis_no" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Ele. Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="electrical" id="eleacc" class='form-control show-info' disabled>
                                                <option value="0" selected="selected">No</option>
                                                <option value="5000">5,000</option>
                                                <option value="10000">10,000</option>
                                                <option value="15000">15,000</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Non Ele. Accessories</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select  name="non_electrical" id="non_eleacc" class="form-control show-info" disabled >
                                                 <option selected="selected"  value="0" >No</option>
                                               <option value="5000">5,000</option>
                                                <option value="10000">10,000</option>
                                                <option value="15000">15,000</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Year of Manufacturing</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select data-md-selectize show-info data-live-search="true" class='form-control required show-info' name="yom_selected" id="yom_selected" data-name="Year of Manufacturing">
                                                <option hidden="" disabled="" value="">Year of Manuf.</option>
                                        @foreach ($base_data->yom_list() as $yom_obj)
                                                <option value="{{  $yom_obj }}"> {{  $yom_obj }} </option>
                                        @endforeach                                               
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Color</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" value="" name="color" placeholder="Color" id="color" >
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
    
    <div class="wizard-footer">
    <div class="pull-right">
    <input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="vehicle_store"  name="next" value="Next" type="button">
    </div>
     <div class="pull-left">
       <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
      </div>
    <div class="clearfix"></div>
    </div>                          
                        
 </div>
 
<!--  Start : Previous Insurer Section ----------------------------------------------------------------------------------------------- -->                    
                    
                    <div class="tab-pane" id="previousinsurer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Previous Year Insurance Details!</h6>
                            @if($base_data->get_pre_policy_status())
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select id="previnsurance" name="previnsurance" class='form-control required' >
                                                <option selected hidden="" disabled="" value="">Previous Insurer</option>
@foreach ($base_data->pre_insurer_list() as $preinsr_obj)
                                                <option value="{{  $preinsr_obj->preinsr_code }}" data-name="{{  $preinsr_obj->preinsr_name }} "> {{  $preinsr_obj->preinsr_name }} </option>
@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="policyno" value="" placeholder="Policy Number" id="policyno" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                             @endif
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="nomineeName" value="" placeholder="Nominee Name" id="nomineeName">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nomine Age</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select  name="nomi_age" id="nomi_age" class="form-control" >
<!--                                                 <option selected="selected"  value="18" >18</option> -->
                                                @for ($itr =18; $itr < 100; $itr++)
                                                <option  value="{{ $itr }}" >{{$itr}}</option>
                                                @endfor
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Relationship</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="nomineeRel" placeholder="Nominee Relation" id="nomineeRel" class='form-control show-info required' >
                                                <option  hidden="" disabled="" value="">Nominee Relationship</option>
@foreach ($base_data->nom_rel_list() as $nomrel_obj)
                                                <option  value="{{  $nomrel_obj->nomrel_code }}" data-name="{{  $nomrel_obj->nomrel_name }}" >{{  $nomrel_obj->nomrel_name }}</option>
@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
 @if( $base_data->get_pre_zerodept() == 'Y' )                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft" style="padding: 12px 0">
                                            <a>
                                                <p>Had Zero Depreciation? </p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:12px">
                                        <div class="radiobutton" >
                                            <input type="radio" name="prevzerodep" id="prevzerodep_selected" value="Y"  checked="checked"  />
                                            <label for="prevzerodep_selected" class="inline-label required show-info">Yes</label>
                                        </div>
                                        <div class="radiobutton">
                                            <input type="radio" name="prevzerodep" id="prevzerodep_not_selected" value="N" />
                                            <label for="prevzerodep_not_selected" class="inline-label required show-info">No</label>
                                        </div>
                                    </div>
                                </div>

                            </div>
@endif         
                        </div>
                        
<div class="wizard-footer">
    <div class="pull-right">
    <input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="preinsurer_store"  name="next" value="Next" type="button">
    </div>
     <div class="pull-left">
       <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
      </div>
    <div class="clearfix"></div>
    </div>      
                        
                        
 </div>
 <input type="hidden" id="tw_trans_code" value="{{ $tw_trans_code }}" />
 <!--  Start : Preview  Section ----------------------------------------------------------------------------------------------- -->

<div class="tab-pane uppertxt" id="review">
    <h6 class="info-text">Review the data you entered!</h6>

    <div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change"  id="goto_proposer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Proposer :</h6>
                    </div>
                </div>
                <div class="row" id="proposer_preview">
                    <div class="col-md-12 div_customtable">
                         <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Owner Type</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_Individual"></span>
                            </div>
                            <div class="col-sm-3 p_title">Gender</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_gender_group"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Full Name</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_cust_name"></span>
                            </div>
                            <div class="col-sm-3 p_title">Date of Birth</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_cust_dob"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Email</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_customer_email"></span>
                            </div>
                            <div class="col-sm-3 p_title">Mobile</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_mobile"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Aadhar Number</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_aadhar_no"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_commu">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Communication :</h6>
                    </div>
                </div>
                <div class="row" id="communication_preview">
                    <div class="div_customtable">
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">House No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_houseno"></span>
                            </div>
                            <div class="col-sm-3 p_title">Street Address</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_street"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Locality</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_locality"></span>
                            </div>
                            <div class="col-sm-3 p_title">State</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_state"></span>
                            </div>
                        </div>
                         <div class="col-sm-12">
                            <div class="col-sm-3 p_title">City</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_city"></span>
                            </div>
                            <div class="col-sm-3 p_title">Pincode</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_pincode"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_vehicle">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Vehicle Details :</h6>
                    </div>
                </div>
                <div class="row" id="vehicle_preview">
                    <div class="div_customtable">
                         <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Reg. No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_reg_number"></span>
                            </div>
                            <div class="col-sm-3 p_title">Mfg Year</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_yom_selected"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Chassis No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_chassis_no"></span>
                            </div>
                            <div class="col-sm-3 p_title">Engine No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_eng_no"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Electrical</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_electrical"></span>
                            </div>
                            <div class="col-sm-3 p_title">Non Electrical</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_non_electrical"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Color</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_color"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_preinsr">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Previous Insurer :</h6>
                    </div>
                </div>
<div class="div_customtable"
    id="previousinsurer_preview">
    <div>
      @if($base_data->get_pre_policy_status())
        <div class="col-sm-12">
            <div class="col-sm-3 p_title">Previous Ins.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_previnsurance"></span>
            </div>
            <div class="col-sm-3 p_title">Policy No.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_policyno"></span>
            </div>
        </div>
        @endif
        <div class="col-sm-12">
            <div class="col-sm-3 p_title">Nominee Name</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomineeName"></span>
            </div>
            <div class="col-sm-3 p_title">Nominee  Rel.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomineeRel"></span>
            </div>
        </div>
         <div class="col-sm-12">
            <div class="col-sm-3 p_title">Nominee Age</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomi_age"></span>
            </div>
      
 @if( $base_data->get_pre_zerodept() == 'Y' )       
             <div class="col-sm-3 p_title">Had Zero Depreciation</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_prevzerodep_selected"></span>
            </div>

@endif      
          </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>

<!--  Start : Disclaimer text -->
<div class="col-md-12 radiobutton" id="tnc_box">
    <label> <input name="disclaimer" type="checkbox" value="disclaimer" id="disclaimer"> 
    I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.
    </label>
</div>
<!--  End : Disclaimer Text -->

</div>

                </div>
            </form>
            
            <div class="wizard-footer">
                <div class="pull-right">
                    <input data-focus='modal_div' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="tw-btn-pay">
                </div>
                
                <div class="clearfix"></div>
            </div>
            
        </div>
    </div>
</div>
<!-- fnished form wizard -->

@include('tw.layouts.inn-ftr')
  <script src="{{ asset('js/tw/twpolicy.js') }}"></script> 
  <script src="{{ asset('js/validation_lib.js') }}"></script> 
 <script src="{{ asset('js/tw/policy/hdfc.js') }}"></script> 
<script type="text/javascript"> retrive_proposal_data(); </script>
 <script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script> 
<script type="text/javascript"> 
 $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });   
 </script>
