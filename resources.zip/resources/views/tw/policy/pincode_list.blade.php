<option value="" data-name="" > Select a Pincode </option>
@foreach ($pincode_list as $pincode)
 <option value="{{$pincode->pincode}}" data-name="{{$pincode->pincode}}" > {{$pincode->pincode}} </option>
@endforeach