@include('tw.layouts.inn-hdr')
<div style="padding-top:50px!important" class="wizard-container addmargin">
    <div class="row">
    
   <div class="container genenq">
      <div class="col-md-6 card-contact">
         <a> <img class="img" src="{{ URL::asset('image/consultant.svg')}}" alt="Insurance Consultant" /></a>
      </div>
      <div class="col-md-6 card-contact">
        
         @if(isset($msg) && !empty($msg))
		<h2 class="card-title" style="color: #00669C;">{{$msg}}</h2>
         @else
          <h2 class="card-title" style="color: #00669C;">Transferred to a Offline Team</h2>
         @endif
         <h5> One of our consultant will get in touch with you shortly to help you purchase this policy.</h5>

         <h6>In a hurry? Call us right now : <b>+91 7899-000-333</b></h6>

         <a href="/two-wheeler-insurance"><button type="submit" class="btn btn-success">Home</button></a>
      </div>
   </div>
   
    </div>
</div>
@include('tw.layouts.inn-ftr')