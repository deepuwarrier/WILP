
<div class="wizard-container">
    <div class="col-md-4">
        	  @include('tw.quote.d_preview')
    </div>
    <!-- wizard container -->
    <div class="col-md-4">
        <div class="card card-form-horizontal" style="min-height:121px">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <a class="btn btn-info btn-xs pull-right" href="{{URL::to('two-wheeler-insurance/quote')}}/{{ $tw_trans_code }}">Change</a>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Basic Information :</h6>
                    </div>
                </div>
				<table class="table customtable">
					<tbody>
						<tr>
							<td>Reg. Date</td>
							<td class="text-right">{{ $q_preview['reg_date'] }}</td>
							<td>Policy Start Date</td>
							<td class="text-right">{{ $q_preview['term_start_date'] }}</td>
						</tr>
						<tr>
							<td>IDV</td>
							<td class="text-right">{{ $q_preview['opt_idv'] }}</td>
							<td>Eligible NCB</td>
							<td class="text-right">{{ $q_preview['eli_ncb'] }}%</td>
						</tr>
					</tbody>
				</table>
			</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="row card customcard" style="min-height:121px">
            <div class="col-xs-4 logobox">
                <img src="{{asset('image/logos')}}/{{ $q_preview['insurer_logo'] }}" alt="Insurer Logo">
            </div>
            <div class="col-xs-8 rightalign_ss" style="text-align: right">
                <h6>{{ $q_preview['insurer_name'] }}</h6>
                <h5 class="card-title" style="font-size:30px">&#8377;  {{ $q_preview['total_premium'] }}</h5>
 				<a href="#"><i class="material-icons iconcustom modal_details" data-modal="packageInfo" data-producid ="" data-toggle="tooltip" data-placement="top" id="" title="Package Info" onclick='jQuery("#pkginfo_{{$quote->insurer_code() }}").modal();' >stars</i></a>
                       <a href="#"><i class="material-icons iconcustom modal_details" data-modal="premiumBreakup" data-producid =""  data-toggle="tooltip" data-placement="top" title="Premium Breakup" onclick='jQuery("#prebreak_{{$quote->insurer_code() }}").modal();'>description</i></a>             
            </div>
        </div>
    </div>

</div>

 <!--  Start : Package Info ------------------->
 <div class="modal fade" id="pkginfo_{{$quote->insurer_code() }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">

         <div class="card card-pricing card-margin">
         <div class="row customcard">
               <div class="col-sm-4 logobox">
                  <img src="{{ URL::asset('image/logos/')}}/{{$quote -> insurer_logo() }}" alt="Insurer Logo">
               </div>
                  <div class="col-sm-4">
                     <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$quote -> final_premium() }}</h5>
                     <span class="label label-default extrapanelitem">IDV: {{$quote -> idv() }}</span>
                  </div>
                  
        </div>
                     <div class="content">
                        <h3>Many Benefits in <b>one</b> Package</h3>
                        <ul>
                                 <li><b>Own Damage</b> </li>
                                 <li><b>Third Party Liability</b></li>
                                 <li><b>PA Cover for Owner Driver</b></li>
 @if($quote->addon_zrdp() > 0)  <li><b>Zero Depreciation (Bumper to Bumper)</b></li>  @endif                              
 @if($quote->addon_cnsm() > 0)  <li><b>Cost of Consumables </b></li>  @endif                              
 @if($quote->addon_ncbp() > 0)  <li><b>NCB Protection </b></li>  @endif                              
 @if($quote->addon_rsac() > 0)  <li><b>Enhanced Roadside Assistance</b></li>  @endif                              
 @if($quote->addon_rtin() > 0)  <li><b>Return to Invoice</b></li>  @endif                              
                        </ul>
                     </div>
                  </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
    <!--         <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0">Save</a>	 -->
         </div>
      </div>
   </div>
</div>
 
 <!--  End : Package Info ------------------->
 <!--   Start : Premium Breakup  -->

<div class="modal fade" id="prebreak_{{$quote->insurer_code() }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                     <div class="modal-dialog">
                        <div class="modal-content premium-breakup-card ">
                           <div class="modal-body premium-breakup">
                           <div class="card customcard">
                                 <div class="col-sm-4 logobox">
                                    <img src="{{ URL::asset('image/logos/')}}/{{$quote -> insurer_logo() }}" alt="Insurer Logo">
                                 </div>
                                    <div class="col-sm-4">
                                       <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$quote -> final_premium() }}</h5>
                                       <span class="label label-default extrapanelitem">IDV: {{$quote -> idv() }}</span>
                                    </div>
                                    <div class="col-sm-4 buybutton" style="margin-top: 15px;">
                                       <!-- <button type="button" class="btn btn-success btn-sm">Buy Now</button> -->
                                    </div>
                           </div>
                           <div style="text-align:left">
                              <h3>Premium Breakup</h3>
                              <h4>Basic Covers</h4>
                              <ul>
                                 <li>
                                    <span class="">{{$cover_list[0]->cover_name}}</span>
                                    <span class="value pull-right">  {{ $quote->od_value() }}</span>
                                 </li>
                                 <li>
                                    <span class="">{{$cover_list[1]->cover_name}}</span>
                                    <span class="value pull-right"> {{ $quote->tp_value() }}</span>
                                 </li>
                              </ul>
                              <h4>Addon Covers</h4>
                              <ul>
                                    <li>
                                       <span class="">{{$cover_list[2]->cover_name}}</span>
                                       <span class="value pull-right">  {{ $quote->pa_value() }} </span>
                                    </li>

    @if($quote->addon_zrdp() > 0)  
     <li>
	     <span class="">{{$cover_list[3]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_zrdp() }} </span>
     </li>
      @endif
   @if($quote->addon_cnsm() > 0) 
	<li>
	     <span class="">{{$cover_list[4]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_cnsm() }} </span>
     </li>
  @endif                                  
 @if($quote->addon_ncbp() > 0) 
	<li>
	     <span class="">{{$cover_list[5]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_ncbp() }} </span>
     </li>
  @endif 
  @if($quote->addon_rsac() > 0) 
	<li>
	     <span class="">{{$cover_list[6]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_rsac() }} </span>
     </li>
  @endif 
  @if($quote->addon_rtin() > 0) 
	<li>
	     <span class="">{{$cover_list[7]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_rtin() }} </span>
     </li>
  @endif 
                               
                              </ul>
                              <h4>Discounts</h4>
                              <ul>
                                <li>
                                    <span class="">OD Discount</span>
                                    <span class="value pull-right">( - )  {{ $quote->od_disc()  }}</span>
                                 </li>
                                 <li>
                                    <span class="">No Claim Bonus</span>
                                    <span class="value pull-right">( - )   {{ $quote->ncb_value() }}</span>
                                 </li>
                              </ul>
                              <h4>Taxes</h4>
                              <ul>
                                 <li>
                                    <span class="">Goods & Services Tax</span>
                                    <span class="value pull-right">  {{ $quote->service_tax() }}</span>
                                 </li>
                              </ul>
                              <h4>Final Premium</h4>
                              <ul>
                                 <li class="finalprm">
                                    <span class="">Total Premium</span>
                                    <span class="pull-right">{{ $quote->final_premium() }}</span>
                                 </li>
                              </ul>
                        </div> 
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
<!--                               <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0">Save</a>	-->
                        </div>
                     </div>
                  </div>
                  </div>
                  


 <!--   End : Premium Breakup  -->



<div id="modal_div"></div>
