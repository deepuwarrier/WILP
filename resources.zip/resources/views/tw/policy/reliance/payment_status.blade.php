@include('tw.layouts.inn-hdr')
<div class="wizard-container">
    @if( $trans_resp['trans_status'] == 1 )

        <div class="premiumconfirmation">
        <div class="card">
            <div class="content content-success" style="border-bottom-left-radius: 0px;border-bottom-right-radius: 0px">
                <h3 class="category-social whitefont">
                     <i class="fa fa-newspaper-o"></i> Congratulations!!
                  </h3>
                <h4 class="card-title">
                     <a href="#pablo">Your payment has been processed Successfully!</a>
                  </h4>
                <p class="card-description">
                    Thank you for your patronage.
                </p>
            </div>
            <div class="content">
                <h4 class="card-title">
                  <div class="logobox">
                     <img src="{{asset('image/logos/')}}/{{ $trans_resp['insurer_logo'] }}" alt="Insurer Logo">
                  </div>
                    <a href="#pablo">Your policy will hit your inbox shortly.</a>
                </h4>
                <h5 class="category-social">
                     <i class="fa fa-newspaper-o"></i>Please note your policy number!
                  </h5>
                <p><h2>{{ $trans_resp['policy_number'] }}</h2></p>

                <p>
                    @if(isset($trans_resp['download_link']))
                        <a href="{{ $trans_resp['download_link'] }}" target="_target" class='btn btn-primary'>Download Policy</a>
                    @endif
                </p>
                <p></p>

                <div class="content hidden">
                    <form class="nl">
                        <button type="button" class="nl__btn btn-xs">Email This!</button>
                        <input placeholder="your@email.com" class="nl__input aria-hidden" type="text">
                    </form>
                </div>
                <div class="content">

                    <p>Your policy will be sent to your email id shortly by the insurance company</p>
                    <p>Meanwhile, you will soon recieve a welcome email from us as well!</p>
                </div>


            </div>
        </div>
        </div>

    @else
   <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" /></a>
      </div>
      <div class="col-md-6 card-contact">
         <h1 class="card-title" style="color: #00669C;">{{ $trans_resp['trans_msg'] }}</h1>
         <h4 class="card-title" style="color: #00669C;">Most of the time we get you through. But if money is deducted and still you see this page, Dont worry! </h4>
         <h5> By the time you finish reading this, one of our experts would have started working on it. <b>You will be contacted soon.</b></h5>
		<p>
		<h5 class="category-social">
                     </i>Meanwhile please note your reference number!
         </h5>
                <h3>{{ $trans_resp['proposal_number'] }}</h3>
         </p>
			
         <a href="{{ URL::to ('two-wheeler-insurance') }}"><button type="submit" class="btn btn-success">Home</button></a>
      </div>
   </div>
    @endif
</div>
@include('tw.layouts.inn-ftr')
