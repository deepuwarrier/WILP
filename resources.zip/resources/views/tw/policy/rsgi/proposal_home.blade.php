
@include('tw.layouts.inn-hdr')

@include('tw.policy.q_preview')

<!-- start form wizard  -->
<div class="row" >
    <div class="wizard-container wizard-proposalcontainer" style="padding-top: 20px;">
        <div class="card wizard-card" data-color="green" id="wizardProfile">
            <form autocomplete="off" method="post"  id="buy_policy_form">
                <div class="wizard-navigation">
                    <ul class="nav nav-pills">
                        <li style="width: 20%;" class="active">
                            <a href="#proposer" data-toggle="tab" aria-expanded="" id="proposer_tab" onclick="strt_proposal_data();">Proposer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#communication" data-toggle="tab" id="commu_tab" onclick="strt_proposal_data();" >Communication</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#vehicle" data-toggle="tab" id="vehicle_tab" onclick="strt_proposal_data();">Vehicle Details</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#previousinsurer" data-toggle="tab" id="preinsr_tab" onclick="strt_proposal_data();">Previous Insurer</a>
                        </li>
                        <li style="width:20%;">
                            <a href="#review" data-toggle="tab" onclick="strt_proposal_data();">Review</a>
                        </li>
                    </ul>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                    <div class="moving-tab" style="width: 282px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Proposer</div>
                </div>
                <div class="tab-content" id='setdata' >
                    <div class="tab-pane active" id="proposer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Proposer Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft dark">
                                            <a>
                                                <p>Owner Type</p>
                                            </a>
                                        </div>
                                    </div>

                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                           

                                            <div class="radiobutton">
                                                <input type="radio" name="type" id="Individual"  value="I" data-name="INDIVIDUAL"  checked />
                                                <label for="Individual">INDIVIDUAL</label>
                                            </div>
<!--                                             <div class="radiobutton"> -->
<!--                                                 <input type="radio"  name="type" id="Organization" value="O" data-name="Owner Type" /> -->
<!--                                                 <label for="Organization">ORGANIZATION</label> -->
<!--                                             </div> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Gender</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright" id="gender_group">
                                            <div class="radiobutton" >
                                                <input type="radio" name="p_gender" id="val_radio_male" value="M" checked data-name="MALE" />
                                                       <label for="val_radio_male" class="inline-label required show-info">MALE</label>
                                            </div>
                                            <div class="radiobutton">
                                                <input type="radio" name="p_gender" id="val_radio_female" value="F" data-name="FEMALE" />
                                                <label for="val_radio_female" class="inline-label required show-info">FEMALE</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Date of birth</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input class="form-control" type="text" data-minYear="01-Jan-1918" data-maxYear="30-Jun-1998"  id="cust_dob" name="cust_dob" placeholder="dd-mmm-yyyy" value="" data-name="Date of birth">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Company Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" name="companyname" value="" placeholder="Company Name" id="companyname" class="form-control required show-info" data-name="Company Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 organization hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Contact Person Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="contactperson" value="" placeholder="Contact Person Name" id="contactperson" class="form-control required show-info" data-name="Contact Person Name">

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=" col-sm-4 individual">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Full Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" name="cust_name" value="" id="cust_name" class="form-control" placeholder="Full Name">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Email ID</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="customer_email" value="" placeholder="Email" id="customer_email" data-name="Email ID">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Mobile</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" placeholder="10 Digit Mobile Number" class="form-control" name="mobile" value="" id="mobile"  maxlength="10">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
<div class="col-sm-4">
    <div class="card proposalcard">
        <div class="col-sm-4" style="padding:0">
            <div class="labelleft">
                <a>
                    <p>PAN Number</p>
                </a>
            </div>
        </div>
        <div class="col-sm-8" style="padding:0">
            <div class="labelright">
                <input type="text" placeholder="10 Digit PAN Number" class="form-control" name="pan_no" value="" id="pan_no" maxlength="10">
            </div>
        </div>
    </div>
</div> 
                            
<div class="col-sm-4">
    <div class="card proposalcard">
        <div class="col-sm-4" style="padding:0">
            <div class="labelleft">
                <a>
                    <p>Aadhar Number</p>
                </a>
            </div>
        </div>
        <div class="col-sm-8" style="padding:0">
            <div class="labelright">
                <input type="text" placeholder="12 Digit Aadhar Number" class="form-control" name="aadhar_no" value="" id="aadhar_no" maxlength="14">
            </div>
        </div>
    </div>
</div>                                  
                            
                                 <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
											<a>
												<p>Occupation</p>
											</a>
										</div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="rsgi_p_occuptn" id="rsgi_p_occuptn" class="form-control required show-info" >
									    <option selected  hidden="" disabled="" value="">SELECT OCCUPATION</option>
								@foreach ($base_data->get_occupation_list() as $occ_obj)
                                                <option value="{{$occ_obj->occu_code}}" data-name="{{$occ_obj->occu_name}}"> {{$occ_obj->occu_name}} </option>
								@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            
                        </div>

	<div class="wizard-footer">
	<div class="pull-right">
	<input  class="btn scrolltop btn-next btn-info"  id="proposer_store"   name="next" value="Next" type="button"/>
	</div>
	<div class="clearfix"></div>
	</div> 

</div>

<!--  Start : Address Details  Section ----------------------------------------------------------------------------------------------- -->
                    
                    <div class="tab-pane" id="communication">
                        <div class="row">
                            <h6 class="info-text"> ADDRESS AS PER THE TW REGISTRATION CERTIFICATE!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="houseno" value="" placeholder="House Number" id="houseno" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street Address</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" value="" name="street" placeholder="Street" id="street">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="locality" value="" placeholder="Locality" id="locality" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="statecode" id="state" class="form-control required show-info"   >
									    <option selected  hidden="" disabled="" value="">Select State</option>
								@foreach ($base_data->state_list() as $state_obj)
                                                <option value="{{$state_obj->state_code}}" data-name=" {{$state_obj->state_name}} "> {{$state_obj->state_name}} </option>
								@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="citycode" id="city" class="form-control required show-info" >
                                                <option selected hidden="" disabled="" value="">Select City</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="pincode" value="" placeholder="Pincode" id="pincode"  maxlength="6" >
                                        </div>
                                    </div>
                                </div>
                            </div>

<div class="col-sm-12">
	<div class="card proposalcard">
		<label> <input name="commu_addr_chkbx" type="checkbox"  id="commu_addr_chkbx" value=""> 
	Communication Address Same As Above
	</label>
	</div>
</div>
<p>&nbsp;</p>

 <div id="commu_addr_box" >   
 <h6 class="info-text"> Communication Address</h6>
       <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>House Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" name="comm_houseno" value="" placeholder="House Number" id="comm_houseno" data-name="House/Apartment Number">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Street Address</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control required show-info" value="" name="comm_street" placeholder="Street" id="comm_street" data-name="Street">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Locality</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required show-info" name="comm_locality" value="" placeholder="Locality" id="comm_locality" data-name="Locality">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>State</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="comm_statecode" id="comm_state" class="form-control required show-info"   >
									    <option selected  hidden="" disabled="" value="">Select State</option>
								@foreach ($base_data->state_list() as $state_obj)
                                                <option value="{{$state_obj->state_code}}" data-name=" {{$state_obj->state_name}} "> {{$state_obj->state_name}} </option>
								@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>City</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="comm_citycode" id="comm_city" class="form-control required show-info" >
                                                <option selected hidden="" disabled="" value="">Select City</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Pincode</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">

                                            <input type="text" class="form-control required digits show-info" name="comm_pincode" value="" placeholder="Pincode" id="comm_pincode"  maxlength="6" data-name="Pincode">
                                        </div>
                                    </div>
                                </div>
                            </div>
</div>


</div>

<div class="wizard-footer">
	<div class="pull-right">
	<input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="address_store"  name="next" value="Next" type="button">
	</div>
	 <div class="pull-left">
                    <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
                </div>
	<div class="clearfix"></div>
	</div>   
                        
</div>

<!--  Start : Vehicle Details  Section ----------------------------------------------------------------------------------------------- -->      

                    <div class="tab-pane" id="vehicle">
                        <div class="row">
                            <h6 class="info-text"> Enter the Vehicle Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Reg No.</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                                    <input type="text" class="form-control" name="tw_reg_no" id="tw_reg_no" style="text-transform: uppercase;" value="" placeholder="MH-01-AB-1234">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Engine No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="eng_no" value="" placeholder="Engine Number" id="eng_no" value="" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Chassis No</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="chassis_no" value="" placeholder="Chassis Number" id="chassis_no" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Onwership changed in past 12 Months</p>
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                         <select name="rsgi_owner_change" id="rsgi_owner_change" class="form-control required" >
									    			<option selected value="N" >No</option>
                                                <option value="Y">Yes</option>
                                         </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 hidden">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Voluntary Deductibles</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select  name="rsgi_vol_deduct" id="rsgi_vol_deduct" class="form-control"  disabled>
                                                 <option value="0" selected>No</option>
                                                <option  value="2500" >2500</option>
                                                <option  value="5000" >5000</option>
                                                <option  value="7500" >7500</option>
                                                <option  value="10000" >10000</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Year of Manufacturing</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select class='form-control required' name="yom_selected" id="yom_selected" >
                                            <option selected hidden="" disabled="" value="">Year Of Manuf.</option>
										@foreach ($base_data->yom_list() as $yom_obj)
                                                <option value="{{  $yom_obj }}"> {{  $yom_obj }} </option>
										@endforeach                                               
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Color</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" value="" name="color" placeholder="Color" id="color" >
                                        </div>
                                    </div>
                                </div>
                            </div>

 			<div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Is Vechicle Financed?</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                         <select name="rsgi_tw_finance" id="rsgi_tw_finance" class="form-control required" >
									    		   <option selected value="N">No</option>
                                                <option value="Y">Yes</option>
                                         </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
<div class="col-sm-4 ihide" id="rsgi_finance_type_box">
    <div class="card proposalcard">
        <div class="col-sm-4" style="padding: 0">
            <div class="labelleft">
                <a>
                    <p>Select Type of Finance</p>
                </a>
            </div>
        </div>
        <div class="col-sm-8" style="padding: 0">
            <div class="labelright">
                <select name="rsgi_tw_finance_type" id="rsgi_tw_finance_type" class="form-control required" >
                        <option selected value="">Select Type of finance</option>
                        <option  value="HYPOTHECATION">HYPOTHECATION</option>
                        <option  value="HIRE PURCHASE">HIRE PURCHASE</option>
                        <option  value="LEASE">LEASE</option>
                </select>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-4 ihide" id="rsgi_finance_name_box">
    <div class="card proposalcard">
        <div class="col-sm-4" style="padding: 0">
            <div class="labelleft">
                <a>
                    <p>Financier Name</p>
                </a>
            </div>
        </div>
        <div class="col-sm-8" style="padding: 0">
            <div class="labelright">
                <input type="text" class="form-control required show-info" name="rsgi_finance_name" value="" placeholder="Financier Name" id="rsgi_finance_name">
            </div>
        </div>
    </div>
</div>

</div>
 	
 	<div class="wizard-footer">
	<div class="pull-right">
	<input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="vehicle_store"  name="next" value="Next" type="button">
	</div>
	 <div class="pull-left">
       <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
      </div>
	<div class="clearfix"></div>
	</div>                          
                        
 </div>
 
<!--  Start : Previous Insurer Section ----------------------------------------------------------------------------------------------- -->                    
                    
                    <div class="tab-pane" id="previousinsurer">
                        <div class="row">
                            <h6 class="info-text"> Enter the Previous Year Insurance Details!</h6>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select id="previnsurance" name="previnsurance" class='form-control required' >
                                                <option selected hidden="" disabled="" value="">Previous Insurer</option>
@foreach ($base_data->pre_insurer_list() as $preinsr_obj)
                                                <option value="{{  $preinsr_obj->preinsr_code }}" data-name="{{  $preinsr_obj->preinsr_name }} "> {{  $preinsr_obj->preinsr_name }} </option>
@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Policy Number</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="policyno" value="" placeholder="Policy Number" id="policyno" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Policy Type</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                         <select name="rsgi_pre_policy_type" id="rsgi_pre_policy_type" class="form-control required" >
									    		   <option value="C"  >COMPREHENSIVE</option>
                                                <option value="L">LEAGAL LIABILITY</option>
                                         </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Previous Insurer Address</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control show-info " name="rsgi_preinsur_addr" value="" placeholder="Previous Insurer Address" id="rsgi_preinsur_addr" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Name</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <input type="text" class="form-control" name="nomineeName" value="" placeholder="Nominee Name" id="nomineeName">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nomine Age</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select  name="nomi_age" id="nomi_age" class="form-control required" >
                                            <option selected hidden="" disabled="" value="">Nomine Age</option>
                                                @for ($itr =18; $itr < 100; $itr++)
                                                <option  value="{{ $itr }}" >{{$itr}}</option>
                                                @endfor
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-4">
                                <div class="card proposalcard">
                                    <div class="col-sm-4" style="padding:0">
                                        <div class="labelleft">
                                            <a>
                                                <p>Nominee Relationship</p>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-sm-8" style="padding:0">
                                        <div class="labelright">
                                            <select name="nomineeRel" placeholder="Nominee Relation" id="nomineeRel" class='form-control show-info required' >
                                                <option  hidden="" disabled="" value="">Nominee Relationship</option>
@foreach ($base_data->nom_rel_list() as $nomrel_obj)
                                                <option  value="{{  $nomrel_obj->nomrel_code }}" data-name="{{  $nomrel_obj->nomrel_name }}" >{{  $nomrel_obj->nomrel_name }}</option>
@endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
 		
@if( $base_data->get_pre_claim_status() )
		<div class="col-sm-4">
		    <div class="card proposalcard">
		        <div class="col-sm-4" style="padding:0">
		            <div class="labelleft">
		                <a>
		                    <p>No. of Claims</p>
		                </a>
		            </div>
		        </div>
		        <div class="col-sm-8" style="padding:0">
		            <div class="labelright">
		                <input type="text" class="form-control" name="pre_claim_count" value="" placeholder="NO. OF CLAIMS (NUMBER)" id="pre_claim_count">
		            </div>
		        </div>
		    </div>
		</div>
		<div class="col-sm-4">
		    <div class="card proposalcard">
		        <div class="col-sm-4" style="padding:0">
		            <div class="labelleft">
		                <a>
		                    <p>Total Claim Amount</p>
		                </a>
		            </div>
		        </div>
		        <div class="col-sm-8" style="padding:0">
		            <div class="labelright">
		                <input type="text" class="form-control" name="pre_claim_amount" value="" placeholder="TOTAL CLAIM AMOUNT" id="pre_claim_amount">
		            </div>
		        </div>
		    </div>
		</div>
 @endif		
 
</div>
                        
<div class="wizard-footer">
	<div class="pull-right">
	<input data-focus='modal_div' class="btn scrolltop btn-next btn-info"  id="preinsurer_store"  name="next" value="Next" type="button">
	</div>
	 <div class="pull-left">
       <input data-focus='modal_div' class="btn scrolltop btn-previous btn-info disabled" name="previous" value="Previous" type="button">
      </div>
	<div class="clearfix"></div>
	</div>      
                        
                        
 </div>
 <input type="hidden" id="tw_trans_code" value="{{ $tw_trans_code }}" />
 <!--  Start : Preview  Section ----------------------------------------------------------------------------------------------- -->

<div class="tab-pane uppertxt" id="review">
	<h6 class="info-text">Review the data you entered!</h6>

	<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change"  id="goto_proposer">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Proposer :</h6>
                    </div>
                </div>
                <div class="row" id="proposer_preview">
                    <div class="col-md-12 div_customtable">
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Owner Type</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_Individual"></span>
                            </div>
                            <div class="col-sm-3 p_title">Gender</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_gender_group"></span>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Full Name</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_cust_name"></span>
                            </div>
                            <div class="col-sm-3 p_title">Date of Birth</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_cust_dob"></span>
                            </div>
                        </div>
						<div class="col-sm-12">
                            <div class="col-sm-3 p_title">Email</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_customer_email"></span>
                            </div>
                            <div class="col-sm-3 p_title">Mobile</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_mobile"></span>
                            </div>
                        </div>
						 <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Aadhar Number</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_aadhar_no"></span>
                            </div>
                            <div class="col-sm-3 p_title">Occupation</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_rsgi_p_occuptn"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">PAN Number</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_pan_no"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_commu">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Communication :</h6>
                    </div>
                </div>
               <div class="row" id="communication_preview">
                    <div class="div_customtable">
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">House No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_houseno"></span>
                            </div>
                            <div class="col-sm-3 p_title">Street Address</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_street"></span>
                            </div>
                        </div>


                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Locality</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_locality"></span>
                            </div>
                            <div class="col-sm-3 p_title">State</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_state"></span>
                            </div>
                        </div>
						  <div class="col-sm-12">
                            <div class="col-sm-3 p_title">City</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_city"></span>
                            </div>
                            <div class="col-sm-3 p_title">Pincode</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_pincode"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_vehicle">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Vehicle Details :</h6>
                    </div>
                </div>
                <div class="row" id="vehicle_preview">
                     <div class="div_customtable">
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Reg. No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_reg_number"></span>
                            </div>
                            <div class="col-sm-3 p_title">Mfg Year</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_yom_selected"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Chassis No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_chassis_no"></span>
                            </div>
                            <div class="col-sm-3 p_title">Engine No.</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_eng_no"></span>
                            </div>
                        </div>
						<div class="col-sm-12">
                            <div class="col-sm-3 p_title">Owner Changed</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_rsgi_owner_change"></span>
                            </div>
                            <div class="col-sm-3 p_title">Vechicle Financed</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_rsgi_tw_finance"></span>
                            </div>
                        </div>
						<div class="col-sm-12">
                            <div class="col-sm-3 p_title">Color</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_color"></span>
                            </div>
                            <div class="col-sm-3 p_title">Financie Type</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_rsgi_finance_type"></span>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="col-sm-3 p_title">Financier Name</div>
                            <div class="col-sm-3">
                                <span class="text-right" id="p_rsgi_finance_name"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6">
        <div class="card card-form-horizontal previewheight">
            <div class="content">
                <div class="row">
                    <div class="col-xs-6 pull-right">
                        <button type="button" class="btn btn-info btn-xs pull-right change" id="goto_preinsr">Change</button>
                    </div>
                    <div class="col-xs-6 pull-left">
                        <h6 class="pull-left">Previous Insurer :</h6>
                    </div>
                </div>
<div class="" id="previousinsurer_preview">
     <div class="div_customtable">
	<div class="col-sm-12">
		<div class="col-sm-12">
            <div class="col-sm-3 p_title">Previous Ins.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_previnsurance"></span>
            </div>
            <div class="col-sm-3 p_title">Policy No.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_policyno"></span>
            </div>
        </div>
		<div class="col-sm-12">
            <div class="col-sm-3 p_title">Nominee Name</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomineeName"></span>
            </div>
            <div class="col-sm-3 p_title">Nominee  Rel.</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomineeRel"></span>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-3 p_title">Nominee Age</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_nomi_age"></span>
            </div>
            <div class="col-sm-3 p_title">Previous Ins. Type</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_rsgi_pre_policy_type"></span>
            </div>
        </div>
@if( $base_data->get_pre_claim_status() )	
		<div class="col-sm-12">
            <div class="col-sm-3 p_title">No. of Claims</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_pre_claim_count"></span>
            </div>
            <div class="col-sm-3 p_title">Total Claims Amout</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_pre_claim_amount"></span>
            </div>
        </div>
@endif		
 @if( $base_data->get_pre_zerodept() == 'Y' ) 		
        <div class="col-sm-12">
            <div class="col-sm-3 p_title">Had Zero Depreciation</div>
            <div class="col-sm-3">
                <span class="text-right" id="p_prevzerodep_selected"></span>
            </div>
        </div>
@endif		
	</div>
</div>
			</div>
        </div>
    </div>
</div>

<!--  Start : Disclaimer text -->
<div class="col-md-12 radiobutton" id="tnc_box">
	<label> <input name="disclaimer" type="checkbox" value="disclaimer" id="disclaimer"> 
	I confirm that all the information provided above are true to the best of my knowledge. I also agree to appoint Toyota Tsusho Insurance Broker to represent me as my Insurance Broker.
	</label>
</div>
<!--  End : Disclaimer Text -->

</div>

				</div>
            </form>
            
            <div class="wizard-footer">
                <div class="pull-right">
                    <input data-focus='modal_div' class="btn scrolltop btn-finish btn-info" name="finish" value="Finish" style="display: none;" type="button" id="tw_rsgi_proposal_finish">
                </div>
                
                <div class="clearfix"></div>
            </div>
            
        </div>
    </div>
</div>
<!-- fnished form wizard -->

@include('tw.layouts.inn-ftr')
<script src="{{ asset('js/tw/twpolicy.js') }}"></script> 
<script src="{{ asset('js/validation_lib.js') }}"></script> 
 <script src="{{ asset('js/tw/policy/rsgi.js') }}"></script> 
<script type="text/javascript"> retrive_proposal_data(); </script>
 <script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script> 
<script type="text/javascript"> 
 $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    });   
 </script>
