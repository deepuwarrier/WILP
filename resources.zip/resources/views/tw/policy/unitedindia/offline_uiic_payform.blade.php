

<form id="payment" name="uiic_payment" method="POST"
	action="https://pgi.billdesk.com/pgidsk/PGIMerchantPayment">
	<input type='text' name='msg' value='{{ $embstr }}'  size="220"/>
		<input type='Submit' value='Submit' id='submit_uiic_payment' />
</form>

	

