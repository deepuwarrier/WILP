<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style type="text/css">
        body{
         background: white;
         margin:  0px;
         }
        html{
          margin:30px 40px; 
          font-size: 11px;
        }

        .cntr{ 
          text-align:center;
        } 
        
        table {
          border-collapse: none;
	     border-spacing: 0px;
        }
        
       table, th, td {
   		border: 1px solid #000;
		}
        th,td,tr,td,p,div,b {
          margin:0;
          padding:0;
        }
          

      </style>
   </head>
   <body>
      <div class="container">

         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160px" height="90px"  alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
         </div>
         <div class="col-sm-12 cntr">
            <div>10/4, MITHRA TOWERS KASTURBA ROAD BANGALORE, BANGALORE, KARNATAKA BANGALORE - 560001 KARNATAKA</div>
            <div>PH: (080) 22210847 FAX: EMAIL:</div>
            <div>MOTORCYCLE / SCOOTER LIABILITY ONLY POLICY</div>
            <div>POLICY NO.: {{ $usr_data->policy_number }}</div>
            <div>VEHICLE NO.: {{ $usr_data->tw_reg_no }}</div>
            <div>&nbsp;</div>
            <div>PERIOD OF INSURANCE</div>
            <div>From 00:00 Hrs on {{ $usr_data->term_start_date }}</div>
            <div>To Midnight on {{ $usr_data->term_end_date }}</div>
            <div>&nbsp;</div>
            <div>Insured</div>
            <div><h3>{{ $usr_data->proposer_name }}</h3></div>
            <div>{{ $usr_data->regn_addr1 }}, {{ $usr_data->proposer_city_code }}, {{ $usr_data->proposer_state_code }} - {{ $usr_data->regn_pincode }}</div>
            <div>CONTACT NUMBER : {{ $usr_data->proposer_mobile }} (M)</div>
            <div>&nbsp;</div>
            <table align="center">
               <tr>
                  <td>Agent Name</td>
                  <td>: TOYOTA TSUSHO INSURANCE BROKER INDIA PVT LTD.</td>
               </tr>
               <tr>
                  <td>Agent Code</td>
                  <td>: {{ $usr_data->broker_code }}</td>
               </tr>
               <tr>
                  <td>Mobile/Landline Number/Email</td>
                  <td>: +91 7899-000-333</td>
               </tr>
            </table>
            
           
            <div style="position: absolute;bottom: 0px; left: 10px;">
             <hr>
            REGD. & HEAD OFFICE, 24, WHITES ROAD, CHENNAI - 600014 Website: http://www.uiic.co.in, Email - info@uiic.co.in | Printed By : InstaInsure.com @ {{ $usr_data->policy_date }}
            </div>
</div>
         </div>

         <p style="page-break-after: always;">&nbsp;</p>
        

         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160" height="90px"  alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
            <div>CERTIFICATE OF INSURANCE</div>
            <div>MOTORCYCLE / SCOOTER - (FORM 51 OF CENTRAL MOTOR VEHICLE RULES 1989)</div>
         </div>

         <div class="container">
            <table width="100%">
               <tr>
                  <td colspan="2">Policy No.</td>
                  <td colspan="3" >{{ $usr_data->policy_number }}</td>
                  <td colspan="2">Certificate Number.</td>
                  <td colspan="3"></td>
               </tr>
               <tr>
                  <td colspan="2">Customer Id</td>
                  <td colspan="3" >{{ $usr_data->policy_number }}</td>
                  <td colspan="2">Issuing Office Address</td>
                  <td colspan="1">Code</td>
                  <td colspan="2"></td>
               </tr>
               <tr>
                  <td colspan="2">Name of the Insured</td>
                  <td colspan="3" >{{ $usr_data->proposer_name }}</td>
                  <td colspan="5">10/4, MITHRA TOWERS KASTURBA ROAD BANGALORE, BANGALORE, KARNATAKA 560001 BANGALORE KARNATAKA.</td>
               </tr>
               <tr>
                  <td colspan="2">Address of the Insured</td>
                  <td colspan="3">{{ $usr_data->regn_addr1 }}<br>{{ $usr_data->proposer_city_code }} - {{ $usr_data->proposer_pincode }}, {{ $usr_data->proposer_state_code }}</td>
                  <td colspan="2">Telephone</td>
                  <td colspan="3">--</td>
               </tr>
               <tr>
                  <td colspan="5">Effective date of commencement of Insurance for the purpose of Act from 00:00 Hrs on {{ $usr_data->term_start_date }}</td>
                  <td colspan="2">Mobile</td>
                  <td colspan="3">{{ $usr_data->proposer_mobile }}</td>
               </tr>
               <tr>
                  <td colspan="10">Date of Expiry of the Insurance Midnight on {{ $usr_data->term_end_date }}</td>
               </tr>
               <tr>
                  <td colspan="10">Particulars of Vehicle Insured</td>
               </tr>
               <tr>
                  <td colspan="2">Registration No.</td>
                  <td colspan="1">Obsolete Vehicle</td>
                  <td colspan="1">Engine No.</td>
                  <td colspan="1">Chassis No.</td>
                  <td colspan="1">Make/ Model</td>
                  <td colspan="1">Year of Mfg</td>
                  <td colspan="1">Type of Body</td>
                  <td colspan="1">Cubic Capacity</td>
                  <td colspan="1">Seating including driver</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data->tw_reg_no }}</td>
                  <td colspan="1">NA</td>
                  <td colspan="1">{{ $usr_data->tw_engine_no }}</td>
                  <td colspan="1">{{ $usr_data->tw_chassis_no }}</td>
                  <td colspan="1">{{ $usr_data->make_code }} / {{ $usr_data->model_code }}</td>
                  <td colspan="1">{{ $usr_data->yom }} </td>
                 <td colspan="1"> {{ $usr_data->body_type }}</td>
                  <td colspan="1">{{ $usr_data->variant_cc }}</td>
                  <td colspan="1">2</td>
               </tr>
               <tr>
                  <td colspan="3">Registration Authority</td>
                  <td colspan="3">Geographical Area</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="3">{{ $usr_data->rto_code }} {{ $usr_data->rto_location }}</td>
                  <td colspan="3">INDIA</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="6">Amount in words: {{ $usr_data->final_premium_words }}</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="10"><b>Persons or classes of persons entitled to drive</b><br>Any person including Insured provided that a person holds an effective driving licence at the time of accident and is not disqualified from holding or obtaining such a licence. Provided also that the person holding an effective Learner's Licence may also drive the vehicle and such a person satisfies the requirements of Rule 3 of Central Motor Vehicle Rule, 1989.</td>
               </tr>
               <tr>
                  <td colspan="5" rowspan="11">
                     <b>Limitations as to use</b><br>The policy covers use of the vehicle for any purpose other than<br>
                        1. Hire or Reward<br>
                        2. Carriage Goods (other than samples or personal luggage) <br>
                        3. Organized Racing<br>
                        4. Pace Making <br>
                        5. Speed Testing and Reliability Trials<br>
                        6. Use in connection with Motor Trade<br>
                  </td>
                  <td colspan="3">Premium:</td>
                  <td colspan="2">{{ $usr_data->gross_total_premium }}</td>
               </tr>
               <tr>
                  <td colspan="3">Goods & Services Tax:</td>
                  <td colspan="2">{{ $usr_data->total_tax }}</td>
               </tr>
               <tr>
                  <td colspan="3">Swachh Bharat Cess:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Krishi Kalyan Cess:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Stamp Duty:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Total(Rounded Off):</td>
                  <td colspan="2">{{ $usr_data->final_premium }}</td>
               </tr>
               <tr>
                  <td colspan="3">Receipt Number:</td>
                  <td colspan="2">{{ $usr_data->pg_refno }}</td>
               </tr>
               <tr>
                  <td colspan="3">Receipt Date:</td>
                  <td colspan="2">{{ $usr_data->policy_date }}</td>
               </tr>
               <tr>
                  <td colspan="3">DebitNote Number:</td>
                  <td colspan="2"></td>
               </tr>
               <tr>
                  <td colspan="3">Document Date:</td>
                  <td colspan="2"></td>
               </tr>
               <tr>
                  <td colspan="3">STax Regn No.:</td>
                  <td colspan="2">AAACU5552CST001</td>
               </tr>
               <tr>
                  <td colspan="5" width="50%"><b>Limits of Liability</b><br>
                     Under Section II-I (i) Death or bodily injury in respect of any one accident; As per Motor Vehicles Act 1988
                     <br>Under Section II-I (ii) Damage to third party property in respect of any one claim or series of claims arising out of one event:   100000/-
                  </td>
                  <td colspan="5">Agency/Broker Code: ({{ $usr_data->broker_code }})<br>
                     Toyota. <br> Direct Business:
                     Developement Officer Code:<br>
                  </td>
               </tr>
            </table>
         </div>

         <div class="col-sm-12 cntr">
            <table width="100%">
               <tr>
                  <td width="80%">&nbsp;</td>
                  <td>For and On behalf of United India Insurance Co. Ltd.</td>
               </tr>
               <tr>
                  <td><b>Subject to IMT Endorsement No.s, terms and conditions printed herein / attached hereto IMT.22</b><br>
                     I/We hereby certify that the policy to which the certificate relates as well as the certificate of insurance are issued in accordance with provisions of Chapter X & XI of M.V Act, 1988.
                     <br><b>Date of Issue:</b> {{ $usr_data->policy_date }}<br>
                     <b>Underwritten By - Lekha Kilikar, Sr. Divisional Manager (072300)</b>
                  </td>
                  <td><img src="{{public_path('image/digital')}}/uiic_auth_sign.png"></td>
               </tr>
               <tr>
                  <td>&nbsp;</td>
                  <td>Duly Constituted Attorney</td>
               </tr>
            </table>
         </div>

         
         <p style="page-break-after: always;">&nbsp;</p>
         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png" width="160px" height="90px" alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
            <div>MOTORCYCLE / SCOOTER -SCHEDULE</div>
         </div>
         <div class="col-sm-12 cntr">
            <table width="100%">
               <tr>
                  <td colspan="2">Policy No.</td>
                  <td colspan="3">{{ $usr_data->policy_number }}</td>
                  <td colspan="2">Previous Policy No.</td>
                  <td colspan="3">{{ $usr_data->pre_policy_number }}</td>
               </tr>
               <tr>
                  <td colspan="2" rowspan="5">Insured Details</td>
                  <td colspan="3">Customer Id</td>
                  <td colspan="5">CF260320171094125</td>
               </tr>
               <tr>
                  <td colspan="3">Name</td>
                  <td colspan="5">{{ $usr_data->proposer_name }}</td>
               </tr>
               <tr>
                  <td colspan="3">Tel(O)</td>
                  <td colspan="2">Tel(R)</td>
                  <td colspan="3">Fax:</td>
               </tr>
               <tr>
                  <td colspan="3">Email: {{ $usr_data->proposer_email }}</td>
                  <td colspan="5">Mobile: {{ $usr_data->proposer_mobile }}</td>
               </tr>
               <tr>
                  <td colspan="1">Period of Insurance</td>
                  <td colspan="1">From</td>
                  <td colspan="2">00:00 Hrs of {{ $usr_data->term_start_date }}</td>
                  <td colspan="1">To</td>
                  <td colspan="3">Midnight of {{ $usr_data->term_end_date }}</td>
               </tr>
               <tr>
                  <td colspan="2">Co-Insurance</td>
                  <td colspan="1">Type</td>
                  <td colspan="7"></td>
               </tr>
               <tr>
                  <td colspan="10"><b>Particulars of Vehicle Insured</b></td>
               </tr>
               <tr>
                  <td colspan="2">Registration No.</td>
                  <td colspan="1">Obsolete Vehicle</td>
                  <td colspan="1">Engine No.</td>
                  <td colspan="1">Chassis No.</td>
                  <td colspan="1">Make/ Model</td>
                  <td colspan="1">Year of Mfg</td>
                  <td colspan="1">Type of Body</td>
                  <td colspan="1">Cubic Capacity</td>
                  <td colspan="1">Seating including driver</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data->tw_reg_no }}</td>
                  <td colspan="1">No</td>
                  <td colspan="1">{{ $usr_data->tw_engine_no }}</td>
                  <td colspan="1">{{ $usr_data->tw_chassis_no }}</td>
                  <td colspan="1">{{ $usr_data->make_code }} / {{ $usr_data->model_code }}</td>
                  <td colspan="1">{{ $usr_data->yom }}</td>
                  <td colspan="1"> {{ $usr_data->body_type }}</td>
                  <td colspan="1">{{ $usr_data->variant_cc }}</td>
                  <td colspan="1">2</td>
               </tr>
               <tr>
                  <td colspan="2">Registration Authority</td>
                  <td colspan="2">Auto Association Membership No.</td>
                  <td colspan="2">Geographical Area</td>
                  <td colspan="4">Extension</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data->rto_code }} {{ $usr_data->rto_location }}</td>
                  <td colspan="2"></td>
                  <td colspan="2">INDIA</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="10">Two wheeler shall be deemed to include a Side Car attached to it.</td>
               </tr>
               <tr>
                  <td colspan="10"><b>Persons or classes of persons entitled to drive</b><br>Any person including Insured provided that a person holds an effective driving licence at the time of accident and is not disqualified from holding or obtaining such a licence. Provided also that the person holding an effective Learner's Licence may also drive the vehicle and such a person satisfies the requirements of Rule 3 of Central Motor Vehicle Rule, 1989.</td>
               </tr>
               <tr>
                  <td colspan="10"><b>Limitations as to use</b><br>
                     The policy covers use of the Vehicle for any purpose other than: a) Hire or Reward
                     b) Carriage Goods (other than samples or personal luggage)
                     c) Organized Racing
                     d) Pace Making
                     e) Speed Testing and Reliability Trials
                  </td>
               </tr>
               <tr>
                  <td colspan="10"><b>Limits of Liability</b> As narrated in the Certificate of Insurance attached herewith.<br>
                     EXCLUSIONS :<br>
                     1) Any accidental loss or damage or Liability / caused or sustained or incurrred outside the geographical area.<br>
                     2) Any claim arising out of any contractual liability.<br>
                     3) Any accidental loss or damage to any property whatsoever or any loss or any expense whatsoever resulting or arising there from or any consequential loss.<br>
                     4) Any liability of whatsoever nature directly or indirectly caused by or constituted to or by or arising out of ionizing radiations or contamination by radioactivity from any nuclear fuel. For the purpose of this exception, combustion shall include any self-sustaining process of nuclear fission.<br>
                     5) Any accidental loss or damage or liability directly or indirectly caused by or contributed to, by or arising from nuclear weapons material.<br>
                     6) Any accidental loss, damage or liability directly or indirectly or proximatley or remotely occasioned by contributed to, by or traceable to or arising out of or in connection with war, invasion, act of foreign enemies, hostilities or warlike operations (whether before or after declaration of war), civil war, mutiny, rebellion, military or usurped power, or by any direct or indirect consequence of any of the said occurrences or may consequence thereof and in default of such proof, the Company shall not be liable to make any payment in respect of such a claim.
                  </td>
               </tr>
            </table>
         </div>
         <div class="col-sm-12">
            Underwritten by: United India Insurance Co Ltd.<br>
            <b>This policy is subject to terms and conditions and IMT Endorsement Nos. printed herein / attached hereto IMT.22</b>
         </div>
         <p>&nbsp;</p>
         <p style="page-break-after: always;">&nbsp;</p>
         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160px" height="90px"   alt="Insurer Logo">
         </div>
         <div class="col-sm-12">
            <table width="100%">
               <tr>
                  <td colspan="2">SCHEDULE OF PREMIUM (IN  )</td>
               </tr>
				<tr>
					<td width="80%">Basic TP  
						<br>ADD:<br>
						@foreach($usr_data->cover_name_arr as $cov_name)
						{{$cov_name}}<br> 
						@endforeach  
						<br><br><b>Gross Total TP:   </b> 
					</td>
					<td>
					 {{ $usr_data->tp_premium }}
					 <br><br> 
					@foreach($usr_data->cover_value_arr as $cov_value)
						{{$cov_value}}<br> 
						@endforeach  
					<br><br><b> {{ $usr_data->gross_total_premium }}</b>
					</td>
					
				</tr>
			</table>
         </div>
         <div class="col-sm-12">
            <b>TERMS AND CONDITIONS</b><br>
            AS PER THE INDIAN MOTOR TARIFF. PERSONA COPY OF THE SAME IS AVAILABLE FREE OF COST ON REQUEST. FURTHER, THE INDIAN MOTOR TARIFF IS ALSO AVAILABLE AND DISPLAYED AT ALL UNITED INDIA INSURANCE COMPANY OFFICES AND ON UIIC WEBSITE : www.uiic.co.in
            DISCLAIMER : THE POLICY STANDS CANCELLED OR VOID IN THE EVENT OF CHEQUE DISHONOR. THE COMPANY MAY CANCEL THE POLICY BY SENDING 7 DAYS NOTICE IN CASE OF ANY FRAUD OR MISREPRESENTATION, NON-DISCLOSURE OF MATERIAL FACT OR NON-COOPERATION OF THE INSURED.<br>
            <b>IMPORTANT NOTICE</b><br>
            THE INSURED IS NOT INDEMNIFIED IF THE VEHICLE IS USED OR DRIVEN OTHERWISE THAN IN ACCORDANCE WITH THIS SCHEDULE. ANY PAYMENT MADE BY THE COMPANY BY REASON OF WIDER TERMS APPEARING IN THE CERTIFICATE IN ORDER TO COMPLY WITH THE MOTOR VEHICLES ACT, 1988 IS RECOVERABLE FROM THE INSURED. SEE THE CLAUSE HEADED "AVOIDANCE OF CERTAIN TERMS AND RIGHT OF RECOVERY". FOR LEGAL INTERPRETATION, ENGLISH VERSION WILL HOLD GOOD.
         </div>
         <p>&nbsp;</p>
         <div class="col-sm-12">
            <table width="100%">
               <tr>
                  <td>Premium:</td>
                  <td>  {{ $usr_data->gross_total_premium }}</td>
                  <td>Receipt Number :</td>
                  <td>IPNB5223805366</td>
                  <td>Agency/Broker Code:</td>
                  <td>{{ $usr_data->broker_code }}</td>
               </tr>
               <tr>
                  <td>Goods & Services Tax
                  <td>    {{ $usr_data->total_tax }}</td>
                  <td>Receipt Date :</td>
                  <td>{{ $usr_data->policy_date }}</td>
                  <td>Direct Business:</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Stamp Duty:</td>
                  <td>   0</td>
                  <td>DebitNote Number :</td>
                  <td></td>
                  <td>Developement Officer Code:</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Total (Rounded Off):</td>
                  <td>  {{ $usr_data->final_premium }}</td>
                  <td>Document Date :</td>
                  <td></td>
                  <td>Cover Note No.:</td>
                  <td></td>
               </tr>
               <tr>
                  <td colspan="2"></td>
                  <td>STax Regn No:</td>
                  <td>AAACU5552CST001</td>
                  <td>Cover Note Date:</td>
                  <td></td>
               </tr>
            </table>
         </div>
         <div class="col-sm-12">
            <b>Anti Money Laundering Clause:-</b>In the event of a claim under the policy exceeding   1 lakh or a claim for refund of premium exceeding   1 lakh, the insured will comply with the provisions of AML policy of the company. The AML policy is available in all our operating offices as well as Company's web site.
            <br><br>
            Date of Proposal and Declaration: {{ $usr_data->policy_date }} <br><br><br>
            IN WITNESS WHEREOF, this policy has been signed at on {{ $usr_data->policy_date }}.
            For and On behalf of<br>
            United India Insurance Co. Ltd.<br><br>
            <img src="{{public_path('image/digital')}}/uiic_auth_sign.png">
            <br><br>
            Duly Constituted Attorney:<br>
            <b>Underwritten By - Lekha Kilikar, Sr. Divisional Manager (072300)</b>
         </div>
         <p>&nbsp;</p>
         
    
         <!--  --------------------------- end :  page no. [5]  --------------------------- -->

  
         
      </div>
      <p>&nbsp;</p>
   </body>
</html>