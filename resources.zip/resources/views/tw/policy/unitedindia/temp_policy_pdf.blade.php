<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <style type="text/css">
        body{
         background: white;
         margin:  0px;
         }
        html{
          margin:30px 40px; 
          font-size: 11px;
        }
        .cntr{ 
          text-align:center;
        } 
        table {
          border-collapse: none;
	     border-spacing: 0px;
	     
        }
       table, th, td {
   		border: 1px solid #000;
		}
        th,td,tr,td,p,div,b {
          margin:0;
          padding:0;
        }
          

      </style>
   </head>
   <body>
      <div class="container">

         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160px" height="90px"  alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
         </div>
         <div class="col-sm-12 cntr">
            <div>10/4, MITHRA TOWERS KASTURBA ROAD BANGALORE, BANGALORE, KARNATAKA BANGALORE - 560001 KARNATAKA</div>
            <div>PH: (080) 22210847 FAX: EMAIL:</div>
            <div>MOTORCYCLE / SCOOTER PACKAGE POLICY</div>
            <div>POLICY NO.: {{ $usr_data["policy_number"] }}</div>
            <div>VEHICLE NO.: {{ $usr_data["vehicle_number"] }}</div>
            <div>&nbsp;</div>
            <div>PERIOD OF INSURANCE</div>
            <div>From 00:00 Hrs on {{ $usr_data["policy_start_date"] }}</div>
            <div>To Midnight on {{ $usr_data["policy_end_date"] }}</div>
            <div>&nbsp;</div>
            <div>Insured</div>
            <div><h3>{{ $usr_data["customer_name"] }}</h3></div>
            <div>{{ $usr_data["customer_addr"] }}, {{ $usr_data["customer_city"] }} - {{ $usr_data["customer_pin"] }}, {{ $usr_data["customer_state"] }}</div>
            <div>CONTACT NUMBER : {{ $usr_data["customer_phone"] }} (M)</div>
            <div>&nbsp;</div>
            <table align="center">
               <tr>
                  <td>Agent Name</td>
                  <td>: TOYOTA TSUSHO INSURANCE BROKER INDIA PVT LTD.</td>
               </tr>
               <tr>
                  <td>Agent Code</td>
                  <td>: BRC0000702</td>
               </tr>
               <tr>
                  <td>Mobile/Landline Number/Email</td>
                  <td>: +91 7899-000-333</td>
               </tr>
            </table>
            
           
            <div style="position: absolute;bottom: 0px; left: 10px;">
             <hr>
            REGD. & HEAD OFFICE, 24, WHITES ROAD, CHENNAI - 600014 Website: http://www.uiic.co.in, Email - info@uiic.co.in | Printed By : InstaInsure.com @ {{ $usr_data["policy_date"] }}
            </div>
</div>
         </div>

         <p style="page-break-after: always;">&nbsp;</p>
        

         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160" height="90px"  alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
            <div>CERTIFICATE OF INSURANCE</div>
            <div>MOTORCYCLE / SCOOTER - (FORM 51 OF CENTRAL MOTOR VEHICLE RULES 1989)</div>
         </div>

         <div class="container">
            <table width="100%">
               <tr>
                  <td colspan="2">Policy No.</td>
                  <td colspan="3" >{{ $usr_data["policy_number"] }}</td>
                  <td colspan="2">Certificate Number.</td>
                  <td colspan="3"></td>
               </tr>
               <tr>
                  <td colspan="2">Customer Id</td>
                  <td colspan="3" >{{ $usr_data["policy_number"] }}</td>
                  <td colspan="2">Issuing Office Address</td>
                  <td colspan="1">Code</td>
                  <td colspan="2">072300</td>
               </tr>
               <tr>
                  <td colspan="2">Name of the Insured</td>
                  <td colspan="3" >{{ $usr_data["customer_name"] }}</td>
                  <td colspan="5">10/4, MITHRA TOWERS KASTURBA ROAD BANGALORE, BANGALORE, KARNATAKA 560001 BANGALORE KARNATAKA.</td>
               </tr>
               <tr>
                  <td colspan="2">Address of the Insured</td>
                  <td colspan="3">{{ $usr_data["customer_addr"] }},<br>{{ $usr_data["customer_city"] }} - {{ $usr_data["customer_pin"] }}, {{ $usr_data["customer_state"] }}</td>
                  <td colspan="2">Telephone</td>
                  <td colspan="3">--</td>
               </tr>
               <tr>
                  <td colspan="2">Business/Occupation</td>
                  <td colspan="3"></td>
                  <td colspan="2">Mobile</td>
                  <td colspan="3">{{ $usr_data["customer_phone"] }}</td>
               </tr>
               <tr>
                  <td colspan="5">Effective date of commencement of Insurance for the purpose of Act from 00:00 Hrs on {{ $usr_data["policy_start_date"] }}</td>
                  <td colspan="5">Insured's Declared Value   {{ $usr_data["idv_value"] }}</td>
               </tr>
               <tr>
                  <td colspan="10">Date of Expiry of the Insurance Midnight on {{ $usr_data["policy_end_date"] }}</td>
               </tr>
               <tr>
                  <td colspan="10">Particulars of Vehicle Insured</td>
               </tr>
               <tr>
                  <td colspan="2">Registration No.</td>
                  <td colspan="1">Obsolete Vehicle</td>
                  <td colspan="1">Engine No.</td>
                  <td colspan="1">Chassis No.</td>
                  <td colspan="1">Make/ Model</td>
                  <td colspan="1">Year of Mfg/Reg Date</td>
                  <td colspan="1">Type of Body</td>
                  <td colspan="1">Cubic Capacity</td>
                  <td colspan="1">Seating including driver</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data["vehicle_number"] }}</td>
                  <td colspan="1">NA</td>
                  <td colspan="1">{{ $usr_data["engine_number"] }}</td>
                  <td colspan="1">{{ $usr_data["chasis_number"] }}</td>
                  <td colspan="1">{{ $usr_data["make_name"] }} / {{ $usr_data["model_name"] }}</td>
                  <td colspan="1">{{ $usr_data["yom"] }} / {{ $usr_data["tw_reg_date"]  }}</td>
                  <td colspan="1">{{  $usr_data["body_type"]  }}</td>
                  <td colspan="1">{{ $usr_data["cc_value"] }}</td>
                  <td colspan="1">2</td>
               </tr>
               <tr>
                  <td colspan="3">Registration Authority</td>
                  <td colspan="3">Geographical Area</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="3">{{ $usr_data["rto_loc"] }}</td>
                  <td colspan="3">INDIA</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="6">Amount in words: {{ $usr_data["premium_words"] }}</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="10"><b>Persons or classes of persons entitled to drive</b><br>Any person including Insured provided that a person holds an effective driving licence at the time of accident and is not disqualified from holding or obtaining such a licence. Provided also that the person holding an effective Learner's Licence may also drive the vehicle and such a person satisfies the requirements of Rule 3 of Central Motor Vehicle Rule, 1989.</td>
               </tr>
               <tr>
                  <td colspan="5" rowspan="11">
                     <b>Limitations as to use</b><br>The policy covers use of the vehicle for any purpose other than<br>
                        1. Hire or Reward<br>
                        2. Carriage Goods (other than samples or personal luggage) <br>
                        3. Organized Racing<br>
                        4. Pace Making <br>
                        5. Speed Testing and Reliability Trials<br>
                        6. Use in connection with Motor Trade<br>
                  </td>
                  <td colspan="3">Premium:</td>
                  <td colspan="2">{{ $usr_data["gross_final_premium"] }}</td>
               </tr>
               <tr>
                  <td colspan="3">Goods & Services Tax:</td>
                  <td colspan="2">{{ $usr_data["gst_value"] }}</td>
               </tr>
               <tr>
                  <td colspan="3">Swachh Bharat Cess:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Krishi Kalyan Cess:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Stamp Duty:</td>
                  <td colspan="2">--</td>
               </tr>
               <tr>
                  <td colspan="3">Total(Rounded Off):</td>
                  <td colspan="2">{{ $usr_data["final_premium"] }}</td>
               </tr>
               <tr>
                  <td colspan="3">Receipt Number:</td>
                  <td colspan="2">{{ $usr_data["pg_ref_number"] }}</td>
               </tr>
               <tr>
                  <td colspan="3">Receipt Date:</td>
                  <td colspan="2">{{ $usr_data["policy_date"] }}</td>
               </tr>
               <tr>
                  <td colspan="3">DebitNote Number:</td>
                  <td colspan="2"></td>
               </tr>
               <tr>
                  <td colspan="3">Document Date:</td>
                  <td colspan="2"></td>
               </tr>
               <tr>
                  <td colspan="3">STax Regn No.:</td>
                  <td colspan="2">AAACU5552CST001</td>
               </tr>
               <tr>
                  <td colspan="5" width="50%"><b>Limits of Liability</b><br>
                     Under Section II-I (i) Death or bodily injury in respect of any one accident; As per Motor Vehicles Act 1988
                     <br>Under Section II-I (ii) Damage to third party property in respect of any one claim or series of claims arising out of one event:   100000/-
                  </td>
                  <td colspan="5">Agency/Broker Code: (BRC0000702)<br>
                     Toyota. <br> Direct Business:<br>
                     Developement Officer Code:<br>
                  </td>
               </tr>
            </table>
         </div>

         <div class="col-sm-12 cntr">
            <table width="100%">
               <tr>
                  <td width="80%">&nbsp;</td>
                  <td>For and On behalf of United India Insurance Co. Ltd.</td>
               </tr>
               <tr>
                  <td><b>Subject to IMT Endorsement No.s, terms and conditions printed herein / attached hereto IMT.22</b><br>
                     I/We hereby certify that the policy to which the certificate relates as well as the certificate of insurance are issued in accordance with provisions of Chapter X & XI of M.V Act, 1988.
                     <br><b>Date of Issue:</b> {{ $usr_data["policy_date"] }}<br>
                     <b>Underwritten By - Lekha Kilikar, Sr. Divisional Manager (072300)</b>
                  </td>
                  <td><img src="{{public_path('image/digital')}}/uiic_auth_sign.png"></td>
               </tr>
               <tr>
                  <td>&nbsp;</td>
                  <td>Duly Constituted Attorney</td>
               </tr>
            </table>
         </div>

         
         <p style="page-break-after: always;">&nbsp;</p>
         <div class="col-sm-12v cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png" width="160px" height="90px" alt="Insurer Logo">
            <h3>UNITED INDIA INSURANCE COMPANY LIMITED</h3>
            <div>MOTORCYCLE / SCOOTER -SCHEDULE</div>
         </div>
         <div class="col-sm-12 cntr">
            <table width="100%">
               <tr>
                  <td colspan="2">Policy No.</td>
                  <td colspan="3">{{ $usr_data["policy_number"] }}</td>
                  <td colspan="2">Previous Policy No.</td>
                  <td colspan="3">{{ $usr_data["previous_policy_no"] }}</td>
               </tr>
               <tr>
                  <td colspan="2" rowspan="5">Insured Details</td>
                  <td colspan="3">Customer Id</td>
                  <td colspan="5"></td>
               </tr>
               <tr>
                  <td colspan="5">Name</td>
                  <td colspan="5">{{ $usr_data["customer_name"] }}</td>
               </tr>
               <tr>
                  <td colspan="5">Tel(O)</td>
                  <td colspan="2">Tel(R)</td>
                  <td colspan="3">Fax:</td>
               </tr>
               <tr>
                  <td colspan="5">Email: {{ $usr_data["customer_email"] }}</td>
                  <td colspan="5">Mobile: {{ $usr_data["customer_phone"] }}</td>
               </tr>
               <tr>
                  <td colspan="5">Business / Occupation</td>
                  <td colspan="5"></td>
               </tr>
               <tr>
                  <td colspan="2">Period of Insurance</td>
                  <td colspan="1">From</td>
                  <td colspan="3">00:00 Hrs of {{ $usr_data["policy_start_date"]}}</td>
                  <td colspan="1">To</td>
                  <td colspan="3">Midnight of {{ $usr_data["policy_end_date"] }}</td>
               </tr>
               <tr>
                  <td colspan="2">Co-Insurance</td>
                  <td colspan="1">Type</td>
                  <td colspan="7"></td>
               </tr>
               <tr>
                  <td colspan="10"><b>Particulars of Vehicle Insured</b></td>
               </tr>
               <tr>
                  <td colspan="2">Registration No.</td>
                  <td colspan="1">Obsolete Vehicle</td>
                  <td colspan="1">Engine No.</td>
                  <td colspan="1">Chassis No.</td>
                  <td colspan="1">Make/ Model</td>
                  <td colspan="1">Year of Mfg / Reg Date</td>
                  <td colspan="1">Type of Body</td>
                  <td colspan="1">Cubic Capacity</td>
                  <td colspan="1">Seating including driver</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data["vehicle_number"] }}</td>
                  <td colspan="1">No</td>
                  <td colspan="1">{{ $usr_data["engine_number"] }}</td>
                  <td colspan="1">{{ $usr_data["chasis_number"] }}</td>
                  <td colspan="1">{{ $usr_data["make_name"] }} / {{ $usr_data["model_name"] }}</td>
                  <td colspan="1">{{ $usr_data["yom"] }} / {{ $usr_data["tw_reg_date"]  }}</td>
                  <td colspan="1"></td>
                  <td colspan="1">{{ $usr_data["cc_value"] }}</td>
                  <td colspan="1">2</td>
               </tr>
               <tr>
                  <td colspan="10"><b>Insured's Declared Value</b></td>
               </tr>
               <tr>
                  <td colspan="2">For Vehicle (R)</td>
                  <td colspan="1">For Side Car (R)</td>
                  <td colspan="2">Non Electrical Accessories (R)</td>
                  <td colspan="2">Electrical/Electronic Accessories (R)</td>
                  <td colspan="1">CNG Unit (R)</td>
                  <td colspan="1">LPG Unit (R)</td>
                  <td colspan="1">Total Value (R)</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data["idv_value"] }}</td>
                  <td colspan="1">-</td>
                  <td colspan="2">-</td>
                  <td colspan="2">-</td>
                  <td colspan="1">-</td>
                  <td colspan="1">-</td>
                  <td colspan="1">{{ $usr_data["idv_value"] }}</td>
               </tr>
               <tr>
                  <td colspan="2">Registration Authority</td>
                  <td colspan="2">Auto Association Membership No.</td>
                  <td colspan="2">Geographical Area</td>
                  <td colspan="4">Extension</td>
               </tr>
               <tr>
                  <td colspan="2">{{ $usr_data["rto_loc"] }}</td>
                  <td colspan="2"></td>
                  <td colspan="2">INDIA</td>
                  <td colspan="4"></td>
               </tr>
               <tr>
                  <td colspan="10">Two wheeler shall be deemed to include a Side Car attached to it.</td>
               </tr>
               <tr>
                  <td colspan="10"><b>Persons or classes of persons entitled to drive</b><br>Any person including Insured provided that a person holds an effective driving licence at the time of accident and is not disqualified from holding or obtaining such a licence. Provided also that the person holding an effective Learner's Licence may also drive the vehicle and such a person satisfies the requirements of Rule 3 of Central Motor Vehicle Rule, 1989.</td>
               </tr>
               <tr>
                  <td colspan="10"><b>Limitations as to use</b><br>
                     The policy covers use of the Vehicle for any purpose other than: a) Hire or Reward
                     b) Carriage Goods (other than samples or personal luggage)
                     c) Organized Racing
                     d) Pace Making
                     e) Speed Testing and Reliability Trials
                  </td>
               </tr>
               <tr>
                  <td colspan="10"><b>Limits of Liability</b> As narrated in the Certificate of Insurance attached herewith.<br>
                     EXCLUSIONS :<br>
                     1) Any accidental loss or damage or Liability / caused or sustained or incurrred outside the geographical area.<br>
                     2) Any claim arising out of any contractual liability.<br>
                     3) Any accidental loss or damage to any property whatsoever or any loss or any expense whatsoever resulting or arising there from or any consequential loss.<br>
                     4) Any liability of whatsoever nature directly or indirectly caused by or constituted to or by or arising out of ionizing radiations or contamination by radioactivity from any nuclear fuel. For the purpose of this exception, combustion shall include any self-sustaining process of nuclear fission.<br>
                     5) Any accidental loss or damage or liability directly or indirectly caused by or contributed to, by or arising from nuclear weapons material.<br>
                     6) Any accidental loss, damage or liability directly or indirectly or proximatley or remotely occasioned by contributed to, by or traceable to or arising out of or in connection with war, invasion, act of foreign enemies, hostilities or warlike operations (whether before or after declaration of war), civil war, mutiny, rebellion, military or usurped power, or by any direct or indirect consequence of any of the said occurrences or may consequence thereof and in default of such proof, the Company shall not be liable to make any payment in respect of such a claim.
                  </td>
               </tr>
            </table>
         </div>
         <div class="col-sm-12">
            Underwritten by: United India Insurance Co Ltd.<br>
            <b>This policy is subject to terms and conditions and IMT Endorsement Nos. printed herein / attached hereto IMT.22</b>
         </div>
         <div class="col-sm-12">
            <table width="100%">
               <tr>
                  <td width="30%">Imposed Excess</td>
                  <td width="30%">(R) 0</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Voluntary Excess</td>
                  <td>(R) 0</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Compulsory Excess</td>
                  <td>(R) 100</td>
                  <td></td>
               </tr>
            </table>
         </div>
         <p>&nbsp;</p>
         <hr>
         <p style="page-break-after: always;">&nbsp;</p>
         <div class="col-sm-12 cntr">
            <img src="{{public_path('image/logos/')}}/uiicgi_logo.png"  width="160px" height="90px"   alt="Insurer Logo">
         </div>
         <div class="col-sm-12">
            <table width="100%">
               <tr>
                  <td colspan="4">SCHEDULE OF PREMIUM (IN  )</td>
               </tr>
               <tr>
                  <td colspan="2" width="50%">OWN DAMAGE</td>
                  <td colspan="2" width="50%">LIABILITY</td>
               </tr>
				<tr>
					<td width="45%">
								Basic premium on Vehicle and Accessories<br>
								A. Basic - OD<br>
								<br>
			@if($usr_data["zero_dept_value"] )						Add:<br>
								Addon - Zero Depriciation<br>  @endif
								<br>
								Less:<br>
								OD Discount<br>
								No Claim Bonus  - {{ $usr_data["ncb_rate"] }}%<br>
								<br>
								<br>
								Gross Total OD (A)
				</td>
				<td width="5%">
							<br>
							{{ $usr_data["od_value"] }} <br>
							<br>
			@if($usr_data["zero_dept_value"] )				<br>
							 {{ $usr_data["zero_dept_value"] }}<br>  @endif
							<br>
							<br>
							{{ $usr_data["od_disc_value"] }}<br>
								{{ $usr_data["ncb_value"] }} <br>
								<br>
								<br>
								{{ $usr_data["gross_od_value"] }} 
				</td>
				<td width="45%">
				<br>
				Basic TP <br>
				<br>
			<!--  Add:  -->	<br>
			@if($usr_data["paod_value"] != 0)	Compulsory PA for Owner Driver @endif   <br> 
			@if($usr_data["paupass_value"] != 0)		PA for Unnamed Persons (INR 1,00,000 x 2 )<br> @endif
				<br><br>
				Gross TP (B)<br>
				<br>
				Gross OD(A) + TP(B)
				</td>
				<td width="5%">
				<br>
						{{ $usr_data["tp_value"] }}  <br>
				<br>
				<br>
			@if($usr_data["paod_value"] != 0) 	{{ $usr_data["paod_value"] }}    @endif<br>
			@if($usr_data["paupass_value"] != 0)	{{ $usr_data["paupass_value"] }}<br> @endif
				<br><br>
				{{ $usr_data["gross_tp_value"] }}<br>
				<br>
				{{ $usr_data["gross_final_premium"] }}
				</td>
			</tr>
			</table>
         </div>
         <div class="col-sm-12">
            <b>TERMS AND CONDITIONS</b><br>
            AS PER THE INDIAN MOTOR TARIFF. PERSONA COPY OF THE SAME IS AVAILABLE FREE OF COST ON REQUEST. FURTHER, THE INDIAN MOTOR TARIFF IS ALSO AVAILABLE AND DISPLAYED AT ALL UNITED INDIA INSURANCE COMPANY OFFICES AND ON UIIC WEBSITE : www.uiic.co.in
            DISCLAIMER : THE POLICY STANDS CANCELLED OR VOID IN THE EVENT OF CHEQUE DISHONOR. THE COMPANY MAY CANCEL THE POLICY BY SENDING 7 DAYS NOTICE IN CASE OF ANY FRAUD OR MISREPRESENTATION, NON-DISCLOSURE OF MATERIAL FACT OR NON-COOPERATION OF THE INSURED.<br>
            <b>IMPORTANT NOTICE</b><br>
            THE INSURED IS NOT INDEMNIFIED IF THE VEHICLE IS USED OR DRIVEN OTHERWISE THAN IN ACCORDANCE WITH THIS SCHEDULE. ANY PAYMENT MADE BY THE COMPANY BY REASON OF WIDER TERMS APPEARING IN THE CERTIFICATE IN ORDER TO COMPLY WITH THE MOTOR VEHICLES ACT, 1988 IS RECOVERABLE FROM THE INSURED. SEE THE CLAUSE HEADED "AVOIDANCE OF CERTAIN TERMS AND RIGHT OF RECOVERY". FOR LEGAL INTERPRETATION, ENGLISH VERSION WILL HOLD GOOD.
         </div>
         <p>&nbsp;</p>
         <div class="col-sm-12">
            <table width="100%">
               <tr>
                  <td>Premium:</td>
                  <td>  {{ $usr_data["gross_final_premium"] }}</td>
                  <td>Receipt Number :</td>
                  <td>{{ $usr_data["pg_ref_number"] }}</td>
                  <td>Agency/Broker Code:</td>
                  <td>BRC0000702</td>
               </tr>
               <tr>
                  <td>Goods & Services Tax
                  <td>    {{ $usr_data["gst_value"] }}</td>
                  <td>Receipt Date :</td>
                  <td>{{ $usr_data["policy_date"] }}</td>
                  <td>Direct Business:</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Stamp Duty:</td>
                  <td>   0</td>
                  <td>DebitNote Number :</td>
                  <td></td>
                  <td>Developement Officer Code:</td>
                  <td></td>
               </tr>
               <tr>
                  <td>Total (Rounded Off):</td>
                  <td>  {{ $usr_data["final_premium"] }}</td>
                  <td>Document Date :</td>
                  <td></td>
                  <td>Cover Note No.:</td>
                  <td></td>
               </tr>
               <tr>
                  <td colspan="2"></td>
                  <td>STax Regn No:</td>
                  <td>AAACU5552CST001</td>
                  <td>Cover Note Date:</td>
                  <td></td>
               </tr>
            </table>
         </div>
         <div class="col-sm-12">
            <b>Anti Money Laundering Clause:-</b>In the event of a claim under the policy exceeding   1 lakh or a claim for refund of premium exceeding   1 lakh, the insured will comply with the provisions of AML policy of the company. The AML policy is available in all our operating offices as well as Company's web site.
            <br><br>
            Date of Proposal and Declaration: {{ $usr_data["policy_date"] }} <br><br><br>
            IN WITNESS WHEREOF, this policy has been signed at on {{ $usr_data["policy_date"] }}.
            For and On behalf of<br>
            United India Insurance Co. Ltd.<br><br>
            <img src="{{public_path('image/digital')}}/uiic_auth_sign.png">
            <br><br>
            Duly Constituted Attorney:<br>
            <b>Underwritten By - Lekha Kilikar, Sr. Divisional Manager (072300)</b>
         </div>
         <p>&nbsp;</p>
         
         <p style="page-break-after: always;">&nbsp;</p>
         <div class="col-sm-12">
            <b>MOTORCYCLE / SCOOTER - PACKAGE POLICY</b><br>
            Whereas the Insured by a proposal and declaration dated as stated in the Schedule which shall be the basis of this contract and is deemed to be incorporated herein has applied to the company for insurance hereinafter contained and has paid the premium mentioned in the schedule as consideration for such insurance in respect of accident loss or damage occurring during the Period of Insurance. (The term two wheeler referred to in this Tariff will include motor cycle/scooter / auto cycle or any other motorised two wheeled vehicle mentioned in the Schedule.) 
            <b>NOW THIS POLICY WITNESSETH:</b><br>
            That subject to the Terms Exceptions and Conditions contained herein or endorsed or otherwise expressed hereon.<br><br>
            <b>SECTION - I : LOSS OF OR DAMAGE TO THE VEHICLE INSURED</b><br>
            The Company will indemnify the insured against loss or damage to the vehicle insured hereunder and/or its accessories whilst thereon<br>
            a) by fire explosion self ignition or lightning;<br>
            b) by burglary housebreaking or theft;<br>
            c) by riot and strike;<br>
            d) by earthquake (fire and shock damage);<br>
            e) by flood typhoon hurricane storm tempest inundation cyclone hailstorm frost;<br>
            f) by accidental external means; <br>
            g) by malicious act;<br>
            h) by terrorist activity;<br>
            i) whilst in transit by road rail inland- waterway lift elevator or air;<br>
            j) by landslide rockslide<br>
            <br>
            Subject to a deduction for depreciation at the rates mentioned below in respect of parts replaced :<br> 
            1. For all rubber/ nylon/ plastic parts, tyres and tubes, batteries 50%<br>
            2. For fibre glass components 30%<br>
            3. For all parts made of glass Nil<br>
            4. Rate of depreciation for all other parts including wooden parts will be as per the following schedule :<br>
            <table width="100%">
               <tr>
                  <td>Age of Vehicle</td>
                  <td>% of Depreciation</td>
                  <td>Age of Vehicle</td>
                  <td>% of Depreciation</td>
               </tr>
               <tr>
                  <td>Not exceeding 6 months</td>
                  <td>Nil</td>
                  <td>Exceeding 3 years but not exceeding 4 years</td>
                  <td>25%</td>
               </tr>
               <tr>
                  <td>Exceeding 6 months but not exceeding 1 year</td>
                  <td>5%</td>
                  <td>Exceeding 4 years but not exceeding 5 years</td>
                  <td>35%</td>
               </tr>
               <tr>
                  <td>Exceeding 1 year but not exceeding 2 years</td>
                  <td>10%</td>
                  <td>Exceeding 5 year but not exceeding 10 years</td>
                  <td>40%</td>
               </tr>
               <tr>
                  <td>Exceeding 2 years but not exceeding 3 years</td>
                  <td>15%</td>
                  <td>Exceeding 10 years</td>
                  <td>50%</td>
               </tr>
            </table>
            5.Rate of Depreciation for Painting: In the case of painting, the depreciation rate of 50% shall be applied only on the material cost of total painting charges. In case of consolidated bill for painting charges, the material component shall be considered as 25% of total painting charges for the purpose of applying the depreciation.<br>
            <br>
            The Company shall not be liable to make any payment in respect of :<br>
            (a) consequential loss, depreciation, wear and tear, mechanical or electrical breakdown failures or breakages.<br>
            (b) damage to tyres and Tubes unless the vehicle insured is damaged at the same time in which case the liability of the company shall be limited to 50% of the cost of replacement.<br>
            (c) loss of or damage to accessories by burglary housebreaking or theft unless the vehicle is stolen at the same time<br>
            <br>and<br><br>
            (d) any accidental loss or damage suffered whilst the insured or any person driving the vehicle with the knowledge and consent of the insured is under the influence of intoxicating liquor or drugs.<br><br>
            In the event of the vehicle being disabled by reason of loss or damage covered under this Policy the Company will bear the reasonable cost of protection and removal to the nearest repairer and of redelivery to the Insured but not exceeding in all Rs.300/- in respect of any one accident.<br><br>
            The insured may authorise the repair of the vehicle necessitated by damage for which the Company may be liable under this Policy provided that:-<br> 
            (a) the estimated cost of such repair including replacements, if any, does not exceed Rs.150/-<br>
            (b) the Company is furnished forthwith a detailed estimate of the cost of repairs and<br>
            the insured shall give the Company every assistance to see that such repair is necessary and the charges are reasonable. <br>
         </div>
         <!--  --------------------------- end :  page no. [5]  --------------------------- -->
         <p>&nbsp;</p>
         <hr>
         <p style="page-break-after: always;">&nbsp;</p>
         <!--  --------------------------- start :  page no. [6]  --------------------------- -->
         <div class="col-sm-12">
            <b>SUM INSURED - INSURED'S DECLARED VALUE (IDV)</b><br>
            The Insured's Declared Value (IDV) of the vehicle will be deemed to be the 'SUM INSURED' for the purpose of this policy which is fixed at the commencement of each policy period for the insured vehicle.<br><br>
            The IDV of the vehicle (and side car/accessories, if any, fitted to the vehicle) is to be fixed on the basis of the manufacturer's listed selling price of the brand and model as the insured vehicle at the commencement of insurance/renewal and adjusted for depreciation (as per schedule below).<br><br>
            The schedule of age-wise depreciation as shown below is applicable for the purpose of Total Loss/Constructive Total Loss (TL/CTL) claims only.<br><br>
            <b>THE SCHEDULE OF DEPRECIATION FOR FIXING IDV OF THE VEHICLE</b><br>
            <table width="100%">
               <tr>
                  <td width="50%">AGE OF VEHICLE</td>
                  <td>% OF DEPRECIATION FOR FIXING IDV</td>
               </tr>
               <tr>
                  <td width="50%">Not exceeding 6 months</td>
                  <td>5%</td>
               </tr>
               <tr>
                  <td width="50%">Exceeding 6 months but not exceeding 1 year</td>
                  <td>15%</td>
               </tr>
               <tr>
                  <td width="50%">Exceeding 1 year but not exceeding 2 years</td>
                  <td>20%</td>
               </tr>
               <tr>
                  <td width="50%">Exceeding 2 years but not exceeding 3 years</td>
                  <td>30%</td>
               </tr>
               <tr>
                  <td width="50%">Exceeding 3 years but not exceeding 4 years</td>
                  <td>40%</td>
               </tr>
               <tr>
                  <td width="50%">Exceeding 4 years but not exceeding 5 years</td>
                  <td>50%</td>
               </tr>
            </table>
            IDV of vehicles beyond 5 years of age and of obsolete models of the vehicles ( i.e. models which the manufacturers have discontinued to manufacture) is to be determined on the basis of an understanding between the insurer and the insured.<br><br>
            IDV shall be treated as the Market Value throughout the policy period without any further depreciation for the purpose of Total Loss (TL) / Constructive Total Loss (CTL) claims.<br><br>
            The insured vehicle shall be treated as CTL if the aggregate cost of retrieval and / or repair of the vehicle, subject to terms and conditions of the policy, exceeds 75% of the IDV of the vehicle.<br><br>
            <b>SECTION II - LIABILITY TO THIRD PARTIES</b><br>
            1. Subject to the limits of liability as laid down in the Schedule hereto the Company will indemnify the insured in the event of an accident caused by or arising out of the use of the insured vehicle against all sums which the insured shall become legally liable to pay in respect of :-<br>
            (i) death of or bodily injury to any person including occupants carried in the insured vehicle ( provided such occupants are not carried for hire or reward) but except so far as it is necessary to meet the requirements of Motor Vehicles Act, the Company shall not be liable where such death or injury arises out of and in the course of the employment of such person by the insured,<br>
            (ii) damage to property other than property belonging to the insured or held in trust or in the custody or control of the insured. Provided always that the Company shall not be liable in respect of death injury or damage caused or arising beyond the limits of any carriageway or thoroughfare in connection with the bringing of the load to the vehicle for loading thereon or the taking away of the load from the vehicle after unloading there from.<br>
            2. The Company will pay all costs and expenses incurred with its written consent.<br>
            3. In terms of and subject to the limitations of the indemnity granted by this section to the insured, the Company will indemnify any driver who is driving the vehicle on the insured's order or with insured's permission provided that such driver shall as though he/she was the insured observe fulfill and be subject to the terms exceptions and conditions of this Policy in so far as they apply.<br>
            4. In the event of the death of any person entitled to indemnity under this policy the Company will in respect of the liability incurred by such person indemnify his/her personal representative in terms of and subject to the limitations of this Policy provided that such personal representative shall as though such representative was the insured observe fulfill and be subject to the terms exceptions and conditions of this Policy in so far as they apply.<br>
            5. The Company may at its own option (a) arrange for representation at any Inquest or Fatal Inquiry in respect of any death which may be the subject of indemnity under this Policy and (b)undertake the defence of proceedings in any Court of Law in respect of any act or alleged offence causing or relating to any event which may be the subject of indemnity under this Policy.<br><br>
            <b>AVOIDANCE OF CERTAIN TERMS AND RIGHT OF RECOVERY</b><br>
            Nothing in this Policy or any endorsement hereon shall affect the right of any person indemnified by this policy or any other person to recover an amount under or by virtue of the Provisions of the Motor Vehicles Act. But the Insured shall repay to the Company all sums paid by the Company which the Company would not have been liable to pay but for the said provision.<br><br>
            <b>APPLICATION OF LIMITS OF INDEMNITY</b><br>
            In the event of any accident involving indemnity to more than one person any limitation by the terms of this Policy and/or of any Endorsement thereon of the amount of any indemnity shall apply to the aggregate amount of indemnity to all persons indemnified and such indemnity shall apply in priority to the insured<br>
         </div>
         <!--  --------------------------- end :  page no. [6]  --------------------------- -->    
         <p>&nbsp;</p>
         <hr>
         <p style="page-break-after: always;">&nbsp;</p>
         <!--  --------------------------- start :  page no. [7]  --------------------------- -->
         <div class="col-sm-12">
            <b>SECTION III - PERSONAL ACCIDENT COVER FOR OWNER-DRIVER</b><br>
            <table width="100%" border="0">
               <tr>
                  <td>Name Of the Nominee</td>
                  <td>Age</td>
                  <td>Name of the Appointee(If Nominee is Minor)</td>
                  <td>Relationship</td>
               </tr>
               <tr>
                  <td>{{ $usr_data["nomi_name"] }}</td>
                  <td>{{ $usr_data["nomi_age"] }}</td>
                  <td>NA</td>
                  <td>{{ $usr_data["nomi_rel"] }}</td>
               </tr>
            </table>
            Subject otherwise to the terms exceptions conditions and limitations of this Policy, the Company undertakes to pay compensation as per the following scale for bodily injury/ death sustained by the owner-driver of the vehicle indirect connection with the vehicle insured whilst mounting into/dismounting from or traveling in the insured vehicle as a co-driver, caused by violent accidental external and visible means which independent of any other cause shall within six calendar months of such injury result in:<br>
            <table width="100%">
               <tr>
                  <td>Nature of injury</td>
                  <td>Scale of compensation</td>
                  <td>Nature of injury</td>
                  <td>Scale of compensation</td>
               </tr>
               <tr>
                  <td>(i) Death</td>
                  <td>100%</td>
                  <td>(iii) Loss of one limb or sight of one eye</td>
                  <td>50%</td>
               </tr>
               <tr>
                  <td>(ii) Loss of two limbs or sight of two eyes or one limb and sight of one eye</td>
                  <td>100%</td>
                  <td>(iv) Permanent total disablement from injuries other than named above</td>
                  <td>100%</td>
               </tr>
            </table>
            <br>Provided always that<br>
            A) the compensation shall be payable under only one of the items (i) to (iv) above in respect of the owner-driver arising out of any one occurrence and the total liability of the insurer shall not in the aggregate exceed the sum of Rs. 1 lakh during any one period of insurance.<br>
            B) no compensation shall be payable in respect of death or bodily injury directly or indirectly wholly or in part arising or resulting from or traceable to (a) intentional self injury suicide or attempted suicide physical defect or infirmity or (b) an accident happening whilst such person is under the influence of intoxicating liquor or drugs.<br>
            C) Such compensation shall be payable directly to the insured or to his/her legal representatives whose receipt shall be the full discharge in respect of the injury to the insured.<br><br>
            <b><u>This cover is subject to</u></b><br>
            (a) the owner-driver is the registered owner of the vehicle insured herein.<br>
            (b) the owner-driver is the insured named in this policy.<br>
            (c) the owner-driver holds an effective driving licence, in accordance with the provisions of Rule 3 of the Central Motor Vehicles Rules, 1989, at the time of the accident<br><br>
            <b>GENERAL EXCEPTIONS </b>(Applicable to all sections of the Policy)<br>
            The Company shall not be liable in respect of :<br>
            1. any accidental loss damage and/or liability caused sustained or incurred outside the Geographical Area.<br>
            2. any claim arising out of any contractual liability.<br>
            3. any accidental loss damage and/or liability caused sustained or incurred whilst the vehicle insured herein is<br>
            (a) being used otherwise than in accordance with the 'Limitations as to Use' <br><br> OR <br><br>
            (b) being driven by or is for the purpose of being driven by him/her in the charge of any person other than a Driver as stated in the Driver's clause.<br>
            4. (i) Any accident loss or damage to any property whatsoever or any loss or expense whatsoever resulting or arising there from or any consequential loss<br>
            (ii) any liability of whatsoever nature directly or indirectly caused by or contributed to by or arising from ionising radiations or contamination by radioactivity from any nuclear fuel or from any
            nuclear waste from the combustion of nuclear fuel. For the purposes of this exception combustion shall include any self-sustaining process of nuclear fission.<br>
            5. Any accidental loss or damage or liability directly or indirectly caused by or contributed to by or arising from nuclear weapons material<br>
            6. Any accidental loss damage and/or liability directly or indirectly or proximately or remotely occasioned by or contributed to by or traceable to or arising out of or in connection with war, invasion, the act of foreign enemies, hostilities or warlike operations (whether before or after declaration of war), civil war, mutiny rebellion, military or usurped power or by any direct or indirect consequences of any of the said occurrences and in the event of any claim hereunder the Insured shall prove that the accidental loss damage and/or liability arose independently of and was in no way connected with or occasioned by or contributed to by or traceable to any of the said occurrences or any consequences thereof and in default of such proof the Company shall not be liable to make any payment in respect of such a claim.<br><br>
            <b>DEDUCTIBLE</b><br>
            The Company shall not be liable for each and every claim under Section -1 (loss of or damage to the vehicle insured) of this Policy in respect of the deductible stated in the schedule.<br>
         </div>
         <!--  --------------------------- end :  page no. [7]  --------------------------- -->    
         <p>&nbsp;</p>
         <hr>
         <p>&nbsp;</p>
         <!--  --------------------------- start :  page no. [8]  --------------------------- -->
         <div class="col-sm-12">
            CONDITIONS
            This Policy and the Schedule shall be read together and any word or expression to which a specific meaning has been attached in any part of this Policy or of the Schedule shall bear the same meaning wherever it may appear.<br>
            1. Notice shall be given in writing to the Company immediately upon the occurrence of any accidental loss or damage and in the event of any claim and thereafter the insured shall give all such information and assistance as the Company shall require. Every letter claim writ summons and/or process or copy thereof shall be forwarded to the Company immediately on receipt by the insured. Notice shall also be given in writing to the Company immediately the insured shall have knowledge of any impending prosecution inquest or fatal injury in respect of any occurrence which may give rise to a claim under this policy. In case of theft or other criminal act which may be the subject of a claim under this Policy the insured shall give immediate notice to the police and co-operate with the Company in securing the conviction of the offender.<br>
            2. No admission offer promise payment or indemnity shall be made or given by or on behalf of the Insured without the written consent of the Company which shall be entitled if it so desires
            to take over and conduct in the name of the Insured the defence or settlement of any claim or to prosecute in the name of the Insured for its own benefit any claim for indemnity or damages or otherwise and shall have full discretion in the conduct of any proceedings or in the settlement of any claim and the Insured shall give all such information and assistance as the Company may require.<br>
            3. The Company may at its own option repair reinstate or replace the vehicle or part thereof and/or its accessories or may pay in cash the amount of the loss or damage and the liability of the Company shall not exceed:<br>
            (a) for total loss / constructive total loss of the vehicle - the Insured's Declared Value (IDV) of the vehicle (including accessories thereon) as specified in the Schedule less the value of the wreck<br>
            (b) for partial losses, i.e. losses other than Total Loss/Constructive Total Loss of the vehicle - actual and reasonable costs of repair and/or replacement of parts lost/damaged subject to depreciation as per limits specified.<br>
            4. The Insured shall take all reasonable steps to safeguard the vehicle from loss or damage and to maintain it in efficient condition and the Company shall have at all times free and full access to examine the vehicle or any part thereof or any driver or employee of the insured. In the event of any accident or breakdown, the vehicle shall not be left unattended without proper precautions being taken to prevent further damage or loss and if the vehicle be driven before the necessary repairs are effected any extension of the damage or any further damage to the vehicle shall be entirely at the insured's own risk.<br>
            5. The Company may at any time cancel the policy on grounds of misrepresentation, fraud. non-disclosure of material fact or non- cooperation by the insured by sending seven days notice by recorded delivery to the insured at insured's last known address and in such event will return to the insured the premium paid less the pro rata portion thereof for the period the Policy has been in force or the policy may be cancelled at any time by the insured on seven days' notice by recorded delivery and provided no claim has arisen during the currency of the policy, the insured shall be entitled to a return of premium less premium at the Company's Short Period rates for the period the Policy has been in force. Return of the premium by the company will be subject to retention of the minimum premium of Rs.100/ - (or Rs.25 /- i n respect of vehicles specifically designed/modified for use by blind/handicapped/mentally challenged persons).<br>
            Where the ownership of the vehicle is transferred, the policy cannot be cancelled unless evidence that the vehicle is insured elsewhere at least for Liability Only cover is produced and original Certificate of Insurance is produced for cancellation.
            6. If at the time of occurrence of an event that gives rise to any claim under this policy there is in existence any other insurance covering the same liability, the Company shall not be liable to pay or contribute more than its ratable proportion of any compensation, cost or expense.<br>
            7. If any dispute or difference shall arise as to the quantum to be paid under this policy (liability being otherwise admitted), such difference shall independent of all other questions be referred to the decision of a sole arbitrator to be appointed in writing by the parties to the dispute or if they cannot agree upon a single arbitrator within 30 days of any party invoking Arbitration, the same shall be referred to a panel of three arbitrators comprising two arbitrators one to be appointed by each of the parties to the dispute / difference, and a third arbitrator to,
            be appointed by such two arbitrators who shall act as the presiding arbitrator and Arbitration shall be conducted under and in accordance with the provisions of the Arbitration and Conciliation Act, 1996. It is clearly agreed and understood that no difference or dispute shall be referable to Arbitration as hereinbefore provided, if the Company has disputed or not accepted liability under or in respect of this policy. It is hereby expressly stipulated and declared that it shall be condition precedent to any right of action or suit upon this policy that the award by such arbitrator/ arbitrators of the amount of the loss or damage shall be first obtained. It is also hereby further expressly agreed and declared that if the Company shall disclaim liability to the insured for any claim hereunder and such claim shall not, within twelve calendar months from the date of such disclaimer have been made the subject matter of a suit in a court of law, then the claim shall for all purposes be deemed to have been abandoned and shall not thereafter be recoverable hereunder.<br>
            8. The due observance and fulfillment of the terms, conditions and endorsements of this Policy in so far as they relate to anything to be done or complied with by the insured and the truth of the statements and answers in the said proposal shall be conditions precedent to any liability of the Company to make any payment under this Policy.<br>
            9. In the event of the death of the sole insured, this policy will not immediately lapse but will remain valid for a period of three months from the date of the death of insured or until the expiry of this policy (whichever is earlier). During the said period, legal heir(s) of the insured to whom the custody and use of the Motor Vehicle passes may apply to have this Policy transferred to the name(s) of the heir(s) or obtain a new insurance policy for the Motor Vehicle.<br>
            Where such legal heir(s) desire(s) to apply for transfer of this policy or obtain a new policy for the vehicle such heir(s) should make an application to the Company accordingly within the aforesaid period. All such applications should be accompanied by:-<br>
            a) Death Certificate in respect of the insured<br> 
            b) Proof of title to the vehicle<br>
            c) Original Policy<br>
         </div>
         <!--  --------------------------- end :  page no. [8]  --------------------------- -->    
         <p>&nbsp;</p>
         <hr>
         <p style="page-break-after: always;">&nbsp;</p>
         <!--  --------------------------- start :  page no. [9]  --------------------------- -->
         <div class="col-sm-12">
            <b>No Claim Bonus</b><br>
            The insured is entitled for a No Claim Bonus (NCB) on the Own Damage section of the policy, if no claim is made or pending during the preceding year(s), as per the following table:<br>
            <table width="100%">
               <tr>
                  <td width="50%">Period of insurance</td>
                  <td>% of NCB on OD premium</td>
               </tr>
               <tr>
                  <td width="50%">The preceding year</td>
                  <td>20%</td>
               </tr>
               <tr>
                  <td width="50%">Preceding Two consecutive years</td>
                  <td>25%</td>
               </tr>
               <tr>
                  <td width="50%">Preceding Three consecutive years</td>
                  <td>35%</td>
               </tr>
               <tr>
                  <td width="50%">Preceding Four consecutive years</td>
                  <td>45%</td>
               </tr>
               <tr>
                  <td width="50%">Preceding Five consecutive years</td>
                  <td>50%</td>
               </tr>
            </table>
            No Claim Bonus will only be allowed provided the policy is renewed within 90 days of the expiry date of the previous policy. <br>
            NB1:-InLiabilitywithFireand/orTheftOnly policiesNCBasabovewillbeapplicableonlyontheFireand/orTheftcomponentofthepremium.<br>
            2:- In Fire and / or Theft Only policies the insured is not entitled for NCB.<br><br>
            <b>IMT ENDORSEMENTS : 16,22</b><br><br>
            <b>IMT.16. Personal accident to unnamed passangers other than Insured and the paid driver and cleaner { For vehicles rated as Private cars and Motorised two wheelers (not for hire or reward) with or without side car}</b><br>
            In consideration of the payment of an additional premium it is hereby understood and agreed that the insurer undertakes to pay compensation on the scale provided below for bodily injuries hereinafter defined sustained by any passenger other than the insured and/or the paid driver attendant or cleaner and/or a person in the employ of the insured coming within the scope of the Workmens Compensation Act, 1923 and subsequent amendments of the said Act and engaged in and upon the service of the insured at the time such injury is sustained whilst mounting into, dismounting from or traveling in but not driving the insured motor car and caused by violent, accidental, external and visible means which independently of any other cause shall within three calendar months of the occurrence of such injury result in :<br>
            <table>
               <tr>
                  <td>Details of Injury</td>
                  <td>Scale of Compensation</td>
               </tr>
               <tr>
                  <td>i)Death</td>
                  <td>100%</td>
               </tr>
               <tr>
                  <td>ii) Loss of two limbs or sight of two eyes or one limb and sight of one eye</td>
                  <td>100%</td>
               </tr>
               <tr>
                  <td>iii) Loss of one limb or sight of one eye</td>
                  <td>50%</td>
               </tr>
               <tr>
                  <td>iv) Permanent Total Disablement from injuries other than named above</td>
                  <td>100%</td>
               </tr>
            </table>
            <br>
            Provided always that<br>
            (1) compensation shall be payable under only one of the items (i) to (iv) above in respect of any such person arising out of any one occurrence and total liability of the insurer shall not in the aggregate exceed the sum of Rs. during any one period of insurance in respect of any such person.<br>
            (2) no compensation shall be payable in respect of death or injury directly or indirectly wholly or in part arising or resulting from or traceable to<br>
            (a) intentional self injury suicide or attempted suicide physical defect or infirmity or<br> (b) an accident happening whilst such person is under the influence of intoxicating liquor or drugs.<br>
            (3) such compensation shall be payable only with the approval of the insured named in the policy and directly to the injured person or his/her legal representative(s) whose receipt shall be a full discharge in respect of the injury of such person.<br>
            (4) not more than 2persons/passengers are in the vehicle insured at the time of occurrence of such injury. Subject otherwise to the terms exceptions conditions and limitations of this policy.<br><br>
            <b>IMT.22. Compulsory Deductible (Applicable to Private Cars, three wheelers rated as private cars, all motorized two wheelers, taxis, private car type vehicle plying for public/private hire, private type taxi let out on private hire)</b><br><br>
            Notwithstanding anything to the contrary contained in the policy it is hereby understood and agreed that the insured shall bear under Section 1 of the policy in respect of each and every event (including event giving rise to a total loss/constructive total loss) the first 100 (or any less expenditure which may be incurred) of any expenditure for which provision has been made under this policy and/or of any expenditure by the insurer in the exercise of his discretion under Condition 3 of this policy.<br>
            If the expenditure incurred by the insurer shall include any amount for which the insured is responsible hereunder such amount shall be repaid by the insured to the insurer forthwith.<br>
            For the purpose of this Endorsement the expression "event" shall mean an event or series of events arising out of one cause in connection with the vehicle insured in respect of which indemnity is provided under this policy.<br>
            Subject otherwise to the terms conditions limitations and exceptions of this Policy.<br>
         </div>
         <!--  --------------------------- end :  page no. [9]  --------------------------- -->    
         <p>&nbsp;</p>
         <hr>
      </div>
      <p>&nbsp;</p>
   </body>
</html>