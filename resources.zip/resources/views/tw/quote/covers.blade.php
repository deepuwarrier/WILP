               <div class="col-sm-4">
                  <div class="card card-form-horizontal">
                     <div class="row accordion">
                        <div class="col-md-12">
                           <h6> Default Inclusions in your Two Wheeler Insurance Policy </h6>
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="false">
                                  @foreach($cover_list as $cover)
                                  	@if( $cover->cover_type == '1')
                                          <div class="panel panel-default">
                                             <div class="panel-heading" role="tab">
                                                <h4 class="panel-title pull-left">
                                                   <a data-toggle="collapse" data-parent="#accordion1" href="#{{$cover->cover_id}}_toggle">{{$cover->cover_name}}</a>
                                                </h4>
                                                <div class="included"> 
                                                   <input  class="filter_quote hidden" name="{{$cover->cover_id}}" id="{{$cover->cover_id}}" value="#" type="checkbox" checked disabled>
                                                   <img class="checkmark" src="{{asset('image/check.png')}}" alt="Included">
                                                </div>
                                             </div>
                                             <div id="{{$cover->cover_id}}_toggle" class="panel-collapse collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                                <div class="panel-body">{{$cover->cover_desc}}</div>
                                             </div>
                                          </div>
                                        @endif   
                                    @endforeach 
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-12" id="covers_summary_details">
                           <h6> Additional Features and Covers </h6>
                           <div class="row">
                              <div class="col-md-12 middleSectionInner1">
                                 <div class="panel-group" id="accordion2" role="tablist" aria-multiselectable="false">
                                    @foreach($cover_list as $cover)
                                  	@if( $cover->cover_type == '2')
                                          <div class="panel panel-default">
                                             <div class="panel-heading" role="tab">
                                                <h4 class="panel-title pull-left">
                                                   <a data-toggle="collapse" data-parent="#accordion2" href="#{{$cover->cover_id}}_toggle">{{ $cover->cover_name }}</a>
                                                </h4>
                                                <div align="right">
                                                   <div class="togglebutton">
                                                      <label>
                                                            <input class="filter_quote" id="addon_{{ $cover->cover_code }}" name="someSwitchOption001"   value="{{ $cover->cover_code }}" type="checkbox" />
                                                      </label>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="{{$cover->cover_id}}_toggle" class="panel-collapse collapse collapse" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="false">
                                                <div class="panel-body"> {{$cover->cover_desc}}</div>
                                             </div>
                                          </div>
                                         @endif   
                                    @endforeach   
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>