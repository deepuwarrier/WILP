<div class="card card-form-horizontal" id="car_details" style="min-height:121px">
                     <div class="content">
                        <div class="row">
                           <div class="col-xs-6 pull-right">
                              <a class="btn btn-primary btn-xs pull-right hvr-grow boldtext"  href="{{URL::to('two-wheeler-insurance')}}">Change</a>
                           </div>
                           <div class="col-xs-6 pull-left">
                              <h6 class="pull-left">Showing Results for</h6>
                           </div>
                        </div>
                        <div class="row content pull-left" id = "detail">
                           <span class="label label-default base_detail">{{ $d_preview['make_name'] }}</span>
                           <span class="label label-default base_detail">{{ $d_preview['model_name'] }}</span>
                           <span class="label label-default base_detail">{{ $d_preview['variant_name'] }}</span>
                           <span class="label label-default base_detail">{{ $d_preview['rto_code'] }}</span>
                           <span class="label label-default base_detail">{{ $d_preview['yor'] }}</span>
                        </div>
                     </div>
                  </div>
