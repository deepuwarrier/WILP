<div class="card importantinfo" id="idv">
                     <div class="col-xs-12">
                        <div class="titleinput">
                           <h6>Some Very Important Information</h6>
                        </div>
                     </div>
                      <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You will find this in your insurance policy copy or your renewal notice. Your new policy will start from the next day.">
                           <a>
                              <p>Previous Policy</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
							<select name="pre_policy_status" id="pre_policy_status" class="form-control valid" aria-invalid="false" >
                                 <option value="NEX" {{ $idv_details->get_pre_policy_status()== 'NEX' ? 'selected':''}} >Not Expired</option>
                                 <option value="E90" {{ $idv_details->get_pre_policy_status()== 'E90' ? 'selected':''}} >Expired within 90 days</option>
                                 <option value="E90P" {{ $idv_details->get_pre_policy_status()== 'E90P' ? 'selected':''}} >Expired beyond 90 days</option>
                              </select>                           
                        </div>
                     </div>
                     @if(1)
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You will find this in your insurance policy copy or your renewal notice. Your new policy will start from the next day.">
                           <a href="#">
                              <p>Policy Exp. Date</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
							 <input class="form-control" type="text" id="policy_expiry_date" name="policy_expiry_date" value="{{ $idv_details->r_pexdt()}}" data-minDate="{{ $idv_details->r_pexdt_min()}}"  data-maxDate="{{ $idv_details->r_pexdt_max()}}" data-Ovalue="{{ $idv_details->r_pexdt()}}" data-OminDate="{{ $idv_details->r_pexdt_min()}}" data-OmaxDate="{{ $idv_details->r_pexdt_max()}}" @if($idv_details->r_pexdt() == '') disabled="disabled" @endif/>                          
                        </div>
                     </div>
                     @else
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You policy will need to start on the same day or before the day you plan to register your car.">
                           <a href="#">
                              <p>Policy Start. Date</p>
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <input class="form-control" type="text" value="" id='policy_start_date' name='policy_start_date'/>
                        </div>
                     </div>
                     @endif
            
                     <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="You will find this in your insurance policy copy or your vehicle RC (Registration Certificate)">
                           <a href="#">
                              @if(1)
                                <p>Reg. Date</p>
                              @else
                                 <p> Purchase Date</p>
                               @endif
                           </a>
                        </div>
                     </div>
                     <div class="col-xs-8">
                        <div class="labelright">
                           <input class="form-control" type="text" id="car_registration_date" data-minYear="" data-maxYear="" name="car_registration_date" value="{{ $idv_details->r_twrgdt()}}" />
                        </div>
                     </div>
                     @if(1)
                       <div class="col-xs-4">
                           <div class="labelleft"  data-toggle="tooltip" data-placement="top" title="Did you get any claim settled during your current policy period?">
                              <a href="#">
                                 <p>Claims </p>
                              </a>
                           </div>
                        </div>
                        <div class="col-xs-8" id="reg_summary">
                           <div class="labelright">
                              <div class="radiobutton">
                                 <input type="radio"  name="claim_status" id="radio_3" value="Y" @if( $idv_details->r_claims()) checked @endif />
                                 <label for="radio_3">Yes</label>
                              </div>
                              <div class="radiobutton">
                                 <input type="radio" class="ajaxRequiredData" name="claim_status" id="radio_4"  value="N" @if( ! $idv_details->r_claims()) checked @endif />
                                 <label for="radio_4">No</label>
                              </div>
                           </div>
                        </div>
                     @endif                     
                     <div class="col-xs-4">
                        <div class="labelleft"  data-toggle="tooltip" data-placement="top" title="Current No Claim Bonus percent can be found in your insurance policy copy's premium calculation table">
                           @if(1)
                             <p>NCB</p>
                           @else
                              <p>NCB Transfer</p>
                           @endif                     
                        </div>
                     </div>
                     <div class="col-xs-8">
                     <form id="ncb_form_sec" >
                        <div class="labelright">

                           <div class="col-xs-3 ncblabel">
                              <span>Current: </span>
                           </div>
                           <div class="col-xs-3 ncbvalue">
                              <select name="current_ncb" id="current_ncb" class="form-control valid" aria-invalid="false" data-Ovalue="">
                                 <option value="" disabled>Choose your option</option>
                                 <option value="0" {{ $idv_details->r_crr_ncb()== '0' ? 'selected':''}}>0 %</option>
                                 <option value="20" {{ $idv_details->r_crr_ncb()== '20' ? 'selected':''}} >20 %</option>
                                 <option value="25" {{ $idv_details->r_crr_ncb() == '25' ? 'selected':''}}>25 %</option>
                                 <option value="35" {{ $idv_details->r_crr_ncb() == '35' ? 'selected':''}}>35 %</option>
                                 <option value="45" {{ $idv_details->r_crr_ncb() == '45' ? 'selected':''}}>45 %</option>
                                 <option value="50" {{ $idv_details->r_crr_ncb() == '50' ? 'selected':''}}>50 %</option>        
                              </select>
                           </div>
                           <div class="">
                              <div class="col-xs-3 ncblabel">
                                 <span>Eligible: </span>
                              </div>
                              <div class="col-xs-3 eligible">
                                 <span class="label-on-left pretext" id="eli_ncb_span">{{ $idv_details->r_eli_ncb() }}%</span>
                              </div>
                           </div>
                        </div>
                        </form>
                     </div>
                      <div class="col-xs-4">
                        <div class="labelleft" data-toggle="tooltip" data-placement="top" title="IDV (Insured Declared Value) is the current market value of your vehicle.">
                           <a href="#">
                              <p>Expected IDV</p>
                           </a>
                        </div>
                     </div>
                     
                      <div class="col-xs-8">
                        <div class="labelright">
                           <div class="xQty">
                              <input type="button" value="-" class="qtyminus" data-qtymin="{{ $idv_details->get_base_idv_min()}}" field="expected_idv">
                              <input name="expected_idv" id="expected_idv" value="{{ $idv_details->calc_idv()}}"  data-minLimit="{{ $idv_details->get_base_idv_min()}}" data-maxLimit="{{ $idv_details->get_base_idv_max()}}" type="input" step="500" class='qtyValue' >
                              <input type="button" value="+" class="qtyplus" data-qtymax="{{ $idv_details->get_base_idv_max()}}" field="expected_idv">
                           </div>
                        </div>
                    </div>  
                     
<!--                      <div class="col-xs-4"> -->
<!--                         <div class="labelleft" data-toggle="tooltip" data-placement="top" title="Insurance for 1 Year, 2 year or 3 year."> -->
<!--                               <p>Duration</p> -->
<!--                         </div> -->
<!--                      </div> -->
<!--                      <div class="col-xs-8" id="plan_duration"> -->
<!--                            <div class="labelright"> -->
<!--                               <div class="radiobutton"> -->
<!--                                  <input type="radio" class="ajaxRequiredData" name="plan_duration" id="radio_1yr" value="1" checked /> -->
<!--                                  <label for="radio_1yr">1 Year</label> -->
<!--                               </div> -->
<!--                               <div class="radiobutton"> -->
<!--                                  <input type="radio" class="ajaxRequiredData" name="plan_duration" id="radio_2yr"  value="2" disabled  /> -->
<!--                                  <label for="radio_2yr">2 Year</label> -->
<!--                               </div> -->
<!--                               <div class="radiobutton"> -->
<!--                                  <input type="radio" class="ajaxRequiredData" name="plan_duration" id="radio_3yr"  value="3" disabled  /> -->
<!--                                  <label for="radio_3yr">3 Year</label> -->
<!--                               </div> -->
<!--                            </div> -->
<!--                         </div> -->
                     <div class="col-xs-12">
                        <div class="titleinput update_footer">
                           <button type="button" class="btn btn-primary btn-xs pull-right hvr-grow boldtext" id="update_btn_idvsec" >Update Quotes</button>
                        </div>
                     </div>
                  </div>
