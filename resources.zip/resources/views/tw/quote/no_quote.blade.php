<div class="quote-box no_quotes_box hidden">
<div class="row card customcard">
  <div class="col-sm-4 logobox">
    <img src="{{asset('image/logos/')}}/[image_name]" alt="Insurer Logo" class="no_quotes_logo">
  </div>
  <div class="row col-sm-8 logoright">
     <div class="col-md-6">
        <h5 class="no_price">No Quote</h5>
        
     </div>
     <div class="col-md-6 buybutton hvr-grow">
        <form>
          <button type="button" class="btn  btn-md scrolltop" id="buy_policy" data-focus="idv">Buy Now</button>
        </form>
     </div>
     <div class="row">
        <div class="col-sm-12">
           <div class="content extrapanel">
              <span class="extrapanelitem name" style="font-weight: 500">[insurer_name]
              </span>   
           
              <a href="javascript:void(0)">
                <button style="background-color: Transparent;background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;" 
                disabled="disabled" class="material-icons iconcustom modal_details" title="Package Info">stars</button>
              </a>

               <a href="javascript:void(0)"><button style="background-color: Transparent;background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;outline:none;" disabled="disabled" class="material-icons iconcustom modal_details"  data-toggle="tooltip" data-placement="top" title="Premium Breakup">description</button></a>
           </div>
        </div>
     </div>
  </div>
</div>
</div>



