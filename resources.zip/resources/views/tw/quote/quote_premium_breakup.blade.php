<div class="modal fade" id="premiumBreakup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                     <div class="modal-dialog">
                        <div class="modal-content premium-breakup-card ">
                           <div class="modal-body premium-breakup">
                           <div class="card customcard">
                                 <div class="col-sm-4 logobox">
                                    <img src="{{ URL::asset('image/logos/')}}/{{$modal_value['insurer_id']}}.png" alt="Insurer Logo">
                                 </div>
                                    <div class="col-sm-4">
                                       <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$modal_value['premiumBreakup']['totalpremium']['basic_premium']}}</h5>
                                       <span class="label label-default extrapanelitem">IDV: {{$modal_value['idv_received']}}</span>
                                    </div>
                                    <div class="col-sm-4 buybutton" style="margin-top: 15px;">
                                       <!-- <button type="button" class="btn btn-success btn-sm">Buy Now</button> -->
                                    </div>
                                    </div>
                              <h3>Premium Breakup</h3>
                              <h4>Basic Covers</h4>
                              <ul>

                                 @foreach($modal_value['premiumBreakup']['basic'] as $data)
                                 <li>
                                    <span class="">{{$data['displayName']}}</span>
                                    <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                 </li>
                                 @endforeach
                              </ul>
                              <h4>Addon Covers</h4>
                              <ul>
                              @if(!empty($modal_value['premiumBreakup']['addon']))
                                 @foreach($modal_value['premiumBreakup']['addon'] as $data)
                                    <li>
                                       <span class="">{{$data['displayName']}}</span>
                                       <span class="value pull-right">  {{$data['basic_premium']}}</span>
                                    </li>
                                 @endforeach
                              @else
                                 <p>No addons selected</p>
                              @endif
                              </ul>
                              <h4>Discounts</h4>
                              <ul>
                              @if(!empty($modal_value['premiumBreakup']['discounts']))
                                 <li>
                                    <span class="">{{$modal_value['premiumBreakup']['discounts']['displayName']}}</span>
                                    <span class="value pull-right"> - {{$modal_value['premiumBreakup']['discounts']['basic_premium']}}</span>
                                 </li>
                              @else
                                 <li>
                                    <span class="">No Claim Bonus</span>
                                    <span class="value pull-right"> - 0</span>
                                 </li>
                              @endif
                              </ul>
                              <h4>Taxes</h4>
                              <ul>
                                 <li>
                                    <span class="">{{$modal_value['premiumBreakup']['serviceTax']['displayName']}}</span>
                                    <span class="value pull-right">  {{$modal_value['premiumBreakup']['serviceTax']['basic_premium']}}</span>
                                 </li>
                              </ul>
                              <h4>Final Premium</h4>
                              <ul>
                                 <li class="finalprm">
                                    <span class="">{{$modal_value['premiumBreakup']['totalpremium']['displayName']}}</span>
                                    <span class="pull-right">  {{$modal_value['premiumBreakup']['totalpremium']['basic_premium']}}</span>
                                 </li>
                              </ul>
                              <!-- <form class="nl pull-left">
                                 <button type="button" class="nl__btn btn-xs">Email This!</button>
                                 <input type="text" placeholder="your@email.com" class="nl__input aria-hidden">
                              </form> -->
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
                              <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0">Save</a>
                        </div>
                     </div>
                  </div>';
