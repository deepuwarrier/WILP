<div class="row card customcard quote-box" id="quote_{{ $quote->insurer_code() }}">
<div class="col-sm-4 logobox">
	<img class="logo" src="{{asset('image/logos/')}}/{{$quote ->insurer_logo() }}" alt="Insurer Logo">
</div>
	<div class="row col-sm-8 logoright">
	<div class="col-md-6">
		<h5 class="card-title price">&#8377; {{$quote -> final_premium() }}</h5>
		<span class="label label-default extrapanelitem idv" style="font-weight: 500">IDV: {{$quote -> idv() }} </span>
	</div>
	<div class="col-md-6 buybutton hvr-grow">
		<form name="policy_submit" id="policy_submit" method="get" action="{{ URL::to('/tw/load_proposal_page') }}">
	
			<input type="hidden" name="tw_trans_code" value="{{ $quote->get_tw_trans_code() }}"/>
			<input type="hidden" name="quote_unique_id" value="{{$quote->get_quote_id() }}"/>
			<input type="hidden" name="insurer_code" value="{{$quote->insurer_code() }}"/>
			<input type="hidden" name="opted_idv" value="{{$quote->idv() }}"/>
			<input type="hidden" name="opted_od" value="{{ $quote->od_value() }}"/>
			<input type="hidden" name="opted_tp" value="{{ $quote->tp_value() }}"/>
			<input type="hidden" name="opted_pa" value="{{ $quote->pa_value() }}"/>
			<input type="hidden" name="opted_oddisc" value="{{ $quote->od_disc()  }}"/>
			<input type="hidden" name="opted_ncb" value="{{ $quote->ncb_value() }}"/>
			<input type="hidden" name="opted_addon" value="{{ $quote->addon_zrdp() }}"/>
			<input type="hidden" name="opted_gst" value="{{ $quote->service_tax() }}"/>
			<input type="hidden" name="opted_premium" value="{{$quote->final_premium() }}"/>
			<button type="button" class="btn btn-success btn-md scrolltop" id="buy_policy" data-focus="idv">Buy Now</button>
		</form>
	</div>
<div class="row">
<div class="col-sm-12">
<div class="content extrapanel">
              <span class="extrapanelitem" style="font-weight: 500">{{$quote->get_misc_text() }}</span> 
             <span class="extrapanelitem name" style="font-weight: 500">{{$quote->insurer_name() }}</span>
              <a href="#"><i class="material-icons iconcustom modal_details" data-modal="packageInfo" data-producid ="" data-toggle="tooltip" data-placement="top" id="" title="Package Info" onclick='jQuery("#pkginfo_{{$quote->insurer_code() }}").modal();' >stars</i></a>
              <a href="#"><i class="material-icons iconcustom modal_details" data-modal="premiumBreakup" data-producid =""  data-toggle="tooltip" data-placement="top" title="Premium Breakup" onclick='jQuery("#prebreak_{{$quote->insurer_code() }}").modal();'>description</i></a>
              <!-- <a href="javascript:void(0)"><i class="material-icons iconcustom modal_details" data-modal="moreInfo" data-producid =""data-toggle="tooltip" data-placement="top" title="More Info">info_outline</i></a> -->
</div>
</div>
</div>
    </div>
 </div>
 
 <!--  Start : Package Info ------------------->
 <div class="modal fade" id="pkginfo_{{$quote->insurer_code() }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">

         <div class="card card-pricing card-margin">
         <div class="row customcard">
               <div class="col-sm-4 logobox">
                  <img src="{{ URL::asset('image/logos/')}}/{{$quote -> insurer_logo() }}" alt="Insurer Logo">
               </div>
                  <div class="col-sm-4">
                     <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$quote -> final_premium() }}</h5>
                     <span class="label label-default extrapanelitem">IDV: {{$quote -> idv() }}</span>
                  </div>
                  
        </div>
                     <div class="content">
                        <h3>Many Benefits in <b>one</b> Package</h3>
                        <ul>
                                 <li><b>Own Damage</b> </li>
                                 <li><b>Third Party Liability</b></li>
                                 <li><b>PA Cover for Owner Driver</b></li>
 @if($quote->addon_zrdp() > 0)  <li><b>Zero Depreciation (Bumper to Bumper)</b></li>  @endif                              
 @if($quote->addon_cnsm() > 0)  <li><b>Cost of Consumables </b></li>  @endif                              
 @if($quote->addon_ncbp() > 0)  <li><b>NCB Protection </b></li>  @endif                              
 @if($quote->addon_rsac() > 0)  <li><b>Enhanced Roadside Assistance</b></li>  @endif                              
 @if($quote->addon_rtin() > 0)  <li><b>Return to Invoice</b></li>  @endif                              
                        </ul>
                     </div>
                  </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
    <!--         <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0">Save</a>	 -->
         </div>
      </div>
   </div>
</div>
 
 <!--  End : Package Info ------------------->
 <!--   Start : Premium Breakup  -->

<div class="modal fade" id="prebreak_{{$quote->insurer_code() }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                     <div class="modal-dialog">
                        <div class="modal-content premium-breakup-card ">
                           <div class="modal-body premium-breakup">
                           <div class="card customcard">
                                 <div class="col-sm-4 logobox">
                                    <img src="{{ URL::asset('image/logos/')}}/{{$quote -> insurer_logo() }}" alt="Insurer Logo">
                                 </div>
                                    <div class="col-sm-4">
                                       <h5 class="card-title price" style="margin-top: 15px;">&#8377; {{$quote -> final_premium() }}</h5>
                                       <span class="label label-default extrapanelitem">IDV: {{$quote -> idv() }}</span>
                                    </div>
                                    <div class="col-sm-4 buybutton" style="margin-top: 15px;">
                                       <!-- <button type="button" class="btn btn-success btn-sm">Buy Now</button> -->
                                    </div>
                           </div>
                           <div style="text-align:left">
                              <h3>Premium Breakup</h3>
                              <h4>Basic Covers</h4>
                              <ul>
                                 <li>
                                    <span class="">{{$cover_list[0]->cover_name}}</span>
                                    <span class="value pull-right">  {{ $quote->od_value() }}</span>
                                 </li>
                                 <li>
                                    <span class="">{{$cover_list[1]->cover_name}}</span>
                                    <span class="value pull-right"> {{ $quote->tp_value() }}</span>
                                 </li>
                              </ul>
                              <h4>Addon Covers</h4>
                              <ul>
                                    <li>
                                       <span class="">{{$cover_list[2]->cover_name}}</span>
                                       <span class="value pull-right">  {{ $quote->pa_value() }} </span>
                                    </li>

    @if($quote->addon_zrdp() > 0)  
     <li>
	     <span class="">{{$cover_list[3]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_zrdp() }} </span>
     </li>
      @endif
   @if($quote->addon_cnsm() > 0) 
	<li>
	     <span class="">{{$cover_list[4]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_cnsm() }} </span>
     </li>
  @endif                                  
 @if($quote->addon_ncbp() > 0) 
	<li>
	     <span class="">{{$cover_list[5]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_ncbp() }} </span>
     </li>
  @endif 
  @if($quote->addon_rsac() > 0) 
	<li>
	     <span class="">{{$cover_list[6]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_rsac() }} </span>
     </li>
  @endif 
  @if($quote->addon_rtin() > 0) 
	<li>
	     <span class="">{{$cover_list[7]->cover_name}}</span> <span class="value pull-right">  {{ $quote->addon_rtin() }} </span>
     </li>
  @endif 
                               
                              </ul>
                              <h4>Discounts</h4>
                              <ul>
                                <li>
                                    <span class="">OD Discount</span>
                                    <span class="value pull-right">( - )  {{ $quote->od_disc()  }}</span>
                                 </li>
                                 <li>
                                    <span class="">No Claim Bonus</span>
                                    <span class="value pull-right">( - )   {{ $quote->ncb_value() }}</span>
                                 </li>
                              </ul>
                              <h4>Taxes</h4>
                              <ul>
                                 <li>
                                    <span class="">Goods & Services Tax</span>
                                    <span class="value pull-right">  {{ $quote->service_tax() }}</span>
                                 </li>
                              </ul>
                              <h4>Final Premium</h4>
                              <ul>
                                 <li class="finalprm">
                                    <span class="">Total Premium</span>
                                    <span class="pull-right">{{ $quote->final_premium() }}</span>
                                 </li>
                              </ul>
                        </div> 
                           </div>
                           <div class="modal-footer">
                              <button type="button" class="btn btn-default btn-primary btn-xs" data-dismiss="modal">Close</button>
<!--                               <a target="_blank" href="{{ route('car.quote.getpdf') }}" class="btn btn-info btn-success btn-xs" style="margin: 0">Save</a>	-->
                        </div>
                     </div>
                  </div>
                  </div>
                  


 <!--   End : Premium Breakup  -->
