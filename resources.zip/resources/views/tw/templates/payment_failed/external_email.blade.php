<html>
<head>
  <title></title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <style type="text/css">
  .whitefont {
      color: white;
  }
  .card [class*="content-"] {
    border-radius: 6px;
  }
  .card [class*="header-"], .card [class*="content-"] {
      color: #FFF;
  }
  .card .header-success, .card .content-success {
      background: linear-gradient(60deg,#66bb6a,#388e3c);
  }
  .card .content {
      padding: 15px 30px;
  }
  .card {
    box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .14), 0 3px 1px -2px rgba(0, 0, 0, .2), 0 1px 5px 0 rgba(0, 0, 0, .12);
  }
  .card {
      margin: 0 0 20px 0;
      border-radius: 3px;
      color: #00669C;
  }
  .card {
      display: inline-block;
      position: relative;
      width: 100%;
      margin-bottom: 30px;
      border-radius: 6px;
      color: rgba(0,0,0,.87);
      background: #fff;
      box-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2), 0 1px 5px 0 rgba(0,0,0,.12);
  }
  .premiumconfirmation {
      min-height: 280px!important;
      display: inline-block;
      padding: 0px!important;
      margin: 0px!important line-height:1.5em;
  }
  </style>
</head>
<body>
  <div class="container genenq">
      <div class="col-md-6">
         <a> <img class="img" src="{{ URL::asset('image/spark.gif')}}" alt="Lost Connection" style="width:250px;"/></a>
      </div>
      <div class="col-md-6 card-contact">
        <p>Dear {{$name}},</p>
        <p>Your transaction with {{$company_name}} through Instainsure.com has failed.</p>
        <p>You can continue and re-attempt the payment by clicking below.</p> 
        <p><a href="{{$proposal_request_url}}"><button class="btn btn-primary">Complete payment</button></a></p>
        <p>If you got this email despite money getting deducted from your account, please contact us immediately and quote the below transaction code. We will help you resolve the issue on top priority.</p>
        {{-- Transaction Code: {{$proposal_form_result['data']['OrderNo']}} --}}
      </div>
   </div>
</body>
</html>
