<html>
    <head>
        <title>New Enquiry</title>
        <!-- Bootstrap core CSS     -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>

      <style type="text/css">
        .panel-primary {
            border-color: #337ab7;
        }
        .panel {
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .table {
            margin-bottom: 20px;
            max-width: 100%;
            width: 100%;
        }
        .row {
            margin-left: -15px;
            margin-right: -15px;
        }
        .panel-heading {
            border-bottom: 1px solid transparent;
            border-top-left-radius: 3px;
            border-top-right-radius: 3px;
            padding: 10px 15px;
        }
        .panel-title {
            color: inherit;
            font-size: 16px;
            margin-bottom: 0;
            margin-top: 0;
        }
      </style>
    </head>
    <body>
        <p>A new policy has been applied with the following details</p>
        <div class="container">
            {{-- <div class="row">
                <table class="table panel panel-primary">
                    <tr class="panel-heading">
                        <td>
                            Request Url
                        </td>
                        <td>
                            Please, <a href="{{$data_value->request_url}}">click here</a> to vist request URL
                        </td>
                    </tr>
                </table>
            </div> --}}
            <div class="row">
            <table class="table panel panel-primary">
                <tr class="panel-heading">
                    <td colspan='2' class="panel-title">Transaction Details</td>
                </tr>
                @php
                    function displayCol($data){
                    if(is_array($data)){
                        foreach($data as $key => $value){
                            if(is_array($value)){
                                displayCol($value);
                            } else {
                                echo "<tr >
                                        <td class='row'>
                                            ".$key."
                                        </td>
                                        <td>
                                            ".$value."
                                        </td>
                                    </tr>";
                            }
                        }
                    } else {
                        echo "<tr >
                                <td class='row'>
                                    {{$data}}
                                </td>
                            </tr>";
                    }
                }
                @endphp
                @if(is_object($data_value))
                    @php
                        $data_value = get_object_vars($data_value);
                    @endphp
                @endif
                @if(is_array($data_value))
                    @php
                        displayCol($data_value)
                    @endphp
                @else 
                    {{$data_value}}
                @endif
            </table>
        </div>
    

        </div>
    </body>
</html>
