@include('tw.layouts.inn-hdr')
<p>&nbsp;</p>
<style>
    .tp-policy .add-on {
    color: rgb(66, 66, 66) !important;
    cursor: pointer;
    font-size: 12px;
    font-weight: 600;
}

.tp-policy .togglebutton{
    display: inline
}
.tp-policy .proposalcard{
    min-height: 135px !important;
}
.tp-spacer{
padding-bottom:10px;
}

.flb{ font-size:10px; }
.espc{ margin-bottom:5px;}
.upcase {text-transform: uppercase;}


</style>
<form id="tp_policy_form" method="get" action="/two-wheeler-insurance/tp">

<div class="container tp-policy" >
    <div class="row">
        <div class="col-md-12">
        <h3 style="text-align: center;" class="info-text">TP Policy Purchase</h3>
        </div>
            <div class="col-sm-5" >
                <div class="card proposalcard" id="cc_value_group" >
                    <h5>Two Wheeler CC</h5>
                    <div class="radiobutton">
                        <input class="cc" type="radio" name="cc_value" id="75cc"  value="75" @if( $data_list["cc_value"] == "75") checked @endif  />
                        <label for="75cc">Upto 75 CC</label>
                    </div>
                    <div class="radiobutton">
                        <input class="cc" type="radio" name="cc_value"  id="150cc" value="150" @if( $data_list["cc_value"] == "150") checked @endif />
                        <label for="150cc">Upto 150 CC</label>
                    </div>
                    <div class="radiobutton">
                        <input class="cc" type="radio" name="cc_value" id="350cc" value="350" @if( $data_list["cc_value"] == "350") checked @endif />
                        <label for="350cc">Upto 350 CC</label>
                    </div>
                    <div class="radiobutton">
                        <input class="cc" type="radio" name="cc_value" id="350cc+" value="351" @if( $data_list["cc_value"]  == '351') checked @endif />
                        <label for="350cc+">Above 350 CC</label>
                    </div>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="card proposalcard" id="addon_group" >
                    <h5>Addon Covers</h5>
                    <div class="col-sm-3">
                    		<label class="add-on">
                            PA OD
                           </label>
                    </div>
                    <div class="col-sm-3">
	                    	 <select class="form-control" id="addon_pa_od" name="addon_pa_od">
	                       @if($data_list["customer_type"] == "I")
	                       <option value="Y"  selected @if( $data_list["addon_pa_od"] == "Y")  selected @endif >Yes</option>  
	                       @else
							<option value="N" @if( $data_list["addon_pa_od"] == "N")  selected @endif >No</option>	                       
	                       @endif
	                    </select>
                    </div>
                    <div class="col-sm-3">
                    		<label class="add-on">
                            PA to Un.PASS
                           </label>
                    </div>
                    <div class="col-sm-3">
	                    	 <select class="form-control valid" id="addon_pa_pass" name="addon_pa_pass">
	                        <option value="Y" @if( $data_list["addon_pa_pass"] == "Y")  selected @endif >Yes</option>
	                        <option value="N" @if( $data_list["addon_pa_pass"] == "N")  selected @endif >No</option>
	                    </select>
                    </div>
                    <br>
                </div>
            </div>
       
        <div class="col-sm-2">
            <div class="card proposalcard" title="Inclusive GST"  >
                <h5>Premium</h5>
                <h5 class="card-title" style="font-size:25px;">
                		<span id="final_premium">{{ $premium["FINAL_PREMIUM"] }} </span>
                </h5>
            </div>
        </div>
    </div>
</div>
 <input type="hidden" id="basic_tp_premium" name="basic_tp_premium" value="{{ $premium["BASIC_TP_PREMIUM"] }}" >
 <input type="hidden" id="addon_premium" name="addon_premium" value="{{ $premium["ADDON_PREMIUM"] }}" >
 <input type="hidden" id="total_gst" name="total_gst" value="{{ $premium["TOTAL_GST"] }}" >
 
    <div class="container">    
        <!-- Contact Details -->
        <div class="row">
            <div class="col-md-12">
            <div class="card proposalcard ">
                <div class="col-sm-12">
                    <h5 class="info-text">Policy For</h5>
                </div>
                 <div class="col-sm-4 tp-spacer">
                 <span class="flb">Customer Type</span>
                    <select class="form-control"  id="customer_type" name="customer_type">
                        <option value="I" @if( $data_list["customer_type"] == "I")  selected @endif >INDIVIDUAL</option>
                        <option value="O" @if( $data_list["customer_type"] == "O")  selected @endif >ORGANIZATION</option>
                    </select>
                </div>
                 <div class="col-sm-4 tp-spacer @if($data_list["customer_type"] != "I") hidden @endif'">
                <span class="flb">Customer Gender</span>
                    <select class="form-control" id="customer_gender" name="customer_gender">
                        <option value="Male" @if( $data_list["customer_gender"] == "Male")  selected @endif  @if($data_list["customer_type"] != "I") selected @endif'>Male</option>
                        <option value="Female" @if( $data_list["customer_gender"] == "Female")  selected @endif >Female</option>
                    </select>
                </div>
                <div class='col-sm-4 tp-spacer @if($data_list["customer_type"] != "I") hidden @endif'>
               <span class="flb">Customer Date of Birth</span>
                    <input class="form-control datepicker" type="text" id="customer_dob" name="customer_dob" placeholder="DOB" value="{{ $data_list["customer_dob"] }}" >
                </div>
               <div class='col-sm-4 tp-spacer  @if($data_list["customer_type"] != "I") hidden @endif '>
              <span class="flb">Customer First Last Name</span>
                    <input class="form-control upcase" type="text" id="customer_name" name="customer_name" maxlength="40"  value="{{ $data_list["customer_name"]  }}" placeholder="FULL NAME" >
                </div>
                 <div class='col-sm-4 tp-spacer @if($data_list["customer_type"] == "I") hidden @endif '>
                <span class="flb">Organisation Name</span>
                    <input class="form-control upcase" type="text" id="organisation_name" name="organisation_name" placeholder="Organisation Name"  value="{{ $data_list["organisation_name"] }}" >
                </div>
                <div class='col-sm-4 tp-spacer  @if($data_list["customer_type"] == "I") hidden @endif '>
               <span class="flb">Customer GSTN Number</span>
                    <input class="form-control upcase" type="text" id="organisation_gstnno" name="organisation_gstnno" maxlength="14"  value="{{ $data_list["organisation_gstnno"]  }}" placeholder="GSTN Number" >
                </div>
                <div class="col-sm-4 tp-spacer">
               <span class="flb">Customer Mobile Number</span>
                    <input class="form-control" type="text" id="customer_mobile" name="customer_mobile" placeholder="Mobile Number" value="{{ $data_list["customer_mobile"] }}" maxlength="10"  >
                </div>
                <div class="col-sm-4 tp-spacer">
               <span class="flb">Customer Email</span>
                    <input class="form-control upcase" type="text" id="customer_email" name="customer_email"  value="{{ $data_list["customer_email"] }}" placeholder="EMAIL ID" >
                </div>
                <div class="col-sm-4 tp-spacer">
               <span class="flb">Registered Address</span>
                    <input class="form-control upcase" type="text" id="customer_address" name="customer_address" placeholder="Address" value="{{ $data_list["customer_address"] }}" maxlength="75">
                </div>
                <div class="col-sm-4 tp-spacer espc">
               <span class="flb">Registered State</span>
                    <select name="statecode" id="statecode" class="form-control">
                        <option   hidden="" value="-1">Select State</option>
                        @foreach($state_list as $state)
                        <option  value="{{ $state->state_code }}" @if( $data_list["statecode"] == $state->state_code)  selected @endif > {{ $state->state_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-sm-4 tp-spacer espc">
               <span class="flb">Registerd City</span>
                    <select name="citycode" id="citycode" class="form-control">
                        <option   hidden="" value="-1">Select City</option>
                       @foreach($city_list as $city)
                        <option  value="{{ $city->city_code }}" @if( $data_list["citycode"] == $city->city_code )  selected @endif   >{{ $city->city_name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-sm-4 tp-spacer">
               <span class="flb">Registered Pincode</span>
                    <input class="form-control" type="text" id="customer_pincode" name="customer_pincode" maxlength="6"  value="{{ $data_list["customer_pincode"]  }}" placeholder="Pincode" >
                </div>
                 <div class='col-sm-4 tp-spacer @if($data_list["customer_type"] != "I") hidden @endif'>
                <span class="flb">Customer Aadhar Number</span>
                    <input class="form-control" type="text" id="customer_aadharno" name="customer_aadharno" maxlength="12"  value="{{ $data_list["customer_aadharno"]  }}" placeholder="Aadhar Number" >
                </div>
                
            </div>
            </div>
        </div>
    </div>

<div class="container">  
    <div class="row">
        <!-- Contact Details -->
        <div class="col-md-12">
        <div class="card proposalcard">
            <div class="col-sm-12">
                <h5 class="info-text">Vehicle Details</h5>
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Vehicle Make Model</span>
                <select id="vechicle_code" name="vechicle_code"  class="form-control" >
                     <option hidden="" value="-1">Vehicle Make Model</option>
                    @foreach($vechicle_list as $vechicle)
                    <option   value="{{ $vechicle->vehicle_code_desc }}" @if( $data_list["vechicle_code"] != "" && $data_list["vechicle_code"] == $vechicle->vehicle_code_desc )  selected @endif >{{ $vechicle->vechicle_name_desc }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Registration Number</span>
                <input class="form-control upcase" type="text" id="tw_regno" name="tw_regno" placeholder="MH-01-AB-1234" value="{{ $data_list["tw_regno"]  }}" >
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Registration Date</span>
                <input class="form-control datepicker" type="text" id="reg_date"  name="reg_date"  placeholder="Registration Date"  value="{{ $data_list["reg_date"]  }}" >
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Engine Number</span>
                <input class="form-control  upcase" type="text" id="engine_no" name="engine_no" placeholder="Engine No" value="{{ $data_list["engine_no"]  }}"  >
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Chassis Number</span>
                <input class="form-control  upcase" type="text" id="chassis_no" name="chassis_no" placeholder="Chassis No"   value="{{ $data_list["chassis_no"]  }}" maxlength="20" >
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Vehicle Color</span>
                <input class="form-control  upcase" type="text" id="tw_color" name="tw_color" placeholder="Color" value="{{ $data_list["tw_color"]  }}" >
            </div>
             <div class="col-sm-4 tp-spacer">
            <span class="flb">Previous Insurer</span>
                <select id="pre_insurer" name="pre_insurer"  class="form-control" >
                     <option hidden="" value="-1">Previous Insurer</option>
                    @foreach($preins_list as $preins_data)
                    <option   value="{{ $preins_data->preinsr_code }}" @if( isset($data_list["pre_insurer"] ) && $data_list["pre_insurer"] == $preins_data->preinsr_code )  selected @endif >{{ $preins_data->preinsr_name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Previous Policy No.</span>
                <input class="form-control upcase" type="text" id="pre_policyno" name="pre_policyno" placeholder="PREVIOUS POLICY NUMBER" value="{{ $data_list["pre_policyno"]  }}" >
            </div>
            <div class="col-sm-4 tp-spacer">
           <span class="flb">Previous Policy Expiry Date</span>
                <input class="form-control datepicker" type="text" id="pre_pex_date"  name="pre_pex_date" data-pexMin='{{$def_data["PEX_MIN"]}}' data-pexMax='{{$def_data["PEX_MAX"]}}'   placeholder="PREVIOUS POLICY EXPIRY DATE"  value="{{ $data_list["pre_pex_date"]  }}" >
            </div>
              
        </div>
        </div>
    </div>
</div>

<div class="container">  
    <div class="row">
        <!-- Contact Details -->
        <div class="col-md-12">
        <div class="card proposalcard">
            <div class="col-sm-12">
                <h5 class="info-text">New Policy Details</h5>
            </div>
             <div class="col-sm-4 tp-spacer">
             	<span class="flb">Policy Start Date </span>
                <input class="form-control" type="text" id="policy_start_date" name="policy_start_date" placeholder="Policy Start Date" value="{{ $data_list["policy_start_date"]  }}"  readonly>
            </div>
            <div class="col-sm-4 tp-spacer">
            <span class="flb">Policy End Date </span>
                <input class="form-control" type="text" id="policy_end_date" name="policy_end_date" placeholder="Policy End Date"  value="{{ $data_list["policy_end_date"]  }}" readonly >
            </div>
        </div>
        </div>
        <p>&nbsp;</p>
    </div>
</div>

<div class="container">   
    <div class="row">
        <div class="col-sm-12" id="submit_container">
<!--            <button class="btn btn-success  pull-right"  onclick="setMail();">Email this</button>-->
 <button type ="button" class="btn btn-success pull-right" id="submit_buynow" >Buy Now</button>
  <button type ="#" class="btn btn-success pull-right" id="save_page" >Save URL</button>
           
            
        </div>
    </div>
</div>
</form>



<br>
<br>
@include('tw.layouts.inn-ftr')
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script src="/js/tw/twtp.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    
    });
</script>