@include('tw.layouts.inn-hdr')

               <!--      Wizard container        -->
               <div class="wizard-container addmargin" id="home">
                  <div class="card wizard-card" data-color="green" id="wizardProfile">
                  <div class="wizard-header">
                           <h3 class="wizard-title" style="text-align: center; color: burlywood">
                              Select your Two Wheeler!
                           </h3>
                        </div>
<form method="get" id="tw_details_form" action="/tw/details_store" >

	<div class="col-md-12" >
		<div class="row pad10bottom">
		<div class="col-sm-4" ></div>
    		<div class="col-sm-4 pad10bottom" >
<!--            <span class="flb">Vehicle Make Model</span> -->
                <select id="vechicle_code" name="vechicle_code"  class="form-control">
                     <option hidden="" value="-1">Vehicle Make Model</option>
                    @foreach($vehicle_list as $vechicle)
                    <option   value="{{ $vechicle->vehicle_code_desc }}" >{{ $vechicle->vechicle_name_desc }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-sm-4" ></div>
            </div>
            <div class="row pad10bottom">
            <div class="col-sm-4" ></div>
            <div class="col-sm-4 pad10bottom">
<!--            <span class="flb">Vehicle RTO</span> -->
                <select id="tw_rto" name="tw_rto"  class="form-control"  required>
                     <option hidden="" value="-1">Vehicle RTO</option>
                    @foreach($rto_list as $rto_data)
                    <option   value="{{ $rto_data->rto_code }}" >{{ $rto_data->rto_code }} - {{ $rto_data->rto }} - ({{$rto_data->zone}})</option>
                    @endforeach
                </select>
            </div>
            <div class="col-sm-4" ></div>
            </div>
         	<div class="row pad10bottom">
         	<div class="col-sm-4" ></div>   
            <div class="col-sm-4 pad10bottom">
<!--            <span class="flb">Registration Year</span> -->
                <select id="tw_yor" name="tw_yor"  class="form-control" required>
                     <option hidden="" value="-1">Registration Year</option>
                    @foreach($yor_list as $yor)
                    <option   value="{{ $yor }}" >{{ $yor }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-sm-4" ></div> 
            </div>                 
    </div>  
    <p>&nbsp;</p>
    <div class="col-md-12">
    		<input class="btn btn-info" type="submit" value="View Quotes" />
    </div>
</form>                
                  </div>
               </div>
               <!-- wizard container -->




<div class="features-1" >@include('layouts.c_legacy') </div>
<div class="features-5" >@include('layouts.c_whyus') </div>
<div class="testimonials-2 section-image" >@include('layouts.c_testimonial')</div>
<div class="blogs-2" style="padding-top: 80px">@include('layouts.c_blog')</div>
<div class="team-1" >@include('layouts.c_team')</div>
           
	
@include('tw.layouts.inn-ftr')
<script src="{{URL::asset('js/tw/twdetails.js')}}" type="text/javascript"></script>
<script type="text/javascript" src="{{ URL::asset('js/select2.min.js') }}"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("select").select2({ width: '100%' ,minimumResultsForSearch: 6 });
    
    });
</script>