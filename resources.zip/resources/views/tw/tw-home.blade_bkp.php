@include('tw.layouts.inn-hdr')
      

               <!--      Wizard container        -->
               <div class="wizard-container addmargin" id="home">
                  <div class="card wizard-card" data-color="green" id="wizardProfile">
                     <form action="#" method="" novalidate>
                        <!--        You can switch " data-color="purple" "  with one of the next bright colors: "green", "orange", "red", "blue"       -->
                        <div class="wizard-header">
                           <h3 class="wizard-title" style="text-align: center; color: burlywood">
                              Select your Two Wheeler!
                           </h3>
                        </div>
                        <div class="wizard-navigation">
                           <ul class="nav nav-pills">
                              <li style="width: 16.6666%;" class="active">
                                 <a href="#make" data-toggle="tab" aria-expanded="true">Make</a>
                              </li>
                              <li style="width:16.6666%;">
                                 <a href="#model" data-toggle="tab">Model</a>
                              </li>
                              <li style="width:16.6666%;">
                                 <a href="#variant" data-toggle="tab" id="vari_tab">Variant</a>
                              </li>
                              <li style="width:16.6666%;">
                                 <a href="#rtostate" data-toggle="tab" id="rtos_tab">RTO State</a>
                              </li>
                               <li style="width:16.6666%;">
                                 <a href="#rtocodes" data-toggle="tab" id="rtoc_tab">RTO Code</a>
                              </li>
                              <li style="width:16.6666%;">
                                 <a href="#yor" data-toggle="tab">Year of Reg.</a>
                              </li>
                           </ul>
                           <div class="moving-tab" style="width: 235.556px; transform: translate3d(-8px, 0px, 0px); transition: transform 0s ease 0s;">Make</div>
                        </div>
                        <div class="tab-content">
                           <div class="tab-pane active" id="make">
                              <div class="row">
                                 <h6 class="info-text"> Let's select your bike manafucturer!</h6>
                                 <div class="container tabdata">
                                 @foreach ($twmks as $mkidx => $twmk)																	
                                    <input id="{{ $twmk->make_code }}" data-make-id="{{ $twmk->make_code }}"  class="btn btn-next btn-fill btn-wd {{ ($twmk->make_code == $selected['make_code']) ? 'btn-blue' : 'btn-white'}}" name="make" value="{{ $twmk->make_name }}" type="button">
                                  @if ($mkidx == 7)<hr>@endif
                                   @endforeach
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane" id="model">
                              <div class="row">
                                 <div class="container tabdata">
                                    <h6 class="info-text"> Let's select your bike model!</h6>
                                    <div id="modelccnt">	
										@include('tw.model-list')	
									</div>	                                   
                                 </div>
                              </div>
                           </div>
                         
                           <div class="tab-pane" id="variant">
                              <div class="row">
                                 <div class="container tabdata">
                                    <h6 class="info-text"> Let's select your bike variant!</h6>
                                    <div id="variantccnt">@include('tw.variant-list')</div>	
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane" id="rtostate">
                              <div class="row">
                                 <div class="container tabdata">
                                    <h6 class="info-text"> Let's select your RTO State!</h6>
									@foreach ($stlst as $stidx=>$st)
									<a class="btn btn-next btn-wd {{ ($st->state_code == $selected['state_code']) ? 'btn-blue' : 'btn-white'}}" href="#rtocodes" id="{{$st->state_code}}" data-code="{{$st->rto_code}}" data-toggle="tab" name="rtostate" type="button">{{$st->state_name}}</a>
									@if ($stidx == 8)<hr>@endif
									@endforeach
                                 </div>
                              </div>
                           </div>
                           
                           <div class="tab-pane" id="rtocodes">
                             
                              <div class="container tabdata">
                                 <div class="" id="">
                                    <div class="row">
                                       <div id="js-calculator">
                                          <!-- Screen and clear key -->
                                             <h6>Use the Dial Pad to enter the RTO<h6>
                                             <span style="font-size: 20px" id="rto_code_txt">{{ substr($selected['rto_code'], 0,2) }}</span>
                                             <span class="screen" style="font-size: 20px" id="rto_code_val">{{ substr($selected['rto_code'],2,2) }}</span>
                                       
                                          <div class="row">
                                             <div class="col-xs-12">&nbsp;</div>
                                          </div>

                                          <!-- operators and other keys -->


                                       <div class="card table-responsive rtocard">
                                        <table class="rtotable">
                                            <tbody>
                                                <tr>
                                                    <td><button type="button" class="btn btn-white">1</button></td>
                                                    <td><button type="button" class="btn btn-white">2</button></td>
                                                    <td><button type="button" class="btn btn-white">3</button></td>
                                                </tr>
                                                <tr>
                                                    <td><button type="button" class="btn btn-white">4</button></td>
                                                    <td><button type="button" class="btn btn-white">5</button></td>
                                                    <td><button type="button" class="btn btn-white">6</button></td>
                                                </tr>
                                                <tr>
                                                    <td><button type="button" class="btn btn-white">7</button></td>
                                                    <td><button type="button" class="btn btn-white">8</button></td>
                                                    <td><button type="button" class="btn btn-white">9</button></td>
                                                </tr>
                                                <tr>
                                                    <td><button type="button" class="btn btn-white">0</button></td>
                                                    <td><button type="button" class="btn-calc">Clear</button></td>
                                                    <td><input class="btn-calc btn-next" id="rto_code_pad"  name="rto" style="background-color: #00669C"value="Proceed" type="button"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                          
                                       </div>
                                    </div>
                                 </div>
                                 
                              </div>
                           </div>
                           <div class="tab-pane" id="yor">
                              <div class="row">
                                 <div class="container tabdata">
                                    <h6 class="info-text"> Let's select your Year of Registration!</h6>
                                     @foreach ($yorlst as $yrlst)     
                                    <a href="#" id="{{ $yrlst }}" class="btn btn-submit btn-fill btn-wd {{ ($yrlst == $selected['yor']) ? 'btn-blue' : 'btn-white'}}" name="yor" value="{{ $yrlst }}" type="button">{{ $yrlst }}</a>
                                     @endforeach
                                 </div>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
               <!-- wizard container -->

<form method="get" id="tw_dtls_form">
	<input type="hidden" name="hdn_make" id="hdn_make"  value="{{ $selected['make_code']}}" />
	<input type="hidden" name="hdn_model" id="hdn_model"  value="{{ $selected['model_code']}}" />
	<input type="hidden" name="hdn_variant" id="hdn_variant"  value="{{ $selected['variant_code']}}" />
	<input type="hidden" name="hdn_state" id="hdn_state"  value="{{ $selected['state_code']}}" />
	<input type="hidden" name="hdn_rtocode" id="hdn_rtocode"  value="{{ $selected['rto_code']}}" />
	<input type="hidden" name="hdn_yor" id="hdn_yor"  value="{{ $selected['yor']}}" />
</form>


<div class="features-1" >@include('layouts.c_legacy') </div>
<div class="features-5" >@include('layouts.c_whyus') </div>
<div class="testimonials-2 section-image" >@include('layouts.c_testimonial')</div>
<div class="blogs-2" style="padding-top: 80px">@include('layouts.c_blog')</div>
<div class="team-1" >@include('layouts.c_team')</div>
<div class="contactus-1 section-image">@include('layouts.c_contact')</div>
           
	
@include('tw.layouts.inn-ftr')
<script src="{{URL::asset('js/jquery.isonscreen.js')}}" type="text/javascript"></script>
<script src="{{URL::asset('js/tw/twdetails.js')}}" type="text/javascript"></script>
