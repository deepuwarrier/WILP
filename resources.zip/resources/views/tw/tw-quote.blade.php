 @include('tw.layouts.inn-hdr')
      <div class="cd-section" id="carwizard">
         <div class="col-sm-12 removepaddingsmallscreen whitebg">
            <!--      Wizard container        -->
            <div class="wizard-container">
                   
            <form name="update_quote" id="update_quote" method="post" action="">
               <div class="col-sm-4">

@include('tw.quote.d_preview')

@include('tw.quote.idvsection')
                  
               </div>
               
@include('tw.quote.covers')

               </form>
               <div class="col-sm-4">
                  <div class="insurance-list" id="quote_ctnr_box">
							<div class="row card customcard"><h5 class="card-title price">-- Loading Quotes --  </h5>
                     </div>
							
                  </div>
                  <div class="insurance-list" id="no_quotes">
                     <p id="no_quote_text" class="hidden">
                        We did not get a quote from the bellow insurers
                     </p>                     
                  </div>
                  @include('tw.quote.no_quote')
                  <div class="row customcard">
                     <button onclick='jQuery("#email").modal();' type="button" class="btn btn-info btn-simple btn-xs pull-left" data-toggle="modal" data-target="#email_quote_modal">Email Quotes</button>
                     <!-- <button type="button" class="btn btn-info btn-simple btn-xs pull-right">Load More Quotes</button> -->
                  </div>
               </div>
            </div>
            <!-- wizard container -->
         </div>
      </div>
      <div id="modal_div"></div>
      <input type="hidden" id="tw_trans_code" value="{{ $tw_trans_code }}" />
      <input type="hidden" id="trans_code" value="{{ $tw_trans_code }}" />
      <div class="modal fade" id="email_quote_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
         <div class="modal-dialog">
           <form id="email_quote_form" method="POST">
              <input type="hidden" name="quote_form_url" id="quote_form_url" value="{{URL::route('send-quote-mail')}}">
               <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span><span class="sr-only">Close</span></button>
                      <h4 class="modal-title" id="QuoteLabel"> E-mail Quotes</h4>
                  </div>
                     <div class="modal-body">    
                        {{ csrf_field() }}
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                           <input type="text" id="email_quote_name" name="email_quote_name" class="form-control" placeholder="Your name">
                        </div>
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                           <input type="email" id="email_quote" name="email_quote" class="form-control" placeholder="your@email.com">
                        </div>
                        <br />
                        <span id="quote_email_message"></span>
                     </div>
                     <div class="modal-footer">
                        <button type="button" id="quote_email_submit" value="sub" name="sub" class="btn btn-primary" ><i class="fa fa-share"></i> Send </button>
                     </div>
               </div>
            </form>
         </div>
      </div>
@include('tw.layouts.inn-ftr')
  <script src="{{ asset('js/tw/twquote.js') }}"></script>
<script type="text/javascript" language="JavaScript"> $( document ).ready(function() { load_tw_quotes();  }); </script>


