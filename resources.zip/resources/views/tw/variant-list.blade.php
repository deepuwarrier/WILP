@foreach ($data_list as $dtidx=>$data)
<input class="btn btn-next btn-fill btn-wd {{ ($data->variant_code == $selected['variant_code']) ? 'btn-blue' : 'btn-white'}}" name="twvl" data-model-id="{{ $data->variant_code }}"   id="{{ $data->variant_code }}" value="{{ $data->variant_name }}" type="button">
@if ($dtidx == 7)<hr>@endif
@endforeach
