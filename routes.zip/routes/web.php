<?php


Route::get('/ttibi', 'TtibiGmc@load_ttibigmc');
Route::get('/ttibi_search', 'TtibiGmc@search_ttibigmc');
Route::post('/ttibi_member_submit', 'TtibiGmc@submit_ttibigmc');


Route::get('/ttibi1', 'TtibiGmc1@load_ttibigmc');
Route::get('/ttibi_search1', 'TtibiGmc1@search_ttibigmc');
Route::post('/ttibi_member_submit1', 'TtibiGmc1@submit_ttibigmc');


Route::get('/mis', function() {
        return Redirect::to('http://instainsure.net/employee/add-policy');
    });

Route::get('/test/1', 'TW/TwTest@execute');



/*  ------------------------------------ START: Basic Routes ------------------------------------- */

Route::get('/', 'InstaHome@index');
Route::get('/faqs', 'InstaHome@getFaqs');
Route::get('/team', 'InstaHome@getTeam');
Route::get('/blog', 'InstaHome@getBlog');
Route::get('/premium-calculator', 'Calculator@index');
Route::get('/#contactus', 'InstaHome@index');
Route::post('/calc-add-products', 'Calculator@add_products');
Route::post('/calc-remove-products', 'Calculator@remove_products');
Route::post('/calc-send-email', 'Calculator@send_email');

Route::get('/terms', function () {return view('pages.terms');});
Route::get('/privacy', function () {return view('pages.privacy');});

Route::get('/car-insurance-offer','InstaHome@getCarInsuranceOffer');
Route::post('/car-insurance-offer-form','InstaHome@setCarInsuranceOfferCustomer')->name('pages.car_insurance_offer_form');

//Survey
Route::get('/health-insurance/survey/{agent_id}', 'LeadController@index_agent')->name('vew_helath_survey');
Route::get('/health-insurance/survey', 'LeadController@index_no_agent')->name('vew_helath_survey_no_agent');
Route::post('submit_survey/{agent_id}', 'LeadController@save_survey')->name('submit_health_survey');



Route::get('/get_car_ins_companies_section', 'InstaHome@get_car_ins_companies_section');
Route::get('/get_car_ins_stories_section', 'InstaHome@get_car_ins_stories_section');
Route::get('/get_car_getquote_section', 'InstaHome@get_car_getquote_section');
Route::get('/get_car_terms_section', 'InstaHome@get_car_terms_section');
Route::get('/get_car_mustread_section', 'InstaHome@get_car_mustread_section');

Route::get('/set-car-details', 'InstaHome@get_car_mustread_section');

Route::group(['prefix' => '/blog'], function () {
	Route::get('/what-is-bumper-to-bumper-cover', function () {return view('b2bcover');});
	Route::get('/be-aware-low-premium-comes-at-a-cost', function () {return view('lowpremium');});
	Route::get('/toyota-tsusho-insurance-day', function () {return view('toyotatiday');});
});

Route::get('/home-insurance', function () {return view('genenq', ['insurance_type' => 'home_insurance']);});
Route::get('/term-insurance', function () {return view('genenq', ['insurance_type' => 'term_insurance']);});
Route::get('/mode/{uat}', 'InstaHome@uatindex')->name('insta_uat_mode');
Route::post('/sendmail', 'EmailSender@send');
Route::post('/sendinquiry', 'EmailSender@inquiry');
Route::post('/send-quote-mail', 'EmailSender@quotEmail')->name('send-quote-mail');

/*  ----------------------------------- END: Basic Routes ---------------------------------------- */

/*  ----------------------------------- SART: Customer Routes ---------------------------------------- */
Route::post('/customer-logout', 'Customers\Customers@logout')->name('customer.logout');
Route::post('/customer-login', 'Customers\Customers@login')->name('customer.login');
Route::post('/customer-registration', 'Customers\Customers@register')->name('customer.registration');
Route::post('/customer-forgot-password', 'Customers\Customers@forgotPassword')->name('customer.forgotPassword');
Route::post('/customer-password', 'Customers\Customers@updatePassword')->name('customer.changePassword');
Route::post('/customer-register-modal', 'Customers\Customers@getRegisterForm')->name('customer.registerForm');
Route::post('/customer-forget-password-modal', 'Customers\Customers@getForgetPasswordForm')->name('customer.passwordForgetForm');
Route::post('/customer-login-modal', 'Customers\Customers@getLoginForm')->name('customer.loginForm');
Route::get('/agent/agent_dashboard', 'Customers\Customers@agentDashboard')->middleware('checkagent')->name('agent_dashboard');
/*  ----------------------------------- END: Customer Routes ---------------------------------------- */

/*  ------------------------------------ START: Car Routes ------------------------------------- */

Route::get('/car-insurance', 'Car\CarHome@index')->name('car_insurance');
Route::get('/car-insurance/mode/{uat}', 'Car\CarHome@uatindex')->name('car_insurance_mode_uat');
Route::post('/set-car-details', 'Car\CarHome@setDetailData')->name('car_details_update');
Route::get('/car-insurance/cartisan', 'Car\CarHome@partner_cartisan')->name('car_insurance_cartisan');
Route::get('/car-insurance/cartisan/reports', 'Reports\Export@cartisanReport')->name('cartisan_report');
Route::get('/car-insurance/agent/daily_report', 'Reports\Export@agentReport')->name('agent_daily_report');

Route::group(['prefix' => '/car-insurance'], function () {
	
	Route::post('/load_proposal_page', 'Car\CarQuote@load_proposal_page')->name('car.load_proposal');

	Route::get('/refresh', 'Car\CarQuote@refresh')->name('car.car_refresh');
	Route::get('/get_idv_section','Car\CarQuote@get_idv_section');
	Route::post('/getmodel', 'Car\CarHome@getModelFromMake');
	Route::post('/getquote/getmodal', 'Car\CarQuote@get_modal');
	Route::post('/getquote/check_ncb', 'Car\CarQuote@check_ncb');
	Route::post('/getquote/update-policy-status', 'Car\CarQuote@updatePrevPolicyStatus');
	Route::post('/getquote/reset_idv', 'Car\CarQuote@reset_idv');
	Route::get('/getquote/defaultvalue', 'Car\CarQuote@defaultvalue');
	Route::post('/getvariant', 'Car\CarHome@getVariant');
	Route::post('/getrto', 'Car\CarHome@getRto');
	Route::post('/checkrto', 'Car\CarHome@checkrto');
	Route::post('/carrsgiquote', 'Car\CarQuote@getRsgiQuote')->name("car.quote.getrsgiquote");
	Route::post('/updatersgiquote', 'Car\CarQuote@getRsgiQuote')->name("car.quote.updatersgiquote");
	//fetch quote
	Route::post('/tata_quote', 'Car\CarQuote@getTataQuote')->name("car.quote.gettataquote");
	Route::post('/uiic_quote', 'Car\CarQuote@getUIICQuote')->name("car.quote.getuiicquote");
	Route::post('/hdfc_quote', 'Car\CarQuote@getHDFCQuote')->name("car.quote.getuiicquote");

	Route::post('/updatetataquote', 'Car\CarQuote@updateTataQuote')->name("car.quote.updatetataquote");
	Route::post('/api/lastdecimal', 'Car\CarQuote@apiLastdecimal')->name("car.quote.apiLastdecimal");

	
	Route::post('/carquote', 'Car\CarQuote@getPdf')->name("car.quote.getpdf");
	Route::get('/get_financier', 'Car\CarPolicy@getFinancier')->name("car.policy.get_financier");

	/* Routes for status */
	Route::post('/getpremiumstatus', 'Car\CarPolicy@getPremiumStatus')->name("car.policy.premiumstatus");
	Route::post('/premiumreconfirm', 'Car\CarPolicy@getReConfirmStatus')
		->name("car.policy.premiumreconfirm");
	Route::post('/premiummissmatch', 'Car\CarPolicy@getPremiumMissmatchStatus')
		->name("car.policy.premiummissmatchstatus");
	Route::post('/badresponse', 'Car\CarPolicy@getBadResponseStatus')
		->name("car.policy.badresponse");
	Route::post('/inspection_status', 'Car\CarPolicy@getInspectionConfirmStatus')
		->name("car.policy.inspection_status");
	/* Routes for status ends here*/
	Route::post('/genrate_otp', 'Car\CarPolicy@genrateOtp')->name("car.policy.gen_otp");
	Route::post('/verify_otp', 'Car\CarPolicy@verifyOtp')->name("car.policy.very_otp");
	Route::get('/setDetail', 'Car\CarQuote@setDetailData'); // Store values in database

	Route::post('/initiate_payment', 'Car\CarPolicy@initiatePayment')
		->name("car.policy.initiate_payment");
});
/*----    Car Policy ----*/
// Route::post('/car-insurance/policy', 'Car\CarPolicy@index');
Route::get('/car-insurance/hdfc', 'Car\Policy\HdfcPolicy@index');
Route::group(['prefix' => 'car-insurance', 'middleware' => ['tarnsaction']], function () {
	// get car quote
	Route::post('/store_quote_data', 'Car\CarHome@storeQuoteData')->name('car-insurance.store_quote_data');
	Route::any('/quote/{transcode}', 'Car\CarQuote@index')->name('car-insurance.getquote');

    Route::post('/tata/check_tata_addon', 'Car\Policy\TataAig@checkprevaddon');
	Route::get('/quote/{transcode}/getfilterquote', 'Car\CarQuote@filter_quote');
});

Route::group(['prefix' => 'car-insurance/policy', 'middleware' => ['tarnsaction']], function () {
	Route::post('/unitedindia_branch', 'Car\Policy\UnitedIndia@getUiicBranch');
	// load proposal section
	Route::post('/bhartiaxa/{transcode}', 'Car\Policy\BhartiAxa@index');
	Route::get('/bhartiaxa/{transcode}', 'Car\Policy\BhartiAxa@loadProposalUrl');
	Route::post('/hdfc/{transcode}', 'Car\Policy\HdfcPolicy@index');
	Route::get('/hdfc/{transcode}', 'Car\Policy\HdfcPolicy@loadProposalUrl');

	// load hdfc proposal
	Route::get('hdfc/{transcode}', 'Car\Policy\HDFC@loadProposalUrl');
	Route::post('hdfc/{transcode}', 'Car\Policy\HDFC@index');
        

	// load tata aig proposal
	Route::get('/tata/{transcode}', 'Car\Policy\TataAig@loadProposalUrl');
	Route::post('/tata/{transcode}', 'Car\Policy\TataAig@index');
       
	Route::post('/iffcotokio/{transcode}', 'Car\Policy\IffcoTokio@index');
	Route::get('/iffcotokio/{transcode}', 'Car\Policy\IffcoTokio@loadProposalUrl');
	Route::post('/futuregenerali/{transcode}', 'Car\Policy\FutureGenerali@index');
	Route::get('/futuregenerali/{transcode}', 'Car\Policy\FutureGenerali@loadProposalUrl');
	Route::post('/unisompo/{transcode}', 'Car\Policy\UniSompo@index');
	Route::get('/unisompo/{transcode}', 'Car\Policy\UniSompo@loadProposalUrl');
	
	Route::post('/bajajallianz/{transcode}', 'Car\Policy\Bajajallianz@index');
	Route::get('/bajajallianz/{transcode}', 'Car\Policy\Bajajallianz@loadProposalUrl');

	Route::any('/reliance/{transcode}', 'Car\Policy\Reliance@index');

	
	Route::post('/rsgi/{transcode}', 'Car\Policy\RoyalSundram@index');
	Route::get('/rsgi/{transcode}', 'Car\Policy\RoyalSundram@loadProposalUrl');


	Route::get('/bajajallianz', 'Car\Policy\Bajajallianz@callIndex');
	Route::get('/bhartiaxa', 'Car\Policy\BhartiAxa@callIndex');
	Route::get('/hdfc', 'Car\Policy\HdfcPolicy@callIndex');
	Route::get('/unitedindia', 'Car\Policy\UnitedIndia@callIndex');
	Route::get('/iffcotokio', 'Car\Policy\IffcoTokio@callIndex');
	Route::get('/futuregenerali', 'Car\Policy\FutureGenerali@callIndex');
	Route::get('/unisompo', 'Car\Policy\UniSompo@callIndex');
	Route::get('/rsgi', 'Car\Policy\RoyalSundram@callIndex');

});

Route::get('/api_bad_response', 'Car\CarPolicy@badResponse')
		->name('api_bad_response');
		
Route::group(['prefix' => 'car-insurance/unisompo'], function () {
	Route::get('/', 'Car\Policy\UniSompo@index');
	Route::get('/paymentstatus', 'Car\Policy\UniSompo@returnPage')->name('car.policy.unisompo.returnPage');
	Route::post('/getpolicy', 'Car\Policy\UniSompo@getPolicy');
	Route::post('/getmaster', 'Car\Policy\UniSompo@getApiMasters');
	Route::post('/setproposaldata', 'Car\Policy\UniSompo@setProposalData')->name('car.policy.unisompo.setproposaldata')->middleware('tarnsaction');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.unisompo.proposal_error');
});

Route::group(['prefix' => 'car-insurance/bhartiaxa'], function () {
	Route::get('/', 'Car\Policy\BhartiAxa@index');
	Route::get('/paymentstatus', 'Car\Policy\BhartiAxa@returnPage')->name('car.policy.bhartiaxa.returnPage');
	Route::post('/getpolicy', 'Car\Policy\BhartiAxa@getPolicy');
	Route::post('/getmaster', 'Car\Policy\BhartiAxa@getApiMasters');
	Route::post('/setproposaldata', 'Car\Policy\BhartiAxa@setProposalData')->name('car.policy.bhartiaxa.setproposaldata')->middleware('tarnsaction');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.bhartiaxa.proposal_error');

});

// Route::group(['prefix' => 'car-insurance/unitedindia'], function () {
// 	Route::get('/', 'Car\Policy\UnitedIndia@index');
// 	Route::get('/paymentstatus', 'Car\Policy\UnitedIndia@returnPage')->name('car.policy.unitedindia.returnPage');
// 	Route::post('/getpolicy', 'Car\Policy\UnitedIndia@getPolicy')->middleware('tarnsaction');
// 	Route::post('/getmaster', 'Car\Policy\UnitedIndia@getApiMasters');
// 	Route::post('/setproposaldata', 'Car\Policy\UnitedIndia@setProposalData')->name('car.policy.unitedindia.setproposaldata')->middleware('tarnsaction');
// 	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.unitedindia.proposal_error');
// });


Route::get('car-insurance/tata/pdf/{policy_no}', 'Car\Policy\TataAig@tata_policy_pdf')->name('car.tata.policy_pdf');


Route::group(['prefix' => 'car-insurance/tata'], function () {
	Route::get('/', 'Car\Policy\TataAig@index');
	Route::any('/payment/status', 'Car\Policy\TataAig@returnPage')->name('car.policy.tata.returnPage');
	Route::post('/getpolicy', 'Car\Policy\TataAig@getPolicy')->middleware('tarnsaction');
	Route::any('/policy/status','Car\Policy\TataAig@proposalError')->name('car.tata.proposal_error');
	Route::post('/get_tata_status','Car\Policy\TataAig@getStatus')
	->name('car.tata.addon_status');
	Route::post('/get_external_cng_status','Car\Policy\TataAig@checkExternalCngValue')->name('car.tata.external_cng_status');
});

// start UIIC
Route::get('car-insurance/policy/uiic/{sessionid}', 'Car\Policy\UnitedIndia@loadProposalUrl')->middleware('tarnsaction');
Route::post('car-insurance/policy/uiic/{sessionid}', 'Car\Policy\UnitedIndia@index')->middleware('tarnsaction');
Route::any('car-insurance/uiic/payment/status', 'Car\Policy\UnitedIndia@returnPage')
		->name('car.policy.uiic.returnPage');

Route::get('car-insurance/uiic/pdf/{policy_no}', 'Car\Policy\UnitedIndia@uiic_policy_pdf')
		->name('car.uiic.policy_pdf');
Route::group(['prefix' => 'car-insurance/uiic'], function () {
	Route::get('/', 'Car\Policy\UnitedIndia@index');
	Route::post('/getpolicy', 'Car\Policy\UnitedIndia@getPolicy')
		->middleware('tarnsaction');
	Route::post('/setproposaldata', 'Car\Policy\UnitedIndia@setProposalData')
		->name('car.policy.uiic.setproposaldata')->middleware('tarnsaction');

});
// end UIIC


Route::group(['prefix' => 'car-insurance/iffcotokio'], function () {
	Route::get('/', 'Car\Policy\IffcoTokio@index');
	Route::get('/paymentstatus', 'Car\Policy\IffcoTokio@returnPage')->name('car.policy.iffcotokio.returnPage');
	Route::post('/getpolicy', 'Car\Policy\IffcoTokio@getPolicy');
	Route::post('/getmaster', 'Car\Policy\IffcoTokio@getApiMasters');
	Route::post('/setproposaldata', 'Car\Policy\IffcoTokio@setProposalData')->name('car.policy.iffcotokio.setproposaldata')->middleware('tarnsaction');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.iffcotokio.proposal_error');

});

Route::group(['prefix' => 'car-insurance/futuregenerali'], function () {
	Route::get('/', 'Car\Policy\FutureGenerali@index');
	Route::get('/paymentstatus', 'Car\Policy\FutureGenerali@returnPage')->name('car.policy.futuregenerali.returnPage');
	Route::post('/getpolicy', 'Car\Policy\FutureGenerali@getPolicy');
	Route::post('/getmaster', 'Car\Policy\FutureGenerali@getApiMasters');
	Route::post('/setproposaldata', 'Car\Policy\FutureGenerali@setProposalData')->name('car.policy.futuregenerali.setproposaldata')->middleware('tarnsaction');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.futuregenerali.proposal_error');
});

// Route::group(['prefix' => 'car-insurance/hdfc'], function () {
// 	Route::get('/', 'Car\Policy\HdfcPolicy@index');
// 	Route::get('/payment/status', 'Car\Policy\HdfcPolicy@returnPage')->name('car.policy.hdfc.returnPage');
// 	Route::post('/getpolicy', 'Car\Policy\HdfcPolicy@getPolicy');
// 	Route::post('/getmaster', 'Car\Policy\HdfcPolicy@getApiMasters');
// 	Route::post('/setproposaldata', 'Car\Policy\HdfcPolicy@setProposalData')->name('car.policy.hdfc.setproposaldata')->middleware('tarnsaction');
// 	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.hdfc.proposal_error');
// });

// uat hdfc
Route::any('car-insurance/hdfc/payment/status','Car\Policy\HDFC@returnPage')->name('car.policy.hdfc.returnPage');

Route::group(['prefix' => 'car-insurance/hdfc'], function () {
	Route::get('/', 'Car\Policy\HDFC@index');
	Route::post('/getpolicy', 'Car\Policy\HDFC@getPolicy');
	Route::post('/get_zerodep_status','Car\Policy\HDFC@getZerodepStatus')
	->name('car.hdfc.zerodep_status');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.hdfc.proposal_error');
	Route::post('/update_paymode', 'Car\Policy\HDFC@update_pay_mode')->name('car.hdfc.update_paymode');
});

Route::group(['prefix' => 'car-insurance/bajajallianz'], function () {
	Route::get('/', 'Car\Policy\Bajajallianz@index');
	Route::get('/paymentstatus', 'Car\Policy\Bajajallianz@returnPage')->name('car.policy.bajajallianz.returnPage');
	Route::post('/getpolicy', 'Car\Policy\Bajajallianz@getPolicy');
	Route::post('/getmaster', 'Car\Policy\Bajajallianz@getApiMasters');
	Route::post('/setproposaldata', 'Car\Policy\Bajajallianz@setProposalData')->name('car.policy.bajajallianz.setproposaldata')->middleware('tarnsaction');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.bajajallianz.proposal_error');
});

//uat bajaj
Route::post('car-insurance/bajaj_quote', 'Car\CarQuote@getBAJAJQuote')->name("car.quote.getbajajquote");
// Route::any('car-insurance/policy/uat/bajaj/{sessionid}', function(){
// 	return redirect('https://general.bajajallianz.com/MotorInsurance/onlineportal/motorNew/indexCar.jsp?p_product_code=1801&src=CBM_02641');
// });
Route::any('car-insurance/policy/uat/bajaj/{transcode}', 'Car\Policy\UAT\BajajAllianz@index')->middleware('tarnsaction');
Route::group(['prefix' => 'car-insurance/bajaj'], function () {
	Route::get('/', 'Car\Policy\UAT\BajajAllianz@index');
	Route::any('/payment/status', 'Car\Policy\UAT\BajajAllianz@returnPage')->name('car.policy.bajaj.returnPage');
	Route::post('/getpolicy', 'Car\Policy\UAT\BajajAllianz@getPolicy');
	Route::post('/getmaster', 'Car\Policy\UAT\BajajAllianz@getApiMasters');
	Route::post('/policy/status','Car\Policy\UAT\BajajAllianz@proposalError')->name('car.bajaj.proposal_error');
	Route::get('/policy/pdf/{trans_code}/{policy_no}','Car\Policy\UAT\BajajAllianz@downloadPolicy')
	->name('car.bajaj.pdf');
});

//end uat bajaj

// UAT Reliance
Route::post('car-insurance/reliance_quote', 'Car\CarQuote@getRelianceQuote')->name("car.quote.getreliancequote");
Route::any('car-insurance/policy/reliance/{transcode}', 'Car\Policy\Reliance@index')->middleware('tarnsaction');
Route::group(['prefix' => 'car-insurance/reliance'], function () {
	Route::get('/', 'Car\Policy\Reliance@index');
	Route::get('/paymentstatus', 'Car\Policy\Reliance@returnPage')->name('car.policy.reliance.returnPage');
	Route::post('/getpolicy', 'Car\Policy\Reliance@getPolicy');
	Route::post('/getmaster', 'Car\Policy\Reliance@getApiMasters');
	Route::get('/policy/status','Car\Policy\Reliance@proposalError')->name('car.reliance.proposal_error');
});
// UAT Reliance  ends here

Route::post('car-insurance/getmaster', 'Car\CarPolicy@getCity')
	->name('car.policy.city');

Route::post('car-insurance/getpincode', 'Car\CarPolicy@getPincode')
	->name('car.policy.pincode');

Route::post('car-insurance/setproposaldata', 'Car\CarPolicy@setProposalData')
	->name('car.policy.setproposaldata')->middleware('tarnsaction');;	

// Royal Sundram Car
Route::group(['prefix' => 'car-insurance/rsgi'], function () {
	Route::post('/payment/status', 'Car\Policy\RoyalSundram@returnPage')->name('car.policy.royal_sundaram.returnPage');
	Route::get('/','Car\Policy\RoyalSundram@index');
	Route::post('/setproposaldata', 'Car\Policy\RoyalSundram@setProposalData')->name('car.policy.royal_sundaram.setproposaldata')->middleware('tarnsaction');
	Route::post('/getpolicy', 'Car\Policy\RoyalSundram@getPolicy')->name('car.policy.royal_sundaram.getpolicy');
	Route::get('/policy/status','Car\CarPolicy@proposalError')->name('car.rsgi.proposal_error');
});

//Route::post('/car-insurance/hdfc/getpolicy', 'Car\Policy\HdfcPolicy@getPolicy');
//Route::post('/car-insurance/hdfc/getmaster', 'Car\Policy\HdfcPolicy@getApiMasters');

Route::post('/car-insurance/bhartiaxa/getpolicy', 'Car\Policy\BhartiAxa@getPolicy');
Route::post('/car-insurance/bhartiaxa/getmaster', 'Car\Policy\BhartiAxa@getApiMasters');

// on sucess and fail status
Route::get('/UI/UnitedResponse.aspx', 'Car\Policy\UnitedIndia@returnPage');
Route::get('/webd/buystatus/545/{STATUS}/{POLICYNUMBER}/{PROPOSALNUMBER}', 'Car\Policy\UnitedIndia@returnPage');
Route::get('/webd/buystatus/545', 'Car\Policy\UnitedIndia@returnPage');
Route::get('/webd/buystatus/125', 'Car\Policy\HdfcPolicy@returnPage');

Route::get('/webd/buystatus/106', 'Car\Policy\IffcoTokio@returnPage');
//Route::get('/webd/buystatus/113', 'Car\Policy\Bajajallianz@returnPage');
//Route::get('/webd/buystatus/134', 'Car\Policy\UniSompo@returnPage');
Route::get('/webd/buystatus/132', 'Car\Policy\FutureGenerali@returnPage');

Route::get('/webd/buystatus/139', 'InstaHome@commonBagiPaymentResponse');

Route::get('/webd/buystatus/113', 'InstaHome@commonBajajPaymentResponse');
Route::get('/webd/buystatus/134', 'InstaHome@commonShompoPaymentResponse');


Route::get('/car-insurance/bagi/payment/status', 'Car\Policy\BhartiAxa@returnPage')->name('bagi.payment_response');
 
/*  ----------------------------------- START: Health Routes ----------------------------------- */

//Super-topup campaign
Route::group(['prefix'=>'health-insurance/super-topup'], function () {
    Route::get('/', 'Health\HealthHome@ShowCampaignIndex');
    Route::post('/save_initial_inputs', 'Health\HealthHome@SaveInitialInputs')->name('health.campaign.save_initial_inputs');
    Route::get('/save_proposal_data', 'Health\HealthPolicy@save_campaign_proposaldata')->name('health.campaign.save_proposal_data');
    Route::get('/close_proposal_page', 'Health\HealthPolicy@close_proposal_page')->name('health.campaign.close_proposal');
    Route::post('/connect_campaign_pg', 'Health\HealthPolicy@connect_campaign_pg')->name('health.campaign.connect_pg');
    Route::get('/save_customer_modal_data', 'Health\HealthHome@saveCustomerModalData')->name('health.campaign.save_cust_modal_data');
    Route::get('/check_otp_status', 'Health\HealthPolicy@check_campaign_otp_status')->name('health.campaign.check_otp_status');
    Route::get('/verify_otp', 'Health\HealthPolicy@verify_campaign_otp')->name('health.campaign.verify_otp');
    Route::get('/report', 'Health\HealthPolicy@campaign_report')->name('health.campaign.report');
    Route::post('/fetch-report', 'Health\HealthPolicy@fetch_campaign_report')->name('health.campaign.fetchreport');
    Route::get('/trigger-sms', 'Health\HealthPolicy@trigger_sms')->name('health.campaign.trigger-sms');
    Route::get('/{transcode}', 'Health\HealthHome@ShowCampaignIndex')->name('health.campaign.show_quote');    
});

//Super-topup campaign ends

// Details Section
Route::get('health-insurance', 'Health\HealthHome@index')->name('health.healthhome');
Route::post('health-insurance/home', 'Health\HealthHome@add_members')->name('health.add-members');
Route::get('health-insurance/get_age', 'Health\HealthHome@age_list');

// Quote Section
Route::post('health-insurance/quote/{transcode}', 'Health\HealthQuote@get_quotes')->name('health.load_policy_page');
Route::get('health-insurance/quote/{transcode}', 'Health\HealthQuote@index_quotes')->name('health.load_policy_page');

Route::get('health-insurance/load_rsgi_quotes', 'Health\HealthQuote@load_rsgi_quote');
Route::get('health-insurance/load_hdfc_quotes', 'Health\HealthQuote@load_hdfc_quote')->name('health.load_hdfc_quotes');
Route::get('health-insurance/load_campaign_proposal', 'Health\HealthPolicy@load_campaign_proposal')->name('health.load_proposal');
Route::get('health-insurance/load_star_quotes', 'Health\HealthQuote@load_star_quote');
Route::get('health-insurance/load_religare_quotes', 'Health\HealthQuote@load_religare_quote');
Route::get('health-insurance/load_reliance_quotes', 'Health\HealthQuote@load_reliance_quote');

Route::get('health-insurance/load_proposal_page','Health\HealthQuote@load_proposal_page');
Route::post('health-insurance/h_benefit_req', 'Health\HealthQuote@get_package_info')->name('health.h_benefit_req');
Route::post('health-insurance/healthbr', 'Health\HealthQuote@get_policy_breakup')->name('healthbr');
// Filter quotes
Route::get('health-insurance/load_filter_covers', 'Health\HealthQuote@filter_covers');
Route::post('health-insurance/get-filterquote', 'Health\HealthQuote@filter_quote')->name('health.get-filterquote');
// this is for religare until update code cleanup
//Route::post('health-insurance/store_user_data', 'Health\HealthQuote@store_user_transaction_data');

// Proposal Section
// RSGI
Route::group(['prefix'=>'health-insurance/rsgi'], function () {
	Route::get('/{trans_code}', 'Health\Policy\RSGI@load_policy_page');
	Route::post('/setproposaldata/trans_code', 'Health\Policy\RSGI@store_proposal_data')->name('health.policy.rsgi.setproposaldata');
	Route::post('/submit_proposal','Health\Policy\RSGI@submit_proposal')->name('health.rsgi_submit_proposal');
	Route::post('/payment/status','Health\Policy\RSGI@policy_return_page')->name('health.policy.rsgi.returnPage');
	Route::get('/payment/status', 'Health\Policy\RSGI@policy_return_page')->name('health.policy.rsgi.returnPage');
	Route::get('/policy/status', 'Health\Policy\RSGI@offline_policy')->name('health.policy.rsgi.offlinepolicy');
});
// HDFC 
Route::group(['prefix'=>'health-insurance/hdfc'], function () {
	Route::post('/setproposaldata/trans_code', 'Health\Policy\HDFC@store_proposal_data')->name('health.policy.hdfc.setproposaldata');
	Route::post('/submit_proposal','Health\Policy\HDFC@submit_proposal')->name('health.hdfc_submit_proposal');
	Route::post('/payment/status','Health\Policy\HDFC@policy_return_page')->name('health.policy.hdfc.returnPage');
	Route::get('/payment/status', 'Health\Policy\HDFC@policy_return_page')->name('health.policy.hdfc.returnPage');
	Route::get('/policy/status', 'Health\Policy\HDFC@offline_policy')->name('health.policy.hdfc.offlinepolicy');
	Route::post('/update_paymode', 'Health\Policy\HDFC@update_pay_mode');
	Route::get('/{trans_code}', 'Health\Policy\HDFC@load_policy_page');
});
// Star 
Route::group(['prefix'=>'health-insurance/star'], function () {
	Route::get('/{trans_code}', 'Health\Policy\Star@load_policy_page');
	Route::post('/setproposaldata/trans_code','Health\Policy\Star@store_proposal_data')->name('health.policy.star.setproposaldata');
    Route::post('health-insurance/state_city', 'Health\Policy\Star@state_city')->name('state_city');
	Route::post('health-insurance/area_city', 'Health\Policy\Star@area_city')->name('area_city');
	Route::post('/submit_proposal','Health\Policy\Star@submit_proposal')->name('health.star_submit_proposal');
	Route::post('/payment/status', 'Health\Policy\Star@policy_return_page')->name('health.policy.star.returnPage');
	Route::get('/payment/status', 'Health\Policy\Star@policy_return_page')->name('health.policy.star.returnPage');
	Route::get('/policy/status', 'Health\Policy\Star@offline_policy')->name('health.policy.star.offlinepolicy');
});
//  Reliance 
Route::group(['prefix'=>'health-insurance/reliance'], function () {
	Route::get('/{trans_code}', 'Health\Policy\Reliance@load_policy_page');
	Route::post('/setproposaldata/trans_code', 'Health\Policy\Reliance@store_proposal_data')->name('health.policy.reliance.setproposaldata');
 	Route::post('/submit_proposal','Health\Policy\Reliance@submit_proposal')->name('health.reliance_submit_proposal');
	Route::post('/payment/status','Health\Policy\Reliance@policy_return_page')->name('health.policy.reliance.returnPage');
	Route::get('/payment/status','Health\Policy\Reliance@policy_return_page')->name('health.policy.reliance.returnPage');
	Route::get('/policy/status', 'Health\Policy\Reliance@offline_policy')->name('health.policy.reliance.offlinepolicy');
	Route::post('health-insurance/state_city_list', 'Health\Policy\Reliance@get_state_city_list')->name('state_city_list');

});
// Religare 
Route::group(['prefix'=>'health-insurance/religare'], function () {
	Route::post('/payment/status/{trans_code}', 'Health\Policy\Religare@payment_response');
	Route::get('/pdf', 'Health\Policy\Religare@get_policy_pdf');
    Route::get('/status/148', 'Health\Policy\Religare@offlinePolicy')->name('health.policy.religare.offlinepolicy');
    Route::post('/submit_proposal', 'Health\Policy\Religare@submit_proposal')->name('health.policy.religare.submit_proposal');
    Route::post('/setproposaldata/trans_code', 'Health\Policy\Religare@setProposalData')->name('health.policy.religare.setproposaldata');
    Route::post('/ppc', 'Health\HealthPolicy@religare_ppc_case');
    Route::get('/{trans_code}', 'Health\Policy\Religare@load_policy_page');
});



//Polisy Section Common URL
Route::post('health-insurance/get-city', 'Health\HealthPolicy@get_city_list')->name('health.get_city');
Route::post('health-insurance/get_areacode','Health\HealthPolicy@get_AreaCode')->name('health.get_area_code');
/* Routes for status */ 
Route::post('/getpremiumstatus', 'Health\HealthPolicy@getPremiumStatus')->name("health.policy.premiumstatus");
Route::post('/premiumreconfirm', 'Health\HealthPolicy@getReConfirmStatus')
                ->name("health.policy.premiumreconfirm");
Route::post('/premiummissmatch', 'Health\HealthPolicy@getPremiumMissmatchStatus')
                ->name("health.policy.premiummissmatchstatus");
Route::post('/badresponse', 'Health\HealthPolicy@getBadResponseStatus')
                ->name("health.policy.badresponse");             
/* Routes for status ends here*/
Route::post('/webd/buystatus/148', 'Health\Policy\Religare@payment_response')->name('health.policy.religare.returnPage'); 
Route::get('/health-insurance/religare_uat/{trans_code}','Health\Policy\Religare@load_policy_page');
Route::get('health-insurance/paymentstatus', 'Health\HealthPolicy@redirectReturn')->name('health.returnPage');
Route::post('healthgetconfirm','Health\HealthPolicy@getReConfirmStatus')->name('health.getconfirm');
Route::post('health-insurance/agestatus','Health\HealthPolicy@getAgeStatus')->name('health.agestatus');
Route::post('health-insurance/policycheck','Health\HealthPolicy@check_policy')->name('health.policy_check');
Route::post('health-insurance/hdfcpolicycheck','Health\HealthPolicy@hdfc_check_policy')->name('health.hdfc_policy_check');
Route::post('health-insurance/starpolicycheck','Health\HealthPolicy@star_check_policy')->name('health.star_policy_check');
Route::post('health-insurance/reliancepolicycheck','Health\HealthPolicy@reliance_check_policy')->name('health.reliance_policy_check');
Route::post('health-insurance/bmistatus','Health\HealthPolicy@getBmiStatus')->name('health.bmistatus');
Route::post('getmismatch', 'Health\HealthPolicy@getMismatchStatus')->name('health.getmismatch');  
Route::get('health/api_bad_response', 'Health\HealthPolicy@badResponse')
		->name('health_api_bad_response');

Route::post('health-insurance/store_payment_status', 'Health\HealthPolicy@store_payment_status');  


// Health OTP Implementation  
Route::post('/genrate_otp', 'Health\HealthPolicy@genrateOtp')->name("health_gen_otp");
Route::post('/verify_otp', 'Health\HealthPolicy@verifyOtp')->name("health_very_otp");


/*  ----------------------------------- END: Health Routes ------------------------------------- */

/*  ------------------------------------ START: TwoWheeler Routes ------------------------------------- */



		
Route::get('/two-wheeler-insurance', 'TW\TwHome@index');
Route::get('/tw/model_list', 'TW\TwHome@model_list');
Route::get('/tw/variant_list', 'TW\TwHome@variant_list');
Route::get('/tw/variant_store', 'TW\TwHome@variant_store');
Route::get('/tw/state_store', 'TW\TwHome@state_store');
Route::get('/tw/rto_store', 'TW\TwHome@rto_store');
Route::get('/tw/yor_store', 'TW\TwHome@yor_store');
Route::get('/tw/details_store', 'TW\TwHome@details_store');


Route::get('/two-wheeler-insurance/quote/{session_key}', 'TW\TwQuote@quote_page');
Route::get('/tw/idv_view_values', 'TW\TwQuote@idv_view_values');
Route::get('/tw/update_idvsec_values', 'TW\TwQuote@update_idvsec_values');
Route::get('/tw/idv_claims_no', 'TW\TwQuote@idv_claims_no');
Route::get('/tw/pex_minmax_dates', 'TW\TwQuote@pex_minmax_dates');
Route::get('/tw/store_addon_covers', 'TW\TwQuote@store_addon_covers');
Route::get('/tw/load_proposal_page', 'TW\TwQuote@load_proposal_page');
Route::get('/tw/get_idv_section','TW\TwQuote@get_idv_section');
Route::get('/tw/store_proposal_data', 'TW\TwPolicy@store_proposal_data');
Route::get('/tw/retrive_proposal_data', 'TW\TwPolicy@retrive_proposal_data');
Route::get('/tw/city_by_state', 'TW\TwPolicy@city_by_state');
Route::get('/tw/pincode_by_city', 'TW\TwPolicy@pincode_by_city');
Route::get('/tw/proposal_submit_overlay', function () { return view('tw.policy.proposal_submit_overlay'); });

// ITGI
Route::get('/tw/load_itgi_quotes', 'TW\TwQuote@load_itgi_quote');
Route::get('/two-wheeler-insurance/itgi/{trans_code}', 'TW\Policy\ITGI@load_policy_page');

// FGGI
Route::get('/tw/load_fggi_quotes', 'TW\TwQuote@load_fggi_quote');
Route::get('/two-wheeler-insurance/fggi/{trans_code}', 'TW\Policy\FGGI@load_policy_page');


// Bajaj
Route::get('/tw/load_bajaj_quotes', 'TW\TwQuote@load_bajaj_quote');
Route::get('/two-wheeler-insurance/bajaj/{trans_code}', 'TW\Policy\Bajaj@load_policy_page');


Route::get('/tw/bajaj_proposal_submit', 'TW\Policy\Bajaj@submit_proposal');
Route::get('/tw/submit_bajaj_payment', 'TW\Policy\Bajaj@submit_payment');
Route::get('/tw/pm_submit_bajaj_payment', 'TW\Policy\Bajaj@pm_submit_payment');
Route::post('/two-wheeler-insurance/bajaj/payment/status', 'TW\Policy\Bajaj@payment_status')->name('tw.policy.bajaj.returnPage');
Route::get('/two-wheeler-insurance/bajaj/policy/status', function () {return view('tw/policy/proposal_error_page');});

// Reliance
Route::get('/tw/load_reliance_quotes', 'TW\TwQuote@load_reliance_quote');
Route::get('/two-wheeler-insurance/reliance/{trans_code}', 'TW\Policy\Reliance@load_policy_page');
Route::get('/tw/reliance_proposal_submit', 'TW\Policy\Reliance@submit_proposal');
Route::get('/tw/submit_reliance_payment', 'TW\Policy\Reliance@submit_payment');
Route::get('/tw/pm_submit_reliance_payment', 'TW\Policy\Reliance@pm_submit_payment');
Route::get('/two-wheeler-insurance/reliance/payment/status', 'TW\Policy\Reliance@payment_status')->name('tw.policy.reliance.returnPage');

Route::get('/two-wheeler-insurance/reliance/policy/status', function () {return view('tw/policy/proposal_error_page');});Route::get('/two-wheeler-insurance/reliance/policy/status', function () {return view('tw/policy/proposal_error_page');});
//UIIC
Route::get('/tw/load_uiic_quotes', 'TW\TwQuote@load_uiic_quote');
Route::get('/tw/uiic_proposal_submit', 'TW\Policy\UIIC@submit_proposal');
Route::get('/tw/submit_uiic_payment', 'TW\Policy\UIIC@submit_payment');
Route::get('/two-wheeler-insurance/uiic/{snn_key}', 'TW\Policy\UIIC@load_policy_page');
Route::any('/two-wheeler-insurance/uiic/payment/status', 'TW\Policy\UIIC@payment_response');
Route::get('/two-wheeler-insurance/uiic/policy/pdf', 'TW\Policy\UIIC@uiic_policy_pdf');

//UIIC TP
// Route::get('/two-wheeler-insurance/tp', 'TW\TwTp@load_tphome');
// Route::get('/twtp/get_policy_dates', 'TW\TwTp@calc_policy_dates');
// Route::get('/twtp/submitproposal', 'TW\TwTp@submit_payment');
// Route::post('/two-wheeler-insurance/tp/uiic/payment/status', 'TW\TwTp@payment_response');
// Route::get('/two-wheeler-insurance/tp/uiic/policy/pdf', 'TW\TwTp@uiictp_policy_pdf');

//HDFC
Route::get('/tw/load_hdfc_quotes', 'TW\TwQuote@load_hdfc_quote');
Route::get('/two-wheeler-insurance/hdfc/{snn_key}', 'TW\Policy\Hdfc@load_policy_page');
Route::get('/tw/hdfc_proposal_submit', 'TW\Policy\Hdfc@submit_proposal');
Route::get('/tw/submit_hdfc_payment', 'TW\Policy\Hdfc@submit_payment');
Route::get('/tw/pm_submit_hdfc_payment', 'TW\Policy\Hdfc@pm_submit_payment');
Route::any('/two-wheeler-insurance/hdfc/payment/status', 'TW\Policy\Hdfc@payment_status');
Route::get('/two-wheeler-insurance/hdfc/policy/status', function () {return view('tw/policy/proposal_error_page');});

//RSGI
Route::get('/tw/load_rsgi_quotes', 'TW\TwQuote@load_rsgi_quote');
Route::get('/two-wheeler-insurance/rsgi/{snn_key}', 'TW\Policy\RSGI@load_policy_page');
Route::get('/tw/rsgi_proposal_submit', 'TW\Policy\RSGI@submit_proposal');
Route::get('/tw/submit_rsgi_payment', 'TW\Policy\RSGI@submit_payment');
Route::get('/tw/pm_submit_rsgi_payment', 'TW\Policy\RSGI@pm_submit_payment');
Route::get('/two-wheeler-insurance/rsgi/policy/status', function () {return view('tw/policy/proposal_error_page');});
Route::post('/two-wheeler-insurance/rsgi/payment/status', 'TW\Policy\RSGI@payment_status');

//MHDI
Route::get('/tw/load_mhdi_quotes', 'TW\TwQuote@load_mhdi_quote');

/*  ------------------------------------  END: TwoWheeler Routes ------------------------------------- */

/*  ------------------------------------  START: Travel Routes ------------------------------------- */
 
//DETAILS PAGE
route::get('travel-insurance', 'Travel\TravelHome@index')->name('travel.home');
Route::get('travel-insurance', 'Travel\TravelHome@index')->name('updatereq');

Route::group(['prefix'=>'travel-insurance/home'], function () {
    Route::get('/load_travel_area', 'Travel\TravelHome@load_travel_area');
    Route::get('/load_travel_duration', 'Travel\TravelHome@load_travel_duration');
    Route::get('/load_traveller_list', 'Travel\TravelHome@load_traveller_list');
    Route::get('/add_new_traveller', 'Travel\TravelHome@add_new_traveller');
    Route::get('/load_traveller_age_list', 'Travel\TravelHome@load_traveller_age_list');
    Route::get('/save_user_data', 'Travel\TravelHome@save_user_data');
}); 

//QUOTES
Route::post('quote', 'Travel\TravelQuote@getquotes');
Route::get('travel-insurance/quotes/{trans_code}','Travel\TravelQuote@getquotes')->name('travel.getquotes');
Route::get('travel-insurance/save_policyid/{trans_code}', 'Travel\TravelQuote@save_policyid')->name('save_policyid');
Route::get('travel-insurance/travel_filter_quote/{trans_code}', 'Travel\TravelQuote@filter_quote')->name('travel_filter_quote');
Route::post('travel-insurance/documents/save', 'Travel\TravelQuote@getPdf')->name('saveBreakup');
Route::post('travel-insurance/inputreq', 'Travel\TravelHome@getHTMLInputs'); // For Update Page
Route::get('breakupreq/{trans_code}', 'Travel\TravelQuote@get_breakup')->name('breakupreq'); // For Quotes Page / Premium Breakup
Route::get('benefitreq/{trans_code}', 'Travel\TravelQuote@get_benefits')->name('benefitreq');
Route::get('travel-insurance/quote/{trans_code}','Travel\TravelQuote@back')->name('backtoquote');
Route::post('map_sum_insured', 'Travel\TravelQuote@mapSumInsured')->name('map_sum_insured');

Route::group(['prefix'=>'travel-insurance'], function () {
    Route::post('/load_tata_quotes', 'Travel\TravelQuote@load_tata_quotes');
    Route::post('/load_hdfc_quotes', 'Travel\TravelQuote@load_hdfc_quotes');
    Route::post('/load_star_quotes', 'Travel\TravelQuote@load_star_quotes');
    Route::post('/load_religare_quotes', 'Travel\TravelQuote@load_religare_quotes');
    Route::post('/load_fggi_quotes', 'Travel\TravelQuote@load_fggi_quotes');
    Route::post('/load_covers', 'Travel\TravelQuote@load_covers');
}); 

//HDFC
Route::group(['prefix'=>'travel-insurance/hdfc'], function () {
    Route::get('/set_proposal', 'Travel\Policy\Hdfc@set_proposal_data')->name('travel.hdfc.setproposal');
    Route::get('/submit_proposal', 'Travel\Policy\Hdfc@submit_proposal');
    Route::get('/payment/status', 'Travel\Policy\Hdfc@payment_response');
    Route::get('/update_paymode', 'Travel\Policy\Hdfc@update_paymode');
    Route::get('/policy/status/offline', 'Travel\TravelPolicy@offline_response');
    Route::get('/policy/status', 'Travel\Policy\Hdfc@post_payment_status')->name('travel_hdfc_post_payment_status');
    Route::get('/{trans_code}', 'Travel\Policy\Hdfc@load_policy_page');
}); 

//RELIGARE
Route::group(['prefix'=>'travel-insurance/religare'], function () {
	Route::get('/set_proposal', 'Travel\Policy\Religare@set_proposal_data')->name('travel.religare.setproposal');
	Route::get('/submit_proposal', 'Travel\Policy\Religare@submit_proposal');
	Route::post('/payment/status/{trans_code}', 'Travel\Policy\Religare@payment_response');
	Route::get('/policy/status', 'Travel\Policy\Religare@post_payment_status')->name('travel_religare_post_payment_status');
	Route::get('/pdf', 'Travel\Policy\Religare@get_policy_pdf');
    Route::get('/{trans_code}', 'Travel\Policy\Religare@load_policy_page');
});


//FGGI
Route::group(['prefix'=>'travel-insurance/fggi'], function () {
    Route::get('/set_proposal', 'Travel\Policy\Fggi@set_proposal_data')->name('travel.fggi.setproposal');
    Route::get('/submit_proposal', 'Travel\Policy\Fggi@submit_proposal');
    Route::get('/payment/status', 'Travel\Policy\Fggi@payment_response');
    Route::get('/policy/status', 'Travel\Policy\Fggi@post_payment_status')->name('travel_fggi_post_payment_status');
    Route::get('/policy/status/offline', 'Travel\TravelPolicy@offline_response');
    Route::get('/{trans_code}', 'Travel\Policy\Fggi@load_policy_page');
}); 
        
//TATA
Route::group(['prefix'=>'travel-insurance/tata'], function () {
    Route::get('/set_proposal', 'Travel\Policy\Tata@set_proposal_data')->name('travel.tata.setproposal');
    Route::get('/submit_proposal', 'Travel\Policy\Tata@submit_proposal');
    Route::get('/get_user_agreement', 'Travel\Policy\Tata@get_user_agreement');
    Route::get('/payment/status', 'Travel\Policy\Tata@payment_response');
    Route::get('/policy/status/offline', 'Travel\TravelPolicy@offline_response');
    Route::get('/policy/status', 'Travel\Policy\Tata@post_payment_status')->name('travel_tata_post_payment_status');
    Route::get('/{trans_code}', 'Travel\Policy\Tata@load_policy_page');
});


//STAR
Route::group(['prefix'=>'travel-insurance/star'], function () {
    Route::get('/set_proposal', 'Travel\Policy\Star@set_proposal_data')->name('travel.star.setproposal');
    Route::get('/submit_proposal', 'Travel\Policy\Star@submit_proposal');
    Route::get('/payment/status', 'Travel\Policy\Star@payment_response');
    Route::get('/policy/status/offline', 'Travel\TravelPolicy@offline_response');
    Route::get('/policy/status', 'Travel\Policy\Star@post_payment_status')->name('travel_star_post_payment_status');
    Route::get('/get_state_city_list', 'Travel\Policy\Star@get_state_city_list');
        Route::get('/get_travel_date', 'Travel\Policy\Star@get_travel_date');

    Route::get('/get_area_list', 'Travel\Policy\Star@get_area_list');
    Route::get('/{trans_code}', 'Travel\Policy\Star@load_policy_page');
}); 


//COMMON PROPOSAL
Route::group(['prefix'=>'travel-insurance'], function () {
	Route::post('/load_proposal_page', 'Travel\TravelQuote@load_proposal_page')->name('travel.load_proposal');

    Route::get('/get_city', 'Travel\TravelPolicy@get_city')->name('getcity');
    Route::get('/get_trip_end_date', 'Travel\TravelPolicy@get_trip_end_date');
    Route::get('/load_preview', 'Travel\TravelPolicy@load_preview');
    Route::get('/get_confirm_box', 'Travel\TravelPolicy@get_confirm_box');
    Route::get('/no_premium_change', 'Travel\TravelPolicy@get_no_premium_change_box');
    Route::get('/premium_mismatch', 'Travel\TravelPolicy@get_premium_mismatch_box');
    Route::get('/update_payment_status', 'Travel\TravelPolicy@update_payment_status');
    Route::get('/bad_response', 'Travel\TravelPolicy@bad_response');
});   

// OTP IMPLEMENTATION END
Route::post('travel_gen_otp', 'Travel\TravelPolicy@genrateOtp')->name("travel_gen_otp");
Route::post('travel_very_otp', 'Travel\TravelPolicy@verifyOtp')->name("travel_very_otp");


/*  ------------------------------------  END: Travel Routes ------------------------------------- */


/*  ------------------------ Admin/Agent Routes Starts -------------------------- */

Route::get('/login', 'Auth\LoginCntlr@login_page')->name('login');
Route::post('/usr-login', 'Auth\LoginCntlr@validate_login');
Route::get('/agent-logout', 'Auth\LoginCntlr@logout');

Route::group(['middleware' => 'auth_agent'], function() {
	Route::get('/agent/dashboard', 'Agent\AgentCntlr@load_dashboard')->name('agent.dashboard');
	Route::get('/agent/reports/trans-summary-search', 'Agent\ReportCntlr@trans_summary_search');
	Route::get('/agent/reports/trans-summary-data', 'Agent\ReportCntlr@trans_summary_data');
	Route::get('/agent/reports/policy-summary-report', 'Agent\ReportCntlr@policy_summary_report');
	Route::get('/agent/graph/bar_graph', 'Agent\ReportCntlr@dashboard_chart');
	Route::get('/agent/operations/policy-schedule', 'Agent\OprCntlr@generateSchedule');
	Route::post('/agent/operations/download-policy-schedule', 'Agent\OprCntlr@downloadPolicySchedule');
	Route::get('/agent-logout', 'Agent\AgentCntlr@logout');
	Route::get('/agent/change-password', function(){
		return view('agent/change_password');
	});
	Route::post('/agent/change-password', 'Auth\LoginCntlr@updatePassword')->name('agent.change-password');
});

Route::group(['middleware' => 'auth_admin'], function() {
	Route::get('/admin/dashboard', 'Admin\AdminCntlr@load_dashboard')->name('admin.dashboard');
	Route::get('/admin-logout', 'Admin\AdminCntlr@logout');
	Route::get('/admin/reports/premium-summary-report', 'Admin\ReportCntlr@premium_summary_report');
	Route::get('/admin/reports/premium-summary-report-xls', 'Admin\ReportCntlr@premium_summary_report_xls');
	Route::get('/admin/reports/policy-summary-report', 'Admin\ReportCntlr@policy_summary_report');
	Route::get('/admin/graph/bar_graph', 'Admin\ReportCntlr@dashboard_chart');
	Route::get('/admin/reports/trans-summary-search', 'Admin\ReportCntlr@trans_summary_search');
	Route::get('/admin/reports/trans-summary-data', 'Admin\ReportCntlr@trans_summary_data');
	Route::get('/admin/operations/policy-schedule', 'Admin\OprCntlr@generateSchedule');
	Route::post('/admin/operations/download-policy-schedule', 'Admin\OprCntlr@downloadPolicySchedule');
	Route::get('/admin/change-password', function(){
		return view('admin/change_password');
	});
	Route::post('/admin/change-password', 'Auth\LoginCntlr@updatePassword')->name('admin.change-password');
});


/*  ------------------------ Admin/Agent Routes Ends -------------------------- */


